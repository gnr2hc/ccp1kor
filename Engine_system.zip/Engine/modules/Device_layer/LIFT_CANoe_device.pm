# *****************************************************************************************************
#
#  Copyright (c) 2017  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
# ******************************************************************************************************
# ******************************************************************************************************

package LIFT_CANoe_device;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

use File::Basename;
use File::Copy;
use strict;
use warnings;
use LIFT_general;
use LIFT_numerics;
use LIFT_simulation;
use POSIX qw/floor/;

# next 2 lines edited by CVS, DO NOT MODIFY

@ISA    = qw(Exporter);
@EXPORT = qw(
  CANoe_Init
  CANoe_start_measurement
  CANoe_stop_measurement
  CANoe_measurement_running_status

  CANoe_read_signal
  CANoe_write_signal

  CANoe_set_envVar_value
  CANoe_get_envVar_value
  CANoe_set_sysVar_value
  CANoe_get_sysVar_value

  CANoe_enable_msg
  CANoe_disable_msg
  CANoe_set_dlc
  CANoe_reset_dlc
  CANoe_set_counter_error
  CANoe_reset_counter_error
  CANoe_set_crc_error
  CANoe_reset_crc_error

  CANoe_trace_store
  CANoe_trace_logging_start
  CANoe_trace_logging_stop
  CANoe_trace_analyze_format
  CANoe_trace_get_message_dataref
  CANoe_trace_get_signal_dataref
  CANoe_trace_get_sysvar_dataref
  CANoe_trace_delete

);

our ( $VERSION, $HEADER );

# Error codes
use constant ERR_OLE_INIT_CANOE             => 111;
use constant ERR_VECTOR_CANOE_CONFIGURATION => 131;
use constant ERR_INVALID_PARAMETERS         => 114;

# log levels
use constant WRLOG_LEVEL_3 => 3;
use constant WRLOG_LEVEL_4 => 4;
use constant WRLOG_LEVEL_5 => 5;

# for internal data storage
our $CANoe_dev_control_href;

my @StimulatedFunctionalites = qw(
  CallCOM_Method
  GetCOM_objProperty
  SetCOM_Property
  GetObjProperty
  SetObjProperty
  GetCOM_Object
  Get_oleHandle
  S_create_OLE
  CANoe_get_configured_logfile_names
  CANoe_set_EnvVar_value_by_type
  CANoe_get_EnvVar_value_by_type
  CANoe_get_bus_signal_object
  CANoe_get_sys_variable
  CallObj_Method
);

if ($main::opt_simulation) {
    no strict 'refs';

    # redefine functions for simulation mode with default return values
    foreach my $function (@StimulatedFunctionalites) {

        # each function specifed is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = { 'GetCOM_Object' => { 'default' => [1] }, };
    SIM_addToValuesTable($returnValuesTable_href);
}

=head1 NAME

LIFT_CANoe_device 

Provide interface to access the CANoe functionalites via COM.

=head1 SYNOPSIS

    use LIFT_CANoe_device    
    CANoe_Init();    
    CANoe_start_measurement();
    
    # signal : read & write
    ($read_value, $unit ) = CANoe_read_signal($signalInfo_href, 'phys');
    CANoe_write_signal($signalInfo_href , 10, 'phys');  
     
    # Environment & system variables.  
    CANoe_set_envVar_value('Env_Var_Typ_int', 10);
    $intVal = CANoe_get_envVar_value('Env_Var_Typ_int');
    CANoe_set_sysVar_value('LIFT_CAN_access::SysVar_Type_Int', 0xFF) ;
    $intVal = CANoe_get_sysVar_value('LIFT_CAN_access::SysVar_Type_Int') ;       

    # message : 'Disable/enable msg', 'reset/set Dlc', 'set/reset BZ error', 'set/reset crc error'
    CANoe_disable_msg( $msgInfo_href );
    CANoe_enable_msg( $msgInfo_href );    
    CANoe_set_dlc( $msgInfo_href );
    CANoe_reset_dlc( $msgInfo_href );
    CANoe_set_counter_error( $msgInfo_href );
    CANoe_reset_counter_error( $msgInfo_href );
    CANoe_set_crc_error( $msgInfo_href );
    CANoe_reset_crc_error( $msgInfo_href );
    
    CANoe_trace_logging_start();
    CANoe_trace_logging_stop();    
    
    CANoe_stop_measurement();
    CANoe_trace_store();

=head1 DESCRIPTION

This module access the CANoe application and provides below functionalities  :
 
=over 3

=item * start & stop RBS with or without trace logging 

=item * read (CAN, LIN & FlexRay) signals

=item * write (CAN, LIN & FlexRay) signals

=item * stimulation of (CAN, LIN & FlexRay) signals

=item * set & get Environment variables.

=item * set & get system variables.

=item * to Enable & Disbale (CAN, LIN & FlexRay) message.

=item * to reset & set DLC for (CAN, LIN & FlexRay).

=item * to set valid & invalid CRC for (CAN, LIN & FlexRay).

=item * to set valid & invalid BZ for (CAN, LIN & FlexRay).

=item * get the copy of CANoe Trace if logged by CANoe.

=item * get the content of CANoe trace into a data structure for Evaluation.

=item * call user written CAPL functions .
 
=back

=head2 Prerequisites

In order to work with this module following are recommended :  

=over 3

=item * to have basic knowledge of CAN, LIN & FlexRay protocol refer :

=for html
<a href='https://elearning.vector.com/vl_can_introduction_en.html'>vector CAN e-training</a>

=item * basic knowledge of CANoe (for eg. compiling of .cfg file, editing some CAPL program, creating Environment variables in dbc file etc.)

=back

=cut

=head2 TestBench configuration

=head3 Devices section:

    'Devices' => {
        ... 
        'CANoe' => {
            'Hostname'                       => 'BMH1045912',
            'Online_Config'                  => 'C:\TurboLIFT\Engine\test\CANoe\LIFT_CAN_access\COMDemo.cfg',
            'Log_File'                       => 'C:\temp\CANOE_log.asc',                          
            'Keep_Application_After_Test'    => 1,
        },
        ...
      },

B<'Hostname':> It is recommended to have Canoe running on the same host as TurboLIFT. 
If really needed then Canoe can also run on a different host, but then the handling of log files is more difficult.

B<'Online_Config':> Path B<on 'Hostname'> to the .cfg file to be loaded.

B<'Log_File':> Path B<on TurboLIFT host> to the log file that is configured in the defined .cfg file (see 'Online_Config').

B<'Keep_Application_After_Test':> (optional) If set to 1 then Canoe will stay open after test. 
By default Canoe will be closed after the test.

=cut

=head1 Application 

=head2 CANoe_Init

    $returnValue = CANoe_Init();

Does the initialization steps for CANoe application. It includes launching of CANoe application on the 'B<Hostname>', 
loading of the CANoe configuration (.cfg) file 'B<Online_Config>' and checking if the specified 'B<Log_File>' from TestBench is configured in CANoe or not.

B<Hostname> , B<Online_Config> & B<Log_File> are taken from TestBench L</"Devices section:"> under 'CANoe'. 
    
=cut

sub CANoe_Init {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_Init ()', @args );

    my $device = 'CANoe';

    Write_Log_Text(" start ..\n");

    my ( $hostname, $currently_loaded_device );

    my $testbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );

    # STEP Get the 'hostname' from testbench
    unless ( $hostname = $testbench->{'Devices'}{$device}{'Hostname'} ) {
        Write_Error_Text( "No 'Hostname' defined for Device '$device' ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text(" found hostname = '$hostname' from Testbench.");

    my $ole_handle;
    my ( $errTxt, $suggTxt );

    if ( not $currently_loaded_device = $CANoe_dev_control_href->{'DeviceType'} ) {

        # STEP initialze the CANoe application
        unless ( $ole_handle = CANoe_start_application( $device, $hostname ) ) {
            $errTxt  = "Could not start '$device' application on host '$hostname'.\n";
            $suggTxt = "Launch CANoe manually and check whether its opening successfully without any errors or warnings with the last used CANoe Config";
            Write_Error_Text( "ERROR - $errTxt Suggestion - $suggTxt ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }

        # STEP print CANoe version - info
        CANoe_get_application_version($ole_handle);

        # STEP Get the Canoe .cfg file from testbench
        my $onlineCfg_testBench;
        unless ( $onlineCfg_testBench = $testbench->{'Devices'}{$device}{'Online_Config'} ) {
            Write_Error_Text( "No 'Online_Config' defined for 'CANoe' in LIFT_Testbench.", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
        Write_Log_Text(" found Online_Config = '$onlineCfg_testBench' from Testbench.");

        # STEP Load CANoe configuration
        unless ( CANoe_open_configuration( $ole_handle, $onlineCfg_testBench, 1 ) ) {
            Write_Error_Text( "Could not open '$device' configuration '$onlineCfg_testBench'", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
        $CANoe_dev_control_href->{$ole_handle}{'cfg'}{'DefaultOnlineConfig'} = $onlineCfg_testBench;

        # STEP Check the trace log file
        my $logfile_testBench;
        unless ( $logfile_testBench = $testbench->{'Devices'}{$device}{'Log_File'} ) {
            Write_Error_Text( "No 'Log_File' defined for Device '$device' ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
        Check_configured_trace_file( $logfile_testBench, $onlineCfg_testBench );

    }
    else {
        if ( $device =~ /$currently_loaded_device/ ) {
            Write_Log_Text( " 'CANoe' application on host '$hostname' already started.", WRLOG_LEVEL_3 );
            $ole_handle = $CANoe_dev_control_href->{'OLE_handle'};
        }
        else {
            Write_Error_Text( "cannot start 'CANoe' application on $hostname (loaded device '$currently_loaded_device' is not equal to '$device').", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
    }

    # STEP Store setting if CANoe application has to be kept alive or has to be quit
    if ( my $keep_application_after_test = $testbench->{'Devices'}{$device}{'Keep_Application_After_Test'} ) {
        $CANoe_dev_control_href->{$ole_handle}{'cfg'}{'Keep_Application_After_Test'} = 1;
    }
    else {
        $CANoe_dev_control_href->{$ole_handle}{'cfg'}{'Keep_Application_After_Test'} = 0;
    }

    Write_Log_Text(" end ..");
    return 1;
}

=head2 CANoe_start_application

    $OLE_handle = CANoe_start_application($device, $hostname);

Creates the OLE handle for the $device on $hostname.

Here the device is 'CANoe' and $hostname is from TestBench L</"Devices section:"> under 'CANoe' => B<Hostname>.

Called internally by L</"CANoe_Init">.

=cut

sub CANoe_start_application {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_start_application ($device, $hostname)', @args );

    my $device   = shift @args;
    my $hostname = shift @args;

    my ( $vector_cantool_OLE_call, $device_already_running, $ole_handle, );

    Write_Log_Text(" start ..");

    #STEP error if device is not CANoe
    unless ( $device =~ /^CANoe$/i ) {
        Write_Error_Text( "wrong device '$device' (supported is 'CANoe')", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    $vector_cantool_OLE_call = "CANoe.Application" if $device =~ /CANoe/i;

    #STEP warning if host is not reachable
    unless ( S_ping($hostname) ) {
        Write_Error_Text( "Could not reach host '$hostname'  \n may be just a network problem with 'ping'-function \n anyway - try to load config again..", 0 );
    }

    #STEP return if this function has been called before
    if ( $device_already_running = $CANoe_dev_control_href->{'Hostname'} ) {
        Write_Log_Text(" Couldnt load a second CAN tool application on host '$hostname'  ($device_already_running is active) \n");
        return;
    }

    #STEP if the corresponding function has been called in LIFT_vector_cantool then get the OLE handle from there and return it
    if ( defined $LIFT_vector_cantool::Vector_tool_control and $device_already_running = $LIFT_vector_cantool::Vector_tool_control->{'Hostname'}{$hostname} ) {
        Write_Log_Text(" CAN tool application ($device_already_running) is already running on host '$hostname' (called by LIFT_vector_cantool) \n");
        $ole_handle = $LIFT_vector_cantool::Vector_tool_control->{'Devices'}{$device}{'OLE_handle'};
        $CANoe_dev_control_href->{'OLE_handle'}              = $ole_handle;
        $CANoe_dev_control_href->{'DeviceType'}              = $device;
        $CANoe_dev_control_href->{'Hostname'}                = $hostname;
        $CANoe_dev_control_href->{$ole_handle}{'DeviceType'} = $device;
        $CANoe_dev_control_href->{$ole_handle}{'Hostname'}   = $hostname;
        return $ole_handle;
    }

    #STEP kill the application if it is currently running
    # If the application is running at this point then it was not started by TurboLIFT. In that case kill it.
    S_kill_process($device, $hostname);
    S_wait_ms(1000); # without wait time the application sometimes does not start after kill

    #STEP start application
    unless ( $ole_handle = S_create_OLE( $vector_cantool_OLE_call, $hostname, \&CANoe_close_application ) ) {
        Write_Error_Text( "Error creating OLE object on host '$hostname' for device '$device' and application $vector_cantool_OLE_call. ", ERR_OLE_INIT_CANOE );
        return;
    }
    $CANoe_dev_control_href->{'OLE_handle'}              = $ole_handle;
    $CANoe_dev_control_href->{'DeviceType'}              = $device;
    $CANoe_dev_control_href->{'Hostname'}                = $hostname;
    $CANoe_dev_control_href->{$ole_handle}{'DeviceType'} = $device;
    $CANoe_dev_control_href->{$ole_handle}{'Hostname'}   = $hostname;
    Write_Log_Text(" end .. oleHandle = $ole_handle");

    return $ole_handle;
}

=head2 CANoe_close_application

    $status = CANoe_close_application($ole_handle);

It closes the CANoe application which was running on $hostname.
Before closing the application measurement was stopped if runnnig before.

CANoe application will stay open if B<Keep_Application_After_Test> = 1 from TestBench L</"Devices section:"> under 'CANoe'. 
By default Canoe will be closed after the test.

Called when TurboLIFT execution was ended.

=cut

sub CANoe_close_application {

    Write_Log_Text(" start  .. ");

    # STEP retrun 1 in offline case
    return 1 if $main::opt_offline;

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP Check if CANoe application object is defined
    Write_Log_Text(" check if $ole_handle -> Application exists ?  .. ");
    if ( not defined GetObjProperty( $ole_handle, 'Application' ) ) {
        print( " CANoe_close_application : probably CANoe application is alreay closed as object : OLE_handle -> Application not found. \n", 0 );
        Write_Error_Text( "probably CANoe application is alreay closed as object : OLE_handle -> Application not found", 0 );
        return;
    }

    if ( not defined GetObjProperty( $ole_handle, 'Measurement' ) ) {
        Write_Error_Text( "could not get object : OLE_handle -> Measurement", 0 );
        return;
    }

    # STEP Stop CANoe measurement if already running
    Write_Log_Text("$ole_handle -> Measurement -> Running() .. ");

    if ( CallCOM_Method( $ole_handle, ['Measurement'], 'Running' ) ) {
        S_get_LastError_OLE();
        Write_Log_Text(" $device Stop Measurement on $hostname ");
        Write_Log_Text(" $ole_handle -> Measurement -> Stop() .. ");
        CallCOM_Method( $ole_handle, ['Measurement'], 'Stop' );
        S_get_LastError_OLE();
    }

    #IF Keep_Application_After_Test is true?
    	#IF-YES-START
    	#IF-YES-END
    unless ( $CANoe_dev_control_href->{$ole_handle}{'cfg'}{'Keep_Application_After_Test'} ) {
    	#IF-NO-START
        # STEP close application
        print("CANoe_close_application $device on $hostname Quit Application \n");
        my $result = CallCOM_Method( $ole_handle, ['Application'], 'Quit' );
        S_wait_ms(2000);
        S_get_LastError_OLE();

        #STEP kill the application if it is still running
        S_kill_process($device, $hostname);
    	#IF-NO-END
    }

    # STEP delete used hash for storage
    delete $CANoe_dev_control_href->{'DeviceType'};
    delete $CANoe_dev_control_href->{'OLE_handle'};
    delete $CANoe_dev_control_href->{$ole_handle};

    Write_Log_Text(" end .. ");

    return 1;
}

=head2 CANoe_get_application_version

    $cantool_version = CANoe_get_application_version($ole_handle, [$type]);

Returns the CANoe Application version based on the $type.

By default it return the 'FullName' of the CANoe version ex. "Vector CANoe /run 8.0.40" or "Vector CANalyzer.LIN /exp 8.0.40".
else it returns Major version.

$type = B<'Fullname' | 'Major'>, default is 'Fullname'.

Called internally by L</"CANoe_Init">.

=cut

sub CANoe_get_application_version {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_application_version ($ole_handle_mix, [$type])', @args );

    my $ole_handle = shift @args;
    my $type       = shift @args;

    return 'Vector CANoe.LIN.FlexRay offlne' if $main::opt_offline;

    # STEP Get CANoe application version
    my $version_object;
    unless ( $version_object = GetCOM_Object( $ole_handle, [ 'Application', 'Version' ] ) ) {
        Write_Error_Text( "could not get object : OLE_handle -> Application -> Version. Not supported from CANoe", 0 );
        return;
    }

    $type = 'fullname' if not defined $type;
    my $cantool_version;

    # STEP Get CANoe application version for type FullName
    if ( $type =~ /fullname/i ) {
        Write_Log_Text( " OLE_handle -> Application -> Version -> { 'FullName' } .. ", WRLOG_LEVEL_5 );
        $cantool_version = GetCOM_objProperty( $ole_handle, [ 'Application', 'Version' ], 'FullName' );
        Write_Log_Text(" 'FullName' version '$cantool_version' ");

    }

    # STEP Get CANoe application version for type 'major'
    if ( $type =~ /major/i ) {
        Write_Log_Text( " OLE_handle -> Application -> Version -> { 'Major' } .. ", WRLOG_LEVEL_5 );
        $cantool_version = GetCOM_objProperty( $ole_handle, [ 'Application', 'Version' ], 'Major' );
        Write_Log_Text(" 'Major' version '$cantool_version' ");
    }

    # STEP return found CANoe application version
    return $cantool_version;
}

=head1 Configuration 

=head2 CANoe_open_configuration

    $status = CANoe_open_configuration($ole_handle_mix, $config_file , [$visible_mode]);
    
Loads a CANoe configuration '$config_file' file. Before loading the .cfg it makes the CANoe application visible if $visible_mode = 1.

CANoe configuration will be opened two modes 

- B<Autosave mode = 'True'> means the active configuration should be saved if it has been changed. 

- B<promptUser mode = 'False'> indicates that user should intervene in error situations.

Called internally by L</"CANoe_Init">.

=cut

sub CANoe_open_configuration {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_open_configuration ($ole_handle_mix, $config_file , [$visible_mode])', @args );

    my $ole_handle   = shift @args;
    my $config_file  = shift @args;
    my $visible_mode = shift @args;

    my $device   = Get_deviceType($ole_handle) || return;
    my $hostname = Get_hostName($ole_handle)   || return;

    # check if active configuration (loaded configuration) is same as given config file via Test bench.
    return 1 if ( CANoeCfg_alreadyLoaded( $ole_handle, $config_file ) );

    # STEP handle offline mode (return 1)
    return 1 if $main::opt_offline;

    # STEP visible mode ?
    if ($visible_mode) {
        Write_Log_Text(" Set '$device' Visible .. ");
        Write_Log_Text( " OLE_handle -> Application -> { 'Visible' } = 1 .. ", WRLOG_LEVEL_5 );
        SetCOM_Property( $ole_handle, ['Application'], 'Visible', 1 );
        S_get_LastError_OLE();
    }

    #
    # STEP open the $config_file
    #
    Write_Log_Text(" '$device on $hostname' Opening config (AutoSave=True , PromptUser=False) - '$config_file' ");
    Write_Log_Text( " OLE_handle -> Application -> Open( $config_file , 1 , 0 ) .. ", WRLOG_LEVEL_5 );
    CallCOM_Method( $ole_handle, ['Application'], 'Open', [ $config_file, 1, 0 ] );
    S_get_LastError_OLE();

    my $active_config_fullname;

    # STEP return when no config could be read
    return unless $active_config_fullname = CANoe_read_configuration($ole_handle);

    # return when loaded config doesnt correspond with required config
    #  (CANtool is loading mostly a default config)
    unless ( lc basename($config_file) eq lc basename($active_config_fullname) ) {
        S_wait_ms(1000);

        # try to load config 2nd time
        return unless $active_config_fullname = CANoe_read_configuration($ole_handle);
        unless ( lc basename($config_file) eq lc basename($active_config_fullname) ) {
            Write_Error_Text( "'$device' Loading config '$config_file' failed (currently loaded config: '$active_config_fullname')", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
    }

    Write_Log_Text(" CANoe Configuration file loaded succesfully .. ");
    return 1;
}

=head2 CANoe_read_configuration

   $fullName = CANoe_read_configuration($ole_handle)
   
Returns the full path to the currently loaded configuration.   

Called internally by L</"CANoe_open_configuration">.

=cut

sub CANoe_read_configuration {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_read_configuration ($ole_handle_mix)', @args );
    my $ole_handle = shift @args;

    my $device   = Get_deviceType($ole_handle) || return;
    my $hostname = Get_hostName($ole_handle)   || return;

    return 'CANoeCfg_Offline' if $main::opt_offline;    # just return if running in offline mode

    # STEP Get full name of Cfg 'configuration file' from OLE
    Write_Log_Text( " FullName = OLE_handle -> Application -> Configuration -> { 'FullName' } ..", WRLOG_LEVEL_5 );
    my $loaded_configuration_fullName = GetCOM_objProperty( $ole_handle, [ 'Application', 'Configuration' ], 'FullName' );

    S_get_LastError_OLE();
    unless ( defined $loaded_configuration_fullName ) {
        Write_Error_Text( "'$device' on $hostname Couldnt read currently loaded configuration: $!", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text(" $device '$loaded_configuration_fullName' (host: $hostname) ");

    # STEP return full name of cfg'
    return $loaded_configuration_fullName;
}

=head2 CANoeCfg_AlreadyLoaded

   $statusCfgLoaded =  CANoeCfg_alreadyLoaded ($ole_handle_mix, $config_file);

It checks if the specified file '$config_file' is already loaded or not. And returns the cfg loaded status.   

=cut

sub CANoeCfg_alreadyLoaded {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCfg_alreadyLoaded ($ole_handle_mix, $config_file)', @args );
    my $ole_handle  = shift @args;
    my $config_file = shift @args;

    my $loaded_cfg_fullName = CANoe_read_configuration($ole_handle);

    my $statusCfgLoaded = 0;
    if ( lc basename($loaded_cfg_fullName) eq lc basename($config_file) ) {
        Write_Log_Text(" CANoe config '$config_file' is already loaded .. ");
        $statusCfgLoaded = 1;
    }
    return $statusCfgLoaded;
}

=head2 CANoe_saveConfig_if_modified
   
  CANoe_saveConfig_if_modified ();

Determines whether the active configuration has been modified or not, if modified then saves the configuration.

This saving of Configuration is done to aviod popping of `Save prompt` whcih prevents to run or relaod another configurtion or another testlist.  

B<Examples:>

    CANoe_saveConfig_if_modified();       

=cut

sub CANoe_saveConfig_if_modified {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_saveConfig_if_modified ()', @args );

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    my $loaded_cfg_fullName = CANoe_read_configuration($ole_handle);

    Write_Log_Text( " check if congfiguation '$loaded_cfg_fullName' has been modified or not on $hostname .. ", WRLOG_LEVEL_4 );

    # STEP Check if active configuration has been modifed or not, if modified then save the configuration
    my $configuration_modified_status = GetCOM_objProperty( $ole_handle, [ 'Application', 'Configuration' ], 'Modified' );

    Write_Log_Text( " modified status of '$loaded_cfg_fullName' = '$configuration_modified_status' (1 = cfg modifed, 0 =cfg unmodified)", WRLOG_LEVEL_4 );
    if ($configuration_modified_status) {

        Write_Log_Text( " Modified congfiguation '$loaded_cfg_fullName' has been saved .. ", WRLOG_LEVEL_4 );
        CallCOM_Method( $ole_handle, [ 'Application', 'Configuration' ], 'Save' );
        S_wait_ms(200);
    }

    return 1;
}

=head2 CANoe_configure_rd_wr_tr

    CANoe_configure_rd_wr_tr ($ole_handle_mix);

It checks if B<currently loaded configuration> file is same as that of the B<default configuration>.

default configuration is B<Online_Config> from TestBench L</"Devices section:"> under 'CANoe'.

If it is same then it does nothing & returns with true value.
But if it is not same then it stops the measurement if already running and then loads the B<default configuration>.
    
=cut

sub CANoe_configure_rd_wr_tr {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_configure_rd_wr_tr ($ole_handle_mix)', @args );
    my $ole_handle = shift @args;

    my $device = Get_deviceType($ole_handle) || return;

    # STEP Check if active and default configuration is same ?
    my $default_configuration = $CANoe_dev_control_href->{$ole_handle}{'cfg'}{'DefaultOnlineConfig'};
    return 1 if ( CANoeCfg_alreadyLoaded( $ole_handle, $default_configuration ) );

    # STEP If active & default is not same then stop measurement before loading the default configuration
    Write_Log_Text(" active configuration is not equal to the default = '$default_configuration'. Will try to load the default config again.. ");
    if ( CANoe_check_running($ole_handle) ) {
        CANoe_stop_measurement();
    }

    # STEP Load the CANoe configuration
    unless ( CANoe_open_configuration( $ole_handle, $default_configuration, 1 ) ) {
        Write_Error_Text( "Could not open $device configuration '$default_configuration'", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    return 1;
}

=head1 Measurement

=head2 CANoe_start_measurement
    
    $status = CANoe_start_measurement();

Starts the CANoe measurement.

B<Note :>

- After calling start measurement command it checks if really measurement has started or not for sucessive waitTime of 100, 200, 500, 1500, 5000 ms.

- If measurement was already started then it does nothing and it just returns.

=cut

sub CANoe_start_measurement {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_start_measurement ()', @args );

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP check if CANoe is configured for rd, wr & tr
    unless ( CANoe_configure_rd_wr_tr($ole_handle) ) {
        Write_Error_Text( "Could not configure devices for CANoe Start measurement ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP CANoe measurement is already running - do nothing
    if ( CANoe_check_running($ole_handle) ) {
        Write_Log_Text( " measurement has been started already ( $device on $hostname )\n", WRLOG_LEVEL_3 );
        return 1;
    }

    Write_Log_Text(" start $device Measurement on $hostname");
    return 1 if $main::opt_offline;

    Write_Log_Text( " OLE_handle -> Measurement -> Start() ..", WRLOG_LEVEL_5 );

    # STEP start the CANoe measurement
    CallCOM_Method( $ole_handle, ['Measurement'], 'Start' );
    if ( my $err = S_get_LastError_OLE() ) {
        S_wait_ms(1000);
        Write_Log_Text( " trying 2nd time : OLE_handle -> Measurement -> Start() ..", WRLOG_LEVEL_5 );

        CallCOM_Method( $ole_handle, ['Measurement'], 'Start' );
        if ( $err = S_get_LastError_OLE() ) {
            Write_Error_Text( "Couldnt start '$device' measurement on $hostname ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
    }

    # STEP verify if canoe measurement has really started ?
    # STEP check running status of CANoe after successive steps of 100, 200, 500, 1500, 5000
    return 1 if CANoe_check_running($ole_handle);
    foreach ( ( 100, 200, 500, 1500, 5000 ) ) {
        S_wait_ms($_, "Checking if CANoe measurement is running...");
        return 1 if CANoe_check_running($ole_handle);
        Write_Log_Text( " measurement is still not running ?!?! ", WRLOG_LEVEL_4 );
    }
    Write_Error_Text( "Couldnt start '$device' measurement on $hostname ", ERR_VECTOR_CANOE_CONFIGURATION );
    return;
}

=head2 CANoe_stop_measurement
    
    $status = CANoe_stop_measurement();

Stops the CANoe measurement.

B<Note :>

- After calling stop measurement command it checks if really measurement has stopped or not for sucessive waitTime of 100, 200, 500, 1500, 5000 ms.

- If measurement was already stopted then it does nothing and it just returns.

=cut

sub CANoe_stop_measurement {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_stop_measurement ()', @args );

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    Write_Log_Text( " Stop $device Measurement on $hostname .. ", WRLOG_LEVEL_3 );

    # STEP CANoe measurement is already stopped ?
    if ( CANoe_check_running($ole_handle) == 0 ) {
        Write_Log_Text(" measurement has been stopped already ( $device on $hostname )\n");
        return 1;
    }

    return 1 if ($main::opt_offline);

    Write_Log_Text( " OLE_handle -> Measurement -> Stop() .. ", WRLOG_LEVEL_5 );

    #
    # STEP OLE call to stop the measurement
    #
    CallCOM_Method( $ole_handle, ['Measurement'], 'Stop' );

    Write_Log_Text( " is done .. ", WRLOG_LEVEL_3 );

    if ( my $err = S_get_LastError_OLE() ) {
        S_wait_ms(1000);
        Write_Log_Text( " trying 2nd time : OLE_handle -> Measurement -> Stop() .. ", WRLOG_LEVEL_5 );
        CallCOM_Method( $ole_handle, ['Measurement'], 'Stop' );
        if ( $err = S_get_LastError_OLE() ) {
            Write_Error_Text( "Couldnt stop '$device' CAN measurement on '$hostname'. ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
    }

    # CALL CANoe_saveConfig_if_modified save ative configuration if modified
    CANoe_saveConfig_if_modified();

    # STEP verify if canoe measurement has really stopped ?
    # STEP check running status of CANoe after successive steps of 100, 200, 500, 1500, 5000
    return 1 unless CANoe_check_running($ole_handle);

    foreach ( ( 100, 200, 500, 1500, 5000, 10000, 10000, 20000 ) ) {
        S_wait_ms($_, "checking if CANoe measurement has stopped...");
        return 1 unless CANoe_check_running($ole_handle);
        Write_Log_Text( " measurement is still running ?!?! ", WRLOG_LEVEL_4 );
    }
    Write_Error_Text( "Couldnt stop '$device' CAN measurement on '$hostname' after several tries. ", ERR_VECTOR_CANOE_CONFIGURATION );
    return;
}

=head2 CANoe_measurement_running_status
   
  $canoe_meas_running_status = CANoe_measurement_running_status ();

Determines whether the measurement has been started or not.

If the measurement is running, B<1 is returned; otherwise 0 > is returned.

B<Examples:>

    CANoe_measurement_running_status();       

=cut

sub CANoe_measurement_running_status {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_measurement_running_status ()', @args );
    my $ole_handle = Get_oleHandle() || return;
    my $canoe_meas_running_status = CANoe_check_running($ole_handle);
    return $canoe_meas_running_status;
}

=head2 CANoe_check_running
    
   $canoe_meas_running_status = CANoe_check_running($ole_handle)

Determines whether the measurement has been started or not.

If the measurement is running, B<1 is returned; otherwise 0 > is returned.

=cut

sub CANoe_check_running {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_check_running ($ole_handle_mix)', @args );
    my $ole_handle = shift @args;

    return 1 if $main::opt_offline;

    my $device   = Get_deviceType($ole_handle) || return;
    my $hostname = Get_hostName($ole_handle)   || return;

    Write_Log_Text( " OLE_handle -> Measurement -> Running() ..", WRLOG_LEVEL_5 );
    my $status = CallCOM_Method( $ole_handle, ['Measurement'], 'Running' );
    if ( my $err = S_get_LastError_OLE() ) {
        S_wait_ms(1000);
        Write_Log_Text( " trying 2nd time : OLE_handle -> Measurement -> Running()) ..", WRLOG_LEVEL_5 );
        $status = CallCOM_Method( $ole_handle, ['Measurement'], 'Running' );
        if ( $err = S_get_LastError_OLE() ) {
            Write_Error_Text( "Couldnt check '$device' CANoe measurement running on $hostname ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
    }

    if ( my $err = S_get_LastError_OLE() ) { Write_Error_Text( "OLE exception : '$err' (after OLE_handle -> Measurement -> Running())", ERR_VECTOR_CANOE_CONFIGURATION ); return; }

    my $canoe_meas_running_status;
    if ($status) {
        Write_Log_Text( " '$device' on '$hostname' is running", WRLOG_LEVEL_4 );
        $canoe_meas_running_status = 1;
    }
    else {
        Write_Log_Text( " '$device' on $hostname is NOT running", WRLOG_LEVEL_4 );
        $canoe_meas_running_status = 0;

    }
    return $canoe_meas_running_status;
}

=head1 Trace 

=head2 CANoe_trace_store

    $trStore_filepath = CANoe_trace_store ( [$trStore_filepath] );

Store the CANoe trace Logfile under path $trStore_filepath.
If no $trStore_filepath given then it will be stored under test report folder.

return value is the $trStore_filepath

=cut

sub CANoe_trace_store {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_store ([$trStore_filepath])', @args );
    my $trStore_filepath = shift @args;

    Write_Log_Text('start ..');

    # STEP args : - optional ($trStore_filepath)
    # STEP if trace store path is not given - then log will be stored under report folder.
    $trStore_filepath = $main::REPORT_PATH . '/' . S_get_TC_number() . '_LIFT_canoe_trace_' . S_get_date_extension() . ".asc" if not defined $trStore_filepath;
    Write_Log_Text("trace file path to store is : '$trStore_filepath'");

    # STEP create dummy log file in case of offline condition.
    if ($main::opt_offline) {
        S_create_dummy_file($trStore_filepath);
        return $trStore_filepath;
    }

    # CALL LogTrace_based_on_LoggingFileConfig
    $trStore_filepath = LogTrace_based_on_LoggingFileConfig($trStore_filepath);
    Write_Log_Text('end ..');

    # STEP return $trStore_filepath
    return $trStore_filepath;
}

=head2 CANoe_trace_delete

    $retval = CANoe_trace_delete();

Deletes the CANoe trace file configured in testbench for CANoe.

Trace file is taken from the TestBench L</"Devices section:"> under 'CANoe' -> 'Log_File'.

B<Returns,>

1 - On success

0 - On Failure

B<Example:>

    CANoe_trace_delete();
    CANoe_start_measurement();
        
This deletes the trace file generated during the previous measurement start

In the above case, it deletes the trace file : B<C:\temp\CANOE_log.asc>.

=cut

sub CANoe_trace_delete {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CANoe_trace_delete()', @args );

    #Get the CANoe tracefile from Testbench
    my $testbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );
    my $canoe_logfile = $testbench->{'Devices'}{'CANoe'}{'Log_File'};

    if ( -f $canoe_logfile ) {
        if ( unlink $canoe_logfile ) {
            Write_Log_Text("Successfully deleted the CANoe trace file '$canoe_logfile' before the Measurement Start ");
        }
        else {
            S_set_warning(" CANoe_trace_delete: Failed to delete the trace file '$canoe_logfile'");
        }
    }
    else {
        Write_Log_Text(" CANoe trace file '$canoe_logfile' is Not present ");
    }

    return 1;
}

=head2 LogTrace_based_on_LoggingFileConfig

    $return_trStore_fpath = LogTrace_based_on_LoggingFileConfig ( $trStore_filepath );
    
It logs the CANoe trace based on the setting's done in the CANoe for B<"Logging File Configuration">.

- called internally by function L</"CANoe_trace_store">. 

B<Note> :

Check : what user has Selected for the logging file ?
Measurement setup -> Logging Block > Logging File Configuration > B<FieldCodes> 

-> if option B<"With each Trigger"> is :

- selected : RBS will not be stopped to take the log file (log file name will be incremented with each trigger).

- unselected : stop the RBS & take the log file.
 
B<Return value > : 

- Successful => B<$return_trStore_fpath , Offline => B<dummy_Log.asc> , Error => B<undef>

=cut

sub LogTrace_based_on_LoggingFileConfig {
    my @args = @_;
    return unless S_checkFunctionArguments( 'LogTrace_based_on_LoggingFileConfig ($trStore_filepath)', @args );
    my $trStore_fpath = shift @args;

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;

    Write_Log_Text('start ..');

    # STEP Get the DefaultLogFile from Test Bench ..
    my $trTstBnch_fpath = $CANoe_dev_control_href->{$ole_handle}{'LogFileConfig'}{'DefaultLogFile'};
    my $return_trStore_fpath;

    # IF Log file config - 'Increment with trigger' ?
    if ( $CANoe_dev_control_href->{$ole_handle}{'LogFileConfig'}{'IncrementAfterTrigger'} == 1 ) {

        # IF-YES-START
        # STEP stop logging ..
        my $sysVarName = 'LIFT_CAN_access::SysVar_logging_control';    # used system variable
        CANoe_set_sysVar_value( $sysVarName, 0 ) || return;

        # CALL GetTrace_without_stop_measurement
        # IF-YES-END
        $return_trStore_fpath = GetTrace_without_stop_measurement( $ole_handle, $trTstBnch_fpath, $trStore_fpath );

    }
    else {
        # IF-NO-START
        # CALL GetTrace_with_stop_measurement
        # IF-NO-END
        $return_trStore_fpath = GetTrace_with_stop_measurement( $ole_handle, $trTstBnch_fpath, $trStore_fpath );
    }

    Write_Log_Text("end. Returned store file = '$return_trStore_fpath'");

    # STEP return $return_trStore_fpath
    return $return_trStore_fpath;
}

=head2 GetTrace_with_stop_measurement

    $trStore_fpth_dstn = GetTrace_with_stop_measurement ($ole_handle_mix, $trTstbnch_fpath_src, $trStore_fpth_dstn);

Log file configured in testBench "$trTstbnch_fpath_src" will be copied to location "$trStore_fpth_dstn".

B<Note :>

- It stops the RBS / measurement before taking the trace log file.
- called internally by function L</"LogTrace_based_on_LoggingFileConfig">.   

B<Return Value:>  

- Successful => B<$store_file_name> , Offline => B<dummy_Log.asc> , Failure => B<undef>

=cut

sub GetTrace_with_stop_measurement {

    my @args = @_;
    return unless S_checkFunctionArguments( 'GetTrace_with_stop_measurement ($ole_handle_mix, $trTstbnch_fpath_src, $trStore_fpth_dstn)', @args );
    my $ole_handle          = shift @args;
    my $trTstbnch_fpath_src = shift @args;
    my $trStore_fpth_dstn   = shift @args;

    # STEP args - $ole_handle, - $trTstbnch_fpath_src, - $trStore_fpth_dstn
    Write_Log_Text("Stop CANoe measurement before getting the trace file '$trStore_fpth_dstn'");

    # STEP STOP measuremnt if already running
    my $measRunning_status = CANoe_check_running($ole_handle);
    CANoe_stop_measurement() if ( $measRunning_status == 1 );
    Write_Log_Text("Copy '$trTstbnch_fpath_src' -> $trStore_fpth_dstn ");

    # STEP validate the file length of $trTstbnch_fpath_src and $trStore_fpth_dstn
    # CALL CheckTraceFilePathLength
    CheckTraceFilePathLength($trTstbnch_fpath_src) and CheckTraceFilePathLength($trStore_fpth_dstn);

    return $trTstbnch_fpath_src if $main::opt_offline;

    # STEP copy file from '$trTstbnch_fpath_src to $trStore_fpth_dstn'
    unless ( copy( $trTstbnch_fpath_src, $trStore_fpth_dstn ) ) {
        Write_Error_Text( "copy ( '$trTstbnch_fpath_src', '$trStore_fpth_dstn' ) : $!", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP again the measuremnt if already running
    CANoe_start_measurement() if ( $measRunning_status == 1 );

    # STEP retrun $trStore_fpth_dstn
    return $trStore_fpth_dstn;
}

=head2 GetTrace_without_stop_measurement

    $trStore_fpth_dstn = GetTrace_without_stop_measurement ($ole_handle_mix, $trTstbnch_fpath_src, $trStore_fpth_dstn);

Log file configured in testBench "$trTstbnch_fpath_src" will be copied to location "$trStore_fpth_dstn".

B<Note :>

- It doesnot stops the RBS / measurement before taking the trace log file. 
- Log file name will be incremented with Each trigger.
- called internally by function L</"LogTrace_based_on_LoggingFileConfig">.   

B<Return Value:>  

- Successful => B<$trStore_fpth_dstn , Offline => B<dummy_Log.asc> , Failure => B<undef>

=cut

sub GetTrace_without_stop_measurement {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetTrace_without_stop_measurement ($ole_handle_mix, $trTstbnch_fpath_src, $trStore_fpth_dstn)', @args );
    my $ole_handle          = shift @args;
    my $trTstbnch_fpath_src = shift @args;
    my $trStore_fpth_dstn   = shift @args;

    # STEP args - $ole_handle, - $trTstbnch_fpath_src, - $trStore_fpth_dstn
    my $matched_flag;
    my $incremented_LogFile_CANoe;

    # CALL CANoe_get_configured_logfile_names
    # STEP validate trace file (should be same as given in the Testbench) and get the incremented trace file from CANoe
    my @logFileNames = CANoe_get_configured_logfile_names($ole_handle);
    @logFileNames = ($trTstbnch_fpath_src) if $main::opt_offline;
    $matched_flag = 0;
    foreach (@logFileNames) {
        $incremented_LogFile_CANoe = $_;    # use it later to store this file
        my $logFileName = basename($_);
        $logFileName =~ s/_T\d+\.asc$/.asc/i if $CANoe_dev_control_href->{$ole_handle}{'LogFileConfig'}{'IncrementAfterTrigger'} == 1;
        if ( $logFileName eq basename($trTstbnch_fpath_src) ) {
            $matched_flag = 1;              # same log file as from CANoe and Testbench
        }
    }

    unless ($matched_flag) {
        my $log_files_text = join( " ", @logFileNames );
        Write_Error_Text( "Could not find Testbench Log_File '$trTstbnch_fpath_src' in configured Log_Files ( '$log_files_text' ). ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP check the file length of incremented trace file & $trStore_fpth_dstn
    CheckTraceFilePathLength($incremented_LogFile_CANoe) and CheckTraceFilePathLength($trStore_fpth_dstn);

    return $trTstbnch_fpath_src if $main::opt_offline;

    # STEP copy file from '$incremented_LogFile_CANoe to $trStore_fpth_dstn'
    Write_Log_Text("Copy '$incremented_LogFile_CANoe' -> $trStore_fpth_dstn");
    unless ( copy( $incremented_LogFile_CANoe, $trStore_fpth_dstn ) ) {
        Write_Error_Text( "copy ( '$incremented_LogFile_CANoe' , '$trStore_fpth_dstn' ) : $! ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP return $trStore_fpth_dstn
    return $trStore_fpth_dstn;
}

=head2 CANoe_get_configured_logfile_names
    
    @returned_LogFileNames = CANoe_get_configured_logfile_names ($ole_handle);

Returns an array of the configured trace files from the Measurement setup configured under Logging Block.

Example if there are two logging blocks 'B<Logging 1> => c:\temp\CANoe_trace_1.asc' and 'B<Logging 2> => c:\temp\CANoe_trace_2.asc'

then @returned_LogFileNames = B<(c:\temp\CANoe_trace_1.asc ,  c:\temp\CANoe_trace_2.asc)>

Called internally via L</"CANoe_Init"> => L</"Check_configured_trace_file">

=cut

sub CANoe_get_configured_logfile_names {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_configured_logfile_names ($ole_handle_mix)', @args );
    my $ole_handle = shift @args;

    return 1 if $main::opt_offline;

    my @returned_LogFileNames;
    my ( $logging_object, $fileNameOptions_object );

    Write_Log_Text( " nbr_of_looging_objects = OLE_handle -> Configuration -> OnlineSetup -> LoggingCollection -> Count() ", WRLOG_LEVEL_5 );
    my $nbr_looging_objects = $ole_handle->Configuration->OnlineSetup->LoggingCollection->Count();
    S_get_LastError_OLE();
    Write_Log_Text( " nbr of logging objects = $nbr_looging_objects ", WRLOG_LEVEL_5 );

    # STEP Look all the logging blocks configured in measurement setup
    for ( 1 .. $nbr_looging_objects ) {

        Write_Log_Text( " Logging_handle = OLE_handle -> Configuration -> OnlineSetup -> LoggingCollection -> Item($_) .. ", WRLOG_LEVEL_5 );
        $logging_object = $ole_handle->Configuration->OnlineSetup->LoggingCollection->Item($_);
        S_get_LastError_OLE();
        $logging_object = $ole_handle->Configuration->OnlineSetup->LoggingCollection($_);
        S_get_LastError_OLE();

        # STEP Fetch the trace log file from the logging block & store it
        push( @returned_LogFileNames, $logging_object->{'FullName'} );
        Write_Log_Text( " -> " . $logging_object->{'FullName'} );

        $fileNameOptions_object = $logging_object->FileNameOptions;

        # STEP check the IncrementAfterTrigger option
        $CANoe_dev_control_href->{$ole_handle}{'LogFileConfig'}{'IncrementAfterTrigger'} = $fileNameOptions_object->IncrementAfterTrigger;
        Write_Log_Text( " for '" . $logging_object->{'FullName'} . "' -  IncrementAfterTrigger option is '" . $fileNameOptions_object->IncrementAfterTrigger . "'", WRLOG_LEVEL_3 );

    }

    # STEP return all the trace log files
    return @returned_LogFileNames;
}

=head2 Check_configured_trace_file
    
    $matched_flag = Check_configured_trace_file ($logFile_testBench, $online_config);
    
Checks if the mentioned trace file 'B<Log_File>' from TestBench L</"Devices section:"> under 'CANoe' matches with the trace file as configured in CANoe measurement setup
under Logging block. If it matches then B<$matched_flag = 1 else 0>. 

Called internally via L</"CANoe_Init">.
    
=cut

sub Check_configured_trace_file {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Check_configured_trace_file ($logFile_testBench, $online_config)', @args );
    my $logFile_testBench = shift @args;
    my $online_config     = shift @args;    # for documentation only

    my $ole_handle   = Get_oleHandle();
    my @logFileNames = CANoe_get_configured_logfile_names($ole_handle);
    @logFileNames = ($logFile_testBench) if $main::opt_offline;

    my $matched_flag = 0;
    foreach (@logFileNames) {
        my $logfile = basename($_);

        # STEP remove numbers from CANoe log file if IncrementAfterTrigger is true
        $logfile =~ s/_T\d+\.asc$/.asc/i if $CANoe_dev_control_href->{$ole_handle}{'LogFileConfig'}{'IncrementAfterTrigger'} == 1;

        if ( basename($logFile_testBench) =~ /$logfile/i ) {
            Write_Log_Text( "'CANoe' Configuration has Log File - '$_' configured\n", WRLOG_LEVEL_3 );
            $CANoe_dev_control_href->{$ole_handle}{'LogFileConfig'}{'DefaultLogFile'} = $logFile_testBench;
            $matched_flag = 1;
        }
    }

    unless ($matched_flag) {
        my $log_files_text = join( " ", @logFileNames );
        Write_Error_Text( "Could not find Testbench Log_File '$logFile_testBench' in configured Log_Files ( $log_files_text ) of 'CANoe' configuration '$online_config' \n", ERR_VECTOR_CANOE_CONFIGURATION );
    }
    return $matched_flag;
}

=head2 CANoe_trace_logging_start

    CANoe_trace_logging_start();

Start logging of the trace file. CAPL code must be included in RBS as defined in the tutorial <>.    

=cut

sub CANoe_trace_logging_start {
    CANoe_set_sysVar_value( 'LIFT_CAN_access::SysVar_logging_control', 1 );
    return 1;
}

=head2 CANoe_trace_logging_stop

    CANoe_trace_logging_stop ();

Stop logging of the trace file. CAPL code must be included in RBS as defined in the tutorial <>.   
    
=cut

sub CANoe_trace_logging_stop {
    CANoe_set_sysVar_value( 'LIFT_CAN_access::SysVar_logging_control', 0 );
    return 1;
}

=head2 CheckTraceFilePathLength

    CheckTraceFilePathLength ( $trFilepath ) ;

Perform the trace file length check. If it is greater than 255 characters then it throws warning.

=cut

sub CheckTraceFilePathLength {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CheckTraceFilePathLength ($trFilepath)', @args );

    my $trFilepath    = shift @args;
    my $trfpathlength = length($trFilepath);

    Write_Log_Text("file length of '$trFilepath' = $trfpathlength");
    if ( $trfpathlength > 255 ) {
        Write_Error_Text( "file length of '$trFilepath' = $trfpathlength > 255. Remark - it will an error if > 259.", 0 );
        return;
    }

    return 1;
}

=head2 CANoe_trace_get_message_dataref

 $message_data_href = CANoe_trace_get_message_dataref ( $trace_file_path, $msg_PDU_info_href, $data_format,$message_data_href);

B<Arguments:>

=over

=item $trace_file_path

-CANoe trace file path

=item $msg_PDU_info_href

-Message related information returned from LIFT_NET_access::GetMsgPDUInfo

=item $data_format

-Format of data present in trace file. Can be HEX or DEC.

=item $message_data_href

-Reference of message data to be stored

=back

B<Return Values:>

=over

=item $message_data_href

-Returns the updated hash with message information updated

=back

B<Examples:>

 $message_data_href = CANoe_trace_get_message_dataref ('C:\temp\CANOE_trace.asc',$msg_PDU_info_href,$data_format,$message_data_href);
 
B<Notes:> 
Returns the message dataref for the CANoe trace file.

Ex:
   $message_data_href  =    {
                                 '0.001376' => {
                                           'ISO_Airbag_01_Resp' => {
                                                              'DLC' => '8',
                                                              'DATA' => '00 00 00 00 00 00 00 00  '
                                                             }
                                              },
                                 '0.002376' => {
                                           'ISO_Airbag_01_Resp' => {
                                                              'DLC' => '8',
                                                              'DATA' => '00 10 00 00 00 01 00 00  '
                                                             }
                                              },
                            };

Internally calls -> L</CANoe_trace_find_message> -> L</CANoe_trace_can_get_message_data>
 
=cut

sub CANoe_trace_get_message_dataref {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_get_message_dataref ( $trace_file_path, $msg_PDU_info_href, $data_format, $message_data_href)', @args );

    #STEP Read trace_file_path,msg_PDU_info_href
    my $trace_file_path   = shift;
    my $msg_PDU_info      = shift;
    my $data_format       = shift;
    my $message_data_href = shift;

    #STEP Fetch the message name and Bus type from msg info
    my $message  = $msg_PDU_info->{'PDU_MESSAGE'};
    my $bus_type = $msg_PDU_info->{'BUS_TYPE'};

    Write_Log_Text("start..");
    Write_Log_Text("GET DATAREF for message -> '$message'");

    my ( $found_messages, $found_PDU );

    #STEP For each Bus type(LIN|CAN|CANFD|FLEXRAY) get the message data and Store in a hashref
    # CALL CANoe_trace_find_message
    if ( $bus_type =~ /^CAN/i || $bus_type =~ /^LIN/i ) {
        $found_messages = CANoe_trace_find_message( $trace_file_path, $msg_PDU_info, $data_format );
        foreach my $time_stamp ( sort { $a <=> $b } keys %$found_messages ) {
            my $dlc  = $found_messages->{$time_stamp}{'DLC'};
            my $data = $found_messages->{$time_stamp}{'DATA'};
            $message_data_href->{$time_stamp}{$message}{'DLC'}  = $dlc;
            $message_data_href->{$time_stamp}{$message}{'DATA'} = $data;
        }
    }
    elsif ( $bus_type =~ /^FLEXRAY$/i ) {
        $found_PDU = CANoe_trace_find_message( $trace_file_path, $msg_PDU_info, $data_format );
        foreach my $time_stamp ( keys %$found_PDU ) {
            my $pdu_data  = $found_PDU->{$time_stamp}{'DATA'};
            my $pdu_dlc_1 = $found_PDU->{$time_stamp}{'DLC_1'};
            my $pdu_dlc_2 = $found_PDU->{$time_stamp}{'DLC_2'};
            $message_data_href->{$time_stamp}{$message}{'DATA'}  = $pdu_data;
            $message_data_href->{$time_stamp}{$message}{'DLC_1'} = $pdu_dlc_1;
            $message_data_href->{$time_stamp}{$message}{'DLC_2'} = $pdu_dlc_2;
        }
    }

    Write_Log_Text("end..\n");

    #STEP Return the message dataref
    return $message_data_href;
}

=head2 CANoe_trace_find_message

    $found_messages = CANoe_trace_find_message ( $trace_file_path, $msg_PDU_info_href, $data_format);

B<Arguments:>

=over

=item $trace_file_path

-CANoe trace file path

=item $msg_PDU_info_href

-Message related information returned from LIFT_NET_access::GetMsgPDUInfo

=item $data_format

-Format of data present in trace file. Can be HEX or DEC.

=back

B<Return Values:>

=over

=item $found_messages

-Holds the message data in CANoe trace over time

=back

B<Examples:>

 $found_messages = CANoe_trace_find_message ('C:\\temp\\CANOE_trace.asc', $msg_PDU_info_href, $data_format );

B<Notes:> 

Called internally by L</CANoe_trace_get_message_dataref> and L</CANoe_trace_signal_dataref>.
 
=cut

sub CANoe_trace_find_message {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_find_message ( $trace_file_path, $msg_PDU_info_href, $data_format)', @args );

    #STEP Read trace_file_path and msg_PDU_info_href
    my $trace_file_path = shift;
    my $msg_PDU_info    = shift;
    my $data_format     = shift;

    #STEP Fetch the message name and Bus type from msg info
    my $message  = $msg_PDU_info->{'PDU_MESSAGE'};
    my $bus_type = $msg_PDU_info->{'BUS_TYPE'};

    my $msg_pdu_canoe_name;
    if ( $message =~ /^(CAN|CANFD|LIN|FLEXRAY)\d+::(.*)$/i ) {
        $msg_pdu_canoe_name = $2;
    }
    else {
        $msg_pdu_canoe_name = $message;
    }

    my $bus_nbr;
    $bus_nbr = $msg_PDU_info->{$message}{'BUS_NBR'};

    #STEP Fetch the message data from trace file using message name
    my $found_messages;
    if ( lc $bus_type eq 'can' ) {

        # CALL CANoe_trace_can_get_message_data to get CAN data if bus type is CAN
        $found_messages = CANoe_trace_can_get_message_data( $trace_file_path, $msg_pdu_canoe_name, $bus_nbr );

        #STEP If not found using Message Name find it using ID
        unless ($found_messages) {
            my $id_dec = $msg_PDU_info->{$message}{'ID'};
            my $id = GetIDfromDecID( $id_dec, $data_format, $bus_type );
            $found_messages = CANoe_trace_can_get_message_data( $trace_file_path, $id, $bus_nbr );
        }
    }
    elsif ( lc $bus_type eq 'canfd' ) {

        my $id_dec = $msg_PDU_info->{$message}{'ID'};
        my $id = GetIDfromDecID( $id_dec, $data_format, $bus_type );

        # CALL CANoe_trace_canfd_get_message_data to get CAN data if bus type is CANFD
        $found_messages = CANoe_trace_canfd_get_message_data( $trace_file_path, { CANFD_MSG_NAME => $msg_pdu_canoe_name, CANFD_ID => $id, CANFD_CHNL_NBR => $bus_nbr } );
    }
    elsif ( lc $bus_type eq 'lin' ) {

        # CALL CANoe_trace_lin_get_message_data to get CAN data if bus type is LIN
        $found_messages = CANoe_trace_lin_get_message_data( $trace_file_path, $msg_pdu_canoe_name );

        #STEP If not found using Message Name find it using ID
        unless ($found_messages) {
            my $id_dec = $msg_PDU_info->{$message}{'ID'};
            my $id = GetIDfromDecID( $id_dec, $data_format, $bus_type );
            $found_messages = CANoe_trace_lin_get_message_data( $trace_file_path, $id );
        }
    }
    elsif ( lc $bus_type eq 'flexray' ) {

        # CALL CANoe_trace_fr_get_PDU_data to get CAN data if bus type is FLEXRAY
        $found_messages = CANoe_trace_fr_get_PDU_data( $trace_file_path, $msg_PDU_info );
    }

    #STEP Return the found messages
    return $found_messages;
}

=head2 CANoe_trace_get_signal_dataref

    $signal_data_href = CANoe_trace_get_signal_dataref ( $trace_file_path, $signal_info_href, $signal, $data_format, $signal_data_href);

B<Arguments:>

=over

=item $trace_file_path

-CANoe trace file path

=item $signal_info_href

-Signal related information returned from LIFT_NET_access::GetSignalInfo

=item $signal

-Signal to be searched in CANoe trace 

=item $data_format

-Format of data present in trace file. Can be HEX or DEC.

=item $signal_data_href

-Signal data to be returned

=back

B<Return Values:>

=over

=item $signal_data_href

-Signal data to be returned

=back

B<Examples:>

 $signal_data_href = CANoe_trace_get_signal_dataref ( $trace_file_path, $signal_info_href, $signal, $data_format, $signal_data_href);
 
 Ex: $signal_data_href = {
                '0.001376' => {
                        'ISO_Airbag_01_Resp_Data' => 0,
                        'ISO_Airbag_01_Resp'      => {
                                'DLC'  => '8',
                                'DATA' => '00 00 00 00 00 00 00 00  '
                        }
                },
                '0.002456' => {
                        'ISO_Airbag_02_Resp_Data' => 0,
                        'ISO_Airbag_02_Resp'      => {
                                'DLC'  => '8',
                                'DATA' => '00 00 21 00 00 32 00 00  '
                        }
                }
    };

B<Notes:> 

=cut

sub CANoe_trace_get_signal_dataref {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_get_signal_dataref ( $trace_file_path, $signal_info_href, $signal_name, $data_format, $signal_data_href)', @args );
    my $trace_file_path  = shift @args;
    my $signal_info      = shift @args;
    my $signal_name      = shift @args;
    my $data_format      = shift @args;
    my $signal_data_href = shift @args;

    # COMMENT-START
    # in- args :
    # - $trace_file_path
    # - $signal_info_href
    # - $signal_name
    # - $data_format
    # out- args:
    # - $signal_data_href -> with value and time stamps
    # COMMENT-END

    my $found_messages;

    # STEP Extract msgData (timestamps, data ) for $signal_name from $trace_file_path
    my $bus_type = $signal_info->{'BUS_TYPE'};
    my $message  = $signal_info->{'PDU_MESSAGE'};

    Write_Log_Text("start..");
    Write_Log_Text("GET DATAREF for signal -> '$signal_name'");

    # CALL CANoe_trace_find_message
    $found_messages = CANoe_trace_find_message( $trace_file_path, $signal_info, $data_format );

    if ( $bus_type =~ /^CAN|CANFD$/ || $bus_type =~ /^LIN$/ ) {
        foreach my $time_stamp ( sort { $a <=> $b } keys %$found_messages ) {
            my $dlc  = $found_messages->{$time_stamp}{'DLC'};
            my $data = $found_messages->{$time_stamp}{'DATA'};
            $signal_data_href->{$time_stamp}{$message}{'DLC'}  = $dlc;
            $signal_data_href->{$time_stamp}{$message}{'DATA'} = $data;
        }
    }
    elsif ( $bus_type =~ /^FLEXRAY$/ ) {
        foreach my $time_stamp ( sort { $a <=> $b } keys %$found_messages ) {
            my $pdu_data  = $found_messages->{$time_stamp}{'DATA'};
            my $pdu_dlc_1 = $found_messages->{$time_stamp}{'DLC_1'};
            my $pdu_dlc_2 = $found_messages->{$time_stamp}{'DLC_2'};
            $signal_data_href->{$time_stamp}{$message}{'DATA'}  = $pdu_data;
            $signal_data_href->{$time_stamp}{$message}{'DLC_1'} = $pdu_dlc_1;
            $signal_data_href->{$time_stamp}{$message}{'DLC_2'} = $pdu_dlc_2;
        }
    }

    #STEP Get the signal data from trace for respective bus ( LIN|CAN|FLEXRAY )
    # CALL CANoe_trace_get_signal_data
    my $signal_data_ref = CANoe_trace_get_signal_data( $found_messages, $signal_name, $data_format, $signal_info );
    foreach my $time_stamp ( sort { $a <=> $b } keys %$signal_data_ref ) {
        my $signal_Data_local = $$signal_data_ref{$time_stamp};
        $signal_data_href->{$time_stamp}{$signal_name} = $signal_Data_local;
    }

    Write_Log_Text("end..\n");

    #STEP Return the Signal dataref
    return $signal_data_href;
}

=head2 CANoe_trace_get_sysvar_dataref

    $sysvar_data_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, $sysvar, $sysvar_data_href );

B<Arguments:>

=over

=item $trace_file_path

-CANoe trace file path

=item $sysvar

- CANoe SYSTEM variable to be searched in trace 

=item $sysvar_data_href

-Updated data referance with the System variable related information

=back


B<Return Values:>

=over

=item $sysvar_data_href

-Updated data referance with the System variable related information

=back

B<Examples:>

 $sysvar_data_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, $sysvar, $sysvar_data_href );

=cut

sub CANoe_trace_get_sysvar_dataref {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_get_sysvar_dataref ( $trace_file_path, $sysvar, $sysvar_data_href )', @args );

    #STEP Read the trace_file_path and SysVar
    my $trace_file_path  = shift;
    my $sysvar           = shift;
    my $sysvar_data_href = shift;

    #STEP Get the SysVar data from trace file
    my $sysvar_data_ref = CANoe_trace_sysVar_get_data( $trace_file_path, $sysvar );

    #STEP Store the SysVar data
    foreach my $time_stamp ( sort { $a <=> $b } keys %$sysvar_data_ref ) {
        my $sysvar_Data_local = $$sysvar_data_ref{$time_stamp}{'DATA'};
        $sysvar_data_href->{$time_stamp}->{$sysvar} = $sysvar_Data_local;
    }

    #STEP Return the SysVar dataref
    return $sysvar_data_href;
}

sub GetIDfromDecID {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetIDfromDecID($id_dec,$data_format,$bus_type)', @args );

    my $id_dec      = shift;
    my $data_format = shift;
    my $bus_type    = shift;

    if ( $bus_type =~ /^CAN$/ && $id_dec > 0x1FFFFFFF ) {
        Write_Log_Text( "given ID $id_dec (dec) / 0x" . uc sprintf( "%x", $id_dec ) . " (hex) is greater the 29 bit ; sometime 100 is added to 29bit IDs (EXT identifier)\n" );
        $id_dec = $id_dec & 0x1FFFFFFF;    # mask with 29bit
        Write_Log_Text( "changed to $id_dec (dec) / 0x" . uc sprintf( "%x", $id_dec ) . " (hex) \n" );
    }
    elsif ( $bus_type =~ /^LIN$/ && $id_dec > 0xFF ) {
        Write_Log_Text( "given ID $id_dec (dec) / 0x" . uc sprintf( "%x", $id_dec ) . " (hex) is greater the 8 bit \n" );
        $id_dec = $id_dec & 0xFF;          # mask with 8bit
        Write_Log_Text( "changed to $id_dec (dec) / 0x" . uc sprintf( "%x", $id_dec ) . " (hex) \n" );
    }

    my $id_hex = uc sprintf( "%x", $id_dec );
    my $id;
    $id = $id_dec if $data_format =~ /dec/i;
    $id = $id_hex if $data_format =~ /hex/i;
    return $id;
}

=head2 CANoe_trace_analyze_format

    ($data_format, $timestamps)  = CANoe_trace_analyze_format($canoe_trace_file);

B<Arguments:>

=over

=item $can_trace_file

-CANoe trace file path

=back

B<Return Values:>

=over

=item $data_format

-Format of data present in trace file. Can be HEX or DEC.

=item $timestamps

-Indicates the type of timestamp. Can be either 'relative' or 'absolute'

=back


B<Examples:>

 CANoe_trace_analyze_format('C:\temp\CANOE_trace.asc'); 

B<Notes:> 

=cut

sub CANoe_trace_analyze_format {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_analyze_format($can_trace_file)', @args );
    my $can_trace_file = shift @args;

    my $data_format;
    my $timestamps;

    # STEP if Offline = dataformat is hex and timestamp is absolute
    if ($main::opt_offline) {
        $data_format = 'hex';
        $timestamps  = 'absolute';
    }
    else {
        # STEP if Online - Get dataformat and time stamp from the trace file
        my $trace_FH = GetFileHandle($can_trace_file) || return;
        while (<$trace_FH>) {
            if (/base\s+(\S+)\s+timestamps\s+(\S+)/) { $data_format = $1; $timestamps = $2; last; }
        }
        $trace_FH->close;
    }
    Write_Log_Text("base = $data_format timestamps = $timestamps");

    return ( $data_format, $timestamps );

}

######################################################################

=head2 CANoe_trace_can_get_message_data

    $message_ref = CANoe_trace_can_get_message_data ( $can_log_file , $can_message , $can_bus_nbr );

Reads a single CAN message from a Canalyzer logfile. 

B<Input arguments:>

$can_log_file : is the full name of the logfile.

$can_message : is symbolic name or decimal or hexadecimal value of the CAN frame in the logfile.

$can_bus_nbr : is the CAN bus number to which CAN Message belongs to.

B<Return Value(s):>

Returns reference to hash structure:

      $message_ref->{$timestamp}{'DLC'} = DLC;
      $message_ref->{$timestamp}{'DATA'} = raw bytes of message;

=cut

sub CANoe_trace_can_get_message_data {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_can_get_message_data($can_log_file,$can_message,$can_bus_nbr)', @args );

    my $can_log_file = shift;
    my $can_message  = shift;
    my $can_bus_nbr  = shift;

    my ( $msg_cnt, $all_msgs, $time_stamp, $dlc, $data, $other );

    #STEP verify can channel name
    unless ( defined $can_bus_nbr ) {
        $can_bus_nbr = 1;
    }

    $msg_cnt = 0;
    Write_Log_Text("Reading CAN frame '$can_message' on Bus-Nbr $can_bus_nbr from $can_log_file)");

    #STEP Parse the CANoe trace & fetch CAN data for input 'CAN' message
    my $trace_FH = GetFileHandle($can_log_file) || return;

    while (<$trace_FH>) {
        ## try to match:
        ##      0.0171 1  Bremse_1   Rx   d 8 00 18 00 00 FE FE 00 18
        if (
            /^
          \s*        # leading spaces
          (\d+\.\d+)    # timestamp
          \s+        # spaces
          $can_bus_nbr     # bus ID must be right !!!
          \s+        # spaces
          $can_message
          x?
          \s+        # spaces
          [TxRq]+      # match Rx or Tx or TxRq
          \s+        # spaces
          d
          \s+        # spaces
          (\d+)      # DLC
          \s+        # spaces
          (.+)$      # all Data and aditional info unil end of line  (e.g. 2A 34 42 FF 20 00  Length = 192000 BitCount = 100)
          /ix
          )
        {
            $msg_cnt++;
            $time_stamp = $1;
            $dlc        = $2;
            $data       = $3;

            $data =~ s/(([\da-fA-F]{2}\s*){$dlc})(.*)/$1/;    # extract sequence of bytes (number given by DLC)

            if ($3) { $other = $3 }
            else    { undef $other }

            $all_msgs->{$time_stamp}{'DLC'}   = $dlc;
            $all_msgs->{$time_stamp}{'DATA'}  = $data;
            $all_msgs->{$time_stamp}{'OTHER'} = $other if defined $other;
        }
    }
    $trace_FH->close;
    Write_Log_Text("Found $can_message -> $msg_cnt times");

    # STEP return the hash reference with found CAN data.
    return $all_msgs;
}

=head2 CANoe_trace_canfd_get_message_data

    $canfd_msg_href = CANoe_trace_canfd_get_message_data ( $canfd_log_file , $canfd_param_href );

Reads all CANFD frames defined by $canfd_param_href from a CANoe logfile ($canfd_log_file).

B<Arguments:>

=over

=item $canfd_log_file 

full name of the CANoe logfile.

=item $canfd_param_href 

Hash reference to define the CANFD frame to be fetched from log file.

    $canfd_param_href = {
        CANFD_MSG_NAME => <CANFD message name>, 
        CANFD_ID       => <CANFD ID (identifier)>,
        CANFD_CHNL_NBR => <CANFD channel number>,
    };
    
Either CANFD_MSG_NAME or CANFD_ID is required to identify the CANFD frame.
If both are given then both have to match.

If CANFD_CHNL_NBR is not given then 1 is used as default.

=back

B<Return Value:>

=over

=item $returnValue 

Reference to data hash structure:

    $message_ref->{$timestamp}{'DLC'} = <DLC>;
    $message_ref->{$timestamp}{'DATA'} = <string with raw bytes of message separated by whitespace>;

=back

B<Examples:>

    $msg_name = 'GGCC'
    $id = '100'
    $can_bus_nbr = '1'
    $returnValue = CANoe_trace_canfd_get_message_data($trace_file_path, {CANFD_MSG_NAME=> $msg_name, CANFD_ID=>$id, CANFD_CHNL_NBR=>$can_bus_nbr}); 

=cut

sub CANoe_trace_canfd_get_message_data {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_canfd_get_message_data ($canfd_log_file, $canfd_param_href)', @args );

    my $canfd_log_file   = shift @args;
    my $canfd_param_href = shift @args;

    #STEP verify CANFD message name and ID  & channel name
    my $canfd_message = $canfd_param_href->{CANFD_MSG_NAME};
    my $canfd_id      = $canfd_param_href->{CANFD_ID};

    if ( not defined $canfd_message and not defined $canfd_id ) {
        Write_Error_Text( " both \$canfd_param_href->{CANFD_MSG_NAME} and \$canfd_param_href->{CANFD_ID} not given. At least one of them has to be given.", 110 );
        return;
    }

    #set default value for regex
    unless ( defined($canfd_message) ) {
        $canfd_message = '\w+';
    }

    #set default value for regex
    unless ( defined($canfd_id) ) {
        $canfd_id = '\w+';
    }

    my $canfd_bus_nbr = $canfd_param_href->{CANFD_CHNL_NBR};
    $canfd_bus_nbr = 1 if not defined $canfd_bus_nbr;

    my $trace_FH = GetFileHandle($canfd_log_file) || return;
    my ( $msg_cnt, $all_msgs, $time_stamp, $dlc, $data, $other, $messageRead );

    $msg_cnt = 0;
    Write_Log_Text("Reading CANFD frame '$canfd_message' on Bus-Nbr $canfd_bus_nbr from $canfd_log_file)");

    #STEP Parse the CANoe trace & fetch CANFD data for input 'CANFD' message
    while (<$trace_FH>) {
        ## try to match:
        ##   6.249610 CANFD   1 Rx        650  ProDiag_Request                  0 0 8  8 03 00 a5 a8 ff ff ff ff   236015  122   200000     33e8 50052050 4b080250 201f0002 20010104
        ##   1.990428 CANFD   1 Rx        650                                   0 0 8  8 03 00 a5 a8 ff ff ff ff   236000  122   200000     33e8 50052050 4b080250 201f0002 20010104
        if (
            /^
           \s*            # leading spaces
           (\d+\.\d+)     # <TIME>     -> timestamp
           \s+            # spaces
           CANFD          # CANFD      -> Fixed name for CANFD
           \s+            # spaces
           $canfd_bus_nbr # <Channel>  -> bus ID -> CANFD channel
           \s+            # spaces
           [TxRq]+        # <DIR>  match Rx or Tx or TxRq
           \s+            # spaces
           $canfd_id      # <ID>   -> CAN FD ID 
           x?
           \s+?            # spaces, try to match one or more space , but less is better  
           (\s+|$canfd_message)  # <SymbolicName> -> CANFD message name (Optional)
           \s+            # spaces 
           \d+            #  <BRS>  -> not used
           \s+            #  spaces
           \d+            #  <ESI>  -> not used
           \s+            # spaces
           [a-fA-F0-9]+   #  <DLC>  -> ignore this
           \s+            # spaces
           (\d+)          #  <DataLength> data lenth count
           \s+            # spaces
           (.+)$          # all Data and aditional info unil end of line  (e.g. 02 00 00 00 00 00 00 00   246000  126   220040     5f51 50052050 4b080250 201f0002 20010104)
           /ix
          )
        {
            $msg_cnt++;
            $time_stamp  = $1;
            $messageRead = $2;
            $dlc         = $3;
            $data        = $4;

            $data =~ s/(([\da-fA-F]{2}\s*){$dlc})(.*)/$1/;    # extract sequence of bytes (number given by DLC)

            if ($3) { $other = $3 }
            else    { undef $other }

            $all_msgs->{$time_stamp}{'DLC'}   = $dlc;
            $all_msgs->{$time_stamp}{'DATA'}  = $data;
            $all_msgs->{$time_stamp}{'OTHER'} = $other if defined $other;
        }
    }
    $trace_FH->close;

    # STEP return the hash reference with found CANFD data.
    $messageRead = $canfd_id if ( not defined $messageRead or $messageRead =~ /^\s+$/ );
    Write_Log_Text("Found message '$messageRead' -> $msg_cnt times");

    return $all_msgs;
}

=head2 CANoe_trace_get_signal_data

    $signal_data_ref = CANoe_trace_get_signal_data($all_msgs_href, $can_signal, $data_format );

Extracts the data of CAN , LIN & FlexRay signal into a data hash_ref. Signal data is searched from all message dataref read by L</CANoe_trace_can_get_message_data> for CAN, 
L</CANoe_trace_lin_get_message_data> for LIN and L</CANoe_trace_fr_get_PDU_data> for FlexRay. 

B<Input arguments:>

$all_msgs_href : is the CAN message or FR PDU or LIN Frame dataref 

$bus_signal : is the name of CAN , LIN or FlexRay signal as in LIFT <CAN, LIN or FlexRay> Mapping

$data_format : is format of data in CAN trace : 'dec' or 'hex'

B<Return Value(s):>

Returns hash ref structure:

        $signal_data_ref = {
                              $timestamp1 => $phys_value1,
                              $timestamp2 => $phys_value2,
                           };
                        
        $found_messages = {
            timestamp1 => {
                'DATA' => '00 18 00 00 FE FE 00 18',
            },
            timestamp2 => {
                'DATA' => '00 18 00 00 FE FE 00 18',
            },
        };
                            
=cut

sub CANoe_trace_get_signal_data {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_get_signal_data ($all_msgs_href, $bus_signal, $data_format, $signalInfo_href)', @args );
    my $all_msgs        = shift @args;
    my $bus_signal      = shift @args;
    my $data_format     = shift @args;    ### DEC or HEX
    my $signalInfo_href = shift @args;

    my $busType = $signalInfo_href->{'BUS_TYPE'};
    Write_Log_Text(" Get the time stamps for signal '$bus_signal' from messages dataref for busType = '$busType'.");

    unless ( $data_format =~ /dec/i or $data_format =~ /hex/i ) {
        Write_Error_Text( "CANoe_trace_get_signal_data parameter 'base' must be 'dec' or 'hex'", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP validate the sigal data like OFFSET, FACTOR etc required later for fetching the signal
    # CALL Validate_signal_for_traceDataRef
    my ( $signal_length, $signal_factor, $signal_offset, $signal_format, $signal_start_bit, $signal_type, $signal_MX_Master, $signal_MX_Master_code_value, );
    my $bus_signal_href = Validate_signal_for_traceDataRef( $signalInfo_href, $bus_signal, $busType ) || return;
    $signal_length               = $bus_signal_href->{'LENGTH'};
    $signal_offset               = $bus_signal_href->{'OFFSET'};
    $signal_factor               = $bus_signal_href->{'FACTOR'};
    $signal_format               = $bus_signal_href->{'FORMAT'};
    $signal_start_bit            = $bus_signal_href->{'STARTBIT'};
    $signal_type                 = $bus_signal_href->{'TYPE'};
    $signal_MX_Master            = $bus_signal_href->{'MULTIPLEX'}{'MASTER'};
    $signal_MX_Master_code_value = $bus_signal_href->{'MULTIPLEX'}{'CODE'};

    # STEP check the $multiplex_type for signal $bus_signal (MASTER, SLAVE, NO_MULTIPLEX) ?
    my $multiplex_type;
    if ( defined $signal_MX_Master and not defined $signal_MX_Master_code_value ) {
        $multiplex_type = 'MASTER';
    }
    elsif ( defined $signal_MX_Master and defined $signal_MX_Master_code_value ) {
        $multiplex_type = 'SLAVE';
        Write_Log_Text(" MULTIPLEX SLAVE signal '$bus_signal' (MASTER='$signal_MX_Master' CODE='$signal_MX_Master_code_value')");
    }
    elsif ( not defined $signal_MX_Master and defined $signal_MX_Master_code_value ) {
        Write_Error_Text( " wrong signal config ('CODE' defined but not 'MASTER' defined)", ERR_INVALID_PARAMETERS );
        return;
    }
    else {
        $multiplex_type = 'NO_MULTIPLEX';
    }

    Write_Log_Text(" Multiplex_type type is '$multiplex_type' for signal '$bus_signal',  busType = '$busType'.");

    my $signal_MX_Master_href;

    # STEP if $multiplex_type is slave then fetch the attributes for multipled signal
    if ( $multiplex_type eq 'SLAVE' ) {
        $busType = uc($busType);
        my $bus_Mapping = S_get_contents_of_hash( [ 'Mapping_NET_Access_' . "$busType" ] );
        undef $signalInfo_href;
        $signalInfo_href->{$signal_MX_Master} = $bus_Mapping->{$signal_MX_Master};
        $signal_MX_Master_href = Validate_signal_for_traceDataRef( $signalInfo_href, $signal_MX_Master, $busType ) || return;
    }

    my (
        $data_raw,
        @data_list,
        $bus_frame_bin, $bus_frame_bin_display,
        $byte_value,    $byte_bin_lsb,
        $sig_value_phys,
        $sig_data_ref,

    );

    # STEP Loop all the messages and get the timestamps from the raw data
    foreach my $time_stamp ( sort { $a <=> $b } keys %$all_msgs ) {
        $data_raw = $all_msgs->{$time_stamp}{'DATA'};
        $data_raw =~ s/^\s+//g;    ## remove possible leading spaces
        ## convert string to list of data bytes ( $data_list[0] eq CAN Byte 0)
        @data_list             = split( /\s+/, $data_raw );
        $bus_frame_bin         = "";                          ## CAN frame binary format (LSB)
        $bus_frame_bin_display = "";                          ## CAN frame binary format (LSB)

        foreach my $data_byte (@data_list) {
            ## converts 'F0' into '00001111' (LSB format) (starting with lowest significant bit))
            ##   PERL lesson:
            ##                 - 'hex $data_byte' interprete given value as hexadecimal value
            ##                 - 'sprintf( "%08b",...' format the given value into 8bit format (MSB)
            ##                 - 'reverse' sort the given scalar in opposite order (that means: MSB to LSB)
            if    ( $data_format =~ /hex/i )        { $byte_value   = hex $data_byte; }
            elsif ( $data_format =~ /dec/i )        { $byte_value   = $data_byte; }
            if    ( $signal_format =~ /INTEL/i )    { $byte_bin_lsb = reverse sprintf( "%08b", $byte_value ); }
            elsif ( $signal_format =~ /MOTOROLA/i ) { $byte_bin_lsb = sprintf( "%08b", $byte_value ); }
            ## create the full CAN message by concatinating all bytes (binary LSB)
            $bus_frame_bin .= $byte_bin_lsb;
            $bus_frame_bin_display .= $byte_bin_lsb . ' ';
        }

        # section for MULTIPLEX master in case of SLAVE signal required
        if ( $multiplex_type eq 'SLAVE' ) {
            my $signal_MX_Master_value_phys = GetSignal_physValue_fromRawByte( $signal_MX_Master_href, $bus_frame_bin, $all_msgs->{$time_stamp}{'DLC'} );
            unless ( $signal_MX_Master_value_phys == $signal_MX_Master_code_value ) {
                next;
            }
        }

        # end of MULTIPLEX section
        $sig_value_phys = GetSignal_physValue_fromRawByte( $bus_signal_href, $bus_frame_bin, $all_msgs->{$time_stamp}{'DLC'} );
        $sig_data_ref->{$time_stamp} = $sig_value_phys;
    }

    unless ($sig_data_ref) {
        Write_Log_Text( " could not extract signal $bus_signal at startbit: $signal_start_bit, length: $signal_length format: $signal_format", WRLOG_LEVEL_3 );
    }

    Write_Log_Text("return the timestamps 'phy-value' of the signals that were extracted from log and filled into the \$sig_data_ref.");

    # STEP return $sig_data_ref
    return $sig_data_ref;
}

=head2 CANoe_trace_sysVar_get_data

    $all_sysVars_href = CANoe_trace_sysVar_get_data($can_log_file, $fullQualifiedSysVarName);

Get system variable time stamp and value from the trace file and return reference to hash structure.

B<Input arguments:>

$can_log_file : Refers to the full path of CANoe log file

$fullQualifiedSysVarName : Refers to the full path of the System variable

B<Return Value(s):>

   $allSysVar_ref->{$timestamp}{'DATA'} = <value of system variable>;
            
B<Example :>  

  CANoe_trace_sysVar_get_data($can_log_file, 'LIFT_CAN_access::SysVar_Type_Float' )

B<Remark :>
 
-> This function is common for all the bus types (CAN, LIN and FLEXRAY).

-> works only with system variabe of data type int or float    
       
=cut

sub CANoe_trace_sysVar_get_data {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_sysVar_get_data ($can_log_file, $fullQualifiedSysVarName)', @args );

    my $can_log_file            = shift @args;
    my $fullQualifiedSysVarName = shift @args;

    my ( $sysVar_cnt, $all_sysVars_href, $time_stamp, $data );
    $sysVar_cnt = 0;
    Write_Log_Text(" CANoe_trace_sysVar_get_data : read system variable '$fullQualifiedSysVarName' from $can_log_file)");

    my $trace_FH = GetFileHandle($can_log_file) || return;
    while ( my $line = <$trace_FH> ) {
        ## try to match:
        ##         0.038080    SV: 2 0 1 ::LIFT_CAN_access::SysVar_Type_Int = ff
        if (
            $line =~ m/^ 
            \s*        # leading spaces
            (\d+\.\d+) # timestamp          
            \s+        # some spaces
            SV:        # keyword for system variable    
            \s+        # some spaces
            (?:\d+\s+){3} # some digits followed by spaces
            [\:\:]+
            $fullQualifiedSysVarName    # full qualified system variable name
            \s+        # some spaces 
            =
            \s+
            ([a-fA-F0-9.]+)    # decimal or hex values
            /x
          )
        {
            $sysVar_cnt++;
            $time_stamp = $1;
            $data       = $2;

            $all_sysVars_href->{$time_stamp}{'DATA'} = $data;
        }
    }
    close($trace_FH);
    Write_Log_Text( "Found $fullQualifiedSysVarName -> $sysVar_cnt times\n", WRLOG_LEVEL_4 );
    return $all_sysVars_href;
}

sub GetSignal_physValue_fromRawByte {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetSignal_physValue_fromRawByte ($bus_signal_href, $bus_frame_bin , [$dlc])', @args );

    my $bus_signal_href = shift @args;
    my $bus_frame_bin   = shift @args;
    my $dlc             = shift @args;

    my $signal_length    = $bus_signal_href->{'LENGTH'};
    my $signal_offset    = $bus_signal_href->{'OFFSET'};
    my $signal_factor    = $bus_signal_href->{'FACTOR'};
    my $signal_format    = $bus_signal_href->{'FORMAT'};
    my $signal_start_bit = $bus_signal_href->{'STARTBIT'};
    my $signal_type      = $bus_signal_href->{'TYPE'};

    my ( $signal_lsb, $signal_msb, $temp_bus_frame_bin, $temp_sig_pos_start, $signal_msb_without_sign, $signal_msb_without_sign_compl );

    my ( $signal_raw_value, $sig_value_phys );

    if ( $signal_format =~ /INTEL/i ) {
        $signal_lsb = substr( $bus_frame_bin, $signal_start_bit, $signal_length );
    }
    elsif ( $signal_format =~ /MOTOROLA/i ) {
        $temp_bus_frame_bin = reverse $bus_frame_bin;

        #$dlc                = $all_msgs->{$time_stamp}{'DLC'};
        $dlc = 0 if not defined $dlc;    # to avoid undef in $temp_sig_pos_start calculation
        $temp_sig_pos_start = $dlc * 8 - ( ( $signal_start_bit >> 3 ) << 3 ) - ( 7 + ( ( $signal_start_bit >> 3 ) << 3 ) - $signal_start_bit );
        $signal_lsb = substr( $temp_bus_frame_bin, $temp_sig_pos_start - $signal_length, $signal_length );
    }
    $signal_msb = reverse $signal_lsb;
    if ( $signal_type eq 'SIGNED' and $signal_msb =~ /^1/ ) {
        $signal_msb_without_sign       = substr( $signal_msb, 1, length($signal_msb) - 1 );
        $signal_msb_without_sign_compl = ~$signal_msb_without_sign;                                                                # 2 - complement (change all bits)
        $signal_raw_value              = unpack( "N", pack( "B32", substr( "0" x 32 . $signal_msb_without_sign_compl, -32 ) ) );
        $signal_raw_value              = ( $signal_raw_value + 1 ) * -1;                                                           # add 1 due to calculation rule with signed values and multiply with -1

    }
    else {
        $signal_raw_value = unpack( "N", pack( "B32", substr( "0" x 32 . $signal_msb, -32 ) ) );
    }
    $sig_value_phys = ( $signal_raw_value * $signal_factor ) + $signal_offset;

    return $sig_value_phys;

}

######################################################################

=head2 CANoe_trace_lin_get_message_data

    $message_ref = CANoe_trace_lin_get_message_data ( $lin_log_file , $lin_message );

Reads a single LIN Message from a CANoe logfile. 

B<Input arguments:>

$lin_log_file - is the full path of the logfile.

$lin_message - is symbolic name or decimal or hexadecimal value of the LIN Message in the logfile.

B<Return Value(s):>

Returns reference to hash structure:

      $message_ref->{$timestamp}{'DLC'} = DLC;
      $message_ref->{$timestamp}{'DATA'} = raw bytes of message;

=cut

######################################################################

sub CANoe_trace_lin_get_message_data {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_lin_get_message_data ( $lin_log_file, $lin_message)', @args );

    my $lin_log_file = shift @args;
    my $lin_message  = shift @args;

    my ( $msg_cnt, $all_msgs );
    $msg_cnt = 0;

    Write_Log_Text("Reading LIN frame '$lin_message' from $lin_log_file)");

    # STEP Parse the CANoe trace file and get the lin message data with timestamp

    my $trace_FH = GetFileHandle($lin_log_file) || return;
    while (<$trace_FH>) {
        ## try to match:
        ##      3.688702 Li 31              Tx     8 00 00 e0 ff fe fe b3 ff  checksum = bb
        if (
            /^
          \s*        # leading spaces
          (\d+\.\d+)    # timestamp
          \s+        # spaces
           Li        # must be Li for lin
          \s+        # spaces
          $lin_message        
          \s+        # spaces
          [TxRq]+      # match Rx or Tx or TxRq
          \s+        # spaces                 
          (\d+)      # DLC
          ((\s+[\da-fA-F]{2})+)      # only Data bytes are considered
          /ix
          )
        {
            $msg_cnt++;
            $all_msgs->{$1}{'DLC'}  = $2;
            $all_msgs->{$1}{'DATA'} = $3;
        }
    }
    $trace_FH->close;

    # STEP return the hash reference with found LIN data.
    Write_Log_Text("Found $lin_message -> $msg_cnt times\n");

    return $all_msgs;
}

=head2 CANoe_trace_fr_get_PDU_data

    $message_ref = CANoe_trace_fr_get_PDU_data( $fr_log_file , $fr_PDU);

Reads a single Flexray PDU from a CANoe logfile. 

B<Input arguments:>

$fr_log_file: is the full path of the logfile.

$fr_PDU: refers to Flerxray PDU in the logfile.

B<Return Value(s):>

Returns reference to hash structure with information on Flexray PDU:

    $message_ref->{$timestamp}{'FR_PDU'} = FR_PDU;
    $message_ref->{$timestamp}{'HEADER_CRC'} = HEADER_CRC;
    $message_ref->{$timestamp}{'DLC_1'} = DLC_1;
    $message_ref->{$timestamp}{'DLC_2'} = DLC_2;
    $message_ref->{$timestamp}{'DATA'}  = raw bytes of message;
    
=cut

######################################################################

sub CANoe_trace_fr_get_PDU_data {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_trace_fr_get_PDU_data ( $fr_log_file, $msg_PDU_info_href)', @args );

    my $fr_log_file       = shift @args;
    my $msg_PDU_info_href = shift @args;

    my $pdu_full_name = $msg_PDU_info_href->{'PDU_MESSAGE'};
    my $fr_PDU        = GetPduName($pdu_full_name);

    my ( $msg_cnt, $all_msgs );
    my $fr_bus_nbr = 'Fr';    #Set bus number to 'Fr' by default
    $msg_cnt = 0;
    my $fr_ignore_uBit = 1;

    # STEP parse the CANoe trace file and get the FlexRay data with timestamp.
    Write_Log_Text("Reading FlexRay PDU '$fr_PDU' on Bus  '$fr_bus_nbr' from file '$fr_log_file') ");

    # STEP Get the autosar schema version.
    # IF AUTOSAR_SCHEMA_VERSION == AUTOSAR_4-3-0 ?
    my $frame_based_log = 0;
    $frame_based_log = 1 if ( $msg_PDU_info_href->{'AUTOSAR_SCHEMA_VERSION'} =~ /^AUTOSAR_4-3-0$/i );

    # IF-YES-START
    my $framePduInfo_href;
    if ($frame_based_log) {

        # CALL GetFrameInfoForFrameBasedLog
        $framePduInfo_href = GetFrameInfoForFrameBasedLog( $msg_PDU_info_href, $pdu_full_name );
    }

    # IF-YES-END
    # IF-NO-START
    # IF-NO-END

    # STEP Read asc trace log file
    my $trace_FH = GetFileHandle($fr_log_file) || return;

    # LOOP-START loop over all trace lines
    while ( my $line = <$trace_FH> ) {

        my $pdu_line = $line;

        # IF frame_based_log ?
        if ($frame_based_log) {

            # IF-YES-START
            my $checkUpdateBit = 0;
            $checkUpdateBit = 1 if ( defined $msg_PDU_info_href->{$pdu_full_name}{'UPDATE-INDICATION-BIT-POSITION'} );

            # CALL PreparePDULineUsingUpdateBit if update_bit is set
            if ($checkUpdateBit) {
                $pdu_line = PreparePDULineUsingUpdateBit( { line => $line, framePduInfo => $framePduInfo_href, pdu => $fr_PDU } );
            }
            else {
                #  CALL GetPDULineFromFrame if update_bit is NOT set
                $pdu_line = GetPDULineFromFrame( $line, $framePduInfo_href, $fr_PDU );
            }

            # IF-YES-END
            # IF-NO-START
            # IF-NO-END
        }

        # CALL GetPDUInfoFromLog
        my $pdu_info;
        $pdu_info = GetPDUInfoFromLog( $pdu_line, $fr_PDU, $fr_bus_nbr ) if $pdu_line;
        if ($pdu_info) {
            if ( $fr_ignore_uBit or ubit( $pdu_info->{'BIN'} ) ) {
                my $timestamp = $pdu_info->{'TIME'};
                $msg_cnt++;

                #Save info in the hash
                $all_msgs->{$timestamp}{'FR_PDU'}     = $fr_PDU;
                $all_msgs->{$timestamp}{'HEADER_CRC'} = $pdu_info->{'CRC'};
                $all_msgs->{$timestamp}{'DLC_1'}      = $pdu_info->{'DLC1'};
                $all_msgs->{$timestamp}{'DLC_2'}      = $pdu_info->{'DLC2'};
                $all_msgs->{$timestamp}{'DATA'}       = $pdu_info->{'DATA'};

                #Check of good build (DLC values vs DATA size)
                my $dlc_minus_1 = $all_msgs->{$timestamp}{'DLC_1'} - 1;
                unless ( ( $all_msgs->{$timestamp}{'DLC_1'} == $all_msgs->{$timestamp}{'DLC_2'} )
                    && ( $all_msgs->{$timestamp}{'DATA'} =~ m/^([0-9a-fA-F]{2}\s){$dlc_minus_1}[0-9a-f]{2}$/ix ) )
                {
                    Write_Log_Text("Mismatched between DLC and DATA lenght or between the 2 DLC values");
                    $all_msgs->{$timestamp}{'MALFORMED'} = 1;
                }
            }

        }
    }

    # LOOP-END last trace line ?

    # STEP return the hash reference with found FlexRay data.
    Write_Log_Text( "Found " . $fr_PDU . " -> " . $msg_cnt . " times\n" );

    return $all_msgs;
}

sub GetPDUInfoFromLog {
    my $pdu_line    = shift;
    my $pduToSearch = shift;
    my $fr_bus_nbr  = shift;

    my $pduInfoHref;

    ## try to match PDU based logfile:
    ##      timestamp    Bus    keyword   frame information?        Tx/Rx info     ????????????   Frame state      HEADER_CRC     PDU_name  DLC_1   DLC_2   DATA (DLC_1 bytes)    ????????????????????
    ##      0.038955     Fr     PDU       0 0 1 1 19 26             Rx             0 438002 5     20               3a6            FD_ESP    1       1       00                    b980d5  1  43125  32
    # 438002
    # 0100001110000000000010
    #       ^
    if (
        $pdu_line =~ /^
            \s*        
            (\d+\.\d+)                              # Timestamp
            \s+        
            (?:$fr_bus_nbr)                         # Bus ID
            \s+        
            (?:PDU)                                 # Keyword
            \s+        
            (\w+\s+\w+\s+\w+\s+\w+\s+\w+\s+\w+)     # what is it:timing info???
            \s+        
            (?:Tx|Rx|TxRq)                          # match Rx or Tx or TxRq
            \s+        
            (?:\d+)                                 # what is it:info???
            \s+
            ([0-9a-f]+)                             # contains at least the update bit information
            \s+
            (?:\d+)                                 # what is it:info???
            \s+        
            [0-9a-f]+                               # Frame state: not useful
            \s+        
            ([0-9a-f]+)                             # CRC header
            \s+        
            (?:$pduToSearch)                        # searched PDU
            \s+        
            ([0-9a-f]+)                             # DLC 1
            \s+        
            ([0-9a-f]+)                             # DLC 2
            \s+
            (([0-9a-f]{2}(\s))*[0-9a-f]{2}) # DATA
            \s+
            .+$       # all Data until end of line
          /ix
      )
    {
        $pduInfoHref->{'BIN'}  = $3;
        $pduInfoHref->{'TIME'} = $1;
        $pduInfoHref->{'CRC'}  = $4;
        $pduInfoHref->{'DLC1'} = hex($5);
        $pduInfoHref->{'DLC2'} = hex($6);
        $pduInfoHref->{'DATA'} = $7;
    }
    return $pduInfoHref;
}

sub GetPduIdShortHeader {
    my $pdu_id_short_header = shift;
    $pdu_id_short_header =~ s/0x//;
    $pdu_id_short_header = '0' . $pdu_id_short_header if ( length($pdu_id_short_header) % 2 == 1 );
    my $pdu_id = join( " ", ( $pdu_id_short_header =~ m/../g ) );
    return $pdu_id;
}

sub GetPduName {
    my $pdu_full_name = shift;
    my $pdu_name;
    if ( $pdu_full_name =~ /^(FLEXRAY)\d+::(.*)$/i ) {
        $pdu_name = $2;
    }
    else {
        $pdu_name = $pdu_full_name;
    }
    return $pdu_name;
}

=head2 GetFrameInfoForFrameBasedLog

    $framePduLookup_href = GetFrameInfoForFrameBasedLog ( $flexray_Mapping_href, $pduToSearch)
    
Returns the Frame information from the Flexray Mapping

B<Arguments:>

=over

=item $flexray_Mapping_href

-FlexRay mapping hash reference

=item $pduToSearch

-PDU to be searched in log

=back

B<Return Value:>

=over

=item $framePduLookup_href 

-Reference to the PDU data present in frame 

=back

Called internally by L</"CANoe_trace_fr_get_PDU_data">.

=cut

sub GetFrameInfoForFrameBasedLog {
    my $msg_PDU_info_href = shift;
    my $pduToSearch       = shift;

    # STEP for desired pdu fetch Frame info

    #COMMENT-START
    # Read & validate following inputs from FlexRay mapping:
    #  - PDU_ID_SHORT_HEADER
    #  - UPDATE-INDICATION-BIT-POSITION,
    #  - START-BIT-POSITION, DLC
    #COMMENT-END

    my $framePduLookup_href;
    my $pdu_frame    = $msg_PDU_info_href->{$pduToSearch}{'FRAME_NAME'};
    my $pduShortName = GetPduName($pduToSearch);

    my $pdu_id_short_header = $msg_PDU_info_href->{$pduToSearch}{'PDU_ID_SHORT_HEADER'};
    if ($pdu_id_short_header) {
        my $pdu_id = GetPduIdShortHeader( $msg_PDU_info_href->{$pduToSearch}{'PDU_ID_SHORT_HEADER'} );
        $framePduLookup_href->{$pdu_frame}{$pduShortName}{'ID'} = $pdu_id;
    }
    my $pdu_dlc_dec = $msg_PDU_info_href->{$pduToSearch}{'DLC'};
    $framePduLookup_href->{$pdu_frame}{$pduShortName}{'LENGTH'} = sprintf( "%02X", $pdu_dlc_dec );
    $framePduLookup_href->{$pdu_frame}{$pduShortName}{'LENGTH_DEC'} = $pdu_dlc_dec;

    # UPDATE-INDICATION-BIT-POSITION
    my $update_indication_bit_position = $msg_PDU_info_href->{$pduToSearch}{'UPDATE-INDICATION-BIT-POSITION'};
    $framePduLookup_href->{$pdu_frame}{$pduShortName}{'UPDATE-INDICATION-BIT-POSITION'} = $update_indication_bit_position;

    # START-BIT-POSITION
    my $start_bit_position = $msg_PDU_info_href->{$pduToSearch}{'START-BIT-POSITION'};
    $framePduLookup_href->{$pdu_frame}{$pduShortName}{'START-BIT-POSITION'} = $start_bit_position;

    # Frame and Pdu name
    $framePduLookup_href->{'FRAME_NAME'} = $pdu_frame;
    $framePduLookup_href->{'PDU_NAME'}   = $pduShortName;

    Write_Log_Text("From FlexRay mapping file : [FRAME_NAME = '$pdu_frame' , PDU_NAME = '$pduShortName',  PDU_ID_SHORT_HEADER = '$pdu_id_short_header', DLC = '$pdu_dlc_dec' in dec, UPDATE-INDICATION-BIT-POSITION = '$update_indication_bit_position', START-BIT-POSITION = '$start_bit_position'] ");

    # STEP return hash with all frame & pdu info
    return $framePduLookup_href;
}

=head2 PreparePDULineUsingUpdateBit

    $framePduLookup_href = PreparePDULineUsingUpdateBit ($params)
    
Function to get the PDU log exracted from the frame based log when PDU_ID is not present and update bit information is given

B<Arguments:>

=over

=item $params->{'line'}

-Line from log file(Frame based)

=item $params->{'framePduInfo'}

-Frame information from the Flexray Mapping. Returned from L</"GetFrameInfoForFrameBasedLog">.

=item $params->{'pdu'}

-PDU to be searched in Log

=back

B<Return Value:>

=over

=item $pdu_line 

-PDU line extracted from the frame based log

=back

Called internally by L</"CANoe_trace_fr_get_PDU_data">.

=cut

sub PreparePDULineUsingUpdateBit {
    my @args   = @_;
    my $params = shift @args;

    my $frameLine    = $params->{'line'};
    my $framePduInfo = $params->{'framePduInfo'};
    my $pduToSearch  = $params->{'pdu'};

    my $pdu_frame = $framePduInfo->{'FRAME_NAME'};
    my $pdu_line;
    my $updateBitSet = 0;

   # STEP parse the CANoe trace for desired Frame to search
   # STEP ex line: 1.113735 Fr RMSG  0 0 1 1 22 1c Rx 0 e 5  20  81 ORC_CHASSIS_COM_Frame1_ST3 40 40 00 03 f3 2b 00 00 06 1a 88 52 2f 00 00 90 49 28 bf ff 0d 00 00 00 00 ff ff ff ff 00 06 ff ff ff ff ff ff 00 06 ff ff ff ff ff ff 00 06 ff ff 06 17 5d e8 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
   # IF line with frame match found ?
    if (
        $frameLine =~ /^(
                \s*(?:\d+\.\d+)			#Timestamp
                \s+(?:Fr)
                \s+(?:RMSG)				#Keyword
                \s+(?:\w+\s+\w+\s+\w+\s+\w+\s+\w+\s+\w+)
                \s+(?:Tx|Rx|TxRq)		#match Rx or Tx or TxRq
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)		#contains at least the update bit information
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)		#Frame state
                \s+(?:[0-9a-f]+)		#CRC header
                \s+)(?:$pdu_frame)		#Framename
                \s+(?:[0-9a-f]+)		#DLC1
                \s+(?:[0-9a-f]+)		#DLC2
                (.*)/ix
      )
    {
        #Matches: 3702.756816 Fr RMSG  0 0 1 1 8 b Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40
        my $line_data_prefix = $1;

        #Remaining string will have PDU info
        # 00 03 37 80 01 08 c4 f8 f9 00 00 00 00 00 3c 00 01 0e 56 55 55 55 4d ff ff ff ff ff 00 00 00 00 06 00 80 da 7f ff 7f ff ff e0 7f 00 00 00 00 47 8d 07 0a 8b 8e f9 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
        my $remaining_string = $2;
        $line_data_prefix =~ s/RMSG/PDU/;

        $remaining_string =~ s/^\s//;

        my @bytesHexarr = split( /\s+/, $remaining_string );

        #get start bit and length of PDU
        my $startBit = $framePduInfo->{$pdu_frame}{$pduToSearch}{'START-BIT-POSITION'};
        my $length   = $framePduInfo->{$pdu_frame}{$pduToSearch}{'LENGTH_DEC'};

        #Check if Update bit is set
        my $updateBit = $framePduInfo->{$pdu_frame}{$pduToSearch}{'UPDATE-INDICATION-BIT-POSITION'};
        my $offset    = $updateBit % 8;

        #Find exactly which byte we need to convert to binary to verify update bit is set/not(for better performance)
        my $updatebitdata_byte = floor( $updateBit / 8 );

        #Fetch the specific byte where update bit shall be checked, in case 00 03, we need 03 => 0000 0011
        my $updatebitByte = hex( $bytesHexarr[$updatebitdata_byte] );

        # order starts from 7-0, So if update bit is 8 => bit to check is 0, 9 -> bit to check is 1
        # now prepare the mask by shifting bit to relevent position
        # if Update bit is 9, Mast should be 00000010
        # shift left by the $updateBit % 8
        my $one = 1;
        my $bitmask = $offset ? $one << $offset : $one;
        $updateBitSet = 1 if ( $updatebitByte & $bitmask );

        if ($updateBitSet) {
            my $finalPDUdata = [];
            if ( $startBit % 8 == 0 ) {

                #Start bit is multiple of 8
                my $startByte = $startBit / 8;    #starts from 0-7, if bit is 8 => byte to start is 1 , 16 -> byte to start is 3
                push @$finalPDUdata, splice( @bytesHexarr, $startByte, $length );
            }
            else {

                #When Start bit is not multiple of 8(This takes little more time than when start bit is not multiple of 8)
                #convert each byte to binary
                my @bytesBinarr = map { sprintf( "%08b", hex($_) ) } @bytesHexarr;

                #create an array of each bits from each binary byte
                my $bitBinarr;
                map { push( @$bitBinarr, split( //, $_ ) ) } @bytesBinarr;

                #fetch each byte(8bit) from bitarray from the start bit
                foreach ( 1 .. $length ) {
                    my $pduByte = join( '', splice( @$bitBinarr, $startBit, 8 ) );

                    #Convert fetched byte to hex value
                    my $hexData = sprintf( "%02x", oct( "0b" . $pduByte ) );
                    push( @$finalPDUdata, $hexData );
                }
            }

            #now prepare the PDU log
            my $pduLengthHex = $framePduInfo->{$pdu_frame}{$pduToSearch}{'LENGTH'};
            $pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex " . join( ' ', @$finalPDUdata ) . "  0  0  0";
        }
        else {
            return;
        }
    }
    return $pdu_line;

}

=head2 GetPDULineFromFrame

    $pdu_line = GetPDULineFromFrame ( $frameLine, $framePduInfo_href, $pduToSearch)
    
Function to get the PDU log exracted from the frame based log

B<Arguments:>

=over

=item $frameLine

-Line from log file(Frame based)

=item $framePduInfo_href

-Frame information from the Flexray Mapping. Returned from L</"GetFrameInfoForFrameBasedLog">.

=item $pduToSearch

-PDU to be searched in Log

=back

B<Return Value:>

=over

=item $pdu_line 

-PDU line extracted from the frame based log

=back

Called internally by L</"VEC_trace_fr_get_PDU_data">.

=cut

sub GetPDULineFromFrame {
    my $frameLine    = shift;
    my $framePduInfo = shift;
    my $pduToSearch  = shift;

    my $pdu_frame = $framePduInfo->{'FRAME_NAME'};
    my $pdu_line;

  # STEP ex line: 3702.756816 Fr RMSG  0 0 1 1 8 b Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40 37 80 01 08 c4 f8 f9 00 00 00 00 00 3c 00 01 0e 56 55 55 55 4d ff ff ff ff ff 00 00 00 00 06 00 80 da 7f ff 7f ff ff e0 7f 00 00 00 00 47 8d 07 0a 8b 8e f9 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
    if (
        $frameLine =~ /^(
                \s*(?:\d+\.\d+)
                \s+(?:Fr)
                \s+(?:RMSG)
                \s+(?:\w+\s+\w+\s+\w+\s+\w+\s+\w+\s+\w+)
                \s+(?:Tx|Rx|TxRq)
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)
                \s+(?:[0-9a-f]+)
                \s+)(?:$pdu_frame)
                \s+(?:[0-9a-f]+)
                \s+(?:[0-9a-f]+)
                (.*)/ix
      )
    {
        # STEP Matches: 3702.756816 Fr RMSG  0 0 1 1 8 b Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40
        my $line_data_prefix = $1;

        # STEP Remaining string will have PDU info
        # 37 80 01 08 c4 f8 f9 00 00 00 00 00 3c 00 01 0e 56 55 55 55 4d ff ff ff ff ff 00 00 00 00 06 00 80 da 7f ff 7f ff ff e0 7f 00 00 00 00 47 8d 07 0a 8b 8e f9 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
        my $remaining_string = $2;
        $line_data_prefix =~ s/RMSG/PDU/;

        my $pduIdToSearch = $framePduInfo->{$pdu_frame}{$pduToSearch}{'ID'};
        my $pduLengthHex  = $framePduInfo->{$pdu_frame}{$pduToSearch}{'LENGTH'};
        my $pduLengthDec  = hex($pduLengthHex);

        if ( $pdu_frame eq $pduToSearch ) {

            # The frame is the PDU: Go ahead with returning the whole frame
            $remaining_string =~ /\s*((..\s){$pduLengthDec})(.*)?/i;
            $pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex $1" . "0  0  0   0\n";
            return $pdu_line;
        }

        #STEP Match with the ID and length : 37 80 01 08 -> Check if how many times this pattern is present ( 37 80 01-ID, 08-Length)
        my $matchedCount = my @match = $remaining_string =~ /\s*$pduIdToSearch\s$pduLengthHex\s/gi;
        return unless $matchedCount;    #return if there is no match found

        # IF $matchedCount == 1
        if ( $matchedCount == 1 ) {

            # IF-YES-START
            # STEP Matched only once -> Go ahead with returning the value
            # STEP Match: 37 80 01 08 c4 f8 f9 00 00 00 00 00
            $remaining_string =~ /\s*$pduIdToSearch\s$pduLengthHex\s((..\s){$pduLengthDec})(.*)?/i;
            $pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex $1" . "0  0  0   0\n";
            return $pdu_line;

            # IF-YES-END

        }
        else {
            # IF-NO-START
            # STEP Mached more than once -> Find out the proper position of PDU and get info
            my $i       = 0;
            my @pdu_arr = keys %{ $framePduInfo->{$pdu_frame} };
            for ( $i = 0 ; $i < ( scalar @pdu_arr ) ; $i++ ) {
                my $pdu_name      = $pdu_arr[$i];
                my $pdu_info_hash = $framePduInfo->{$pdu_frame}{$pdu_name};
                my $pdu_id        = $pdu_info_hash->{'ID'};
                my $length_hex    = $pdu_info_hash->{'LENGTH'};
                my $length_dec    = hex($length_hex);

                #STEP Get other PDU's present in the FRAME and try to match the remaining string to start with any of these PDUs
                if ( $remaining_string =~ /^\s*$pdu_id\s$length_hex\s((..\s){$length_dec})(.*)?/i ) {
                    $remaining_string = $3;
                    my $data = $1;
                    if ( $pdu_name =~ /^$pduToSearch$/ ) {
                        $pdu_line = $line_data_prefix . "$pduToSearch $length_hex $length_hex $data" . "0  0  0   0\n";
                        last;
                    }
                    @pdu_arr = grep { $_ !~ /^$pdu_name$/ } @pdu_arr;
                    $i = -1;
                }

                #STEP If there is no PDU match Search the PDU pattern in remaining string
                if ( $i == $#pdu_arr ) {

                    # STEP try to find out if the PDU can be found anywhere in the line
                    if ( $remaining_string =~ /\s*$pduIdToSearch\s$pduLengthHex\s((..\s){$pduLengthDec})(.*)?/i ) {
                        $pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex $1" . "0  0  0   0\n";
                        last;
                    }
                }
            }

            # IF-NO-END

        }
    }

    # STEP return the $pdu_line
    return $pdu_line;
}

sub Ubit {
    my $testedInfoBin = sprintf( "%024b", hex(shift) );

    return ( $testedInfoBin =~ m/[01]{6}1[01]{17}/i );
}

=head2 Validate_signal_for_traceDataRef

=cut

sub Validate_signal_for_traceDataRef {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Validate_signal_for_traceDataRef ($signalInfo_href, $signal_name, $bus_type )', @args );

    # STEP inputs : -$signalInfo_href , -$signal_name , -$bus_type
    my $signalInfo_href = shift @args;
    my $signal_name     = shift @args;
    my $bus_type        = shift @args;

    my $validated_signal_href;

    # validate some more attributes.
    $validated_signal_href->{'LENGTH'} = Validate_Signal_Attribute( $signalInfo_href, $signal_name, 'LENGTH', $bus_type );
    $validated_signal_href->{'OFFSET'} = Validate_Signal_Attribute( $signalInfo_href, $signal_name, 'OFFSET', $bus_type );
    $validated_signal_href->{'FACTOR'} = Validate_Signal_Attribute( $signalInfo_href, $signal_name, 'FACTOR', $bus_type );
    $validated_signal_href->{'FORMAT'} = Validate_Signal_Attribute( $signalInfo_href, $signal_name, 'FORMAT', $bus_type );
    unless ( $validated_signal_href->{'FORMAT'} =~ /INTEL/i or $validated_signal_href->{'FORMAT'} =~ /MOTOROLA/i ) {
        Write_Error_Text( "'FORMAT' of signal '$signal_name' in $bus_type Mapping must be INTEL or MOTOROLA", ERR_INVALID_PARAMETERS );
        return;
    }
    $validated_signal_href->{'STARTBIT'} = Validate_Signal_Attribute( $signalInfo_href, $signal_name, 'STARTBIT', $bus_type );
    $validated_signal_href->{'TYPE'}     = Validate_Signal_Attribute( $signalInfo_href, $signal_name, 'TYPE',     $bus_type );
    unless ( $validated_signal_href->{'TYPE'} =~ /^SIGNED/i or $validated_signal_href->{'TYPE'} =~ /^UNSIGNED/i ) {
        Write_Error_Text( "'TYPE' of signal '$signal_name' in $bus_type Mapping must be SIGNED or UNSIGNED", ERR_INVALID_PARAMETERS );
        return;
    }

    $validated_signal_href->{'MULTIPLEX'}{'MASTER'} = $signalInfo_href->{$signal_name}{'MULTIPLEX'}{'MASTER'};
    $validated_signal_href->{'MULTIPLEX'}{'CODE'}   = $signalInfo_href->{$signal_name}{'MULTIPLEX'}{'CODE'};

    # STEP return validated $validated_signal_href
    return $validated_signal_href;
}

=head2 Validate_Signal_Attribute

=cut

sub Validate_Signal_Attribute {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Validate_Signal_Attribute ($signal_href, $signal_name, $attribute , $bus , [, $noError ])', @args );

    my $signal_href = shift @args;
    my $signal_name = shift @args;
    my $attribute   = shift @args;
    my $bus         = shift @args;
    my $noError     = shift @args;

    my $validated_attribute;

    # STEP check if passed '$attribute' in Mapping_$bus ?
    unless ( exists $signal_href->{$signal_name}{$attribute} ) {
        if ( defined $noError ) {
            S_set_warning( " no '$attribute' exists for '$signal_name' in Mapping_$bus \n", 0 );
        }
        else {
            S_set_error( " no '$attribute' exists for '$signal_name' in Mapping_$bus \n", 20 );
        }
    }

    # STEP return the $validated_attribute
    $validated_attribute = $signal_href->{$signal_name}{$attribute};
    return $validated_attribute;
}

=head1 Signal

=head2 CANoe_read_signal

    ( $read_value, $unit ) = CANoe_read_signal ($signalInfo_href, [$mode]);
    
Reads the signal value from CANoe signal object for the $mode (phys or raw). Default  $mode is phys if not given. 

Signal can be either from B<CAN , LIN , FlexRay> bus.

Raw value from the CANoe signal object was read first via L</"CANoe_rd_bus_signal_direct_raw">. 

In case of B<$mode = 'raw'>, read raw value from CANoe was returned (with no conversion) and 
in case of B<$mode = 'phys'>, conversion from raw to phys was done as per offset & factor defined in the Mappings file (CAN, LIN or FlexRay) and then phys value was returned.      
    
=cut

sub CANoe_read_signal {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_read_signal ($signalInfo_href , [$mode])', @args );
    my $signalInfo_href = shift @args;
    my $mode            = shift @args;

    # COMMENT-START
    # args:
    #  - $bus_signal_href (busType, busNbr, Message or PDU, signal_name, unit)
    #  - $mode
    # COMMENT-END

    Write_Log_Text('start ..');

    # already verified
    my $busType    = $signalInfo_href->{'BUS_TYPE'};
    my $busNbr     = $signalInfo_href->{'BUS_NBR'};
    my $msgPdu     = $signalInfo_href->{'PDU_MESSAGE'};
    my $signalName = $signalInfo_href->{'SIGNAL_NAME'};
    my $factor     = $signalInfo_href->{'FACTOR'};
    my $offset     = $signalInfo_href->{'OFFSET'};
    my $cycleTime  = $signalInfo_href->{'CYCLE'};
    my $unit       = $signalInfo_href->{'UNIT'};

    my $parameters = "Bus = '$busType', busNbr = '$busNbr',  msg = '$msgPdu',  signalName = $signalName',  factor = '$factor', offset = '$offset', cycle time = '$cycleTime', unit = $unit";
    Write_Log_Text(" args : [ $parameters , mode = $mode ]");

    # CALL Check_mode
    $mode = Check_mode($mode) || return;

    # STEP offline mode return ( 1, 'dummy_offline' )
    return ( 1, 'dummy_offline' ) if $main::opt_offline;

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP check if CANoe is configured for rd, wr & tr
    unless ( CANoe_configure_rd_wr_tr($ole_handle) ) {
        Write_Error_Text( "Could not configure devices for reading signals", ERR_VECTOR_CANOE_CONFIGURATION );
        return ( undef, undef );
    }

    # STEP check if CANoe measurement is running
    unless ( CANoe_check_running($ole_handle) ) {
        CANoe_start_measurement() || return;
    }

    my $signal_href;
    $signal_href->{'BUS_TYPE'}    = $busType;
    $signal_href->{'BUS_NBR'}     = $busNbr;
    $signal_href->{'PDU_MESSAGE'} = $msgPdu;
    $signal_href->{'SIGNAL_NAME'} = $signalName;

    # CALL CANoe_rd_bus_signal_direct_raw
    my $raw_value = CANoe_rd_bus_signal_direct_raw( $ole_handle, $signal_href );
    if ( $raw_value !~ /\d/ ) {
        Write_Log_Text(" read signal not successful -> wait 1 cycle time $cycleTime ms and read again");
        S_wait_ms($cycleTime);
        $raw_value = CANoe_rd_bus_signal_direct_raw( $ole_handle, $signal_href );
    }

    my ( $read_value, $return_unit );

    # IF $mode ?
    my $phys_value;
    if ( $mode =~ /raw/i and defined $raw_value ) {

        # IF-RAW-START
        # STEP read value is already raw just print corresponding hex value
        # IF-RAW-END
        $read_value = sprintf( "0x%X", $raw_value );
        $return_unit = undef;
    }
    elsif ( $mode =~ /phys/i and defined $raw_value ) {

        # IF-PHYS-START
        # CALL Calc_phys_from_raw
        # IF-PHYS-END
        $read_value = Calc_phys_from_raw( $signalInfo_href, $raw_value );
        $return_unit = $unit;
    }
    else {
        Write_Error_Text( "Error in reading '$signalName' on bus '$busType' for $msgPdu when mode is $mode.", ERR_VECTOR_CANOE_CONFIGURATION );
        $read_value  = undef;
        $return_unit = undef;
    }

    Write_Log_Text("end .. ");

    # STEP Return (signalRead_value, $unit)
    return ( $read_value, $return_unit );
}

=head2 CANoe_rd_bus_signal_direct_raw

    $raw_value = CANoe_rd_bus_signal_direct_raw ($ole_handle, $bus_signal_href);
    
It gets the raw value of the passed signal through signal object. Signal attributes like (BusNbr, BusType, MsgName, SignalName) was passed by $bus_signal_href.

Called internally by L</"CANoe_read_signal">.     
    
=cut

sub CANoe_rd_bus_signal_direct_raw {

    # COMMENT-START
    # args :
    # - $ole_handle,
    # - $bus_signal_href (busType, BusNbr, Message or PDU, signal_name)
    # COMMENT-END

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_rd_bus_signal_direct_raw ($ole_handle_mix, $bus_signal_href)', @args );
    my $ole_handle      = shift @args;
    my $bus_signal_href = shift @args;

    # STEP print signal (bus type, busNbr, msg, signal)
    my $busType    = $bus_signal_href->{'BUS_TYPE'};
    my $busNbr     = $bus_signal_href->{'BUS_NBR'};
    my $msg        = $bus_signal_href->{'PDU_MESSAGE'};
    my $signalName = $bus_signal_href->{'SIGNAL_NAME'};

    # full qualified signal name = Channel, database name (alias), node, message and signal
    my $fullQualifiedSignalName = "$busType" . "_" . "$busNbr :: $msg :: $signalName";
    Write_Log_Text(" start reading  -  '$fullQualifiedSignalName' ");

    # CALL CANoe_get_bus_signal_object
    my $signal_object;
    unless ( $signal_object = CANoe_get_bus_signal_object( $ole_handle, $bus_signal_href ) ) {
        Write_Error_Text( "Could not fetch signal object for $fullQualifiedSignalName ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP fetch the raw value from Signal object.
    my $raw_value = GetObjProperty( $signal_object, 'RawValue' );

    my $hex_value;
    unless ( defined $raw_value ) {
        Write_Error_Text( "Error in getting signal value from signal object for '$fullQualifiedSignalName' ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    $hex_value = sprintf( "%x", $raw_value );
    Write_Log_Text(" read value for '$fullQualifiedSignalName' = 0x$hex_value (= $raw_value ) (raw)");

    # STEP return the raw value
    return ($raw_value);
}

=head2 CANoe_write_signal

    $status = CANoe_write_signal ($signalInfo_href , $busSignalValue, [$mode]);
    
Writes the $busSignalValue value to the signal object for the $mode (phys or raw). Default  $mode is phys if not given. 

Signal can be either from B<CAN , LIN , FlexRay> bus.

In case of B<$mode = 'raw'>, directly $busSignalValue will be written to the bus signal object (no conversion was done) 
in case of B<$mode = 'phys'>, first phys values from raw was calculated as per offset & factor defined in the Mappings file (CAN, LIN or FlexRay) and then raw value shall be written to the signal object.

Raw value to the CANoe signal object was written via L</"CANoe_wr_bus_signal_direct_raw">.

If the Interaction Layer is used for RBS ( ILUsed = 'Yes' in testbench ), Signal data will be directly written using the signal object.
If the Interaction Layer is NOT used for RBS ( ILUsed = 'No' in testbench ), Respective Environment/System variable will be written with the signal value. 
    
=cut

sub CANoe_write_signal {

    # COMMENT-START
    # args:
    #    - $busSignal_href (busType, busNbr, Message or PDU, signal_name, unit)
    #    - $busSignal_val_to_write
    #    - $mode (optional)
    # COMMENT-END

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_write_signal ($signalInfo_href , $busSignalValue, [$mode])', @args );
    my $signalInfo_href = shift @args;
    my $busSignalValue  = shift @args;
    my $mode            = shift @args;

    Write_Log_Text('start ..');

    # already verified
    my $busType     = $signalInfo_href->{'BUS_TYPE'};
    my $busNbr      = $signalInfo_href->{'BUS_NBR'};
    my $msgPdu      = $signalInfo_href->{'PDU_MESSAGE'};
    my $signalName  = $signalInfo_href->{'SIGNAL_NAME'};
    my $factor      = $signalInfo_href->{'FACTOR'};
    my $offset      = $signalInfo_href->{'OFFSET'};
    my $cycleTime   = $signalInfo_href->{'CYCLE'};
    my $unit        = $signalInfo_href->{'UNIT'};
    my $envOrSysvar = $signalInfo_href->{'CANOE_WR_SIGNAL'};

    my $parameters = "Bus = '$busType', busNbr = '$busNbr',  msg = '$msgPdu',  signalName = $signalName',  factor = '$factor', offset = '$offset', cycle time = '$cycleTime', unit = $unit, EnvOrSysVar = '$envOrSysvar'";
    Write_Log_Text(" args : [ $parameters , busSignalValue = $busSignalValue , mode = $mode ]");

    # CALL Check_mode
    $mode = Check_mode($mode) || return;

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP handle offline mode ( return 1 )
    return 1 if $main::opt_offline;

    # STEP check if CANoe measuement runing ? if not write error and return
    unless ( CANoe_check_running($ole_handle) ) {
        CANoe_start_measurement() || return;
    }

    # IF $mode ?
    my $signal_value_raw_to_wr;
    if ( $mode =~ /raw/i ) {

        # IF-RAW-START
        # STEP validate if $busSignal_val_to_write is Hex if Yes proceed to write raw value (no conversion required)
        # IF-RAW-END
        if ( $busSignalValue =~ /^0x[0-9A-F]+$/i ) {
            $signal_value_raw_to_wr = hex($busSignalValue);
        }
        else {
            $signal_value_raw_to_wr = $busSignalValue;
        }

    }
    elsif ( $mode =~ /phys/i ) {

        # IF-PHYS-START
        # CALL Calc_raw_from_phys
        # IF-PHYS-END
        $signal_value_raw_to_wr = Calc_raw_from_phys( $signalInfo_href, $busSignalValue );
    }

    # IF Is Interactive layer used?
    if ( CANoe_check_InteractionLayer_used() ) {

        # IF-YES-START
        # CALL CANoe_rdWr_bus_signal_direct_raw
        Write_Log_Text("Interaction Layer used. Hence writing value '$signal_value_raw_to_wr' to the signal object");
        CANoe_wr_bus_signal_direct_raw( $ole_handle, $signalInfo_href, $signal_value_raw_to_wr );

        # IF-YES-END
    }
    else {
        # IF-NO-START
        # CALL CANoe_Write_EnvOrSysVar
        Write_Log_Text("Interaction Layer NOT used. Hence writing value '$signal_value_raw_to_wr' to the System/Environment variable '$envOrSysvar'");
        CANoe_Write_EnvOrSysVar( $envOrSysvar, $signal_value_raw_to_wr );

        # IF-NO-END
    }

    # STEP End
    return 1;
}

=head2 CANoe_wr_bus_signal_direct_raw

    $status = CANoe_wr_bus_signal_direct_raw ($ole_handle_mix, $bus_signal_href, $signal_value_raw_to_wr);
    
It writes the raw value '$signal_value_raw_to_wr' of the passed signal to the signal object. Signal attributes like (BusNbr, BusType, MsgName, SignalName) was passed by $bus_signal_href.

Called internally by L</"CANoe_write_signal">.     
    
=cut

sub CANoe_wr_bus_signal_direct_raw {

    # COMMENT-START
    # args :
    # - $ole_handle,
    # - $bus_signal_href (busType, BusNbr, Message or PDU, signal_name)
    # COMMENT-END

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_wr_bus_signal_direct_raw ($ole_handle_mix, $bus_signal_href, $signal_value_raw_to_wr)', @args );
    my $ole_handle             = shift @args;
    my $bus_signal_href        = shift @args;
    my $signal_value_raw_to_wr = shift @args;

    # passed args :-
    my $busType    = $bus_signal_href->{'BUS_TYPE'};
    my $busNbr     = $bus_signal_href->{'BUS_NBR'};
    my $msg        = $bus_signal_href->{'PDU_MESSAGE'};
    my $signalName = $bus_signal_href->{'SIGNAL_NAME'};

    # full qualified signal name = Channel, database name (alias), node, message and signal
    my $fullQualifiedSignalName = "$busType" . "_" . "$busNbr :: $msg :: $signalName";
    Write_Log_Text(" start writing  - '$fullQualifiedSignalName' ");

    return 1 if $main::opt_offline;

    # CALL CANoe_get_bus_signal_object
    my $signal_object;
    unless ( $signal_object = CANoe_get_bus_signal_object( $ole_handle, $bus_signal_href ) ) {
        Write_Error_Text( "Could not fetch signal object for $fullQualifiedSignalName ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP Write the Raw value
    SetObjProperty( $signal_object, 'RawValue', $signal_value_raw_to_wr );
    sleep 1;

    Write_Log_Text(" done ..  - '$fullQualifiedSignalName' = $signal_value_raw_to_wr ");
    return 1;
}

=head2 CANoe_get_bus_signal_object

    $signalObject = CANoe_get_bus_signal_object ($ole_handle_mix, $bus_signal_href);
    
It gets the signal object of type either (CAN , LIN or FlexRay). Signal attributes like (BusNbr, BusType, MsgName, SignalName) was passed by $bus_signal_href.

Called internally by L</"CANoe_wr_bus_signal_direct_raw"> and by L</"CANoe_rd_bus_signal_direct_raw">.     
    
=cut

sub CANoe_get_bus_signal_object {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_bus_signal_object ($ole_handle_mix, $bus_signal_href)', @args );
    my $ole_handle      = shift @args;
    my $bus_signal_href = shift @args;

    # passed args :-
    my $busType    = $bus_signal_href->{'BUS_TYPE'};
    my $busNbr     = $bus_signal_href->{'BUS_NBR'};
    my $msg        = $bus_signal_href->{'PDU_MESSAGE'};
    my $signalName = $bus_signal_href->{'SIGNAL_NAME'};

    return {} if $main::opt_offline;

    my ( $signal_object, $bus_Object );

    # STEP Get 'bus-object' from busType (busType = CAN/CANFD/LIN/FlexRay)
    $bus_Object = $ole_handle->Bus            if ( $busType =~ /CAN/i );       # for CAN and CANFD
    $bus_Object = $ole_handle->Bus("Lin")     if ( $busType =~ /LIN/i );
    $bus_Object = $ole_handle->Bus("FlexRay") if ( $busType =~ /FLEXRAY/i );
    unless ($bus_Object) {
        Write_Error_Text( "Unable to get bus Object for BUS type $busType ", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP Get 'signal object' from 'bus-object'
    Write_Log_Text( " OLE_handle -> Bus -> GetSignal(bus_number = $busNbr, message = $msg, given_signal = $signalName ) ..", WRLOG_LEVEL_4 );
    $signal_object = $bus_Object->GetSignal( $busNbr, $msg, $signalName );
    S_get_LastError_OLE();

    # STEP SIGNAL object retireved ? if not try one more time
    unless ( defined $signal_object ) {
        sleep 1;
        Write_Log_Text( " 2nd try .. OLE_handle -> Bus -> GetSignal(bus_number = $busNbr, message = $msg, given_signal = $signalName ) ..", WRLOG_LEVEL_4 );
        $signal_object = $bus_Object->GetSignal( $busNbr, $msg, $signalName );
        S_get_LastError_OLE();
    }

    # STEP return 'signal object'
    return $signal_object;
}

=head2 Check_mode

=cut

sub Check_mode {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Check_mode ( [$mode])', @args );
    my $mode = shift @args;

    # STEP set default $mode = phys if not given
    unless ( defined $mode ) {
        Write_Log_Text(" no mode (phys/raw) given , set to 'phys' per default )");
        $mode = 'phys';
    }

    # STEP check if $mode = either phys or raw ? if not throw error and retrun
    unless ( $mode =~ /phys/i or $mode =~ /raw/i ) {
        Write_Error_Text( "Invalid params ! mode shall be either 'phys' or 'raw'.. )", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP return mode after validation
    return $mode;
}

=head2 Calc_raw_from_phys

   $raw_value =  Calc_raw_from_phys ( $signal_info_href, $phys_value)

Raw value was calculated for the passed $phys_value as per Factor & Offset found in the Mapping file.     

=cut

sub Calc_raw_from_phys {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Calc_raw_from_phys ( $signal_info_href, $phys_value)', @args );
    my $signal_info_href = shift @args;
    my $phys_value       = shift @args;

    my ( $raw_value, $sig_offset, $sig_factor, $signal_name );

    # STEP validate 'SIGNAL_NAME' & fetch signal name from $signalInfo_href
    unless ( $signal_name = $signal_info_href->{'SIGNAL_NAME'} ) {
        Write_Error_Text( "no 'SIGNAL_NAME' defined for given signal\n", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP validate 'OFFSET' & fetch offset value from $signalInfo_href
    $sig_offset = $signal_info_href->{'OFFSET'};
    unless ( defined $sig_offset ) {
        Write_Error_Text( "no 'OFFSET' defined for signal '$signal_name' ", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP validate 'FACTOR' & fetch factor value from $signalInfo_href
    $sig_factor = $signal_info_href->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 ) {
        Write_Error_Text( "no 'FACTOR' defined or '0.0' for signal '$signal_name' \n", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP calculate raw value from phys . Formula : raw = (phys - offset) / factor
    # STEP round the calcualted raw value
    $raw_value = NUM_round2Int( ( $phys_value - $sig_offset ) / $sig_factor );
    Write_Log_Text(" Transformation '$signal_name' : $raw_value (raw) = ( $phys_value (phys) - $sig_offset (offset) / $sig_factor (factor)");

    # STEP return calculated raw value

    return $raw_value;
}

=head2 Calc_phys_from_raw

   $phys_value =  Calc_phys_from_raw ( $signal_info_href, $raw_value)

Physical value was calculated for the passed $raw_value as per Factor & Offset found for the signal in the Mapping file.

=cut

sub Calc_phys_from_raw {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Calc_phys_from_raw ( $signal_info_href, $raw_value)', @args );
    my $signal_info_href = shift @args;
    my $raw_value        = shift @args;

    my ( $phys_value, $sig_offset, $sig_factor, $signal_name );

    # STEP validate 'SIGNAL_NAME' & fetch signal name from $signalInfo_href
    unless ( defined( $signal_name = $signal_info_href->{'SIGNAL_NAME'} ) ) {
        Write_Error_Text( "no 'SIGNAL_NAME' defined for given signal", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP validate 'OFFSET' & fetch offset value from $signalInfo_href
    unless ( defined( $sig_offset = $signal_info_href->{'OFFSET'} ) ) {
        Write_Error_Text( "no 'OFFSET' defined for signal '$signal_name'", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP validate 'FACTOR' & fetch factor value from $signalInfo_href
    $sig_factor = $signal_info_href->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 ) {
        Write_Error_Text( "no 'FACTOR' defined or '0.0' for signal '$signal_name'", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP calculate phys value from raw. Formula : phys = (hex * factor) + offset
    $phys_value = ( $raw_value * $sig_factor ) + $sig_offset;

    Write_Log_Text(" Transformation '$signal_name' : $phys_value (phys) = ( $raw_value (raw) * $sig_factor (factor) + $sig_offset (offset)");

    # STEP return phys value
    return $phys_value;
}

=head1 Message 

=head2 CANoe_disable_msg

    CANoe_disable_msg ( $msgInfo_href, [,$mapping_conversion_done] );
    
It writes corresponding Environment/System variable B<(mapping key = CANOE_ENABLE to the value = 0) > as defined in the Mapping file (CAN, LIN or FlexRay) for disbabling the message or PDU or frame.     
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/System variable & message) for triggering disabling of the message.

- $msgInfo_href->{'CANOE_ENABLE'} = retrieves the Environment/System variable
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

- $mapping_conversion_done is an optional parameter that is set to 1 when NET Access Mapping files are not available resulting in mapping conversion from (CAN/LIN/FlexRay)_Mapping to NET_Access_(CAN/LIN/Flexray)_Mapping

=back    

B<Note> : User has to write the CAPL program for the Environment/System variable event in CANoe which disables the message.

B<Note> : $mapping_conversion_done is set to 1 when mapping conversion is done. In this case, 'CANOE_DISABLE' is set to 1.

B<Hint> : for CAN : Look CANoeIL functionalites like B<ILDisableMsg or ILFaultInjectionDisableMsg>.

=cut

sub CANoe_disable_msg {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_disable_msg ( $msgInfo_href, [,$mapping_conversion_done] )', @args );
    my $msgInfo_href            = shift @args;
    my $mapping_conversion_done = shift @args;

    Write_Log_Text('start ..');

    # STEP get the Envionment/System varible for enable msg : $msgPdu_href -> {'CANOE_ENABLE'}
    my $envOrSysVar = $msgInfo_href->{'CANOE_ENABLE'};
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    Write_Log_Text("Env/SysVar to enable/disable msg '$msgName' = '$envOrSysVar' (mapping key = CANOE_ENABLE)");

    my $set_msg_enable = 0;    #  default for NET_Acces implementation for  key CANOE_ENABLE
    $set_msg_enable = 1 if ( $mapping_conversion_done == 1 );

    # STEP write corresponding Env/SysVar 'CANOE_ENABLE' = 0 when NET Access Mapping is in use and 'CANOE_ENABLE' = 1 when mapping conversion is done.
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, $set_msg_enable );
    unless ( defined $status ) {
        Write_Error_Text( "Error in disabling message '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    # STEP return the status = 1
    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_enable_msg

    CANoe_enable_msg ( $msgInfo_href, [,$mapping_conversion_done] );
    
It writes corresponding B<Environment/System variable (mapping key = CANOE_ENABLE to the value = 1) > as defined in the Mapping file (CAN, LIN or FlexRay) for enabling the message or PDU or frame.     
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/system variable & message) for triggering enabling of the message.

- $msgInfo_href->{'CANOE_ENABLE'} = retrieves the Environment/System variable
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

- $mapping_conversion_done is an optional parameter that is set to 1 when NET Access Mapping files are not available resulting in mapping conversion from (CAN/LIN/FlexRay)_Mapping to NET_Access_(CAN/LIN/Flexray)_Mapping

=back    

B<Note> : User has to write the CAPL program for the Environment/System variable event in CANoe which enables the message.

B<Note> : $mapping_conversion_done is set to 1 when mapping conversion is done. In this case, 'CANOE_DISABLE' is set to 0.

B<Hint> : for CAN : Look CANoeIL functionalites like B<ILEnableMsg or ILFaultInjectionEnableMsg>.

=cut

sub CANoe_enable_msg {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_enable_msg ( $msgInfo_href, [,$mapping_conversion_done] )', @args );
    my $msgInfo_href            = shift @args;
    my $mapping_conversion_done = shift @args;

    Write_Log_Text('start ..');

    # STEP get the Envionment/system varible for enable msg : $msgPdu_href -> {'CANOE_ENABLE'}
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    my $envOrSysVar = $msgInfo_href->{'CANOE_ENABLE'};

    Write_Log_Text("Env/SysVar to enable/disable msg '$msgName' = '$envOrSysVar' (mapping key = CANOE_ENABLE)");

    my $set_msg_enable = 1;    #  default for NET_Acces implementation for  key CANOE_ENABLE
    $set_msg_enable = 0 if ( $mapping_conversion_done == 1 );

    # STEP write corresponding Env/SysVar 'CANOE_ENABLE' = 1 when NET Access Mapping is used and 'CANOE_ENABLE' = 0 when Mapping conversion is done.
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, $set_msg_enable );
    unless ( defined $status ) {
        Write_Error_Text( "Error in enabling message '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }

    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_set_dlc

    CANoe_set_dlc ( $msgInfo_href );
    
It sets the new DLC value to the corresponding B<Environment/System variable (mapping key = CANOE_DLC)> as defined in the Mapping file (CAN, LIN or FlexRay)        
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/System variable & message) for setting new DLC value.

- $msgInfo_href->{'CANOE_DLC'} = retrieves the Environment/System variable for writing the DLC value
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

=back    

B<Note> : User has to write the CAPL program for the Environment/System variable event in CANoe which writes sets the new DLC value.

B<Hint> : for CAN : Look CANoeIL functionalites like B<ILFaultInjectionSetMsgDlc>.

=cut

sub CANoe_set_dlc {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_set_dlc ( $msgInfo_href, $dlcValue )', @args );
    my $msgInfo_href = shift @args;
    my $dlcValue     = shift @args;

    Write_Log_Text('start ..');

    # STEP get the Envionment/System varible for chaning DLC : $msgPdu_href -> {'CANOE_DLC'}
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    my $envOrSysVar = $msgInfo_href->{'CANOE_DLC'};
    Write_Log_Text("Env/SysVar to set DLC value = '$dlcValue' for msg '$msgName' = '$envOrSysVar' (mapping key = CANOE_DLC).");

    # STEP validate the passed '$dlcValue'
    if ( ( $dlcValue < 1 or $dlcValue > 8 ) and $dlcValue !~ /^ERROR$/i ) {
        Write_Error_Text( "passed dlc '$dlcValue' is neither in valid range of DLC (1..8) nor an ERROR flag . Will be set to value = $msgInfo_href->{'DLC_Mapping'} (value from Mapping)", 0 );
        $dlcValue = $msgInfo_href->{'DLC_Mapping'};
    }

    # STEP Set the wrong DLC value (i.e DLC from mapping - 1), if the Error flag was passed.
    if ( $dlcValue =~ /^ERROR$/i ) {
        $dlcValue = $msgInfo_href->{'DLC_Mapping'} - 1;
        Write_Log_Text("Setting the Wrong DLC value (i.e DLC from mapping - 1) = '$dlcValue'..");
    }

    # STEP write corresponding Env/SysVar 'CANOE_DLC' = $dlcValue
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, $dlcValue );
    unless ( defined $status ) {
        Write_Error_Text( "Error in setting DLC value for message or PDU '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_reset_dlc

    CANoe_reset_dlc ( $msgInfo_href );
    
It resets the DLC value to the corresponding B<Environment/System variable (mapping key = CANOE_DLC)> as defined in the Mapping file (CAN, LIN or FlexRay)

reset value can be the new value that user want to set or it is the DLC value from the mapping file if not passed by the user.        
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/system variable & message) for re-setting DLC value.

- $msgInfo_href->{'CANOE_DLC'} = retrieves the Environment/System variable for writing the DLC value
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

=back    

B<Note> : User has to write the CAPL program for the Environment/System variable event in CANoe which resets DLC value.

B<Hint> : for CAN : Look CANoeIL functionalites like B<ILFaultInjectionResetMsgDlc> .

=cut

sub CANoe_reset_dlc {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_reset_dlc ( $msgInfo_href, [$given_DLC] )', @args );
    my $msgInfo_href = shift @args;
    my $given_DLC    = shift @args;
    Write_Log_Text('start ..');

    # STEP get the Envionment/System varible for changing DLC : $msgPdu_href -> {'CANOE_DLC'}
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    my $envOrSysVar = $msgInfo_href->{'CANOE_DLC'};
    Write_Log_Text("Env/SysVar to reset DLC ('optional' value = $given_DLC ) for msg '$msgName' = '$envOrSysVar' (mapping key = CANOE_DLC).");

    # STEP validate the passed '$dlcValue'
    my $dlcValue;
    if ( defined $given_DLC and ( $given_DLC >= 1 and $given_DLC <= 8 ) ) {
        $dlcValue = $given_DLC;
    }
    else {
        $dlcValue = $msgInfo_href->{'DLC_Mapping'};
        Write_Log_Text("Orignal DLC value = '$dlcValue' from Mapping will be set.");
    }

    # STEP write corresponding Env/SysVar 'CANOE_DLC' = $dlcValue
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, $dlcValue );
    unless ( defined $status ) {
        Write_Error_Text( "Error in resetting DLC value for message or PDU '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_set_counter_error

    CANoe_set_counter_error ( $msgInfo_href );
    
It sets the B<value = 0> to the corresponding B<Environment/System variable (mapping key = CANOE_VALIDCNT)> as defined in the Mapping file (CAN, LIN or FlexRay)

User has to write the CAPL program for the Environment/System variable event in CANoe which for creating the BZ error.        
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/System variable & message) for re-setting DLC value.

- $msgInfo_href->{'CANOE_VALIDCNT'} = retrieves the Environment/System variable for creating the BZ error.
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

=back    

=cut

sub CANoe_set_counter_error {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_set_counter_error ( $msgInfo_href )', @args );
    my $msgInfo_href = shift @args;

    Write_Log_Text('start ..');

    # STEP get the Envionment/System varible for enable msg : $msgPdu_href -> {'CANOE_VALIDCNT'}
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    my $envOrSysVar = $msgInfo_href->{'CANOE_VALIDCNT'};
    Write_Log_Text("Env/SysVar to set BZ Error '$msgName' = '$envOrSysVar' (mapping key = CANOE_VALIDCNT) ");

    # STEP write corresponding Env/SysVar, mapping key 'CANOE_VALIDCNT' = 0
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, 0 );
    unless ( defined $status ) {
        Write_Error_Text( "Error in setting BZ error for '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_reset_counter_error

    CANoe_reset_counter_error ( $msgInfo_href );
    
It sets the B<value = 1> to the corresponding B<Environment/System variable (mapping key = CANOE_VALIDCNT)> as defined in the Mapping file (CAN, LIN or FlexRay)

User has to write the CAPL program for the Environment/System variable event in CANoe for re-setting the BZ error.        
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/system variable & message) for re-setting DLC value.

- $msgInfo_href->{'CANOE_VALIDCNT'} = retrieves the Environment/system variable for re-setting the BZ error.
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

=back    

=cut

sub CANoe_reset_counter_error {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_reset_counter_error ( $msgInfo_href )', @args );
    my $msgInfo_href = shift @args;

    Write_Log_Text('start ..');

    # STEP get the Envionment/System varible for enable msg : $msgPdu_href -> {'CANOE_VALIDCNT'}
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    my $envOrSysVar = $msgInfo_href->{'CANOE_VALIDCNT'};

    Write_Log_Text("Env/SysVar to re-set BZ Error '$msgName' = '$envOrSysVar' (mapping key = CANOE_VALIDCNT) ");

    # STEP write corresponding Env/SysVar, mapping key 'CANOE_VALIDCNT' = 1
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, 1 );
    unless ( defined $status ) {
        Write_Error_Text( "Error in re-setting BZ error for '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_set_crc_error

    CANoe_set_crc_error ( $msgInfo_href );
    
It sets the B<value = 0> to the corresponding B<Environment/System variable (mapping key = CANOE_VALIDCRC)> as defined in the Mapping file (CAN, LIN or FlexRay)

User has to write the CAPL program for the Environment/System variable event in CANoe for creating CRC error..        
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/system variable & message) for creating CRC error.

- $msgInfo_href->{'CANOE_VALIDCRC'} = retrieves the Environment/System variable for creating CRC error.
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

=back    

=cut

sub CANoe_set_crc_error {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_set_crc_error ( $msgInfo_href )', @args );
    my $msgInfo_href = shift @args;

    Write_Log_Text('start ..');

    # STEP get the Envionment/System varible for creating CRC error : $msgPdu_href -> {'CANOE_VALIDCRC'}
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    my $envOrSysVar = $msgInfo_href->{'CANOE_VALIDCRC'};

    Write_Log_Text("Env/SysVar to set CRC Error '$msgName' = '$envOrSysVar' (mapping key = CANOE_VALIDCRC) ");

    # STEP write corresponding Env/SysVar, mapping key 'CANOE_VALIDCRC' = 0
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, 0 );
    unless ( defined $status ) {
        Write_Error_Text( "Error in setting CRC error for '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_reset_crc_error

    CANoe_reset_crc_error ( $msgInfo_href );
    
It sets the B<value = 1> to the corresponding B<Environment/System variable (mapping key = CANOE_VALIDCRC)> as defined in the Mapping file (CAN, LIN or FlexRay)

User has to write the CAPL program for the Environment/System variable event in CANoe for re-setting CRC error..        
    
B<Arguments:>

=over

=item $msgInfo_href 

hash reference containing the info (environment/system variable & message) for resetting CRC error.

- $msgInfo_href->{'CANOE_VALIDCRC'} = retrieves the Environment/System variable for resetting CRC error.
 
- $msgInfo_href->{'PDU_MESSAGE'} = retrieves the message name (for info logging)

=back    

=cut

sub CANoe_reset_crc_error {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_reset_crc_error ( $msgInfo_href )', @args );
    my $msgInfo_href = shift @args;

    Write_Log_Text('start ..');

    # STEP get the Envionment/System varible for resetting CRC error : $msgPdu_href -> {'CANOE_VALIDCRC'}
    my $msgName     = $msgInfo_href->{'PDU_MESSAGE'};
    my $envOrSysVar = $msgInfo_href->{'CANOE_VALIDCRC'};

    Write_Log_Text("Env/SysVar to re-set CRC Error '$msgName' = '$envOrSysVar' (mapping key = CANOE_VALIDCRC) ");

    # STEP write corresponding Env/SysVar, mapping key 'CANOE_VALIDCRC' = 1
    my $status = CANoe_Write_EnvOrSysVar( $envOrSysVar, 1 );
    unless ( defined $status ) {
        Write_Error_Text( "Error in re-setting CRC error for '$msgName'. Problem while resolving the Environment/System variable '$envOrSysVar'.", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    Write_Log_Text('end ..');
    return 1;
}

=head1 Environment Variable 

=head2 CANoe_set_envVar_value

    CANoe_set_envVar_value ( $env_var_name, $env_var_value );
    
Sets CANoe B<environment variable> '$env_var_name' to value '$env_var_value'.    

B<Notes:>

- expects $env_var_name as scalar value for EnvVar type of type B<Integer, Float, String>
 
- expects $env_var_name as array_ref if EnvVar type is B<Data>

- Integer and Data may be hex or dec or bin.

B<Examples:>    

    CANoe_set_envVar_value('Env_Var_Typ_int', 10);                         # Int  
    CANoe_set_envVar_value('Env_Var_Typ_int', 10.25);                      # Int (set value 10)
    CANoe_set_envVar_value('Env_Var_Typ_Float', 102.25);                   # Float
    CANoe_set_envVar_value('Env_Var_Typ_String', "LRT ENV testing");       # String
    CANoe_set_envVar_value('Env_Var_Typ_Data', [0xA, 0xB, 0xC, 0xD, 0xE]); # Data
 
=cut

sub CANoe_set_envVar_value {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_set_envVar_value ( $env_var_name, $env_var_value_mix)', @args );
    my $env_var_name  = shift @args;
    my $env_var_value = shift @args;

    # STEP args: - $envVariableName - $env_var_value
    Write_Log_Text(" prepare to set '$env_var_name' to value = '$env_var_value' ");

    # STEP handle offline condition, return 1
    return 1 if $main::opt_offline;

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP Get the Environment variable object
    Write_Log_Text( " OLE_handle -> Application-> Environment-> GetVariable( $env_var_name ) .. ", WRLOG_LEVEL_5 );
    my $env_var_handle = CallCOM_Method( $ole_handle, [ 'Application', 'Environment' ], 'GetVariable', [$env_var_name] );
    unless ( defined $env_var_handle ) {
        Write_Error_Text( "on '$hostname' for '$device' application - No environment variable '$env_var_name' is defined ", 0 );
        return;
    }

    # STEP Set the value $env_var_value to Environment variable object according to type .
    # CALL CANoe_set_EnvVar_value_by_type
    CANoe_set_EnvVar_value_by_type( $env_var_handle, $env_var_name, $env_var_value );
    Write_Log_Text('end ..');

    return 1;
}

=head2 CANoe_set_EnvVar_value_by_type

    CANoe_set_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var, $value_mix )

Sets Environment varible '$env_var' to value '$value_mix' as per type dataType defined in CAN db for Env Variable.

DataTypes are B<'0: Integer, 1: Float, 2: String, 3: Data'>.

Called internally by L</"CANoe_set_envVar_value">.    

=cut

sub CANoe_set_EnvVar_value_by_type {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_set_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var, $value_mix )', @args );

    my $h_env_var_obj = shift @args;
    my $env_var       = shift @args;
    my $value         = shift @args;

    my $envDataTypes = '0: Integer, 1: Float, 2: String, 3: Data';
    my $type         = $h_env_var_obj->Type();                       #( 0: Integer, 1: Float, 2: String, 3: Data)
    if ( $type == 3 ) {
        if ( ref($value) ne "ARRAY" ) {
            Write_Error_Text( "EnvVarValue is not an array reference, but EnvVar type is Data", ERR_INVALID_PARAMETERS );
            return;
        }
        my @temp = @$value;
        foreach (@temp) {
            $_ = S_0x2dec($_);
        }
        $h_env_var_obj->{'Value'} = \@temp;
        Write_Log_Text(" $env_var' set to array = '@temp' of type $type ( $envDataTypes).");
    }
    elsif ( $type == 0 ) {
        $value = S_0x2dec($value);
        $h_env_var_obj->{'Value'} = $value;
        Write_Log_Text(" '$env_var' set to value = '$value' of type $type ( $envDataTypes).");
    }
    else {
        $h_env_var_obj->{'Value'} = $value;
        Write_Log_Text(" '$env_var' set to value = '$value' of type $type. ( $envDataTypes)");
    }
    return 1;
}

=head2 CANoe_get_envVar_value

 $env_var_value = CANoe_get_envVar_value ( $env_var_name );

Returns scalar value for EnvVar of type B<Integer, Float, String> and returns array_ref of dec values if EnvVar type is B<Data>.

B<Examples:>    

    $intVal   = CANoe_get_envVar_value('Env_Var_Typ_int');       # Interger  
    $floatVal = CANoe_get_envVar_value('Env_Var_Typ_Float');     # Float
    $stringVal= CANoe_get_envVar_value('Env_Var_Typ_String');    # String
    $arrRef   = CANoe_get_envVar_value('Env_Var_Typ_Data');      # Data

=cut

sub CANoe_get_envVar_value {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_envVar_value ( $env_var_name)', @args );
    my $env_var_name = shift @args;

    # STEP args: - $envVariableName - $env_var_value
    Write_Log_Text(" prepare to retreive the value of '$env_var_name'");

    # STEP handle offline condition, return 1
    return 1 if $main::opt_offline;

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP Get the Environment variable object
    Write_Log_Text( " OLE_handle -> Application-> Environment-> GetVariable( $env_var_name ) .. ", WRLOG_LEVEL_5 );
    my $env_var_handle = CallCOM_Method( $ole_handle, [ 'Application', 'Environment' ], 'GetVariable', [$env_var_name] );
    unless ( defined $env_var_handle ) {
        Write_Error_Text( "on $hostname for $device application - No environment variable '$env_var_name' is defined ", 0 );
        return;
    }

    # STEP Get the value of Environment variable from object
    # CALL CANoe_get_EnvVar_value_by_type
    my $env_var_value = CANoe_get_EnvVar_value_by_type( $env_var_handle, $env_var_name );
    Write_Log_Text("end .. '$env_var_name = $env_var_value' ");

    # STEP return $env_var_value
    return $env_var_value;
}

=head2 CANoe_get_EnvVar_value_by_type

    $env_var_value = CANoe_get_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var)

Gets the Environment varible '$env_var' as per type dataType defined in CAN db for Env Variable.

DataTypes are B<'0: Integer, 1: Float, 2: String, 3: Data'>.

Called internally by L</"CANoe_get_envVar_value">.  

=cut

sub CANoe_get_EnvVar_value_by_type {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var)', @args );
    my $h_env_var_obj = shift @args;
    my $env_var       = shift @args;

    my $env_var_value;

    my $envDataTypes = '0: Integer, 1: Float, 2: String, 3: Data';
    my $type         = $h_env_var_obj->Type();                       #( 0: Integer, 1: Float, 2: String, 3: Data)
    if ( $type == 3 ) {
        my @temp = split( //, $h_env_var_obj->{'Value'} );
        foreach (@temp) {
            $_ = ord($_);
        }
        $env_var_value = \@temp;
        Write_Log_Text(" '$env_var' retrives array = '@temp' of type $type ($envDataTypes).");
    }
    else {
        $env_var_value = $h_env_var_obj->{'Value'};
        Write_Log_Text(" '$env_var' retrieves value = '$env_var_value' of type $type ($envDataTypes).");
    }

    return $env_var_value;
}

=head1 System variables

=head2 CANoe_set_sysVar_value

    CANoe_set_sysVar_value ( $sys_var_name, $sys_var_value_mix)

Sets the value of B<System variable> of type B<Integer, Float, String, Integer Array, Float Array>  to CANoe.

B<Arguments:>

=over

=item $sys_var_name 

System varible name B<<NAMESPACE::VAR_NAME>> must be defined in the Systme variable file & added to respective CANoe Configuration.
Supported variable types are "Integer, Float, String, Integer Array , Float Array".

MULTIPLE level of namespace are also supported.

=item $sys_var_value_mix 

value to be set for the system variable. Value can be Integer, Float, String, Integer Array , Float Array.
It depends on what kind of System variable has been defined in the system variable file. Pass it accordingly.

=back

B<Examples:>

    # -----------------------------------
    # examples for SINGLE LEVEL NAMESPACE
    # -----------------------------------
    CANoe_set_sysVar_value('LIFT_CAN_access::SysVar_Type_Int', 0xFF) ;        # set integer value
    CANoe_set_sysVar_value('LIFT_CAN_access::SysVar_Type_Int', 255) ;         # set integer value
    CANoe_set_sysVar_value('LIFT_CAN_access::SysVar_Type_Float',  525.25) ;    # set float value
    CANoe_set_sysVar_value('LIFT_CAN_access::SysVar_Type_String',  "LRT SYSVAR testing") ;   # set string value
    
    # set float array of 10 data points, all points must be specified
    # Integer dataPoints will be converted to float before set to CANoe
    CANoe_set_sysVar_value('LIFT_CAN_access::SysVar_FloatArray',  [1.0, 2, 3, 4, 5.5, 6.4, 2.5, 8.0, 9.0 , 9.5]) ;
       
    # set Integer array 10 data points, all points must be specified
    # Float dataPoints if any will be converted to Integer (removed decimal part) before set to CANoe
    CANoe_set_sysVar_value('LIFT_CAN_access::SysVar_IntegerArray',  [0, 1, 1, 2.0, 3, 5, 8.1, 11, 19, 30 ]) ;  

    # -------------------------------------
    # examples for MULTIPLE LEVEL NAMESPACE
    # --------------------------------------
    CANoe_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 0xFF) ;      # set integer value
    CANoe_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 255) ;       # set integer value
    CANoe_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Float',  525.25) ; # set float value
    CANoe_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_String', "LRT SYSVAR testing") ; # set string value
    
    # set float array of 10 data points, all points must be specified
    # Integer dataPoints will be converted to float before set to CANoe
    CANoe_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_FloatArray',  [1.0, 2, 3, 4, 5.5, 6.4, 2.5, 8.0, 9.0 , 9.5]) ;
       
    # set Integer array 10 data points, all points must be specified
    # Float dataPoints if any will be converted to Integer (removed decimal part) before set to CANoe
    CANoe_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_IntegerArray',  [0, 1, 1, 2.0, 3, 5, 8.1, 11, 19, 30 ]) ;    

=cut

sub CANoe_set_sysVar_value {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_set_sysVar_value ( $sys_var_name, $sys_var_value_mix)', @args );
    my $sys_var_name  = shift @args;
    my $sys_var_value = shift @args;

    # STEP args: - $sys_var_name - $sys_var_value
    Write_Log_Text(" prepare to set '$sys_var_name' to value = '$sys_var_value' ");

    # STEP handle offline condition, return 1
    return 1 if $main::opt_offline;
    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP Get the system variable handle
    my $sysvar_handle = CANoe_get_sys_variable( $ole_handle, $sys_var_name );

    # STEP write $sys_var_value to system variable handle
    CANoe_set_sysVar_value_by_type( $sysvar_handle, $sys_var_value );
    Write_Log_Text('end ..');
    return 1;
}

=head2 CANoe_get_sysVar_value

    $sys_var_value = CANoe_get_sysVar_value ( $sys_var_name)

Gets the value of B<System variable> of type B<Integer, Float, String, Integer Array, Float Array> from CANoe. 

B<Arguments:>

=over

=item $sys_var_name 

System varible name B<<NAMESPACE::VAR_NAME>> must be defined in the Systme variable file & added to respective CANoe Configuration.
Supported variable types are of type : "Integer, Float, String, Integer Array , Float Array".

- MULTIPLE level of namespace are also supported.

=back

B<Return Value:>

=over

=item $sys_var_value 

on Success it will return = "Integer, Float, String, Integer Array , Float Array" depends on the type of System variable defined in CANoe (System variable file) .

=item $offline 

Offline return is 1. 

=back

B<Examples:>

  # -----------------------------------
  # examples for SINGLE LEVEL NAMESPACE
  # -----------------------------------
  $intVal       = CANoe_get_sysVar_value('LIFT_CAN_access::SysVar_Type_Int') ;       # get integer value  
  $floatVal     = CANoe_get_sysVar_value('LIFT_CAN_access::SysVar_Type_Float') ;     # get float value
  $stringVal    = CANoe_get_sysVar_value('LIFT_CAN_access::SysVar_Type_String') ;    # get string value
  $float_aref   = CANoe_get_sysVar_value('LIFT_CAN_access::SysVar_FloatArray');      # get float array value as array reference
  $integer_aref = CANoe_get_sysVar_value('LIFT_CAN_access::SysVar_IntegerArray');    # get Integer array value as array reference

  # -------------------------------------
  # examples for MULTIPLE LEVEL NAMESPACE
  # --------------------------------------
  $intVal = CANoe_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int') ;     # get integer value  
  $floatVal = CANoe_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Float') ;   # get float value
  $stringVal = CANoe_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_String') ;  # get string value
  $float_aref = CANoe_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_FloatArray');    # get float array value as array reference
  $integer_aref = CANoe_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_IntegerArray');  # get Integer array value as array reference  

  
=cut

sub CANoe_get_sysVar_value {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_sysVar_value ( $sys_var_name)', @args );
    my $sys_var_name = shift @args;

    # STEP args: - $sys_var_name
    Write_Log_Text(" prepare to retreive the value of '$sys_var_name'");

    # STEP handle offline condition, return 1
    return 1 if $main::opt_offline;

    my $ole_handle = Get_oleHandle()             || return;
    my $device     = Get_deviceType($ole_handle) || return;
    my $hostname   = Get_hostName($ole_handle)   || return;

    # STEP Get the System variable object
    my $sysvar_handle = CANoe_get_sys_variable( $ole_handle, $sys_var_name );

    # STEP Get the value of System variable from object
    my $sys_var_value = CANoe_get_sysVar_value_by_type( $sysvar_handle, $sys_var_name );
    Write_Log_Text("end .. '$sys_var_name = $sys_var_value' ");

    # STEP return $sys_var_value
    return $sys_var_value;
}

=head2 CANoe_get_sys_variable

    $sysvar_handle = CANoe_get_sys_variable ( $ole_handle_mix, $ns_sys_var);

It gets the object (or handle) for the system variable defined in the sytem variable file.

It first looks for the namespace and then the system variable itself.
Once it finds the variable it returns the handle for the system variable which shall be used later to get & set the value for sysVar.

Called internally by L</"CANoe_get_sysVar_value"> and by L</"CANoe_set_sysVar_value">.  

=cut

sub CANoe_get_sys_variable {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_sys_variable ( $ole_handle_mix, $ns_sys_var)', @args );
    my $ole_handle = shift @args;
    my $ns_sys_var = shift @args;

    my $device   = Get_deviceType($ole_handle) || return;
    my $hostname = Get_hostName($ole_handle)   || return;

    my @given_ns = split( "::", $ns_sys_var );
    my $used_sysvar_name = pop(@given_ns);

    return 1 if $main::opt_offline;

    #     System
    #         Namespaces -> Count
    #             Namespace -> Item (index)
    #                 Variables -> Count
    #                     Variable -> Item (index)

    my $object = $ole_handle->System();
    S_get_LastError_OLE();
    return unless defined $object;

    foreach my $name (@given_ns) {
        my $found;
        foreach my $ns_index ( 1 .. $object->Namespaces->Count() ) {
            my $ns_name = $object->Namespaces->Item($ns_index)->Name();
            if ( $ns_name eq $name ) {
                Write_Log_Text(" Found NAMESPACE '$ns_name' .. ");
                $found  = 1;
                $object = $object->Namespaces->Item($ns_index);
                last;
            }
        }

        unless ($found) {
            Write_Error_Text( "could not find $name (on $device (host:$hostname) ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
    }

    foreach my $sysvars_index ( 1 .. $object->Variables->Count() ) {
        my $sysvar_handle = $object->Variables->Item($sysvars_index);
        S_get_LastError_OLE();
        return unless defined $sysvar_handle;
        my $sysvar_name = $sysvar_handle->Name();
        S_get_LastError_OLE();
        return unless defined $sysvar_name;
        next   unless $sysvar_name eq $used_sysvar_name;
        Write_Log_Text(" Found SYSVAR '$ns_name::$sysvar_name' ..");
        return $sysvar_handle;
    }

    Write_Error_Text( "could not find $used_sysvar_name (on $device (host:$hostname) ", ERR_VECTOR_CANOE_CONFIGURATION );
    return;
}

=head2 CANoe_set_sysVar_value_by_type

    CANoe_set_sysVar_value_by_type ( $h_sys_var_obj_mix, $value_mix )

Sets System varible handle '$h_sys_var_obj_mix' to value '$value_mix' as per type dataType defined in CAN db for SysVar Variable.

DataTypes are B<'0: Integer, 1: Float, 2: String, 4: Float Array, 5: Integer Array'>.

Called internally by  L</"CANoe_set_sysVar_value">.   

=cut

sub CANoe_set_sysVar_value_by_type {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_set_sysVar_value_by_type ( $h_sys_var_obj_mix, $value_mix)', @args );

    my $h_sys_var_obj = shift @args;
    my $value         = shift @args;

    my $sysVarsupportedDataTypes = '0: Integer, 1: Float, 2: String, 4: Float Array, 5: Integer Array';
    my $type = CallObj_Method( $h_sys_var_obj, 'Type' );
    if ( $type == 0 ) {    # 0: Integer
        $value = int($value);
    }
    elsif ( $type == 1 ) {    # 1: Float
        $value = $value + 1e-99;
    }
    elsif ( $type == 2 ) {    # 2: String ->  nothing to handle

    }
    elsif ( $type == 4 ) {    # 4: float array
        if ( ref($value) ne "ARRAY" ) {
            Write_Error_Text( "SysVarValue is not an array reference, but SysVar type is Float array ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }
        @$value = map { $_ + 1e-99 } @$value;    # change each value to float if not, otherwise values won't be set to CANoe

    }
    elsif ( $type == 5 ) {                       # Integer array
        if ( ref($value) ne "ARRAY" ) {
            Write_Error_Text( "SysVarValue is not an array reference, but SysVar type is int array ", ERR_VECTOR_CANOE_CONFIGURATION );
            return;
        }

        @$value = map { int($_) } @$value;       # change each value to int if not, otherwise values won't be set to CANoe
    }
    else {
        # not cheked yet or teted for :
        # 6: LongLong, 7: Byte Array, 98: Generic Array , 99: Struct , 65535: Invalid
        Write_Error_Text( "these type of system variable are not implemented yet or checked ( 6: LongLong, 7: Byte Array, 98: Generic Array , 99: Struct)", 0 );
    }

    SetObjProperty( $h_sys_var_obj, 'Value', $value );
    Write_Log_Text(" SysVar type = $type and set to value = '$value' ($sysVarsupportedDataTypes).");

    return 1;
}

=head2 CANoe_get_sysVar_value_by_type

    CANoe_get_sysVar_value_by_type ( $h_sys_var_obj_mix, $value_mix )

Gets System varible handle '$h_sys_var_obj_mix' to value '$value_mix' as per type dataType defined in CAN db for SysVar Variable.

DataTypes are B<'0: Integer, 1: Float, 2: String, 4: Float Array, 5: Integer Array'>.
Called internally by  L</"CANoe_get_sysVar_value">.   

=cut

sub CANoe_get_sysVar_value_by_type {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_get_sysVar_value_by_type ( $h_sys_var_obj_mix, $sysvar)', @args );

    my $h_sys_var_obj = shift @args;
    my $sysvar        = shift @args;

    my $sysVarsupportedDataTypes = '0: Integer, 1: Float, 2: String, 4: Float Array, 5: Integer Array';
    my $type                     = CallObj_Method( $h_sys_var_obj, 'Type' );                              #( 0: Integer, 1: Float, 2: String, 3: Data)
    my $return_sys_var_value     = GetObjProperty( $h_sys_var_obj, 'Value' );

    Write_Log_Text(" '$sysvar' retrieves value = '$return_sys_var_value' of type = '$type'. ($sysVarsupportedDataTypes).");

    return $return_sys_var_value;
}

=head1 COM access

=cut

=head2 GetCOM_Object

    $object = GetCOM_Object($oleHandle_mix, $objectHierarchy_aref);

Gets the COM object from the object hierarchy.  

B<Examples:>

    $version_object = GetCOM_Object( $ole_handle, [ 'Application', 'Version' ] ) )  

=cut

sub GetCOM_Object {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetCOM_Object ( $oleHandle_mix, $objectHierarchy_aref)', @args );
    my $oleHandle                = shift @args;
    my $com_objectHierarchy_aref = shift @args;

    my $object;

    # STEP error if not at least one object passed
    my $nbrObjHierarchy = scalar @$com_objectHierarchy_aref;
    if ( $nbrObjHierarchy < 1 ) {
        Write_Error_Text( "Invalid params ! atleast one COM object is expected.)", ERR_INVALID_PARAMETERS );
        return;
    }

    # STEP find the required object
    my $firstObject = 1;
    foreach my $com_objects (@$com_objectHierarchy_aref) {

        # for first COM object in Object hierarchy
        if ($firstObject) {
            $object      = $oleHandle->$com_objects;
            $firstObject = 0;
            return $object if ( $nbrObjHierarchy == 1 );
        }

        # for rest of the objects
        $object = $object->$com_objects;
    }
    S_get_LastError_OLE();
    return $object;
}

=head2 CallCOM_Method

    $status = CallCOM_Method ( $oleHandle_mix, $objectHierarchy_aref, $methodName [, $methodArgs_aref])

Invokes the COM method which was specified via object hierarchy.

B<Arguments:>

=over

=item $oleHandle_mix 

OLE handle of CANoe

=item $objectHierarchy_aref 

Object hierarcy like [ 'Application', 'Environment' ]

=item $methodName  

Method name to be invoked.

=item $methodArgs_aref (optional)  

Method arguments that should be passed.

=back  

B<Examples:>

    # invode method 'Start', no arguments
    CallCOM_Method( $ole_handle, ['Measurement'], 'Start' ); 
    
    # Invoke method 'Running' and get the status (if running or not) 
    $status = CallCOM_Method( $ole_handle, ['Measurement'], 'Running' );
    
    # Call method GetVariable with argument '$env_var_name'
    my $env_var_handle = CallCOM_Method( $ole_handle, [ 'Application', 'Environment' ], 'GetVariable', [$env_var_name] );
      
=cut

sub CallCOM_Method {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CallCOM_Method ( $oleHandle_mix, $objectHierarchy_aref, $methodName [, $methodArgs_aref])', @args );
    my $oleHandle                = shift @args;
    my $com_objectHierarchy_aref = shift @args;
    my $methodName               = shift @args;
    my $methodArgs_aref          = shift @args;

    my $object = GetCOM_Object( $oleHandle, $com_objectHierarchy_aref ) || return;
    my $status;

    if ( defined $methodArgs_aref ) {
        $status = $object->$methodName( @{$methodArgs_aref} );    # $status = $object->$methodName( $methodArgs_aref ); # didn't work
    }
    else {
        $status = $object->$methodName();
    }

    return $status;
}

=head2 GetCOM_objProperty

    $propertyValue = GetCOM_objProperty($oleHandle_mix, $objectHierarchy_aref, $property);

Gets the COM object property value from the object hierarchy.

B<Arguments:>

=over

=item $oleHandle_mix 

OLE handle of CANoe

=item $objectHierarchy_aref 

Object hierarcy like [ 'Application', 'Version' ]

=item $property  

Property name

=back    

B<Examples:>

    $cantool_version = GetCOM_objProperty( $ole_handle, [ 'Application', 'Version' ], 'FullName' );
    $loaded_cfg_fullName = GetCOM_objProperty( $ole_handle, [ 'Application', 'Configuration' ], 'FullName' );  

=cut

sub GetCOM_objProperty {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetCOM_objProperty ( $oleHandle_mix, $objectHierarchy_aref, $property)', @args );
    my $oleHandle                = shift @args;
    my $com_objectHierarchy_aref = shift @args;
    my $property                 = shift @args;

    my $propertyValue;
    my $object = GetCOM_Object( $oleHandle, $com_objectHierarchy_aref ) || return;
    $propertyValue = $object->{$property};

    return $propertyValue;
}

=head2 SetCOM_Property

    SetCOM_Property($oleHandle_mix, $objectHierarchy_aref, $property, $propertyValue);

Sets the COM object (retrive by $objectHierarchy_aref) '$property' to the value '$propertyValue'.

B<Arguments:>

=over

=item $oleHandle_mix 

OLE handle of CANoe

=item $objectHierarchy_aref 

Object hierarcy like [ 'Application', 'Version' ]

=item $property  

Property name

=item $propertyValue  

Property value to set.

=back    

B<Examples:>

    SetCOM_Property( $ole_handle, ['Application'], 'Visible', 1 );

=cut

sub SetCOM_Property {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SetCOM_Property ( $oleHandle_mix, $objectHierarchy_aref, $property, $propertyValue)', @args );
    my $oleHandle                = shift @args;
    my $com_objectHierarchy_aref = shift @args;
    my $property                 = shift @args;
    my $propertyValue            = shift @args;

    my $object = GetCOM_Object( $oleHandle, $com_objectHierarchy_aref ) || return;
    $object->{$property} = $propertyValue;
    return 1;
}

=head2 GetObjProperty

    $propertyValue = GetObjProperty ($object_mix, $property);

retrieves directly the value of COM '$property' from the object '$object_mix'.    

B<Examples:>

    my $raw_value = GetObjProperty( $signal_object, 'RawValue' );

=cut

sub GetObjProperty {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetObjProperty ($object_mix, $property)', @args );
    my $object   = shift @args;
    my $property = shift @args;

    my $propertyValue;
    $propertyValue = $object->{$property};
    return $propertyValue;
}

=head2 SetObjProperty

    SetObjProperty ($object_mix, $property, $propertyValue);

Set directly the '$propertyValue' to COM '$property' of object '$object_mix'.

B<Examples:>

    SetObjProperty( $signal_object, 'RawValue', $signal_value_raw_to_wr );    
    
=cut

sub SetObjProperty {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SetObjProperty ($object_mix, $property, $propertyValue_mix)', @args );
    my $object        = shift @args;
    my $property      = shift @args;
    my $propertyValue = shift @args;

    $object->{$property} = $propertyValue;
    return 1;
}

=head2 CallObj_Method

    CallObj_Method ($object_mix, $methodName, [, $methodArgs_aref]);

Invokes the Object method, $methodArgs_aref are optional .

B<Examples:>

    my $type = CallObj_Method( $h_sys_var_obj, 'Type' );        
    
=cut

sub CallObj_Method {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CallObj_Method ( $object_mix, $methodName [, $methodArgs_aref])', @args );
    my $object          = shift @args;
    my $methodName      = shift @args;
    my $methodArgs_aref = shift @args;
    my $status;

    # Invoke the method
    if ( defined $methodArgs_aref ) {
        $status = $object->$methodName( @{$methodArgs_aref} );
    }
    else {
        $status = $object->$methodName();
    }
    return $status;
}

=head1 Helper functions 

=head2 Get_deviceType

    $deviceType = Get_deviceType ( $ole_handle_mix )
    
Gets the device type 'CANoe'.    

=cut

sub Get_deviceType {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Get_deviceType ( $ole_handle_mix )', @args );
    my $ole_handle = shift @args;

    return 'CANoe' if $main::opt_offline or $main::opt_simulation;

    my $deviceType;
    unless ( $deviceType = $CANoe_dev_control_href->{$ole_handle}{'DeviceType'} ) {
        Write_Error_Text( "Could not get DeviceType for OLE_Handle - $ole_handle", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    return $deviceType;
}

=head2 Get_hostName

    $hostname = Get_hostName ( $ole_handle_mix )

Gets the hostname.     
For offline and simulation it returns 'localhost'. 

=cut

sub Get_hostName {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Get_hostName ( $ole_handle_mix )', @args );
    my $ole_handle = shift @args;

    return 'localhost' if $main::opt_offline or $main::opt_simulation;

    my $hostname;
    unless ( $hostname = $CANoe_dev_control_href->{$ole_handle}{'Hostname'} ) {
        Write_Error_Text( "Could not get Hostname for OLE_Handle - $ole_handle", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    return $hostname;
}

=head2 Get_oleHandle

    $ole_handle = Get_oleHandle();

Returns the OLE handle for the CANoe application.    
    
=cut

sub Get_oleHandle {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Get_oleHandle ()', @args );

    return 1 if $main::opt_offline;

    my $ole_handle;
    unless ( $ole_handle = $CANoe_dev_control_href->{'OLE_handle'} ) {
        Write_Error_Text( "OLE handle was not defined for CANoe ", ERR_OLE_INIT_CANOE );
        return;
    }
    return $ole_handle;
}

=head2 Write_Log_Text

    Write_Log_Text($errorText, $errorCodeNbr);

It write the log text to the log file and it appends the B<calling function name> before the text message.    

=cut

sub Write_Log_Text {
    my $text     = shift;
    my $logLevel = shift;

    $logLevel = WRLOG_LEVEL_4 if not defined $logLevel;

    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }
    S_w2log( $logLevel, " $callingFunction : $text \n", 'grey' );
    return 1;
}

=head2 Write_Error_Text

    Write_Error_Text($errorText, $errorCodeNbr);

It write the error message to the log file. and it appends the B<calling function name> before the error message.    

=cut

sub Write_Error_Text {
    my $errorText    = shift;
    my $errorCodeNbr = shift;

    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }
    S_set_error( " $callingFunction :  $errorText \n", $errorCodeNbr );
    return 1;
}

=head2 GetFileHandle

    GetFileHandle($file_path);

Get the file handle of the trace file '$file_path' after opening it.    

=cut

sub GetFileHandle {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetFileHandle ($file_path)', @args );

    my $file_path = shift @args;

    my $fileHandle = FileHandle->new();
    unless ( $fileHandle->open($file_path) ) {
        Write_Error_Text( "Couldnt open CANoe trace '$file_path'", ERR_VECTOR_CANOE_CONFIGURATION );
        return;
    }
    return $fileHandle;
}

=head2 CANoe_Write_EnvOrSysVar

    $status = CANoe_Write_EnvOrSysVar( $sysOrEnv_var , $value );

Writes the System/Environment variable '$sysOrEnv_var' with the provided value '$value'.

B<Arguments:>

=over

=item $sysOrEnv_var 

Name of the System/Environment variable

=item $value 

Value to be written to the System/Environment variable

=back

B<Return value:>

=over

=item $status 

status of the Set opeartion

Return 1 if the value is successfully set to the System/Environment variable

=back    

B<Examples:>

     $status = CANoe_Write_EnvOrSysVar( 'LIFT_NET_access::SysVar', 255 );   #System variable
     $status = CANoe_Write_EnvOrSysVar( 'Env_Var', 10 );                    #Environment variable
     
Internally calls L</"CANoe_set_sysVar_value"> and L</"CANoe_set_envVar_value">

=cut

sub CANoe_Write_EnvOrSysVar {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoe_Write_EnvOrSysVar ( $sysOrEnv_var, $value )', @args );

    my $sysOrEnv_var = shift @args;
    my $value        = shift @args;

    # STEP Get the System or Env variable and the value to be written
    # IF Variable contains '::'?
    #   IF-YES-START
    #       STEP It is a System variable
    #       STEP Set the System variable with the provided value
    #       CALL CANoe_set_sysVar_value
    #   IF-YES-END
    #   IF-NO-START
    #       STEP It is an Environment variable
    #       STEP Set the Environment variable with the provided value
    #       CALL CANoe_set_envVar_value
    #   IF-NO-END
    # STEP End
    my $status;
    if ( $sysOrEnv_var =~ /::/ ) {

        #System variable
        Write_Log_Text("Writing value '$value' to System variable '$sysOrEnv_var'");
        $status = CANoe_set_sysVar_value( $sysOrEnv_var, $value );
    }
    else {
        #Environment variable
        Write_Log_Text("Writing value '$value' to Environment variable '$sysOrEnv_var'");
        $status = CANoe_set_envVar_value( $sysOrEnv_var, $value );
    }
    return $status;
}

=head2 CANoe_check_InteractionLayer_used

    $returnValue = CANoe_check_InteractionLayer_used( );

It checks whether if the Interaction layer has been used or not for the RBS.

=cut

sub CANoe_check_InteractionLayer_used {

    my $flag_IL_used = 0;
    my $testbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );

    $flag_IL_used = 0 unless ( defined $testbench->{'Devices'}{'CANoe'}{'ILUsed'} );

    if ( $testbench->{'Devices'}{'CANoe'}{'ILUsed'} =~ /yes/i ) {
        $flag_IL_used = 1;
    }

    return $flag_IL_used;
}
1;

__END__


=head1 AUTHORS

Upendra Singh Rathore, E<lt>Upendra.Rathore@in.bosch.comE<gt>

=head1 NOTES

The "BEGIN" section contains the Statements which to be executed before the start of program execution

=head1 SEE ALSO

perl documentation

=cut
