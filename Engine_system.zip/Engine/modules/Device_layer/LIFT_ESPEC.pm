package LIFT_ESPEC;

use strict;
use warnings;

#Module used to implement COM communication
use Win32::SerialPort;
require Exporter;

#Turbolift specific modules
use LIFT_general;
use LIFT_simulation;

our @ISA    = qw(Exporter);
our @EXPORT = qw(
  ESPEC_connect
  ESPEC_getCurrentTemperature
  ESPEC_setTargetTemperature
  ESPEC_getTargetTemperature
  ESPEC_disconnect
);

our ( $VERSION, $HEADER );

my ( $COM, $com_port );

if ($main::opt_simulation) {
	no strict 'refs';

	# redefine functions for simulation mode with default return values
	foreach my $function ( 'Transmit_command', 'Receive_command' ) {

		# each function specifed is redefined using SIM_returnValues
		*{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
	}

	# define return values table (especially for default values) and pass it to simulation module
	my $returnValuesTable_href = {
		'Transmit_command' => { 'default' => [0] },
		'Receive_command'  => { 'default' => [ 0, undef ] },
	};
	SIM_addToValuesTable($returnValuesTable_href);
}

############################################################################################################

=HEAD 
LIFT_ESPEC.pm 

Perl extension for accessing ESPEC MC811 Oven and perform set and get temperature on that.

=head1 SYNOPSIS

 use LIFT_ESPEC;

 #Connect to Oven using COM
 ESPEC_connect();

 #set the target temperature to 30 Degree Celsius
 ESPEC_setTargetTemperature(30);
	
 #returns 30degree Celsius, Last set temperature of oven
 $target_temp = ESPEC_getTargetTemperature();
	
 #ex:25 degree Celsius, Current temperature of Oven
 $curr_temp = ESPEC_getCurrentTemperature();
 #Disconnect COM, Frees all COM objects
 ESPEC_disconnect();  

=head1 DESCRIPTION

 ESPEC is a company that provides environmental test chambers for quality assurance testing of products in temperature and humidity extremes

 MC811 is the type of Oven which covers wide range of Temperature testing needs, from ultra-low temperature of -85 Degree Celsius to +180 Degree Celsius.
	
 � In TurboLIFT Oven is accessed and programmed using COM communication.
	
 � Commands those are understood by oven are sent via COM interface.

 � COM will be connected to Oven using COM port.
	
 � Commands to be sent to Oven are written into the connected COM port
	
 � Data from oven will be read using the COM port.
	
	
=head2 Prerequisites

Commands that are understood by OVEN MC811:

B<TEMP? :>

 This command asks OVEN to return the various temperature of Oven.
 This returns something like: �31.2, 30.0, 180.0,-85.0 �

 Where,
 31.2 => Indicates the current temperature of Oven
 30.0 => Indicates the last set temperature of Oven
 180.0 => Maximum temperature capacity of Oven
 -85.0 => Minimum temperature capacity of Oven.


B<TEMP, S30.0 :>

 This command sets the temperature of Oven to 30 degree Celsius.

B<MODE, CONSTANT :>

 This commands sets the Oven in constant running mode.

=cut

=head2 Tutorial

Please refer below documentation to know more about ESPEC MC811.

=over 3

=item

=for html
<a href='http://www.seneco.it/prospetti/espec/compact_ultra_low.pdf'>ESPEC MC811</a>

=back

=cut

=head2 Testbench configuration

 'Devices' => {
  ... 
  'ESPEC' => {
    'connect' => 'COM1',
  },
  ...
 },
 
 Where COM1 is the port connected to Oven         

=cut

=head1 Exported Subroutines

=head2 ESPEC_connect

 $status = ESPEC_connect();
    
Connects the OVEN through configured COM port number.

Please refer configuration : L</"Testbench configuration">. 

B<Return Value:>

=over

=item $status 

 Indicates the Success/Failure of function

 1 - Connection Succeeded
 0 - Connection Failed

=back

B<Examples:>

 $status = ESPEC_connect();

=cut

############################################################################################################

sub ESPEC_connect {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'ESPEC_connect()', @args );

	if ($COM) {
		S_set_warning("LIFT_ESPEC::ESPEC_connect - COM is already initialized");
		return 1;
	}

	#STEP Read COM port number from config
	$com_port = $LIFT_config::LIFT_Testbench->{'Devices'}{'ESPEC'}{'connect'};

	unless ( $com_port =~ /^COM\d+$/i ) {
		Write_error( "Error in COM configuration. Please specify the valid COM port in LIFT Testbench", 20 );
		return 0;
	}

	return 1 if ($main::opt_offline);

	#STEP Create COM object using the COM port
	$COM = Win32::SerialPort->new("$com_port");
	unless ($COM) {
		Write_error( "Can't connect through $com_port", 120 );
		return 0;
	}

	#STEP Set up all parameters for COM port
	$COM->error_msg(1);
	$COM->user_msg(1);
	$COM->baudrate(9600);
	$COM->parity('none');
	$COM->databits(8);
	$COM->stopbits(1);
	$COM->handshake('none');
	$COM->read_const_time(5000);    # total = (avg * bytes) + const => total timeout 5 sec
	$COM->read_interval(200);       # timeout between chars 0.2 sec
	$COM->binary('T');
	$COM->parity_enable('F');
	$COM->buffers( 1024, 1024 );

	#STEP write a new Device Control Block to the driver
	my $status = $COM->write_settings();
	unless ($status) {
		Write_error( "Error when configuring $com_port port", 120 );
		return 0;
	}

	#STEP Return 1 if nothing has failed
	return 1;
}

############################################################################################################

=head2 ESPEC_getCurrentTemperature

 $curr_temp_degC = ESPEC_getCurrentTemperature();
    
Returns the Current temperature of Oven in degree Celsius.

Allowed temperature of the Oven is from -85 - 180 Degree Celsius

B<Return Value:>

=over

=item $curr_temp_degC 

 Current temperature of OVEN

 Returns 0 in case of failure

=back

B<Examples:>

 $curr_temp_degC  = ESPEC_getCurrentTemperature();
 
 Returns the current temperature of the Oven in degree Celsius
 
=cut

############################################################################################################

sub ESPEC_getCurrentTemperature {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'ESPEC_getCurrentTemperature()', @args );

	return 10 if ($main::opt_offline);    #return dummy temperature

	#STEP Get the temperature data
	my $temperature_data = Get_temperature();

	unless ($temperature_data) {
		Write_error( "Failed to get temperature data", 10 );
		return 0;
	}

	#STEP Extract current temperature
	my ( $curr_temp_degC, $set_temp_degC, $max_temp_degC, $min_temp_degC ) = split( ',', $temperature_data );

	#STEP Return the current temperature
	return $curr_temp_degC;
}

############################################################################################################

=head2 ESPEC_setTargetTemperature

  $status = ESPEC_setTargetTemperature($temperature);
  
Sets the target temperature of the MC811 OVEN to $temperature degree celsius.

Please specify the temperature within the range from -85 to 180 Degree Celsius
	
Note: This function doesnt wait until the Oven has reached the target temperature.Only sends the command to Oven to set the target temperature.

B<Arguments:>

=over

=item $temperature

 Temperature of the OVEN to be set.Should be specified in Degree Celsius

=back

B<Return Value:>

=over

=item $status
 
 Indicates the Success/Failure of function

 1 - Successfully set the temperature of OVEN
 0 - Failed to set the temperature of OVEN

=back

B<Examples:>

 $status = ESPEC_setTargetTemperature(35);
	
 Sets the OVEN temperature to 35 Degree Celcius

=cut

############################################################################################################

sub ESPEC_setTargetTemperature {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'ESPEC_setTargetTemperature($target_temperature  [, $gradientNotSupported])', @args );

	#STEP Get the temperature
	my $target_temperature = shift @args;
	chomp($target_temperature);

    #STEP Handle unsupported gradient
	my $gradientNotSupported = shift @args;
    S_set_warning("Second argument (temperature gradient) is not supported by ESPEC and will be ignored.") if defined $gradientNotSupported;

	#STEP Validate the temperature
	unless ( $target_temperature =~ /^(\+|\-)?\d+(\.\d+)?$/ && $target_temperature < 180 && $target_temperature > -85 ) {
		Write_error( "Invalid temperature specified. Please specify temperature within the range -85 to 180!!", 20 );
		return 0;
	}

	my ( $status, $set_temperature );

	#STEP Prepare the Command to set the temperature of Oven
	$target_temperature = sprintf( "%2.1f", $target_temperature );
	my $cmd_to_set_temperature = "TEMP,S$target_temperature";
	return 1 if ($main::opt_offline);

	#STEP Transmit the command to Oven
	$status = Transmit_command($cmd_to_set_temperature);

	unless ($status) {
		Write_error( "Failed to set the temperature $target_temperature to Oven using $com_port!! ", 15 );
		return 0;
	}

	#STEP Check whether the Temperature is set properly
	( $status, $set_temperature ) = Receive_command();

	unless ( $status && $set_temperature =~ /OK:TEMP\,S$target_temperature/ ) {
		Write_error( "could not set target temperature:$target_temperature!! ", 15 );
		return 0;
	}

	#STEP set Oven to Constant Running Mode
	my $cmd_constant_mode = "MODE,CONSTANT";
	$status = Transmit_command($cmd_constant_mode);
	unless ($status) {
		Write_error( "Failed to set the Constant Running Mode in Oven using $com_port!! ", 15 );
		return 0;
	}

	#STEP check for Oven status
	( $status, $set_temperature ) = Receive_command();

	unless ( $status && $set_temperature =~ /OK:$cmd_constant_mode/ ) {
		Write_error( "Could not get the Oven status using $com_port!! ", 10 );
		return 0;
	}

	#STEP wait for 2 second. Required to reflect the set time in Oven
	S_wait_ms(2000);

	#STEP Return 1 if nothing has failed
	return 1;
}

############################################################################################################

=head2 ESPEC_getTargetTemperature

  $set_temp_degC = ESPEC_getTargetTemperature();
    
Returns the last set temperature of Oven in degree Celsius

Allowed temperature of the Oven is from -85 - 180 Degree Celsius

B<Return Value:>

=over

=item $set_temp_degC 
 Temperature of the OVEN to be set. In terms of Degree Celsius

 0 - Failed to get the temperature of OVEN

=back

B<Examples:>
 
 $set_temp_degC = ESPEC_getTargetTemperature();
    
 Returns the set temperature of oven, in terms of Degree Celsius


=cut

############################################################################################################

sub ESPEC_getTargetTemperature {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'ESPEC_getTargetTemperature( )', @args );

	return 10 if ($main::opt_offline);    #return dummy temperature

	#STEP Get the temperature data
	my $temperature_data = Get_temperature();

	unless ($temperature_data) {
		Write_error( "Failed to get temperature data", 10 );
		return 0;
	}

	##STEP Extract target temperature
	my ( $curr_temp_degC, $set_temp_degC, $max_temp_degC, $min_temp_degC ) = split( ',', $temperature_data );

	#STEP Return the Target temperature
	return $set_temp_degC;
}

############################################################################################################

=head2 ESPEC_disconnect

 ($status) = ESPEC_disconnect();
    
Disconnects from MC811 OVEN. Frees the COM object and Exits COM connection.

B<Return Value:>

=over

=item $status 

 Indicates the Success/Failure of function

 1 - Successfully Disconnected.
 0 - Failed to disconnect

=back

B<Examples:>

 $status = ESPEC_disconnect();
    
=cut

############################################################################################################

sub ESPEC_disconnect {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'ESPEC_disconnect()', @args );

	return 1 if ($main::opt_offline);

	#STEP Check if COM is initialized
	unless ($COM) {
		Write_error( "COM is not initialized!! ", 120 );
		return 0;
	}

	#STEP Exit the COM connection
	my $status = $COM->close;
	undef $COM;

	unless ($status) {
		Write_error( "Failed to diconnect COM!! ", 120 );
		return 0;
	}

	#STEP Return 1 if everything is fine
	return 1;
}

=head1 Non Exported Subroutines

=head2 Transmit_command

 $status = Transmit_command($command);

Transmits the specified $data to Oven using COM port.

B<Arguments:>

=over

=item $command

 Valid MC811 Oven command which is understandable by Oven 

=back

B<Return Value:>

=over

=item $status 

 $status - Indicates the Success/Failure of function

 1 - Transmission Succeeded
 0 - Transmission Failed

=back

B<Examples:>

 $status = Transmit_command('TEMP?');

 Transmits 'TEMP?' command to Oven

 'TEMP?' is the command which is used to get the temperature of in Oven

=cut

############################################################################################################
sub Transmit_command {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'Transmit_command($data)', @args );
	my $data = shift @args;

	#STEP Check if COM is initialized
	unless ($COM) {
		Write_error( "COM is not initialized!! ", 120 );
		return 0;
	}

	#STEP clear the COM buffer before sending
	$COM->purge_all;

	#STEP Write the command to COM port
	my $transmit_count = $COM->write( $data . chr(13) );    #char(13) is the carriage return . i.e \r

	unless ( defined $transmit_count ) {
		Write_error( "Writing to COM port:$com_port failed ", 15 );
		return 0;
	}
	if ( $transmit_count != length($data) + 1 ) {
		Write_error( "Writing to COM port:$com_port is Incomplete ", 15 );
		return 0;
	}

	#STEP return 1 if everything is fine
	return 1;
}

############################################################################################################

=head2 Receive_command

 ($status,$data) = Receive_command();
    
Receives the data from Oven using COM port.

B<Return Value:>

=over

=item $status 

 $status - Indicates the Success/Failure of function

 1 - Successfully Received data from Oven
 0 - Failed Receive data from Oven

=item $data 

 Data Received from Oven

=back

B<Examples:>

 ($status,$data) = Receive_command();

=cut

############################################################################################################
sub Receive_command {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'Receive_command()', @args );

	my $data;
	my $data_count = 0;

	#STEP Check if COM is initialized
	unless ($COM) {
		Write_error( "COM is not initialized!! ", 120 );
		return ( 0, undef );
	}

	#STEP Read 250 bytes of data
	( $data_count, $data ) = $COM->read(250);

	unless ( $data =~ /\r/ ) {
		Write_error( "Reading from COM port:$com_port failed : Receive Timeout!! ", 10 );
		return ( 0, undef );
	}

	$data =~ s/\r//g;     # drop all <Lf>
	$data =~ s/\x0//g;    # remove all nullstrings
	$data =~ s/\W+$//;    # drop all non-word characters at end
	chomp($data);

	#STEP Return received data
	return ( 1, $data );
}

=head2 Get_temperature

 $temperature_data = Get_temperature();
    
Returns the temperature data from Oven

B<Return Value:>

=over

=item $temperature_data 

 temperature data of Oven

 Return undef in case of failure 

=back

B<Examples:>

  (31.5,30,180.0,-85.0) = Get_temperature();

=cut

sub Get_temperature {
	my @args = @_;
	return unless S_checkFunctionArguments( 'Get_temperature()', @args );
	my ( $status, $temperature_data );

	#STEP Send "Read temperture Command" to Oven
	my $cmd_to_get_temperature = sprintf("TEMP?");

	$status = Transmit_command($cmd_to_get_temperature);
	unless ($status) {
		Write_error( "Failed to write command $cmd_to_get_temperature to $com_port!! ", 15 );
		return;
	}

	#STEP Read the temperature data from Oven
	( $status, $temperature_data ) = Receive_command();

	unless ( $status && defined $temperature_data ) {
		Write_error( "Failed to receive temperature data from $com_port!! ", 10 );
		return;
	}
 
	#STEP Return the temperature data
	return $temperature_data;
}

=head2 Write_error
 
 Write_error();
    
Helper function to write the Error using S_set_error

B<Arguments:>

=over

=item $error_text

 Text to be displayed as a error message to the use

=item $error_code

 Error code which specifies the category of error

=back

B<Examples:>

 Write_error( "Failed to receive temperature data from com_port!! ", 10 );

=cut

sub Write_error {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'Write_error ($error_text,$error_code)', @args );
	my $error_text = shift @args;
	my $error_code = shift @args;

	my $calling_func = ( caller 1 )[3];
	if ($calling_func) {
		S_set_error( "$calling_func - $error_text\n", $error_code );
	}
	return 1;
}

1;

__END__

=head1 AUTHORS

Pallavi M Prabhu, E<lt> PallaviMaruthi.Prabhu@in.bosch.com E<gt>


=head1 SEE ALSO

Perl documentation

=cut
