# *****************************************************************************************************
#
#  Copyright (c) 2014  Robert Bosch GmBH
#					  Germany
#					  All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_TOELLNER;

use strict;
use warnings;
use File::Basename;
use LIFT_general;
use LIFT_simulation;


#suppress 'Subroutine redefined' warning locally
local $SIG{__WARN__} = sub {
	my $warning = shift;
	warn $warning unless $warning =~ /Subroutine .* redefined at/;
};

BEGIN
{
	use LIFT_general;
	S_add_paths2INC(['./GPIB', './GPIB/GPIB', './GPIB/Win32'], []);
}

use GPIB;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_TOELLNER ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
	'all' => [
		qw(

		  )
	]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  TOE_connect
  TOE_disconnect
  TOE_setCurveFile
  TOE_setCurveRamp
  TOE_runCurve
  TOE_checkGPIBerror
  TOE_setCurveStart
  TOE_setCurveEnd
  TOE_initCurve
  TOE_startCurve
  TOE_stopCurve
  TOE_setExecute
  TOE_setExternalTrigger
  TOE_setStandby
  TOE_setRepetition
  TOE_setVoltage
  TOE_setCurrent
  TOE_setMode
  TOE_writeString
  TOE_writeStringOPC
  TOE_readString
  TOE_storePage
  TOE_recallPage
  TOE_isConnected
  TOE_saveCurveFile
  TOE_ON
  TOE_OFF
  TOE_VOLTAGE
  TOE_createRandomOnOffFile
  TOE_createGraph
  TOE_createRampGraph
  TOE_isCurveRunning
  TOE_initArbitrary
  TOE_isArbitrary

);

our ( $VERSION, $HEADER );

if ($main::opt_simulation)
{
	# redefine all functions for simulation mode with default return values
	foreach my $function (@EXPORT)
	{
		{
			no strict 'refs';

			# each function in @EXPORT is redefined using SIM_returnValues
			*{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); }
		}
	}

	# define return values table (especially for default values) and pass it to simulation module
	my $returnValuesTable_href = {};
	SIM_addToValuesTable($returnValuesTable_href);

}

=head1 NAME

LIFT_TOELLNER 

Perl extension for Toellner power supply TOE8805/TOE8815, TOE8871 and TOE8952

=head1 SYNOPSIS

	use LIFT_TOELLNER;

	my ($status, $DeviceID, $ErrorString);

	$DeviceID = TOE_connect('Ubat');
	$DeviceID = TOE_connect('Udisposal');

	TOE_VOLTAGE('Udisposal','U_BATT_DEFAULT');

	$duration = TOE_setCurveFile('Ubat',"test.sat");
	$duration = TOE_setCurveRamp('Ubat',12.6,3.8,3600);
	$string = TOE_readString('Ubat');
	$value = TOE_isConnected('Ubat');
	$value = TOE_isCurveRunning('Ubat');

	TOE_runCurve('Ubat');
	TOE_ON('Ubat');
	TOE_OFF('Ubat');
	TOE_ON('Udisposal');

	TOE_initCurve('Ubat');
	TOE_setExecute('Ubat');
	TOE_startCurve('Ubat');
	TOE_stopCurve('Ubat');
	TOE_setStandby('Ubat');
	TOE_checkError('Ubat');

	TOE_setMode('Ubat',3);
	TOE_setMode('Ubat',0);
	TOE_createRandomOnOffFile('Ubat',"test.sat", 3000, 2000, 700, 500, 12.5, 10.8, 60);
	TOE_VOLTAGE('Ubat','U_BATT_DEFAULT');
	TOE_setCurveStart('Ubat'2);
	TOE_setCurveEnd('Ubat',19);
	TOE_setRepetition('Ubat',4);
	$pic = TOE_createGraph('Ubat',"test.txt",0,'U_BATT_OVERVOLTAGE');
	$pic = TOE_createRampGraph('Ubat',"test.txt",[0,1.2,2],[3,5.2,12],0,'U_BATT_OVERVOLTAGE');

	TOE_setVoltage('Ubat',12.5);
	TOE_setCurrent('Ubat',2.5);
	TOE_saveCurveFile('Ubat',"test.txt",0,23);
	TOE_writeString('Ubat',"*IDN?");

	TOE_storePage('Ubat',3);
	TOE_recallPage('Ubat',2);

	TOE_disconnect('Ubat');
	TOE_disconnect('Udisposal');

=head1 CONFIGURATION

B<LIFT_testbenches.pm>

	'Devices' => {
		'TOELLNER' => {
				'UF'		=> { 'gpib' => 8, 'interface' => 1, 'device' => 'TOE8871' },
				'Ubat'	    => { 'gpib' => 3, 'interface' => 0 },
				'Udisposal' => { 'gpib' => 21 },
				'U2'		=> { 'gpib' => 23 }, # a rock band ?
		},
	},

	'gpib' is the GPIB address
	'interface' is usually 0 for first interface, default is 0
	'device' will be used only in offline mode to create virtual device, default is TOE8815

	default GPIB addresses (taken from testprog)
	02: Toellner TOE8815
	20: TOE8852_1 / TOE8952_1
	21: TOE8852_1 / TOE8952_2
	23: Toellner TOE8871

You need to set 'interface' only if you have more than one GPIB hardware connected to your PC.
Just use the same settings as you can see in NI-MAX if you 'scan for instruments'.
In NI-MAX go to 'devices and interfaces', select you interface e.g. 'GPIB0' on the left side,
select 'scan for instruments', now you should see all connected devices.

To read out the GPIB address at the device please refer to the device manual (it is different and depends on the device)

=head1 DESCRIPTION

Remote control functions for TOE8805/TOE8815, TOE8871 and TOE8952 using GPIB.pm via USB or PCI GPIB interface

You may cotrol several power supplies in parallel, differentiation is done by name. Any name is possible but 
it is recommended to use names which reflect the functionality. 'Marvin' or 'U2' are not really helpful.

B<NOTE: National Instruments driver for GPIB has to be installed !>

B<KNOWN ISSUE: TOE8805 does not work with PCI card interface, use USB GPIB interface for TOE8805 to avoid communication problems !>

If you have PCI and USB interface connected, set 'GPIB_device' in testbench config accordingly (usually 1 for 2nd interface, cross-check with NI-MAX)

=cut

my $TOE_struct;
my $TOE_handle;

# todo: check if required to build structure per device for $MAXdeviceAMP, $MAXdeviceVOLT
my $MAXdeviceAMP   = 4;
my $MAXdeviceVOLT  = 32;
my $MINdeviceDELAY = 0.0002; # minimum Arbitrary delay time in seconds
my $MAXdeviceDELAY = 100.0;  # maximum Arbitrary delay time in seconds


#todo check if obsolete
#Help Variables
my ( $status, $DeviceID,  );

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 TOE_connect

	$DeviceID = TOE_connect( $name );

		e.g. $DeviceID = TOE_connect(); # will throw error
			 $DeviceID = TOE_connect( 'UF' );
			 $DeviceID = TOE_connect( 'Ubat' );

Connnect to Toellner via given connection. If no connection details given, data is taken from Testbenchconfig.
Reads device identification (*IDN). This method has to be called first before any other method can be used.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

Make sure Toellner is configured accordingly !

Returns Device ID , on error: empty string, offline return: 'dummy'

=cut

sub TOE_connect
{

	my $name = shift;
	my $error_ret = '';

	# here too early to use check_name, therefore double implemented
	unless ( defined($name) )
	{
		S_set_error( "No power supply name given", 110 );
		return $error_ret;
	}

	my $config_href = $LIFT_config::LIFT_Testbench->{'Devices'}{'TOELLNER'}{$name};
	unless ($config_href)
	{
		S_set_error( "No connection settings for Toellner '$name' in testbench config found", 20 );
		return $error_ret;
	}

	my $connection = $config_href->{'gpib'};
	my $gpibDevice = $config_href->{'interface'};
	my $offline_device = $config_href->{'device'};

	unless ( defined($connection) )
	{
			S_set_error( "no 'gpib' address given for Toellner '$name' in testbench config", 20 );
			return $error_ret;
	}
	unless ( defined($gpibDevice) )
	{
			S_w2log( 5, "no 'interface' given in testbench config for Toellner '$name' taking default 0\n" );
			$gpibDevice = 0;
	}

	S_w2log( 4, "TOE_connect( '$name' ) : Establishing the connection to ADDR $connection on Interface $gpibDevice ... \n" );

	if ($main::opt_offline){
		if (defined ($offline_device)){
			$DeviceID = $offline_device;
			S_w2log( 5, "offline mode uses given virtual Toellner $DeviceID\n" );
		}
		else{
			$DeviceID = 'TOE8815';
			S_w2log( 5, "offline mode uses DEFAULT virtual Toellner $DeviceID\n" );
		}
		$TOE_struct->{$name}{'handle'}          = 'offline';
		$TOE_struct->{$name}{'is_connected'}    = 1;
		$TOE_struct->{$name}{'IDN'}             = $DeviceID;
		$TOE_struct->{$name}{'is_multichannel'} = 0;
		$TOE_struct->{$name}{'is_arbitrary'}    = 0;
		$TOE_struct->{$name}{'channel'}         = 0;
	}
	else{
		#create new GPIB handle
		S_w2log( 5, "creating new TOELLNER instance for '$name'\n" );

		$TOE_handle = GPIB->new( "GPIB::ni", $gpibDevice, $connection, 0, GPIB->T3s, 1, 0 ); #USB and PCI
		unless ( defined($TOE_handle) ) {
			S_set_error( "GPIB object could not be created for '$name'", 21 );
			return $error_ret;
		}

		unless ( $TOE_handle->devicePresent ) {
			S_set_error( "device '$name' is not present on GPIB bus", 21 );
			return $error_ret;
		}
		$TOE_struct->{$name}{'handle'}       = $TOE_handle;
		$TOE_struct->{$name}{'is_connected'} = 0;

		$TOE_handle = $TOE_struct->{$name}{'handle'};
		$TOE_handle->ibonl(1);
		$TOE_struct->{$name}{'is_connected'} = 1;

		# stop curve will only work for arbitrary but is required to get IDN.
		$TOE_handle->ibwrt("FP");
		S_wait_ms(200);

		$TOE_handle->ibwrt("*CLS");
		S_wait_ms(200);
		$TOE_handle->ibclr();
		S_wait_ms(200);
		$TOE_handle->ibwrt("*IDN?");
		S_wait_ms(100);
		$DeviceID = TOE_readString( $name );

		if ($DeviceID) {
			chomp($DeviceID);
			$TOE_handle->ibwrt("*ESE 0");
			$TOE_handle->ibwrt("*SRE 0");
			$TOE_handle->ibwrt("*CLS");
			$TOE_struct->{$name}{'IDN'} = $DeviceID;
			$TOE_struct->{$name}{'is_multichannel'} = 0;
			$TOE_struct->{$name}{'is_arbitrary'}    = 0;
			$TOE_struct->{$name}{'channel'}         = 0;
			S_w2log( 5, "connected '$name' to '$DeviceID'\n" );
		}
		else {
			$TOE_struct->{$name}{'is_connected'} = 0;
			$TOE_struct->{$name}{'IDN'} = 'unknown';
			S_set_error( "Device ID cannot be read from '$name'", 21 );
			return $error_ret;
		}
	}

	if ( $DeviceID =~ /TOE8952/i ) {
		$TOE_struct->{$name}{'is_multichannel'} = 1;
		$TOE_struct->{$name}{'channel'}         = 1;
		S_w2log( 5, "Toellner '$name' is multichannel device\n" );
	}
	$TOE_struct->{$name}{'is_arbitrary'} = 1 if ( $DeviceID =~ /TOE8815/i );
	$TOE_struct->{$name}{'is_arbitrary'} = 1 if ( $DeviceID =~ /TOE8805/i );

	unless ( TOE_isArbitrary( $name ) ) {
		S_w2log( 5, "Toellner '$name' is non arbitrary device\n" );
		TOE_writeString( $name, "SYSTem:LANGuage COMPatibility" ) or return $error_ret;
		S_wait_ms(200);
	}


	S_w2log( 4, "TOE_connect: Connection with device '$name' ($DeviceID) was successful! \n" );
	return $DeviceID;
}

############################################################################################################

=head2 TOE_disconnect

	TOE_disconnect( $name );

Disconnect from Toellner


=cut

sub TOE_disconnect
{
	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;

	my $idn = $TOE_struct->{$name}{'IDN'};
	$TOE_struct->{$name}{'is_connected'} = 0;
	unless ($main::opt_offline){
		$TOE_handle = $TOE_struct->{$name}{'handle'};
		$TOE_handle->ibonl(0);
	}

	S_w2log( 5, "TOE_disconnect: Terminated the connection with device '$name' ($DeviceID) \n" );

	return 1;
}

############################################################################################################

=head2 TOE_setCurveFile

	$duration = TOE_setCurveFile( $name, $file );
	e.g. $duration = TOE_setCurveFile( 'Ubat', "test.sat" );

load curve from file and transmit to Toellner.

Returns duration, on error 0

=cut

sub TOE_setCurveFile
{
	my $name = shift;
	my $file = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	unless ( defined($file) )
	{
		S_set_error( " SYNTAX: duration = TOE_setCurveFile(file);", 110 );
		return $error_ret;
	}

	unless ( -f $file )
	{
		S_set_error( "TOE_setCurveFile, could not access $file", 1 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setCurveFile: To load the curve from file: $file.... \n " );

	if ( TOE_isCurveRunning( $name ) ) {
		TOE_stopCurve( $name ) or return $error_ret;
	}
	my ( $line, @volts, @time, $Amps, $repeat, $count, $duration, $timebuffer_ms );
	$Amps          = 5;
	$repeat        = 1;
	$duration      = 0;
	$timebuffer_ms = 0;
	@volts         = @time = ();

	if ( open( IN, "<$file" ) ) {
		while ( $line = <IN> ) {
			$line =~ s/,/./g;    # replace all commas with dots (convert to float)
			if    ( $line =~ /^(Strombegrenzung|Current Limitations)\s*:\s*(\S+)/ ) { $Amps   = $2 }
			elsif ( $line =~ /^(Wiederholungen|Repetitions)\s*:\s*(\S+)/ )          { $repeat = $2 }
			elsif ( $line =~ /^\s*([\d.]+)\s+([\d.]+)/ ) {
				push( @volts, $1 );
				push( @time,  $2 );
				$duration += $2;
			}
		}
		#close file
		close(IN);
	}
	else {
		S_set_error( "TOE_setCurveFile, could not open input file $file", 1 );
		return $error_ret;
	}

	if ( scalar(@volts) < 1 ) {
		S_set_error( "TOE_setCurveFile, input file $file has no data", 114 );
		return $error_ret;
	}

	if ( scalar(@volts) > 1000 ) {
		S_set_error( "TOE_setCurveFile, input file $file has too many points (>1000)", 114 );
		return $error_ret;
	}

	#chek values from file, add error message later
	$repeat = 1             if ( $repeat < 0 or $repeat > 255 );
	$Amps   = $MAXdeviceAMP if ( $Amps < 0   or $Amps > $MAXdeviceAMP );

	$duration *= 1000;
	$duration += $timebuffer_ms;
	$duration *= $repeat;

	for ( $count = 0 ; $count < @volts ; $count++ ) {
		S_w2log(5,"->FDS $count,$volts[$count],$Amps,$time[$count] \n");
		TOE_writeStringOPC( $name, "FDS $count,$volts[$count],$Amps,$time[$count];*OPC?" ) or return $error_ret;

	}

	TOE_setCurveStart( $name, 0 ) or return $error_ret;
	TOE_setCurveEnd( $name, $count - 1 ) or return $error_ret;
	TOE_setRepetition( $name, $repeat ) or return $error_ret;

	S_w2log( 3, "TOE_setCurveFile: Loaded the curve from file $file for the duration of $duration. \n" );
	return $duration;
}

############################################################################################################

=head2 TOE_initArbitrary

	$duration = TOE_initArbitrary( $name, $samples, $iteration, $arbitrary_time_aref, $arbitrary_voltage_aref, $current );
	e.g. $duration = TOE_initArbitrary( 'Ubat', 4, 1, ['0.050', '0.050', '0.100', '0.100'], ['0.000', '13.500', '0.000', '13.500'], 1 );

initialize the necessary parameters for execution of arbitrary curve.

Input arguments :

	$samples - Samples available in sat file
	$iteration - Iteration value available in sat file
	$arbitrary_time_aref - Array reference of time values
	$arbitrary_voltage_aref - Array reference of voltage values
	$current - Value of Current in sat file 

Returns duration on success or 0 on error

=cut

sub TOE_initArbitrary
{
	my $name                    = shift;
	my $samples                 = shift;
	my $iteration               = shift;
	my $arbitrary_time_aref     = shift;
	my $arbitrary_voltage_aref  = shift;
	my $current                 = shift;
	my $error_ret = 0;


	unless ( defined($samples)
		and defined($iteration)
		and defined($arbitrary_time_aref)
		and defined($arbitrary_voltage_aref)
		and defined($current) and defined($name))
	{
		S_set_error( "SYNTAX: duration = TOE_initArbitrary( name, samples, iteration, arbitrary_time_aref, arbitrary_voltage_aref, current )",110 );
		return $error_ret;
	}

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	#1,2,3 ...
	unless ( $iteration =~ /^\d+$/ )
	{
		S_set_error( "Iteration ($iteration) should be numeric ", 114 );
		return $error_ret;
	}

	unless ( ref($arbitrary_time_aref) eq 'ARRAY' )
	{
		S_set_error( "Time value is not an array", 114 );
		return $error_ret;
	}
	my $time_aref_count = scalar(@$arbitrary_time_aref);
	if ( $time_aref_count == 0 )
	{
		S_set_error( "Time value is an empty", 114 );
		return $error_ret;
	}

	unless ( ref($arbitrary_voltage_aref) eq 'ARRAY' )
	{
		S_set_error( "Voltage value is not an array", 114 );
		return $error_ret;
	}
	my $voltage_aref_count = scalar(@$arbitrary_voltage_aref);
	if ( $voltage_aref_count == 0 )
	{
		S_set_error( "Voltage value is an empty", 114 );
		return $error_ret;
	}

	# check if there are more than 1000 sample points
	if ( $samples > 1000 )
	{
		S_set_error( "TOE_initArbitrary: Curve contains $samples samples, too many points\n ", 114 );
		return $error_ret;
	}

	# limit the repetition count
	$iteration = 1 if ( $iteration < 0 or $iteration > 255 );

	my $skipCnt = 0;

	#todo:
	#bm7zsi: I guess this does not work properly since the array is modified while looping over it
	# remove any time points which are of value dt=0.0
	for ( my $count = 0 ; $count < @$arbitrary_time_aref ; $count++ )
	{
		if ( $$arbitrary_time_aref[$count] == 0.0 )
		{
			$skipCnt++;
			splice @$arbitrary_time_aref, $count, 1; # remove the contents
			splice @$arbitrary_voltage_aref, $count, 1;
			next;
		}
	}

	if ($skipCnt)
	{
		S_w2log( 5, "TOE_initArbitrary : Points with dt=0.0 detected and their count is $skipCnt\n" );
		$samples = $samples - $skipCnt;
	}

	# re arrange the voltage & time samples, since toellner stays at the first curve point
	my $last_time = pop(@$arbitrary_time_aref); # move the last value to the first
	unshift( @$arbitrary_time_aref, $last_time );
	my $last_volt = pop(@$arbitrary_voltage_aref); # move the last value to the first
	unshift( @$arbitrary_voltage_aref, $last_volt );

	S_w2log( 5, "TOE_initArbitrary: Initialize the arbitrary for execution... \n" );

	if ( TOE_isCurveRunning( $name ) ) {
		TOE_stopCurve( $name ) or return $error_ret;
	}

	my $count    = 0;
	my $duration = 0;    # duration of curve
	S_w2log(5,"initArbitrary($samples, $iteration, $arbitrary_time_aref, $arbitrary_voltage_aref, $current) on $name \n");

	# hardware related validations
	$current = $MAXdeviceAMP if ( $current < 0 or $current > $MAXdeviceAMP );    # limit the current
	                                                                             # limit the time delay
	foreach my $time (@$arbitrary_time_aref) {
		$time = $MINdeviceDELAY if ( $time < $MINdeviceDELAY );
		$time = $MAXdeviceDELAY if ( $time > $MAXdeviceDELAY );
		$duration += $time;
	}
	$duration *= $iteration if ( $iteration > 0 );

	for ( $count = 0 ; $count < $samples ; $count++ ) {
#		S_w2log(5,"->FDS $count,$$arbitrary_voltage_aref[$count],$current,$$arbitrary_time_aref[$count] \n");
		TOE_writeStringOPC( $name, "FDS $count,$$arbitrary_voltage_aref[$count],$current,$$arbitrary_time_aref[$count];*OPC?" ) or return $error_ret;
	}

	TOE_setCurveStart( $name, 0 ) or return $error_ret;
	TOE_setCurveEnd( $name, $count - 1 ) or return $error_ret;
	TOE_setRepetition( $name, $iteration ) or return $error_ret;

	S_w2log( 5, "TOE_initArbitrary: Now arbitrary curve data is ready for execution. Duration of curve is $duration \n" );
	return $duration;
}

############################################################################################################

=head2 TOE_setCurveRamp

	$duration = TOE_setCurveRamp( $name, $startV, $endV, $time, [ $start, $end ] );
	e.g. $duration = TOE_setCurveRamp( 'Ubat', 12.6, 3.8, 3600 );

create a linear ramp in curve memory from $startV volts to $endV volts and overall duration $time milliseconds.

If no start/end is given, the full range will taken and curve start and curve end will be set automatically.

$time must be between 200 ms and 100000000 ms (~27.7 h) for full range.

The Time stepwidth has to be between 0.2 ms and 100 seconds.

Returns duration on success, on error 1

=cut

sub TOE_setCurveRamp
{
	my $name   = shift;
	my $startV = shift;
	my $endV   = shift;
	my $time   = shift;
	my $start  = shift;
	my $end    = shift;
	my $error_ret = 0;

	$start = 0   unless ( defined $start );
	$end   = 999 unless ( defined $end );

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	unless ( defined($time) )
	{
		S_set_error( "SYNTAX: duration = TOE_setCurveRamp(name,Vstart,Vend,Time,[start,end]);", 110 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setCurveRamp($startV,$endV,$time,[$start,$end]) \n" );

	if ( $start >= $end )
	{
		S_set_error( "start ($start) >= end ($end)", 114 );
		return $error_ret;
	}
	if ( $start > 998 ) {
		S_set_error( "start > 998 ($start>998)", 114 );
		return $error_ret;
	}
	if ( $end > 999 ) {
		S_set_error( "end > 999 ($end>999)", 114 );
		return $error_ret;
	}



	my $waitforlinearwrite = 500;
	my $timestep           = 0;

	# ToDo use $MAXdeviceAMP to set current

	$timestep =  ( $time / ( ( $end - $start + 1 ) * 1000.0 ) );

	if ( $timestep > 100 ) {
		S_set_error( "timestep too big ($timestep > 100)", 114 );
		return $error_ret;
	}
	if ( $timestep < 0.0002 ) {
		S_set_error( "timestep too small ($timestep < 0.0002)", 114 );
		return $error_ret;
	}

	$timestep = sprintf "%3.4f", $timestep;

	S_w2log(5, "set_curve_ramp($startV,$endV,$time,$start,$end)\n");

	TOE_writeStringOPC( $name, "FDS $start,$startV,04.00,$timestep;*OPC?" ) or return $error_ret;
	TOE_writeStringOPC( $name, "FDS $end,$endV,04.00,$timestep;*OPC?" ) or return $error_ret;

	TOE_writeStringOPC( $name, "FCV $start,$end;*OPC?", $waitforlinearwrite ) or return $error_ret;
	TOE_writeStringOPC( $name, "FCT $start,$end;*OPC?", $waitforlinearwrite ) or return $error_ret;
	TOE_writeStringOPC( $name, "FCC $start,$end;*OPC?", $waitforlinearwrite ) or return $error_ret;

	S_w2log( 3, "TOE_setCurveRamp: Created linear ramp in curve memory for duration of $time \n" );
	return $time;
}

############################################################################################################

=head2 TOE_runCurve

	TOE_runCurve( $name [, $trigger] );

	$trigger = 0 or 1, default is 0

run curve from curve memory, setting all starting conditions.
if trigger is 1, it will be waiting for external trigger (on pin 12)

calls setExternalTrigger, setExecute, initCurve and startCurve.

voltage will stay on first curve value after curve is over


=cut

sub TOE_runCurve
{

	my $name = shift;
	my $trigger = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	$trigger = 0 unless (defined $trigger);

	S_w2log( 5, "TOE_runCurve: Init and executes the curve \n" );
		#parameter range check
	if ( ( $trigger < 0 ) || ( $trigger > 1 ) )
	{
		S_set_error( "trigger $trigger out of range (0<=x<=1)", 114 );
		return $error_ret;
	}

	TOE_setExternalTrigger( $name, $trigger ) or return $error_ret;
	TOE_setMode( $name, 3 ) or return $error_ret;
	TOE_setExecute( $name ) or return $error_ret;
	TOE_initCurve( $name ) or return $error_ret;
	TOE_startCurve( $name ) or return $error_ret;

	S_wait_ms(10);

	return 1;

}



############################################################################################################

=head2 TOE_createRandomOnOffFile

	TOE_createRandomOnOffFile( $filename, $ONmax, $ONmin, $OFFmax, $OFFmin, $Vmax, $Vmin, $MAXduration );
	e.g. TOE_createRandomOnOffFile("test.sat", 3000, 2000, 700, 500, 12500, 10800, 60);

create random voltage curve file (switching on and off at random voltage level for random time in given windows).

time $ONmax,$ONmin,$OFFmax,$OFFmin in msec, voltage $Vmax,$Vmin in mV and $MAXduration in seconds


=cut

sub TOE_createRandomOnOffFile
{

# todo: check if same format like for TSG4 can be used ... what about voltstep and timestep?
#		better to have generic createRandomLevelsFile ?  TOE_createRandomOnOffFile obsolete soon ?
	my $filename    = shift;
	my $ONmax       = shift;
	my $ONmin       = shift;
	my $OFFmax      = shift;
	my $OFFmin      = shift;
	my $Vmax        = shift;
	my $Vmin        = shift;
	my $MAXduration = shift;
	my $error_ret = 0;

	unless ( defined($MAXduration) )
	{
		S_set_error( "SYNTAX: TOE_createRandomOnOffFile(filename,ONmax,ONmin,OFFmax,OFFmin,Vmax,Vmin,MAXduration)", 110 );
		return $error_ret;
	}

	S_w2log( 3, "TOE_createRandomOnOffFile $filename\n  ON($ONmin - $ONmax) OFF($OFFmin - $OFFmax) V($Vmin - $Vmax) MAXduration $MAXduration\n" );

	my $save_dir = dirname($filename);

	unless ( -d $save_dir ) {
#		S_w2log(5,"creating directory $save_dir \n");
		unless ( mkdir($save_dir) ) {
			S_set_error( "could not create directory $save_dir",1 );
			return $error_ret;
		}
	}

	#avoid division of a not defined value
	$ONmax  = $ONmax / 1000;
	$ONmin  = $ONmin / 1000;
	$OFFmax = $OFFmax / 1000;
	$OFFmin = $OFFmin / 1000;
	$Vmax   = $Vmax / 1000;
	$Vmin   = $Vmin / 1000;

#	S_w2log(5,"creating random curve file $filename \n");
#	S_w2log(5,"ON($ONmin - $ONmax) OFF($OFFmin - $OFFmax) V($Vmin - $Vmax) MAXduration $MAXduration \n");

	my ( $points, $duration, $ONtime, $OFFtime, $volts );
	my @filecontent = ( "\n", "U[V]   t[s]\n" );

	$duration = 0;
	$points   = 0;

	while ( $duration < $MAXduration and $points <= 1000 ) {

		$ONtime  = rand( $ONmax - $ONmin ) + $ONmin;
		$OFFtime = rand( $OFFmax - $OFFmin ) + $OFFmin;
		$volts   = rand( $Vmax - $Vmin ) + $Vmin;

		$ONtime  = sprintf( "%6.3f", $ONtime );
		$OFFtime = sprintf( "%6.3f", $OFFtime );
		$volts   = sprintf( "%6.3f", $volts );

		push( @filecontent, " $volts $ONtime\n" );
		push( @filecontent, "  0.000 $OFFtime\n" );
		$points++;
		$duration += $ONtime + $OFFtime;
	}

	# put on top of file
	unshift( @filecontent, "Repetitions:         1\n" );
	unshift( @filecontent, "Current Limitations: 4.00\n" );
	unshift( @filecontent, "Points:              $points\n" );
	unshift( @filecontent, "Filename:            $filename\n" );

	#avoid error by open File
	if ( open( FILE, ">$filename" ) ) {
		print FILE @filecontent;
		close(FILE);
	}
	else {
		S_set_error( "could not create out file $filename",1 );
		return $error_ret;
	}

	# create file but return with error if 1000 points are exceeded
	if ( $points > 1000 ) {
		S_set_error( "parameter error, created too many points (> 1000) in $filename",109 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_createRandomOnOffFile done \n" );
	return 1;
}

############################################################################################################

=head2 TOE_createGraph

	$picfile = TOE_createGraph( $filename, [ $undervoltage, $overvoltage ] );
	e.g.
	$pic = TOE_createGraph("test.txt");	  # no thresholds
	$pic = TOE_createGraph("test.txt",5);	# only undervoltage
	$pic = TOE_createGraph("test.txt",0,'U_BATT_OVERVOLTAGE'); # only overvoltage with label

create a graph from curve file with the same filename. if > 0 under and overvoltage thresholds will be added to graph.
Will save picture as *.png and UNIVIEW file as *.txt.unv

Returns:name of created picture.  on error: empty string,   offline return: name of created picture


=cut

sub TOE_createGraph
{

	my $filename     = shift;
	my $undervoltage = shift;
	my $overvoltage  = shift;
	my ( $uValue, $oValue );
	my $error_ret = '';

	unless ( defined($filename) )
	{
		S_set_error( "SYNTAX: TOE_createGraph(filename, [undervoltage, overvoltage])", 110 );
		return $error_ret;
	}

	unless ( -f $filename )
	{
		S_set_error( "curve file $filename not found", 1 );
		return $error_ret;
	}

	$undervoltage = 0 unless ( defined $undervoltage );
	$overvoltage  = 0 unless ( defined $overvoltage );

	#map voltage if necessary
	unless ( defined( $uValue = $main::ProjectDefaults->{'VEHICLE'}{$undervoltage} ) )
	{
		$uValue = $undervoltage;
	}

	S_w2log( 5, "set undervoltage level to $undervoltage (V $uValue)\n" );

	unless ( defined( $oValue = $main::ProjectDefaults->{'VEHICLE'}{$overvoltage} ) )
	{
		$oValue = $overvoltage;
	}

	S_w2log( 5, "set overvoltage level to $overvoltage (V $oValue)\n" );

	$undervoltage = $uValue;
	$overvoltage  = $oValue;

	#place this message here, because undervoltage/overvoltage not defined
	S_w2log( 5, "TOE_createGraph: Creates a graph with undervoltage $uValue and Overvoltage $oValue \n" );

	my ( $line, @volts, @time, $uV_id, $oV_id );
	my @legend_keys   = ("battery voltage");
	my $locFileHelper = $filename;



	@volts = @time = ();
	my $duration = 0;

	if ( open( IN, "<$filename" ) ) {
		while ( $line = <IN> ) {
			if ( $line =~ /^\s*([\d.]+)\s+([\d.]+)/ ) {
				push( @volts, $1 );
				push( @time,  $2 );
				$duration += $2;
			}
		}
	}
	else {
		S_set_error( "could not open input file $filename",1 );
		return $error_ret;
	}

#	S_w2log(5, "creating graph from $filename \n");

	#create graph
	$filename =~ s/\.\w+$//;    # cut off file extension
	$filename =~ s/\//\\/g;     # replace all slashes with backslashes

	#delete files if existing
	unlink("$filename.txt.unv");
	unlink("$filename.png");

	my ( $i, $graph, @data, $element, $current_time );
	my ( $val, $dt, $last_time );

	#  my $step = 0.001;
	my ( $nbr_of_data_elements, $step );

	@data = ();

	$last_time = $current_time = 0;

	my @linestypes = (1);

	if ( $undervoltage > 0 ) { $uV_id = 2; push( @linestypes, 2 ); }
	else                     { $uV_id = 1; }
	if ( $overvoltage > 0 ) { $oV_id = $uV_id + 1; push( @linestypes, 2 ); }
	else                    { $oV_id = 1; }

	#avoid Error by empty file
	if ( @time != 0 ) {
		$nbr_of_data_elements = scalar(@time);
		$step                 = $duration / ( $nbr_of_data_elements * 100 );    # set plot stepwidth to 1/100 of the average time distance between 2 points
		$step                 = 0.001 if ( $step < 0.001 );                     # minimum clipping of stepwidth

		#	  S_w2log(5,"step $step  elem $nbr_of_data_elements end $time[-1]  $duration\n");

		# loop over all points
		for ( $i = 0 ; $i < @time ; $i++ ) {
			$val = $volts[$i];
			$dt  = $time[$i];
			while ( $current_time < ( $last_time + $dt ) ) {

				#  S_w2log(5,"time $current_time val $val\n");
				push( @{ $data[0] }, $current_time );
				push( @{ $data[1] }, $val );
				if ( $undervoltage > 0 ) { push( @{ $data[$uV_id] }, $undervoltage ); }
				if ( $overvoltage > 0 )  { push( @{ $data[$oV_id] }, $overvoltage ); }
				$current_time += $step;
			}
			push( @{ $data[0] }, $current_time );
			push( @{ $data[1] }, $val );
			if ( $undervoltage > 0 ) { push( @{ $data[$uV_id] }, $undervoltage ); }
			if ( $overvoltage > 0 )  { push( @{ $data[$oV_id] }, $overvoltage ); }
			$last_time = $current_time;
			$current_time += $step;

		}    #END for
	}
	else {
		S_set_error( "toe_createGraph: input file $locFileHelper is empty",109 );
		return $error_ret;
	}
	$graph = GD::Graph::lines->new( 800, 600 );

	$graph->set(
		x_label         => "time in s",
		y_label         => "voltage in V",
		title           => 'waveform',
		x_tick_number   => 'auto',
		r_margin        => 10,
		l_margin        => 10,
		b_margin        => 10,
		line_type_scale => 1,
		line_types      => \@linestypes,
	);

	$graph->set_legend_font( GD::Font->Large );
	if ( $undervoltage > 0 ) { push( @legend_keys, "undervoltage" ); }
	if ( $overvoltage > 0 )  { push( @legend_keys, "overvoltage" ); }

	$graph->set_legend(@legend_keys);

	close(IN);

	if ( open( OUT, ">$filename.txt.unv" ) ) {
		print OUT "TIME;VOLTAGE;\n";
		print OUT "s;volt;\n";
		$current_time = 0;
		for ( $i = 0 ; $i < @time ; $i++ ) {
			$current_time += $time[$i];
			print OUT "$current_time;$volts[$i];\n";
		}
		close(OUT);
	}
	else {
		S_set_error( "could not open out file $filename.txt.unv",1 );
		return $error_ret;
	}

	if ( open( PIC, ">$filename.png" ) ) {
		binmode PIC;
		print PIC $graph->plot( \@data )->png;
		close(PIC);
#		S_w2log(5, "saved graph as $filename.png \n");
	}
	else {
		S_set_error( "could not open out file $filename.png",1 );
		return $error_ret;
	}





	S_w2log( 5, "TOE_createGraph: Created a graph with name $filename.png \n" );
	return "$filename.png";

}

############################################################################################################

=head2 TOE_createRampGraph

	$picfile = TOE_createRampGraph( $filename, $rampStruct, [ $undervoltage, $overvoltage ] );
	e.g.
	$pic = TOE_createRampGraph("test.txt",[[0,1.2,100,0,499]]);											# no thresholds, single ramp
	$pic = TOE_createRampGraph("test.txt",[[0,1.2,100,0,499],[3,5.2,200,500,999]]);						# no thresholds
	$pic = TOE_createRampGraph("test.txt",[[0,1.2,100,0,499],[3,5.2,200,500,999]],5);						# only undervoltage
	$pic = TOE_createRampGraph("test.txt",[[0,1.2,100,0,499],[3,5.2,200,500,999]],0,'U_BATT_OVERVOLTAGE'); # only overvoltage with label

$rampStruct is an array reference containing array references:

$rampStruct = [
				[$startV_1, $endV_1, $time_1, $start_1, $end_1],
				[$startV_2, $endV_2, $time_2, $start_2, $end_2],
				;]

Time in milliseconds, Vstart/Vend in volts, start/end in samples. (start >= 000, end <= 999)

For a single ramp start/end can be omitted, then default will be 000/999

create a graph from arrays with given filename. if > 0 under and overvoltage thresholds will be added to graph.
Time delta between 2 poist hast to be between 0.2 ms and 100 s.
Will save picture as *.png and UNIVIEW file as *.txt.unv

Returns:name of created picture.  on error: empty string,   offline return: name of created picture


=cut

sub TOE_createRampGraph
{

	my $filename     = shift;
	my $rampAoA      = shift;
	my $undervoltage = shift;
	my $overvoltage  = shift;
	my ( $uValue, $oValue );
	my $error_ret = '';
	unless ( defined($rampAoA) )
	{
		S_set_error( "SYNTAX: TOE_createRampGraph(filename, RampStruct, [undervoltage, overvoltage])", 110 );
		return $error_ret;
	}

	# throw error on old structure
	if ( ref($rampAoA) ne "ARRAY" or ref( $$rampAoA[0] ) ne "ARRAY" )
	{
		S_set_error( " RampStruct is not an array reference containing array references", 114 );
		return $error_ret;
	}

	$undervoltage = 0 unless ( defined $undervoltage );
	$overvoltage  = 0 unless ( defined $overvoltage );

	#map voltage if necessary
	unless ( defined( $uValue = $main::ProjectDefaults->{'VEHICLE'}{$undervoltage} ) )
	{
		$uValue = $undervoltage;
	}
	S_w2log( 5, "set undervoltage level to $undervoltage (V $uValue)\n" );

	unless ( defined( $oValue = $main::ProjectDefaults->{'VEHICLE'}{$overvoltage} ) )
	{
		$oValue = $overvoltage;
	}
	S_w2log( 5, "set overvoltage level to $overvoltage (V $oValue)\n" );

	$undervoltage = $uValue;
	$overvoltage  = $oValue;


	my ( $line,, $uV_id, $oV_id );
	my @legend_keys = ("battery voltage");
	my ( @volts, @time, $ramp_ref, $Itime );


	#if only one array and size < 5, start = 000, end = 999
	if ( scalar(@$rampAoA) == 1 ) {
		if ( scalar( @{ $$rampAoA[0] } ) >= 3 and scalar( @{ $$rampAoA[0] } ) < 5 ) {
			$$rampAoA[0][3] = 0;
			$$rampAoA[0][4] = 999;
		}
	}

	#convert Ref to Arrays
	@volts = @time = ();
	$Itime = 0;
	foreach my $ramp_ref (@$rampAoA) {
		my ( $startV, $endV, $time, $start, $end ) = @$ramp_ref;
		unless ( defined($end) ) {
			S_set_error( "error in RampStruct: elements have to be [startV, endV, time, start, end]",1 );
			return $error_ret;
		}

		$time = $time / 1000;
		my $timedelta = $time / ( $end - $start + 1 );

		if ( $timedelta < 0.0002 ) {
			S_set_error( "error in RampStruct, timedelta $timedelta < 0.0002",109 );
			return $error_ret;
		}
		if ( $timedelta > 100 ) {
			S_set_error( "error in RampStruct, timedelta $timedelta > 100",109 );
			return $error_ret;
		}

		$Itime += $timedelta;
		push( @volts, $startV );
		$Itime = sprintf( "%.4f", $Itime );
		push( @time, $Itime );

		foreach my $count ( 1 .. $end - $start ) {
			$Itime += $timedelta;
			my $Ivolt = $startV + ($count) / ( $end - $start ) * ( $endV - $startV );
			$Ivolt = sprintf( "%.3f", $Ivolt );
			$Itime = sprintf( "%.4f", $Itime );
			push( @volts, $Ivolt );
			push( @time,  $Itime );
		}

	}

	#create graph
	$filename =~ s/\.\w+$//;    # cut off file extension
	$filename =~ s/\//\\/g;     # replace all slashes with backslashes

	#delete files if existing
	unlink("$filename.txt.unv");
	unlink("$filename.png");

	if ( open( OUT, ">$filename" . ".txt.unv" ) ) {
		print OUT "TIME;VOLTAGE;\n";
		print OUT "s;volt;\n";
		for ( my $i = 0 ; $i < @time ; $i++ ) {
			print OUT "$time[$i];$volts[$i];\n";
		}
		close(OUT);
	}
	else {
		S_set_error( "could not open out file $filename.txt.unv",1 );
		return $error_ret;
	}

	my ( $i, $graph, @data, $element, $current_time );
	my ( $val, $dt, $last_time );
	$last_time = $current_time = 0;
	@data = ();
	my $duration = $time[-1];

	my $nbr_of_data_elements = 1000;                           # 1000 points
	my $step = $duration / ( $nbr_of_data_elements * 100 );    # set plot stepwidth to 1/100 of the average time distance between 2 points
	$step = 0.001 if ( $step < 0.001 );                        # minimum clipping of stepwidth

	if   ( $undervoltage > 0 ) { $uV_id = 2; }
	else                       { $uV_id = 1; }
	if   ( $overvoltage > 0 ) { $oV_id = $uV_id + 1; }
	else                      { $oV_id = 1; }

	# empty ramp struct will be detected above

	# loop over all points
	for ( $i = 0 ; $i < @time ; $i++ ) {
		$val = $volts[$i];
		$dt  = $time[$i];
		while ( $current_time < $dt ) {
			push( @{ $data[0] }, $current_time );
			push( @{ $data[1] }, $val );
			if ( $undervoltage > 0 ) { push( @{ $data[$uV_id] }, $undervoltage ); }
			if ( $overvoltage > 0 )  { push( @{ $data[$oV_id] }, $overvoltage ); }
			$current_time += $step;
		}
		push( @{ $data[0] }, $current_time );
		push( @{ $data[1] }, $val );
		if ( $undervoltage > 0 ) { push( @{ $data[$uV_id] }, $undervoltage ); }
		if ( $overvoltage > 0 )  { push( @{ $data[$oV_id] }, $overvoltage ); }
		$last_time = $current_time;
		$current_time += $step;

	}    #END for
	$graph = GD::Graph::lines->new( 800, 600 );

	$graph->set(
		x_label       => "time in s",
		y_label       => "voltage in V",
		title         => 'waveform',
		x_tick_number => 'auto',
		r_margin      => 10,
		l_margin      => 10,
		b_margin      => 10,
	);

	$graph->set_legend_font( GD::Font->Large );
	if ( $undervoltage > 0 ) { push( @legend_keys, "undervoltage" ); }
	if ( $overvoltage > 0 )  { push( @legend_keys, "overvoltage" ); }

	$graph->set_legend(@legend_keys);

	if ( open( PIC, ">$filename.png" ) ) {
		binmode PIC;
		print PIC $graph->plot( \@data )->png;
		close(PIC);
#		S_w2log(5, "saved graph as $filename.png \n");
	}
	else {
		S_set_error( "could not open out file $filename.png",1 );
		return $error_ret;
	}


	S_w2log( 5, "TOE_createRampGraph: Created a ramp graph with name $filename.png \n" );
	return "$filename.png";
}

############################################################################################################

=head2 TOE_saveCurveFile

	TOE_saveCurveFile( $name, $filename [, $start, $end] );
	e.g. TOE_saveCurveFile( 'Ubat', "test.txt", 0, 23 );

	If no start/end is given, the full range will taken.

create file from curve memory between $start and $end, will create empty file in offline mode.


=cut

sub TOE_saveCurveFile
{
	my $name     = shift;
	my $filename = shift;
	my $start    = shift;
	my $end      = shift;
	my $error_ret = 0;
	my ($pos,$ret);

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	$start = 0   unless ( defined $start );
	$end   = 999 unless ( defined $end );

	unless ( defined($filename) )
	{
		S_set_error( "SYNTAX: TOE_saveCurveFile(name,filename,start,end)", 110 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_saveCurveFile($filename,$start,$end) \n" );

	my $save_dir = dirname($filename);

	unless ( -d $save_dir ) {
		unless ( mkdir($save_dir) ) {
			S_set_error( "could not create directory $save_dir",1 );
			return $error_ret;
		}
	}

	if ( TOE_isCurveRunning( $name ) ) {
		TOE_stopCurve( $name ) or return $error_ret;
	}
	my ( $points, $duration, $ONtime, $OFFtime, $volts );
	my @filecontent = ( "\n", "U[V]   t[s]\n" );

	$duration = $points = 0;

	if ( $start >= $end ) {
		S_set_error( "start >= end ($start >= $end)", 114 );
		return $error_ret;
	}
	if ( $start > 998 ) {
		S_set_error( "start > 998 ($start>998)", 114 );
		return $error_ret;
	}
	if ( $end > 999 ) {
		S_set_error( "end > 999 ($end>999)", 114 );
		return $error_ret;
	}

	for ( $pos = $start ; $pos <= $end ; $pos++ ) {
		TOE_writeString( $name, "FDS? $pos" );
		$ret = TOE_readString( $name );    # Read result
		if ($ret =~ /^\d+,([^,]+),[^,]+,([^,]+)/){
			push( @filecontent, "$1 $2\n" );
			$points++;
		}
	}

	unshift( @filecontent, "Wiederholungen:  1\n" );
	unshift( @filecontent, "Strombegrenzung: 4.00\n" );
	unshift( @filecontent, "Punkte:          $points\n" );
	unshift( @filecontent, "Dateiname:       $filename\n" );

	#avoid error by open File
	if ( open( FILE, ">$filename" ) ) {
		print FILE @filecontent;
		close(FILE);
	}
	else {
		S_set_error( "could not open out file $filename",1 );
		return $error_ret;
	}



	S_w2log( 5, "TOE_saveCurveFile done \n" );
	return 1;
}

############################################################################################################

=head2 TOE_VOLTAGE

	TOE_VOLTAGE( $name, $voltage, [ $maxcurrent ] );
	e.g. TOE_VOLTAGE( 'Ubat', 'U_BATT_DEFAULT' );
		 TOE_VOLTAGE( 'Ubat', 12.5 );


set output voltage, do all required steps to fulfill preconditions (this will stop a running curve!).
maps voltage via project defaults if necessary.

if no $maxcurrent is given, 4 A will be set as default.


=cut

sub TOE_VOLTAGE
{
	my $name       = shift;
	my $volts      = shift;
	my $maxcurrent = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	$maxcurrent = $MAXdeviceAMP unless ( defined $maxcurrent );

	unless ( defined($volts) )
	{
		S_set_error( "SYNTAX: TOE_VOLTAGE(name,voltage[,maxcurrent])", 110 );
		return $error_ret;
	}


	if ( TOE_isArbitrary( $name ) ) {
		if ( TOE_isCurveRunning( $name ) ) {
			TOE_stopCurve( $name ) or return $error_ret;
		}
		TOE_setMode( $name, 0 ) or return $error_ret;
	}


	TOE_setCurrent($name, $maxcurrent) or return $error_ret;
	TOE_setVoltage($name, $volts) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_ON

	TOE_ON( $name );

set output to ON, do all required steps to fulfil preconditions (this will stop a running curve!).


=cut

sub TOE_ON
{
	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_ON on Toellner '$name'\n" );

	if ( TOE_isArbitrary( $name ) ) {
		if ( TOE_isCurveRunning( $name ) ) {
			TOE_stopCurve( $name ) or return $error_ret;
		}
		TOE_setMode( $name, 0 ) or return $error_ret;
	}

	TOE_setExecute( $name ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_OFF

	TOE_OFF( $name );

set output to OFF, do all required steps to fulfil preconditions (this will stop a running curve!).


=cut

sub TOE_OFF
{

	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_OFF on Toellner '$name'\n" );

	if ( TOE_isArbitrary( $name ) ) {
		if ( TOE_isCurveRunning( $name ) ) {
			TOE_stopCurve( $name ) or return $error_ret;
		}
		TOE_setMode( $name, 0 ) or return $error_ret;
	}

	TOE_setStandby( $name ) or return $error_ret;

	return 1;
}

######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut

############################################################################################################

=head2 TOE_checkGPIBerror

	TOE_checkGPIBerror( );

read error status (*ESR?,ERR?) and report error if there is one

GPIB or internal Error recognized = 0, no Error or offline = 1

=cut

sub TOE_checkGPIBerror
{

	my $name = shift;
	my $error_ret =  0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	return 1 if $main::opt_offline;
	my ( $ESRresp, $ERRresp, $status );

	TOE_writeString(  $name, '*ESR?' ) or return $error_ret;

	#todo: here was a bug before: status was checked instead of response: always 0, check if it works
	$ESRresp = TOE_readString( $name );    # Read result

	chomp($ESRresp);

	#avoid error by empty string
	unless ( $ESRresp eq "" ) {
		if ( $ESRresp > 0 ) {
			TOE_writeString( $name, 'ERR?' ) or return $error_ret;
			( $status, $ERRresp ) = TOE_readString( $name );    # Read result
			if ( defined($ERRresp) ) {
				chomp($ERRresp);
				if ( $ERRresp !~ /^0,/ )                                     #error occurred
				{
					S_set_error( "toe_checkGPIBerror found GPIB: ESR is $ESRresp, ERR is $ERRresp on Toellner '$name'",21 );
					return $error_ret;
				}
			}
		}
	}
	else {
		#### this error cannot be fixed!!, because error occurs occasionally
		S_w2log(5,"**** WARNING: ESRresp was empty \n");
	}

	S_w2log( 5, "TOE_checkGPIBerror found no error \n" );

	#no error occurred
	return 1;

}

############################################################################################################

=head2 TOE_setCurveStart

	TOE_setCurveStart( $name, $point );
	e.g. TOE_setCurveStart( 'Ubat', 2 );

set start point for curve (FAS X)


=cut

sub TOE_setCurveStart
{

	my $name = shift;
	my $start = shift;

	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	unless ( defined($start) )
	{
		S_set_error( "SYNTAX: TOE_setCurveStart(name,point)", 110 );
		return $error_ret;
	}

	#parameter range check
	if ( ( $start < 0 ) || ( $start > 999 ) )
	{
		S_set_error( "start point $start out of range (0<=x<=999)", 114 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setCurveStart start point: $start on Toellner '$name'\n" );

	TOE_writeStringOPC( $name, "FAS $start;*OPC?" ) or return $error_ret;

	return 1;

}

############################################################################################################

=head2 TOE_setCurveEnd

	TOE_setCurveEnd( $name, $point );
	e.g. TOE_setCurveEnd( 'Ubat', 19 );

set end point for curve (FAE X).


=cut

sub TOE_setCurveEnd
{

	my $name = shift;
	my $end = shift;

	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	unless ( defined($end) )
	{
		S_set_error( "SYNTAX: TOE_setCurveEnd(name,point)", 110 );
		return $error_ret;
	}

	#parameter range check
	if ( ( $end < 0 ) || ( $end > 999 ) )
	{
		S_set_error( "end point $end out of range (0<=x<=999)", 114 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setCurveEnd end point: $end on Toellner '$name'\n" );

	TOE_writeStringOPC( $name, "FAE $end;*OPC?" ) or return $error_ret;

	return 1;

}

############################################################################################################

=head2 TOE_initCurve

	TOE_initCurve( $name );

reset curve to start point (FCL)


=cut

sub TOE_initCurve
{

	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_initCurve: reset curve to start point on Toellner '$name'\n" );
	TOE_writeStringOPC( $name, 'FCL;*OPC?' ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_startCurve

	TOE_startCurve( $name );

start curve (FS) if start conditions are fulfilled

voltage will stay on first curve value after curve is over


=cut

sub TOE_startCurve
{

	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_startCurve start curve on Toellner '$name'\n" );
	TOE_writeStringOPC( $name, 'FS;*OPC?' ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_stopCurve

	TOE_stopCurve( $name );

stop curve (FP)


=cut

sub TOE_stopCurve
{
	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_stopCurve: stops curve on Toellner '$name'\n" );
	TOE_writeStringOPC( $name, "FP;*OPC?" ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_setExecute

	TOE_setExecute( $name );

set output to execute (EX 1)


=cut

sub TOE_setExecute
{
	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_setExecute on Toellner '$name'\n" );
	TOE_writeStringOPC( $name, 'EX 1;*OPC?' ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_setStandby

	TOE_setStandby( $name );

set output to standby (EX 0)


=cut

sub TOE_setStandby
{

	my $name = shift;
	my $error_ret = 0;
	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_setStandby on Toellner '$name'\n" );
	TOE_writeStringOPC( $name, 'EX 0;*OPC?' ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_setRepetition

	TOE_setRepetition( $name, $repeat );
	e.g. TOE_setRepetition( 'Ubat', 4 );

set repetition for curve (FB x)


=cut

sub TOE_setRepetition
{
	my $name = shift;
	my $repeat = shift;
	my $value;

	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	unless ( defined($repeat) )
	{
		S_set_error( "SYNTAX: TOE_setRepetition(repeat)  \n", 110 );
		return $error_ret;
	}

	#parameter range check
	if ( ( $repeat < 0 ) || ( $repeat > 255 ) )
	{
		S_set_error( "repetition $repeat out of range (0<=x<=255)", 114 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setRepetition: sets curve repetition to $repeat on Toellner '$name'\n" );

	TOE_writeStringOPC( $name, "FB $repeat;*OPC?" ) or return $error_ret;

	return 1;

}

############################################################################################################

=head2 TOE_setVoltage

	TOE_setVoltage( $name, $voltage );
	e.g. TOE_setVoltage( 'Ubat', 12.5 );
		 TOE_setVoltage( 'Ubat', 'U_BATT_DEFAULT' );

set output voltage (V x)


=cut

sub TOE_setVoltage
{
	my $name = shift;
	my $volts = shift;
	my $value;

	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	unless ( defined($volts) )
	{
		S_set_error( "SYNTAX: TOE_setVoltage(name,voltage)  \n", 110 );
		return $error_ret;
	}
	my $channel    = $TOE_struct->{$name}{'channel'};

	#map voltage if necessary
	unless ( defined( $value = $main::ProjectDefaults->{'VEHICLE'}{$volts} ) )
	{
		if ( $volts =~ /^[+-]*\d+\.?\d*$/ )
		{
			$value = $volts;
		}
		else
		{
			S_set_error( "could not resolve voltage '$volts' (not a valid number)", 114 );
			return $error_ret;
		}
	}

	#parameter range check
	if ( ( $value < 0 ) || ( $value > $MAXdeviceVOLT ) )
	{
		S_set_error( "voltage $value out of range (0<=x<=$MAXdeviceVOLT)", 114 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setVoltage: set voltage to $volts (V $value) on Toellner '$name' \n" );
	my $channel_string = '';
	if ( $channel > 0 ) {
		$channel_string = "INST OUT$channel; ";
	}

	TOE_writeStringOPC( $name, $channel_string . "V $value;*OPC?" ) or return $error_ret;

	return 1;

}

############################################################################################################

=head2 TOE_setCurrent

	TOE_setCurrent( $name, $current );
	e.g. TOE_setCurrent( 'Ubat', 2.5 );

set maximum output current (C x)


=cut

sub TOE_setCurrent
{
	my $name = shift;
	my $current = shift;
	my $value;

	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	unless ( defined($current) )
	{
		S_set_error( "SYNTAX: TOE_setCurrent(name,current)", 110 );
		return $error_ret;
	}
	my $channel    = $TOE_struct->{$name}{'channel'};

	#parameter range check
	if ( ( $current < 0 ) || ( $current > $MAXdeviceAMP ) )
	{
		S_set_error( "current $current out of range (0<=x<=$MAXdeviceAMP)", 114 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setCurrent set current to $current amps on Toellner '$name' \n" );
	my $channel_string = '';
	if ( $channel > 0 ) {
		$channel_string = "INST OUT$channel; ";
	}

	TOE_writeStringOPC( $name, $channel_string . "C $current;*OPC?" ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_setMode

	TOE_setMode( $name, $mode );
	e.g. TOE_setMode( 'Ubat', 3 );

set output mode (F x)

0 = power supply mode, 1 = external voltage control, 2 = external current control, 3 = arbitrary mode


=cut

sub TOE_setMode
{
	my $name = shift;
	my $mode = shift;
	my $value;

	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	unless ( defined($mode) )
	{
		S_set_error( "SYNTAX: TOE_setMode(name,mode)", 110 );
		return $error_ret;
	}

	#parameter range check
	if ( ( $mode < 0 ) || ( $mode > 3 ) )
	{
		S_set_error( "mode $mode out of range (0<=x<=3)", 114 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setMode: sets mode $mode on Toellner '$name'\n" );

	TOE_writeStringOPC( $name, "F $mode;*OPC?" ) or return $error_ret;

	return 1;

}


=head2 TOE_setExternalTrigger

	TOE_setExternalTrigger( $name, $mode );
	e.g. TOE_setExternalTrigger( 'Ubat', 1 );

	mode:
	0 = off
	1 = on
		
set external trigger mode off or on.

works on ARBITRARY only 

=cut

sub TOE_setExternalTrigger
{
	my $name = shift;
	my $mode = shift;
	my $value;

	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;
	unless ( defined($mode) )
	{
		S_set_error( "SYNTAX: TOE_setExternalTrigger(name,mode)", 110 );
		return $error_ret;
	}

	#parameter range check
	if ( ( $mode < 0 ) || ( $mode > 1 ) )
	{
		S_set_error( "mode $mode out of range (0<=x<=1)", 114 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_setExternalTrigger: sets mode $mode on Toellner '$name'\n" );

	TOE_writeStringOPC( $name, "ETR $mode;*OPC?" ) or return $error_ret;

	return 1;

}

############################################################################################################

=head2 TOE_writeString

	TOE_writeString(  $name, $string );
	e.g. TOE_writeString( 'Ubat', "*IDN?");

write string directly to Toellner


=cut

sub TOE_writeString
{
	my $name = shift;
	my $string = shift;
	my $error_ret = 0;

	check_name( $name ) or return $error_ret;

	unless ( defined($string) )
	{
		S_set_error( "SYNTAX: TOE_writeString( name, string )", 110 );
		return $error_ret;
	}

	check_connected( $name ) or return $error_ret;

	S_w2log( 5, "TOE_writeString: writes the string ($string)\n" );

	return 1 if $main::opt_offline;

	$TOE_handle = $TOE_struct->{$name}{'handle'};
	eval { $TOE_handle->ibwrt($string); };

	if ($@) {
		S_set_error( "TOE_writeString to '$name' internal error: $@", 21 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_writeString: success\n" );
	return 1;
}




=head2 TOE_writeStringOPC

	TOE_writeStringOPC(  $name, $string [,$waittime_ms] );
	e.g. 
		TOE_writeStringOPC( 'Ubat', "EX 1;*OPC?");
		TOE_writeStringOPC( 'Ubat', "FCV 001,999;*OPC?", 500 );
	
	$string      - command string, has to end with *OPC?
	$waittime_ms - optional wait time before read

write string directly to Toellner and check for OPC (operation complete)

=cut

sub TOE_writeStringOPC {
	my $name   = shift;
	my $string = shift;
	my $waittime = shift;
	my $result;
	my $error_ret =  0;

	check_name( $name ) or return $error_ret;

	unless ( defined($string) )
	{
		S_set_error( "SYNTAX: TOE_writeStringOPC( name, string [,waittime_ma] )", 110 );
		return $error_ret;
	}

	# if command doe not end with OPC
	unless ( $string =~ /\*OPC\?$/){
		S_set_error( "TOE_writeStringOPC command '$string' does not end with '*OPC?'", 109 );
		return $error_ret;
	}
	check_connected( $name ) or return $error_ret;

	TOE_writeString( $name, $string ) or return $error_ret;
	S_wait_ms($waittime) if (defined $waittime and $waittime > 0);

	$result = TOE_readString( $name );    # Read result
	TOE_checkGPIBerror( $name ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_readString

	$string = TOE_readString( $name );

read string directly from Toellner

Returns string, on error empty string, offline return 'offline'

=cut

sub TOE_readString
{

	my $name = shift;
	my $error_ret =  '';

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	return 'offline' if $main::opt_offline;

	my ( $string, $STB, $i );
	#poll for MAV bit max 5 sec
	for ( $i = 0 ; $i < 500 ; $i++ ) {
		$STB = 256 + ( $TOE_handle->ibrsp() );
		last if ( ( $STB & 16 ) == 16 );

		# sleep 10 msec
		S_wait_ms(10);
	}

	if ( $i > 499 ) {
		S_set_error( "communication timeout while reading from Toellner '$name'",21 );
		return $error_ret;
	}

	S_wait_ms(10);
	$string = $TOE_handle->ibrd(1024);
	unless ( defined($string) ) {
		$string = $TOE_handle->ibrd(1024);
		unless ( defined($string) ) {
			S_set_error( "communication error (no data) while reading from Toellner '$name'",21 );
			return $error_ret;
		}
	}
	chomp($string);

	S_w2log( 4, "TOE_readString: got '$string' from Toellner '$name'\n" );
	return $string;
}

############################################################################################################

=head2 TOE_storePage

	TOE_storePage( $name, $page );
	e.g. TOE_storePage( 'Ubat', 3 );

store current curve on memory card page (CST x).

1 page = 16 K, so a 256 K memory card has 16 pages (0 to 15)


=cut

sub TOE_storePage
{
	my $name = shift;
	my $page = shift;
	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	unless ( defined($page) )
	{
		S_set_error( "SYNTAX: TOE_storePage(name,page)", 110 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_storePage: Stores the curve on Toellner '$name' to page $page\n" );

	TOE_writeStringOPC( $name, "CST $page;*OPC?" ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_recallPage

	TOE_recallPage( $name, $page );
	e.g. TOE_recallPage( 'Ubat', 2 );

load curve from memory card page (CRC x).

wait some time (about 300 ms) between stop curve and recall next page


=cut

sub TOE_recallPage
{
	my $name = shift;
	my $page = shift;
	my $error_ret = 0;

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	unless ( defined($page) )
	{
		S_set_error( "SYNTAX: TOE_recallPage:(name,page)", 110 );
		return $error_ret;
	}

	S_w2log( 5, "TOE_recallPage: Loads the curve on Toellner '$name' from page $page\n" );

	TOE_writeStringOPC( $name, "CRC $page;*OPC?" ) or return $error_ret;

	return 1;
}

############################################################################################################

=head2 TOE_isConnected

	$value = TOE_isConnected( $name );

check if Toellner is connected

Returns 1 if true, 0 if false,  Error: < 0,	  offline return: 1

=cut

sub TOE_isConnected
{
	my $name = shift;
	check_name( $name ) or return 0;

	return ( $TOE_struct->{$name}{'is_connected'} );
}

=head2 TOE_isArbitrary

	$value = TOE_isArbitrary( $name );

check if Toellner is arbitrary device (TOE8815 or TOE 8805)

Returns 1 if true, 0 if false,  Error: < 0,	  offline return: 1

=cut

sub TOE_isArbitrary
{
	my $name = shift;
	check_name( $name ) or return 0;

	return ( $TOE_struct->{$name}{'is_arbitrary'} );
}

############################################################################################################

=head2 TOE_isCurveRunning

	$value = TOE_isCurveRunning( $name );

check if curve is running,

Returns 0 for curve not running, 1 curve running,  Error: < 0 , offline return: 0

=cut

sub TOE_isCurveRunning
{

	my $name = shift;
	my $error_ret =  0;

	S_w2log( 5, "TOE_isCurveRunning: Checks for curve is running or not ....... \n" );

	check_name( $name ) or return $error_ret;
	check_connected( $name ) or return $error_ret;

	# always false for non arbitrary device and offline mode
	return 0 unless ( TOE_isArbitrary( $name ) );
	return 0 if $main::opt_offline;

	$TOE_handle = $TOE_struct->{$name}{'handle'};

	# check for running curve
	my $STB = 256 + ( $TOE_handle->ibrsp() );

	if ( ( $STB & 128 ) != 128 ) {
		S_w2log( 5, "Curve is running \n");
		return 1;
	}

	S_w2log( 5, "Curve is not running \n");
	return 0;
}

############################################################################################################

=head1 not exported functions


=head2 check_name

	check_name( $name ); not exported

check if $name is defined and exists

Returns

		error: 0, succuess 1
=cut

sub check_name{
	my $name=shift;
	unless ( defined($name) )
	{
		S_set_error( "No power supply name given", 110 );
		return 0;
	}

	unless ( exists $TOE_struct->{$name} ) {
		S_set_error( "Toellner '$name' was never connected before", 114 );
		return 0;
	}

	return 1;
}


=head2 check_connected

	check_connected( $name ); not exported

check if $name is connected

Returns

		error: 0, succuess 1
=cut

sub check_connected{
	my $name=shift;
	unless ( TOE_isConnected($name) )
	{
		S_set_error( "Toellner '$name' is not connected", 21 );
		return 0;
	};
	return 1;
}


# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Toellner manual.

=cut
