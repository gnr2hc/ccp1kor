
About TRC_Manager.dll:
	It is 32-bit TRC Manager DLL used to communicate with MF Transient recorder.
	It makes use of the Driver library(TPC_Access.dll) provided by MF Intruments to communicate with the 
	server software (installed in MF TransCom equipment) and control(configure channels & trigger, start/stop recording) 
	the Transient recorder.
	
About TPC_Access.dll:
	A 32-bit C Library to communicate with TransCom server software. 
	It gives APIs for the low level communication.

About LTT2API.dll:
	A 32-bit LTT used in TRC_Manager.dll.

About lttaspi.dll:
	A 32-Bit Ltt internal dll used by LTT2API.dll

To Register COM DLL (TRC_Manager.dll) procedure:


1) Open windows command prompt with admin rights
2) use command "regsvr32" with dll full path
3) It will popup the status of the registaration sucussful/unsucussful, then click ok.

