# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_TRC;

use 5.006001;
use strict;
use warnings;
use LIFT_general;
use LIFT_evaluation;
use LIFT_numerics;
use File::Basename;
use Win32;

BEGIN {
    use LIFT_general;
    S_add_paths2INC(['./Win32', '../MFTRC/Win32'], ['./Win32', '../MFTRC/Win32']);
}

use TRC;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  TRC_InitHW
  TRC_StartMeasurement
  TRC_SendSWTrigger
  TRC_get_values
  TRC_plot_values
  TRC_StopMeasurement
  TRC_EvaluateMeasurement
  TRC_CloseHW
  TRC_ConfigureChannels
);

our ( $VERSION, $HEADER );

my $status;             # Variable to hold the status of operation
my $TRC_initialized;    # flag for TRC initialization
my %TRC_channels;       #hash to contain TRC channel related info based on channel name
my $NumOfChannels;      # number of channels given back by TRC
my ( $SamplingFrequency, $MemorySize, $TriggerDelay );    #used SamplingFrequency, MemorySize, TriggerDelay of TRC
my ( $UsedSamplingFrequency, $UsedMemorySize );

#initialize with default values
$TRC_initialized = 0;

# TRC_Type numbers (order to be kept same as in MFTRC.cpp):
# "_oW" = over wrapper DLL
#       More details about the Wrapper-DLL: TurboLIFT\System\dll_sources\MFTRC\TRC_Manager\TRC_Manager\doc\LTT2API_Wrapper_DLL_Specification.docx)
# 1 : MFTRC         - MF:       TPCAccess.dll
# 2 : LTT           - LTT184:   LTT2API.dll -> lttaspi.dll (recommended for LTT184)
# 3 : LTT_oW        - LTT184:   LTT2API_Wrapper.dll -> ltt2api4.dll -> ltt_osal4.dll (in progress, for development only, do not use)
# 4 : LTTsmart_oW   - LTTsmart: LTT2API_Wrapper.dll -> ltt2api4.dll -> ltt_osal4.dll
# 5 : placeholder   - LTTsmart: ltt2api4.dll -> ltt_osal4.dll (future use for LTTsmart without Wrapper-DLL, which is not planned currently)
my $TRC_Type = 0;

# IMPORTANT for automatic consistency check of TRC_Manager-DLL-VERSION in this module:
# Set string identical to version number given in DLL-Source-File (using dot-notation of version string):
# \TurboLIFT\System\develop\MFTRC\TRC_Manager\TRC_Manager\TRC_Manager.rc
my $TRC_Manager_DLL_Version = "17.0.0.0";

use constant RISING  => 1;
use constant FALLING => 2;

=head1 NAME

LIFT_TRC 

Perl extension for managing MFTRC/LTT with LIFT

=head1 SYNOPSIS

  use LIFT_TRC;

  TRC_InitHW();
  TRC_ConfigureChannels();
  TRC_StartMeasurement();
  TRC_SendSWTrigger();
  $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
  TRC_plot_values("SQUIBS.txt.unv", 1000);
  TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5);
  #                               from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
  TRC_StopMeasurement();
  TRC_CloseHW();

=head1 DESCRIPTION

    Additional Infos
        https://inside-docupedia.bosch.com/confluence/display/aeos/Transient+Recorder

B<ProjectConst:MFTRC>

  $Defaults -> {'TRANSI'} = {
    'General'   =>
    {
        'SamplingFrequency' => 200 * 1000 , # in Hz , 200 KHz (Valid values from 1Hz to the maximum speed)
                    # usual values: 1000 (1KHz), 2000 (2KHz), 5000 (5KHz), 10 * 1000 (10KHz), 20 * 1000 (20KHz),
                    #               50 * 1000 (50KHz),  100 * 1000 (100KHz), 200 * 1000 (200KHz), 
                    #               500 * 1000 (500KHz),  1000 * 1000 (1MHz),
                    #               2000 * 1000 (2MHz), 5000 * 1000 (5MHz),  10 * 1000 * 1000 (10 MHz)
                    # For LTT:
                    #    - above values are best fitted to device values by 
                    #      TRC_ConfigureChannels
                    #    - 16.667MHz: max 5ch, 8.333MHz: max 11ch => 32 ch max. 4.167 MHz
                    
                    # LTT:                               MF: 
                    #    0.06 us (16.667 MHz)                 0.10 us (10.000 MHz)     
                    #    0.12 us ( 8.333 MHz)                 0.20 us ( 5.000 MHz)     
                    #    0.24 us ( 4.167 MHz)                 0.50 us ( 2.000 MHz)     
                    #    0.48 us ( 2.083 MHz)                 1.00 us ( 1.000 MHz)     
                    #    0.80 us ( 1.250 MHz)                 2.00 us ( 0.500 MHz)     
                    #    0.96 us ( 1.042 MHz)                 5.00 us ( 0.200 MHz)     
                    #    1.12 us ( 0.893 MHz)                10.00 us ( 0.100 MHz)     
                    #    2.24 us ( 0.446 MHz)                20.00 us ( 0.050 MHz)     
                    #    3.20 us ( 0.312 MHz)                50.00 us ( 0.020 MHz)     
                    #    4.00 us ( 0.250 MHz)               100.00 us ( 0.010 MHz)    
                    #    5.12 us ( 0.195 MHz)               200.00 us ( 0.005 MHz)    
                    #    8.00 us ( 0.125 MHz)               500.00 us ( 0.002 MHz)    
                    #   12.80 us ( 0.078 MHz)              1000.00 us ( 0.001 MHz)   
                    #   16.00 us ( 0.062 MHz)
                    #   25.60 us ( 0.039 MHz)
                    #   41.60 us ( 0.024 MHz)
                    #  122.88 us ( 0.008 MHz)
                    # 1331.20 us ( 0.001 MHz)                     

                    # LTTsmart:
                    #   0.25 us ( 4.000000 MHz =   4000   * 1000 Hz )
                    #   0.50 us ( 2.000000 MHz =   2000   * 1000 Hz )
                    #   1.00 us ( 1.000000 MHz =   1000   * 1000 Hz )
                    #   2.00 us ( 0.500000 MHz =    500   * 1000 Hz )
                    #   4.00 us ( 0.250000 MHz =    250   * 1000 Hz )
                    #   8.00 us ( 0.125000 MHz =    125   * 1000 Hz )
                    #  10.00 us ( 0.100000 MHz =    100   * 1000 Hz )
                    #  20.00 us ( 0.050000 MHz =     50   * 1000 Hz )
                    #  40.00 us ( 0.025000 MHz =     25   * 1000 Hz )
                    #  50.00 us ( 0.020000 MHz =     20   * 1000 Hz )
                    #  80.00 us ( 0.012500 MHz =     12.5 * 1000 Hz )
                    # 100.00 us ( 0.010000 MHz =     10   * 1000 Hz )
                    # 200.00 us ( 0.005000 MHz =      5   * 1000 Hz )
                    # 500.00 us ( 0.002000 MHz =      2   * 1000 Hz )
                    #   1.00 ms ( 0.001000 MHz =            1000 Hz )
                    #   2.00 ms ( 0.000500 MHz =             500 Hz)
                    #   4.00 ms ( 0.000250 MHz =             250 Hz)
                    #   8.00 ms ( 0.000125 MHz =             125 Hz )
                    #  10.00 ms ( 0.000100 MHz =             100 Hz )


        'MemorySize'        =>  128 * 1024 ,
                 # in samples, 128 K (in samples. Valid values are powers of two from 1024 up to the memory size)
                 # usual values: 1024 (1K), 2 * 1024 (2K), 4 * 1024 (4K), 8 * 1024 (8K), 16 * 1024 (16K),
                 #               32 * 1024 (32K), 64 * 1024 (64K), 128 * 1024 (128K), 256 * 1024 (256K),
                 #               512 * 1024 (512K), 1024 * 1024 (1M), 2 * 1024 * 1024 (2M), 4 * 1024 * 1024 (4M),
                 #               8 * 1024 * 1024 (8M)
                 # refer to Recording time calculation below
                 # Recording time (in seconds) = MemorySize / SamplingFrequency(Hz)
                 #
                 # LTT             LTTsmart             MF    
                 #   -                  1k                1k
                 #    2k                2k                2k
                 #    4k                4k                4k
                 #    8k                8k                8k
                 #   16k               16k               16k
                 #   32k               32k               32k
                 #   64k               64k               64k
                 #  128k              128k              128k
                 #  256k              256k              256k
                 #  512k              512k              512k
                 # 1024k             1024k             1024k
                 # 2048k             2048k             2048k
                 # 4096k             4096k             4096k
                 #  -                8192k             8192k

        'TriggerDelay'      =>  0 , # MF: from -99% to 200%
                                    # LTT: from -100% to 0%,
                                    #      trigger delay not possible for external trigger,
                                    #      only in steps of 1024 samples, i.e. % value adapted accordingly
                                    #
                                    # with [T] = trigger point, following shows impact of trigger delay
                                    #    0%:   [T]<--recordtime--->
                                    # -100%:   <--recordtime--->[T]
                                    #  -50%:   <-record [T] time->
                                    #  +50%:   [T]       <--recordtime--->
                                    # +100%:   [T]                 <--recordtime--->
    },

    'CHANNELS' => {
        'CHANNEL1' => {
             'ChannelName'    => 'AB1FD',        # Channel Name, length should not exceed 255
            #'CouplingMode'   => 'DC',           # uncomment only if needed , 'AC' or 'DC', default is 'DC'
             'SignalMode'     => 'differential', # 'single' or 'differential' or 'single-' ('single-' only LTT)
             'VoltageRange'   => 20,             # one of  1, 2, 2.5, 5, 10, 20, 25, 50, 100
                                                 # E.g. "differential" 20V : -20...+20V => voltage range is 40V
             
                                # LTT-Ranges                 LTT-Couplings:     MF-Ranges      MF-Couplings      
                                # +/-  1.00 V (only 100kR)   Reference / GND    +/-  0.05 V    SE      
                                # +/-  2.00 V (only 100kR)   DC (100kR) SE+     +/-  0.10 V    DE
                                # +/-  2.50 V (only 100kR)   DC (100kR) SE-     +/-  0.20 V
                                # +/-  5.00 V (only 100kR)   DC (100kR) DE      +/-  0.50 V
                                # +/- 10.00 V (all)          DC (1MR)   SE+     +/-  1.00 V
                                # +/- 20.00 V (all)          DC (1MR)   SE-     +/-  2.00 V
                                # +/- 25.00 V (all)          DC (1MR)   DE      +/-  5.00 V
                                # +/- 50.00 V (all)                             +/- 10.00 V
                                # +/- 100.00 V (only 1MR)                       +/- 20.00 V
                                # +/- 200.00 V (only 1MR)                       +/- 50.00 V
                                # +/- 250.00 V (only 1MR)
                                # +/- 500.00 V (only 1MR)
                                #
                                # LTTsmart-Ranges            LTTsmart-Couplings
                                # +/-  500 mV                GND
                                # +/-  10.0 V                DC    SE/SE BNC (use DC + SE BNC)
                                # +/-  90.0 V                AC    SE/SE BNC
                                # LTTsmart-Ranges: Less ranges required due to increased 24 Bit resolution
                                # LTTsmart-Couplings: SE is equivalent to DE, because
                                #                     1. GND is floating and led by the input signal
                                #                     2. Both +/- inputs are fully isolated
                                #
                                # ( DC = direct current, SE = single ended, DE = differential ended,
                                #   all: TRC_ConfigureChannels will select 1MR DE as default )

                                # Below are the general usecases for Voltage Range +/- ve range 
                                # Example If the given 'VoltageRange' => 20, +/- ve range is calculated
                                # based on given 'SignalMode'
                                # a) LTT 'SignalMode' => 'single'        =>  0...+20V      
                                # b) LTT 'SignalMode' => 'differential'  => -20...+20V   Most typical usecase.   
                                # c) LTT 'SignalMode' => 'single-'       => -20...0V      
                                # d) MF 'SignalMode' => 'single'         =>  0...+20V      
                                # e) MF 'SignalMode' => 'differential'   => -20...+20V   Most typical usecase.   
                                # (MF does not have 'single-')
             
           # 'VoltageRange_Offset'  => 50,  # uncomment only if needed for MFTRC for +/- ve signal measurement,
                                # [LTT - not required, because automatically done by HW -> 0% for single ended,
                                # 50% for differential ended]
                                # 0% to 100%, by default 'VoltageRange_Offset = 50 %'                                     
                                # 'FullVoltageRange' = 2 * 'VoltageRange'
                                # minimum Voltage Range = - 'FullVoltageRange' * 'VoltageRange_Offset' / 100 
                                # maximum Voltage Range = min + 'FullVoltageRange' 
                                # Example: When setting 'VoltageRange' to 20V and 'VoltageRange_Offset' to 50%,
                                # the effective Voltage Range will be
                                # Minimum VoltageRange = -1 * (40V * .50 ) = -20V
                                # Maximum VoltageRange =  -20V + 40 = 20 V

            'TRIGGER'   => {
                 'TriggerVoltage' =>  3.5,       # should be <= 'VoltageRange' of the particular Channel
                #'Hysteresis'     =>  3.0,       # uncomment, if needed, default 'Hysteresis = TriggerVoltage'
                 'SlopeType'      => 'positive', # 'positive' or 'negative'
            },
        },
    },	
   'EXTERNAL_TRIGGER' => {
        'SlopeType'   => 'negative',  # MF: 'positive' or 'negative'
        							  # LTT184: Only 'positive' successfully tested
        							  # LTTsmart: 'positive' or 'negative'
    },
    'ENABLE_DEBUG_LOG_FILE' => 0 | 1, # OPTIONAL (default: 0): '0' for disable | '1' for enable
 },
 
B<TestBench Config:>

    $Testbench={

    'COB409407' => {      # LIFT PC host name
             ### ----------- Device Configuration Section ------
           'Devices' => {
                'TRC' => {
                    # 'Type' can be 'MFTRC', 'LTT', 'LTT_oW', or 'LTTsmart_oW'
                    # oW = over wrapper DLL: LTT2API_Wrapper.dll
                    # TurboLIFT\System\dll_sources\MFTRC\TRC_Manager\TRC_Manager\doc\
                    #     LTT2API_Wrapper_DLL_Specification.docx
                    'Type' => 'LTT' ,  
                    'IP' => '10.40.5.18:10010',  # for MFTRC
                    # Ignored for MF and LTTsmart_oW, because hard-wired (MF) or -coded (LTT2API-Wrapper).
                    'LTT_EXTERNAL_TRIGGER_ChannelNo'  =>  7, # for LTT184, optional for LTTsmart (to avoid a warning)
                            # 
                            # TurboLIFT | LTT-API        | LTT (19''rack)   |
                            # ChannelNo | digital in bit | 37 pin connector | comment
                            #-----------+----------------+---------+--------+--------
                            #     1     |      09        |         4        | unused
                            #     2     |      10        |         5        | LTT184
                            #     3     |      11        |         6        | LTT184
                            #     4     |      12        |         7        | LTT184
                            #     5     |      13        |         8        | LTT184
                            #     6     |      14        |         9        | LTT184
                            #     7     |      15        |        10        | LTT184, LTTsmart [x]
                            #+5V        |      n/a       |        19        | LTT184, LTTsmart
                            #Digital GND|      n/a       |        20 *)     | LTT184, LTTsmart [x]
                            #-----------+----------------+------------------+---------------------
                            # Preferred/Required pins for the external TTL-Trigger-Source are marked with [x]
                            # *) Recommended: Instead connecting Trigger-GND to pin 20, connect it to the
                            #    banana socket marked with the ground symbol on the rear side of the housing.
                },                                             
            },
        },
    };

B<Note:>

=over 3

=item * The name 'EXTERNAL' is reserved & should not be used for any channel, as it denotes EXTERNAL_TRIGGER.

=item * Only for MFTRC, If two or more triggers configured (including EXTERNAL_TRIGGER), All the triggers will be 'OR'ed (i.e., Any trigger that is obtained first, will start the recording).

=item * SamplingFrequency & MemorySize :


B<SamplingFrequency> = Valid values are from 1Hz to the maximum speed of the board or cluster (can be found in report TRC_InitHW())

B<MemorySize> = in samples. Valid values are powers of two from 1024 up to the memory size of the board

B<Recording time> = MemorySize / SamplingFrequency

for example, SamplingFrequency = 200 KHz, MemorySize = 128 * 1024 (128 K), then

recording time = (128 * 1024) / (200 * 1000) = 0.65536 seconds ~ 655.36 milliseconds

B<Usecases:>

        LIFT_Testbench->{'Devices'}{'TRC'} = 
       {
           'Type' => 'LTT' ,              ###-------------- Type can be 'MFTRC', 'LTT', 'LTT_oW', or 'LTTsmart_oW'
          #'IP' => '10.40.5.18:10010',    ###-------------- only required for Type = MFTRC
          #'LTT_EXTERNAL_TRIGGER_ChannelNo' => 7, ###-------------- EXTERNAL TRIGGER uncomment only if required for Type = LTT
        }, 

  $config_struct_href = {
    'General'   =>
    {
        'SamplingFrequency' => 200 * 1000  , # in Hz , 2 KHz
        'MemorySize'        =>  128 * 1024 , # in bytes, 128 KB
        'TriggerDelay'      =>  -25 ,        # from -99% to 200%
    },

    'CHANNELS' => {
        'CHANNEL1' => {
             'ChannelName'    => 'AB1FD',        # Channel Name, length should not exceed 255
            #'CouplingMode'   => 'DC',           # uncomment only if needed , 'AC' or 'DC', by default 'CouplingMode = DC'
             'SignalMode'     => 'differential', # 'single' or 'differential'
             'VoltageRange'   => 5,              # one of 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100
            #'VoltageRange_Offset'         => 50,              # uncomment only if needed, 0% to 100%, by default 'VoltageRange_Offset = 50'

            'TRIGGER'   => {
                 'TriggerVoltage'    =>  2.5,       # should be less than or equal to value in 'VoltageRange' of the particular Channel
                #'Hysteresis'        =>  3.0,       # uncomment only if needed,  by default 'Hysteresis = TriggerVoltage'
                 'SlopeType'         => 'positive', # 'positive' or 'negative'
            },
        },
    },

    'EXTERNAL_TRIGGER' => {
        'SlopeType'   => 'positive',  # 'positive' or 'negative'
    },
 };

    TRC_InitHW();
    
   1: Config a Measurement with SW-Trigger
   ---------------------------------------
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement();
    TRC_SendSWTrigger();
    S_wait_ms(10000);
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5); # from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
    TRC_StopMeasurement(); # Optional

   2: Config with Channel-Trigger (UBAT) => Measurement
   -----------------------------------------------------
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement(); 
    #UBAT Trigger
    S_wait_ms(10000);    
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5); # from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
    TRC_StopMeasurement(); # Optional    

    3:  Config a Measurement with SW-Trigger and Measurement with SW-Trigger
	-------------------------------------------------------------------------    
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement();
    TRC_SendSWTrigger();
    S_wait_ms(10000); 
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5); # from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
    TRC_StopMeasurement(); # Optional    
    
    TRC_StartMeasurement();
    TRC_SendSWTrigger();
    S_wait_ms(10000); 
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5); # from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
    TRC_StopMeasurement(); # Optional        
    
    4: Config with Channel-Trigger(UBAT) and Measurement & Config, Measurement with SW-Trigger
	------------------------------------------------------------------------------------------
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement(); 
    #UBAT Trigger
    S_wait_ms(10000); 	
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5); # from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
    TRC_StopMeasurement(); # Optional    
    
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement();
    TRC_SendSWTrigger();
    S_wait_ms(10000); 
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5); # from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
    TRC_StopMeasurement(); # Optional  
  
    5: Config with External-Trigger Measurement
	-------------------------------------------
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement();
    S_wait_ms(10000);  
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_EvaluateMeasurement('AB1FD', 5, 'rising', 200 , 500 , 2000, 0, 5); # from 200 to 500, with 2000ms wait time, 0 tolerance, 5 minimum samples / pulse
    TRC_StopMeasurement(); # Optional   
   
    6: Config with External-Trigger Measurement and Config with Channel–Trigger (UBAT) and Measurement
	--------------------------------------------------------------------------------------------------
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement();
    #External Trigger
    S_wait_ms(10000);  
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_StopMeasurement(); # Optional
	
    TRC_ConfigureChannels($config_struct_href);
    TRC_StartMeasurement(); 
    #UBAT Trigger
    S_wait_ms(10000); 	
    $data_HOH = TRC_get_values(['AB1FD', 'AB2FD'], 2000);
    TRC_plot_values("SQUIBS.txt.unv", 1000);
    TRC_StopMeasurement(); # Optional

    TRC_CloseHW();

=for html
<h4>Trigger delay notation : </h4>
<br>
<IMG SRC='..\..\pics\trigger_delay.png' width='700px' height='400px' alt="Trigger delay pictorial representation" border="0">
<br><br>

=head1 DESCRIPTION

The module LIFT_TRC has all the necessary functions to configure and measure using MF/LTT TRC.
The configuration should be done in LIFT ProjectConst file as given in L</SYNOPSIS>.


=head2 TRC_CloseHW

    TRC_CloseHW();

has to be called at the end, It will unload TRC_Manager.dll.
This function should be called in ENDcampaign

=cut

sub TRC_CloseHW {
	unless ($TRC_initialized) {
		S_set_warning("TRC not initialized");
		return 0;
	}

	S_w2log( 1, "TRC_CloseHW\n" );

	if ($main::opt_offline) {

		#reset the flag for initialization
		$TRC_initialized = 0;
		return 1;
	}

	#flag to indicate success/failure of TRC_CloseHW
	my $all_ok = 1;

	$status = trc_ExitTRC();
	Check_status($status);
	S_w2log( 4, "TRC CloseHW status=$status\n" );

	$all_ok = 0 if ( $status < 0 );

	# this will free COM objects.
	$status = trc_End();
	S_w2log( 4, "TRC End status=$status\n" );
	$all_ok = 0 if ( $status < 0 );

	#clear the global flags
	$TRC_initialized = 0;
	$TRC_Type        = 0;

	return $all_ok;

}

=head2 TRC_EvaluateMeasurement

    TRC_EvaluateMeasurement($channelName, $voltageLevel, $slopeType, $time_min  , $time_max [, $minWaitTime_ms [, $voltageTolerance [, $minSamplesPerPulse]]])

To evaluate the given channel's data to check whether the recorded signal contains a pulse within the mentioned time.

	$channelName        :   channel name configured in ProjectDefaults->{'TRANSI'}{'CHANNELS'} / ProjectDefaults->{'LTT'}{'CHANNELS'}
	$voltageLevel       :   Voltage threshold for the pulse (in volts)
	$slopeType          :   Direction of the pulse ('rising' or 'falling')
	$time_min            :   Starting time in time interval to be checked (relative to trigger, in milliseconds) or 'START'
	$time_max           :   Finish time in time interval to be checked (relative to trigger, in milliseconds) or 'END'
	$minWaitTime_ms     :   Optional wait time to wait for data to be recorded in Transient recorder (used for fail-safe measurement, in milliseconds)
	$voltageTolerance   :   Tolerance to be considered in $voltageLevel (in volts)
	$minSamplesPerPulse :   The minimum number of samples for considering as a pulse ( = 1 , by default)

	e.g.;

	($SucceededPulses_aref, $pulses_href) = TRC_EvaluateMeasurement('CHANNEL1' , 5.0, 'rising', 200 , 500 ); #retrieve data immediately and evaluate
	($SucceededPulses_aref, $pulses_href) = TRC_EvaluateMeasurement('CHANNEL1' , 5.0, 'rising', 200 , 500, 0, 0.001 ); #retrieve data immediately and evaluate with tolerance of 0.001 V.
	($SucceededPulses_aref, $pulses_href) = TRC_EvaluateMeasurement('CHANNEL1' , 5.0, 'rising', 200 , 500, 0, 0.001, 10 ); #retrieve data immediately and evaluate, atleast 10 samples should be there for a pulse

returns ($SucceededPulses_aref, $pulses_href) , on Success

	$SucceededPulses_aref : Index of pulses which satisfies the given condition (0,1,2, etc). In success conditions, number of elements in $SucceededPulses_aref array > 0
                            Access the successful pulses as $pulses_href->{"pulse$index"}

	$pulses_href          : Hashes that contain all available pulse details in the recorded signal for the total duration
	                        Format:
	                        $pulses_href = {
	                        	'pulse0' =>{
	                        		'start' = 100.05,
	                        		'end' = 220.10,
	                        		'values' = [2.2, 5.0, 6.1 ... ],
	                        	},
	                        	'pulse1' =>{
	                        		'start' = 275.20,
	                        		'end' = 325.10,
	                        		'values' = [2.8, 5.2, 6.7 ... ],
	                        	}
	                        }


error return : (undef, undef)

offline return :

                ([0], {
                         'pulse0' => {
                            'start' => 0,
                            'end' => 1,
                            'values' => [0, 1]
                          }
                      }
                 )


B<KNOWN ISSUE :>

=over 3

=item * Gives "Out Of Memory!" runtime exception when used with "Memory size = 8MB, TriggerDelay >~ +50%"

=back

=cut

sub TRC_EvaluateMeasurement {
	my $channelName        = shift;
	my $voltageLevel       = shift;
	my $slopeType          = shift;
	my $time_min           = shift;
	my $time_max           = shift;
	my $minWaitTime_ms     = shift;
	my $voltageTolerance   = shift;
	my $minSamplesPerPulse = shift;
	my ( $startTime, $traceFinishTime );
	my @succeededPulses = ();
	my ( $numOfActualPulses, %pulses, @values );
	my $data_HoA;

	# check for too less parameters
	unless ( defined($time_max) ) {
		S_set_error( "! too less parameters ! SYNTAX: TRC_EvaluateMeasurement(\$channelName, \$voltageLevel, \$slopeType, \$Time_min , \$Time_max [, \$minWaitTime_ms [, \$voltageTolerance [, \$MinSamplesPerPulse]]])", 110 );
		return ( undef, undef );
	}

	#validate slope type
	unless ( $slopeType =~ /rising/i || $slopeType =~ /falling/i ) {
		S_set_error( "Invalid 'SlopeType' specified for TRC Channel $channelName. 'SlopeType' shall be 'rising' or 'falling'", 109 );
		return ( undef, undef );
	}

	#Time_min should be a number or 'START'
	unless ( $time_min =~ /\d+?\.?\d+?/ || $time_min =~ /START/i ) {
		S_set_error( "\$Time_min shall be a number or 'START'", 109 );
		return ( undef, undef );
	}

	#Time_max should be a number or 'END'
	unless ( $time_max =~ /\d+?\.?\d+?/ || $time_max =~ /END/i ) {
		S_set_error( "\$Time_max shall be a number or 'END'", 109 );
		return ( undef, undef );
	}

	# minimum samples per pulse should be greater than 0
	if ( defined($minSamplesPerPulse) && $minSamplesPerPulse <= 0 ) {
		S_set_error( "Minimum samples per pulse should be greater than 0", 109 );
		return ( undef, undef );
	}

	#check whether TRC is already initialized
	unless ($TRC_initialized) {
		S_set_error( "TRC not initialized", 120 );
		return ( undef, undef );
	}

	#assign minimum wait time as 0, if not defined
	$minWaitTime_ms = 0 unless ( defined($minWaitTime_ms) );

	#assign voltage tolerance as 0, if not defined
	$voltageTolerance = 0 unless ( defined($voltageTolerance) );

	#assign Min samples per pulse as 1, if not defined
	$minSamplesPerPulse = 1 unless ( defined($minSamplesPerPulse) );

	S_w2log( 1,
		"TRC_EvaluateMeasurement (channel = $channelName, voltage level = $voltageLevel, slope = $slopeType, min time = $time_min  ms, max time = $time_max ms, wait time = $minWaitTime_ms ms , voltage tolerance = $voltageTolerance , Minimum number of samples/pulse = $minSamplesPerPulse])\n" );

	#set the number of pulses found as 0
	$numOfActualPulses = 0;

	#TRC_get_values() called even in offline mode, to validate $channelName & $minWaitTime_ms
	$data_HoA = TRC_get_values( [$channelName], $minWaitTime_ms );

	if ($main::opt_offline) {
		return (
			[0],
			{
				'pulse0' => {
					'start'  => 0,
					'end'    => 1,
					'values' => [ 0, 1 ]
				}
			}
		);
	}

	#if any error occured during retrieving data from  TRC, then report that Evaluation failed
	unless ( defined $data_HoA ) {
		S_set_error( "TRC_EvaluateMeasurement for channel '$channelName' failed", 21 );
		return ( undef, undef );
	}

	#get the time array and signal array corresponding to the channel
	my $timearray = $data_HoA->{'time'};

	$time_min = $$timearray[0]  if ( $time_min =~ /START/i );
	$time_max = $$timearray[-1] if ( $time_max =~ /END/i );

	#$slopeType shall be made to a constant defined integer to eliminate comparision time
	$slopeType = RISING  if ( $slopeType =~ /rising/i );
	$slopeType = FALLING if ( $slopeType =~ /falling/i );

	#Time_min should be lesser than Time_max
	if ( $time_min >= $time_max ) {
		S_set_error( "\$Time_max should be greater than \$Time_min", 109 );
		return ( undef, undef );
	}

	my $channeldata = $data_HoA->{$channelName};

	#go through all the signals and evaluate for pulses, for the whole interval (not only between $time_min  and $time_max)
	for ( my $count = 0 ; $count < scalar(@$timearray) ; $count++ ) {
		my $isConditionPassed = 0;
		my $previousTime;
		my $time = $$timearray[$count];

		#store the previous time
		$previousTime = $traceFinishTime;

		#store current time as trace finish time, so that it shall be used to store 'end' time, outside of loop
		$traceFinishTime = $time;
		my $cdata = $$channeldata[$count];

		#determine whether the signal satisfies the pulse condition & slope
		$isConditionPassed = 1 if ( $slopeType == RISING  && ( $cdata >= ( $voltageLevel - $voltageTolerance ) ) );
		$isConditionPassed = 1 if ( $slopeType == FALLING && ( $cdata >= ( $voltageLevel - $voltageTolerance ) ) );

		if ( $isConditionPassed == 1 ) {

			#if this is the first element that satisfies the slope
			$startTime = $time if ( scalar(@values) <= 0 );
			push( @values, $cdata );
		}
		else {
			#sine-like wave is only considered if number of collected samples greater than or equal to $minSamplesPerPulse
			if ( scalar(@values) >= $minSamplesPerPulse ) {
				$pulses{ 'pulse' . $numOfActualPulses }{'start'} = $startTime;
				$pulses{ 'pulse' . $numOfActualPulses }{'end'}   = $previousTime;    #store previous time as endtime of pulse, as currenttime is not corresponding to pulse

				#get all the values of the pulse and store
				push( @{ $pulses{ 'pulse' . $numOfActualPulses }{'values'} }, @values );
				$numOfActualPulses++;
			}

			#empty the collected values
			@values = ();
		}

	}

	#check if the pulse was still ongoing at the time of exit of forloop
	if ( scalar(@values) >= $minSamplesPerPulse ) {
		$pulses{ 'pulse' . $numOfActualPulses }{'start'} = $startTime;
		$pulses{ 'pulse' . $numOfActualPulses }{'end'}   = $traceFinishTime;

		#get all the values of the pulse and store
		push( @{ $pulses{ 'pulse' . $numOfActualPulses }{'values'} }, @values );
		$numOfActualPulses++;
	}

	S_w2log( 4, " -> found $numOfActualPulses pulses in the signal $channelName (Threshold = $voltageLevel, Tolerance = $voltageTolerance, Slope = '$slopeType', Minimum signal count = $minSamplesPerPulse)\n" );

	#log the pulse start and end timings in the report for all pulses in the total duration
	#foreach my $pulseNumber (0 .. ($numOfActualPulses - 1)){
	#    S_w2log( 5, " Pulse($pulseNumber) => start : ". $pulses{"pulse$pulseNumber"}{'start'} . " , end : ". $pulses{"pulse$pulseNumber"}{'end'} . ", Number of values : ". scalar(@{$pulses{"pulse$pulseNumber"}{'values'}}) . "\n" );
	#}

	# check whether any pulses available within Time_min and Time_max, if available, add the index to Succeeded pulse list
	foreach my $pulseNumber ( 0 .. ( $numOfActualPulses - 1 ) ) {
		if ( $time_min <= $pulses{"pulse$pulseNumber"}{"start"} && $time_max >= $pulses{"pulse$pulseNumber"}{"end"} ) {
			push( @succeededPulses, $pulseNumber );
		}
	}

	#check if any pulses are found and log into report, if no pulses found
	if ( scalar(@succeededPulses) > 0 ) {
		S_w2log( 5, scalar(@succeededPulses) . " pulse(s) found between $time_min  ms and $time_max ms \n" );
		foreach my $succeededPulseIndex ( 0 .. ( scalar(@succeededPulses) - 1 ) ) {
			S_w2log( 5,
				    " Pulse ( "
				  . ($succeededPulseIndex)
				  . " ) : start -> "
				  . $pulses{"pulse$succeededPulses[$succeededPulseIndex]"}{"start"}
				  . ", end -> "
				  . $pulses{"pulse$succeededPulses[$succeededPulseIndex]"}{"end"}
				  . " , Number of values : "
				  . scalar( @{ $pulses{"pulse$succeededPulses[$succeededPulseIndex]"}{'values'} } )
				  . "\n" );
		}
	}
	else {
		S_w2log( 4, "No pulses found between $time_min  ms and $time_max ms" );
	}

	return ( \@succeededPulses, \%pulses );
}

=head2 TRC_get_values

    $data_href = TRC_get_values( $channelName_aref [, $minWaitTime_ms, $hashType, $constantValueThreshold, $dataCompressionFactor ] );

Returns the data recorded for particular channels ($channelName_aref). The channel names are configured in 
ProjectDefaults->{'TRANSI'}{'CHANNELS'} / ProjectDefaults->{'LTT'}{'CHANNELS'}.
Optionally a time to wait for data to be recorded in Transient recorder (used for fail-safe measurement) can be given ($minWaitTime_ms). 
Default for $minWaitTime_ms is 0.
The structure of the output data ($data_href) depends on $hashType: $hashType is either 'HoA' (default) or 'HoH'.
It is possible to perform a data reduction algorithm on the data for $hashType = 'HoH':
If the difference between 2 data point is < $constantValueThreshold then data points are removed until a data compression factor $dataCompressionFactor is reached.
If $dataCompressionFactor is not defined then a maximum compression factor of 1E7 is used, i.e. as many data points as possible will be removed.
If $constantValueThreshold is not defined then no data compression is performed.

By default the function returns the data in HoA format:

	$data_HoA = {	# Trigger will always be at time 0
                'time'     => [-3, -2, -1, 0, 1, 2, 3, ...],
                "CHANNEL1" => [1.15, 5.23, 2.52, 3.25, 6.20, 5.15, 5.82, ...],
                "CHANNEL2" => [1.25, 2.15, 5.24, 4.17, 5.65, 10.10, 7.50, ...],
                ...
	}

If $hashType = 'HoH' the data are returned in HoH format:

	$data_HoA = {	# Trigger will always be at time 0
        -3 => {
                "CHANNEL1" => 1.15,
                "CHANNEL2" => 1.25,            
        }               
        -2 => {
                "CHANNEL1" => 5.23,
                "CHANNEL2" => 2.15,            
        }               
        -1 => {
                "CHANNEL1" => 2.52,
                "CHANNEL2" => 5.24,            
        }
        ...             
    }

	          
Examples:

	$data_HoA = TRC_get_values(['CHANNEL1', 'CHANNEL2'], 2000);     # retrieve data after 2000 milliseconds
	$data_HoA = TRC_get_values(['CHANNEL1', 'CHANNEL2']);           # retrieve data immediately
	$data_HoH = TRC_get_values(['CHANNEL1', 'CHANNEL2'], 0, 'HoH', 0.5);  # get data as HoH with data reduction (threshold 0.5 and maximum reduction factor)

Error return : undef

offline return :

    {
        'time'     => [0],
        "CHANNEL1" => [0],
        "CHANNEL2" => [0],
    }

or if $hashType = 'HoH':

    {
        0 => {
            "CHANNEL1" => 0,
            "CHANNEL2" => 0,
        }
    }

B<PERL CANNOT STORE LARGE AMOUNT OF DATA IN RAM-MEMORY FOR LONG-TIME (MAY PRODUCE "Out Of Memory!" runtime exception in 32-bit PERL). SO, THIS FUNCTION SHOULD BE USED WITH CARE!>

B<Note:>

=over 3

=item * If 'TriggerDelay' is positive, the signals of the channels from the 'triggering point (i.e., time 0)' till 'recording point' is assumed as 0.

=back

=cut

sub TRC_get_values {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'TRC_get_values( $channelName_aref [, $minWaitTime_ms, $hashType, $constantValueThreshold, $dataCompressionFactor ] )', @args );

	my $channelName_aref       = shift;
	my $minWaitTime_ms         = shift;
	my $hashType               = shift;
	my $constantValueThreshold = shift;
	my $dataCompressionFactor  = shift;

	my %channelData = ();

	my $data_HoA = {};
	my $data_HoH = {};

	#wait time sould not be negative
	if ( defined($minWaitTime_ms) && $minWaitTime_ms < 0 ) {
		S_set_error( "parameter \$minWaitTime_ms should be > 0", 114 );

		#return undef;
		return;
	}

	#if $minWaitTime_ms is not given, then assign it to 0
	$minWaitTime_ms = 0 unless ( defined($minWaitTime_ms) );

	if ( defined $hashType and $hashType !~ /^hoa|hoh$/i ) {
		S_set_error( "parameter \$hashType should be either 'HoA' or 'HoH'.", 114 );
		return;
	}
	unless ($TRC_initialized) {
		S_set_error( "TRC not initialized", 120 );

		#return undef;
		return;
	}

	#check whether all channel names exists in ProjectConst
	foreach my $channelName (@$channelName_aref) {
		unless ( exists $TRC_channels{$channelName} ) {
			S_set_error( "TRC Channel $channelName is not configured in ProjectConst", 109 );

			#return undef;
			return;
		}
	}

	S_w2log( 1, "TRC_get_values (CHANNELS: @$channelName_aref, wait time of $minWaitTime_ms ms) \n" );

	#wait for the specified time
	S_wait_ms($minWaitTime_ms);

	if ($main::opt_offline) {
		my $data_dummy_href;

		#prepare dummy hash to return for offline condition
		if ( $hashType =~ /^hoh$/i ) {
			foreach my $channelName (@$channelName_aref) { $data_dummy_href->{0}{$channelName} = 0; }
		}
		else {
			foreach my $channelName (@$channelName_aref) { $data_dummy_href->{$channelName} = [0]; }
			$data_dummy_href->{'time'} = [0];
		}
		return $data_dummy_href;
	}

	my $timeInterval_ms;
	my $totalRecordingTime_ms;
	my $nMemorySize;
	my $dataStartTime_ms;
	if ( $TRC_Type == 1 ) {    # MF
		                       #determine time interval in milliseconds
		$timeInterval_ms = ( 1.0 / $SamplingFrequency ) * 1000;

		#determine total recording time
		$totalRecordingTime_ms = ( $MemorySize * $timeInterval_ms );
		$nMemorySize           = $MemorySize;

		#determine the exact trigger time to insert the trigger line data
		$dataStartTime_ms = ( $TriggerDelay / 100.0 ) * $totalRecordingTime_ms;
	}
	else {                     # LTT
		my ( $res, $SamplingTime_s, $usedTriggerDelay );
		( $res, $SamplingTime_s ) = ltttrc_GetSampleTime_s();
		( $res, $nMemorySize )    = ltttrc_GetMemorySizeByIndex($MemorySize);
		$nMemorySize *= 1024;
		$timeInterval_ms = $SamplingTime_s * 1000;
		$totalRecordingTime_ms = ( $nMemorySize * $timeInterval_ms );

		( $res, $usedTriggerDelay ) = ltttrc_GetTriggerDelay();
		my $triggerDelay_perCent = -100.0 / $totalRecordingTime_ms * $usedTriggerDelay;
		if ( abs( $TriggerDelay - $triggerDelay_perCent ) > $NUM_EPSILON_1E_MINUS_6 ) {
			S_set_warning("INFO: TRC Configured TriggerDelay $TriggerDelay % changed to $triggerDelay_perCent % ($usedTriggerDelay ms), because either (1) LTT allows only delays in steps of 1024 samples or (2) in case of SW-Trigger, trigger delay is set to 0.");
		}

		$dataStartTime_ms = $usedTriggerDelay;
	}
	S_w2log( 1, "TRC Total Recording time :\"$totalRecordingTime_ms\" ms\n" );

	#my $dataStartTime_ms   = ( $TriggerDelay / 100.0 ) * $totalRecordingTime_ms;

	my $time_ms            = 0.00;
	my $isTimeArrayCreated = 0;

	#the Start time should be added to each time
	my $timeToBeAdded = $dataStartTime_ms;

	my $timearray = [];

	#look into DLL AND Change the logic
	for ( my $index = 0 ; $index < $nMemorySize ; $index++ ) {

		$time_ms = $index * $timeInterval_ms + $timeToBeAdded;
		push( @$timearray, $time_ms );    #prepare time array
	}
	$data_HoA->{'time'} = $timearray;

	foreach my $channelName (@$channelName_aref) {

		#get the data for all channels from Low level library
		my ( $data_aref, $data_aref_size );

		my $ok = 0;
		if ( $TRC_Type == 1 ) {           # MF
			( $status, $data_aref, $data_aref_size ) = trc_GetRecordedData( $channelName, 0 );    #wait for  0 ms, since the wait is already given using S_wait_ms()
			Check_status($data_aref_size);
			$ok = 1 if $data_aref_size > 0;
		}
		else {                                                                                    # LTT
			( $status, $data_aref, $data_aref_size ) = trc_GetRecordedData( $TRC_channels{$channelName}{'ChannelNumber'}, 0 );    #wait for  0 ms, since the wait is already given using S_wait_ms()
			Check_status($status);
			$ok = 1 if $status == 0;
		}

		#check whether all channel data is recorded  and obtained into hash , if not so, return error
		if ( not $ok ) {

			# return undef return value if error
			S_set_error( "could not read recorded data for $channelName", 21 );
			return;
		}

		S_w2log( 4, "TRC GetRecordedData($channelName) : Number of signals recorded = $data_aref_size\n" );

		unless ( $nMemorySize == $data_aref_size ) {
			S_set_error( "Low level driver error: Expected signals = $nMemorySize, Got = $data_aref_size ", 21 );
			return;
		}

		if ( $hashType =~ /^hoh$/i ) {
			AddArray2HoH( $data_HoH, $channelName, $timearray, $data_aref, $constantValueThreshold, $dataCompressionFactor );
		}
		else {
			$data_HoA->{$channelName} = $data_aref;
		}
	}

	if ( $hashType =~ /^hoh$/i ) {
		return ($data_HoH);
	}
	else {
		return ($data_HoA);
	}

}

=head2 TRC_InitHW

    TRC_InitHW();

This function should be called before calling any other function in this module.
It loads the driver DLL, initilaizes the low level module. TRC_ConfigureChannels needs to be called to be ready for measurement.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration options

	e.g.;

		TRC_InitHW();

=cut

sub TRC_InitHW {
	my $ipAddress;
	S_w2log( 1, "TRC_InitHW\n" );

	#check if TRC already initialized
	if ($TRC_initialized) {
		S_w2log( 1, "TRC Hardware already intialized\n" );
		return 1;
	}

	$TRC_Type = $LIFT_config::LIFT_Testbench->{'Devices'}{'TRC'}{'Type'};

	#  $TRC_Type = $main::ProjectDefaults->{'TRC'}{'UsedTRCType'};
	#print($TRC_Type);
	#check Used trc type, if exists validate it & convert it to DLL understandable number (MFTRC = 1, LTT = 2)
	unless ( defined($TRC_Type) ) {
		$TRC_Type = 1;    #by default, MFTRC type
	}
	else {
		#validation for TRC Type: 1 : MFTRC / 2 : LTT / 3 : LTT_oW / 4 : LTTsmart_oW
		unless ( $TRC_Type =~ /MFTRC/i || $TRC_Type =~ /LTT\s*$/i || $TRC_Type =~ /LTT_oW/i  || $TRC_Type =~ /LTTsmart_oW/i) {
			S_set_error( "Invalid 'TRC_Type' specified. 'TRC_Type' shall be 'MFTRC' or 'LTT'", 20 );
			return 0;
		}

		#change TRC mode to DLL understandable number (MFTRC = 1, LTT = 2)
		$TRC_Type = 1 if ( $TRC_Type =~ /MFTRC/i );
		$TRC_Type = 2 if ( $TRC_Type =~ /LTT\s*$/i );
		$TRC_Type = 3 if ( $TRC_Type =~ /LTT_oW/i );
		$TRC_Type = 4 if ( $TRC_Type =~ /LTTsmart_oW/i );
	}

	#check for Admin rights if LTT184 configured
	if ( IsLTT184() and not $main::opt_offline and not $main::opt_simulation ) {

		#Admin Rights is required for LTT184
		my $admin = Win32::IsAdminUser();
		if ( $admin == 0 ) {

			#User is not running this script as admin
			S_set_error( "Admin Rights required for 'LTT184'", 120 );
			return 0;
		}
	}

	if ($main::opt_offline) {

		#set the flag for initialization
		$TRC_initialized = 1;
		$NumOfChannels   = 32;
		return 1;
	}
	S_w2log( 1, "TRC_start\n" );

	#load the modules and initialize WIN32::ole object
	$status = trc_Start();
	Check_status($status);

	S_w2log( 4, "TRC Start status = $status\n" );


    # trc_SetFlagPrintDbgInfosEnabled
    my $flagEnableDebugLogFile = $main::ProjectDefaults->{'TRANSI'}{'ENABLE_DEBUG_LOG_FILE'};
    if ( not defined($flagEnableDebugLogFile) or $flagEnableDebugLogFile != 1 ) { $flagEnableDebugLogFile = 0; }

    my $snapshot_directory = "$main::REPORT_PATH/_snapshot_";
    unless ( -e $snapshot_directory or mkdir $snapshot_directory ) {
        S_set_error("Snapshot Directory: $snapshot_directory does not exist and could not be created\n");
        return;
    }
    $snapshot_directory =~ s/\//\\/g;    # replace all slashes by backslashes
    $snapshot_directory = File::Spec->rel2abs($snapshot_directory);
    trc_SetFlagPrintDbgInfosEnabled($flagEnableDebugLogFile, $snapshot_directory);


	$status = trc_SetType($TRC_Type);
	Check_status($status);
	S_w2log( 4, "TRC Set Type status = $status\n" );
	if ( $TRC_Type == 1 ) {

		#get the IP address
		$ipAddress = $LIFT_config::LIFT_Testbench->{'Devices'}{'TRC'}{'IP'};    # dummy for LTT

		#check whether IP address is defined for TRC
		unless ( defined $ipAddress ) {
			S_set_error( "No IP found for Transi in Testbench config", 20 );
			return 0;
		}

		#checking of IP address format
		unless ( $ipAddress =~ /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}/i ) {
			S_set_error( "IP address not in correct format (IPAddress:portnumber) ex: 10.3.45.18:10010", 20 );
			return 0;
		}
	}
	if ( IsLTT() ) {
		$ipAddress = "NULL_LTT";
	}

	#initialize the TRC #this fn should be called first, required for LTT All other function
	$status = trc_InitTRC($ipAddress);
	Check_status($status);
	if ( $TRC_Type == 1 ) {
		S_w2log( 4, "TRC Init ($ipAddress) status = $status\n" );
	}
	if ( IsLTT() ) {
		S_w2log( 4, "TRC Init status = $status\n" );
	}

	#get the version of Low level dll log it and check it
	my $trcDLLVersion;
	( $status, $trcDLLVersion ) = trc_GetDLLVersion();
	Check_status($status);
	S_w2log( 4, "TRC_Manager DLL version $trcDLLVersion\n" );
	my ( $enginePath, $enginePathDll, $trcDLLVersionNumber );
	$enginePath = $main::LIFT_exec_path;

	if ( not defined $enginePath )
    {
        # Assume .t testing
        require( "Unit_test_engine_path.pm" );
        $enginePath = $Unit_test_engine_path::enginePath;
    }

    $enginePath = File::Spec->rel2abs($enginePath);

	if ( $trcDLLVersion =~ /(.+Engine).+\((.+)\)/i ) {
		$enginePathDll       = $1;
		$trcDLLVersionNumber = $2;
		$enginePathDll =~ s/\\/\//g;    # replace all backslashes with slashes
		$enginePath =~ s/\\/\//g;       # replace all backslashes with slashes
		if ( $enginePathDll !~ /$enginePath/i ) {
			S_set_warning("INFO: TRC-DLL used from engine '$enginePathDll', which is outside current LIFT execution path '$enginePath' (Consider running run_once).");
		}
		if ( $trcDLLVersionNumber !~ /$TRC_Manager_DLL_Version/i ) {
			S_set_error( "Wrong TRC-Manager-DLL Version: FOUND: $trcDLLVersionNumber, EXPECTED: $TRC_Manager_DLL_Version (Consider running run_once). TRC-Manager-DLL-Path & Version FOUND: $trcDLLVersion", 24 );
			return 0;
		}
	}
	else {
		S_set_warning("Unable to verify the TRC-DLL path and version, because TRC-DLL-Version string $trcDLLVersion does not contain text 'Engine'.");
	}
	S_w2log( 4, "TRC PM-" . trc_getPMrevision() . "\n" );

	#get the TRC internal details and report in the log
	my ( $deviceId, $serverSWVersion, $macAddress, $maxMemory_samples, $maxSpeed_Hz );
	( $status, $deviceId, $serverSWVersion, $macAddress, $NumOfChannels, $maxMemory_samples, $maxSpeed_Hz ) = trc_GetDeviceDetails();

	Check_status($status);
	S_w2log( 4, "TRC GetDeviceDetails status=$status\n" );

	my $maxMemory_kSamples = $maxMemory_samples / 1024;
	my $maxSpeed_MHz = $maxSpeed_Hz / 1E6;

	#log the internal details of TRC
	if ( $TRC_Type == 1 ) {
		S_w2log( 4,
"TRC Details : Device type = $LIFT_config::LIFT_Testbench->{'Devices'}{'TRC'}{'Type'}\n deviceId = $deviceId\n Server Software Version = $serverSWVersion\n MAC Address = $macAddress\n Number of channels = $NumOfChannels\n Maximum memory (per channel) = $maxMemory_kSamples kSamples\n Maximum sampling frequency = $maxSpeed_MHz MHz\n"
		) if ( $status >= 0 );
	}
	if ( IsLTT() ) {
		S_w2log( 4,
"TRC Details : Device type = $LIFT_config::LIFT_Testbench->{'Devices'}{'TRC'}{'Type'}\n deviceId = $deviceId\n Server Software Version = $serverSWVersion\n Number of channels = $NumOfChannels\n Maximum memory (per channel) = $maxMemory_kSamples kSamples\n Maximum sampling frequency = $maxSpeed_MHz MHz\n"
		) if ( $status >= 0 );
	}

	$TRC_initialized = 1;

	#if status is -ve, print error log
	if ( ( $status < 0 ) || ( $NumOfChannels == 0 ) )    #Validate if no TRC device is detected or if TRC Driver not detected
	{
		S_set_error( "could not initialize TRC", 5 );
		$TRC_initialized = 0;
	}

	return 1;
}

=head2 TRC_ConfigureChannels

    TRC_ConfigureChannels( [, $config_struct_href] );

configures TRC channels with given structure, if no structure is given ProjectDefaults->{'TRANSI'}{'CHANNELS'} / ProjectDefaults->{'LTT'}{'CHANNELS'} will be used.

 validates & configures all channels mentioned in the ProjectConst/config. Configures the Trigger based on the mentioned configuration.

# Highest sample rate (16MHz) for LTT is only possible for 5 Channels per Device (Device-1 is Channel 1-16, Device-2 is Channel 17-32).
# Second Highest sample rate (8MHz) for LTT is only possible for 11 Channels per Device.
# Trigger delay works only in steps of 1k points, i.e. if delay is too small (<1k) then it is 0.
 
# for easier handling fix used maximum channelnumber = 32
# this means, that in case of TRC6070 (6 channels) 24 channels to much
# by saving to HD we need more memory as realy needed but the saving is 
# much easier.

#  For Configuring LTT more then once(ex External trigger to channel trigger), TRC_StopMeasurement() must be called if measurement is in progress state. 
  
=cut

sub TRC_ConfigureChannels {
	S_w2log( 1, "TRC_ConfigureChannels\n" );

	my $config_struct = shift;
	my ( $channelNumber, $maxChannelNumber, $channelName );
	my %trc_ChannelsSection;

	# my ( $SamplingFrequency, $MemorySize, $TriggerDelay );
	my $memindex         = 0;    # To use the highest allowable memory size
	my $freqindex        = 0;    # To use the highest allowable sampling frequency
	my $voltindex        = 0;    # To use the highest allowable Voltage range for LTT
	my $nNoofchannels    = 0;
	my $lttTriggerFlag   = 0;
	my $nTriggerMode     = -1;
	my $nTriggerCoupling = 0;    # used for LTT dll
	                             #channel variables
	my ( $signalMode, $voltageRange, $couplingMode, $offset );

	#Trigger variables
	my $triggerVoltage = 0;
	my $hysteresisVoltage = 0;
	my $slopeType = 0;

	# External Trigger
	my ( $externalTrigger, $externalLTTChannelNo );
	my $extslopeType;

	#array to hold channel information for all avilable channels.
	my @aChannelnumber        = ();
	my @achannelOn            = ();
	my @achannelRange         = ();
	my @achannelCoupling      = ();
	my @amfSamplingFrequency  = ( 1000, 2000, 5000, 10 * 1000, 20 * 1000, 50 * 1000, 100 * 1000, 200 * 1000, 500 * 1000, 1000 * 1000, 2000 * 1000, 5000 * 1000, 10 * 1000 * 1000 );
	my @altt184SamplingFrequency = ( 751.2019231, 8138.020833, 24038.46154, 39062.5, 62500, 78125, 125000, 195312.5, 250000, 312500, 446428.5714, 892857.1429, 1041666.667, 1250000, 2083333.333, 4166666.667, 8333333.333, 16666666.67 );
	my @aLTTsmartSamplingFrequency = ( 100, 125, 250, 500, 1000, 2000, 5000, 10 * 1000, 12.5 * 1000, 20 * 1000, 25 * 1000, 50 * 1000, 100 * 1000, 125 * 1000, 250 * 1000, 500 * 1000, 1000 * 1000, 2000 * 1000, 4000 * 1000 );
	my @aSamplingFrequency    = ();
	my @alttVoltagerange      = ( 1, 2, 2.5, 5, 10, 20, 25, 50, 100 );
	my $config_source         = $main::ProjectDefaults->{'TRANSI'};                                                                                                                                                                       #Change To TRC

	if ( defined $config_struct ) {
		$config_source = $config_struct;
	}

	#check & validate ProjectDefaults->{'TRANSI'} section
	$SamplingFrequency = $config_source->{'General'}{'SamplingFrequency'};
	$MemorySize        = $config_source->{'General'}{'MemorySize'};
	$TriggerDelay      = $config_source->{'General'}{'TriggerDelay'};

	#check whether necessary parameters are defined
	unless ( defined($SamplingFrequency) && defined($MemorySize) && defined($TriggerDelay) ) {
		S_set_error( "'SamplingFrequency' is not defined in ProjectDefaults->{'TRANSI'}", 20 ) unless ( defined $SamplingFrequency );
		S_set_error( "'MemorySize' is not defined in ProjectDefaults->{'TRANSI'}",        20 ) unless ( defined $MemorySize );
		S_set_error( "'TriggerDelay' is not defined in ProjectDefaults->{'TRANSI'}",      20 ) unless ( defined $TriggerDelay );
		return 0;
	}

    # STEP check if $TRC_Type is not defined
    unless ( defined $TRC_Type ){
        S_set_error( "'TRC_Type' is undef. It can happen when TRC_InitHW was not called or entry LIFT_Testbench->{'Devices'}{'TRC'}{'Type'} is undef.", 109 );
		return ;
    }

	# STEP check whether the TRC_Type is valid
	unless ( ( $TRC_Type == 1 || IsLTT() ) ) {
		S_set_error( "'TRC_Type'= $TRC_Type is not a valid type. It can be either 1(MFTRC) or 2(LTT) or 3(LTT_oW) or (4)LTTsmart_oW.\n Please set the proper type in LIFT_Testbench->{'Devices'}{'TRC'}{'Type'}", 109 );
		return ;
	}
	if ( $TRC_Type == 1 )    #Assign MF constant samplingFrequency array to General Sampling frequency array
	{
		@aSamplingFrequency = @amfSamplingFrequency;
	}
	if ( IsLTT184() )    #Assign LTT184 constant samplingFrequency array to General Sampling frequency array
	{
		@aSamplingFrequency = @altt184SamplingFrequency;
	}
	if ( IsLTTsmart() )    #Assign IsLTTsmart constant samplingFrequency array to General Sampling frequency array
    {
        @aSamplingFrequency = @aLTTsmartSamplingFrequency;
    }

	if ( $SamplingFrequency < $aSamplingFrequency[0] || $SamplingFrequency > $aSamplingFrequency[-1] ) {
		S_set_error( "'SamplingFrequency' value $SamplingFrequency not allowed for selected TRC", 20 );
		return 0;
	}
	else {
		#Frequency calculation for Common TRC
		while ( $aSamplingFrequency[$freqindex] < $SamplingFrequency ) {
			$freqindex++;
		}
	}

	if ( IsLTT184() && ( $MemorySize < 2048 || $MemorySize > 1024 * 1024 * 4 ) )    # only for LTT184
	{
		S_set_error( "'MemorySize' value $MemorySize not allowed for LTT", 20 );
		return 0;
	}

	if ( ( $MemorySize < 1024 || $MemorySize > 1024 * 1024 * 8 ) )                          # General
	{
		S_set_error( "'MemorySize' value $MemorySize not allowed for TRC, should be >= 1024 && <= 1024 *1024 * 8 ", 20 );
		return 0;
	}
	else {
		#Memory Size Calculation for Common TRC
		while ( ( 2**$memindex ) * 1024 < $MemorySize ) {
			$memindex++;
		}
	}

	if ( ( $TRC_Type == 1 ) && ( $TriggerDelay == -100 ) )                                  #  only for MFTRC = -100%
	{
		S_set_error( "'TriggerDelay' value $TriggerDelay not allowed for MFTRC", 20 );
		return 0;
	}
	elsif ( IsLTT() && ( $TriggerDelay > 0 ) )                                   # validate for LTT > 0%
	{
		S_set_error( "'TriggerDelay' value $TriggerDelay not allowed for LTT", 20 );
		return 0;
	}

	unless ( defined( $config_source->{'CHANNELS'} ) ) {
		S_set_error( "{'TRANSI'}{'CHANNELS'} is not defined in ProjectDefaults or config_struct_href", 20 );
		return 0;
	}

	#collect info about channels to be configured
	%trc_ChannelsSection = %{ $config_source->{'CHANNELS'} };

	#empty the already existing channel configuration
	%TRC_channels = ();

	#parse through all channel definitions and do basic validation
	foreach my $channelIndex ( sort keys(%trc_ChannelsSection) ) {
		if ( $channelIndex =~ /CHANNEL(\d{1,2})/i ) {
			$channelNumber = $1;

			#check if channel 0 is defined
			if ( $channelNumber == 0 ) {
				S_set_error( "Invalid TRC channel definition : $channelIndex", 20 );
				return 0;
			}

			#increment the channel counter number used only for LTT.
			$nNoofchannels++;

			#store the max channel number
			$maxChannelNumber = $channelNumber unless ( defined($maxChannelNumber) );
			$maxChannelNumber = $channelNumber if ( $channelNumber > $maxChannelNumber );

			#check the mandatory parameters of channel
			$channelName = $config_source->{'CHANNELS'}{$channelIndex}{'ChannelName'};

			$signalMode   = $config_source->{'CHANNELS'}{$channelIndex}{'SignalMode'};
			$voltageRange = $config_source->{'CHANNELS'}{$channelIndex}{'VoltageRange'};
			$couplingMode = $config_source->{'CHANNELS'}{$channelIndex}{'CouplingMode'};
			$offset       = $config_source->{'CHANNELS'}{$channelIndex}{'VoltageRange_Offset'};

			unless ( defined($channelName) && defined($signalMode) && defined($voltageRange) ) {
				S_set_error( "'ChannelName' not defined for TRC Channel $channelIndex",  20 ) unless ( defined $channelName );
				S_set_error( "'SignalMode' not defined for TRC Channel $channelIndex",   20 ) unless ( defined $signalMode );
				S_set_error( "'VoltageRange' not defined for TRC Channel $channelIndex", 20 ) unless ( defined $voltageRange );
				return 0;
			}

			if ( $voltageRange < 1 || $voltageRange > 100 ) {
				S_set_error( "Invalid  'voltageRange' => $voltageRange specified for TRC Channel $channelIndex.  ", 20 );
				return 0;
			}

			#validation for VolatageRage for MFTRC (Type = MF)
			# TODO: For this if/else condition exists an ALM story: Story 46554
			if ( $TRC_Type == 1 ) {
				if ( $voltageRange == 2.5 || $voltageRange == 25 ) {
					S_set_error( "Invalid  'voltageRange' => $voltageRange specified for TRC(MFTRC) Channel $channelIndex.  ", 20 );
					return 0;
				}

				if ( $voltageRange == 2 ) {
					$voltageRange = 5;    #  4 volts not possible round off to 5 Volts
				}
				if ( $voltageRange == 20 ) {
					$voltageRange = 50;    #  40 volts not possible round off to 5 Volts
				}

				else {
					$voltageRange = ( 2 * $voltageRange ) if ( $voltageRange < 100 );    # to get +/- range (10V Range >> +/-5.0V with 50% offset
				}
			}
			else {
				$voltindex = 0;                                                          # reset to each signal
				                                                                         #Voltage idex calculation for Common LTT required for DLL
				while ( $alttVoltagerange[$voltindex] < $voltageRange ) {
					$voltindex++;
				}
			}

			#validation for signal mode
			unless ( $signalMode =~ /single/i || $signalMode =~ /differential/i || $signalMode =~ /single-/i ) {
				S_set_error( "Invalid 'SignalMode' specified for TRC Channel $channelIndex. 'SignalMode' shall be 'single' or 'differential' or 'single-' ", 20 );
				return 0;
			}

			#change signal mode to DLL understandable number (single = 1, differential = 2)
			$signalMode = 1 if ( $signalMode =~ /single/i );
			$signalMode = 2 if ( $signalMode =~ /differential/i );
			$signalMode = 3 if ( $signalMode =~ /single-/i );

			#check coupling mode, if exists validate it & convert it to DLL understandable number (AC = 1, DC = 2)
			unless ( defined($couplingMode) ) {
				$couplingMode = 2 if ( $TRC_Type == 1 );                                                         #by default, DC coupling mode
				                                                                                                 #$couplingMode = 6 if($TRC_Type == 2);   #by default, 1MOhm DC Differential ended coupling mode
				                                                                                                 #LTT coupling mode
				$couplingMode = 1 if ( ( IsLTT() ) && ( $signalMode == 1 ) && ( $voltageRange <= 5 ) );
				$couplingMode = 2 if ( ( IsLTT() ) && ( $signalMode == 3 ) && ( $voltageRange <= 5 ) );
				$couplingMode = 3 if ( ( IsLTT() ) && ( $signalMode == 2 ) && ( $voltageRange <= 5 ) );
				$couplingMode = 4 if ( ( IsLTT() ) && ( $signalMode == 1 ) && ( $voltageRange > 5 ) );
				$couplingMode = 5 if ( ( IsLTT() ) && ( $signalMode == 3 ) && ( $voltageRange > 5 ) );
				$couplingMode = 6 if ( ( IsLTT() ) && ( $signalMode == 2 ) && ( $voltageRange > 5 ) );
			}
			else {
				#validation for coupling mode
				unless ( $couplingMode =~ /AC/i || $couplingMode =~ /DC/i ) {
					S_set_error( "Invalid 'CouplingMode' specified for TRC Channel $channelIndex. 'CouplingMode' shall be 'AC' or 'DC'", 20 );
					return 0;
				}
				unless ( $couplingMode =~ /DC/i ) {
					S_set_error( "Invalid 'CouplingMode' specified for TRC(LTT) Channel $channelIndex. 'CouplingMode' should be 'DC'", 20 ) if ( IsLTT() );
					return 0 if ( IsLTT() );
				}

				#change Coupling mode to DLL understandable number  for MFTRC(AC = 1, DC = 2)
				$couplingMode = 1 if ( ( $couplingMode =~ /AC/i ) && ( $TRC_Type == 1 ) );
				$couplingMode = 2 if ( ( $couplingMode =~ /DC/i ) && ( $TRC_Type == 1 ) );

				#LTT coupling mode
				$couplingMode = 1 if ( ( $couplingMode =~ /DC/i ) && ( IsLTT() ) && ( $signalMode == 1 ) && ( $voltageRange <= 5 ) );
				$couplingMode = 2 if ( ( $couplingMode =~ /DC/i ) && ( IsLTT() ) && ( $signalMode == 3 ) && ( $voltageRange <= 5 ) );
				$couplingMode = 3 if ( ( $couplingMode =~ /DC/i ) && ( IsLTT() ) && ( $signalMode == 2 ) && ( $voltageRange <= 5 ) );
				$couplingMode = 4 if ( ( $couplingMode =~ /DC/i ) && ( IsLTT() ) && ( $signalMode == 1 ) && ( $voltageRange > 5 ) );
				$couplingMode = 5 if ( ( $couplingMode =~ /DC/i ) && ( IsLTT() ) && ( $signalMode == 3 ) && ( $voltageRange > 5 ) );
				$couplingMode = 6 if ( ( $couplingMode =~ /DC/i ) && ( IsLTT() ) && ( $signalMode == 2 ) && ( $voltageRange > 5 ) );

			}

			#by default, offset will be 50%, if not defined for any channel  to get +/- range (Ex., 10V Range >> +/-5.0V with 50% offset)
			$offset = 50 unless ( defined($offset) );

			#validation of offset (should not be -ve)
			if ( $offset < 0 || $offset > 100 ) {
				S_set_error( "Invalid 'VoltageRange_Offset' specified for TRC Channel $channelIndex.  0 <= 'VoltageRange_Offset' <= 100", 20 );
				return 0;
			}

			#check whether channel name is already exisiting
			if ( exists( $TRC_channels{$channelName} ) ) {
				S_set_error( "Channel name $channelName exists multiple times in ProjectDefaults->{'TRANSI'}{'CHANNELS'}", 20 );
				return 0;
			}

			#save the channel configuration in global hash
			$TRC_channels{$channelName}{'ChannelNumber'}       = $channelNumber;
			$TRC_channels{$channelName}{'CouplingMode'}        = $couplingMode;
			$TRC_channels{$channelName}{'SignalMode'}          = $signalMode;
			$TRC_channels{$channelName}{'VoltageRange'}        = $voltageRange;
			$TRC_channels{$channelName}{'VoltageRange_Offset'} = $offset;

			if ( IsLTT() ) {
				$TRC_channels{$channelName}{'CouplingOn'} = 1;    #To Power on The configured LTT channel

				# global array
				push( @aChannelnumber,   $channelNumber - 1 );
				push( @achannelOn,       1 );                     #$nCouplingOn);
				push( @achannelRange,    $voltindex );
				push( @achannelCoupling, $couplingMode );
				if ($main::opt_offline) {

					#do nothing Implemeted to work in offline mode
				}
				else {
					$status = ltttrc_ConfigureChannelNames( $channelName, $channelNumber );
				}
			}

			#check for channel trigger settings
			if ( exists( $config_source->{'CHANNELS'}{$channelIndex}{'TRIGGER'} ) ) {
				$triggerVoltage    = $config_source->{'CHANNELS'}{$channelIndex}{'TRIGGER'}{'TriggerVoltage'};
				$hysteresisVoltage = $config_source->{'CHANNELS'}{$channelIndex}{'TRIGGER'}{'HysteresisVoltage'};
				$slopeType         = $config_source->{'CHANNELS'}{$channelIndex}{'TRIGGER'}{'SlopeType'};

				if ( IsLTT() ) {
					if ( $lttTriggerFlag == 0 ) {

						$nTriggerMode = substr( $channelIndex, 7, length($channelIndex) );    #Set the Trigger Channel Number for LTT.
						$lttTriggerFlag = 1;
					}
					else {
						S_set_error( "There should not be more then one TRIGGER entry for LTT", 20 );
						return 0;
					}

				}

				#check if any one of the trigger parameters defined
				if ( defined($triggerVoltage) || defined($hysteresisVoltage) || defined($slopeType) ) {

					#check whether all the mandatory trigger parameters are defined
					unless ( defined($triggerVoltage) && defined($slopeType) ) {
						S_set_error( "'TriggerVoltage' not defined for TRC Channel $channelIndex=>{'TRIGGER'}", 20 ) unless ( defined $triggerVoltage );
						S_set_error( "'SlopeType' not defined for TRC Channel $channelIndex=>{'TRIGGER'}",      20 ) unless ( defined $slopeType );
						return 0;
					}

					#validate slope type
					unless ( $slopeType =~ /positive/i || $slopeType =~ /negative/i ) {
						S_set_error( "Invalid 'SlopeType' specified for TRC Channel $channelIndex. 'SlopeType' shall be 'positive' or 'negative'", 20 );
						return 0;
					}

					#change signal mode to DLL understandable number (single = 1, differential = 2)
					$slopeType = 1 if ( $slopeType =~ /positive/i );
					$slopeType = 2 if ( $slopeType =~ /negative/i );
					$slopeType = 0 if ( ( $slopeType == 2 ) && IsLTT() ); # LTT: positive = 1, negative = 0

					#Assign 'Trigger voltage' to Hysteresis , by default , if Hysteresis is not defiend
					$hysteresisVoltage = $triggerVoltage unless ( defined($hysteresisVoltage) );

					#save the trigger parameters in global hash
					$TRC_channels{$channelName}{'TRIGGER'}{'TriggerVoltage'}    = $triggerVoltage;
					$TRC_channels{$channelName}{'TRIGGER'}{'HysteresisVoltage'} = $hysteresisVoltage;
					$TRC_channels{$channelName}{'TRIGGER'}{'SlopeType'}         = $slopeType;
				}
			}
		}
		else {
			#invalid channel definition
			S_set_error( "Invalid convention for TRC channel definition : $channelIndex", 20 );
			return 0;
		}
	}

	#if there are no valid channel definition found, return error
	if ( !defined $maxChannelNumber || $maxChannelNumber <= 0 ) {
		S_set_error( "No valid channel definition found in ProjectDefaults->{'TRANSI'}{'CHANNELS'}", 20 );
		return 0;
	}

	#validate max channel number based on the internal details of TRC
	if ( defined $NumOfChannels && $maxChannelNumber > $NumOfChannels ) {
		S_set_error( "Only $NumOfChannels channel definitions are allowed for this TRC", 20 );
		return 0;
	}

	#check and validate external trigger settings
	if ( defined $config_source->{'EXTERNAL_TRIGGER'}{'SlopeType'} ) {
		$extslopeType = $config_source->{'EXTERNAL_TRIGGER'}{'SlopeType'};

		#validate slope type
		unless ( $extslopeType =~ /positive/i || $extslopeType =~ /negative/i ) {
			S_set_error( "Invalid 'SlopeType' specified for ProjectDefaults->{'TRANSI'}{'EXTERNAL_TRIGGER'}. 'SlopeType' shall be 'positive' or 'negative'", 20 );
			return 0;
		}

		#change signal mode to DLL understandable number (positive = 1, negative = 2)
		$extslopeType = 1             if ( $extslopeType =~ /positive/i );
		$extslopeType = 2             if ( $extslopeType =~ /negative/i );
		$extslopeType = 0             if ( ( $extslopeType == 2 ) && IsLTT() ); # LTT: positive = 1, negative = 0

		$externalTrigger = $extslopeType;
		if ( IsLTTsmart_oW() ) {
		    $lttTriggerFlag = 1;
		}
	}

	#get values from TRC testbenchconfig & preload TRC settings
	if ( defined( $LIFT_config::LIFT_Testbench->{'Devices'}{'TRC'}{'LTT_EXTERNAL_TRIGGER_ChannelNo'} ) ) {
		$externalLTTChannelNo = 32 + $LIFT_config::LIFT_Testbench->{'Devices'}{'TRC'}{'LTT_EXTERNAL_TRIGGER_ChannelNo'} if ( IsLTT() );

		$nTriggerMode = $externalLTTChannelNo if ( IsLTT() );
		$lttTriggerFlag = 1;
	}

    # LTTsmart && TriggerDelay > 0 && SamplingFrequency < 125kHz => Warning
    if ( IsLTTsmart() && $TriggerDelay != 0 && $SamplingFrequency < 125 * 1000)
    {
        S_set_warning("TriggerDelay = $TriggerDelay %, SamplingFrequency = $SamplingFrequency Hz. If a TriggerDelay is specified, choose a SamplingFrequency >= 125 kHz, because below this frequency, the time deviation from trigger detected to begin of recording starts to increase and may lead to wrong time measurement results, depending on specified tolerances.");
    }

	if ( ( $lttTriggerFlag == 0 ) && IsLTT() ) {
		# No trigger configured (Use case: SW Trigger assumed)
		$slopeType = 0;
		$triggerVoltage = 0;
		S_set_warning("INFO: No HW-Trigger configured, only SW-Trigger possible");
	}

	#check whether TRC is initialized
	unless ($TRC_initialized) {
		S_set_error( "TRC not initialized", 120 );
		return 0;
	}

	# in offline mode, return without accessing hardware
	if ($main::opt_offline) {
		return 1;
	}

	# reset all the configurations that are previously done
	$status = trc_ClearChannelsAndSetDefaults();
	S_w2log( 4, "TRC ClearChannelsAndSetDefaults status = $status\n" );

	if ( $TRC_Type == 1 ) {

		#Sampling Frequency for MFTRC
		$SamplingFrequency = $aSamplingFrequency[$freqindex];

		#Memory size for MFTRC
		$MemorySize = 2**($memindex) * 1024;

		#configure gerneral settings of the TRC
		S_w2log( 4, "Configuring TRC General settings => Sampling frequency = $SamplingFrequency Hz, Memory Size = $MemorySize bytes, Trigger delay = $TriggerDelay %\n" );

		$status = mftrc_ConfigureTransi( $SamplingFrequency, $MemorySize, $TriggerDelay );
		Check_status($status);
		S_w2log( 4, "TRC ConfigureTransi status = $status\n" );

		#configure the available channels
		foreach my $channelName ( sort keys(%TRC_channels) ) {
			S_w2log( 4, "-> Configuring channel $channelName\n" );

			#save channel number to use for reporting
			$channelNumber = $TRC_channels{$channelName}{'ChannelNumber'};

			#for report logging
			$couplingMode = $config_source->{'CHANNELS'}{"CHANNEL$channelNumber"}{'CouplingMode'};
			$couplingMode = 'DC' unless ( defined($couplingMode) );    #default value for coupling mode

			$signalMode = $config_source->{'CHANNELS'}{"CHANNEL$channelNumber"}{'SignalMode'};

			S_w2log( 4, "Channel Number = $channelNumber, Coupling mode = '$couplingMode', Signal mode = '$signalMode',Voltage range = $TRC_channels{$channelName}{'VoltageRange'} V, Offset = $TRC_channels{$channelName}{'VoltageRange_Offset'} % \n" );

			$status =
			  mftrc_ConfigureRecordingChannel( $channelName, $TRC_channels{$channelName}{'ChannelNumber'}, $TRC_channels{$channelName}{'CouplingMode'}, $TRC_channels{$channelName}{'SignalMode'}, $TRC_channels{$channelName}{'VoltageRange'}, $TRC_channels{$channelName}{'VoltageRange_Offset'} );
			Check_status($status);
			S_w2log( 4, "TRC ConfigureRecordingChannel($channelName) status = $status\n" );

			#set trigger only if channel configuration is successful
			if ( $status >= 0 && exists( $TRC_channels{$channelName}{'TRIGGER'} ) ) {
				S_w2log( 4, "-> Configuring Trigger for channel $channelName\n" );

				$slopeType = $config_source->{'CHANNELS'}{"CHANNEL$channelNumber"}{'TRIGGER'}{'SlopeType'};

				S_w2log( 4, " Trigger voltage = $TRC_channels{$channelName}{'TRIGGER'}{'TriggerVoltage'} V,Hysteresis voltage = $TRC_channels{$channelName}{'TRIGGER'}{'HysteresisVoltage'} V, Slope type = '$slopeType'\n" );

				$status = mftrc_ConfigureTrigger( $channelName, $TRC_channels{$channelName}{'TRIGGER'}{'TriggerVoltage'}, $TRC_channels{$channelName}{'TRIGGER'}{'HysteresisVoltage'}, $TRC_channels{$channelName}{'TRIGGER'}{'SlopeType'} );
				Check_status($status);
				S_w2log( 4, "TRC ConfigureTrigger($channelName) status = $status\n" );
			}
		}

		#set external trigger, if configured
		if ( defined($externalTrigger) ) {

			#get the external trigger slope type and log
			$slopeType = $config_source->{'EXTERNAL_TRIGGER'}{'SlopeType'};

			S_w2log( 4, "Configuring External Trigger for TRC with '$slopeType' slope\n" );
			$status = mftrc_ConfigureTrigger( 'EXTERNAL', 0, 0, $externalTrigger );
			Check_status($status);
			S_w2log( 4, "TRC ConfigureTrigger('EXTERNAL') status = $status\n" );
		}
	}

	if ( IsLTT() ) {
		my $result;

		# Sampling Frequency for LTT. Array stored as time (i.e. inverse order in DLL)
		if ( IsLTT184() ) { $SamplingFrequency = 17 - $freqindex; }
		if ( IsLTTsmart() ) { $SamplingFrequency = 18 - $freqindex; }
		$MemorySize        = $memindex;
		( $result, $UsedSamplingFrequency ) = ltttrc_GetSampleTimeByIndex($SamplingFrequency);
		( $result, $UsedMemorySize )        = ltttrc_GetMemorySizeByIndex($MemorySize);
		$UsedMemorySize = $UsedMemorySize * 1024;    # byte conversion

		#configure gerneral settings of the TRC
		S_w2log( 4,
"Configuring TRC General settings => Number Of Channels => $nNoofchannels, Sampling Frequency in [Hz] => $aSamplingFrequency[$freqindex], Memory Size in bytes=> $UsedMemorySize, Trigger Channel => $nTriggerMode, Trigger delay = $TriggerDelay %, TriggerCoupling = $nTriggerCoupling, TriggerSlope = $slopeType, TriggerVoltage= $triggerVoltage \n"
		);

        # if external / digital trigger
        if ( $nTriggerMode > 32 ) {
            $slopeType = $extslopeType;
            $triggerVoltage = 2.5; # middle of TTL level
        }
        
		#configure the available channels
		$status = ltttrc_ConfigureRecordingChannel( $nNoofchannels, $SamplingFrequency, $MemorySize, $nTriggerMode, $nTriggerCoupling, $slopeType, $triggerVoltage, $TriggerDelay, \@aChannelnumber, \@achannelOn, \@achannelRange, \@achannelCoupling );
	}

	#if status is -ve, print error log
	if ( $status < 0 ) {
		S_set_error( "could not initialize TRC", 5 );
		$TRC_initialized = 0;
	}

	return 1;
}

=head2 TRC_plot_values

    TRC_plot_values($plotfilename [, $minWaitTime_ms]);

Plots the recorded signals for All the configured MF / LTT TRC channels only into UNIVIEW formatted file. (data with semi-colon seperated format)

	$plotfilename : the file name for the UNIVIEW plot
	$minWaitTime_ms : Optional wait time to wait for data to be recorded in Transient recorder (used for fail-safe measurement)

=cut

sub TRC_plot_values {
	my $plotfilename   = shift;
	my $minWaitTime_ms = shift;

	unless ( defined($plotfilename) ) {
		S_set_error( "! too less parameters ! SYNTAX: TRC_plot_values( \$data_HoH )", 110 );
		return 0;
	}

	#wait time sould not be negative
	if ( defined($minWaitTime_ms) && $minWaitTime_ms < 0 ) {
		S_set_error( "parameter \$minWaitTime_ms should be > 0", 114 );
		return 0;
	}

	#minimum wait time is 0, if not given
	$minWaitTime_ms = 0 unless ( defined($minWaitTime_ms) );

	unless ($TRC_initialized) {
		S_set_error( "TRC not initialized", 120 );
		return 0;
	}

	S_w2log( 1, "TRC_plot_values\n" );

	if ($main::opt_offline) {

		#create dummy pictures and return
		#S_create_dummy_pic($plotfilename);
		S_create_dummy_file($plotfilename);
		return 1;
	}

	#call the DLL function to create UNIVIEW plot for all configured channels
	$status = trc_PlotUNVForAllChannels( $plotfilename, $minWaitTime_ms );
	S_w2log( 4, "TRC PlotUNV For AllChannels status=$status\n" );

	if ( $status == -39 ) {
		my $errortext = trc_GetErrorString($status);
		S_set_warning("TRC ($status): $errortext");
	}
	else { Check_status($status); }

	#report success or failure
	if ( $status >= 0 ) {
		S_w2log( 1, "UNIVIEW plot \"$plotfilename\" is created\n" );
	}
	else {
		S_set_error( "Unable to create the UNIVIEW plot \"$plotfilename\"", 5 ) if ( $status != -39 );
		return 0;
	}

	#return 1 if nothing has failed
	return 1;
}

=head2 TRC_SendSWTrigger

    TRC_SendSWTrigger();

Triggers the Transient recorder by software. The transient recorder starts recording as soon as it gets the software trigger.
Measurement should be already started (by L</"TRC_StartMeasurement">()) before calling this function.

	e.g.;

		TRC_SendSWTrigger();

=cut

sub TRC_SendSWTrigger {
	unless ($TRC_initialized) {
		S_set_error( "TRC not initialized", 120 );
		return 0;
	}

	S_w2log( 1, "TRC_SendSWTrigger\n" );

	if ($main::opt_offline) {
		return 1;
	}

	#send trigger via Software
	$status = trc_SendSWTrigger();
	Check_status($status);
	S_w2log( 4, "TRC SendSWTrigger status=$status\n" );

	return 0 if ( $status < 0 );

	#return 1 if nothing has failed
	return 1;
}

=head2 TRC_StartMeasurement

    TRC_StartMeasurement();

starts a new measurement and waits for trigger.
Until one of the configured trigger or Software trigger(refer L</"TRC_SendSWTrigger">()) is obtained , the Transient recorder will not start recording.

	e.g.;

		 TRC_StartMeasurement();

=cut

sub TRC_StartMeasurement {

	#check whether TRC is initialized
	unless ($TRC_initialized) {
		S_set_error( "TRC not initialized", 120 );
		return 0;
	}

	S_w2log( 1, "TRC_StartMeasurement\n" );

	#return 1 in offline mode
	if ($main::opt_offline) {
		return 1;
	}

	#start measurement
	$status = trc_InitNewMeasurement();
	Check_status($status);
	S_w2log( 4, "TRC StartMeasurement status=$status\n" );

	return 0 if ( $status < 0 );

	#return 1 if nothing has failed
	return 1;
}

=head2 TRC_StopMeasurement

    TRC_StopMeasurement();

stops the already running measurement, if any.
If measurement is not running, no error will be returned.
Note : # Before calling TRC_ConfigureChannels(), TRC_StopMeasurement() must be called if measurement is in progress state.
	e.g.;

		 TRC_StopMeasurement();

=cut

sub TRC_StopMeasurement {

	#check whether TRC is initialized
	unless ($TRC_initialized) {
		S_set_error( "TRC not initialized", 120 );
		return 0;
	}

	S_w2log( 1, "TRC_StopMeasurement\n" );

	#return 1 in offline mode
	if ($main::opt_offline) {
		return 1;
	}

	#stop measurement
	$status = trc_StopMeasurement();
	Check_status($status);
	S_w2log( 4, "TRC StopMeasurement status=$status\n" );

	return 0 if ( $status < 0 );

	#Return 1 if nothing has failed
	return 1;
}

=head1 not exported functions

=head2 Check_status

 Check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub Check_status {
	$status = shift;

	return 1 if $main::opt_offline;
	if ( $status < 0 ) {
		my $errortext = trc_GetErrorString($status);
		S_set_error( "TRC ($status): $errortext", 5 );

	}
	return 1;

}

=head2 CompressConstantData

    ($times_comressed_aref, $values_compressed_aref) = CompressConstantData( $times_aref, $values_aref, $constantValueThreshold, $dataCompressionFactor );

Perform a data reduction algorithm on the data in $values_aref:

Data point #n is the so called reference data point. The difference of data point #n+1 and the reference point is calculated. 
If the difference is <= $constantValueThreshold then we remove the data point #n+1 and continue with the next data point (#n+2) and so on. 
If for one data point (#n+x) the difference is > $constantValueThreshold then this data point is the new reference point, 
we include the previously removed data point (#n+x-1) again and we start the algorithm again from the new reference point.
When we have removed $dataCompressionFactor-1 data points in a row then we set a new referenve point and start the algorithm again.
I.e. for $dataCompressionFactor = 10 up to 9 of 10 data points are removed, 
depending on the differences between the values and the value of $constantValueThreshold.

For each removed data value in $values_aref, also the corresponding time value in $times_aref will be removed.

Examples:

For

    $times_aref  = [ 1,   2,   3,   4,   5,   6,   7,   8,   9,   10  ];
    $values_aref = [ 1.0, 1.1, 1.3, 1.1, 1.2, 2.0, 1.0, 3.0, 3.1, 3.0 ];

the following call

    ($times_comressed_aref, $values_compressed_aref) = CompressConstantData( $times_aref, $values_aref, 0.5, 10 ); 

will result in:

    $times_comressed_aref   = [ 1,   5,   6,   7,   8  ];
    $values_compressed_aref = [ 1.0, 1.2, 2.0, 1.0, 3.0 ];

=cut

sub CompressConstantData {
	my @args = @_;
	return ( [], [] ) unless S_checkFunctionArguments( 'CompressConstantData( $times_aref, $values_aref, $constantValueThreshold, $dataCompressionFactor )', @args );
	my $times_aref             = shift @args;
	my $values_aref            = shift @args;
	my $constantValueThreshold = shift @args;
	my $dataCompressionFactor  = shift @args;

	my $timeSize  = $#$times_aref + 1;
	my $valueSize = $#$values_aref + 1;
	if ( $valueSize != $timeSize ) {
		S_set_error( "Value array (\$values_aref) and time array (\$times_aref) differ in size: $valueSize values but $timeSize times\n", 114 );
		return ( [], [] );
	}
	if ( $constantValueThreshold <= 0 ) {
		S_set_error( "\$constantValueThreshold is $constantValueThreshold but it must be > 0\n", 114 );
		return ( [], [] );
	}

	if ( $dataCompressionFactor < 2 ) {
		S_set_error( "\$dataCompressionFactor is $dataCompressionFactor but it must be >= 2\n", 114 );
		return ( [], [] );
	}

	my ( @compressedTimes, @compressedValues, $lastTime, $lastValue );
	my $referenceValue = -1e99;
	my $removalCounter = 0;
	my $index          = 0;
	while ( $index < $timeSize ) {    # while-loop is used on purpose (instead of foreach) to avoid creating a possibly huge time array
		my $time  = $$times_aref[$index];
		my $value = $$values_aref[$index];

		if ( abs( $value - $referenceValue ) <= $constantValueThreshold and $removalCounter < $dataCompressionFactor - 1 ) {
			$removalCounter++;
		}
		else {
			if ( abs( $value - $referenceValue ) > $constantValueThreshold and $removalCounter > 0 ) {

				# special case: if a data point is used because the value difference is over the threshold ($removalCounter < $dataCompressionFactor-1)
				# and some data points have been removed before ($removalCounter > 0) we have to add the last data point to the output lists
				# so that the time information about the data jump is not lost
				push( @compressedTimes,  $lastTime );
				push( @compressedValues, $lastValue );
			}
			push( @compressedTimes,  $time );
			push( @compressedValues, $value );
			$referenceValue = $value;
			$removalCounter = 0;
		}
		$lastTime  = $time;
		$lastValue = $value;
		$index++;
	}
	return ( \@compressedTimes, \@compressedValues );
}

=head2 AddArray2HoH

    AddArray2HoH( $hoh_href, $signalName, $times_aref, $values_aref [, $constantValueThreshold, $dataCompressionFactor ] );

Take $times_aref and $values_aref and sort the data into the given HoH structure $hoh_href with the given signal name $signalName.
If $constantValueThreshold is given then $times_aref and $values_aref are compressed using CompressConstantData L</"CompressConstantData">
before being sorted into $hoh_href.
$dataCompressionFactor is also needed for data compression. If not given then 1E7 is used as default.

=cut

sub AddArray2HoH {
	my @args = @_;
	return {} unless S_checkFunctionArguments( 'AddArray2HoH( $hoh_href, $signalName, $times_aref, $values_aref [, $constantValueThreshold, $dataCompressionFactor ] )', @args );

	my $hoh_href               = shift @args;
	my $signalName             = shift @args;
	my $times_aref             = shift @args;
	my $values_aref            = shift @args;
	my $constantValueThreshold = shift @args;
	my $dataCompressionFactor  = shift @args;

	$dataCompressionFactor = 1E7 if not defined $dataCompressionFactor;    # maximum compression factor, determined by the maximum possible number of points (MF with memory size 8MB)

	# do data compression if $constantValueThreshold is defined, otherwise use data directly
	my ( $timesUsed_aref, $valuesUsed_aref );
	if ( defined $constantValueThreshold ) {
		( $timesUsed_aref, $valuesUsed_aref ) = CompressConstantData( $times_aref, $values_aref, $constantValueThreshold, $dataCompressionFactor );
	}
	else {
		$timesUsed_aref  = $times_aref;
		$valuesUsed_aref = $values_aref;
	}

	# lop over all times and sort the values into $hoh_href
	my $timeIndex = 0;
	foreach my $time ( @{$timesUsed_aref} ) {
		my $value = $$valuesUsed_aref[$timeIndex];

		if ( not defined $value ) {
			S_set_error( "Undefined value for signal $signalName at index $timeIndex !\n", 114 );
			return 0;
		}

		$hoh_href->{$time}{$signalName} = $value;
		$timeIndex++;
	}

	return 1;
}

# TRC type numbers:
# 1 : MFTRC
# 2 : LTT
# 3 : LTT_oW
# 4 : LTTsmart_oW
# 5 : LTTsmart (NOT IMPLEMENTED, only a placeholder)
sub IsLTT
{
	return $TRC_Type == 2 || $TRC_Type == 3 || $TRC_Type == 4 || $TRC_Type == 5;
}

# TRC type numbers:
# 1 : MFTRC
# 2 : LTT
# 3 : LTT_oW
# 4 : LTTsmart_oW
# 5 : LTTsmart (NOT IMPLEMENTED, only a placeholder)
sub IsLTT184
{
    return $TRC_Type == 2 || $TRC_Type == 3;
}

# TRC type numbers:
# 1 : MFTRC
# 2 : LTT
# 3 : LTT_oW
# 4 : LTTsmart_oW
# 5 : LTTsmart (NOT IMPLEMENTED, only a placeholder)
sub IsLTTsmart
{
    return $TRC_Type == 4 || $TRC_Type == 5;
}

# TRC type numbers:
# 1 : MFTRC
# 2 : LTT
# 3 : LTT_oW
# 4 : LTTsmart_oW
# 5 : LTTsmart (NOT IMPLEMENTED, only a placeholder)
sub IsLTTsmart_oW
{
    return $TRC_Type == 4;
}

#return 1 (default for all perl modules)
1;

__END__

=head1 AUTHOR

Manikandan C, E<lt>Manikandan.C@in.bosch.comE<gt>


=head1 SEE ALSO

Low level MF / LTT TRC module

Airbags MLC Support Mailbox, E<lt>Airbags.MLCSupport@in.bosch.comE<gt>

=cut
