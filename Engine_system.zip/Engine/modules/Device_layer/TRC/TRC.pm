package TRC;

use 5.006000;
use strict;
use warnings;
use Win32::OLE;
use Win32::OLE::Variant;
use LIFT_simulation;

use constant MAX_DOUBLE_DATA => ( 8 * 1024 * 1024 );

#my $array_record_data_OLEvariant = Variant(VT_ARRAY| VT_R8 | VT_BYREF, MAX_DOUBLE_DATA);
my $obj;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use TRC ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  trc_getPMrevision
  trc_SetType
  trc_SetFlagPrintDbgInfosEnabled
  trc_GetDLLVersion
  trc_InitTRC
  trc_ExitTRC
  trc_Start
  trc_End
  trc_GetDeviceDetails
  trc_SendSWTrigger
  trc_InitNewMeasurement
  trc_StopMeasurement
  trc_GetRecordedData
  trc_PlotUNVForAllChannels
  trc_ClearChannelsAndSetDefaults
  trc_GetErrorString
  mftrc_ConfigureTransi
  mftrc_ConfigureRecordingChannel
  mftrc_ConfigureTrigger
  ltttrc_ConfigureRecordingChannel
  ltttrc_ConfigureChannelNames
  ltttrc_GetSampleTimeByIndex
  ltttrc_GetSampleTime_s
  ltttrc_GetMemorySizeByIndex
  ltttrc_GetTriggerDelay
);

our $VERSION = '0.01';

my $trc_manager_dll_out_of_process = 0;

my $iMemorysize = 64 * 1024;

#
# simulation functions start here
#

if ($main::opt_simulation) {
    no strict 'refs';

    # redefine all functions for simulation mode with default return values
    foreach my $function (@EXPORT) {

        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
        'trc_GetDeviceDetails' => { 'default' => [ 1, 1, 1, 1, 32, 1, 1 ] },
        'trc_GetRecordedData' => { 'default' => [ 1, [ 1, 2, 3, 4, 5 ], 5 ] },
        'ltttrc_GetSampleTimeByIndex' => { 'default' => [ 1, 1000 ] },
        'ltttrc_GetSampleTime_s' => { 'default' => [ 1, 0.001 ] },
        'ltttrc_GetMemorySizeByIndex' => { 'default' => [ 1, 10 ] },
    };
    SIM_addToValuesTable($returnValuesTable_href);

}

# Preloaded methods go here.

sub trc_getPMrevision {
    return ('SCM');
}

sub mftrc_getXSrevision {

    return (0);
}

sub mftrc_getCWrevision {
    return (0);
}

sub trc_SetType {

    #Set the Type of TRC used
    my $nType             = shift;
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    my $hr                = Win32::OLE->LastError( $obj->SetTRCType( $nType, $result_OLEvariant ) );
    return ($result_OLEvariant);

}

sub trc_SetFlagPrintDbgInfosEnabled {
    my $flagEnableDebugLogFile = shift;
    my $snapshot_directory     = shift;
    my $result_OLEvariant      = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->LogFile_Enable( $flagEnableDebugLogFile, $snapshot_directory, $result_OLEvariant );
    return ($result_OLEvariant);
}

sub trc_GetDLLVersion {

    #get the version of Low level dll and log it
    my $dllversion = Variant( VT_BSTR | VT_BYREF );
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->GetDLLVersion( $dllversion, $result_OLEvariant );
    return ( $result_OLEvariant, $dllversion );
}

sub trc_InitTRC {

    #Intialize the Selected TRC.
    my $IPaddress = shift;
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->InitTRC( $IPaddress, $result_OLEvariant );
    return ($result_OLEvariant);
}

sub ltttrc_ConfigureChannelNames {

    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    my $ChannelName = shift; 
    my $nChannelid = shift; 
       $obj->ConfigureLTTRecordingChannels( $ChannelName, $nChannelid, $result_OLEvariant );
    return ($result_OLEvariant);
}

sub trc_GetDeviceDetails {

    # to Get the connected device details

    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    my $caDeviceId        = Variant( VT_BSTR | VT_BYREF );
    my $caServerSWVersion = Variant( VT_BSTR | VT_BYREF );
    my $caMACAddress      = Variant( VT_BSTR | VT_BYREF );
    my $nNumOfChannels    = Variant( VT_I4 | VT_BYREF, 0 );
    my $nMaxMemory_samples   = Variant( VT_I4 | VT_BYREF, 0 );
    my $nMaxSpeed_Hz      = Variant( VT_I4 | VT_BYREF, 0 );
    $obj->GetDeviceDetails( $caDeviceId, $caServerSWVersion, $caMACAddress, $nNumOfChannels, $nMaxMemory_samples, $nMaxSpeed_Hz, $result_OLEvariant );
    return ( $result_OLEvariant, $caDeviceId, $caServerSWVersion, $caMACAddress, $nNumOfChannels, $nMaxMemory_samples, $nMaxSpeed_Hz );
}

sub trc_InitNewMeasurement {

    # set start postion
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->InitNewMeasurement($result_OLEvariant);
    return (0); # only with MF and channel trigger defined InitNewMeasurement returns -32 even though the measurement is actually started, therefore we ignore the return value and return 0 here until this is fixed in the dll
    #return ($result_OLEvariant);
}

sub trc_SendSWTrigger {

    #Send software trigger
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->SendSWTrigger($result_OLEvariant);
    return ($result_OLEvariant);
}

sub trc_StopMeasurement {

    #Stops the measurement
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->StopMeasurement($result_OLEvariant);
    return ($result_OLEvariant);
}

sub trc_GetRecordedData {
    my $channel = shift;
    my $time    = shift;

    # get the Data from the recorded channels.
    my $result_OLEvariant               = Variant( VT_I4 | VT_BYREF, -1 );
    my $channelname_OLEvariant          = Variant(VT_BSTR);
    my $array_record_data_OLEvariant    = Variant( VT_VARIANT | VT_BYREF );
    my $narray_size_OLEvariant          = Variant( VT_I4 | VT_BYREF, 0 );
    my $nnMinimumWaitTime_ms_OLEvariant = Variant( VT_I4, 0 );

    $channelname_OLEvariant          = $channel;    # operator '=' is overloaded: here the value of the OLE variant object is set
    $nnMinimumWaitTime_ms_OLEvariant = $time;       # operator '=' is overloaded: here the value of the OLE variant object is set

    $obj->GetRecordedData( $channelname_OLEvariant, $array_record_data_OLEvariant, $narray_size_OLEvariant, $nnMinimumWaitTime_ms_OLEvariant, $result_OLEvariant );

    my $data_aref = $array_record_data_OLEvariant->Value();    # for an array reference the method Value has to be used explicitly to get the whole array reference

    $obj->FreeRecordedData($result_OLEvariant);

    undef $array_record_data_OLEvariant;

    return ( $result_OLEvariant, $data_aref, $narray_size_OLEvariant );    # OLE variant objects that are passed as return values are implicitly cast to scalar if the calling function uses scalars

}

sub trc_ExitTRC {
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->ExitTRC($result_OLEvariant);
    return ($result_OLEvariant);
}

sub trc_Start {
    $obj = Win32::OLE->Initialize(Win32::OLE::COINIT_MULTITHREADED);

    if ( $trc_manager_dll_out_of_process )
    {
        $obj = Win32::OLE->new('TRC_Manager_NET.InfcOopSrv32_v1.0.0.0') or die "TRC_Manager_NET.dll Not registred, Execute _run_once.bat.\n";        
    }   
    else
    {
        $obj = Win32::OLE->new('TRC_Manager.MFTRC') or die "TRC_Manager.dll Not registred, Execute _run_once.bat.\n";        
    } 
    
    return (0);
}

sub trc_End {
 my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );

	$obj->FreeUnusedLibraries();
	$obj->Uninitialize();
	undef $obj;	
    my $val = 0;
    $result_OLEvariant = $val;
    return ($result_OLEvariant);
}

sub trc_ClearChannelsAndSetDefaults {
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->ClearChannelsAndSetDefaults($result_OLEvariant);
    return ($result_OLEvariant);
}

sub ltttrc_GetSampleTimeByIndex {
    my $indexs = shift; 
    my $samplerate        = Variant( VT_R8 | VT_BYREF, 0 );
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->GetSampleTimeByIndex( $indexs, $samplerate, $result_OLEvariant );
    return ( $result_OLEvariant, $samplerate );
}

sub ltttrc_GetSampleTime_s {
    my $sampleTime_s        = Variant( VT_R8 | VT_BYREF, 0 );
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->GetSampleTime_s( $sampleTime_s, $result_OLEvariant );
    return ( $result_OLEvariant, $sampleTime_s );    
}

sub ltttrc_GetMemorySizeByIndex {
    my $index = shift; 
    my $memorysize        = Variant( VT_I4 | VT_BYREF, 0 );
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->GetMemorySizeByIndex( $index, $memorysize, $result_OLEvariant );
    return ( $result_OLEvariant, $memorysize );
}

sub ltttrc_GetTriggerDelay {
	my $TriggerDelay      = Variant( VT_R8 | VT_BYREF, 0 );
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
	$obj->GetTriggerDelay($TriggerDelay, $result_OLEvariant);
	return ( $result_OLEvariant, $TriggerDelay );
}
sub mftrc_ConfigureTransi {

    my $nSamplingFrequency = shift; 
    my $nMemorySize        = shift; 
    my $dTriggerDelay      = shift; 
	
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->ConfigureTransi( $nSamplingFrequency, $nMemorySize, $dTriggerDelay, $result_OLEvariant );
    $iMemorysize = $nMemorySize;
    print "Memory Size:" . $iMemorysize;
    return ($result_OLEvariant);
}

sub mftrc_ConfigureRecordingChannel {

    my $caChannelName       = shift; 
    my $nInputChannelNumber = shift; 
    my $nInputCouplingMode  = shift; 
    my $nInputSignalMode    = shift; 
    my $dInputVoltageRange  = shift; 
    my $dInputOffset        = shift; 

    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->ConfigureRecordingChannel( $caChannelName, $nInputChannelNumber, $nInputCouplingMode, $nInputSignalMode, $dInputVoltageRange, $dInputOffset, $result_OLEvariant );
    return ($result_OLEvariant);

}

sub mftrc_ConfigureTrigger {

    my $caTriggerChannelName = shift; 
    my $dTriggerVoltage      = shift; 
    my $dHysterisis          = shift; 
    my $nSlopeType           = shift; 

    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->ConfigureTrigger( $caTriggerChannelName, $dTriggerVoltage, $dHysterisis, $nSlopeType, $result_OLEvariant );

    return ($result_OLEvariant);
}

sub trc_PlotUNVForAllChannels {

    my $caUNVPath = shift; 
    my $nMinimumWaitTime_ms = shift; 
    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->PlotUNVForAllChannels( $caUNVPath, $nMinimumWaitTime_ms, $result_OLEvariant );
    return ($result_OLEvariant);

}

sub trc_GetErrorString {

    my $Errorstring = Variant( VT_BSTR | VT_BYREF );

    my $nErrorCode = shift;

    $obj->GetErrorString($nErrorCode, $Errorstring);
    return ($Errorstring);
}

sub ltttrc_ConfigureRecordingChannel {

    my $vnOfChannels     = shift;
    my $vsampleRate      = shift;
    my $vmemorySize      = shift;
    my $vtriggerMode     = shift;
    my $vtriggerCoupling = shift;
    my $vtriggerEdge     = shift;
    my $vtriggerLevel    = shift;
    my $vtriggerDelay    = shift;

    my $channelNumsref     = shift;
    my $channelOnref       = shift;
    my $channelRangeref    = shift;
    my $channelCouplingref = shift;
    
    my $vchannelNums     = Variant( VT_ARRAY | VT_I4, $vnOfChannels );
	$vchannelNums->Put( $channelNumsref );
    my $vchannelOn       = Variant( VT_ARRAY | VT_I4, $vnOfChannels );
    $vchannelOn->Put( $channelOnref );
    my $vchannelRange    = Variant( VT_ARRAY | VT_I4, $vnOfChannels );
    $vchannelRange->Put( $channelRangeref );
    my $vchannelCoupling = Variant( VT_ARRAY | VT_I4, $vnOfChannels );
    $vchannelCoupling->Put( $channelCouplingref);

    my $result_OLEvariant = Variant( VT_I4 | VT_BYREF, -1 );
    $obj->ConfigureLTT( $vnOfChannels, $vchannelNums, $vchannelOn, $vchannelRange, $vchannelCoupling, $vsampleRate, $vmemorySize, $vtriggerMode, $vtriggerCoupling, $vtriggerEdge, $vtriggerLevel, $vtriggerDelay, $result_OLEvariant );
    my $result = 0;
    ( $result, $iMemorysize ) = ltttrc_GetMemorySizeByIndex($vmemorySize);
    $iMemorysize = $iMemorysize * 1024;    # Byte conversion
    return ($result_OLEvariant);
}

1;
__END__
# Below is TRC OLE documentation for your module. You'd better edit it!

=head1 NAME

TRC - Perl extension for TRC_Manager.dll (Low level control DLL for MF transcom transient recorder & LTT)

=head1 SYNOPSIS
  
  # Example code for MFTRC  
  use TRC;
  my ($status, $version, $data_aref,$data_size); 
  my ($DeviceId, $ServerSWVersion, $MACAddress, $NumOfChannels, $MaxMemory_byte, $MaxSpeed_Hz);
  
  $status = trc_SetType(1);  # MFTRC:1
  $status = trc_Start();
  ($status, $version) = trc_GetDLLVersion();  
  
  $status = trc_InitTRC('10.40.5.18:10010');
  ($status, $DeviceId, $ServerSWVersion, $MACAddress, $NumOfChannels, $MaxMemory_byte, $MaxSpeed_Hz) = trc_GetDeviceDetails();
  
  $status = mftrc_ConfigureTransi(1000000 , 2097152, -30);	# 1MHz, 2MB, -30%
  
  $status = mftrc_ConfigureRecordingChannel("AB1FD", 2, 2, 2, 5, 0);	# (2, 2, 2, 5, 0) = CHANNEL-2, DC coupling, Differential, 5V range, 0% offset
  $status = mftrc_ConfigureRecordingChannel("BT1FD", 5, 2, 2, 10, 10);	# (5, 2, 2, 5, 0) = CHANNEL-5, DC coupling, Differential, 10V range, 10% offset
  
  $status = mftrc_ConfigureTrigger("AB1FD", 3.5, 3.0, 1);	#3.5V trigger voltage, 3V Hysteresis, +ve slope
  $status = mftrc_ConfigureTrigger("EXTERNAL", 0, 0, 2);	#-ve slope TTL external trigger
  
  $status = trc_InitNewMeasurement();
  sleep(2);
  
  $status = trc_SendSWTrigger();
  ($status, $data_aref, $data_size) = trc_GetRecordedData("AB1FD", 5000);	# wait 5 seconds and retrieve the data
  
  $status = trc_PlotUNVForAllChannels('C:\\TRC_UNVPlot.txt.unv', 2000);
  
  $status = trc_StopMeasurement();	# stop measurement incase if it is running
  
  $status = trc_End();
  
 
=head1 SYNOPSIS_LTT


  # Example code for LTT  
  use TRC;
  my ($status, $version, $data_aref,$data_size); 
  my ($ChannelName, $nNoofchannels, $SamplingRate, $MemorySize, $TriggerMode,$TriggerCoupling,$TriggerEdge,$TriggerLevel,$TriggerDelay);
  my @aChannelnumber = () ; # array to hold required recording channel numbers.
  my @achannelOn = (); # array to hold on or off state of channels.
  my @achannelRange= ();  # array to hold range of configured channels.
  my @achannelCoupling = ();  # array to hold coupling of configured channels.
  my ($ChannelName, $channelNumber);
	
  $status = trc_SetType(2);  # LTT:2
  $status = trc_Start();
  ($status, $version) = trc_GetDLLVersion();  
  
  $status = trc_InitTRC('10.40.5.18:10010'); # IP=> dummy value for LTT
  ($status, $DeviceId, $ServerSWVersion, $MACAddress, $NumOfChannels, $MaxMemory_byte, $MaxSpeed_Hz) = trc_GetDeviceDetails();
  
  $status = ltttrc_ConfigureRecordingChannel(2, 13, 9, 2, 0, 1, 5.0, 0,  # (2, 13, 9, 2, 0, 1, 5.0, 0 ) =  CHANNEL-2, 16ms, 1024kb, trigger channel 2,not used,rising,5V range, 0% offset
	          \@aChannelnumber, \@achannelOn,  \@achannelRange,  \@achannelCoupling);
 
  $status = ltttrc_ConfigureChannelNames("AB1FD", 2); 
  
  $status = trc_InitNewMeasurement();
  sleep(2);
  
  $status = trc_SendSWTrigger();
  ($status, $data_aref, $data_size) = trc_GetRecordedData("AB1FD", 5000);	# wait 5 seconds and retrieve the data
  
  $status = trc_PlotUNVForAllChannels('C:\\TRC_UNVPlot.txt.unv', 2000);
  
  $status = trc_StopMeasurement();	# stop measurement incase if it is running
  
  $status = trc_End();


=head1 DESCRIPTION

The functions in this module are given as a Perl wrapper for the functions available in TRC_Manage.dll.
Refer to the User manual of TRC_Manager.dll for further information about parameter details and validation ideas.

=head2 mftrc_ConfigureRecordingChannel

	$status = mftrc_ConfigureRecordingChannel($ChannelName, $InputChannelNumber, $InputCouplingMode, $InputSignalMode, $InputVoltageRange, $InputOffset);


To configure a recording channel

	$ChannelName 		:	should be unique name (the name "EXTERNAL" is reserved (refer mftrc_ConfigureTrigger()) and shall not be used as a channel name)
	$InputChannelNumber	:	1 to Maximum allowed channels for connected TRC
	$InputCouplingMode	:	1 = AC, 2 = DC
	$InputSignalMode	:	1 = single-ended, 2 = differential
	$InputVoltageRange	:	one of 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100 (in volts)
	$InputOffset		:	0 to 100%

=head2 mftrc_ConfigureTransi

	$status = mftrc_ConfigureTransi($SamplingFrequency, $MemorySize, $TriggerDelay);

sets the sampling frequency, memory size for recording, trigger delay for the connected MF TransCom.
In Addition, refer to default TRC configuration (L</"mftrc_InitTRC">)

	$SamplingFrequency	:	in Hz
	$MemorySize		:	in bytes
	$TriggerDelay		:	in %

=head2 mftrc_ConfigureTrigger

	$status = mftrc_ConfigureTrigger($TriggerChannelName, $TriggerVoltage, $Hysterisis, $SlopeType);

To configure a recording channel as a Trigger, or External trigger.

	$TriggerChannelName	:	If channel name is given, it should be already configured for recording or use "EXTERNAL" for external trigger
	$TriggerVoltage		: 	voltage level for the trigger (not necessary for external trigger) in Volts
	$Hysterisis		:	Filtering (or protection) voltage level for trigger (not necessary for external trigger) in Volts
	$SlopeType		:	1 = positive, 2 = negative

Two or more trigger shall also be configured. In this case, all the trigger conditions will be OR-ed (TRC will be triggered if anyone of the trigger is obtained).

=head2 trc_End
	
	$status = trc_End();

Unloads the loaded DLL from process memory and deletes all function pointers.

=head2 trc_ExitTRC

	$status = trc_ExitTRC();

Removes all the configured channels and removes all the configuration details.

=head2 trc_GetDLLVersion

	($status, $version) = trc_GetDLLVersion();

returns version of TRC_Manager.dll 

=head2 trc_GetDeviceDetails

	($status, $DeviceId, $ServerSWVersion, $MACAddress, $NumOfChannels, $MaxMemory_byte, $MaxSpeed_Hz) = trc_GetDeviceDetails();

returns Device internal details for the connected MF Transient recorder or LTT.

=head2 trc_GetErrorString

    $errortext = trc_GetErrorString($status);

To get error string, if $status < 0

=head2 trc_GetRecordedData

	($status, $data_aref, $data_size) = trc_GetRecordedData($ChannelName, $MinimumWaitTime_ms);

Returns the recorded data from previous measurement. If succeeded, $status will contain the number of signals & $data_aref will contain the recorded signals.

=head2 trc_PlotUNVForAllChannels

	$status = trc_PlotUNVForAllChannels($FileName, $MinimumWaitTime_ms);

Plots all the recorded signals of configured channels into a File with semi-colon seperated format (like .csv files).

=head2 trc_InitNewMeasurement

	$status = trc_InitNewMeasurement();

Initialize new measurement and wait for trigger

=head2 trc_SetType

	$status = trc_SetType(1); MFTRC:1, LTT:2

To set the Transi type as 1(MFTRC) or 2(LTT)

This function should be called before using any other functions (refer to example in L</"SYNOPSIS">)

=head2 trc_InitTRC

	$status = trc_InitTRC($IPAddress);

Initializes the  Transient recorder with default settings. 

By Default,

	* All recording channels will be set to OFF
	* All triggers will be OFF
	* Default sampling frequency = 0.1 MHz, Memory size = 64KB, Trigger delay = -25%  for MFTRC
	(records approximately 655 milliseconds)

=head2 trc_SendSWTrigger

	$status = trc_SendSWTrigger();

Sends a trigger by Software, if the measurement is already started and waiting for trigger.
If the measurement is not started, this function returns error.

=head2 trc_Start

	$status = trc_Start();

Loads the TRC_Manager.dll into Memory of the loading process. Initializes all function pointers for the low level DLL.
This function must be called next to trc_SetType (refer to example in L</"SYNOPSIS">)

=head2 trc_StopMeasurement

	$status = trc_StopMeasurement();

stops the on-going measurement

=head2 ltttrc_ConfigureRecordingChannel

	$status = ltttrc_ConfigureRecordingChannel($nNoofchannels, $SamplingRate, $MemorySize, $TriggerMode, $TriggerCoupling,  
	           $TriggerEdge, $TriggerLevel, $TriggerDelay,\@aChannelnumber, \@achannelOn,  \@achannelRange,  \@achannelCoupling);
		
To Configure the LTT recording channels.

	$nNoofchannels    : Number of channels to be configured
	$SamplingRate     : Sampling rate (0 - 17)
	$MemorySize       : Memory size in KB (0 - 11)
	$TriggerMode      : Trigger channel number
	$TriggerCoupling  : Not in use
	$TriggerEdge      : 0: falling, 1: rising
	$TriggerLevel     : Volts
	$TriggerDelay     : percentage of the memorySize
	\@aChannelnumber  : 32 + 8 # upto 32 analog / 32 >  digital channel
	\@achannelOn      : 0: channel out, 1: channel on
	\@achannelRange   : in mV (0 - 11)
	\@achannelCoupling: (0 - 6)

	
=head2 ltttrc_GetSampleTimeByIndex

	($res,$SamplingFrequency) = ltttrc_GetSampleTimeByIndex($SamplingFrequencyindex);
	
To get the sampling time by gien index for the configured channel from dll.
	
	$SamplingFrequencyindex : index of samplingfrequency


=head2 ltttrc_GetSampleTime_s

    ($res, $SampleTime_s) = ltttrc_GetSampleTime_s();
    
To get the used sampling time in seconds from dll.


=head2 ltttrc_GetMemorySizeByIndex

	($res,$MemorySize) =  ltttrc_GetMemorySizeByIndex($Memoryindex); 

To get the Memory size by given index for the configured channel from dll

	$Memoryindex : index of memory.


=head2 ltttrc_ConfigureChannelNames

	$status = ltttrc_ConfigureChannelNames($ChannelName, $channelNumber);

Store the Configured Recording channel number and name to the dll.

	$ChannelName  : Channel to be recorded
	$channelNumber: Channel number.
	
=head1 TRACEABILITY FUNCTIONS

=head2 mftrc_getPMrevision

returns MKS revision number of .pm file

=head1 AUTHOR

Manikandan C, E<lt>Manikandan.C@in.bosch.comE<gt>


=head1 SEE ALSO

perl, TRC_Manager.dll User Manual

=cut
