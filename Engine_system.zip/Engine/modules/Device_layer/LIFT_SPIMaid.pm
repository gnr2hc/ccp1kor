# *****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_SPIMaid;

use strict;
use warnings;
use LIFT_general;
use LIFT_functional_layer;
use XML::LibXML;
use Readonly;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_SPIMaid ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  MAID_init
  MAID_trace_start
  MAID_trace_stop
  MAID_trace_load_file
);

our ( $VERSION, $HEADER );

Readonly::Scalar my $BIT_NBR_PER_BYTE => 8;

Readonly::Scalar my $DAT_FILE_FIRST_DATA_LINE              => 33;
Readonly::Scalar my $DAT_FILE_BYTES_PER_FRAME              => 64;
Readonly::Scalar my $DAT_FILE_TIME_STAMP_CONVERSION_FACTOR => 0.0000125;    #conversion to ms

# Structure of information in one line of data file (.dat)
Readonly::Scalar my $BYTE_NBR_TIME_STAMP      => 8;
Readonly::Scalar my $BYTE_NBR_MESSAGE_NBR     => 4;
Readonly::Scalar my $BYTE_NBR_MISO_MOSI_FRAME => 16;
Readonly::Scalar my $BYTE_NBR_CHIP_SELECT     => 1;
Readonly::Scalar my $BYTE_NBR_BITS_IN_FRAME   => 1;

=head1 NAME

LIFT_SPIMaid 

=head1 SYNOPSIS

    use LIFT_SPIMaid;

    MAID_init();

    MAID_trace_start();

    MAID_trace_stop();

    MAID_trace_load_file();

=head1 DESCRIPTION


=head2 Testbench Configuration

$Testbench={

  'localhost' => {      # LIFT PC host name
    'Functions' => {
        'SPI_Access' => {
            'trace'     =>   '<device>', # possible devices: SPIMaid
            'manipulate'     =>   '<device>', # possible devices: Manitoo 
        },
    },
  },
};

=cut

=head1 Function Group 'base'

=head2 MAID_init

    MAID_init();

=cut

sub MAID_init {
    S_w2log( 1, "Initialize SPI Maid...\n" );
    return 1;
}

=head1 Function Group 'trace'

=head2 MAID_trace_start

    $traceStarted = MAID_trace_start();

user action for starting SPI trace on SPI Maid manually

=cut

sub MAID_trace_start {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MAID_trace_start( )', @args );

    S_user_action("Start SPI Maid trace!");

    return 1;
}

=head2 MAID_trace_stop

    $traceStopped = MAID_trace_stop();

user action for stopping SPI trace on SPI Maid manually

=cut

sub MAID_trace_stop {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MAID_trace_stop( )', @args );

    S_user_action("Stop SPI Maid trace!");

    return 1;
}

=head2 MAID_trace_load_file

    $traceStopped = MAID_trace_load_file();

Load given .dat file
Add all measurement points to XML handle in standard format:

    <?xml version="1.0" encoding="utf-8"?>
    <SPI_Measurement>
      <TimeOffset_ms>MyFirstMeasurement</TimeOffset_ms>
      <MeasurementLabel>MyFirstMeasurement</MeasurementLabel>
      <MeasurementPoint MessageNumber="0" Time="0" MOSI_Hex="ff00ff00" MISO_Hex="00000000" ChipSelect="2" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="1" Time="0.00531249999994543" MOSI_Hex="2080004c" MISO_Hex="00000000" ChipSelect="2" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="2" Time="0.0106375000000298" MOSI_Hex="20000010" MISO_Hex="280a5028" ChipSelect="2" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="3" Time="0.0189000000000306" MOSI_Hex="ff00ff00" MISO_Hex="00000000" ChipSelect="3" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="4" Time="0.024212499999976" MOSI_Hex="2080004c" MISO_Hex="00000000" ChipSelect="3" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="5" Time="0.0295375000000604" MOSI_Hex="20000010" MISO_Hex="280a5028" ChipSelect="3" FrameLength_Bits="32"/>
    </SPI_Measurement>

=cut

sub MAID_trace_load_file {

    my $datFile              = shift;
    my $measurementLabel     = shift;
    my $firstTimeStampIsZero = shift;
    my $measurementXML       = shift;

    my $spiTempPath = $main::REPORT_PATH . "\\SPI_Temp";
    unless ( -e $spiTempPath ) {
        mkdir($spiTempPath);
    }
    my $reportPath = $main::REPORT_PATH . "\\SPI_Temp\\Measurements";
    unless ( -e $reportPath ) {
        mkdir($reportPath);
    }

    S_w2log( 3, "MAID_trace_load_file: convert from binary to hex\n" );
    open( BINFILE, "< $datFile" )
      or die "Can't open $datFile: $!";
    binmode(BINFILE);
    open( OUT, "> $reportPath\\$measurementLabel\_Hex.txt" )
      or die "Can't open $reportPath\\$measurementLabel\_Hex.txt: $!";

    my $valueRead;
    while ( sysread( BINFILE, $valueRead, $DAT_FILE_BYTES_PER_FRAME ) ) {
        my $n = length($valueRead);
        my $s = 2 * $n;
        print( OUT unpack( "H$s", $valueRead ), "\n" );
    }
    close(BINFILE)
      or die "Can't close $datFile: $!";
    close(OUT)
      or die "Can't close $reportPath\\$measurementLabel\_Hex.txt: $!";

    open( BINFILE, "< $datFile" )
      or die "Can't open $datFile: $!";
    binmode(BINFILE);
    open( OUT, "> $reportPath\\$measurementLabel\_Bin.dat" )
      or die "Can't open $reportPath\\$measurementLabel\_Hex.txt: $!";
    binmode(OUT);

    S_w2log( 3, "MAID_trace_load_file: split raw data into MessageNumber/Time/MOSI_Hex/MISO_Hex/ChipSelect/FrameLength_Bits\n" );

    # parse the summary XML file and get the reference of Document root element
    my $parser = XML::LibXML->new();

    # important for formatting
    $parser->keep_blanks(0);

    # get the reference to root element
    my $rootElement = $measurementXML->documentElement;

    my $lineNumber     = 0;
    my $timeZeroOffset = 0;

    # Letzte Zeile von HEXFILE ist der Offset
    open( HEXFILE, "< $reportPath\\$measurementLabel\_Hex.txt" )
      or die "Can't open $reportPath\\$measurementLabel\_Hex.txt: $!";
    while (<HEXFILE>) {
        $lineNumber++;
        next if ( $lineNumber < $DAT_FILE_FIRST_DATA_LINE );

        # {'MessageNumber' => $messageNbr, 'Time' => , 'MOSI_Hex' => , 'MISO_Hex' => , 'ChipSelect' => , 'FrameLength_Bits' =>}
        my ( $parsedSPItraceLine_href, $returnType ) = _parse_SPI_Trace_Line($_);
        last if ( not defined $parsedSPItraceLine_href );
        if ( $returnType == 1 ) {
            if ( $lineNumber == $DAT_FILE_FIRST_DATA_LINE and $firstTimeStampIsZero ) {
                $timeZeroOffset = $parsedSPItraceLine_href->{'Time'};
            }
            $parsedSPItraceLine_href->{'Time'} = $parsedSPItraceLine_href->{'Time'} - $timeZeroOffset;
            $measurementXML = _add_MeasurementPointToXML( $measurementXML, $rootElement, $parsedSPItraceLine_href );
        }
        elsif ( $returnType == 2 ) {

            # $parsedSPItraceLine_href is time offset!
            # calculate offset / or give directly calculated offset from function

            # update measurement XML
            my $timeOffsetNode = $measurementXML->createElement("TimeOffset");    # node is created

            $timeOffsetNode->appendText($parsedSPItraceLine_href);                # $parsedSPItraceLine_href is content of TimeOffset

            $rootElement->appendChild($timeOffsetNode);                           # node is appended to SPI_Measurement
        }
    }
    close(HEXFILE)
      or die "Can't close $reportPath\\$measurementLabel\_Hex.txt: $!";

    return $measurementXML;
}

=head1 Non exported functions

=head2 _parse_SPI_Trace_Line

Parses the SPI data in each line

    $returnType = 1: Parsed line
    $returnType = 2: Time Offset

=cut

sub _parse_SPI_Trace_Line {
    my $lineString = shift;
    my $returnType;
    chop($lineString);

    if ( length($lineString) < $DAT_FILE_BYTES_PER_FRAME * 2 ) {    # 1 byte -> 2 characters in string
        S_w2log( 3, "Given string '$lineString' is shorter than expected. Nothing will be done.\n" );
        my @thisTimeOffset_bytes;
        foreach my $byteInLine ( 0 .. $BYTE_NBR_TIME_STAMP - 2 ) {
            $thisTimeOffset_bytes[$byteInLine] = substr( $lineString, $byteInLine * 2, 2 );    # 1 byte -> 2 characters in string
        }
        my $timeOffset = join( "", reverse(@thisTimeOffset_bytes) );
        $timeOffset = hex($timeOffset);
        $timeOffset = $timeOffset * $DAT_FILE_TIME_STAMP_CONVERSION_FACTOR;
        S_w2log( 4, "Time offset for measurement: $timeOffset ms\n" );
        $returnType = 2;
        return ( $timeOffset, $returnType );
    }

    # extract data byte wise
    my @thisTimeStampArray_bytes;
    foreach my $byteInLine ( 0 .. $DAT_FILE_BYTES_PER_FRAME - 1 ) {
        $thisTimeStampArray_bytes[$byteInLine] = substr( $lineString, $byteInLine * 2, 2 );    # 1 byte -> 2 characters in string
    }

    my $parsed_SPI_Trace_Line_href;
    my $timeStampHex = join( "", reverse( splice( @thisTimeStampArray_bytes, 0, $BYTE_NBR_TIME_STAMP ) ) );
    $parsed_SPI_Trace_Line_href->{'Time'} = hex($timeStampHex) * $DAT_FILE_TIME_STAMP_CONVERSION_FACTOR;
    my @mosiHex_array = splice( @thisTimeStampArray_bytes, 0, $BYTE_NBR_MISO_MOSI_FRAME );
    my @misoHex_array = splice( @thisTimeStampArray_bytes, 0, $BYTE_NBR_MISO_MOSI_FRAME );
    my $messageHex = join( "", reverse( splice( @thisTimeStampArray_bytes, 0, $BYTE_NBR_MESSAGE_NBR ) ) );
    $parsed_SPI_Trace_Line_href->{'MessageNumber'} = hex($messageHex);
    my $cs = join( "", reverse( splice( @thisTimeStampArray_bytes, 0, $BYTE_NBR_CHIP_SELECT ) ) );
    $parsed_SPI_Trace_Line_href->{'ChipSelect'} = hex($cs);
    my $spiFrameLengthBits = join( "", reverse( splice( @thisTimeStampArray_bytes, 0, $BYTE_NBR_BITS_IN_FRAME ) ) );
    $parsed_SPI_Trace_Line_href->{'FrameLength_Bits'} = hex($spiFrameLengthBits);

    my $bytesPerFrame = $parsed_SPI_Trace_Line_href->{'FrameLength_Bits'} / $BIT_NBR_PER_BYTE;
    $parsed_SPI_Trace_Line_href->{'MOSI_Hex'} = join( "", reverse( splice( @mosiHex_array, 0, $bytesPerFrame ) ) );
    $parsed_SPI_Trace_Line_href->{'MISO_Hex'} = join( "", reverse( splice( @misoHex_array, 0, $bytesPerFrame ) ) );

    $returnType = 1;
    return ( $parsed_SPI_Trace_Line_href, $returnType );
}

sub _add_MeasurementPointToXML {
    my $measurementXML          = shift;
    my $rootElement             = shift;
    my $parsedSPItraceLine_href = shift;

    my $measurementPointNode = $measurementXML->createElement("MeasurementPoint");
    $measurementPointNode->setAttribute( "MessageNumber",    $parsedSPItraceLine_href->{'MessageNumber'} );
    $measurementPointNode->setAttribute( "Time",             $parsedSPItraceLine_href->{'Time'} );
    $measurementPointNode->setAttribute( "MOSI_Hex",         $parsedSPItraceLine_href->{'MOSI_Hex'} );
    $measurementPointNode->setAttribute( "MISO_Hex",         $parsedSPItraceLine_href->{'MISO_Hex'} );
    $measurementPointNode->setAttribute( "ChipSelect",       $parsedSPItraceLine_href->{'ChipSelect'} );
    $measurementPointNode->setAttribute( "FrameLength_Bits", $parsedSPItraceLine_href->{'FrameLength_Bits'} );

    $rootElement->appendChild($measurementPointNode);

    return $measurementXML;
}

1;
