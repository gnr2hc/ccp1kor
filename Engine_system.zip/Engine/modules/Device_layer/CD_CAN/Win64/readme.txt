About vxlapi64.dll:
A 64-bit XL driver library from Vector used to communicate with vector hardwares.

About CAN.dll:
A 64-bit Wrapper perl dll for CANWIN32.dl . 
It is compiled using Perl 5.12, 64 bit version

About CANWIN32.dll:
 64-bit wrapper C++ DLL for CAN_Control.dll (which is a C# Assembly dll)

About CAN_Control.dll:
A 64-bit C# dll to control CAN Communication and form TPX control layer

About CAN_Communication.dll:
A 64-bit C++ Low level DLL which perfom simple Send and receive of CAN messages