# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_CD_CAN;

use strict;
use warnings;
use File::Basename;

my $addpath;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['./Win32'], ['./Win32']);
}

use LIFT_general;
use CAN;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_CD_CAN ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  CAN_send_request_wait_response
  CD_CAN_exit
  CD_CAN_init
  CD_CAN_send_request_wait_response
  CD_CAN_send_request_get_all_response_timestamp
  CD_CAN_start_simulation
  CD_CAN_set_addressing_mode
  CD_CAN_send_message
  CD_CAN_stop_message
);

our ( $VERSION, $HEADER );


my $status;
my $CD_CAN_initialized = 0;    #flag to indicate whether CD is initialized using CD_CAN_init()
my $CD_CAN_running     = 0;    #flag to indicate whether simulation is started using CD_CAN_start_simulation
my ($DLCmode,$DTCdefaultstate,$DTCdefaultsubfunction,$DTCbytes);
my $CD_CAN_disabled = 0;

# global variables modified by CD_CAN_set_addressing_mode
my $CD_CAN_RequestID;
my $CD_CAN_ResponseID;
my $CD_CAN_FlowControlID;
my $CD_CAN_Timeout;
my $CD_CAN_P3_mintime;
my $CD_CAN_PrevResponseID = 0;    # to keep track of responseIds passed to CD_CAN_send_request_wait_response(), for purpose of configuring ports appropriately

=head1 NAME

LIFT_CD_CAN 

Perl extension for Customer Diagnosis and CAN

THIS IS STILL A PROTOTYPE !!!

=head1 SYNOPSIS

    use LIFT_CD_CAN;

    CD_CAN_init();
    CD_CAN_start_simulation();
    $msg_handle = CD_CAN_send_message( $payload_aref, $ID, $cycletime_ms );
    ($RequestID, $FlowControlID, $ResponseID, $Timeout) = CD_CAN_set_addressing_mode( $address_mode );
    $response_aref = CD_CAN_send_request_wait_response( [0x19,0x2,0x20], undef, undef, 1000 );
    CD_CAN_stop_message( $msg_handle );
    CD_CAN_exit();

ProjectConst:

   'CUSTOMER_DIAGNOSIS' => {
        'RequestID_physical' => '0x6dc',          #as hex string
        'ResponseID_physical' => '0x4fc',         #as hex string
        'FlowControlID_physical' => '0x6dc',      #as hex string
        'Timeout_physical' => 10000,              #in milliseconds
        'P3_mintime_physical' => 200 ,              #in milliseconds

        'RequestID_functional' => '0x6dc',          #as hex string
        'ResponseID_functional' => '0x4fc',         #as hex string
        'FlowControlID_functional' => '0x6dc',      #as hex string
        'Timeout_functional' => 10000,              #in milliseconds
        'P3_mintime_functional' => 400,               #in milli seconds

        'FlowControl' => [0x30,0x0f,0x01],       #3 Bytes as array ref
        'clearDTC' => [0x14,0xff,0xff,0xff],     #Bytes as array ref
        'SAM' => 1,
        'SJW' => 3,
        'Tseg1' => 0xc,
        'Tseg2' => 3,
        'Baudrate' => 500000,
        'DLCmode' => 0,                     # 0 for 8 byte, 1 for dynamic DLC
        'DTCdefaultstate' => 0x8,
        'DTCdefaultsubfunction' => 0x2,
        'DTCbytes' => 3,                    # bytes per DTC
        'ExtID' => 0,                       # 1 for Extended Identifier, 0 for Standard
        'ExtAddressing' => 1,               # 1 for Extended Addressing, 0 for Normal
        'EcuAddr' => 0x01,                  # ECU id for Extended Addressing.
        'TargetAddr' => 0xF1,               # Target address for Extended Addressing.

        'DISABLE' => 1,                 # optional, to disable all CD features (similar to offline mode)
    },

TestBench Config:  
 
    If you use CANcaseXL for diagnosis no extra setting is required, settings of PD will be used.

    If you use VN89xx or VN16xx for diagnosis you have to specify CANHWSerialNo and CANchannel.
    Important note for CANchannel: only CAN channels are counted, so if CH1,2 = LIN and CH3,4 = CAN then 
    CANchannel = 1 if CH3 is used and CANchannel = 2 if CH4 is used
    'CD' => {
            'CANchannel' => 1,
            'CANHWSerialNo' => 28761,           #e.g. for serial no 007129-028761
        },


=head1 DESCRIPTION


=head2 CAN_send_request_wait_response

I<B<Syntax : >>

    $respone_aref = CAN_send_request_wait_response( $request_aref [, $RequestID [, $ResponseID [, $Timeout_ms [, $interFrameDelay_ms]]]]] )

I<B<Arguments    : >>

    $request_aref       = array reference to the request array
    $RequestID          = (optional) send ID, if not given will be taken from CD_CAN_set_addressing_mode
    $ResponseID         = (optional) response ID, if not given will be taken from CD_CAN_set_addressing_mode
    $Timeout_ms         = (optional) timeout in milliseconds. if not given, will be taken from CD_CAN_set_addressing_mode
    $interFrameDelay_ms = (optional) inter-CAN-frame delay in milliseconds. if not given, will be taken as 0 milliseconds

I<B<Description :>>

This API provides a generic way of sending CAN messages to CAN bus and retrieving the response.
It supports sending CAN request of multiple frames and wait for response with multiple frames.

B<This API is not related anyway to Customer Diagnosis.>

B<Note:>

=over 1

=item * The padding byte (incase if the DLC is not filled by actual bytes) = 0xFF

=item * The Response length will be taken from the First byte of the first response frame. i.e., Maximum possible response length = 255 (0xFF)

=item * Response array will contain all bytes except Response length (First byte of First frame) byte

=item * The DLC mode is as same as ProjectConst->{'CUSTOMER_DIAGNOSIS'}{'DLCmode'} configuration

=back

I<B<Return values :>>

    $respone_aref   = returned reference of response array

response data (or) [] if receive timeout

I<B<Examples :>>

    [0x80, 0xA1, 0x85,0xE9,0xB5,0xDA] = CAN_send_request_wait_response( [0x00,0xA1,0xA4] );                      # consider PD login Request
    [0x80, 0xA1, 0x85,0xE9,0xB5,0xDA] = CAN_send_request_wait_response( [0x00,0xA1,0xA4], 0x715);
    [0x80, 0xA1, 0x85,0xE9,0xB5,0xDA] = CAN_send_request_wait_response( [0x00,0xA1,0xA4], undef, undef, 100);    # 100ms timeout
    [0x80, 0xA1, 0x85,0xE9,0xB5,0xDA] = CAN_send_request_wait_response( [0x00,0xA1,0xA4], 0x715, 0x744, 100, 5); # 5ms interframe delay

=cut

sub CAN_send_request_wait_response
{
    my $request_aref       = shift;
    my $sendRequestID      = shift;
    my $sendResponseID     = shift;
    my $sendTimeout_ms     = shift;
    my $interFrameDelay_ms = shift;
    my ( $data_aref, $start, $resp_len );

    unless ( defined($request_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: respone_aref = CAN_send_request_wait_response( request_aref [, RequestID [, flowcontrol_ID [, ResponseID [, Timeout_ms [, $interFrameDelay_ms]]]]]) ", 110 );
        return [];
    }

    if ( ref($request_aref) ne "ARRAY" )
    {
        S_set_error( " request_aref is not an array reference", 114 );
        return [];
    }

    #set default values , if undefined
    unless ( defined($sendRequestID) )
    {
        $sendRequestID = $CD_CAN_RequestID;
    }

    unless ( defined($sendResponseID) )
    {
        $sendResponseID = $CD_CAN_ResponseID;
    }

    unless ( defined($sendTimeout_ms) )
    {
        $sendTimeout_ms = $CD_CAN_Timeout;
    }

    unless ( defined($interFrameDelay_ms) )
    {
        $interFrameDelay_ms = 0;    # by default, 0ms interframe delay
    }


    # convert to decimal, if required
    foreach my $byte (@$request_aref) { $byte = S_0x2dec($byte); }

    my @hex_request = (@$request_aref);
    foreach my $byte (@hex_request) { $byte = "0x" . sprintf( "%02X", $byte ); }
    S_w2log( 3, "CAN_send_request_wait_response ->Request (" . ( scalar(@$request_aref) ) . ") @hex_request\n" );

    my $hexsendID     = sprintf( "0x%x", S_0x2dec($sendRequestID) );
    my $hexresponseID = sprintf( "0x%x", S_0x2dec($sendResponseID) );

    S_w2log( 3, "CAN_send_request_wait_response ->Request ID: $hexsendID,  Response ID: $hexresponseID , Response Timeout: $sendTimeout_ms ms, Interframe delay = $interFrameDelay_ms ms\n" );

    return [] if ($main::opt_offline);

    #if previous message response ID is not the same as the current one, then configure CAN port filter for current response ID
    $sendResponseID = S_0x2dec($sendResponseID);
    if ( $sendResponseID != $CD_CAN_PrevResponseID )
    {
        $status = can_ConfigurePorts( $sendResponseID, $sendResponseID );
        Check_Status($status);
        my $hexval = sprintf( "0x%x", $sendResponseID );
        S_w2log( 5, "Configure port ($hexval) status = $status\n" );

        #save the current response ID , if configuring port is successful
        $CD_CAN_PrevResponseID = $sendResponseID if ( $status >= 0 );
    }

    ( $status, $data_aref ) = can_MultiSendAndWaitForResponse( [@$request_aref], S_0x2dec($sendRequestID), S_0x2dec($sendResponseID), $sendTimeout_ms, $interFrameDelay_ms );
    S_w2log( 5, "-> Status = $status\n" );
    my @hex_resp = (@$data_aref);
    foreach my $byte (@hex_resp) { $byte = "0x" . sprintf( "%02X", $byte ); }
    S_w2log( 3, "CAN_send_request_wait_response -> Response (" . scalar(@hex_resp) . ") @hex_resp\n" );

    return ($data_aref);

}

=head2 CD_CAN_exit

    CD_CAN_exit( );

has to be called at the end. should be called in ENDcampaign. should have at least 1 second delay to previous CD function call.

=cut

sub CD_CAN_exit
{

    if ($CD_CAN_disabled)
    {
        S_w2log( 3, "CD_CAN_exit skipped because CD is DISABLED\n" );
        return 1;
    }

    unless ($CD_CAN_initialized)
    {
        S_set_error( "CD not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $CD_CAN_initialized = 0;
        $CD_CAN_running     = 0;
        S_w2log( 3, "CD_CAN_exit:  Communication terminated \n" );
        return 1;
    }

    $status = can_End();
    Check_Status($status);
    S_w2log( 5, "CD_CAN_exit status : $status\n" );

    #reset flags
    $CD_CAN_initialized = 0;
    $CD_CAN_running     = 0;
    S_w2log( 3, "CD_CAN_exit:  Communication terminated \n" );

    return 1;
}

=head2 CD_CAN_init

    CD_CAN_init( );

initialize customer diagnosis and CAN.

has to be called before any other CD command.

=cut

sub CD_CAN_init
{

    $CD_CAN_disabled = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DISABLE'};
    unless ( defined $CD_CAN_disabled ) { $CD_CAN_disabled = 0; }    # set default

    if ($CD_CAN_disabled)
    {
        S_w2log( 3, "CD_CAN_init skipped because CD is DISABLED\n" );
        return 1;
    }

    if ($CD_CAN_initialized)
    {
        S_set_warning("CD already initialized");
        return;
    }

    if ($main::opt_offline)
    {
    	S_w2log( 4, "CD_CAN_init: Initialized successfully \n" );
        $CD_CAN_initialized = 1;
        return 1;
    }

    my $version;
    $version = can_getPMrevision();
    S_w2log( 5, "PM $version\n" );
    $version = can_getXSrevision();
    S_w2log( 5, "XS $version\n" );
    $version = can_getCWrevision();
    S_w2log( 5, "CW $version\n" );

    $status = can_Start();
    Check_Status($status);
    S_w2log( 5, "CD_CAN_init: can_Start status = $status \n" );

    #S_w2log(1,"($stat) CAN DLL version: $version\n");
    $CD_CAN_initialized = 1;

    if ( $status < 0 )
    {
        S_set_error( "could not initialize CD", 5 );
        $CD_CAN_initialized = 0;
    }

    S_w2log( 3, "CD_CAN_init: Initialized successfully \n" );
    return 1;
}

=head2 CD_CAN_send_message

    $msg_handle = CD_CAN_send_message( $payload_aref, $ID, $cycletime_ms );    

Sends the given request bytes to ECU and returns the message handle.

B<Arguments:>

=over

=item $payload_aref 

Array reference to the request array

=item $ID 

CAN ID on which the message needs to be sent

=item $cycletime_ms 

cycletime in milliseconds ( 0 = Send only once, non-zero = send continuously with $cycletime_ms as interval time).
Messages can be sent cyclically only if message is single frame.

B< Multi frame messages cannot be sent cyclically.>

=back

B<Return Value:>

=over

=item $msg_handle 

Success : >= 0 if message is sent Successfuly.

Error : NRC code ( Negative values ) or undef in error condition

=back

B<Examples:>

        Single frame message with Cycle time: Sends message every 200ms
$msg_handle = CD_CAN_send_message( [0x19,0x1,0x20], 0x6DC , 200 );

        Single frame message with Cycle time 0 : Sends only once        
$msg_handle = CD_CAN_send_message( [0x19,0x1,0x20], 0x6DC , 0 );

        Multi Frame message cycletime 0: Sends only once:        
$msg_handle = CD_CAN_send_message( [0x2E,0x02,0x74,0x00,0x00,0x00,0x01,0x00,0x10,0x00,0x11,0x01,0x00,0x01,0x01], 0x6DC , 0 );

B<Notes>:

DLC will be calculated automatically 

use L</CD_CAN_stop_message>() to stop cyclic message sending

=cut

sub CD_CAN_send_message {
    ### DESIGN  ###

    # COMMENT-START
    #   get arguments
    #   mandatory :
    # - $payload_aref,$ID,$cycletime_ms
    # COMMENT-END

    # STEP Check if function arguments are defined
    # STEP Check if CD is initialized
    # STEP Convert the input array values to hex
    # IF $DLC > 8 ?
    #   IF-YES-START
    #       Multi frame requests cannot be sent cyclically
    #       IF Cycletime == 0 ?
    #           IF-NO-START
    #               STEP Set error Multi frame requests cannot be sent cyclically
    #           IF-NO-END
    #           IF-YES-START
    #               Multi Frame request needs to be sent using flowcontrol method.
    #               STEP Call DLL function can_SendMultiFrameMessage
    #           IF-YES-END
    #   IF-YES-END
    #   IF-NO-START
    #       STEP add DLC to request
    #       STEP Call DLL function can_SendMessage
    #   IF-NO-END
    # STEP Return $msg_handle

    my @args = @_;
    return undef unless S_checkFunctionArguments( 'CD_CAN_send_message( $payload_aref, $ID, $cycletime_ms  )', @args );

    my $payload_aref = shift @args;
    my $msgID        = shift @args;
    my $cycle        = shift @args;
    my $msg_handle;
    my $dlc;

    unless ($CD_CAN_initialized) {
        S_set_error( "CD not initialized", 120 );
        return;
    }

    # convert to dec if required
    foreach (@$payload_aref) { $_ = S_0x2dec($_); }
    $dlc = scalar(@$payload_aref);

    my @hex_msg = ( $dlc, @$payload_aref );
    foreach (@hex_msg) { $_ = "0x" . sprintf( "%02X", $_ ); }
    S_w2log( 3, "CD_CAN_send_message ->Message ($msgID) @hex_msg\n" );

    return 1 if ($main::opt_offline);

    if ( $dlc > 8 ) {
        if ( $cycle == 0 ) {
            $msg_handle = can_SendMultiFrameMessage( $payload_aref, S_0x2dec($msgID), $CD_CAN_Timeout );
            Check_Status($msg_handle);
        }
        else {
            S_set_error( "CD_CAN_send_message : Length = $dlc , cycle time = $cycle. Cannot send Multi Frame messages cyclically, cycletime should be made 0 ", 109 );
            return;
        }
    }
    else {
        my $CANmsg_aref = [ $dlc, @$payload_aref ];

        $msg_handle = can_SendMessage( $CANmsg_aref, S_0x2dec($msgID), $cycle, $CD_CAN_P3_mintime );
        Check_Status($msg_handle);
    }

    S_w2log( 5, "msg_handle returned by CD_send is $msg_handle\n" );
    return $msg_handle;

}

=head2 CD_CAN_send_request_wait_response

    ($status, $time_aref, $response_aref) = CD_CAN_send_request_wait_response( $request_aref [,$options_href] ) 
    

Sends request and waits for response. Sends flow control, if response is of Multiple frames (response code : 0x78)

B<Arguments:>

=over

=item $request_aref 

Array reference to the request array

=item $options_href 

(optional) This is a hash reference containing the values for optional parameters.

Below are the optional parameters in the hash reference
           
=> $options_href->{'Manipulated_length'} : This holds the value to manipulate the request length(valid range = 0-255(0x00-0xFF))
                                           and if the value is not provided , then the request length will not be manipulated.

=back

B<Return Value:>

=over

=item $status 

Success : Returns the status of the obtained response

Returns 0 if Got positive response

Returns 1 if Got response after pending

Returns 2 if Got negative response

Returns 3 if Got no response

Offline : 1

Error : undef

=item $time_aref 

Success : Returns array reference to the inter-CAN-frame timings (with precision of +2 or -2 ms) in milliseconds

Offline : []

Error : []

=item $response_aref 

Success : Returns reference of response array => response data (or) [] if receive timeout

Offline : []

Error : []

=back

B<Examples:>

    (1, [20],[0x7F, 0x19, 0x12]) = CD_CAN_send_request_wait_response( [0x19,0x1,0x20] );
    
    $options_href->{'Manipulated_length'} = '0x03'
    (1, [20],[0x7F, 0x19, 0x12]) = CD_CAN_send_request_wait_response( [0x19,0x1,0x20], $options_href);

=for html
<h4><i>response_aref & time_aref possibilities :</i></h4>
<IMG SRC='..\..\pics\CD_CAN\CD_CAN_send_request_wait_response.png' width='800px' height='400px' alt="Sample response_aref & time_aref" border="0">
<br><br>

=cut

sub CD_CAN_send_request_wait_response {

    my @args = @_;
    return ( undef, [], [] ) unless S_checkFunctionArguments( 'CD_CAN_send_request_wait_response( $request_aref [,$options_href] )', @args );

    my $request_aref = shift @args;
    my $options_href = shift @args;

    my $sendRequestID;
    my $sendflowcontrol_ID;
    my $sendResponseID;
    my $sendTimeout_ms;

    if ($CD_CAN_disabled) {
        S_w2log( 1, "CD_CAN_send_request_wait_response skipped because CD is DISABLED\n" );
        return ( undef, [], [] );
    }

    unless ($CD_CAN_initialized) {
        S_set_error( "CD not initialized", 120 );
        return ( undef, [], [] );
    }

    unless ($CD_CAN_running) {
        S_set_error( "CD not running", 120 );
        return ( undef, [], [] );
    }

    if ( ref($request_aref) ne "ARRAY" ) {
        S_set_error( " request_aref is not an array reference", 114 );
        return ( undef, [], [] );
    }

    $sendRequestID = $CD_CAN_RequestID;

    $sendflowcontrol_ID = $CD_CAN_FlowControlID;

    $sendResponseID = $CD_CAN_ResponseID;

    $sendTimeout_ms = $CD_CAN_Timeout;

    my $manipulated_length;
    $manipulated_length = $options_href->{'Manipulated_length'};

    # convert to dec if required
    foreach (@$request_aref) { $_ = S_0x2dec($_); }

    my $count = scalar(@$request_aref);

    if ( defined $manipulated_length ) {        
    
        S_w2log( 4, "CD_CAN_send_request_wait_response -> The Manipulated Length is: $manipulated_length\n" );

        $manipulated_length = S_0x2dec($manipulated_length);

        if ( $manipulated_length < 0 or $manipulated_length > 255 ) {
            S_set_error( " The value $manipulated_length provided for manipulating the request length byte is invalid, it should be within the range 0 - 255(0x00-0xFF)", 114 );
            return ( undef, [], [] );
        }

        $count = $manipulated_length;
    }
    else {
        $manipulated_length = -1;    #If the manipulated length value is not defined, then by default -1 is considered to indicate no manipulation is needed
    }

    my @hex_request = ( $count, @$request_aref );
    foreach (@hex_request) { $_ = "0x" . sprintf( "%02X", $_ ); }
    S_w2log( 3, "CD_CAN_send_request_wait_response ->Request (" . ( scalar(@hex_request) ) . ") @hex_request\n" );

    my $hexsendID        = sprintf( "0x%x", S_0x2dec($sendRequestID) );
    my $hexflowcontrolID = sprintf( "0x%x", S_0x2dec($sendflowcontrol_ID) );
    my $hexresponseID    = sprintf( "0x%x", S_0x2dec($sendResponseID) );

    S_w2log( 3, "CD_CAN_send_request_wait_response ->Request ID: $hexsendID, Flowcontrol ID: $hexflowcontrolID, Response ID: $hexresponseID , P3_mintime: $CD_CAN_P3_mintime\n" );

    return ( 1, [], [] ) if ($main::opt_offline);

    my $response_status;

    #if previous message response ID is not the same as the current one, then configure CAN port filter for current response ID
    $sendResponseID = S_0x2dec($sendResponseID);
    if ( $sendResponseID != $CD_CAN_PrevResponseID ) {
        $response_status = can_ConfigurePorts( $sendResponseID, $sendResponseID );
        Check_Status($response_status);
        my $hexval = sprintf( "0x%x", $sendResponseID );
        S_w2log( 4, "CD_CAN_send_request_wait_response: Configure port ($hexval) status = $response_status\n" );

        #save the current response ID , if configuring port is successful
        $CD_CAN_PrevResponseID = $sendResponseID if ( $response_status >= 0 );
    }

    my $tpx_request_aref = [@$request_aref];
    my ( $data_aref, $time_aref );
    ( $response_status, $data_aref, $time_aref ) = can_TPXSendAndGetResponse( $tpx_request_aref, S_0x2dec($sendRequestID), S_0x2dec($sendflowcontrol_ID), S_0x2dec($sendResponseID), $sendTimeout_ms, $CD_CAN_P3_mintime, $manipulated_length );

    if ( $response_status == 1 ) {
        S_w2log( 3, "got response after pending\n" );
    }
    elsif ( $response_status == 2 ) {
        S_w2log( 3, "got negative response\n" );
    }
    elsif ( $response_status == 3 ) {
        S_w2log( 3, "got no response\n" );
        return ( undef, [], [] );
    }
    else {
        Check_Status($response_status);
    }
    my @hex_resp = (@$data_aref);
    foreach (@hex_resp) { $_ = "0x" . sprintf( "%02X", $_ ); }
    S_w2log( 3, "CD_CAN_send_request_wait_response <-Response (" . scalar(@hex_resp) . ") @hex_resp\n" );

    return ( $response_status, $time_aref, $data_aref );

}


=head2 CD_CAN_send_request_get_all_response_timestamp

    ($status, $response_timestamp_href) = CD_CAN_send_request_get_all_response_timestamp( $request_aref [,$options_href] )     

Sends request and waits for response. Sends flow control, if response is of Multiple frames (response code : 0x78)

Fetches all types of response(negative/positive/pending) and their coressponding inter-Can-frame timings 

B<Arguments:>

=over

=item $request_aref 

Array reference to the request array

=item $options_href 

(optional) This is a hash reference containing the values for optional parameters.

Below are the optional parameters in the hash reference
           
=> $options_href->{'Manipulated_length'} : This holds the value to manipulate the request length(valid range = 0-255(0x00-0xFF))
                                           and if the value is not provided , then the request length will not be manipulated.

=back

B<Return Value:>

=over

=item $status 

Success : Returns the status of the obtained response

Returns 0 if Got positive response

Returns 1 if Got response after pending

Returns 2 if Got negative response

Returns 3 if Got no response

Offline : 1

Error : undef

=item $response_timestamp_href 

Success : Returns Hash reference of all response and their respective inter-CAN-frame timings (with precision of +2 or -2 ms) in milliseconds
          $response_timestamp_href->{$response_sequence}->{time} = [response];

Offline : {}

Error : undef

=back

B<Examples:>

    (1, $response_timestamp_href) = CD_CAN_send_request_get_all_response_timestamp( [0x19,0x1,0x20] );
    
    $options_href->{'Manipulated_length'} = '0x03'
    (1, $response_timestamp_href) = CD_CAN_send_request_get_all_response_timestamp( [0x19,0x1,0x20], $options_href);

=cut

sub CD_CAN_send_request_get_all_response_timestamp {

    my @args = @_;
    return ( undef, undef ) unless S_checkFunctionArguments( 'CD_CAN_send_request_get_all_response_timestamp( $request_aref [,$options_href] )', @args );

    my $request_aref = shift @args;
    my $options_href = shift @args;

    my $sendRequestID;
    my $sendflowcontrol_ID;
    my $sendResponseID;
    my $sendTimeout_ms;

    if ($CD_CAN_disabled) {
        S_w2log( 1, "CD_CAN_send_request_get_all_response_timestamp : skipped because CD is DISABLED\n" );
        return ( undef, undef );
    }

    unless ($CD_CAN_initialized) {
        S_set_error( "CD_CAN_send_request_get_all_response_timestamp : CD not initialized", 120 );
        return ( undef, undef );
    }

    unless ($CD_CAN_running) {
        S_set_error( "CD_CAN_send_request_get_all_response_timestamp : CD not running", 120 );
        return ( undef, undef );
    }

    $sendRequestID = $CD_CAN_RequestID;

    $sendflowcontrol_ID = $CD_CAN_FlowControlID;

    $sendResponseID = $CD_CAN_ResponseID;

    $sendTimeout_ms = $CD_CAN_Timeout;

    my $manipulated_length;
    $manipulated_length = $options_href->{'Manipulated_length'};

    # convert to dec if required
    foreach (@$request_aref) { $_ = S_0x2dec($_); }

    my $count = scalar(@$request_aref);

    if ( defined $manipulated_length ) {

        S_w2log( 4, "CD_CAN_send_request_get_all_response_timestamp -> The Manipulated Length is: $manipulated_length\n" );

        $manipulated_length = S_0x2dec($manipulated_length);

        if ( $manipulated_length < 0 or $manipulated_length > 255 ) {
            S_set_error( "CD_CAN_send_request_get_all_response_timestamp : The value $manipulated_length provided for manipulating the request length byte is invalid, it should be within the range 0 - 255(0x00-0xFF)", 114 );
            return ( undef, undef );
        }

        $count = $manipulated_length;
    }
    else {
        $manipulated_length = -1;    #If the manipulated length value is not defined, then by default -1 is considered to indicate no manipulation is needed
    }

    my @hex_request = ( $count, @$request_aref );
    foreach (@hex_request) { $_ = "0x" . sprintf( "%02X", $_ ); }
    S_w2log( 3, "CD_CAN_send_request_get_all_response_timestamp ->Request (" . ( scalar(@hex_request) ) . ") @hex_request\n" );

    my $hexsendID        = sprintf( "0x%x", S_0x2dec($sendRequestID) );
    my $hexflowcontrolID = sprintf( "0x%x", S_0x2dec($sendflowcontrol_ID) );
    my $hexresponseID    = sprintf( "0x%x", S_0x2dec($sendResponseID) );

    S_w2log( 3, "CD_CAN_send_request_get_all_response_timestamp ->Request ID: $hexsendID, Flowcontrol ID: $hexflowcontrolID, Response ID: $hexresponseID , P3_mintime: $CD_CAN_P3_mintime\n" );

    return ( 1, {} ) if ($main::opt_offline);

    my $response_status;

    #if previous message response ID is not the same as the current one, then configure CAN port filter for current response ID
    $sendResponseID = S_0x2dec($sendResponseID);
    if ( $sendResponseID != $CD_CAN_PrevResponseID ) {
        $response_status = can_ConfigurePorts( $sendResponseID, $sendResponseID );
        Check_Status($response_status);
        my $hexval = sprintf( "0x%x", $sendResponseID );
        S_w2log( 4, "CD_CAN_send_request_get_all_response_timestamp : Configure port ($hexval) status = $response_status\n" );

        #save the current response ID , if configuring port is successful
        $CD_CAN_PrevResponseID = $sendResponseID if ( $response_status >= 0 );
    }

    my $tpx_request_aref = [@$request_aref];
    my ( $data_aref, $time_ms_aref );
    ( $response_status, $data_aref, $time_ms_aref ) = can_TPXSendAndGetAllResponseTimestamp( $tpx_request_aref, S_0x2dec($sendRequestID), S_0x2dec($sendflowcontrol_ID), S_0x2dec($sendResponseID), $sendTimeout_ms, $CD_CAN_P3_mintime, $manipulated_length );

    if ( $response_status == 1 ) {
        S_w2log( 3, "got response after pending\n" );
    }
    elsif ( $response_status == 2 ) {
        S_w2log( 3, "got negative response\n" );
    }
    elsif ( $response_status == 3 ) {
        S_w2log( 3, "got no response\n" );
        return ( undef, undef );
    }
    else {
        Check_Status($response_status);
    }

    my $response_timestamp_href;
    my $response_sequence;

    $response_sequence = 1;

    #sort the response and timestamp array according to the sequence they are received
    foreach (@$data_aref) {
        if ( $$data_aref[0] == 0x7F ) {
            $response_timestamp_href->{$response_sequence}->{ shift @$time_ms_aref } = [ splice @$data_aref, 0, 3 ];
        }
        else {
            $response_timestamp_href->{$response_sequence}->{ shift @$time_ms_aref } = [ splice @$data_aref, 0, scalar(@$data_aref) ];
        }

        $response_sequence++;

    }

    return ( $response_status, $response_timestamp_href );

}

=head2 CD_CAN_set_addressing_mode

I<B<Syntax : >>

 ($RequestID, $FlowControlID, $ResponseID, $Timeout, $P3_mintime) = CD_CAN_set_addressing_mode( $address_mode )

I<B<Arguments    : >>

    $address_mode = string name which is mentioned in ProjectDefaults ('physical', 'functional', 'disposal' etc)

B<Note:> The input '$address_mode' string is case-sensitive

The necessary parameters should be defined in ProjectConst->{'CUSTOMER_DIAGNOSIS'} with labels "RequestID_B<addressmode>", "ResponseID_B<addressmode>", "FlowControlID_B<addressmode>", "Timeout_B<addressmode>".

I<B<Description :>>

Sets the request ID, response ID, flowcontrol ID, Timeout (in millisecond(s)) for the future CD requests based on input "$address_mode" string.

Logs error string, if any of the necessary parameters (RequestID, ResponseID, FlowControlID, Timeout) is not defined in ProjectDefaults and set INCONC.

I<B<Return values :>>

Returns $RequestID, $FlowControlID, $ResponseID and $Timeout values of the corresponding Addressing mode, which is set.

I<B<Examples :>>

    ('0x7f4', '0x6dc', '0x7f7', 10000, 400) = CD_CAN_set_addressing_mode( 'disposal' )
    (undef,  undef, undef,  undef, undef)     = CD_CAN_set_addressing_mode( 'unknown'  )   #verdict set to INCONC

I<B<ProjectConst :>>

   'CUSTOMER_DIAGNOSIS' => {

     'RequestID_disposal' => '0x7f4',          #as hex string
     'ResponseID_disposal' => '0x7f7',         #as hex string
     'FlowControlID_disposal' => '0x6dc',      #as hex string
     'Timeout_disposal' => 10000,              #in milliseconds
     'P3_mintime_disposal' => 400,             #in milli seconds
   }

=cut

sub CD_CAN_set_addressing_mode
{
    my $address_mode = shift;

    if ($CD_CAN_disabled)
    {
        S_w2log( 3, "CD_CAN_set_addressing_mode skipped because CD is DISABLED\n" );
        return;
    }

    my $CD_CAN_RequestID_label;
    my $CD_CAN_ResponseID_label;
    my $CD_CAN_FlowControlID_label;
    my $CD_CAN_Timeout_label;
    my $CD_CAN_P3_mintime_label;

    unless ( defined($address_mode) )
    {
        S_set_error( "! too less parameters ! SYNTAX: CD_CAN_set_addressing_mode( address_mode )", 110 );
        return 1;
    }

    $CD_CAN_RequestID_label     = 'RequestID_' . $address_mode;
    $CD_CAN_ResponseID_label    = 'ResponseID_' . $address_mode;
    $CD_CAN_FlowControlID_label = 'FlowControlID_' . $address_mode;
    $CD_CAN_Timeout_label       = 'Timeout_' . $address_mode;
    $CD_CAN_P3_mintime_label    = 'P3_mintime_' . $address_mode;

    unless (    defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_RequestID_label} )
             && defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_ResponseID_label} )
             && defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_FlowControlID_label} )
             && defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_Timeout_label} )
             && defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_P3_mintime_label} ) )
    {
        unless ( defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_RequestID_label} ) )     { S_set_error( "! $CD_CAN_RequestID_label for CUSTOMER_DIAGNOSIS not found in ProjectConst ",     114 ); return; }
        unless ( defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_ResponseID_label} ) )    { S_set_error( "! $CD_CAN_ResponseID_label for CUSTOMER_DIAGNOSIS not found in ProjectConst ",    114 ); return; }
        unless ( defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_FlowControlID_label} ) ) { S_set_error( "! $CD_CAN_FlowControlID_label for CUSTOMER_DIAGNOSIS not found in ProjectConst ", 114 ); return; }
        unless ( defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_Timeout_label} ) )       { S_set_error( "! $CD_CAN_Timeout_label for CUSTOMER_DIAGNOSIS not found in ProjectConst ",       114 ); return; }
        unless ( defined( $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_P3_mintime_label} ) )    { S_set_error( "! $CD_CAN_P3_mintime_label for CUSTOMER_DIAGNOSIS not found in ProjectConst ",    114 ); return; }
    }

    #will be executed only if all the necessary labels are defined in ProjectDefaults
    $CD_CAN_RequestID     = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_RequestID_label};
    $CD_CAN_ResponseID    = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_ResponseID_label};
    $CD_CAN_FlowControlID = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_FlowControlID_label};
    $CD_CAN_Timeout       = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_Timeout_label};
    $CD_CAN_P3_mintime    = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{$CD_CAN_P3_mintime_label};

    if ( $CD_CAN_P3_mintime < 0 )
    {
        S_set_error( "! $CD_CAN_P3_mintime_label is -ve. $CD_CAN_P3_mintime_label set to Zero", 0 );
        $CD_CAN_P3_mintime = 0;
    }
    S_w2log( 4, "CD addressing mode set to '$address_mode'\n -> Request ID: $CD_CAN_RequestID, Flowcontrol ID: $CD_CAN_FlowControlID, Response ID: $CD_CAN_ResponseID, Timeout: $CD_CAN_Timeout millisecond(s) , P3_mintime: $CD_CAN_P3_mintime milliseconds(s) \n" );
    return ( $CD_CAN_RequestID, $CD_CAN_FlowControlID, $CD_CAN_ResponseID, $CD_CAN_Timeout, $CD_CAN_P3_mintime );
}

=head2 CD_CAN_start_simulation

    CD_CAN_start_simulation( [$CANscript] );

initalize CAN hardware with simulation script

CD physical request settings are taken as default. It can be changed by L</CD_CAN_set_addressing_mode>()

 NOTE: CAN settings can be found in CAN_parameter.txt of WinDiag

    settings are taken from ProjectConst :
    e.g.

    'CUSTOMER_DIAGNOSIS' => {
        'RequestID_physical' => '0x6dc',          #as hex string
        'ResponseID_physical' => '0x4fc',         #as hex string
        'FlowControlID_physical' => '0x6dc',      #as hex string
        'Timeout_physical' => 10000,              #in milliseconds
        'P3_mintime_physical' => 200 ,            #in milliseconds(by default its 0)

        'RequestID_functional' => '0x6dc',          #as hex string
        'ResponseID_functional' => '0x4fc',         #as hex string
        'FlowControlID_functional' => '0x6dc',      #as hex string
        'Timeout_functional' => 10000,              #in milliseconds
        'P3_mintime_functional' => 400 ,            #in milliseconds(by default its 0)

        'FlowControl' => [0x30,0x0f,0x01],       #3 Bytes as array ref
        'clearDTC' => [0x14,0xff,0xff,0xff],     #Bytes as array ref
        'SAM' => 1,
        'SJW' => 3,
        'Tseg1' => 0xc,
        'Tseg2' => 3,
        'Baudrate' => 500000,
        'DLCmode' => 0,                     # 0 for 8 byte, 1 for dynamic DLC
        'DTCdefaultstate' => 0x8,
        'DTCdefaultsubfunction' => 0x2,
        'DTCbytes' => 3,                    # bytes per DTC
        'ExtID' => 0,                       # 1 for Extended Identifier, 0 for Standard
        'ExtAddressing' => 1,               # 1 for Extended Addressing, 0 for Normal
        'EcuAddr' => 0x01,                  # ECU id for Extended Addressing.
        'TargetAddr' => 0xF1,               # Target address for Extended Addressing.

        'DISABLE' => 1,                 # optional, to disable all CD features (similar to offline mode)
    },

    By default CAN device settings will be taken from testbench config PD settings:
    e.g.'PD' => {
            'Hostname' => 'SI54207',
            'CANchannel' => 1,
            'CANHWSerialNo' => 28761,           #e.g. for serial no 007129-028761
        },

    However if you have a VN89xx or a VN16xx box the CD dll will only count CAN channels, 
    therefore a separate CD section is needed in testbench config:
    e.g.'CD' => {
            'CANchannel' => 1,
            'CANHWSerialNo' => 28761,           #e.g. for serial no 007129-028761
        },
    

    offline Run : sets CD_CAN_running flag .

=cut

sub CD_CAN_start_simulation
{
    my ( $CANchannel, $SAM, $SJW, $Tseg1, $Tseg2, $Baudrate, $FlowControl );
    my ( $Extmode, $ExtAddressing, $Ecu_ID, $Targetaddr, $Serialno );

    #    S_w2log( 1, "CD_CAN_start_simulation\n" );

    if ($CD_CAN_disabled)
    {
        S_w2log( 3, "CD_CAN_start_simulation skipped because CD is DISABLED\n" );
        return 1;
    }
    unless ($CD_CAN_initialized)
    {
        S_set_error( "CD not initialized", 120 );
        return 0;
    }
    
	if ($CD_CAN_running)  {
        S_set_error( "CAN hardware is already initialized and port was opened already opened.", 0);
        return 0;
	}

    my $CANscript = shift;
    if ( defined $CANscript )
    {
        unless ( -f $CANscript )
        {
            S_set_error( "CANscript not found", 1 );
            return 0;
        }
    }

    $CANchannel = $LIFT_config::LIFT_Testbench->{'Devices'}{'CD'}{'CANchannel'};
    $CANchannel = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANchannel'} if not defined $CANchannel;

    $Serialno = $LIFT_config::LIFT_Testbench->{'Devices'}{'CD'}{'CANHWSerialNo'};
    $Serialno = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANHWSerialNo'} if not defined $Serialno;

    unless (defined $CANchannel) {S_set_error( "CANchannel not defined in testbenchconfig CD or PD" , 105);return;}
    unless (defined $Serialno) {S_set_error( "CANHWSerialNo not defined in testbenchconfig CD or PD" , 0);} # only warning

    $CD_CAN_RequestID     = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'RequestID_physical'};
    $CD_CAN_ResponseID    = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'ResponseID_physical'};
    $CD_CAN_FlowControlID = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'FlowControlID_physical'};
    $CD_CAN_Timeout       = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'Timeout_physical'};
    $CD_CAN_P3_mintime    = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'P3_mintime_physical'};

    $SAM                   = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'SAM'};
    $SJW                   = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'SJW'};
    $Tseg1                 = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'Tseg1'};
    $Tseg2                 = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'Tseg2'};
    $Baudrate              = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'Baudrate'};
    $DLCmode               = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DLCmode'};
    $DTCdefaultstate       = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTCdefaultstate'};
    $DTCdefaultsubfunction = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTCdefaultsubfunction'};
    $DTCbytes              = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTCbytes'};
    $FlowControl           = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'FlowControl'};

    $Extmode       = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'ExtID'};
    $ExtAddressing = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'ExtAddressing'};
    $Ecu_ID        = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'EcuAddr'};
    $Targetaddr    = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'TargetAddr'};

    unless ( defined $CD_CAN_RequestID )     { S_set_error( "! RequestID_physical for CUSTOMER_DIAGNOSIS not found in ProjectConst ",     114 ); return; }
    unless ( defined $CD_CAN_ResponseID )    { S_set_error( "! ResponseID_physical for CUSTOMER_DIAGNOSIS not found in ProjectConst ",    114 ); return; }
    unless ( defined $CD_CAN_FlowControlID ) { S_set_error( "! FlowControlID_physical for CUSTOMER_DIAGNOSIS not found in ProjectConst ", 114 ); return; }
    unless ( defined $CD_CAN_Timeout )       { S_set_error( "! Timeout_physical for CUSTOMER_DIAGNOSIS not found in ProjectConst ",       114 ); return; }
    unless ( defined $CD_CAN_P3_mintime )    { S_set_error( "! P3_mintime_physical for CUSTOMER_DIAGNOSIS not found in ProjectConst ",    114 ); return; }
    unless ( defined $FlowControl )          { S_set_error( "! FlowControl for CUSTOMER_DIAGNOSIS not found in ProjectConst ",            114 ); return; }
    if     ( ref($FlowControl) ne "ARRAY" )
    {
        S_set_error( " FlowControl is not an array reference", 114 );
        return 0;
    }
    unless ( defined $SAM )                   { S_set_error( "! SAM for CUSTOMER_DIAGNOSIS not found in ProjectConst ",                   114 ); return; }
    unless ( defined $SJW )                   { S_set_error( "! SJW for CUSTOMER_DIAGNOSIS not found in ProjectConst ",                   114 ); return; }
    unless ( defined $Tseg1 )                 { S_set_error( "! Tseg1 for CUSTOMER_DIAGNOSIS not found in ProjectConst ",                 114 ); return; }
    unless ( defined $Tseg2 )                 { S_set_error( "! Tseg2 for CUSTOMER_DIAGNOSIS not found in ProjectConst ",                 114 ); return; }
    unless ( defined $Baudrate )              { S_set_error( "! Baudrate for CUSTOMER_DIAGNOSIS not found in ProjectConst ",              114 ); return; }
    unless ( defined $DLCmode )               { S_set_error( "! DLCmode for CUSTOMER_DIAGNOSIS not found in ProjectConst ",               114 ); return; }
    unless ( defined $DTCdefaultstate )       { S_set_error( "! DTCdefaultstate for CUSTOMER_DIAGNOSIS not found in ProjectConst ",       114 ); return; }
    unless ( defined $DTCdefaultsubfunction ) { S_set_error( "! DTCdefaultsubfunction for CUSTOMER_DIAGNOSIS not found in ProjectConst ", 114 ); return; }
    unless ( defined $DTCbytes )              { S_set_error( "! DTCbytes for CUSTOMER_DIAGNOSIS not found in ProjectConst ",              114 ); return; }

    unless ( defined $Extmode ) { S_set_error( "! ExtAddressing for CUSTOMER_DIAGNOSIS not found in ProjectConst ", 114 ); return; }
    my $Modetext = "extended ID";
    if ( $Extmode == 0 )
    {
        $Modetext = "normal ID";
    }
    unless ( defined $ExtAddressing ) { S_set_error( "! ExtID for CUSTOMER_DIAGNOSIS not found in ProjectConst ", 114 ); return; }
    my $Addrtext = "extended addressing";
    if ( $ExtAddressing == 0 )
    {
        $Ecu_ID = $Targetaddr = 0;
        $Addrtext = "normal addressing";
    }
    unless ( defined $Ecu_ID )     { S_set_error( "! EcuAddr for CUSTOMER_DIAGNOSIS not found in ProjectConst ",    114 ); return; }
    unless ( defined $Targetaddr ) { S_set_error( "! TargetAddr for CUSTOMER_DIAGNOSIS not found in ProjectConst ", 114 ); return; }

    if ( $CD_CAN_P3_mintime < 0 )
    {
        S_set_error( "! P3_mintime_physical is -ve. P3_mintime_physical set to Zero", 0 );
        $CD_CAN_P3_mintime = 0;
    }

    if ($main::opt_offline)
    {
        $CD_CAN_running = 1;
        return 1;
    }

    # check for vector HW
    my ( $IDs_aref, $channels_aref );
    ( $status, $IDs_aref, $channels_aref ) = can_GetHWlist();
    Check_Status($status);

    # set SerialNo if only one HW detected and no entry in testbenchconfig
    if ( scalar(@$IDs_aref) == 1 and not defined $Serialno )
    {
        $Serialno = $$IDs_aref[0];
    }

    # set error if no entry in testbenchconfig (and more than one HW detected)
    unless ( defined $Serialno ) { S_set_error( "CANHWSerialNo not defined in testbenchconfig PD, detected HWs: @$IDs_aref ", 114 ); return; }

    # check if expected HW connected and channel number in range
    my $foundSerialno = 0;
    for ( my $count = 0 ; $count < scalar(@$IDs_aref) ; $count++ )
    {
        if ( $$IDs_aref[$count] == $Serialno )
        {
            $foundSerialno = $Serialno;

        }
    }

    unless ($foundSerialno > 0)
    {
        S_set_error( "! given CANHWSerialNo $Serialno not connected, detected HWs: @$IDs_aref  )", 114 );
        return;
    }

    my $DLCtext = "dynamic";
    if ( $DLCmode == 0 )
    {
        $DLCtext = "static 8 bytes";
    }

    if ($CANscript)
    {
        $status = can_InitWithScript( $CANscript, $CANchannel, S_0x2dec($CD_CAN_ResponseID), $SAM, $SJW, $Tseg1, $Tseg2, $Baudrate, $Extmode, $ExtAddressing, $Ecu_ID, $Targetaddr, $DLCmode, $Serialno );
        Check_Status($status);
        S_w2log( 3, "CD_CAN_start_simulation ($status) on channel $CANchannel with $CANscript DLCmode $DLCtext, $Modetext and $Addrtext\n" );
    }
    else
    {
        $status = can_InitHW( $CANchannel, S_0x2dec($CD_CAN_ResponseID), $SAM, $SJW, $Tseg1, $Tseg2, $Baudrate, $Extmode, $ExtAddressing, $Ecu_ID, $Targetaddr, $DLCmode, $Serialno );
        Check_Status($status);
        S_w2log( 3, "CD_CAN_start_simulation ($status) on channel $CANchannel DLCmode $DLCtext, $Modetext and $Addrtext\n" );
    }

    $status = can_TPXSetFC($FlowControl);
    Check_Status($status);
    S_w2log( 3, "FlowControl ($status) set to ( @$FlowControl )\n" );

    $CD_CAN_running = 1;

    #Save the response ID as previous response ID. so that Port will not be configured for this ID in firstcall of CD_CAN_send_request_wait_response()
    $CD_CAN_PrevResponseID = S_0x2dec($CD_CAN_ResponseID);

    return 1;
}

=head2 CD_CAN_stop_message

 CD_CAN_stop_message( $MSG_handle );

stop cyclic message referred by $MSG_handle

=cut

sub CD_CAN_stop_message
{
    my $MSG_handle = shift;

    unless ( defined($MSG_handle) )
    {
        S_set_error( "! too less parameters ! SYNTAX: CD_CAN_stop_message( MSG_handle )", 110 );
        return 1;
    }

    unless ($CD_CAN_initialized)
    {
        S_set_error( "CD not initialized", 120 );
        return 1;
    }

    return 1 if ($main::opt_offline);

    $status = can_StopMessage($MSG_handle);
    Check_Status($status);
    S_w2log( 5, "can_StopMessage status = $status \n" );
    return 1;

}

=head1 not exported functions

=head2 Check_Status

 Check_Status($result) not exported

if result < 0, log error string and set INCONC.

=cut

sub Check_Status
{
    my $chk_status = shift;

    return 1 if $main::opt_offline;
    if ( $chk_status < 0 )
    {
        my $errortext = can_GetErrorString($chk_status);
        S_set_error( "CD ($chk_status): $errortext", 5 );

    }

    return 1;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHORS

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

