package CAN;

use strict;
use warnings;
use Cwd 'abs_path'; 
use LIFT_simulation;
no strict 'refs';

my $addpath;
BEGIN
{
    
    # add directory to search for additional DLLs
    $addpath = ";".abs_path("./");
    $addpath =~ s/\//\\/g; # replace all slashes with backslahes
    $ENV{PATH} .= $addpath;
}

require Exporter;
require DynaLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use CAN ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
    can_getPMrevision
    can_getXSrevision
    can_getCWrevision
    can_Start
    can_End
    can_InitHW
    can_InitWithScript
    can_GetErrorString
    can_ConfigurePorts
    can_SendMessage
	can_SendMultiFrameMessage
    can_SetEVarray
    can_SetEVvalue
    can_StopMessage
    can_waitForMessage
    can_GetEVarray
    can_GetEVvalue
    can_ModifyCycleTime
    can_ModifyCycleContent
    can_AddEV
    can_RemoveEV
    can_StopWaitingForSessionID
    can_GetEVtype
    can_GetMessageForSessionID
    can_GetHWlist
    can_TPXSendAndGetResponse
	can_TPXSendAndGetAllResponseTimestamp
    can_TPXSetFC
    can_SendAndWaitForResponse
    can_MultiSendAndWaitForResponse
);
our $VERSION = '1.0';

bootstrap CAN $VERSION;

# Preloaded methods go here.

sub can_getPMrevision{
    return ('SCM');
}

sub can_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub can_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

if ( $main::opt_simulation ){
	# redefine all functions for simulation mode with default return values
	foreach my $function (@EXPORT, 'new'){
		# each function in @EXPORT is redefined using SIM_returnValues
		*{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
	}	

	# define return values table (especially for default values) and pass it to simulation module
	my $returnValuesTable_href = {
		'can_TPXSendAndGetResponse' => { 'default' => [ 1, [1, 1, 1], [1] ], },
		'can_TPXSendAndGetAllResponse' => { 'default' => [ 1, [1, 1, 1], [1] ], },
		'can_MultiSendAndWaitForResponse' => { 'default' => [ 1, [1] ], },
	};
	SIM_addToValuesTable( $returnValuesTable_href );

	*can_GetHWlist = sub{
		my $defaultSerialNo;
		if( defined $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANHWSerialNo'} ){
			$defaultSerialNo = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANHWSerialNo'};
		}
		else{
			$defaultSerialNo = '12345';
		}
		return SIM_returnValues('can_GetHWlist', [ 0, [$defaultSerialNo], [1] ], \@_); 
	};

	*can_TPXSendAndGetResponse = sub{
		my $request_aref = $_[0];
		my $response = ${$request_aref}[0] + 64;
		return SIM_returnValues('can_TPXSendAndGetResponse', [ 1, [$response, 1, 1], [1] ], \@_); 
	};
	
	*can_TPXSendAndGetAllResponse = sub{
        my $request_aref = $_[0];
        my $response = ${$request_aref}[0] + 64;
        return SIM_returnValues('can_TPXSendAndGetAllResponse', [ 1, [$response, 1, 1], [1] ], \@_); 
    };
	
}



1;
__END__

=head1 NAME

CAN - Perl extension for generic CAN dll

=head1 SYNOPSIS

  use CAN;

    $ret = can_getPMrevision();
    print "PM $ret\n";
    $ret = can_getXSrevision();
    print "XS $ret\n";
    $ret = can_getCWrevision();
    print "CW $ret\n";

=head1 DESCRIPTION

All these functions are wrapped around CAN_control DLL APIs.


=head2 can_AddEV

 $status = can_AddEV( $name );

add environment variable to simulation, $name should be unique.



=head2 can_ConfigurePorts

 $status = can_ConfigurePorts( $startID, $endID );

configure ports for CAN



=head2 can_End

 $status = mlc_End();

unload CAN_control.DLL



=head2 can_GetEVarray

 ($status, $data_aref) = can_GetEVarray( $name );

read environment variable array



=head2 can_GetEVtype

 $value = can_GetEVtype( $name );

get environment variable type

    1  : for Single DWORD value
    2  : For Array of values
    <0 : On failure



=head2 can_GetEVvalue

 ($status, $value) = can_GetEVvalue( $name );

read environment variable value



=head2 can_GetErrorString

    $errortext = can_GetErrorString( $status );

resolve error string from $status < 0


=head2 can_GetHWlist

    ($status, $IDs_aref, $channels_aref) = can_GetHWlist();

get IDs of connected CAN HW and supported CAN channels


=head2 can_GetMessageForSessionID

 ($status, $ID, $data_aref) = can_GetMessageForSessionID( $sessionID );

This funciton will return the latest frame bytes for infinite waiting session (can_waitForMessage with timeout 0)

In case of Finite waiting session, it will return the first frame bytes and clears session information.

Do not use after can_waitForMessage with timeout > 0 !



=head2 can_InitHW

  $status = can_InitHW( $CANChannel, $RespID, $SAM, $SJW, $Tseg1, $Tseg2, $Baudrate, $Extmode, $ExtAddressing, $Ecu_ID, $Targetadd, $DLCmode, $Serialno )

initalize CAN hardware

    $CANChannel : CAN Channel
    $RespID     : Response Identifier that needs to be configured
    $SAM        : Sample Point Setting
    $SJW        : Synchronization Jump Width
    $Tseg1      : Time Segment 1
    $Tseg2      : Time Segment 2
    $Baudrate   : Baudrate
    $Extmode        : 1 for Extended Identifier, 0 for Standard   
    $ExtAddressing  : 1 for Extended Addressing, 0 for Normal
    $Ecu_ID         : ECU id for Extended Addressing.
    $Targetadd      : Target address for Extended Addressing.
    $DLCmode        : 1 for Dynamic DLC, 0 for Fixed DLC
    $nSerialno      : Serial Number of CAN Hardware.


=head2 can_InitWithScript

  $status = can_InitWithScript( $CANscript, $CANChannel, $RespID, $SAM, $SJW, $Tseg1, $Tseg2, $Baudrate, $Extmode, $ExtAddressing, $Ecu_ID, $Targetadd, $DLCmode, $Serialno )

initalize CAN hardware with simulation script

    $CANscript   : path of can scritp file
    $CANChannel : CAN Channel
    $RespID     : Response Identifier that needs to be configured
    $SAM        : Sample Point Setting
    $SJW        : Synchronization Jump Width
    $Tseg1      : Time Segment 1
    $Tseg2      : Time Segment 2
    $Baudrate   : Baudrate
    $Extmode        : 1 for Extended Identifier, 0 for Standard   
    $ExtAddressing  : 1 for Extended Addressing, 0 for Normal
    $Ecu_ID         : ECU id for Extended Addressing.
    $Targetadd      : Target address for Extended Addressing.
    $DLCmode        : 1 for Dynamic DLC, 0 for Fixed DLC
    $nSerialno      : Serial Number of CAN Hardware.



=head2 can_ModifyCycleContent

 $status = can_ModifyCycleContent( $MSG_handle, $bytes_aref );

modify content of cyclic message

 $bytes_aref = [DLC, Byte1, Byte2 , ...]



=head2 can_ModifyCycleTime

 $status = can_ModifyCycleTime( $MSG_handle, $cycletime) ;

modify cycle time of cyclic message


=head2 can_MultiSendAndWaitForResponse

 ($status,$data_aref) = can_MultiSendAndWaitForResponse( $bytes_aref, $requestID, $responseID, $timeout_ms, $interFrameDelay_ms );

send multiple frames of CAN message and wait for multiple frames of response

 $bytes_aref = [Byte1, Byte2 , ...]

Note:

=over 1

=item * The padding byte (incase if the DLC is not filled by actual bytes) = 0xFF

=item * The Response length will be taken from the First byte of the first response frame

=item * Response array will contain all bytes except Response length (First byte of First frame) byte

=item * The DLC mode will be taken from Initialization (L</can_InitHW>() or L</can_InitWithScript>()) function call. By default, the DLC is 8 bytes

=item * The CAN port should be configured correctly to receive responses from the given Response ID using function L</can_ConfigurePorts>()


=back

=head2 can_RemoveEV

 $status = can_RemoveEV( $name );

remove existing environment variable from simulation.



=head2 can_SendMessage

 $MSG_handle = can_SendMessage( $bytes_aref, $ID, $cycletime, $p3_mintime );

send message, $cycletime = 0 will send only once

 $bytes_aref = [DLC, Byte1, Byte2 , ...]

 $p3_mintime :  minimum time for the client to wait after the successful transmission of a request before sending next request


=head2 can_SendMultiFrameMessage

 $MSG_handle = can_SendMultiFrameMessage( $bytes_aref, $ID, $CD_CAN_Timeout);

send Multi frame message, $cycletime = 0 will sent only once

 $bytes_aref = [ Byte1, Byte2 , ...]
 
 ID = CAN Message ID 
 
 CD_CAN_Timeout: timeout in milli-seconds


=head2 can_SendAndWaitForResponse

 ($status,$data_aref) = can_SendAndWaitForResponse( $bytes_aref, $requestID, $responseID, $timeout_ms );

 send message and wait for response

 $bytes_aref = [DLC, Byte1, Byte2 , ...]



=head2 can_SetEVarray

 $status = can_SetEVarray( $name, $bytes_aref );

set environment variable array



=head2 can_SetEVvalue

 $status = can_SetEVvalue( $name, $vaue);

set environment variable value



=head2 can_Start

 $status = can_Start();

load CAN_control.DLL and initalize function pointers and TP



=head2 can_StopMessage

 $status = can_StopMessage( $MSG_handle );

stop cyclic message



=head2 can_StopWaitingForSessionID

 $status = can_StopWaitingForSessionID( $sessionID );

Function to stop infinite waiting for message session. 
This function will stop waiting for the message Identifier and also clears all session informations. 

Do not use after can_waitForMessage with timeout > 0 !



=head2 can_TPXSendAndGetResponse

 ($status, $resp_aref, $time_aref) = can_TPXSendAndGetResponse( $request_aref, $request_ID, $flowcontrol_ID, $response_ID, $Timeout_ms, $p3_mintime, $manipulated_length);

send request and wait for response
$time_aref contains all delay times of all frames (sum = response time)

    $request_aref    :  [Byte1, Byte2 , ...]
    $request_ID      :  the CAN ID in which the request should be sent
    $flowcontrol_ID  :  the CAN ID in which the flow control should be sent incase of Multibyte response
                (0 = use the $request_ID as $flowcontrol_ID, non-zero = valid flowcontrol CAN ID)
    $response_ID  :  the CAN ID from which the response should be received
                (0 = use the $response_ID from can_InitHW(), non-zero = valid response CAN ID)
    $Timeout_ms      :  timeout in milli-seconds
    $p3_mintime      :  minimum time for the client to wait after the successful transmission of a request before sending next request 
	$manipulated_length : This value can be used to manipulate the length of the request

=head2 can_TPXSendAndGetAllResponseTimestamp

 ($status, $resp_aref, $time_aref) = can_TPXSendAndGetAllResponseTimestamp( $request_aref, $request_ID, $flowcontrol_ID, $response_ID, $Timeout_ms, $p3_mintime, $manipulated_length);

send request and wait for response
$time_aref contains all delay times of all frames (sum = response time)

    $request_aref       :  [Byte1, Byte2 , ...]
    $request_ID         :  the CAN ID in which the request should be sent
    $flowcontrol_ID     :  the CAN ID in which the flow control should be sent incase of Multibyte response
                (0 = use the $request_ID as $flowcontrol_ID, non-zero = valid flowcontrol CAN ID)
    $response_ID        :  the CAN ID from which the response should be received
                (0 = use the $response_ID from can_InitHW(), non-zero = valid response CAN ID)
    $Timeout_ms         :  timeout in milli-seconds
    $p3_mintime         :  minimum time for the client to wait after the successful transmission of a request before sending next request 
	$manipulated_length : This value can be used to manipulate the length of the request
	

=head2 can_TPXSetFC

 $status = can_TPXSetFC( $FC_aref );

sset flow control bytes, default is 30 00 00



=head2 can_waitForMessage

 ($sessionID, $ID, $data_aref) = can_waitForMessage( $IDs_aref, $timeout_ms );

wait for message list

$timeout_ms = 0 will wait until can_StopWaitingForSessionID is called



=head1 TRACEABILITY FUNCTIONS

=head2 can_getPMrevision

returns MKS revision number of .pm file

=head2 can_getXSrevision

returns MKS revision number of .xs file

=cut

=head2 can_getCWrevision

returns MKS revision number of Interface.c file

=cut

=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Arulkumar S, E<lt>Arulkumar.S@in.bosch.comE<gt>

=head1 SEE ALSO

perl, CAN_control documentation

=cut
