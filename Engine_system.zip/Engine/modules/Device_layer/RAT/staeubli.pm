package staeubli;

use strict;
use warnings;
use LIFT_simulation;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
   rat_connect
   rat_transmit
   rat_disconnect
);

our ($VERSION,$HEADER);

my $server;

############################################################################################################

=head1 Control module for Staeubli Robot art via TCP socket 

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 rat_connect

 $status = rat_connect($IP,$port);
 
 e.g. rat_connect('10.10.90.1',22)
 
Connnect to Robot arm.

=cut

sub rat_connect {
    my $IP = shift @_;
    my $port = shift;
	my $timeout = 5000;
	
	my ($Connect_Count,$socket);
    use IO::Socket;
    # Set up the server object
    
    $server = IO::Socket::INET->new(    Proto     => 'tcp',
                                        PeerAddr => $IP ,
                                        PeerPort => $port,
                                        Timeout   => $timeout
                                        );

    return -1 unless ($server);
    
    print "Server port: $port Timeout value: $timeout\n";
    
    $server->autoflush(1);
    print "communication started \n";
	return 0;


}


############################################################################################################

=head2 rat_disconnect

 $status = rat_disconnect();
 
Disconnnect from Robot arm.

=cut

sub rat_disconnect{
      close($server);
	  return 0;
}



############################################################################################################

=head2 rat_transmit

	($status,$answer) = rat_transmit($command);

sends command to robot arm and returns answer.

=cut

sub rat_transmit {
    my $data= shift;

		Write_server($data);
		my $answer=Read_server();
		my $ret=0;
		if ($answer ne 'Ready'){
			$ret = -1;
		}
		
    return ($ret,$answer);
}



################ advanced functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


##################################
# internal function
##################################
sub wait_ms{
    my $time = shift;    
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
}



sub Write_server
{ 
    if ($server) 
    {
        my $text=shift;
        print $server $text."\015\012";      # Send command     
        print "S-> $text\n";       
    } 
    else 
    {
        return 0;
    }
    
}


sub Read_server
{
	my $text;
    while ($text=<$server>) 
    {
        next unless $text =~ /\S/;             # ignore blank lines
        $text =~ s/\r\n$//;
        print "<-R $text\n";       
        return $text;
    }
}


##############################################################################################################################
##############################################################################################################################
#
# simulation functions start here
#

if ( $main::opt_simulation ){

	# redefine all functions for simulation mode with default return values
	foreach my $function (@EXPORT){
		no strict 'refs';
		# each function in @EXPORT is redefined using SIM_returnValues
		*{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
	}

	# define return values table (especially for default values) and pass it to simulation module
	my $returnValuesTable_href = {
		'rat_connect' => { 'default' => [ 0 ], },
		'rat_disconnect' => { 'default' => [ 0 ], },
		'rat_transmit' => { 'default' => [ 0, 1 ], },
	};
	SIM_addToValuesTable( $returnValuesTable_href );

}



1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, robotm arm manual.

=cut



