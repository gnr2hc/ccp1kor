# *****************************************************************************************************
#
#  Copyright (c) 2013  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_RAT;

use strict;
use warnings;
use File::Basename;
use LIFT_general;

use staeubli;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_RAT ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  RAT_connect
  RAT_disconnect
  RAT_position
  RAT_lowlevel_transmit
);

our ( $VERSION, $HEADER );

my $status;
my $RAT_connected;    # flag for RAT initialization

=head1 NAME

LIFT_RAT 

Perl extension for Straeubli robot arm

=head1 SYNOPSIS

    use LIFT_RAT;

    RAT_connect();
    
    RAT_position( $axis, $angle_deg);
    RAT_lowlevel_transmit('MoveAbsJ,0,120,-90,0,15,0');

    RAT_disconnect();

=head1 DESCRIPTION

Provide the possibility to control the RAT (Robotic Airbag Testsystem). 
The ECU can be mounted on the robot arm; then the ECU can be moved in all possible directions.

=head2 Testbench configuration

=head3 Devices section:

    'Devices' => {
        ...
        'RAT' => {
            'IP' => '10.10.90.1',       # TCP socket IP-address of RAT controller
            'port' => 22,               # TCP socket port
        },
        ...
    },

=cut

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 RAT_connect

    RAT_connect( [$ip,$port] );

    e.g. RAT_connect();
         RAT_connect('10.10.90.1',22);
         
Connnect to robot arm via TCP socket. If no connection given, data is taken from Testbenchconfig. 

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub RAT_connect {
    my $ip   = shift;
    my $port = shift;
    unless ( defined($ip) ) {
        $ip = $LIFT_config::LIFT_Testbench->{'Devices'}{'RAT'}{'IP'};
        unless ($ip) {
            S_set_error( "No IP settings for RAT in testbench config found", 20 );
            return 0;
        }
        S_w2log( 1, "no IP given, taking '$ip' from testbench config\n" );
    }
    unless ( defined($port) ) {
        $port = $LIFT_config::LIFT_Testbench->{'Devices'}{'RAT'}{'port'};
        unless ($port) {
            S_set_error( "No port settings for RAT in testbench config found", 20 );
            return 0;
        }
        S_w2log( 1, "no port given, taking '$port' from testbench config\n" );
    }
    if ($RAT_connected) {
        S_set_error( "RAT already initialized", 0 );
        return 0;
    }
    unless ( $ip =~ /^\d+\.\d+\.\d+\.\d+$/ ) {
        S_set_error( "IP $ip is not a valid IP", 109 );
        return 0;
    }
    unless ( $port =~ /^\d+$/ ) {
        S_set_error( "port $port is not a valid number", 109 );
        return 0;
    }

    if ($main::opt_offline) {
        $RAT_connected = 1;
        return 1;
    }
    S_w2log( 4, "RAT: connecting to $ip : $port\n" );

    $status = rat_connect( $ip, $port );
    check_status($status);
    if ( $status < 0 ) {
        S_set_error( "could not initialize RAT", 5 );
        $RAT_connected = 0;
        return 0;
    }
    $RAT_connected = 1;
    return 1;
}

############################################################################################################

=head2 RAT_disconnect

    RAT_disconnect();

Disconnnect from robot arm.

=cut

sub RAT_disconnect {
    S_w2log( 4, "RAT: disconnecting\n" );
    unless ($RAT_connected) {
        S_set_error( "RAT not initialized", 0 );
        return 0;
    }
    if ($main::opt_offline) {

        #clear the global flags
        $RAT_connected = 0;
        return 1;
    }

    $status = rat_disconnect();
    check_status($status);
    $RAT_connected = 0;
    return 1;
}

############################################################################################################

=head2 RAT_position

    RAT_position( $axis, $angle_deg);

Move the robot arm on axis $axis (x, y or z) to angle $angle_deg (in degrees).

=cut

sub RAT_position {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'RAT_position( $axis, $angle)', @args );

    my $axis      = shift @args;
    my $angle_deg = shift @args;

    if ( $axis !~ /^[xyz]$/i ) {
        S_set_error( "\$axis is set to $axis, but it must be one of: 'x', 'y', 'z' ", 109 );
        return 0;
    }

    unless ($RAT_connected) {
        S_set_error( "RAT not initialized", 120 );
        return 0;
    }

    S_w2log( 5, "RAT_position: Moving arm on axis $axis to an angle of $angle_deg deg\n" );

    return 1 if ($main::opt_offline);

    if ( $axis =~ /^x$/i ) {

        # set Robo movement speed
        RAT_lowlevel_transmit('Speed,100,100,100,99999,40');

        # move to the right start position
        RAT_lowlevel_transmit('MoveAbsJ,90.11,9.81,80.09,35.71,-59.8,-56.43');

        # rotate with the def. angle
        RAT_lowlevel_transmit("MoveL,ry,$angle_deg");
    }
    elsif ( $axis =~ /^y$/i ) {

        # set Robo movement speed
        RAT_lowlevel_transmit('Speed,100,100,100,99999,40');

        # move to the right start position
        RAT_lowlevel_transmit('MoveAbsJ,-6.88,117.58,-84.01,92.81,33.85,-51.36');

        # rotate with the def. angle
        RAT_lowlevel_transmit("MoveL,rx,$angle_deg");
    }
    elsif ( $axis =~ /^z$/i ) {

        # set Robo movement speed
        RAT_lowlevel_transmit('Speed,100,100,100,99999,40');

        # move to the right start position
        RAT_lowlevel_transmit('MoveAbsJ,6,97,-74,41,72,-105');

        # rotate with the def. angle
        RAT_lowlevel_transmit("MoveL,rx,$angle_deg");
    }

    return 1;
}

############################################################################################################

=head2 RAT_lowlevel_transmit

    $answer = RAT_lowlevel_transmit( $command );
    
    e.g.
    RAT_lowlevel_transmit('SetFrame,1000');
	RAT_lowlevel_transmit('MoveAbsJ,0,120,-90,0,15,0');
	RAT_lowlevel_transmit('SetInitPos');	

executes given lowlevel command and returns answer.

offline return: 1

=cut

sub RAT_lowlevel_transmit {
    my $command = shift;
    my $answer;

    unless ( defined($command) ) {
        S_set_error( "! too less parameters ! SYNTAX: RAT_lowlevel_transmit( \$command )", 110 );
        return 'error';
    }

    unless ($RAT_connected) {
        S_set_error( "RAT not initialized", 120 );
        return 'error';
    }
    if ($main::opt_offline) {
        return 'offline';
    }

    ( $status, $answer ) = rat_transmit($command);
    check_status($status);

    return ($answer);
}

=head1 not exported functions

=head2 check_status

 check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub check_status {
    my $lstatus = shift;

    return 1 if $main::opt_offline;
    if ( $lstatus < 0 ) {

        #       my $errortext = rat_get_error($lstatus);
        #       S_set_error( "VT ($lstatus): $errortext" , 5);
        S_set_error( "RAT ($lstatus): error occured", 5 );
    }

    return 1;

}

1;

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, robot arm manual.

=cut
