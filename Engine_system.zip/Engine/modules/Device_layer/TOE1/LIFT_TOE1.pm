# *****************************************************************************************************
#
#  Copyright (c) 2014  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_TOE1;

use strict;
use warnings;
use File::Basename;
use LIFT_general;
use LIFT_simulation;

#suppress 'Subroutine redefined' warning locally
local $SIG{__WARN__} = sub {
    my $warning = shift;
    warn $warning unless $warning =~ /Subroutine .* redefined at/;
};

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['..\GPIB', '..\GPIB\GPIB', '..\GPIB\Win32' ], []);
}

use TOE88x5;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use TOE8805 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  TOE1_connect
  TOE1_disconnect
  TOE1_setCurveFile
  TOE1_setCurveRamp
  TOE1_runCurve
  TOE1_runCurveOnTrigger
  TOE1_checkError
  TOE1_setCurveStart
  TOE1_setCurveEnd
  TOE1_initCurve
  TOE1_startCurve
  TOE1_stopCurve
  TOE1_setExecute
  TOE1_setStandby
  TOE1_setRepetition
  TOE1_setVoltage
  TOE1_setCurrent
  TOE1_setMode
  TOE1_writeString
  TOE1_readString
  TOE1_storePage
  TOE1_recallPage
  TOE1_isConnected
  TOE1_saveCurveFile
  TOE1_PPSon
  TOE1_PPSoff
  TOE1_PPSvoltage
  TOE1_createRandomOnOffFile
  TOE1_createGraph
  TOE1_createRampGraph
  TOE1_isCurveRunning
  TOE1_initArbitrary

);

our ( $VERSION, $HEADER );

if ($main::opt_simulation)
{
    # redefine all functions for simulation mode with default return values
    foreach my $function (@EXPORT)
    {
        {
            no strict 'refs';

            # each function in @EXPORT is redefined using SIM_returnValues
            *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); }
        }
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {};
    SIM_addToValuesTable($returnValuesTable_href);

}

=head1 NAME

LIFT_TOE1 

Perl extension for Toellner programmable power supply TOE8805 and TOE8815

=head1 SYNOPSIS

    use LIFT_TOE1;

    my ($status, $DeviceID, $ErrorString);

    $DeviceID = TOE1_connect('GPIB:8');

    TOE1_disconnect();

    $duration = TOE1_setCurveFile("test.sat");
    $duration = TOE1_setCurveRamp(12.6,3.8,3600);
    $string = TOE1_readString();
    $value = TOE1_isConnected();
    $value = TOE1_isCurveRunning();

    TOE1_runCurve();
    TOE1_PPSon();
    TOE1_PPSoff();

    TOE1_initCurve();
    TOE1_setExecute();
    TOE1_startCurve();
    TOE1_stopCurve();
    TOE1_setStandby();
    TOE1_checkError();

    TOE1_setMode(3);
    TOE1_setMode(0);
    TOE1_createRandomOnOffFile("test.sat", 3000, 2000, 700, 500, 12.5, 10.8, 60);
    TOE1_PPSvoltage('U_BATT_DEFAULT');
    TOE1_setCurveStart(2);
    TOE1_setCurveEnd(19);
    TOE1_setRepetition(4);
    $pic = TOE1_createGraph("test.txt",0,'U_BATT_OVERVOLTAGE');
    $pic = TOE1_createRampGraph("test.txt",[0,1.2,2],[3,5.2,12],0,'U_BATT_OVERVOLTAGE');

    TOE1_setVoltage(12.5);
    TOE1_setCurrent(2.5);
    TOE1_saveCurveFile("test.txt",0,23);
    TOE1_writeString("*IDN?");

    TOE1_storePage(3);
    TOE1_recallPage(2);


=head1 DESCRIPTION

remote control functions for TOE8805 and TOE8815 using GPIB.pm via USB or PCI GPIB interface

B<NOTE: National Instruments driver for GPIB has to be installed !>

B<KNOWN ISSUE: TOE8805 does not work with PCI card interface, use USB GPIB interface for TOE8805 to avoid communication problems !>

If you have PCI and USB interface connected, set 'GPIB_device' in testbench config accordingly (usually 1 for 2nd interface, cross-check with NI-MAX)

=cut

my $pps1;

#Help Variables
my ( $status, $DeviceID, $ErrorString );

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 TOE1_connect

    $DeviceID = TOE1_connect( [$connection, $gpibDevice] );

    e.g. $DeviceID = TOE1_connect();
         $DeviceID = TOE1_connect('GPIB:8');
         $DeviceID = TOE1_connect('GPIB:8',1);

    Testbenchconfig:
    'Devices' => {
        'TOE1' => {
            'connect' => 'GPIB:8',
            'GPIB_device' => 1, # optional, default is 0
        },


Connnect to PPS via given connection. If no connection details given, data is taken from Testbenchconfig.
Reads device identification (*IDN). This method has to be called first before any other method can be used.

Make sure Programmable Power Supply is configured accordingly !

Returns Device ID , on error: empty string, offline return: 'dummy'

=cut

sub TOE1_connect
{

    my $connection = shift;
    my $gpibDevice = shift;

    unless ( defined($connection) )
    {
        $connection = $LIFT_config::LIFT_Testbench->{'Devices'}{'TOE1'}{'connect'};
        unless ($connection)
        {
            S_set_error( "No connection settings for TOE1 in testbench config found", 20 );
            return "";
        }
        S_w2log( 5, "no connection given, taking '$connection' from testbench config\n" );
    }

    unless ( defined($gpibDevice) )
    {
        $gpibDevice = $LIFT_config::LIFT_Testbench->{'Devices'}{'TOE1'}{'GPIB_device'};
        unless ($gpibDevice)
        {
            S_w2log( 5, "no GPIBdevice given in testbench config, taking default 0\n" );
            $gpibDevice = 0;
        }
        else
        {
            S_w2log( 5, "no GPIBdevice given, taking '$gpibDevice' from testbench config\n" );
        }
    }

    if ( defined($pps1) )
    {
        S_set_warning( "TOE1 is already connected, nothing done.");
        return 1;
    }

    S_w2log( 4, "TOE1_connect(connection: $connection,GPIB Device: $gpibDevice) : Establishing the connection... \n" );

    if ($main::opt_offline)
    {
        $pps1 = 1;
        $DeviceID = 'offline';
        return "dummy";
    }

    #avoid more connections
    unless ( defined($pps1) )
    {
        $pps1 = TOE88x5->new();
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object could not be created", 1 );    #****
        return "";
    }

    ( $status, $DeviceID ) = $pps1->connect( $connection, $gpibDevice );

    #check error
    check_Status();
    S_w2log( 3, "TOE1_connect: Connection with device ($DeviceID) is successful! \n" );
    return $DeviceID;
}

############################################################################################################

=head2 TOE1_disconnect

    TOE1_disconnect( );

Disconnect from PPS


=cut

sub TOE1_disconnect
{

    S_w2log( 4, "TOE1_disconnect: Disconnecting the device ... \n" );

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_warning( "TOE1 is not connected, nothing done." );
        return 1;
    }

    if ($main::opt_offline)
    {
        undef $pps1;
        return 1;
    }

    $status = $pps1->disconnect();
    check_Status();
    S_w2log( 5, "Status of device $pps1 disconnection: $status \n" );

    undef $pps1;

    S_w2log( 3, "TOE1_disconnect: Terminated the connection with device $DeviceID \n" );

    return;
}

############################################################################################################

=head2 TOE1_setCurveFile

    $duration = TOE1_setCurveFile( $file );
    e.g. $duration = TOE1_setCurveFile("test.sat");

load curve from file and transmit to PPS.

Returns duration, on error 1, offline return: 1

=cut

sub TOE1_setCurveFile
{
    my $file = shift;
    my $duration;

    unless ( defined($file) )
    {
        S_set_error( " SYNTAX: (status,duration) = TOE1_setCurveFile(file);", 110 );
        return 1;
    }

    unless ( -f $file )
    {
        S_set_error( "TOE1_setCurveFile, could not access $file", 1 );
        return 1;
    }

    S_w2log( 4, "TOE1_setCurveFile: To load the curve from file: $file.... \n " );

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    return 1 if $main::opt_offline;

    ( $status, $duration ) = $pps1->setCurveFile($file);
    check_Status();
    S_w2log( 5, "Status of setCurveFile for device $DeviceID: $status \n" );
    S_w2log( 5, "Duration of setCurveFile for device $DeviceID: $duration \n" );

    S_w2log( 3, "TOE1_setCurveFile: Loaded the curve from file $file for the duration of $duration. \n" );
    return $duration;
}

############################################################################################################

=head2 TOE1_initArbitrary

    $duration = TOE1_initArbitrary( $samples, $iteration, $arbitrary_time_aref, $arbitrary_voltage_aref, $current);
    e.g. $duration = TOE1_initArbitrary(4,1,['0.050', '0.050', '0.100', '0.100'], ['0.000','13.500', '0.000', '13.500'],1);

initialize the necessary parameters for execution of arbitrary curve.

Input arguments :

    $samples - Samples available in sat file
	$iteration - Iteration value available in sat file
    $arbitrary_time_aref - Array reference of time values
    $arbitrary_voltage_aref - Array reference of voltage values
    $current - Value of Current in sat file 

Returns duration on success or 1 on error .

=cut

sub TOE1_initArbitrary
{
    my $samples                = shift;
    my $iteration              = shift;
    my $arbitrary_time_aref    = shift;
    my $arbitrary_voltage_aref = shift;
    my $current                = shift;
    my $duration;

    #1,2,3 ...
    unless ( $iteration =~ /^\d+$/ )
    {
        S_set_error( "Iteration ($iteration) should be numeric ", 114 );
        return 1;
    }

    unless ( ref($arbitrary_time_aref) eq 'ARRAY' )
    {
        S_set_error( "Time value is not an array", 114 );
        return 1;
    }
    my $time_aref_count = scalar(@$arbitrary_time_aref);
    if ( $time_aref_count == 0 )
    {
        S_set_error( "Time value is an empty", 114 );
        return 1;
    }

    unless ( ref($arbitrary_voltage_aref) eq 'ARRAY' )
    {
        S_set_error( "Voltage value is not an array", 114 );
        return 1;
    }
    my $voltage_aref_count = scalar(@$arbitrary_voltage_aref);
    if ( $voltage_aref_count == 0 )
    {
        S_set_error( "Voltage value is an empty", 114 );
        return 1;
    }

    # check if there are more than 1000 sample points
    if ( $samples > 1000 )
    {
        S_set_error( "TOE1_initArbitrary: Curve contains $samples samples, too many points\n ", 114 );
        return 1;
    }

    # limit the repetition count
    $iteration = 1 if ( $iteration < 0 or $iteration > 255 );

    my $skipCnt = 0;

    # remove any time points which are of value dt=0.0
    for ( my $count = 0 ; $count < @$arbitrary_time_aref ; $count++ )
    {
        if ( $$arbitrary_time_aref[$count] == 0.0 )
        {
            $skipCnt++;
            splice @$arbitrary_time_aref,    $count, 1;    # remove the contents
            splice @$arbitrary_voltage_aref, $count, 1;
            next;
        }
    }

    if ($skipCnt)
    {
        S_w2log( 4, "TOE1_initArbitrary : Points with dt=0.0 detected and their count is $skipCnt\n" );
        $samples = $samples - $skipCnt;
    }

    # re arrange the voltage & time samples, since toellner stays at the first curve point
    my $last_time = pop(@$arbitrary_time_aref);    # move the last value to the first
    unshift( @$arbitrary_time_aref, $last_time );
    my $last_volt = pop(@$arbitrary_voltage_aref);    # move the last value to the first
    unshift( @$arbitrary_voltage_aref, $last_volt );

    S_w2log( 4, "TOE1_initArbitrary: Initialize the arbitrary for execution... \n" );

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    return 1 if $main::opt_offline;

    ( $status, $duration ) = $pps1->initArbitrary( $samples, $iteration, $arbitrary_time_aref, $arbitrary_voltage_aref, $current );
    check_Status();
    S_w2log( 5, "Status of initArbitrary for device $DeviceID: $status \n" );
    S_w2log( 5, "Duration of initArbitrary for device $DeviceID: $duration \n" );

    S_w2log( 3, "TOE1_initArbitrary: Now arbitrary curve data is ready for execution. Duration of curve is $duration \n" );
    return $duration;
}

############################################################################################################

=head2 TOE1_setCurveRamp

    $duration = TOE1_setCurveRamp( $startV, $endV, $time, [ $start, $end ] );
    e.g. $duration = TOE1_setCurveRamp(12.6,3.8,3600);

create a linear ramp in curve memory from $startV volts to $endV volts and overall duration $time milliseconds.

If no start/end is given, the full range will taken and curve start and curve end will be set automatically.

$time must be between 200 ms and 100000000 ms (~27.7 h) for full range.

The Time stepwidth has to be between 0.2 ms and 100 seconds.

Returns duration on success, on error 1, offline return: 1

=cut

sub TOE1_setCurveRamp
{
    my $startV = shift;
    my $endV   = shift;
    my $time   = shift;
    my $start  = shift;
    my $end    = shift;
    my $duration;

    $start = 0   unless ( defined $start );
    $end   = 999 unless ( defined $end );

    unless ( defined($time) )
    {
        S_set_error( "SYNTAX: (status,duration) = TOE1_setCurveRamp(Vstart,Vend,Time,[start,end]);", 110 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    #avoid string concatenation error/warning and wrong function call
    if ( defined($start) )
    {
        if ( defined($end) )
        {
            S_w2log( 4, "TOE1_setCurveRamp($startV,$endV,$time,[$start,$end]) \n" );
        }
        else
        {
            S_w2log( 4, "TOE1_setCurveRamp($startV,$endV,$time,[$start]) \n" );
        }
    }
    else
    {
        S_w2log( 4, "TOE1_setCurveRamp($startV,$endV,$time) \n" );
    }

    if ( $start > $end )
    {
        S_set_error( "start ($start) > end ($end)", 114 );
        return 1;
    }

    return 1 if $main::opt_offline;

    ( $status, $duration ) = $pps1->setCurveRamp( $startV, $endV, $time, $start, $end );
    check_Status();
    S_w2log( 5, "Status of setCurveRamp of device $DeviceID: $status \n" );
    S_w2log( 5, "Duration of setCurveRamp of device $DeviceID: $duration \n" );

    S_w2log( 3, "TOE1_setCurveRamp: Created linear ramp in curve memory for duration of $duration \n" );
    return $duration;
}

############################################################################################################

=head2 TOE1_runCurve

    TOE1_runCurve( );

run curve from curve memory,setting all starting conditions.

calls setExecute, initCurve and startCurve.

voltage will stay on first curve value after curve is over


=cut

sub TOE1_runCurve
{

    S_w2log( 4, "TOE1_runCurve(): Init and executes the curve \n" );

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    return 1 if $main::opt_offline;

    $status = $pps1->runCurve();
    check_Status();
    S_w2log( 5, "Status of runCurve is $status \n" );

    S_w2log( 3, "TOE1_runCurve done \n" );
    return;
}

############################################################################################################

=head2 TOE1_runCurveOnTrigger

    TOE1_runCurveOnTrigger( );

run curve from curve memory, setting all starting conditions, waiting for external trigger (on pin 12)

calls setExecute, initCurve and startCurve.

voltage will stay on first curve value after curve is over


=cut

sub TOE1_runCurveOnTrigger
{

    S_w2log( 4, "TOE1_runCurveOnTrigger(): Init and executes the curve on external trigger \n" );

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    return 1 if $main::opt_offline;

    $status = $pps1->runCurveOnTrigger();
    check_Status();
    S_w2log( 5, "Status of runCurveOnTrigger of device $DeviceID: $status \n" );

    S_w2log( 3, "TOE1_runCurveOnTrigger done \n" );
    return;
}

############################################################################################################

=head2 TOE1_createRandomOnOffFile

    TOE1_createRandomOnOffFile( $filename, $ONmax, $ONmin, $OFFmax, $OFFmin, $Vmax, $Vmin, $MAXduration );
    e.g. TOE1_createRandomOnOffFile("test.sat", 3000, 2000, 700, 500, 12500, 10800, 60);

create random voltage curve file (switching on and off at random voltage level for random time in given windows).

time $ONmax,$ONmin,$OFFmax,$OFFmin in msec, voltage $Vmax,$Vmin in mV and $MAXduration in seconds


=cut

sub TOE1_createRandomOnOffFile
{

    my $filename    = shift;
    my $ONmax       = shift;
    my $ONmin       = shift;
    my $OFFmax      = shift;
    my $OFFmin      = shift;
    my $Vmax        = shift;
    my $Vmin        = shift;
    my $MAXduration = shift;

    unless ( defined($MAXduration) )
    {
        S_set_error( "SYNTAX: TOE1_createRandomOnOffFile(filename,ONmax,ONmin,OFFmax,OFFmin,Vmax,Vmin,MAXduration)", 109 );
        return 1;
    }

    S_w2log( 3, "TOE1_createRandomOnOffFile $filename\n  ON($ONmin - $ONmax) OFF($OFFmin - $OFFmax) V($Vmin - $Vmax) MAXduration $MAXduration\n" );

    if ($main::opt_offline)
    {
        S_create_dummy_file($filename);
        return 1;
    }
    $status = createRandomOnOffFile( $filename, $ONmax, $ONmin, $OFFmax, $OFFmin, $Vmax, $Vmin, $MAXduration );
    check_Status();
    S_w2log( 5, "Status of createRandomOnOffFile of device $DeviceID: $status \n" );

    S_w2log( 3, "TOE1_createRandomOnOffFile done \n" );
    return;
}

############################################################################################################

=head2 TOE1_createGraph

    $picfile = TOE1_createGraph( $filename, [ $undervoltage, $overvoltage ] );
    e.g.
    $pic = TOE1_createGraph("test.txt");      # no thresholds
    $pic = TOE1_createGraph("test.txt",5);    # only undervoltage
    $pic = TOE1_createGraph("test.txt",0,'U_BATT_OVERVOLTAGE'); # only overvoltage with label

create a graph from curve file with the same filename. if > 0 under and overvoltage thresholds will be added to graph.
Will save picture as *.png and UNIVIEW file as *.txt.unv

Returns:name of created picture.  on error: empty string,   offline return: name of dummy file


=cut

sub TOE1_createGraph
{

    my $filename     = shift;
    my $undervoltage = shift;
    my $overvoltage  = shift;
    my ( $uValue, $oValue );
    my $picfile;

    unless ( defined($filename) )
    {
        S_set_error( "SYNTAX: TOE1_createGraph(filename, [undervoltage, overvoltage])", 110 );
        return "";
    }

    unless ( -f $filename )
    {
        S_set_error( "curve file $filename not found", 1 );
        return;
    }

    if ($main::opt_offline)
    {
        $filename =~ s/\.\w+$//;    # cut off file extension
        $filename =~ s/\//\\/g;     # replace all slashes with backslashes

        S_create_dummy_file( $filename . ".txt.unv" );
        S_create_dummy_pic( $filename . ".png" );
        $picfile = $filename . ".png";
        return $picfile;
    }

    $undervoltage = 0 unless ( defined $undervoltage );
    $overvoltage  = 0 unless ( defined $overvoltage );

    #map voltage if necessary
    unless ( defined( $uValue = $main::ProjectDefaults->{'VEHICLE'}{$undervoltage} ) )
    {
        $uValue = $undervoltage;
    }

    S_w2log( 3, "set undervoltage level to $undervoltage (V $uValue) on TOE1\n" );

    unless ( defined( $oValue = $main::ProjectDefaults->{'VEHICLE'}{$overvoltage} ) )
    {
        $oValue = $overvoltage;
    }

    S_w2log( 3, "set overvoltage level to $overvoltage (V $oValue) on TOE1\n" );

    #place this message here, because undervoltage/overvoltage not defined
    S_w2log( 4, "TOE1_createGraph: Creates a graph with undervoltage $uValue and Overvoltage $oValue \n" );

    ( $status, $picfile ) = createGraph( $filename, $uValue, $oValue );
    check_Status();
    S_w2log( 5, "Status of createGraph is $status \n" );

    S_w2log( 3, "TOE1_createGraph: Created a graph with name $picfile \n" );
    return $picfile;

}

############################################################################################################

=head2 TOE1_createRampGraph

    $picfile = TOE1_createRampGraph( $filename, $rampStruct, [ $undervoltage, $overvoltage ] );
    e.g.
    $pic = TOE1_createRampGraph("test.txt",[[0,1.2,2,0,499],[3,5.2,12]]);                                  # no thresholds, single ramp
    $pic = TOE1_createRampGraph("test.txt",[[0,1.2,2,0,499],[3,5.2,12,500,999]]);                          # no thresholds
    $pic = TOE1_createRampGraph("test.txt",[[0,1.2,2,0,499],[3,5.2,12,500,999]],5);                        # only undervoltage
    $pic = TOE1_createRampGraph("test.txt",[[0,1.2,2,0,499],[3,5.2,12,500,999]],0,'U_BATT_OVERVOLTAGE');   # only overvoltage with label

$rampStruct is an array reference containing array references:

$rampStruct = [
                [$startV_1, $endV_1, $time_1, $start_1, $end_1],
                [$startV_2, $endV_2, $time_2, $start_2, $end_2],
                ;]

Time in milliseconds, Vstart/Vend in volts, start/end in samples. (start >= 000, end <= 999)

For a single ramp start/end can be omitted, then default will be 000/999

create a graph from arrays with given filename. if > 0 under and overvoltage thresholds will be added to graph.
Time delta between 2 poist hast to be between 0.2 ms and 100 s.
Will save picture as *.png and UNIVIEW file as *.txt.unv

Returns:name of created picture.  on error: empty string,   offline return: name of dummy file


=cut

sub TOE1_createRampGraph
{

    my $filename     = shift;
    my $rampStruct   = shift;
    my $undervoltage = shift;
    my $overvoltage  = shift;
    my ( $uValue, $oValue );
    my $picfile;
    unless ( defined($rampStruct) )
    {
        S_set_error( "SYNTAX: TOE1_createRampGraph(filename, RampStruct, [undervoltage, overvoltage])", 110 );
        return "";
    }

    # throw error on old structure
    if ( ref($rampStruct) ne "ARRAY" or ref( $$rampStruct[0] ) ne "ARRAY" )
    {
        S_set_error( " RampStruct is not an array reference containing array references", 114 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $filename =~ s/\.\w+$//;    # cut off file extension
        $filename =~ s/\//\\/g;     # replace all slashes with backslashes
        S_create_dummy_file( $filename . ".txt.unv" );
        S_create_dummy_pic( $filename . ".png" );
        $picfile = $filename . ".png";
        return $picfile;
    }

    $undervoltage = 0 unless ( defined $undervoltage );
    $overvoltage  = 0 unless ( defined $overvoltage );

    #map voltage if necessary
    unless ( defined( $uValue = $main::ProjectDefaults->{'VEHICLE'}{$undervoltage} ) )
    {
        $uValue = $undervoltage;
    }
    S_w2log( 3, "set undervoltage level to $undervoltage (V $uValue) on TOE1\n" );

    unless ( defined( $oValue = $main::ProjectDefaults->{'VEHICLE'}{$overvoltage} ) )
    {
        $oValue = $overvoltage;
    }
    S_w2log( 3, "set overvoltage level to $overvoltage (V $oValue) on TOE1\n" );

    S_w2log( 4, "TOE1_createRampGraph: Creates a ramp graph with under voltage $uValue and over voltage $oValue \n" );

    ( $status, $picfile ) = createRampGraph( $filename, $rampStruct, $uValue, $oValue );

    check_Status();
    S_w2log( 5, "Status of createRampGraph is $status \n" );

    S_w2log( 3, "TOE1_createRampGraph: Created a ramp graph with name $picfile \n" );
    return $picfile;
}

############################################################################################################

=head2 TOE1_saveCurveFile

    TOE1_saveCurveFile( $filename, $start, $end );
    e.g. TOE1_saveCurveFile("test.txt",0,23);

create file from curve memory between $start and $end


=cut

sub TOE1_saveCurveFile
{
    my $filename = shift;
    my $start    = shift;
    my $end      = shift;

    unless ( defined($end) )
    {
        S_set_error( "SYNTAX: TOE1_saveCurveFile(filename,start,end)", 110 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 4, "TOE1_saveCurveFile($filename,$start,$end) \n" );

    if ($main::opt_offline)
    {
        S_create_dummy_file($filename);
        return 1;
    }

    $status = $pps1->saveCurveFile( $filename, $start, $end );
    check_Status();
    S_w2log( 5, "Status of saveCurveFile is $status \n" );

    S_w2log( 3, "TOE1_saveCurveFile done \n" );
    return;
}

############################################################################################################

=head2 TOE1_PPSvoltage

    TOE1_PPSvoltage( $voltage, [ $maxcurrent ] );
    e.g. TOE1_PPSvoltage('U_BATT_DEFAULT');
         TOE1_PPSvoltage(12.5);


set output voltage, do all required steps to fulfill preconditions (this will stop a running curve!).
maps voltage via project defaults if necessary.

if no $maxcurrent is given, 4 A will be set as default.


=cut

sub TOE1_PPSvoltage
{
    my $volts      = shift;
    my $maxcurrent = shift;
    my $value;

    $maxcurrent = 4 unless ( defined $maxcurrent );

    unless ( defined($volts) )
    {
        S_set_error( "SYNTAX: TOE1_PPSvoltage(voltage[,maxcurrent])", 110 );
        return 1;
    }

    #map voltage if necessary
    unless ( defined( $value = $main::ProjectDefaults->{'VEHICLE'}{$volts} ) )
    {
        if ( $volts =~ /^\d+\.?\d*$/ )
        {
            $value = $volts;
        }
        else
        {
            S_set_error( "could not resolve voltage $volts", 114 );
            return 1;
        }
    }

    #parameter range check
    if ( ( $value < 0 ) || ( $value > 32 ) )
    {
        S_set_error( "voltage $value out of range (0<=x<=32)", 114 );
        return 1;
    }

    #parameter range check
    if ( ( $maxcurrent < 0 ) || ( $maxcurrent > 4 ) )
    {
        S_set_error( "current $maxcurrent out of range (0<=x<=4)", 114 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_PPSvoltage: set voltage to $volts (V $value) on TOE1\n" );

    return 1 if $main::opt_offline;

    $status = $pps1->PPSvoltage( $value, $maxcurrent );
    check_Status();
    S_w2log( 5, "Status of PPSvoltage is $status \n" );

    S_w2log( 4, "TOE1_PPSvoltage done \n" );

    return;
}

############################################################################################################

=head2 TOE1_PPSon

    TOE1_PPSon( );

set output to ON, do all required steps to fulfil preconditions (this will stop a running curve!).


=cut

sub TOE1_PPSon
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return;
    }

    S_w2log( 4, "TOE1_PPSon() \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->PPSon();
    check_Status();
    S_w2log( 5, "PPSon status is $status \n" );

    S_w2log( 3, "Func TOE1_PPSon done \n" );
    return;
}

############################################################################################################

=head2 TOE1_PPSoff

    TOE1_PPSoff( );

set output to OFF, do all required steps to fulfil preconditions (this will stop a running curve!).


=cut

sub TOE1_PPSoff
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 4, "TOE1_PPSoff() \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->PPSoff();
    check_Status();
    S_w2log( 5, "PPSoff status is $status \n" );

    S_w2log( 3, "Func TOE1_PPSoff success\n" );

    return;
}

######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut

############################################################################################################

=head2 TOE1_checkError

    TOE1_checkError( );

read error status (*ESR?,ERR?) and report error if there is one


=cut

sub TOE1_checkError
{
    my $value;

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    return 1 if $main::opt_offline;

    ( $status, $value ) = $pps1->checkError();
    check_Status();
    S_w2log( 5, "checkError status is $status \n" );
    S_w2log( 5, "checkError value is $value \n" );

    return;
}

############################################################################################################

=head2 TOE1_setCurveStart

    TOE1_setCurveStart( $point );
    e.g. TOE1_setCurveStart(2);

set start point for curve (FAS X)


=cut

sub TOE1_setCurveStart
{
    my $start = shift;

    unless ( defined($start) )
    {
        S_set_error( "SYNTAX: TOE1_setCurveStart(point)", 110 );
        return 1;
    }

    #parameter range check
    if ( ( $start < 0 ) || ( $start > 999 ) )
    {
        S_set_error( "start point $start out of range (0<=x<=999)", 114 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return;
    }

    S_w2log( 3, "TOE1_setCurveStart start point: $start \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->setCurveStart($start);
    check_Status();
    S_w2log( 5, "setCurveStart status is $status \n" );
    S_w2log( 3, "Func TOE1_setCurveStart success \n" );

    return;
}

############################################################################################################

=head2 TOE1_setCurveEnd

    TOE1_setCurveEnd( $point );
    e.g. TOE1_setCurveEnd(19);

set end point for curve (FAE X).


=cut

sub TOE1_setCurveEnd
{
    my $end = shift;

    unless ( defined($end) )
    {
        S_set_error( "SYNTAX: TOE1_setCurveEnd(point)", 110 );
        return 1;
    }

    #parameter range check
    if ( ( $end < 0 ) || ( $end > 999 ) )
    {
        S_set_error( "end point $end out of range (0<=x<=999)", 114 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_setCurveEnd end point: $end \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->setCurveEnd($end);
    check_Status();
    S_w2log( 5, "setCurveEnd status is $status \n" );
    S_w2log( 3, "Func TOE1_setCurveEnd success\n" );

    return;
}

############################################################################################################

=head2 TOE1_initCurve

    TOE1_initCurve( );

reset curve to start point (FCL)


=cut

sub TOE1_initCurve
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_initCurve: Initilizes the curve.... \n" );

    return 1 if $main::opt_offline;
    $status = $pps1->initCurve();
    check_Status();
    S_w2log( 5, "initCurve status is $status \n" );
    S_w2log( 3, "Func TOE1_initCurve: Curve is initialized successfully \n" );

    return;
}

############################################################################################################

=head2 TOE1_startCurve

    TOE1_startCurve( );

start curve (FS) if start conditions are fulfilled

voltage will stay on first curve value after curve is over


=cut

sub TOE1_startCurve
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_startCurve: starts the curve loading..... \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->startCurve();
    check_Status();
    S_w2log( 5, "startCurve status is $status \n" );
    S_w2log( 3, "TOE1_startCurve: Curve started successfully \n" );

    return;
}

############################################################################################################

=head2 TOE1_stopCurve

    TOE1_stopCurve( );

stop curve (FP)


=cut

sub TOE1_stopCurve
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_stopCurve: stops the curve loading..... \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->stopCurve();
    check_Status();
    S_w2log( 5, "stopCurve status is $status \n" );
    S_w2log( 3, "TOE1_stopCurve: Curve stopped successfully \n" );

    return;
}

############################################################################################################

=head2 TOE1_setExecute

    TOE1_setExecute( );

set output to execute (EX 1)


=cut

sub TOE1_setExecute
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_setExecute: setting the curve to execute.... \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->setExecute();
    check_Status();
    S_w2log( 5, "setExecute status is $status \n" );
    S_w2log( 3, "TOE1_setExecute: Curve executed successfully \n" );

    return;
}

############################################################################################################

=head2 TOE1_setStandby

    TOE1_setStandby( );

set output to standby (EX 0)


=cut

sub TOE1_setStandby
{
    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_setStandby: Setting the system to standby mode... \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->setStandby();
    check_Status();
    S_w2log( 5, "setStandby status is $status \n" );
    S_w2log( 3, "TOE1_setStandby: Device $DeviceID is in standby \n" );

    return;
}

############################################################################################################

=head2 TOE1_setRepetition

    TOE1_setRepetition( $repeat );
    e.g. TOE1_setRepetition(4);

set repetition for curve (FB x)


=cut

sub TOE1_setRepetition
{
    my $repeat = shift;

    unless ( defined($repeat) )
    {
        S_set_error( "SYNTAX: TOE1_setRepetition(repeat)  \n", 110 );
        return 1;
    }

    #parameter range check
    if ( ( $repeat < 0 ) || ( $repeat > 255 ) )
    {
        S_set_error( "repetition $repeat out of range (0<=x<=255)", 114 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_setRepetition: Ready to repeat the  curve for $repeat iterations \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->setRepetition($repeat);
    check_Status();
    S_w2log( 5, "setRepetition status is $status \n" );
    S_w2log( 3, "TOE1_setRepetition: Curve setted to repetition for $repeat iterations successfully \n" );

    return;
}

############################################################################################################

=head2 TOE1_setVoltage

    TOE1_setVoltage( $voltage );
    e.g. TOE1_setVoltage(12.5);
         TOE1_setVoltage('U_BATT_DEFAULT');



set output voltage (V x)


=cut

sub TOE1_setVoltage
{
    my $volts = shift;
    my $value;
    unless ( defined($volts) )
    {
        S_set_error( "SYNTAX: TOE1_setVoltage(voltage)  \n", 110 );
        return 1;
    }

    #map voltage if necessary
    unless ( defined( $value = $main::ProjectDefaults->{'VEHICLE'}{$volts} ) )
    {
        if ( $volts =~ /^\d+\.?\d*$/ )
        {
            $value = $volts;
        }
        else
        {
            S_set_error( "could not resolve voltage $volts", 114 );
            return 1;
        }
    }

    #parameter range check
    if ( ( $value < 0 ) || ( $value > 32 ) )
    {
        S_set_error( "voltage $value out of range (0<=x<=32)", 114 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_setVoltage: sets the device $DeviceID for $volts V \n" );

    return 1 if $main::opt_offline;

    #    S_w2log( 4, "set voltage to $volts (V $value) on TOE1 \n" );

    $status = $pps1->setVoltage($value);
    check_Status();
    S_w2log( 5, "status of setVoltage is $status \n" );
    S_w2log( 3, "TOE1_setVoltage: Now device is setted to $volts V successfully \n" );

    return;
}

############################################################################################################

=head2 TOE1_setCurrent

    TOE1_setCurrent( $current );
    e.g. TOE1_setCurrent(2.5);

set maximum output current (C x)


=cut

sub TOE1_setCurrent
{
    my $current = shift;

    unless ( defined($current) )
    {
        S_set_error( "SYNTAX: TOE1_setCurrent(current)", 110 );
        return 1;
    }

    #parameter range check
    if ( ( $current < 0 ) || ( $current > 4 ) )
    {
        S_set_error( "current $current out of range (0<=x<=4)", 114 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_setCurrent: sets the device $DeviceID for $current amps \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->setCurrent($current);
    check_Status();
    S_w2log( 5, "setCurrent status is $status \n" );
    S_w2log( 3, "TOE1_setCurrent: Current setted successfully\n" );

    return;
}

############################################################################################################

=head2 TOE1_setMode

    TOE1_setMode( $mode );
    e.g. TOE1_setMode(3);

set output mode (F x)

0 = power supply mode, 1 = external voltage control, 2 = external current control, 3 = arbitrary mode


=cut

sub TOE1_setMode
{
    my $mode = shift;

    unless ( defined($mode) )
    {
        S_set_error( "SYNTAX: TOE1_setMode(mode)", 110 );
        return;
    }

    #parameter range check
    if ( ( $mode < 0 ) || ( $mode > 3 ) )
    {
        S_set_error( "mode $mode out of range (0<=x<=3)", 114 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_setMode:sets the device $DeviceID to mode $mode \n" );

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    return 1 if $main::opt_offline;

    $status = $pps1->setMode($mode);
    check_Status();
    S_w2log( 5, "setMode status is $status \n" );
    S_w2log( 3, "TOE1_setMode: Mode setted successfully\n" );

    return;
}

############################################################################################################

=head2 TOE1_writeString

    TOE1_writeString( $string );
    e.g. TOE1_writeString("*IDN?");

write string directly to PPS


=cut

sub TOE1_writeString
{
    my $string = shift;

    unless ( defined($string) )
    {
        S_set_error( "SYNTAX: TOE1_writeString(string)", 110 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_writeString: writes the string ($string)\n" );

    return 1 if $main::opt_offline;

    $status = $pps1->writeString($string);
    check_Status();
    S_w2log( 5, "writeString status is $status \n" );
    S_w2log( 3, "TOE1_writeString: success\n" );

    return;
}

############################################################################################################

=head2 TOE1_readString

    $string = TOE1_readString( );

read string directly from PPS

Returns string, on error empty string, offline return 'dummy'

=cut

sub TOE1_readString
{

    my $string;

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    return 'dummy' if $main::opt_offline;

    ( $status, $string ) = $pps1->readString();

    check_Status();
    S_w2log( 5, "readString status is $status \n" );
    S_w2log( 3, "TOE1_readString: string read is  $string \n" );
    S_w2log( 4, "TOE1_readString success\n" );

    return $string;
}

############################################################################################################

=head2 TOE1_storePage

    TOE1_storePage( $page );
    e.g. TOE1_storePage(3);

store current curve on memory card page (CST x).

1 page = 16 K, so a 256 K memory card has 16 pages (0 to15)


=cut

sub TOE1_storePage
{
    my $page = shift;

    unless ( defined($page) )
    {
        S_set_error( "SYNTAX: TOE1_storePage(page)", 110 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 4, "TOE1_storePage: Stores the curve to $page pages \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->storePage($page);
    check_Status();
    S_w2log( 5, "storePage status is $status \n" );
    S_w2log( 3, "TOE1_storePage: success\n" );

    return;
}

############################################################################################################

=head2 TOE1_recallPage

    TOE1_recallPage( $page );
    e.g. TOE1_recallPage(2);

load curve from memory card page (CRC x).

wait some time (about 300 ms) between stop curve and recall next page


=cut

sub TOE1_recallPage
{
    my $page = shift;

    unless ( defined($page) )
    {
        S_set_error( "SYNTAX: TOE1_recallPage(page)", 110 );
        return 1;
    }

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_recallPage: Loads the curves from $page pages \n" );

    return 1 if $main::opt_offline;

    $status = $pps1->recallPage($page);
    check_Status();
    S_w2log( 5, "recallPage status is $status \n" );
    S_w2log( 3, "TOE1_recallPage: success\n" );

    return;
}

############################################################################################################

=head2 TOE1_isConnected

    $value = TOE1_isConnected( );

check if PPS is connected

Returns 1 if true, 0 if false,  Error: < 0,      offline return: 1

=cut

sub TOE1_isConnected
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    S_w2log( 3, "TOE1_isConnected: Checks for device $DeviceID is connected... \n" );

    return 1 if $main::opt_offline;

    S_w2log( 3, "TOE1_isConnected: Checking of connection \n" );
    return ( $pps1->isConnected() );
}

############################################################################################################

=head2 TOE1_isCurveRunning

    $value = TOE1_isCurveRunning( );

check if curve is running,

Returns 0 for curve not running, 1 curve running,  Error: < 0 ,   offline return: 0

=cut

sub TOE1_isCurveRunning
{

    #fix object error
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 0;
    }

    S_w2log( 3, "TOE1_isCurveRunning: Checks for curve is running or not ....... \n" );

    return 0 if $main::opt_offline;

    $status = $pps1->isCurveRunning();
    check_Status();
    S_w2log( 5, "TOE1_isCurveRunning: status is $status \n" );
    S_w2log( 3, "Func TOE1_isCurveRunning success \n" );
    return $status;
}

############################################################################################################

=head1 not exported functions

=head2 check_Status

    check_Status( ); not exported

check occurred error and write error message from low level Modul in Report File. this method will not be import (use only local)

Returns

        offline: 1

=cut

sub check_Status
{

    return 1 if $main::opt_offline;

    if ( $status < 0 )
    {
        $ErrorString = getErrorString($status);
        S_set_error( "TOE1: $ErrorString", 5 );
    }
    return;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Toellner manual.

=cut
