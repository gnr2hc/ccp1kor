package TOE88x5;

use strict;
use warnings;
use File::Basename;
use GD::Graph::lines;

# need to add in calling module
#BEGIN
#{
#    # add directories to search path for perl modules
#    unshift @INC, dirname( $0 )."/modules/GPIB";
#    unshift @INC, dirname( $0 )."/modules/GPIB/GPIB";
#}

use GPIB;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use TOE88x5 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
    createGraph
    createRampGraph
    createRandomOnOffFile
    getErrorString
);

our ($VERSION,$HEADER);


#Error definitions for Toellner
my %Error_Hash = (
             0 => "no Error is success",
            -1 => "open File, access error",
            -2 => "Function parameters error",
            -3 => "Internal function calling error, response is wrong",
            -4 => "TOE88x5: Connection fail, device is not present ",
            -5 => "TOE88x5: Connection Error, Device ID cannot be read",
            -6 => "TOE88x5: Connection Error, Device is allready connected",
            -7 => "TOE88x5: Disconnection error, device was not connected",
            -8 => "TOE88x5: Connection Error, Device is not connected",
            -9 => "TOE88x5: Curve is running",
            -10 => "Not able to create dir ", 
            -11 => "File is empty",
            -12 => "TOE88x5: ERROR String : not defined ****",
            -13 => "TOE88x5: ERROR String : not defined ****",
            -14 => "TOE88x5: ERROR String : not defined ****",
            -15 => "TOE88x5: Object cannot be created",          
            -16 => "TOE88x5: Connection fail, Parameter error, use following function call format: connect(\$connection); Example:  connect('GPIB: 8')",
            -17 => "TOE88x5: setCurveFile failed, Parameter error, use following function call format: (\$status,\$String) = setCurveFile(file, [\$pic_mode]); Example: setCurveFile(\"C:\\test.txt\", 2);, see Function documentation for more Info",
            -18 => "TOE88x5: setCurveRamp failed, Parameter error, use following function call format: (\$status,\$String) = setCurveRamp(Vstart,Vend,Time,[start,end]); Example: setCurveRamp(12.6,3.8,1000,1,5);, see Function documentation for more Info",
            -19 => "TOE88x5: createRandomOnOffFile, Parameter error, use following function call format: \$status = createRandomOnOffFile(filename,ONmax,ONmin,OFFmax,OFFmin,Vmax,Vmin,MAXduration); example: createRandomOnOffFile(\"test.sat\", 3000, 2000, 700, 500, 12.5, 10.8, 60);, see Function documentation for more Info",
            -20 => "TOE88x5: createGraph, Parameter error, use following function call format: (\$status,\$picfile) = createGraph(filename, [undervoltage, overvoltage]);, Example: createGraph(\"test.txt\");", 
            -21 => "TOE88x5: createRampGraph, Parameter error, use following function call format: (\$status,\$picfile) = createRampGraph(filename, RampStruct, [\$undervoltage, \$overvoltage]);, Example: createRampGraph(\"test1.txt\",[[0,1.2,2]]);",            
            -22 => "TOE88x5: setCurveRamp: Parameter Error, Time must between 200 ms and 100000000 ms (~27.7 h) for full range. Time Step is: Time / ((end-start +1 ) * 1000)",
            -23 => "TOE88x5: saveCurveFile: Parameter Error, use following function call format:  \$status = \$pps-> saveCurveFile(\$filename,\$start,\$end); Example: saveCurveFile(\"test.txt\",1,12);",
            -24 => "TOE88x5: checkError, communication error: no status received ",
            -25 => "TOE88x5: PPSvoltage, Parameter Error, use following function call format: \$status = \$pps->PPSvoltage(\$voltage[,\$maxcurrent]); Example: PPSvoltage(12.4), voltage range = 0 ... 32",        
            -26 => "TOE88x5: setCurveStart, Parameter Error, use following function call format: \$pps->setCurveStart(\$point); Example:  setCurveStart(001), point range = 0 ... 999 ",
            -27 => "TOE88x5: setCurveEnd, Parameter Error, use following function call format: \$pps->setCurveEnd(\$point); Example: setCurveEnd(19), \$point range = 0 ... 999",
            -28 => "TOE88x5: setRepetition, Parameter Error, use following function call format: \$status = \$pps->setRepetition(\$repeat); Example: setRepetition(1), repeat range = 0 ... 255",
            -29 => "TOE88x5: setVoltage, Parameter Error, use following function call format: \$status = \$pps->setVoltage(\$voltage); Example: setVoltage(12.5), voltage range = 0 ... 32",
            -30 => "TOE88x5: setCurrent, Parameter Error, use following function call format: \$status = \$pps->setCurrent(\$current); Example: setCurrent(3.5), current range = 0 ... 5",
            -31 => "TOE88x5: setMode, Parameter Error, use following function call format: \$status =  \$pps->setMode(\$mode); Example: setMode(3)",            
            -32 => "TOE88x5: writeString, Parameter Error, use following function call format: \$status =  \$pps->writeString(\$string); Example: writeString(\"*IDN?\")",
            -33 => "TOE88x5: readString, communication timeout while reading",
            -34 => "TOE88x5: readString, communication error while reading",
            -35 => "TOE88x5: storePage, Parameter Error, use following function call format: \$status = \$pps->storePage(\$page); Example: storePage(3)",            
            -36 => "TOE88x5: recallPage, Parameter Error, use following function call format: \$status = \$pps->recallPage(\$page); Example: recallPage(2)"
            );

my $ErrorString;
my $MAXdeviceAMP = 4;
my $MAXdeviceVOLT = 32;
my $MINdeviceDELAY = 0.0002;	# minimum Arbitrary delay time in seconds
my $MAXdeviceDELAY = 100.0;		# maximum Arbitrary delay time in seconds

=head1 NAME

TOE88x5  

Perl extension for Toellner programmable power supply TOE8805/TOE8815

=head1 SYNOPSIS

    use TOE88x5;

    my ($pps, $value, $string, $duration);
    my %Error_Hash(...);
    
    my $PPS_handle;
    my $logfile_handle;


    $pps = TOE88x5->new(\*LOG);
    ($status , $String) =$pps->connect('GPIB:8',0);
    
    $status = createGraph("test.txt");
    $status = createRandomOnOffFile("test.sat", 3000, 2000, 700, 500, 12.5, 10.8, 60);
    $Response = getErrorString($ErrorCode);
    ($status,$picfile) = createRampGraph("test1.txt",[0,1.2,2],[3,5.2,12]);
    
    
    ($status , $duration) = $pps->setCurveRamp(12.6,3.8,360);
    ($status , $duration) = $pps->setCurveRamp(12.6,3.8,1000,1,5); 
    ($status , $duration) = $pps->setCurveRamp(3.8,12.6,2000,6,12); 
    ($status , $duration) = $pps->setCurveFile("test.sat", 2);
    ($status , $value) = $pps->checkError();
    
    $status = $pps->runCurve();
    
    $status = $pps->setCurveStart(001);    
    $status = $pps->setCurveEnd(012);    
    $status = $pps->setRepetition(1);
    $status = $pps->saveCurveFile("test.txt",1,12);

    $status = $pps->PPSvoltage(12.4);     
    $status = $pps->PPSon(); 
    $status = $pps->PPSoff(); 

    $status = $pps->setCurveStart(002);
    $status = $pps->setCurveEnd(019);
    $status = $pps->setRepetition(4);
    $status = $pps->setMode(3);
    
    $status = $pps->initCurve();
    
    $status = $pps->setExecute();
    $status = $pps->startCurve();
    
    $value = $pps->isCurveRunning();
    $status = $pps->stopCurve();
    $status = $pps->setStandby();

    $status = $pps->setMode(0);
    $status = $pps->setVoltage(12.5);
    $status = $pps->setCurrent(3.5);

    $status = $pps->writeString("*IDN?");
    $string = $pps->readString();
    
    $status = $pps->storePage(3);
    $status = $pps->recallPage(2);
    $value = $pps->isConnected();

    $value = $pps->disconnect();


=head1 DESCRIPTION

remote control functions for TOE8805/TOE8815 using GPIB.pm

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut




=head1 PPS INDEPENDANT METHODS (exported)

=cut

############################################################################################################

=head2 $status = createRandomOnOffFile($filename,$ONmax,$ONmin,$OFFmax,$OFFmin,$Vmax,$Vmin,$MAXduration);

create random voltage curve file (switching on and off at random voltage level for random time in given windows). 

time: $ONmax,$ONmin,$OFFmax,$OFFmin in msec, voltage: $Vmax,$Vmin in mV and $MAXduration in seconds.

Returns:    

            status:  Success: 0,         Error: Error Code < 0.     

=cut

sub createRandomOnOffFile{

  my $filename = shift;
  my $ONmax = shift; 
  my $ONmin = shift; 
  my $OFFmax = shift;
  my $OFFmin = shift;  
  my $Vmax = shift;
  my $Vmin = shift;
  my $MAXduration = shift; 
  my $ErrorCode;

#ToDo check if Vmax > MAXdeviceVOLT 

  #parameter check, only last parameter
  unless( defined($MAXduration) )
  {   
      $ErrorCode = -19;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: createRandomOnOffFile: $ErrorString  \n");
      return $ErrorCode;
  }
  
  my $save_dir = dirname($filename);

  unless (-d $save_dir ){
    w2log ("creating directory $save_dir \n");
      
    unless( mkdir( $save_dir ) ) { 
        $ErrorCode = -10;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: createRandomOnOffFile: $ErrorString $save_dir : $! \n");
        return $ErrorCode;
    }
  }
  
  #avoid division of a not defined value
  $ONmax = $ONmax/1000;
  $ONmin = $ONmin/1000;
  $OFFmax =$OFFmax/1000;
  $OFFmin =$OFFmin/1000;
  $Vmax = $Vmax/1000;
  $Vmin = $Vmin/1000;
  
  w2log("creating random curve file $filename \n");
  w2log("ON($ONmin - $ONmax) OFF($OFFmin - $OFFmax) V($Vmin - $Vmax) MAXduration $MAXduration \n");

  my ($points, $duration,$ONtime,$OFFtime,$volts);
  my @filecontent=("\n","U[V]   t[s]\n");
  
  $duration = 0;
  $points = 0;
  
  while ($duration<$MAXduration and $points <= 1000){

    $ONtime = rand($ONmax-$ONmin)+$ONmin;
    $OFFtime = rand($OFFmax-$OFFmin)+$OFFmin;
    $volts = rand($Vmax-$Vmin)+$Vmin;

    $ONtime = sprintf("%6.3f", $ONtime);
    $OFFtime = sprintf("%6.3f", $OFFtime);
    $volts = sprintf("%6.3f", $volts);

    push(@filecontent," $volts $ONtime\n");
    push(@filecontent,"  0.000 $OFFtime\n");
    $points++;
    $duration+=$ONtime+$OFFtime;
  }
  
  # put on top of file
  unshift(@filecontent,"Wiederholungen:  1\n");
  unshift(@filecontent,"Strombegrenzung: 4.00\n");
  unshift(@filecontent,"Punkte:          $points\n");
  unshift(@filecontent,"Dateiname:       $filename\n");
  
  #avoid error by open File
  if(open (FILE,">$filename") )
  {
    print FILE @filecontent;
    close (FILE);
  }
  else {
    $ErrorCode = -1;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: createRandomOnOffFile: $ErrorString $filename \n");
    return $ErrorCode;
  }
  
  # create file but return with error if 1000 points are exceeded
  if($points>1000){
      $ErrorCode = -2;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: createRandomOnOffFile, $ErrorString, $filename too many points\n");
      return $ErrorCode;
  }
  
  return 0;

}



############################################################################################################

=head2 ($status,$picfile) = createGraph($filename, [$undervoltage, $overvoltage]);

create a graph from curve file with the same filename. if > 0 under and overvoltage thresholds will be added to graph. 
Will save picture as *.png and UNIVIEW file as *.txt.unv

Returns:    

            1. status:      Success: 0,                                 Error: Error Code< 0.             
            2. picfile:     Success: File name of the created file,     Error: empty.

    e.g.
    ($status,$picfile) = createGraph("test.txt");      # no thresholds 
    ($status,$picfile) = createGraph("test.txt",5);    # only undervoltage
    ($status,$picfile) = createGraph("test.txt",0,10); # only overvoltage

=cut

sub createGraph{

  my $file=shift;
  my $undervoltage = shift;
  my $overvoltage = shift;
  my ($line,@Volts,@Time,$UV_id,$OV_id);
  my @legend_keys = ("battery voltage");
  my $ErrorCode;
  my $locFileHelper = $file;
  
  #parameter check, only last parameter
  unless( defined($file) )
  { 
    $ErrorCode = -20;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return ($ErrorCode,"");
  }
  
  unless (-f $file)
  {  
    $ErrorCode = -1;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: createGraph: $ErrorString $file \n");
    return ($ErrorCode, "");
  }
  
  if(defined ($undervoltage) && defined($overvoltage) ) 
  {
    w2log("createGraph($file, [$undervoltage, $overvoltage]) \n");
  }
  else {
    w2log("createGraph($file )\n");
  }

  @Volts=@Time=();
  my $duration = 0;
  
  if( open(IN,"<$file") )
  {
      while($line = <IN>){
        if ($line =~ /^\s*([\d.]+)\s+([\d.]+)/){
          push(@Volts,$1);
          push(@Time,$2);
          $duration += $2;
        }
      }
  }
  else {
     $ErrorCode = -1;
     $ErrorString = getErrorString($ErrorCode);
     w2log("**** ERROR: createGraph: $ErrorString $file \n");
     return ($ErrorCode, "");
  }
  
  w2log("creating graph from $file \n");
    
  #create graph
  $file =~ s/\.\w+$//; # cut off file extension
  $file =~ s/\//\\/g; # replace all slashes with backslashes

  #delete file if existing
  unlink("$file.txt.unv");

  my ($i, $graph,  @data, $element, $current_time);
  my ($val, $dt, $last_time);
#  my $step = 0.001;
  my ($nbr_of_data_elements,$step);
  
  @data=();
    
  $last_time = $current_time=0;

  #set undervoltage and overvoltage if not defined
  $undervoltage = 0 unless (defined $undervoltage);
  $overvoltage = 0 unless (defined $overvoltage);
     
  my @linestypes = (1);
     
  if ($undervoltage > 0){$UV_id=2;push(@linestypes,2);} else {$UV_id=1;} 
  if ($overvoltage > 0){$OV_id=$UV_id+1;push(@linestypes,2);} else {$OV_id=1;} 
  
  #avoid Error by empty file
  if(@Time != 0)
  {
	  $nbr_of_data_elements=scalar(@Time);
	  $step = $duration/($nbr_of_data_elements*100);  # set plot stepwidth to 1/100 of the average time distance between 2 points
	  $step = 0.001 if ($step < 0.001); # minimum clipping of stepwidth
#	  w2log("step $step  elem $nbr_of_data_elements end $Time[-1]  $duration\n");

      # loop over all points
      for ($i=0; $i<@Time; $i++){
        $val = $Volts[$i];
        $dt = $Time[$i];
        while ($current_time < ($last_time+$dt)){
#  w2log("time $current_time val $val\n");
            push (@{$data[0]},$current_time);
            push (@{$data[1]},$val);
            if ($undervoltage > 0){push (@{$data[$UV_id]},$undervoltage);}
            if ($overvoltage > 0){push (@{$data[$OV_id]},$overvoltage);}
            $current_time+=$step;
        }
        push (@{$data[0]},$current_time);
        push (@{$data[1]},$val);
        if ($undervoltage > 0){push (@{$data[$UV_id]},$undervoltage);}
        if ($overvoltage > 0){push (@{$data[$OV_id]},$overvoltage);}
        $last_time = $current_time;
        $current_time+=$step;

      } #END for
  }
  else {
    $ErrorCode = -11;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: createGraph: $ErrorString $locFileHelper \n");
    return ($ErrorCode,"");
  }
  $graph = GD::Graph::lines->new(800, 600);

  $graph->set( 
          x_label           => "time in s",
          y_label           => "voltage in V",
          title             => 'waveform',
          x_tick_number     => 'auto',
          r_margin          => 10,
          l_margin          => 10,
          b_margin          => 10,
          line_type_scale => 1,
          line_types => \@linestypes,
  );


  $graph->set_legend_font(GD::Font->Large);
  if ($undervoltage > 0){push(@legend_keys,"undervoltage");}
  if ($overvoltage > 0){push(@legend_keys,"overvoltage");}

  $graph->set_legend(@legend_keys);

  close(IN);


  if(open ( OUT,">$file".".txt.unv" ))
  {
    print OUT "TIME;VOLTAGE;\n";
    print OUT "s;volt;\n";
    $current_time=0;
    for ($i=0; $i<@Time; $i++){
      $current_time+=$Time[$i];
      print OUT "$current_time;$Volts[$i];\n";
    }
    close (OUT);
  }
  else {
    $ErrorCode = -1;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: createGraph: $ErrorString $file.txt.unv \n");
    return ($ErrorCode,"");
  }

  
  if(open ( PIC,">$file.png" ))
  {
    binmode PIC;
    print PIC $graph->plot(\@data)->png;
    close (PIC);
    w2log("saved graph as $file.png \n");  
    return(0,"$file.png");   
  }
  else {
    $ErrorCode = -1;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: createGraph: $ErrorString $file.png \n");
    return ($ErrorCode,"");
  }


}


############################################################################################################

=head2 ($status,$picfile) = createRampGraph($filename, $RampStruct, [$undervoltage, $overvoltage]);

create a graph from RampStruct with given filename. if > 0 under and overvoltage thresholds will be added to graph.
Time delta between 2 poist hast to be between 0.2 ms and 100 s.
Will save picture as *.png and UNIVIEW file as *.txt.unv

$RampStruct is an array refernece containing array references:

$RampStruct = [
                [$Vstart_1, $Vend_1, $Time_1, $start_1, $end_1],
                [$Vstart_2, $Vend_2, $Time_2, $start_2, $end_2],
                ;]

Time in milliseconds, Vstart/Vend in volts, start/end in samples. (start >= 000, end <= 999)

For a single ramp start/end can be omitted, then default will be 000/999 

Returns:    

            1. status:          Success: 0,                                 Error: Error Code < 0. 
            2. picfile:         Success:  File name of the created file,    Error: empty.

 e.g.
 ($status,$picfile) = createRampGraph("test1.txt",[[0,1.2,2]]);                                 # no thresholds, single ramp
 ($status,$picfile) = createRampGraph("test1.txt",[[0,1.2,2,0,499],[3,5.2,12,500,999]]);        # no thresholds 
 ($status,$picfile) = createRampGraph("test2.txt",[[0,1.2,2,0,499],[3,5.2,12,500,999]],5);      # only undervoltage
 ($status,$picfile) = createRampGraph("test3.txt",[[0,1.2,2,0,499],[3,5.2,12,500,999]],0,10);   # only overvoltage

=cut

sub createRampGraph{

  my $file=shift;
  my $RampAoA=shift;
  my $undervoltage = shift;
  my $overvoltage = shift;
  my ($line,,$UV_id,$OV_id);
  my @legend_keys = ("battery voltage");
  my $ErrorCode;
  my $locFileHelper = $file;
  my (@Volts,@Time,$ramp_ref,$Itime);
  #parameter check, only last parameter
  unless( defined($RampAoA) )
  {    
        $ErrorCode = -21;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode, "");
  }
  
  #if only one array and size < 5, start = 000, end = 999
  if (scalar(@$RampAoA) == 1){
    if (scalar(@{$$RampAoA[0]}) >= 3 and scalar(@{$$RampAoA[0]}) < 5){
      $$RampAoA[0][3] = 0;
      $$RampAoA[0][4] = 999;
    }
  }
  
  #convert Ref to Arrays
  @Volts=@Time=();
  $Itime=0;
  foreach $ramp_ref (@$RampAoA){
      my ($Vstart,$Vend,$Time,$start,$end) = @$ramp_ref;
      unless( defined($end) ){
        print "error in RampStruct !\n";
        $ErrorCode = -21;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode, "");
      }

      $Time = $Time/1000;
      my $timedelta=$Time/($end-$start+1);

      if ($timedelta < 0.0002){
        print "timedelta $timedelta < 0.0002 !\n";
        $ErrorCode = -21;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode, "");
      }
      if ($timedelta > 100){
        print "timedelta $timedelta > 100 !\n";
        $ErrorCode = -21;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode, "");
      }
    
      $Itime += $timedelta;
      push(@Volts,$Vstart);
      $Itime=sprintf("%.4f",$Itime);
      push(@Time,$Itime);

      foreach my $count (1..$end-$start){
          $Itime += $timedelta;
          my $Ivolt = $Vstart+($count)/($end-$start)*($Vend-$Vstart);
          $Ivolt=sprintf("%.3f",$Ivolt);
          $Itime=sprintf("%.4f",$Itime);
          push(@Volts,$Ivolt);
          push(@Time,$Itime);
      }

  }
  
  
  if(defined($undervoltage)&& defined($overvoltage))
  {
   w2log("createRampGraph(RampStruct, [$undervoltage, $overvoltage]) \n");
  }
  else {
    w2log("createRampGraph( RampStruct ) \n");
  }
  
    #create graph
    $file =~ s/\.\w+$//; # cut off file extension
    $file =~ s/\//\\/g; # replace all slashes with backslashes

  if(open ( OUT,">$file".".txt.unv" ))
  {
    print OUT "TIME;VOLTAGE;\n";
    print OUT "s;volt;\n";
    for (my $i=0; $i<@Time; $i++){
      print OUT "$Time[$i];$Volts[$i];\n";
    }
    close (OUT);
  }
  else {
    $ErrorCode = -1;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: createRampGraph: $ErrorString $file.txt.unv \n");
    return ($ErrorCode,"");
  }

    my ($i, $graph,  @data, $element, $current_time);
    my ($val, $dt, $last_time);
    $last_time = $current_time =0;
    @data=();
    my $duration=$Time[-1];

	my $nbr_of_data_elements=1000; # 1000 points
	my $step = $duration/($nbr_of_data_elements*100);  # set plot stepwidth to 1/100 of the average time distance between 2 points
	$step = 0.001 if ($step < 0.001); # minimum clipping of stepwidth
    
    #set undervoltage and overvoltage if not defined
    $undervoltage = 0 unless (defined $undervoltage);
    $overvoltage = 0 unless (defined $overvoltage);
    
    if ($undervoltage > 0){$UV_id=2;} else {$UV_id=1;} 
    if ($overvoltage > 0){$OV_id=$UV_id+1;} else {$OV_id=1;} 
    if(@Time!= 0)
  {
      # loop over all points
      for ($i=0; $i<@Time; $i++){
        $val = $Volts[$i];
        $dt = $Time[$i];
        while ($current_time < $dt){
            push (@{$data[0]},$current_time);
            push (@{$data[1]},$val);
            if ($undervoltage > 0){push (@{$data[$UV_id]},$undervoltage);}
            if ($overvoltage > 0){push (@{$data[$OV_id]},$overvoltage);}
            $current_time+=$step;
        }
        push (@{$data[0]},$current_time);
        push (@{$data[1]},$val);
        if ($undervoltage > 0){push (@{$data[$UV_id]},$undervoltage);}
        if ($overvoltage > 0){push (@{$data[$OV_id]},$overvoltage);}
        $last_time = $current_time;
        $current_time+=$step;

      } #END for
  }
    else {
        $ErrorCode = -11;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: createRampGraph: $ErrorString $locFileHelper \n");
        return ($ErrorCode,"");
    }
    $graph = GD::Graph::lines->new(800, 600);

      $graph->set( 
          x_label           => "time in s",
          y_label           => "voltage in V",
          title             => 'waveform',
          x_tick_number     => 'auto',
          r_margin          => 10,
          l_margin          => 10,
          b_margin          => 10,
      );


    $graph->set_legend_font(GD::Font->Large);
    if ($undervoltage > 0){push(@legend_keys,"undervoltage");}
    if ($overvoltage > 0){push(@legend_keys,"overvoltage");}

    $graph->set_legend(@legend_keys);


    if(open ( PIC,">$file.png" ))
    {
        binmode PIC;
        print PIC $graph->plot(\@data)->png;
        close (PIC);
        w2log("saved graph as $file.png \n");
        return(0,"$file.png"); 
    }
    else {
        $ErrorCode = -1;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString $file.png \n");
        return ($ErrorCode, "");
    }

}



############################################################################################################

=head2 $Response = getErrorString($ErrorCode);

Function returns a string back, which resolves an error code. Error codes are < 0.

Returns 

        Response:   Success: String with error definitions,       Error: empty.
        
Error Codes: 
             0 => "no Error is success",
            -1 => "open File, access error",
            -2 => "Function parameters error",
            -3 => "Internal function calling error, response is wrong",
            -4 => "TOE88x5: Connection fail, device is not present ",
            -5 => "TOE88x5: Connection Error, Device ID cannot be read",
            -6 => "TOE88x5: Connection Error, Device is allready connected",
            -7 => "TOE88x5: Disconnection error, device was not connected",
            -8 => "TOE88x5: Connection Error, Device is not connected",
            -9 => "TOE88x5: Curve is running",
            -10 => "Not able to create dir ", 
            -11 => "File is empty",
            -12 => "TOE88x5: ERROR String : not defined ****",
            -13 => "TOE88x5: ERROR String : not defined ****",
            -14 => "TOE88x5: ERROR String : not defined ****",
            -15 => "TOE88x5: Object cannot be created",          
            -16 => "TOE88x5: Connection fail, Parameter error, use following function call format: connect(\$connection); Example:  connect('GPIB: 8')",
            -17 => "TOE88x5: setCurveFile failed, Parameter error, use following function call format: (\$status,\$String) = setCurveFile(file, [\$pic_mode]); Example: setCurveFile(\"C:\\test.txt\", 2);, see Function documentation for more Info",
            -18 => "TOE88x5: setCurveRamp failed, Parameter error, use following function call format: (\$status,\$String) = setCurveRamp(Vstart,Vend,Time,[start,end]); Example: setCurveRamp(12.6,3.8,1000,1,5);, see Function documentation for more Info",
            -19 => "TOE88x5: createRandomOnOffFile, Parameter error, use following function call format: \$status = createRandomOnOffFile(filename,ONmax,ONmin,OFFmax,OFFmin,Vmax,Vmin,MAXduration); example: createRandomOnOffFile(\"test.sat\", 3000, 2000, 700, 500, 12.5, 10.8, 60);, see Function documentation for more Info",
            -20 => "TOE88x5: createGraph, Parameter error, use following function call format: (\$status,\$picfile) = createGraph(filename, [undervoltage, overvoltage]);, Example: createGraph(\"test.txt\");", 
            -21 => "TOE88x5: createRampGraph, Parameter error, use following function call format: (\$status,\$picfile) = createRampGraph(filename, RampStruct, [\$undervoltage, \$overvoltage]);, Example: createRampGraph(\"test1.txt\",[[0,1.2,2]]);",            
            -22 => "TOE88x5: setCurveRamp: Parameter Error, Time must between 200 ms and 100000000 ms (~27.7 h) for full range. Time Step is: Time / ((end-start +1 ) * 1000)",
            -23 => "TOE88x5: saveCurveFile: Parameter Error, use following function call format:  \$status = \$pps-> saveCurveFile(\$filename,\$start,\$end); Example: saveCurveFile(\"test.txt\",1,12);",
            -24 => "TOE88x5: checkError, communication error: no status received ",
            -25 => "TOE88x5: PPSvoltage, Parameter Error, use following function call format: \$status = \$pps->PPSvoltage(\$voltage[,\$maxcurrent]); Example: PPSvoltage(12.4), voltage range = 0 ... 32",        
            -26 => "TOE88x5: setCurveStart, Parameter Error, use following function call format: \$pps->setCurveStart(\$point); Example:  setCurveStart(001), point range = 0 ... 999 ",
            -27 => "TOE88x5: setCurveEnd, Parameter Error, use following function call format: \$pps->setCurveEnd(\$point); Example: setCurveEnd(19), \$point range = 0 ... 999",
            -28 => "TOE88x5: setRepetition, Parameter Error, use following function call format: \$status = \$pps->setRepetition(\$repeat); Example: setRepetition(1), repeat range = 0 ... 255",
            -29 => "TOE88x5: setVoltage, Parameter Error, use following function call format: \$status = \$pps->setVoltage(\$voltage); Example: setVoltage(12.5), voltage range = 0 ... 32",
            -30 => "TOE88x5: setCurrent, Parameter Error, use following function call format: \$status = \$pps->setCurrent(\$current); Example: setCurrent(3.5), current range = 0 ... 5",
            -31 => "TOE88x5: setMode, Parameter Error, use following function call format: \$status =  \$pps->setMode(\$mode); Example: setMode(3)",            
            -32 => "TOE88x5: writeString, Parameter Error, use following function call format: \$status =  \$pps->writeString(\$string); Example: writeString(\"*IDN?\")",
            -33 => "TOE88x5: readString, communication timeout while reading",
            -34 => "TOE88x5: readString, communication error while reading",
            -35 => "TOE88x5: storePage, Parameter Error, use following function call format: \$status = \$pps->storePage(\$page); Example: storePage(3)",            
            -36 => "TOE88x5: recallPage, Parameter Error, use following function call format: \$status = \$pps->recallPage(\$page); Example: recallPage(2)"

=cut

sub getErrorString
{
    my $ErrorCode = shift;    
    my $Response;
    
    #parameter check
    unless(defined($ErrorCode))
    {       
        return "";
    }
    if(($ErrorCode < -36) || ($ErrorCode > 0 ))
    {   
        w2log("**** ERROR: Error code out of range, (code not defined) \n"); 
        return ""; 
    }
    else 
    {   
       $Response = $Error_Hash{$ErrorCode};
       unless(defined($Response))
       {
        w2log("**** ERROR: Error code is valid, (code not defined) \n");
        return "";
       }
       else {
        return $Response;           
       }
    }    
}


=head1 CONSTRUCTOR

=cut

=head2 $pps = TOE88x5->new(\*LOG);

creates an instance of a PPS object and returns its handle

writes into give logfile, if no filehandle is given log_TOE88x5pm.txt is created.

Return: 

        Handle to created Object

=cut


my $PPS_handle;
my $logfile_handle;


sub new {
    my $class = shift;
    $logfile_handle=shift;
    
    #parameter check
    unless ($logfile_handle) {
        open ( PPSLOG,">log_TOE88x5pm.txt" ) or die "Couldn't open logfile : $@";
        $logfile_handle = \*PPSLOG;
    }
    my $self = {};
    bless ($self, $class);
    w2log("creating new TOE88x5 instance \n");
    $self->{connected} = 0; # set connected flag to false
    $self->{ID} = "";
    return $self;    
}


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


############################################################################################################

=head2 ($status,$DeviceID) = $pps->connect($connection,$GPIBdevice);

Connnect to PPS via given connection, reads device identification (*IDN). 
This method has to be called first before any other method can be used.   

A valid connection is e.g. 'GPIB:8'. Make sure power supply is configured accordingly !
$GPIBdevice is usually 0 for first device

Returns:    

            1. status:              Success: 0, Error:      Error Code < 0.             
            2. DeviceID:            Success: Device ID,     Error: empty.

=cut

sub connect {
    my $self = shift;
    my $mode;
    my $connection = shift;
    my $GPIBdevice = shift;
    my $DeviceID;
    my $Device_ref;
    my $ErrorCode;
        
    #parameter check    
    unless (defined($connection))
    {   
        $self->{connected} = 0;
        
        $ErrorCode = -16;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode,"");
    }    
            
    w2log("connecting with TOE88x5 via <$connection,$GPIBdevice> \n");
        
    if($self->{connected} == 0)
    {
        if($connection =~ /GPIB:\s*(\d+)/i)
        {    
            $self->{GPIB} = GPIB->new("GPIB::ni", $GPIBdevice, $1, 0, GPIB->T3s, 1, 0);  #USB and PCI
            $PPS_handle = $self->{GPIB};
                                   
            unless ($PPS_handle->devicePresent)
            {   
                $self->{connected} = 0;
                
                $ErrorCode = -4;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString; error on <$connection>  \n");
                return ($ErrorCode,"");
            }
            
            #fix handle error
            unless(defined($PPS_handle))
            {   
                $self->{connected} = 0;
                
                $ErrorCode = -15;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString \n");                
                return($ErrorCode, "");
            }
           
            $self->{connected} = 1;     
            
            $PPS_handle -> ibwrt("FP");
 		    wait_ms(200);
                        
            $PPS_handle -> ibwrt("*RST");
            #wait until reset is done!
            wait_ms(2000);
            
            $PPS_handle -> ibclr();
 		    wait_ms(200);
            $PPS_handle -> ibwrt("*IDN?");
 		    wait_ms(100);
            $DeviceID = readString($self);
            
            #fix "" as Device ID 
            unless(defined ($DeviceID))
            {                   
                $DeviceID = " unknow device ";
                w2log("Device ID is unknow \n");                
            }   
            
            if( $DeviceID )
            {
                chomp($DeviceID);
                w2log("Device is <$DeviceID>\n");
                #$PPS_handle -> ibwrt("FAE 0;*OPC?");               
                #readString($self);
                #$PPS_handle -> ibwrt("*IST?");
                #readString($self);
                #$PPS_handle -> ibwrt("*LRN?");
                #readString($self);
                #$PPS_handle -> ibwrt("*TST?");
                #readString($self);
                $PPS_handle -> ibwrt("*ESE 0");
                $PPS_handle -> ibwrt("*SRE 0");
                $PPS_handle -> ibwrt("*CLS");
                #$PPS_handle -> ibwrt("EX?");
                #readString($self);
                #$PPS_handle -> ibwrt("K?");
                #readString($self);
                #$PPS_handle -> ibwrt("S?");
                #readString($self);
                $self->{connected} = 1; # set connected flag to true
                $self->{ID} = "{$DeviceID}";                                
                w2log("connect completed \n");
                return(0,$DeviceID);
            }
            else {
                
                $self->{connected} = 0;
                
                $ErrorCode = -5;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString \n");                
                return($ErrorCode, "");
           }
        }
        else {    
            $self->{connected} = 0; # set connected flag to false
            
            $ErrorCode = -16;
            $ErrorString = getErrorString($ErrorCode);
            w2log("**** ERROR: $ErrorString \n");                
            return($ErrorCode, "");                
        }
  }
  else {   
    $ErrorCode = -6;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");                
    return($ErrorCode, "");            
  }
}




############################################################################################################

=head2 $status = $pps->disconnect();

Disconnect from PPS

Returns:  
    
            status:     Success: 0, Error: Error Code < 0.

=cut

sub disconnect{
    my $self = shift;
    my $ErrorCode;
    
    if($self->{connected} == 1) {
        $PPS_handle = $self->{GPIB};
        $PPS_handle -> ibonl(0);
        w2log("disconnecting TOE88x5 $self->{ID} \n");
        undef $self->{ID};
        $self->{connected} = 0; # set connected flag to false
        w2log("disconnect completed \n");
        return 0;   
   }
    else{       
        $ErrorCode = -8;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");                
        return $ErrorCode;  
   }
}


############################################################################################################

=head2 ($status,$duration) = $pps->setCurveFile($file);

load curve from file and transmit to PPS. this will stop a running curve!.

Returns     

            1. status:          Success: 0,                             Error: Error Code < 0.            
            2. duration:        Success:Time neccessary to run curve,   Error: -1.

=cut

sub setCurveFile{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $file=shift;
  my $ErrorCode;
  
  #parameter check
  unless(defined($file))
  {   
    $ErrorCode = -17;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return ($ErrorCode,-1);
  }   
  
  if($self->{connected} == 0)
  {         
      $ErrorCode = -8;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setCurveFile, $ErrorString \n");
      return ($ErrorCode,-1);
  }
  
  unless (-f $file)
  {
      $ErrorCode = -1;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setCurveFile, $ErrorString, $file \n");
      return ($ErrorCode,-1);
  }
  
  if (isCurveRunning($self) > 0){
    stopCurve($self);
  }
  
  
  my ($line,@Volts,@Time,$Amps,$repeat,$count,$Duration,$timebuffer_ms);
  $Amps=5;
  $repeat=1;
  $Duration=0;
  $timebuffer_ms=0;
  @Volts=@Time=();
  w2log("set_curve_file($file) on $self->{ID} \n");
  
  
  if(open(IN,"<$file"))
  {
      while($line = <IN>)
      {
        $line =~ s/,/./g; # replace all commas with dots (convert to float)
        if ($line =~ /^(Strombegrenzung|Current Limitations)\s*:\s*(\S+)/){$Amps=$2}
        elsif ($line =~ /^(Wiederholungen|Repetitions)\s*:\s*(\S+)/){$repeat=$2}
        elsif ($line =~ /^\s*([\d.]+)\s+([\d.]+)/){
          push(@Volts,$1);
          push(@Time,$2);
          $Duration+=$2;
        }
      }
  }
  else {
    $ErrorCode = -1;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurveFile, $ErrorString, $file \n");
    return ($ErrorCode,-1);
  }
  
  if(scalar(@Volts)<1){
    $ErrorCode = -11;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurveFile, $ErrorString, $file \n");
    return ($ErrorCode,-1);
  }

  if(scalar(@Volts)>1000){
    $ErrorCode = -2;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurveFile, $ErrorString, $file too many points\n");
    return ($ErrorCode,-1);
  }

  #chek values from file, add error message later
  $repeat=1 if($repeat<0 or $repeat>255);
  $Amps=$MAXdeviceAMP if($Amps<0 or $Amps>$MAXdeviceAMP);
  
  
  $Duration*=1000;
  $Duration+=$timebuffer_ms;
  $Duration*=$repeat;

  return (0,$Duration) if $main::opt_debug;

  
  for($count=0;$count<@Volts;$count++){ 
    w2log("->FDS $count,$Volts[$count],$Amps,$Time[$count] \n");
    writeString($self,"FDS $count,$Volts[$count],$Amps,$Time[$count];*OPC?");
    readString($self);
  }

  setCurveStart($self,'000');
  setCurveEnd($self,$count-1);
  setRepetition($self,$repeat);
  w2log("duration will be $Duration ms \n");

  #close file
  close(IN);
  
  w2log("setCurveFile completed \n");
  return(0,$Duration);  
}

############################################################################################################

=head2 ($status,$duration) = $pps->initArbitrary($samples, $iteration, $arbitrary_time_aref, $arbitrary_voltage_aref, $current);

initialize the necessary parameters for execution of arbitrary curve.

Returns     

            1. status:          Success: 0,                             Error: Error Code < 0.            
            2. duration:        Success:Time neccessary to run curve,   Error: -1.

=cut

sub initArbitrary{
	my $self = shift;
	$PPS_handle = $self->{GPIB};

	my $samples =shift;
	my $iteration =shift;
	my $arbitrary_time_aref =shift;
	my $arbitrary_voltage_aref =shift;
	my $current =shift;
	my $ErrorCode;

	if($self->{connected} == 0)
	{         
		$ErrorCode = -8;
		$ErrorString = getErrorString($ErrorCode);
		w2log("**** ERROR: initArbitrary, $ErrorString \n");
		return ($ErrorCode,-1);
	}
  
	if (isCurveRunning($self) > 0){
		stopCurve($self);
	}
  
	my $count =0;
	my $Duration=0;		# duration of curve
	w2log("initArbitrary($samples, $iteration, $arbitrary_time_aref, $arbitrary_voltage_aref, $current) on $self->{ID} \n");

	# hardware related validations
	$current=$MAXdeviceAMP if($current<0 or $current>$MAXdeviceAMP);	# limit the current
	# limit the time delay
	foreach my $time(@$arbitrary_time_aref)
	{
		$time = $MINdeviceDELAY if ($time < $MINdeviceDELAY);
		$time = $MAXdeviceDELAY if ($time > $MAXdeviceDELAY);
		$Duration+=$time;
	} 
 	$Duration*=$iteration	if ($iteration>0);

	return (0,$Duration) if $main::opt_debug;
  
	for($count=0;$count<$samples;$count++){ 
		w2log("->FDS $count,$$arbitrary_voltage_aref[$count],$current,$$arbitrary_time_aref[$count] \n");
		writeString($self,"FDS $count,$$arbitrary_voltage_aref[$count],$current,$$arbitrary_time_aref[$count];*OPC?");
		readString($self);
	}

	setCurveStart($self,'000');
	setCurveEnd($self,$count-1);
	setRepetition($self,$iteration);
	w2log("duration of curve will be $Duration seconds \n");

	w2log("initArbitrary completed \n");
	return(0,$Duration);  
}

############################################################################################################

=head2 ($status,$duration) = $pps->setCurveRamp($Vstart,$Vend,$Time,[$start,$end]);

create a linear ramp in curve memory from $Vstart volts to $Vend volts and overall duration $Time milliseconds. 

If no start/end is given, the full range will taken and curve start and curve end will be set automatically.

$Time must be between 200 ms and 100000000 ms (~27.7 h) for full range.

The Time stepwidth has to be between 0.2 ms and 100 seconds.

Returns

            1. status:          Success: 0,                                 Error: Error Code < 0 
            2. duration: :      Success:Time neccessary to run curve,       Error: -1.

=cut


sub setCurveRamp{
    my $self = shift;
    $PPS_handle = $self->{GPIB};
    my $Vstart = shift;
    my $Vend = shift;
    my $Time = shift;
    my $start = shift;
    my $end = shift;
    my $waitforlinearwrite=500;
    my $Duration=0;
    my $timebuffer_ms=0;
    my $timestep=0;
    my $ErrorCode;
    
# ToDo use $MAXdeviceAMP to set current

    #Parameter check
    unless (defined($Time) )
    {       
       $ErrorCode = -18;
       $ErrorString = getErrorString($ErrorCode);
       w2log("**** ERROR: $ErrorString \n");
       return ($ErrorCode, -1);
    }
    
    #Connection check    
    if($self->{connected} == 0)
    {                
        $ErrorCode = -8;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: setCurveRamp, $ErrorString \n");
        return ($ErrorCode, -1);
    }
    
    unless (defined($end)) {

        if ($Time >= 200){
          if ($Time <= 100000000){
            if($start > $end)
            {
                $ErrorCode = -22;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString, start > end \n");
                return ($ErrorCode, -1);
            }
            
            $timestep = sprintf"%3.4f",($Time/1000000.0);

            $Duration = $Time+$timebuffer_ms;

            return (0,$Duration) if $main::opt_debug;

            w2log("set_curve_ramp($Vstart,$Vend,$Time) \n");
            w2log("set start\n");
            # to avoid voltage jump after curve, the first voltage is set to the last values
            writeString($self,"FDS 000,$Vend,04.00,0.001;*OPC?");            
            readString($self);
            writeString($self,"FDS 001,$Vstart,04.00,$timestep;*OPC?");            
            readString($self);
            w2log("set end\n");
            writeString($self,"FDS 999,$Vend,04.00,$timestep;*OPC?");             
            readString($self);
            w2log("set linear voltage\n");
            writeString($self,'FCV 001,999;*OPC?');             #write linear voltage values  
            wait_ms($waitforlinearwrite);
            readString($self);
            w2log("set linear time\n");
            writeString($self,'FCT 001,999;*OPC?');             #write linear time values  
            wait_ms($waitforlinearwrite);
            readString($self);
            w2log("set linear current\n");
            writeString($self,'FCC 001,999;*OPC?');             #write linear current values  
            wait_ms($waitforlinearwrite);
            readString($self);
            w2log("set curve start\n");
            setCurveStart($self,'000');
            w2log("set curve end\n");
            setCurveEnd($self,'999');
            setRepetition($self,1);
            w2log("duration will be $Duration ms\n");
            return(0,$Duration);  
         }
         else {
            $ErrorCode = -22;
            $ErrorString = getErrorString($ErrorCode);
            w2log("**** ERROR: $ErrorString \n");
            return ($ErrorCode, -1);
          }
        }
        else {
            $ErrorCode = -22;
            $ErrorString = getErrorString($ErrorCode);
            w2log("**** ERROR: $ErrorString \n");
            return ($ErrorCode, -1);
        }
    }
    else {
            if($start > $end)
            {
                $ErrorCode = -22;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString, start > end \n");
                return ($ErrorCode, -1);
            }
            #start check not required, included in check before or next check
            if($end > 999)
            {
                $ErrorCode = -22;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString, end > 999\n");
                return ($ErrorCode, -1);
            }
            #avoid zero division and negative numbers
            if( (($end-$start+1 ) == 0) || (($end-$start+1 ) < 0) )
            {
                $ErrorCode = -22;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString \n");
                return ($ErrorCode, -1);
            }
            
            $timestep = sprintf"%3.4f",($Time/(($end-$start+1)*1000.0));
            
            if ($timestep > 100){
                $ErrorCode = -22;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString \n");
                return ($ErrorCode, -1);
            }
            if ($timestep < 0.0002){
                $ErrorCode = -22;
                $ErrorString = getErrorString($ErrorCode);
                w2log("**** ERROR: $ErrorString \n");
                return ($ErrorCode, -1);
            }

            $Duration = $Time+$timebuffer_ms;

            return (0,$Duration) if $main::opt_debug;
           
            w2log("set_curve_ramp($Vstart,$Vend,$Time,$start,$end)\n");
            writeString($self,"FDS $start,$Vstart,04.00,$timestep;*OPC?");            
            readString($self);
            writeString($self,"FDS $end,$Vend,04.00,$timestep;*OPC?");            
            readString($self);
            writeString($self,"FCV $start,$end;*OPC?");             #write linear voltage values  
            wait_ms($waitforlinearwrite);
            readString($self);
            writeString($self,"FCT $start,$end;*OPC?");             #write linear time values  
            wait_ms($waitforlinearwrite);
            readString($self);
            writeString($self,"FCC $start,$end;*OPC?");             #write linear current values  
            wait_ms($waitforlinearwrite);
            readString($self);
            w2log("setCurveRamp completed \n");
            return(0,$Duration);  

    }
}

############################################################################################################

=head2 $status = $pps->runCurve();

run curve from curve memory, setting all starting conditions.

calls setExecute, initCurve and startCurve.

voltage will stay on first curve value after curve is over

Returns 
            
            status:     Success: 0,         Error: Error Code < 0. 

=cut

sub runCurve{
  my $self = shift;
  my $ErrorCode;
  
  $PPS_handle = $self->{GPIB};
       
  if($self->{connected} == 0)
  {       
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurve: $ErrorString \n");
    return $ErrorCode;
  }
    
  w2log(">run curve on $self->{ID}\n");
  
  if(setExternalTrigger($self,0)<0){
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurve: $ErrorString, because function setExternalTrigger failed \n");
    return $ErrorCode;
  }
    
  if(setMode($self,3)<0)
  { 
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurve: $ErrorString, because function setMode failed \n");
    return $ErrorCode;
  }
  if(setExecute($self)<0)
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurve: $ErrorString, because function setExecute failed \n");
    return $ErrorCode;
  }
  if(initCurve($self)<0)
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurve: $ErrorString, because function initCurve failed \n");
    return $ErrorCode;
  }
  if(startCurve($self)<0)
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurve: $ErrorString, because function startCurve failed \n");
    return $ErrorCode;
  }
    
  wait_ms(10);
  w2log("runCurve completed \n");  
  return 0;
}


############################################################################################################

=head2 $status = $pps->runCurveOnTrigger();

run curve from curve memory, setting all starting conditions, waiting for external trigger (on pin 12)

calls setExecute, initCurve and startCurve.

voltage will stay on first curve value after curve is over

Returns 
            
            status:     Success: 0,         Error: Error Code < 0. 

=cut

sub runCurveOnTrigger{
  my $self = shift;
  my $ErrorCode;
  
  $PPS_handle = $self->{GPIB};
       
  if($self->{connected} == 0)
  {       
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurveOnTrigger: $ErrorString \n");
    return $ErrorCode;
  }
    
  w2log(">run curve on $self->{ID}\n");
  
  if(setExternalTrigger($self,1)<0){
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurveOnTrigger: $ErrorString, because function setExternalTrigger failed \n");
    return $ErrorCode;
  }
    
  if(setMode($self,3)<0)
  { 
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurveOnTrigger: $ErrorString, because function setMode failed \n");
    return $ErrorCode;
  }
  if(setExecute($self)<0)
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurveOnTrigger: $ErrorString, because function setExecute failed \n");
    return $ErrorCode;
  }
  if(initCurve($self)<0)
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurveOnTrigger: $ErrorString, because function initCurve failed \n");
    return $ErrorCode;
  }
  if(startCurve($self)<0)
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: runCurveOnTrigger: $ErrorString, because function startCurve failed \n");
    return $ErrorCode;
  }
    
  wait_ms(10);
  w2log("runCurveOnTrigger completed \n");  
  return 0;
}


############################################################################################################

=head2 $status = $pps->saveCurveFile($filename,$start,$end);

create file from curve memory between $start and $end, this will stop a running curve!

Returns 
    
            status:     Success : 0,        Error: Error code < 0

=cut

sub saveCurveFile{
  my $self = shift; 

  my $filename = shift;
  my $start = shift;
  my $end = shift;
  my $pos;
  my $ret;
  my $ErrorCode;

  #Parameter check, only last parameter
  unless (defined($end))
  {  
      $ErrorCode = -23;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: $ErrorString \n");
      return $ErrorCode;
  }
  
  if($self->{connected} == 0)
  {         
      $ErrorCode = -8;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: saveCurveFile, $ErrorString \n");
      return $ErrorCode;
  }
  my $save_dir = dirname($filename);
  
  unless (-d $save_dir ){
    w2log ("creating directory $save_dir\n");
    unless( mkdir( $save_dir ) ) 
    { 
        $ErrorCode = -10;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: saveCurveFile, $ErrorString, $save_dir, $! \n");
        return $ErrorCode;
    }
  }
  
  w2log("creating curve file $filename\n");
  
  if (isCurveRunning($self) > 0){
    stopCurve($self);
  }
    
  my ($points, $duration,$ONtime,$OFFtime,$volts);
  my @filecontent=("\n","U[V]   t[s]\n");
  
  $duration = 0;
  
  if($start > $end)
  {
    $ErrorCode = -23;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString, start > end \n");
    return $ErrorCode;
  }
  
  for ($pos=$start;$pos<=$end;$pos++)
  {
    writeString($self,"FDS? $pos");            
    $ret = readString($self);
    
    $ret =~ /^\d+,([^,]+),[^,]+,([^,]+)/;
    push(@filecontent,"$1 $2\n");
    $points++;
  }
 
  unshift(@filecontent,"Wiederholungen:  1\n");
  unshift(@filecontent,"Strombegrenzung: 4.00\n");
  unshift(@filecontent,"Punkte:          $points\n");
  unshift(@filecontent,"Dateiname:       $filename\n");


  #avoid error by open File
  if(open (FILE,">$filename"))
  {
    print FILE @filecontent;
    close (FILE);
    w2log("saveCurveFile completed \n");
    return 0;
  }
  else {  
    $ErrorCode = -1;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: saveCurveFile, $ErrorString, $filename \n");
    return $ErrorCode;
  }
}


############################################################################################################

=head2 ($status, $value) = $pps->checkError();

read error status (*ESR?,ERR?) and report error if there is one

Returns 
            
             1. status: success = 0,                                    Error: Error code < 0, 
             2. value:  Error recognized = 1, no Error occurred = 0,    Error: -1.

=cut

sub checkError{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my ($ESRresp, $ERRresp);
  my $ErrorCode = -1;
  
  if($self->{connected} == 0)
  {  
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: checkError, $ErrorString \n");
    return ($ErrorCode,-1);
  }
   
  $PPS_handle->ibwrt('*ESR?');  

  $ESRresp = readString($self);           # Read result    
  
  unless (defined($ESRresp) ){
     w2log("?retry status check\n");
     $PPS_handle->ibwrt('*ESR?');             
     $ESRresp = readString($self);           # Read result
     
     unless (defined($ESRresp) ){
        $ErrorCode = -24;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: checkError, $ErrorString \n");
        return ($ErrorCode,-1);
     }
  }
  chomp($ESRresp);
  #avoid error by empty string
  unless($ESRresp eq "")
  {
    if ($ESRresp > 0){
      $PPS_handle->ibwrt('ERR?');             
      $ERRresp = readString($self);           # Read result
      if(defined ($ERRresp))
      {
        chomp($ERRresp);
        if ($ERRresp !~ /^0,/)          #error occurred
        {
          w2log("**** ERROR: ESR is $ESRresp, ERR is $ERRresp\n");
          return (0,1);
        }
      }
    }
  }
  else {
    #### this error cannot be fixed!!, because error occurs occasionally
    w2log("**** WARNING: ESRresp was empty \n");
  }
  #no error occurred
  return (0,0);
}


############################################################################################################

=head2 $status = $pps->PPSon();

set output to ON, do all required steps to fulfil preconditions (this will stop a running curve!). 

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub PPSon{
    my $self = shift;
    my $ErrorCode;
    
    if($self->{connected} == 0)
    {           
        $ErrorCode = -8;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSon, $ErrorString \n");
        return $ErrorCode;
    }
    
    if (isCurveRunning($self) > 0){
      stopCurve($self);
    }
    
    w2log("set output to execute (EX 1) on $self->{ID}\n");
    if(setMode($self,0)<0)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSon: $ErrorString, because function setMode failed \n");
        return $ErrorCode;
    }
    if(setExecute($self)<0)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSon: $ErrorString, because function setExecute failed \n");
        return $ErrorCode;
    }
    w2log("PPSon completed \n");
    return 0;
}


############################################################################################################

=head2 $status = $pps->PPSoff();

set output to OFF, do all required steps to fulfil preconditions (this will stop a running curve!). 

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub PPSoff{
    my $self = shift;
    my $ErrorCode;
    
    if($self->{connected} == 0)
    {   
        $ErrorCode = -8;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSoff, $ErrorString \n");
        return $ErrorCode;
    }        
    
    w2log("set output to execute (EX 1) on $self->{ID}\n");
    if (isCurveRunning($self) > 0){
        stopCurve($self);
    }
    
    if(setMode($self,0) <0)
    {;
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSoff: $ErrorString, because function setMode failed \n");
        return $ErrorCode;
    }
    if(setStandby($self) <0)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSoff: $ErrorString, because function setStandby failed \n");
        return $ErrorCode;
    }
    w2log("PPSoff completed \n");
    return 0;    
}


############################################################################################################

=head2 $status = $pps->PPSvoltage($voltage[,$maxcurrent]);

set output voltage, do all required steps to fulfil preconditions (this will stop a running curve!).

if no $maxcurrent is given, 4 A will be set as default.

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub PPSvoltage{
    my $self = shift;
    my $voltage = shift;
    my $maxcurrent = shift;
    my $ErrorCode;
    
    unless (defined $voltage) 
    {        
        $ErrorCode = -25;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }    
    
    if($self->{connected} == 0)
    {
        $ErrorCode = -8;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSvoltage, $ErrorString \n");
        return $ErrorCode;
    }
    unless (defined $maxcurrent) {$maxcurrent = $MAXdeviceAMP;}    
    
    
    w2log("set output to execute (EX 1) on $self->{ID}\n");
    
    #parameter range check
    if( ($voltage < 0)||($voltage > $MAXdeviceVOLT) )
    {
        $ErrorCode = -25;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString, voltage out of range: $voltage > $MAXdeviceVOLT \n");
        return $ErrorCode; 
    }
    #parameter range check
    if( ($maxcurrent < 0)||($maxcurrent > $MAXdeviceAMP) )
    {
        $ErrorCode = -25;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString, maxcurrent out of range: $maxcurrent > $MAXdeviceAMP \n");
        return $ErrorCode; 
    }
    
    if (isCurveRunning($self)>0){
      stopCurve($self);
    }    
    
    if(setMode($self,0) <0)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSvoltage: $ErrorString, because function setMode failed \n");
        return $ErrorCode;
    }
    
    
    if( setVoltage($self,$voltage)<0)
    {        
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSvoltage: $ErrorString, because function setVoltage failed \n");
        return $ErrorCode;
    }
    if(setCurrent($self,$maxcurrent)<0)
    {        
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: PPSvoltage: $ErrorString, because function setCurrent failed \n");
        return $ErrorCode;
    }
    w2log("PPSvoltage completed\n");
    return 0;
}



######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut


############################################################################################################

=head2 $status = $pps->setCurveStart($point);

set start point for curve (FAS X). $point range = 0 ... 999 

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setCurveStart{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $start = shift;
  my $ErrorCode;
  my($status, $value);
  
  unless(defined($start))
  {      
      $ErrorCode = -26;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: $ErrorString \n");
      return $ErrorCode;
  }
  
  w2log("set curve start to $start on $self->{ID}\n");
  
  if($self->{connected} == 0)
    {  
      $ErrorCode = -8;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setCurveStart:  $ErrorString \n");
      return $ErrorCode;
  }
  #parameter range check
  if( ($start < 0)||($start > 999) )
  {
     $ErrorCode = -26;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: $ErrorString, inserted: $start  \n");
      return $ErrorCode; 
  }
  
  writeString($self,"FAS $start;*OPC?");
  unless (defined(readString($self)))
  {    
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurveStart: $ErrorString, because function readString failed \n");
    return $ErrorCode;
  }

  ($status, $value) = checkError($self);
  if($status <0)
  {    
      $ErrorCode = -3;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setCurveStart: $ErrorString \n");
      return $ErrorCode;
  }
  else { 
    if($value == 1)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: setCurveStart: $ErrorString, because function checkError has found an Error \n");
        return $ErrorCode;
    }
    else {
        w2log("setCurveStart completed\n");
        return 0;
    }
  } 
}



############################################################################################################

=head2 $status = $pps->setCurveEnd($point);

set end point for curve (FAE X). $point range = 0 ... 999

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setCurveEnd{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $end = shift;
  my $ErrorCode;
  my($status, $value);
  
  #parameter check
  unless(defined($end))
  {
    $ErrorCode = -27;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;
    
  }
  w2log("set curve end to $end on $self->{ID}\n");
  
  if($self->{connected} == 0)
  { 
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurveEnd: $ErrorString \n");
    return $ErrorCode;
  }
  
  #parameter range check
  if( ($end < 0)||($end > 999) )
  {
       $ErrorCode = -27;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString, inserted: $end  \n");
        return $ErrorCode; 
  }
  
  writeString($self,"FAE $end;*OPC?");              
  
  unless( defined( readString($self) ) )
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurveEnd: $ErrorString, because function readString failed \n");
    return $ErrorCode;
  }
  ($status, $value) = checkError($self);
  if($status <0)
  {    
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurveEnd: $ErrorString \n");
    return $ErrorCode;
  }
  else { 
    if($value == 1)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: setCurveEnd: $ErrorString, because function checkError has found an Error \n");
        return $ErrorCode;
    }
    else {
        w2log("setCurveEnd completed\n");
        return 0;
    }
  } 
}



############################################################################################################

=head2 $status = $pps->initCurve();

reset curve to start point (FCL)

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub initCurve{
  my $self = shift;
  my $ErrorCode;
  my ($status, $value);
  
  $PPS_handle = $self->{GPIB};
  
  if($self->{connected} == 0)
  {      
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: initCurve: $ErrorString \n");
    return $ErrorCode;
  }
  
  w2log("init curve (FCL) on $self->{ID}\n");
  writeString($self,'FCL;*OPC?');             
  
  unless( defined(readString($self) ) )
  {
      $ErrorCode = -3;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: initCurve: $ErrorString, because function readString failed \n");
      return $ErrorCode;
  }
  ($status, $value) = checkError($self);
  if($status <0)
  {    
             $ErrorCode = -3;
             $ErrorString = getErrorString($ErrorCode);
             w2log("**** ERROR: initCurve: $ErrorString \n");
             return $ErrorCode;
  }
  else { 
    if($value == 1)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: initCurve: $ErrorString, because function checkError has found an Error \n");
        return $ErrorCode;
    }
    else { 
        w2log("initCurve completed\n");
        return 0;
    }
  }
}



############################################################################################################

=head2 $status = $pps->startCurve();

start curve (FS) if start conditions are fulfilled

voltage will stay on first curve value after curve is over

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub startCurve{
  my $self = shift;
  my $ErrorCode;
  my ($status, $value);
  
  $PPS_handle = $self->{GPIB};
  
  if($self->{connected} == 0)
  {     
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: startCurve: $ErrorString \n");
    return $ErrorCode;
  }
  
  w2log("start curve (FS) on $self->{ID}\n");
  writeString($self,'FS;*OPC?');
  
  unless( defined(readString($self) ) )
  {    
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: startCurve: $ErrorString, because function readString failed \n");
    return $ErrorCode;
  }
  
  ($status, $value) = checkError($self);
  if($status <0)
  {    
           $ErrorCode = -3;
           $ErrorString = getErrorString($ErrorCode);
           w2log("**** ERROR: startCurve: $ErrorString \n");
           return $ErrorCode;
  }
  else { 
    if($value == 1)
    {
           $ErrorCode = -3;
           $ErrorString = getErrorString($ErrorCode);
           w2log("**** ERROR: startCurve: $ErrorString, because function checkError has found an Error \n");
           return $ErrorCode;
    }
    else {
           w2log("startCurve completed\n");
           return 0;
    }
  }
}



############################################################################################################

=head2 $status = $pps->stopCurve();

stop curve (FP)

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub stopCurve{
  my $self = shift;
  my $ErrorCode;
  my ($status, $value);
  
  $PPS_handle = $self->{GPIB};
  
  if($self->{connected} == 0)
  {     
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: stopCurve: $ErrorString \n");
    return $ErrorCode;
  }
  
  w2log("stop curve (FP) on $self->{ID}\n");
  writeString($self,'FP;*OPC?');           
  
  unless( defined(readString($self) ) )
  {    
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: stopCurve: $ErrorString, because function readString failed \n");
    return $ErrorCode;
  }
  
  ($status, $value) = checkError($self);
  if($status <0)
  {    
         $ErrorCode = -3;
         $ErrorString = getErrorString($ErrorCode);
         w2log("**** ERROR: stopCurve: $ErrorString \n");
         return $ErrorCode;
  }
  else { 
    if($value == 1)
    {
         $ErrorCode = -3;
         $ErrorString = getErrorString($ErrorCode);
         w2log("**** ERROR: stopCurve: $ErrorString, because function checkError has found an Error \n");
         return $ErrorCode;
    }
    else {
        w2log("stopCurve completed\n");
        return 0;
    }
  }

}



############################################################################################################

=head2 $status = $pps->setExecute();

set output to execute (EX 1)

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setExecute{
  my $self = shift;
  my $ErrorCode;
  my ($status, $value);
  
  $PPS_handle = $self->{GPIB};
  
  if($self->{connected} == 0)
  { 
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setExecute: $ErrorString \n");
    return $ErrorCode;
  }
  w2log("set output to execute (EX 1) on $self->{ID}\n");
  writeString($self,'EX 1;*OPC?');             
  
  unless( defined(readString($self) ) )
  {        
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setExecute: $ErrorString, because function readString failed \n");
    return $ErrorCode;
  }
  ($status, $value) = checkError($self);
    if($status <0)
    {    
           $ErrorCode = -3;
           $ErrorString = getErrorString($ErrorCode);
           w2log("**** ERROR: setExecute: $ErrorString \n");
           return $ErrorCode;
    }
    else { 
      if($value == 1)
      {
               $ErrorCode = -3;
               $ErrorString = getErrorString($ErrorCode);
               w2log("**** ERROR: setExecute: $ErrorString, because function checkError has found an Error \n");
               return $ErrorCode;
      }
      else {
        w2log("setExecute completed\n");
        return 0;
      }
    }

}



############################################################################################################

=head2 $status = $pps->setStandby();

set output to standby (EX 0)

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setStandby{
  my $self = shift;
  my $ErrorCode;
  my ($status, $value);
  
  $PPS_handle = $self->{GPIB};
  
  if($self->{connected} == 0)
  {     
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setStandby: $ErrorString \n");
    return $ErrorCode;
  }
  
  w2log("set output to standby (EX 0) on $self->{ID}\n");
  writeString($self,'EX 0;*OPC?');             
  
  unless( defined(readString($self) ) )
  {
      $ErrorCode = -3;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setStandby: $ErrorString, because function readString failed \n");
      return $ErrorCode;
  }
  
  ($status, $value) = checkError($self);
  if($status <0)
  {    
         $ErrorCode = -3;
         $ErrorString = getErrorString($ErrorCode);
         w2log("**** ERROR: setStandby: $ErrorString \n");
         return $ErrorCode;
  }
  else { 
    if($value == 1)
    {
             $ErrorCode = -3;
             $ErrorString = getErrorString($ErrorCode);
             w2log("**** ERROR: setStandby: $ErrorString, because function checkError has found an Error \n");
             return $ErrorCode;
    }
    else {
        w2log("setStandby completed\n");
        return 0;
    }
  }
}



############################################################################################################

=head2 $status = $pps->setRepetition($repeat);

set repetition for curve (FB x). $repeat range = 0 ... 255.

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setRepetition{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $repeat=shift;
  my $ErrorCode;
  my ($status, $value);
  
  unless(defined($repeat))
  {     
    $ErrorCode = -28;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;
  }
  
  if($self->{connected} == 0)
  {         
      $ErrorCode = -8;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setRepetition: $ErrorString \n");
      return $ErrorCode;
  }
  
  w2log("set repetition to $repeat (FB $repeat) on $self->{ID}\n");
  
  #parameter range check
  if( ($repeat < 0)||($repeat > 255) )
  {
    $ErrorCode = -28;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString, inserted: $repeat  \n");
    return $ErrorCode; 
  }
  
  writeString($self,"FB $repeat;*OPC?");              
  unless( defined(readString($self) ) )
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setRepetition: $ErrorString, because function readString failed \n");
    return $ErrorCode;
  }
  
  ($status, $value) = checkError($self);
   if($status <0)
   {    
       $ErrorCode = -3;
       $ErrorString = getErrorString($ErrorCode);
       w2log("**** ERROR: setRepetition: $ErrorString \n");
       return $ErrorCode;
   }
   else { 
    if($value == 1)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: setRepetition: $ErrorString, because function checkError has found an Error \n");
        return $ErrorCode;
    }
    else {
        w2log("setRepetition completed\n");
        return 0;
    }
   }
}



############################################################################################################

=head2 $status = $pps->setVoltage($voltage);

set output voltage (V x). $voltage range = 0 ... 32

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setVoltage{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $Volts=shift;
  my $ErrorCode;
  my ($status, $value);
  
  unless(defined($Volts))
  {
    $ErrorCode = -29;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;
  }
    
  if($self->{connected} == 0)
  { 
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setVoltage: $ErrorString \n");
    return $ErrorCode;
  }
  w2log("setVoltage to $Volts");
  
  #parameter range check
  if( ($Volts < 0)||($Volts > $MAXdeviceVOLT) )
  {
    $ErrorCode = -29;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString, voltage out of range: $Volts > $MAXdeviceVOLT \n");
    return $ErrorCode; 
  }
    
  writeString($self,"V $Volts;*OPC?"); 
  unless( defined(readString($self) ) )
  {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: setVoltage: $ErrorString \n");
        return $ErrorCode;
  }
  
   ($status, $value) = checkError($self);
   if($status <0)
   {    
     $ErrorCode = -3;
     $ErrorString = getErrorString($ErrorCode);
     w2log("**** ERROR: setVoltage: $ErrorString \n");
     return $ErrorCode;
   }
   else { 
     if($value == 1)
     {
         $ErrorCode = -3;
         $ErrorString = getErrorString($ErrorCode);
         w2log("**** ERROR: setCurrent: $ErrorString, because function checkError has found an Error \n");
         return $ErrorCode;
     }
     else {
        w2log("setVoltage completed\n");
        return 0;
     }
  }
}


############################################################################################################

=head2 $status = $pps->setCurrent($current);

set maximum output current (C x). $current range = 0 ... 4

Returns 
            
            status:     Success : 0,        Error: Error code < 0.

=cut

sub setCurrent{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $Current=shift;
  my $ErrorCode;
  my ($status, $value);
  
  unless(defined($Current))
  {      
      $ErrorCode = -30;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: $ErrorString \n");
      return $ErrorCode;
  }
  
  if($self->{connected} == 0)
  {   
      $ErrorCode = -8;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setCurrent: $ErrorString \n");
      return $ErrorCode;
  }
  
  w2log("setCurrent: $Current");
  
  #parameter range check
  if( ($Current < 0)||($Current > $MAXdeviceAMP) )
  {
    $ErrorCode = -30;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString, current out of range: $Current > $MAXdeviceAMP \n");
    return $ErrorCode; 
  }  
  
  writeString($self,"C $Current;*OPC?"); 
 
  unless( defined(readString($self) ) )
  {
      $ErrorCode = -3;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setCurrent: $ErrorString \n");
      return $ErrorCode;
  }
  
  ($status, $value) = checkError($self);
  if($status <0)
  {    
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setCurrent: $ErrorString \n");
    return $ErrorCode;
  }
  else { 
    if($value == 1)
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: setCurrent: $ErrorString, because function checkError has found an Error \n");
        return $ErrorCode;
    }
    else {
        w2log("setCurrent completed \n");
        return 0;
    }
  }
}

############################################################################################################

=head2 $status = $pps->setExternalTrigger(0|1);

set external trigger mode off or on.

0 = off, 1 = on

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setExternalTrigger{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $mode=shift;
  my $ErrorCode;
  my ($status, $value);

  unless (defined($mode))
  {    
    $ErrorCode = -31;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;
  }
  if($self->{connected} == 0)
  {     
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setExternalTrigger: $ErrorString \n");
    return $ErrorCode;
  }
  
  w2log("set setExternalTrigger to $mode (ETR $mode) on $self->{ID} \n");
  
  writeString($self,"ETR $mode;*OPC?");             
  
  unless( defined(readString($self) ) )
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setExternalTrigger: $ErrorString \n");
    return $ErrorCode;
  }
  
  ($status, $value) = checkError($self);
  if($status <0)
  {    
      $ErrorCode = -3;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setExternalTrigger: $ErrorString \n");
      return $ErrorCode;
  }
  else { 
      if($value == 0)
      {
          w2log("setExternalTrigger completed \n");
          return 0;
      }
      else {
          $ErrorCode = -3;
          $ErrorString = getErrorString($ErrorCode);
          w2log("**** ERROR: setExternalTrigger: $ErrorString, $value  \n");
          return $ErrorCode;
      }
  }
  
}

############################################################################################################

=head2 $status = $pps->setMode($mode);

set output mode (F x)

0 = power supply mode, 1 = external voltage control, 2 = external current control, 3 = arbitrary mode

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setMode{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $mode=shift;
  my $ErrorCode;
  my ($status, $value);

  unless (defined($mode))
  {    
    $ErrorCode = -31;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;
  }
  if($self->{connected} == 0)
  {     
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setMode: $ErrorString \n");
    return $ErrorCode;
  }
  
  w2log("set mode to $mode (F $mode) on $self->{ID} \n");
  
  writeString($self,"F $mode;*OPC?");             
  
  unless( defined(readString($self) ) )
  {
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: setMode: $ErrorString \n");
    return $ErrorCode;
  }
  
  ($status, $value) = checkError($self);
  if($status <0)
  {    
      $ErrorCode = -3;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: setMode: $ErrorString \n");
      return $ErrorCode;
  }
  else { 
      if($value == 0)
      {
          w2log("setMode completed \n");
          return 0;
      }
      else {
          $ErrorCode = -3;
          $ErrorString = getErrorString($ErrorCode);
          w2log("**** ERROR: setMode: $ErrorString, $value  \n");
          return $ErrorCode;
      }
  }
  
}


############################################################################################################

=head2 $status = $pps->writeString($string);

write string directly to PPS

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub writeString{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $string = shift;
  my $ErrorCode;
  
  unless (defined($string))
  {
    $ErrorCode = -32;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;
  }
  
  if($self->{connected} == 0)
  {     
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: writeString: $ErrorString \n");
    return $ErrorCode;
  }

  eval {  $PPS_handle -> ibwrt($string);  };
  
  if($@)
  {    
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: writeString: $ErrorString, because write <$string> to $self->{ID} failed \n");
    return $ErrorCode;
  }
  else {
    w2log("writing <$string> to $self->{ID}\n");
    return 0;
  }
}



############################################################################################################

=head2 ($status,$string) = $pps->readString();

read string directly from PPS

Returns: 
        
        string:         Success:  readed string,         Error: undef.

=cut

sub readString{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
   my ($string,$STB,$i);
   my $ErrorCode;
   
   if($self->{connected} == 0)
   {        
        $ErrorCode = -8;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: storePage: $ErrorString \n");
        return ($ErrorCode,'');
   }
    
   #poll for MAV bit max 5 sec
    for ($i=0; $i<500; $i++){
        $STB = 256+($PPS_handle -> ibrsp());
        last if (($STB & 16) == 16);
        # sleep 10 msec
        wait_ms(10);        
    }
    
    
    if ($i>499)
    {
        $ErrorCode = -33;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: readString: $ErrorString from $self->{ID} \n");
        return ($ErrorCode,'');
    }
   
    wait_ms(10);        
    $string = $PPS_handle -> ibrd(1024);
    unless (defined($string)){
        w2log("?retry reading from $self->{ID}\n");
        $string = $PPS_handle -> ibrd(1024);
        unless (defined($string))
        {
            $ErrorCode = -34;
            $ErrorString = getErrorString($ErrorCode);
            w2log("**** ERROR: readString: $ErrorString from $self->{ID} \n");
            return ($ErrorCode,'');
        }
    }
    chomp($string);
    w2log("reading <$string> from $self->{ID}\n");
    return (0,$string);
}



############################################################################################################

=head2 $status = $pps->storePage($page);

store current curve on memory card page (CST x).

1 page = 16 K, that means a 256 K memory card has 16 pages (0 to15). 

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub storePage {
  my $self = shift;
  my $page = shift;
  my $ErrorCode;
  my ($status, $value);
  
  #parameter check
  unless (defined($page))
  {
    $ErrorCode = -35;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;
  }
  if($self->{connected} == 0)
  {       
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: storePage: $ErrorString \n");
    return $ErrorCode;
  }
        
  w2log("copy function to page $page (CST $page) on $self->{ID}\n");
  
  writeString($self,"CST $page;*OPC?");   
    
    unless( defined(readString($self) ) )
    {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: setStandby: $ErrorString, because function readString failed \n");
        return $ErrorCode;
    }
  
    ($status, $value) = checkError($self);
  
    if($status < 0)
    {      
      $ErrorCode = -3;
      $ErrorString = getErrorString($ErrorCode);
      w2log("**** ERROR: storePage: $ErrorString \n");
      return $ErrorCode;
    }
    else { 
      if($value == 0)
      {
        w2log("store page $page completed \n");
        return 0;
      }
      else {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: storePage: $ErrorString  \n");
        return $ErrorCode;
      }
    }
}


############################################################################################################

=head2 $status = $pps->recallPage($page);

load curve from memory card page (CRC x). page range 0 ... 15


wait some time (about 300 ms) between stop curve and recall next page

Returns 

        status:     Success : 0,        Error: Error code < 0.

=cut

sub recallPage{
  my $self = shift;
  my $page = shift;
  my $ErrorCode;
  my ($status, $value);
  #parameter check
  unless (defined($page))
  {    
    $ErrorCode = -36;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: $ErrorString \n");
    return $ErrorCode;   
  }
  #connection check
  if($self->{connected} == 0)
  { 
    $ErrorCode = -8;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: recallPage: $ErrorString \n");
    return $ErrorCode;
  }
  
  w2log("recall function from page $page (CRC $page) on $self->{ID}\n");

 
  #writeString($self,"CRC $page");  
  writeString($self,"CRC $page;*OPC?");
  
  unless( defined(readString($self) ) )
  {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: recallPage: $ErrorString, because function readString failed \n");
        return $ErrorCode;
  }

  ($status, $value) = checkError($self);
  if($status <0)
  {    
    $ErrorCode = -3;
    $ErrorString = getErrorString($ErrorCode);
    w2log("**** ERROR: recallPage: $ErrorString \n");
    return $ErrorCode;
  }
  else { 
    if($value == 0)
    {
        w2log("recall Page $page completed \n");
        return 0;
    }
    else {
        $ErrorCode = -3;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: recallPage: $ErrorString \n");
        return $ErrorCode;
    }
  }
}



############################################################################################################

=head2 $value = $pps->isConnected();

check if PPS is connected. 

Returns 

        value: 1 if true, 0 if false

=cut

sub isConnected{
    my $self = shift;
    return($self->{connected});
}



############################################################################################################

=head2 $value = $pps->isCurveRunning();

check if curve is running 

Returns 

        value: 0 for curve not running, 1 curve running; Error: Error Code < 0.

=cut

sub isCurveRunning{
    my $self = shift;
    my $ErrorCode;
    $PPS_handle = $self->{GPIB};

   if($self->{connected} == 0)
   {    
        $ErrorCode = -8;
        $ErrorString = getErrorString($ErrorCode);
        w2log("**** ERROR: isCurveRunning: $ErrorString \n");
        return $ErrorCode;
   }
   
    # check for running curve
    my $STB = 256+($PPS_handle -> ibrsp());
    
    if (($STB & 128) != 128){
        w2log("Curve is running \n");  
        return 1;
    }
    else {
        w2log("Curve is not running \n");
        return 0;
    }
}


############################################################################################################

=head2 $value = w2log($Message)

Logfile handling. this funtion will not be exported (use only local) 

Returns:

           status:  0 for success,          -2 for generic Parameter error 

=cut

sub w2log{
     my $text = shift;
     #Check parameters
     unless(defined($text)) {
        return -2;
     }
     else {
        print $logfile_handle $text if (defined $logfile_handle);
        print $text;
        return 0;     
     }
}

############################################################################################################
#
# wait function
#
# This function will not be exported (use only local) 
#
# Returns 
#           0 for success,          -2 for generic  Parameter error
#
############################################################################################################
sub wait_ms{
    my $time = shift; 
    
    #Check parameters
    unless (defined($time))  {
        return -2;
    }
    
    if( $time > 0) 
    {
        $time = $time/1000;
    }
    select(undef, undef, undef, $time);   #sleep for X ms
    return 0;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Toellner manual.

=cut
