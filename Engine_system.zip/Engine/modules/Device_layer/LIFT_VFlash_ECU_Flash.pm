# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_VFlash_ECU_Flash;

use strict;
use warnings;
use LIFT_general;
use LIFT_NET_access;
use Cwd;
use File::Copy;
use File::Basename;
use File::Spec;
use File::Slurp;
use Readonly;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  VFlash_ECU_AutoFlash
);

Readonly::Hash my %ERRORDESC => {
    1010 => 'Project could not be initialized (e.g. vFlash is not installed on the machine)',
    1011 => 'deprecated / not in use',
    1012 => 'Project handle is not valid',
    1013 => 'License check failed. (e.g. vFlash license is not valid)',
    1020 => 'Stop failed',
    1021 => ' deprecated / not in use',
    1030 => 'Project is not loaded',
    1031 => 'Path to the project file is invalid (e.g. the project file does not exist )',
    1032 => 'The project could not be loaded (e.g. referenced file missing, invalid project content, invalid project path)',
    1033 => 'Not in use',
    1034 => 'Flashware (e.g. Intel-Hex, Motorola-S files, ODX files) cannot be processed',
    1035 => 'Hardware channel already in use (e.g. incorrect hardware configuration setup)',
    1036 => 'Activate Network failed (e.g. incorrect hardware configuration setup)',
    1040 => 'CAN Driver could not be found (e.g. check whether vector driver is installed)',
    1050 => 'Command order is incorrect (e.g. initialization is required before loading a project)',
    1051 => 'The project file or files referenced in a project could not be loaded (e.g. referenced file missing, invalid project content, invalid project path)',
    1052 => 'The project could not be loaded (e.g. referenced file missing, invalid project content)',
    1053 => 'The project could not be unloaded',
    1054 => 'Limit of project number exceeded (e.g. more than 8 projects can not be loaded)',
    1055 => 'Flash attribute could not be found (e.g. incorrect attribute name)',
    1056 => 'Flash attribute could not be converted (e.g. string can not be converted into an integer)',
    1100 => 'Unknown Error',
    2009 => 'vFlash License is not available',
    2010 => 'The launched action was aborted (e.g. flash process was aborted by the user)',
    2011 => 'Unknown error occurred',
    2015 => 'Processing Flashware failed (e.g. due invalid format of Intel-Hex, Motorola-S files, ODX files)',
    2016 => 'Initializing communication failed (e.g. due to incorrect channel assignment, incorrect hardware setup)',
    2017 => 'Reprogramming could not be aborted successfully',
    2018 => 'Invalid project data detected (e.g. invalid communication parameters, missing Flashware, missing SeedKey.dll)',
    2019 => 'Not in use',
    2020 => 'The version of vFlash has to be at least as current as the version of the vFlash Template',
    2021 => 'The project could not be loaded (e.g. referenced file missing, invalid project content)',
    2022 => 'The flashware changed (e.g. the referenced flashware changed during reprogramming)',
    2023 => 'The ODX-F ExpectedIdent data could not be read (e.g. since required ODX-D is missing)',
    2024 => 'Force Boot Mode could not be executed',
    2025 => 'Baudrate switch failed (e.g. since other application has Init Rights on hardware channel)',
    2026 => 'Wakeup pattern could not be send (e.g. transmitting wakeup pattern failed)',
    2040 => 'Executing reprogramming failed (e.g. transferring data failed)',
    2041 => 'SeedKey.dll could not be loaded (e.g. invalid or missing SeedKey.dll)',
    2042 => 'Security Access failed (e.g. Incorrect Signature or Incorrect Challenge or unlocking ECU failed)',
    2043 => 'Starting communication failed (e.g. incomplete hardware configuration setup)',
    2044 => 'Processing Diagnostic transaction failed (e.g. transmitting diagnostic message failed, response missing)',
    2045 => 'Software integrity check failed (e.g. invalid checksum)',
    2046 => 'ECU sends a negative response although a positive response was required',
    2047 => 'Erase memory failed (e.g. ECU responded negatively to Erase-Routine request)',
    2048 => 'Software authenticity check failed (e.g. invalid signature)',
    2049 => 'Software compatibility check failed (e.g. invalid application data selected for already programmed application)',
    2050 => 'Fingerprint check failed (e.g. invalid TesterSerialNumber configured)',
    2051 => 'Hardware compatibility check failed (e.g. invalid software selected for hardware platform)',
    2052 => 'Preconditions are not fulfilled (e.g. since the user tried to reprogram an engine ECU while the engine is running)',
    2053 => 'The value of a FlashAttribute is missing or invalid'
};

=head1 NAME

LIFT_VFlash_ECU_Flash $Revision:

=head1 SYNOPSIS

    use LIFT_VFlash_ECU_Flash

    $result = VFlash_ECU_AutoFlash([$params]);

B<NOTE: Currently, this module supports only secure flashing (i.e., Smart Card is mandatory to initiate Reprogramming Session through vFlash).>

=head1 DESCRIPTION

Device layer module to Flash Application and update the Bootloader in ECU

=head1 CONFIGURATION

=head2 Testbench Configuration (LIFT_Testbenches.pm)

    'Devices' => {
        ...
        'VFlash' =>
        {
		'vflash_exepath' => 'C:\Program Files (x86)\Vector vFlash 5\Bin\vFlash.exe',
        }
    
    'Functions' => {
        ....
        'NET_Access' => {
                'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
                'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL            
            }, 
     }


=head2 Project Configuration (LIFT_CFG.pm)

	$LIFT_VflashFilePath = "$LIFT_PRJCFG_path/Vflash/template.vflash";

=head1 FUNCTIONS

=head2 VFlash_ECU_AutoFlash

    $result = VFlash_ECU_AutoFlash([$params]);

- Flashes the ECU Application SW/Updates Bootloader via CAPL.

- CAPL functionality to flash using VFlash will be called from TurboLIFT with the help of system variables.

- CAPL function to flash ECU expects .vflashpack file as input. Given .vflash file will be converted to .vflashpack using vflash command line option.

- Generated .vflashpack file will be passed to Capl using system variable B<vFlash::flashpackpath>.

- Flashing will be started using system variable B<vFlash::StartFlashing>.

- Status of Flashing will be tracked reading the system variable B<vFlash::StopFlashing>

- Progress of Flashing will be tracked reading the system variable B<vFlash::Progress>

- Error during reprogramming will be tracked reading the system variable B<vFlash::ErrorOccured>

- B<During secure flashing, a pop up will be displayed to the user to enter the Smart Card PIN. if user does not enter PIN within the maximum time frame of 30 minutes, reprogramming session will not be initiated and next test will be started>

B<Arguments:>

=over

=item $params (optional)

  $params = {
	 vflashfilepath => 'path of vflashfile',  #optional, path to the source *.vflash project file
	 hexfilepath    => 'path of hex file',    #optional, path of hexfile to be updated in vflash configuration, rewrites the hexfile specified in vflash configuration
	 crcfilepath    => 'path of crc file',	  #optional, path of crcfile to be updated in vflash configuration, rewrites the crcfile specified in vflash configuration
	 seedkeydllpath => 'path of seed key dll' #optional, path of seedkey dll file to be updated in vflash configuration
  }

=back

B<Return Values:>

=over

=item $result

1          - offline, success

undef      - When preconditions for flashing are not configured (e.g.$vflashfilepath, $hexfilepath, $crcfilepath or $seedkeydllpath doesn't exist or are invalid)

$errorCode - When an error occurs during reprogramming session

=back

B<Examples:>

	$result = VFlash_ECU_AutoFlash()    #Flashes the ECU with already configured .vflash file in testbench

  	$result = VFlash_ECU_AutoFlash( { vflashfilepath => 'C:\temp\vflash\Project1.vflash' } );    #Flashes the ECU with mentioned .vflash file

  	# Updates given .vflash file with the given hex,crc and seed key dll file and flashes the ECU

	$result = VFlash_ECU_AutoFlash(
		{
			vflashfilepath => 'C:\temp\vflash\Project1.vflash',
			hexfilepath    => 'C:\temp\vflash\application_S.hex',
			crcfilepath    => 'C:\temp\vflash\application_S.crc',
			seedkeydllpath => 'C:\temp\vflash\key_generator.dll'
		}
	);

	# Updates already configured .vflash file from testbench with the given hex and crc file and flashes the ECU
	
	$result = VFlash_ECU_AutoFlash( { hexfilepath => 'C:\temp\vflash\application_S.hex', crcfilepath => 'C:\temp\vflash\application_S.crc' } );

    # Updates already configured .vflash file from testbench with the given Invalid hex and crc files and flashes the ECU that results in a software integrity check error. 
    # The error code is returned in this case
    
    $errorCode = VFlash_ECU_AutoFlash(
		{
            hexfilepath = 'D:\vFlash_extension\Vflash\SW_test\Invalid_CRC\application_4_10_S.hex'
            crcfilepath = 'D:\vFlash_extension\Vflash\SW_test\Invalid_CRC\application_4_10_S.crc'
		}
	);

B<Notes:>

- Configure CANoe as per following Bosch connect page : System and Software Test @ Passive Safety Wiki > Training Center > Tutorials > CANoe > vFlash > How to use vFlash from TurboLIFT 

- Make sure vflash project doesn't have any dependancy of required files in case if you have copy pasted vflash project.

- Its recommended to generate Vflash project in the desired location locally to avoid issues due to dependancy files

=cut

sub VFlash_ECU_AutoFlash {

    my @args   = @_;
    my $params = shift @args;

    #STEP Read the input parameters $vflashfilepath(optional), $hexfilepath(optional), $crcfilepath(optional) and seedkeydllpath(optional)
    my $vflashfilepath = $params->{vflashfilepath};
    my $hexfilepath    = $params->{hexfilepath};
    my $crcfilepath    = $params->{crcfilepath};
    my $seedkeydllpath = $params->{seedkeydllpath};

    #IF $vflashfilepath defined?
    #IF-NO-START
    #	STEP Read vflashfilepath from testbench
    #CALL Generate_VflashPack
    #STEP Set vFlash::flashpackpath = generated vflashpack path
    #STEP Start flashing, Set vFlash::StartFlashing = 1
    #IF-NO-END
    #IF-YES-START
    #   IF In Offline Mode?
    #   IF-YES-START
    #       STEP Return 1 in offline mode
    #   IF-YES-END
    #   IF-NO-START
    #	    IF vflashfilepath exists?
    #	    IF-YES-START
    #		    IF Hex and CRC file defined and valid?
    #			    IF-YES-START
    #				    STEP Update the .Vflash file with new hex and crc file path
    #			    IF-YES-END
    #			    IF-NO-START
    #			        STEP Do not update .Vflash file
    #			    IF-NO-END
    # 		    IF Keygenerator dll defined and Valid?
    #			    IF-YES-START
    #				    STEP Update the .Vflash file with given keygenerator dll
    #                   CALL Generate_VflashPack
    #                   STEP Set vFlash::flashpackpath = generated vflashpack path
    #                   STEP Start flashing, Set vFlash::StartFlashing = 1
    #			    IF-YES-END
    #			    IF-NO-START
    #				    STEP Do not update .vflash file
    #			    IF-NO-END
    #	    IF-YES-END
    #	    IF-NO-START
    #	        STEP ERROR-Could not find the Vflash file
    #	    IF-NO-END
    #    IF-NO-END
    #IF-YES-END
    #STEP END

    # Validate inputs
    unless ($vflashfilepath) {
        $vflashfilepath = $LIFT_config::LIFT_VflashFilePath;
        S_w2log( 3, "VFlash_ECU_AutoFlash : Reading .VFlash file from config : '$vflashfilepath'" );
    }

    unless ( -e $vflashfilepath ) {
    	if ($main::opt_offline) {
    		S_set_warning( "VFlash_ECU_AutoFlash : Could not find the Vflash file '$vflashfilepath' \n");
        	return;
    	}
    	else {
    		S_set_error( "VFlash_ECU_AutoFlash : Could not find the Vflash file '$vflashfilepath' \n", 1 );
        	return;
    	} 
    }

    if ( $hexfilepath && $crcfilepath ) {

        #validate hex and crc file
        unless ( -e $hexfilepath and -e $crcfilepath ) {
        	if( $main::opt_offline ) {
        		S_set_warning( "VFlash_ECU_AutoFlash : Input Hex['$hexfilepath'] or CRC['$crcfilepath'] file does not exists!");
            	return;	
        	}
        	else {
        		S_set_error( "VFlash_ECU_AutoFlash : Input Hex['$hexfilepath'] or CRC['$crcfilepath'] file does not exists!", 1 );
            	return;
        	}        
        }

        unless ( $hexfilepath =~ /\.hex$/i and $crcfilepath =~ /\.crc$/i ) {
        	if( $main::opt_offline ) {
        		S_set_warning( "VFlash_ECU_AutoFlash : Invalid Hex or CRC file provided. Not going to update the .vflash file ");
            	return;
        	}
        	else {
        		S_set_error( "VFlash_ECU_AutoFlash : Invalid Hex or CRC file provided. Not going to update the .vflash file ", 1 );
            	return;
        	}
        }

        $hexfilepath = File::Spec->rel2abs($hexfilepath);
        $crcfilepath = File::Spec->rel2abs($crcfilepath);

        #Change the path of hex and crc files in vflashfile
        my $vflashxml_content = read_file $vflashfilepath, { binmode => ':utf8' };

        #Get the relative path of hex file w.r.t vflash file and update .vflash file
        my $relativehexpath = File::Spec->abs2rel( $hexfilepath, dirname($vflashfilepath) );

        my $regex_filepathhex = '<FilePath AbsolutePath=';
        my $regex_relpath     = ' RelativePath=';
        if ( $vflashxml_content =~ s/($regex_filepathhex)".*\.hex"($regex_relpath)".*\.hex"( \/>)/$1"$hexfilepath"$2"$relativehexpath"$3/ ) {
            S_w2log( 3, "VFlash_ECU_AutoFlash : Updated HEX filepath to '$hexfilepath' in vflash file" );
        }

        #Get the relative path of crc file w.r.t vflash file and update .vflash file
        my $regex_filepathcrc = '<ChecksumPath AbsolutePath=';
        my $relativecrcpath = File::Spec->abs2rel( $crcfilepath, dirname($vflashfilepath) );
        if ( $vflashxml_content =~ s/($regex_filepathcrc)".*\.crc"($regex_relpath)".*\.crc"( \/>)/$1"$crcfilepath"$2"$relativecrcpath"$3/ ) {
            S_w2log( 3, "VFlash_ECU_AutoFlash : Updated CRC filepath to '$crcfilepath' in vflash file" );
        }

        write_file $vflashfilepath, { binmode => ':utf8' }, $vflashxml_content;

    }

    if ($seedkeydllpath) {

        unless ( -e $seedkeydllpath && $seedkeydllpath =~ /\.dll$/i ) {
        	if( $main::opt_offline ) {
        		S_set_warning( "VFlash_ECU_AutoFlash : Given seedkey dll file ['$seedkeydllpath'] doesn't exist or is Invalid!");
            	return;
        	}
        	else {
        		S_set_error( "VFlash_ECU_AutoFlash : Given seedkey dll file ['$seedkeydllpath'] doesn't exist or is Invalid!", 1 );
            	return;
        	}            
        }
        else {
            $seedkeydllpath = File::Spec->rel2abs($seedkeydllpath);

            #Change the path keygenerator.dll in vflashfile with given path
            my $vflashxml_content = read_file $vflashfilepath, { binmode => ':utf8' };

            my $regex_filepathdll = '<SeedKeyDLL AbsolutePath=';
            my $regex_relpath     = ' RelativePath=';

            #Get the ralative path of seedkey dll file w.r.t vflash file and update .vflash file
            my $rel_seedkeydllpath = File::Spec->abs2rel( $seedkeydllpath, dirname($vflashfilepath) );
            if ( $vflashxml_content =~ s/($regex_filepathdll)".*\.dll"($regex_relpath)".*\.dll"( \/>)/$1"$seedkeydllpath"$2"$rel_seedkeydllpath"$3/ ) {
                S_w2log( 3, "VFlash_ECU_AutoFlash : Successfully updated seedkey dll file to '$seedkeydllpath' in vflash file" );
            }
            write_file $vflashfilepath, { binmode => ':utf8' }, $vflashxml_content;
        }
    }

    #generate vflashpack
    my $generatedVflashpack;
    if( $main::opt_offline ) {
    	$generatedVflashpack = Generate_VflashPack_NOERROR($vflashfilepath);
    }
    else {
    	$generatedVflashpack = Generate_VflashPack($vflashfilepath);
    }

    return Flash_VFlashpack_with_CAPL_NOERROR($generatedVflashpack) if($main::opt_offline);
    return Flash_VFlashpack_with_CAPL($generatedVflashpack) unless ($main::opt_offline);

}

=head1 Not exported functions

=head2 Flash_VFlashpack_with_CAPL
	
 $status = Flash_VFlashpack_with_CAPL($flashpackpath)
	
Flashes the ECU with given Vflashpack file using CAPL interface.
	
=cut

sub Flash_VFlashpack_with_CAPL {
    my @args          = @_;
    my $flashpackpath = shift @args;

    #STEP Read vflashfilepath
    #IF $flashpackpath is defined?
    #IF-NO-START
    #STEP Throw Error- No vflashfilepath provided!
    #IF-NO-END
    #IF-YES-START
    #       IF In Offline Mode?
    #       IF-YES-START
    #           STEP Return 1 - in Offline Mode
    #       IF-YES-END
    #       IF-NO-START
    #           STEP Start Flashing via CAPL
    #           STEP Set system variable vFlash::flashpackpath = 'path of vflashpack file'
    #           STEP set vflash stop flashing and error sys variable to 0 before starting test
    #           STEP Wait for 1 second before starting vflash
    #           IF Received PIN?
    #           IF-YES-START
    #               STEP set systemvariable 'vFlash::StartFlashing'= 1 to start flashing
    #               STEP wait for a maximum of 30min for user to enter Smart Card PIN, if not abort reprogramming session
    #               STEP Check for any errors by reading 'vFlash::ErrorOccured' if flashing aborted before starting. ex:negative response, communication error
    #               STEP Check for reprogramming status every 5sec, Display it to user
    #               STEP Verify whether flashing was completed by reading 'vFlash::StopFlashing'
    #           IF-YES-END
    #           IF-NO-START
    #               STEP Flashing did not start even after waiting. Maybe the user did not enter the PIN
    #           IF-NO-END
    #       IF-NO-END
    #IF-YES-END
    #STEP END

    unless ($flashpackpath) {
        S_set_error( "Flash_VFlashpack_with_CAPL:ERROR! No vflashpackpath provided!", 1 );
        return;
    }

    return 1 if ($main::opt_offline);

    # Start Flashing via CAPL

    my $sysvar_startflashing  = 'vFlash::StartFlashing';
    my $sysvar_vflashpackpath = 'vFlash::flashpackpath';
    my $sysvar_stopflashing   = 'vFlash::StopFlashing';
    my $sysvar_errorflashing  = 'vFlash::ErrorOccured';
    my $sysvar_flashprogress  = 'vFlash::Progress';

    return unless NET_simulation_start();

    # Set system variable vFlash::flashpackpath = 'path of vflashpack file'
    return unless NET_set_sysVar_value( $sysvar_vflashpackpath, $flashpackpath );

    #set vflash stop flashing and error sys variable to 0 before starting test
    return unless NET_set_sysVar_value( $sysvar_stopflashing,  0 );
    return unless NET_set_sysVar_value( $sysvar_errorflashing, 0 );

    #Wait for 1 second before starting vflash
    S_wait_ms( 1000, "Waiting for vFlash to start..." );

    # set systemvariable 'vFlash::StartFlashing'= 1 to start flashing
    return unless NET_set_sysVar_value( $sysvar_startflashing, 1 );

    #wait for a maximum of 30 minutes for user to enter the PIN, if not abort reprogramming session
    foreach my $counter ( 1 .. 900 ) {
        if ( $counter == 1 ) {
            S_w2log( TEXT | CONSOLE, "Waiting for Reprogramming to start...\n" );
        }
        S_wait_ms_NOHTML( 2000, "\n" );
        my $errorCode = NET_get_sysVar_value($sysvar_errorflashing);
        if ( $errorCode != 0 ) {
            Get_error_info($errorCode);
            NET_simulation_stop();
            return $errorCode;
        }
        if ( NET_get_sysVar_value($sysvar_stopflashing) == 1 ) {

            #Check if flashing aborted before starting. ex:negative response, communication error
            S_set_error("VFlash_ECU_AutoFlash : There was an error while reprogramming... Please check the CANoe log/write window for more details!\n");
            NET_simulation_stop();
            return;
        }
        elsif ( NET_get_sysVar_value($sysvar_flashprogress) != 0 ) {
            S_w2log( TEXT | CONSOLE, "VFlash_ECU_AutoFlash : Started Reprogramming - " . NET_get_sysVar_value($sysvar_flashprogress) . "%!" . "\n", 'green' );
            last;
        }
    }

    #Check for reprogramming status every 5sec, Display it to user
    if ( NET_get_sysVar_value($sysvar_flashprogress) > 0 ) {
        foreach my $counter ( 1 .. 30 ) {
            if ( $counter == 1 ) {
                S_w2log( TEXT | CONSOLE, "Checking for Reprogramming status\n" );
            }
            S_wait_ms_NOHTML(5000);

            # Verify whether flashing was completed by reading 'vFlash::StopFlashing'
            if ( NET_get_sysVar_value($sysvar_stopflashing) == 1 ) {
                my $errorCode = NET_get_sysVar_value($sysvar_errorflashing);
                if ( $errorCode == 0 ) {
                    S_w2log( 3, "vFlash_ECU_AutoFlash : Reprogramming done successfully!\n", 'green' );
                    NET_simulation_stop();
                    return 1;
                }
                else {
                    Get_error_info($errorCode);
                    NET_simulation_stop();
                    return $errorCode;
                }
            }
            S_w2log( TEXT | CONSOLE, "\n Reprogramming is still in progress! Completed - " . NET_get_sysVar_value($sysvar_flashprogress) . "%!" . "\n", 'green' );
        }
    }
    else {
        #Flashing did not start even after waiting. May be user did not enter PIN
        S_set_error( "VFlash_ECU_AutoFlash : There was an error while reprogramming.. May be user did not enter PIN.. Please check the CANoe log/write window for more details!\n", 5 );
        NET_simulation_stop();
        return;
    }

    return;
}

=head2 Generate_VflashPack

    $vflashpackfile_path = Generate_VflashPack( $vflashfilepath );

Generates VFlashpack file using the given VFlash file  

Command Line Option for automated generation of vFlashPack project file based on .vFlash project files:

vFlash.exe /ExportToPack <.vflash project> <.vflashpack project>

1. "vFlash-project" - path to the source *.vflash project file

2. "vFlashPack-project" - path to the target *.vflashpack project file

e.g. vFlash.exe /ExportToPack D:\project.vflash D:\project.vflashpack

B<Examples:>

    $vflashpackfile_path = Generate_VflashPack( 'C:\temp\vflash\Project1.vflash' );

=cut

sub Generate_VflashPack {
    my @args           = @_;
    my $vflashfilepath = shift @args;

    #STEP Read vflashfilepath
    #IF Vflash file exists?
    #IF-YES-START
    #STEP READ Vflash exe path from testbench
    #	IF Vflash exe exists?
    #	IF-YES-START
    #       IF In Offline Mode?
    #       IF-YES-START
    #           STEP Return vflash filepath
    #       IF-YES-END
    #       IF-NO-START
    #		    STEP Generate VFlashpack file
    #           STEP Return vflashpack filepath
    #       IF-NO-END
    #	IF-YES-END
    #	IF-NO-START
    #	IF-NO-END
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    #STEP END

    unless ( -e $vflashfilepath ) {
        S_set_error( "Generate_VflashPack : Could not find the Vflash file '$vflashfilepath' \n", 1 );
        return;
    }

    my $vflash_exepath = $LIFT_config::LIFT_Testbench->{'Devices'}{'VFlash'}{'vflash_exepath'};

    unless ($vflash_exepath) {
        S_set_error( "Generate_VflashPack : Please configure VFlash exe path in test bench - {'Devices'}{'VFlash'}{'vflash_exepath'}\n", 1 );
        return;
    }
    unless ( -e $vflash_exepath ) {
        S_set_error( "Generate_VflashPack : Could not find the Vflash exe in given path '$vflash_exepath' \n", 1 );
        return;
    }

    my $reportpath          = "$main::REPORT_PATH";
    my $vflashpackfile_path = $reportpath . '//' . $main::CURRENT_TC . '.vflashpack';

    $vflashfilepath = File::Spec->rel2abs($vflashfilepath);
    return $vflashfilepath if ($main::opt_offline);

    #Refer Vflash tool help section for more information on different command line options
    my $cmd = '"' . $vflash_exepath . '"' . " /ExportToPack " . '"' . $vflashfilepath . '"' . ' "' . $vflashpackfile_path . '"';
    S_w2log( 3, "Generate_VflashPack: Converting .vflash to .vflashpack.. calling command: '$cmd'" );

    my ( $result, @output ) = S_call_command_NOERROR("$cmd");
    unless ( $result and -e $vflashpackfile_path ) {
        S_set_error( "Generate_VflashPack: Converting .vflash file '$vflashfilepath' to .vflashpack was not successful!! Check if you have valid license or Check if .Vflash file is valid", 23 );
        return;
    }
    S_w2log( 3, "Generate_VflashPack: Successfully generated VFlashpack file '$vflashpackfile_path'" );
    return $vflashpackfile_path;
}

=head2 Get_error_info
	
 $error_info = Get_error_info($errorCode)
 
This function retrieves the $error_info of the given $errorCode and sets an error based on the error conditions
 
B<Error Conditions>
	
-If $errorCode is defined, the $errorCode and its respective error description are written to the report

-If $errorCode is not defined, the error code with a default error message are written to the report

=over

=item List of defined Error Codes

1010 - Project could not be initialized (e.g. vFlash is not installed on the machine)
    
1011 - deprecated / not in use
    
1012 - Project handle is not valid
    
1013 - License check failed. (e.g. vFlash license is not valid)
    
1020 - Stop failed
    
1021 - deprecated / not in use
    
1030 - Project is not loaded
    
1031 - Path to the project file is invalid (e.g. the project file does not exist )
    
1032 - The project could not be loaded (e.g. referenced file missing, invalid project content, invalid project path)
    
1033 - Not in use
    
1034 - Flashware (e.g. Intel-Hex, Motorola-S files, ODX files) cannot be processed
    
1035 - Hardware channel already in use (e.g. incorrect hardware configuration setup)
    
1036 - Activate Network failed (e.g. incorrect hardware configuration setup)
    
1040 - CAN Driver could not be found (e.g. check whether vector driver is installed)
    
1050 - Command order is incorrect (e.g. initialization is required before loading a project)
    
1051 - The project file or files referenced in a project could not be loaded (e.g. referenced file missing, invalid project content, invalid project path)
    
1052 - The project could not be loaded (e.g. referenced file missing, invalid project content)
    
1053 - The project could not be unloaded
    
1054 - Limit of project number exceeded (e.g. more than 8 projects can not be loaded)
    
1055 - Flash attribute could not be found (e.g. incorrect attribute name)
    
1056 - Flash attribute could not be converted (e.g. string can not be converted into an integer)
    
1100 - Unknown Error
    
2009 - vFlash License is not available
    
2010 - The launched action was aborted (e.g. flash process was aborted by the user)
    
2011 - Unknown error occurred
    
2015 - Processing Flashware failed (e.g. due invalid format of Intel-Hex, Motorola-S files, ODX files)
    
2016 - Initializing communication failed (e.g. due to incorrect channel assignment, incorrect hardware setup)
    
2017 - Reprogramming could not be aborted successfully
    
2018 - Invalid project data detected (e.g. invalid communication parameters, missing Flashware, missing SeedKey.dll)
    
2019 - Not in use
    
2020 - The version of vFlash has to be at least as current as the version of the vFlash Template
    
2021 - The project could not be loaded (e.g. referenced file missing, invalid project content)
    
2022 - The flashware changed (e.g. the referenced flashware changed during reprogramming)
    
2023 - The ODX-F ExpectedIdent data could not be read (e.g. since required ODX-D is missing)
    
2024 - Force Boot Mode could not be executed
    
2025 - Baudrate switch failed (e.g. since other application has Init Rights on hardware channel)
    
2026 - Wakeup pattern could not be send (e.g. transmitting wakeup pattern failed)
    
2040 - Executing reprogramming failed (e.g. transferring data failed)
    
2041 - SeedKey.dll could not be loaded (e.g. invalid or missing SeedKey.dll)
    
2042 - Security Access failed (e.g. Incorrect Signature or Incorrect Challenge or unlocking ECU failed)
    
2043 - Starting communication failed (e.g. incomplete hardware configuration setup)
    
2044 - Processing Diagnostic transaction failed (e.g. transmitting diagnostic message failed, response missing)
    
2045 - Software integrity check failed (e.g. invalid checksum)
    
2046 - ECU sends a negative response although a positive response was required
    
2047 - Erase memory failed (e.g. ECU responded negatively to Erase-Routine request)
    
2048 - Software authenticity check failed (e.g. invalid signature)
    
2049 - Software compatibility check failed (e.g. invalid application data selected for already programmed application)
    
2050 - Fingerprint check failed (e.g. invalid TesterSerialNumber configured)
    
2051 - Hardware compatibility check failed (e.g. invalid software selected for hardware platform)
    
2052 - Preconditions are not fulfilled (e.g. since the user tried to reprogram an engine ECU while the engine is running)
    
2053 - The value of a FlashAttribute is missing or invalid

=back
	
=cut

sub Get_error_info {

    my @args     = @_;
    my $errCode  = shift @args;
    my $errDesc  = \%ERRORDESC;
    my $errorMsg = $errDesc->{$errCode};
    if ( defined($errorMsg) ) {
        S_set_error( "(Error Code:$errCode) - $errorMsg", 1 );
    }
    else {
        S_set_error( "(Error Code:$errCode) - VFlash_ECU_AutoFlash : Reprogramming Failed, Please check the CANoe log/write window for more details!", 5 );
    }
    return;
}

1;
