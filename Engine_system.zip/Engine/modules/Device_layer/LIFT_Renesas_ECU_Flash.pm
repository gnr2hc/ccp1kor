# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_Renesas_ECU_Flash;
use strict;
use warnings;
use LIFT_general;
use Cwd;
use File::Spec;
use File::Slurp;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  Renesas_ECU_AutoFlash
);

our ( $VERSION, $HEADER );

my $default_rfpExec_2_05 = 'C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V2.05\RFP.exe';
my $default_rfpExec_3_06 = 'C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V3.06\RFPV3.exe';

my $temp_directory = 'c:\temp\LIFT';

my ( $rwsFileName, $ECU_Type, $Renesas_Sl_Num, $project_Workspace, $absLogFileName );

=head1 NAME

LIFT_Renesas_ECU_Flash $Revision: 1.2

=head1 SYNOPSIS

    use LIFT_Renesas_ECU_Flash

    $result = Renesas_ECU_AutoFlash([$hexFilepath_mix]);

=head1 DESCRIPTION

This is a module for device Renesas used to flash ECU SW.
        
=head1 FUNCTIONS

=head2 Renesas_ECU_AutoFlash

    $result = Renesas_ECU_AutoFlash([$hexFilepath_mix]);

Flashes the ECU SW using Renesas tool. Function invokes RFP.exe which should be pre-installed.

B<Arguments:>

=over

=item $hexFilepath_mix (optional)

B<FOR V2.05 :> The absolute path of hex file for the SW to be flashed. 
If not mentioned here, reads the SAD file path from the config file and uses the same path to search for .hex and _dlash.hex file.
Supports flashing for .hex and dflash.hex files only.

e.g : Renesas_ECU_AutoFlash('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3.hex');

B<FOR V3.06 :> The hex files can be configured in the (.rpj) itself.

If the files in *.rpj has to be overwritten, then this parameter has to configured.

Scalar in case of single hex file

    e.g : Renesas_ECU_AutoFlash('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3.hex');

Array ref in case of multiple hex files 

    e.g : Renesas_ECU_AutoFlash(['C:\TurboLIFT\Projects\Ford_AB12_CD4_1_MCA\config\SW\VW1202_CA_0228_BB100484_Cat5.hex',
                            'C:\TurboLIFT\Projects\Ford_AB12_CD4_1_MCA\config\SW\VW1202_CA_0228_BB100484_Cat5_dflash.hex']);

=back

B<Return Values:>

=over

=item $result

1 - offline, success

undef - error

=back


B<Examples:>
    
    $result = Renesas_ECU_AutoFlash('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3.hex');
    
B<Notes:> 
RFP.exe should be present in the path "C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V2.05\RFP.exe".
     
And corresponding project files have to be present in path given in setting 'Project_Workspace' of Testbench Device config of Renesas_Flash_tool  ( as default is considered "..\config\Tools\Renesas" ).

   Example :  'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # Renesas project workspace

=cut

sub Renesas_ECU_AutoFlash {
    my @args            = @_;
    my $hexFilepath_mix = shift @args;

    #STEP Read testbench configuration for Flash tool exe path and workspace
    my $exe_path = $LIFT_config::LIFT_Testbench->{'Devices'}{'Renesas_Flash_Tool'}{'FlashTool_exe_path'};
    $project_Workspace = $LIFT_config::LIFT_Testbench->{'Devices'}{'Renesas_Flash_Tool'}{'Project_Workspace'};

    unless ( defined $exe_path ) {

        if ( ref $project_Workspace eq 'ARRAY' or $project_Workspace =~ /.*\.rpj/i ) {
            $exe_path = $default_rfpExec_3_06;
            S_w2log( 3, "Renesas_ECU_AutoFlash: Default exe path V3.06 : $exe_path is considered!", 'blue' );
        }
        else {
            $exe_path = $default_rfpExec_2_05;
            S_w2log( 3, "Renesas_ECU_AutoFlash: Default exe path V2.05 : $exe_path is considered!", 'blue' );
        }

    }

    # STEP if exe path not defined consider default as V2.05.
    unless ( -e $exe_path ) {
        my $errTxt  = 'ERROR : Could not find installation of Renesas Flash Programmer ( RFP ) : ' . $exe_path;
        my $hintTxt = 'HINT  : Please install RFP \n';
        $hintTxt .= '( V2.05 from the path: \\\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\Renesas\RFP\Renesas_Flash_Programmer_Package_V20500_free) \n';
        $hintTxt .= '( V3.06 from the path: \\\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\Renesas\RFP_V3\RFP_3.06 ) \n';
        if ($main::opt_offline) {
            S_set_warning("Renesas_ECU_AutoFlash : $errTxt ");
            S_w2rep( "Renesas_ECU_AutoFlash : $hintTxt \n", 'red' );
        }
        else {
            S_set_error("Renesas_ECU_AutoFlash : $errTxt ");
            S_w2rep( "Renesas_ECU_AutoFlash : $hintTxt \n", 'red' );
            return;
        }

    }

    #IF Is RFP version V3 ?
    # IF-YES-START
    # CALL Renesas_ECU_AutoFlash_V3
    # IF-YES-END
    #IF-NO-START
    # CALL Renesas_ECU_AutoFlash_V2_05
    #IF-NO-END

    my $options_href = {
        'exe_path'      => $exe_path,
        'prj_workspace' => $project_Workspace,
        'hex_FileName'  => $hexFilepath_mix
    };

    if ( $exe_path =~ /rfpv3/i ) {
        return unless ( Renesas_ECU_AutoFlash_V3($options_href) );
    }
    else {
        return unless ( Renesas_ECU_AutoFlash_V2_05($options_href) );
    }

    #STEP END
    return 1;
}

=head2 Renesas_ECU_AutoFlash_V2_05

    $result = Renesas_ECU_AutoFlash_V2_05([$hexFilepath]);

Flashes the ECU SW using Renesas Flash Programmer version 2.05. Function invokes RFP.exe which should be pre-installed.

B<Arguments:>

=over

=item $hexFilepath (optional)

The absolute path of hex file for the SW to be flashed. If not mentioned here, it reads the SAD file path from the config file and uses the same path to search for .hex and _dlash.hex file..

=back

B<Return Values:>

=over

=item $result

1 - offline, success

undef - error

=back


B<Examples:>
    
    $result = Renesas_ECU_AutoFlash_V2_05('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3.hex');
    
B<Notes:> 

=cut

sub Renesas_ECU_AutoFlash_V2_05 {
    my @args         = @_;
    my $options_href = shift @args;
    my $hexfilename  = $options_href->{'hex_FileName'};
    my $exe_path     = $options_href->{'exe_path'};
    $project_Workspace = $options_href->{'prj_workspace'};

    #STEP Read testbench configuration for ECU type and tool serial number
    $ECU_Type       = S_get_contents_of_hash( [ 'Devices', 'Renesas_Flash_Tool', 'ECU_type' ],         $LIFT_config::LIFT_Testbench );
    $Renesas_Sl_Num = S_get_contents_of_hash( [ 'Devices', 'Renesas_Flash_Tool', 'FlashTool_Sl_Num' ], $LIFT_config::LIFT_Testbench );

    S_w2log( 3, "Renesas_ECU_AutoFlash_V2_05 : TestBench Info => ECU Type is $ECU_Type and Renesas serial Num is $Renesas_Sl_Num\n" );

    #IF ECU type or serial number of the tool not defined
    #IF-YES-START
    #STEP set error
    #IF-YES-END
    if ( not defined $ECU_Type or not defined $Renesas_Sl_Num ) {
        S_set_error( "Renesas_ECU_AutoFlash_V2_05 : Please configure ECU_type and FlashTool_Sl_Num in Testbench configuration", 108 );
        return;
    }

    if ( ref $project_Workspace eq 'ARRAY' ) {
        S_set_error( "Renesas_ECU_AutoFlash_V2_05 : Project_Workspace should be of type scalar value for V2.05 RFP", 108 );
        return;
    }

    if ( $project_Workspace =~ /\.rpj$/i ) {
        S_set_error( "Renesas_ECU_AutoFlash_V2_05 : Workspace path should contain folder name only for RFP V2.05! Configured name: $project_Workspace", 108 );
        return;
    }

    #IF-NO-START
    # CALL Check_Hex_files
    my $dflashhexfilename;
    ( $hexfilename, $dflashhexfilename ) = Check_Hex_files($hexfilename);

    return unless ( defined $hexfilename );

    #STEP select RFP workspace according to ECU type
    my $rwsActiveProj   = "NOT_DEFINED";
    my $needsCleanHex   = 0;
    my $extendCodeFlash = 0;

    if ( $ECU_Type eq "R1L" ) {
        $rwsActiveProj   = "R1L512k_ecuFlash";
        $needsCleanHex   = 1;
        $extendCodeFlash = 1;
    }
    elsif ( $ECU_Type eq "R1L1MB" ) {
        $rwsActiveProj   = "R1L1MB_ecuFlash";
        $needsCleanHex   = 1;
        $extendCodeFlash = 1;
    }
    elsif ( $ECU_Type eq "D4" ) {
        $rwsActiveProj = "P1xD4_ecuFlash";
        $needsCleanHex = 0;
    }
    elsif ( $ECU_Type eq "D3" ) {
        $rwsActiveProj = "P1xD3_ecuFlash";
        $needsCleanHex = 0;
    }
    elsif ( $ECU_Type eq "D3A" ) {
        $rwsActiveProj = "P1xD3A_ecuFlash";
        $needsCleanHex = 0;
    }
    else {
        ( $rwsActiveProj, $needsCleanHex, $extendCodeFlash ) = split( /;/, $ECU_Type );
    }

    unless ( -e $temp_directory or mkdir $temp_directory ) {
        S_set_error( "Renesas_ECU_AutoFlash_V2_05 : Unable to create $temp_directory\n", 1 );
        return;
    }

    my $project_path = "";
    if ( defined $project_Workspace ) {
        S_w2log( 3, " Renesas_ECU_AutoFlash_V2_05: Use configured 'Project_Workspace' from Testbench config ($project_Workspace)" );
        $project_path = $project_Workspace . "/$rwsActiveProj";
    }
    else {
        $project_path = getcwd . "/config/Tools/Renesas/$rwsActiveProj";
    }
    unless ( -e $project_path ) {
        S_set_error( "Renesas_ECU_AutoFlash_V2_05 : Unable to find the project file : $project_path\n", 108 );
        return;
    }

    S_w2log( 3, "Renesas_ECU_AutoFlash_V2_05 : The Project Path used is $project_path\n" );

    $rwsFileName = $project_path . "/$rwsActiveProj.rws";

    if ( $needsCleanHex == 1 )    # Clean the hex file if required (only for R1x)
    {
        $hexfilename = Prepare_Hex_File($hexfilename) || return;
    }

    return unless ( Prepare_RFP_workspace( $rwsActiveProj, $rwsFileName ) );    # Create workspace file (rws) for RFP tool

    #STEP write RFP script

    my $rfpScriptFile;
    return unless ( $rfpScriptFile = Prepare_RFP_script( $hexfilename, $dflashhexfilename, $extendCodeFlash ) );

    return unless ( Execute_RFP_script( $rfpScriptFile, $exe_path ) );

    #IF-NO-END
    #STEP END
    S_w2log( 3, "Renesas_ECU_AutoFlash_V2_05 : ECU Flashing done\n", 'blue' );

    return 1;
}

=head2 Renesas_ECU_AutoFlash_V3

    $result = Renesas_ECU_AutoFlash_V3 ([$hexFilepath]);

Flashes the ECU SW using Renesas Flash Programmer Version 3.06. Function invokes RFPV3.exe which should be pre-installed.

B<Arguments:>

=over

=item $hexFilepath (optional)

The absolute path of hex file for the SW to be flashed. If not mentioned here, it reads the SAD file path from the config file and uses the same path to search for .hex and _dlash.hex file..

=back

B<Return Values:>

=over

=item $result

1 - offline, success

undef - error

=back


B<Examples:>
    
    $result = Renesas_ECU_AutoFlash_V3('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3_merged.hex');
    
B<Notes:> 

=cut

sub Renesas_ECU_AutoFlash_V3 {

    my @args         = @_;
    my $options_href = shift @args;
    my $exe_path     = $options_href->{'exe_path'};
    $project_Workspace = $options_href->{'prj_workspace'};
    my $hexfilename = $options_href->{'hex_FileName'};

    my $logPath = $temp_directory;

    my $hexfile           = '';
    my $check_result_href = {};
    my $temphexfile;

    unless ($project_Workspace) {
        S_set_error( "Renesas_ECU_AutoFlash_V3: Workspace (.rpj) not configured, Configure 'Project_Workspace' in Testbench!", 108 );
        return;
    }

    #STEP prepare hex file command based on argument
    if ( defined $hexfilename ) {
        $hexfilename = File::Spec->rel2abs($hexfilename);
        if ( $hexfilename !~ /(.*\_merged\.hex$)/ ) {
            my $merged_hex = $hexfilename;
            $merged_hex =~ s/(.*)(\.hex)/$1_merged\.hex/;
            if ( -e $merged_hex ) {
                S_w2log( 3, "Renesas_ECU_AutoFlash_V3: merged hex file is present in the same folder where hex file is, hence merged hex file is considered for flashing since RFPV3 supports only merged hex.\n", 'blue' );
                $hexfile = ' /file ' . '"' . $merged_hex . '"';
            }
            else {
                S_w2log( 3, "Renesas_ECU_AutoFlash_V3: No merged hex file present, hence merged hex file will be prepared as RFPV3 supports only merged hex flashing\n", 'blue' );
                $temphexfile = Prepare_merged_hex_from_hex($hexfilename);
                $hexfile     = ' /file ' . '"' . $temphexfile . '"';
            }
        }
        else {
            $hexfile = ' /file ' . '"' . $hexfilename . '"';
        }

    }
    else {

        $hexfilename = Prepare_hexFileName_from_SADFileName();
        $hexfilename = File::Spec->rel2abs($hexfilename);
        my $merged_hex = $hexfilename;
        $merged_hex =~ s/(.*)(\.hex)/$1_merged\.hex/;
        if ( -e $merged_hex ) {
            S_w2log( 3, "Renesas_ECU_AutoFlash_V3: merged hex file is present in the same folder where hex file is, hence merged hex file is considered for flashing since RFPV3 supports only merged hex.\n", 'blue' );
            $hexfile = ' /file ' . '"' . $merged_hex . '"';
        }
        else {
            S_w2log( 3, "Renesas_ECU_AutoFlash_V3: No merged hex file present, hence merged hex file will be prepared as RFPV3 supports only merged hex flashing\n", 'blue' );
            $temphexfile = Prepare_merged_hex_from_hex($hexfilename);
            $hexfile     = ' /file ' . '"' . $temphexfile . '"';
        }

    }

    # STEP prepare rpj file command based on arg type aref - multiple, scalar - single
    # CALL S_call_command for prepared command string
    # if more than one workspace
    if ( ref $project_Workspace eq 'ARRAY' ) {
        foreach my $rpj (@$project_Workspace) {
            if ( $rpj !~ /\.rpj/i ) {
                S_set_error( "Renesas_ECU_AutoFlash_V3: Complete file path including file name(.rpj) shall be configured When RFP V3 version is used", 109 );
                return;
            }

            if ( $rpj =~ /(.*)(\\|\/)(.*)(\.rpj)/ ) {
                $logPath = $temp_directory . "\\$3" . '.log';
            }

            return 1 if $main::opt_offline;

            my $flash_options_href = { 'project_Workspace' => $rpj, 'hexfilename' => $hexfilename, 'exe_path' => $exe_path, 'hexfile' => $hexfile, 'logPath' => $logPath };
            Flashdata($flash_options_href);
            S_wait_ms(2000);    # wait time given for starting new connect cycle
        }
    }

    # single workspace
    else {
        if ( $project_Workspace !~ /\.rpj/i ) {
            S_set_error( "Renesas_ECU_AutoFlash_V3: Complete file path including file name(.rpj) shall be configured When RFP V3 version is used", 109 );
            return;
        }
        if ( $project_Workspace =~ /(.*)(\\|\/)(.*)(\.rpj)/ ) {
            $logPath = $temp_directory . "\\$3" . '.log';
        }

        return 1 if $main::opt_offline;
        my $flash_options_href = { 'project_Workspace' => $project_Workspace, 'hexfilename' => $hexfilename, 'exe_path' => $exe_path, 'hexfile' => $hexfile, 'logPath' => $logPath };
        return unless ( Flashdata($flash_options_href) );
    }

    if ($temphexfile) {
        unlink $temphexfile;
        S_w2log( 5, "Renesas_ECU_AutoFlash_V3: temporary file deleted!" );
    }

    # STEP END

    return 1;
}

=head1 not exported functions

=head2 Prepare_Hex_File

    $CleanHex = Prepare_Hex_File( $oriFile );

Check if hex file contains any information which RFP can't understand, e.g. "Consolidated hex" header
If so, create a clean copy of hex file and flash the copy instead of original returns path/filename of original or cleaned file.  

B<Examples:>

    $CleanHex = Prepare_Hex_File( $fileHandle ); 

=cut

sub Prepare_Hex_File {
    my @args      = @_;
    my $oriFile   = shift @args;
    my $cleanFile = $temp_directory . '\\cleanHexFile.hex';
    my $state     = 'clean';
    unless ( open( ORI, "<$oriFile" ) ) {
        S_set_error("Prepare_Hex_File : ERROR! Couldn't open $oriFile for reading ");
        return;
    }

    unless ( open CLEAN, ">$cleanFile" ) {
        S_set_error("Prepare_Hex_File : ERROR ! Couldn't open $cleanFile for writing");
        return;
    }

    do {
        my $line = <ORI>;
        if ( $line =~ /Consolidated HEX/ ) {
            $state = 'dirty';
        }
        else {
            print CLEAN $line;
        }
    } until ( eof($oriFile) );

    close(ORI);
    close(CLEAN);

    if ( $state eq 'clean' ) {
        S_w2log( 4, "Prepare_Hex_File : Original Hex file($oriFile) is considered for flashing\n" );
        return ($oriFile);
    }
    else {
        S_w2log( 4, "Prepare_Hex_File : :Hex file is modified($cleanFile) and then it is considered for flashing.\n" );
        return ($cleanFile);
    }

}

=head2 Prepare_RFP_workspace

    Prepare_RFP_workspace( $rwsActiveProj,  $rwsFileName);

    Prepares the renesas workspace(.rws) file.  

B<Examples:>

    Prepare_RFP_workspace( $rwsActiveProj,  $rwsFileName); 

=cut

sub Prepare_RFP_workspace {
    my $rwsActiveProj = shift;
    $rwsFileName = shift;

    my $rwsFileContent;
    my $line;

    my $rwsTemplate = "";
    if ( defined $project_Workspace ) {
        $rwsTemplate = $project_Workspace . "/ecuFlash_allDevices.rws";
        S_w2log( 3, " Prepare_RFP_workspace: Use configured 'Project_Workspace' from Testbench config ($project_Workspace)\n" );
    }
    else {
        $rwsTemplate = getcwd . "/config/Tools/Renesas/ecuFlash_allDevices.rws";    # default workspace for RFP
    }

    unless ( -e $rwsTemplate ) {
        S_set_error("Renesas_ECU_AutoFlash : Unable to find the Renesas workspace RWS template file project file : $rwsTemplate\n");
        return;
    }

    unless ( open RWS, $rwsTemplate ) {
        S_set_error("Prepare_RFP_workspace : ERROR ! Couldn't open file $rwsTemplate !");
        return;
    }

    S_w2log( 3, "Prepare_RFP_workspace : Template Renesas Workspace file is placed at '$rwsTemplate'\n" );

    while ( $line = <RWS> ) {

        # replace dummy with current project data
        $line =~ s/dummy_to_be_replaced/$rwsActiveProj/g;
        if ( $line =~ /<ActiveProjectName>/ ) {

            # Line contains the active project, replace by desired value
            $rwsFileContent .= "  <ActiveProjectName>$rwsActiveProj</ActiveProjectName>\n";
        }
        else {
            $rwsFileContent .= $line;
        }
    }
    close RWS;

    # remove write protection for rws file
    S_w2log( 4, "Prepare_RFP_workspace : Write protection is removed for the Renesas Workspace File\n" );
    chmod 0777, $rwsFileName;

    # Write updated file
    S_w2log( 3, "Prepare_RFP_workspace : The Template Renesas Workspace file contents are copied to the actual Renesas Workspace File($rwsFileName) which will be used for flashing\n" );

    unless ( open RWS, ">$rwsFileName" ) {
        S_set_error("Prepare_RFP_workspace : ERROR ! Couldn't open file $rwsFileName for writing !");
        return;
    }

    print RWS $rwsFileContent;
    close RWS;

    return 1;
}

=head2 Prepare_merged_hex_from_hex

    $result = Prepare_merged_hex_from_hex ($hexfilename);

Flashes the ECU SW using Renesas Flash Programmer Version 3.06. Function invokes RFPV3.exe which should be pre-installed.

B<Arguments:>

=over

=item $hexfilename

The absolute path of *.hex file for the SW to be flashed.

=back

B<Return Values:>

=over

=item $merged_hex

$merged_hex on success

undef on error

=back

=cut

sub Prepare_merged_hex_from_hex {
    my @args        = @_;
    my $hexfilename = shift @args;

    $hexfilename = File::Spec->rel2abs($hexfilename);

    #start merging of hex and dflash hex
    my @hex_file_content = read_file( $hexfilename, { err_mode => "quiet" } );
    unless (@hex_file_content) {
        S_set_error("Prepare_merged_hex_from_hex: ERROR ! Couldn't open $hexfilename for reading\n");
        return;
    }

    my $dflash_hexname = $hexfilename;
    $dflash_hexname =~ s/(.*)(\.hex)/$1_dflash\.hex/;
    my @dflash_hex_file_content = read_file( $dflash_hexname, { err_mode => "quiet" } );
    unless (@dflash_hex_file_content) {
        S_set_error("Prepare_merged_hex_from_hex: ERROR ! Couldn't open $dflash_hexname for reading\n");
        return;
    }
    pop(@hex_file_content);

    my $merged_hex = $hexfilename;
    $merged_hex =~ s/(.*)(\.hex)/$1_tempmerged\.hex/;
    unless ( write_file( $merged_hex, { err_mode => 'quiet' }, @hex_file_content, @dflash_hex_file_content ) ) {
        S_set_error( "Could not write content to '$project_Workspace' workspace ", 1 );
        return;
    }
    return $merged_hex;

}

=head2 Prepare_RFP_script

    $rfpScript = Prepare_RFP_script($hexfilename, $dflashhexfilename, $extendCodeFlash);

This function creates the RFP script for .rsc file. Returns rfp script.

B<Examples:>

    $rfpScript = Prepare_RFP_script( 'C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3.hex', 'C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3_dflash.hex', 1); 

=cut

sub Prepare_RFP_script {
    my @args = @_;

    my $hexfilename       = shift @args;
    my $dflashhexfilename = shift @args;
    my $extendCodeFlash   = shift @args;

    my $rfpScript = <<EOF_RSC;
// Script for Renesas Flash Programmer
// Created by LIFT_Renesas_ECU_Flash
// Hint: All files must be given with ABSOLUTE path !
log "<LOGFILE>"
workspace "<WORKSPACE>"
serial e1 <SerialNumE1>
connect
// If data flash write is enabled, erase complete device first
// to make sure that no previous data flash content remains
<DF_ENABLE>erase device
// Program flash area
programfile "<HEXFILE>" userdata
program
// verify
// Extended user area (program flash)
// Not needed for P1x
<EXTEND_ENABLE>programfile "<HEXFILE>" userboot
<EXTEND_ENABLE>program
// verify
// Data flash area
<DF_ENABLE>programfile "<DATAHEXFILE>" userdata
<DF_ENABLE>program
// verify
disconnect
EOF_RSC

    #replacing the variables with data
    #Adding the log file for info
    $absLogFileName = $temp_directory . '\Renesas.log';
    S_w2log( 4, "Prepare_RFP_script : :Log file is created in $absLogFileName.\n" );
    $rfpScript =~ s/<LOGFILE>/$absLogFileName/;

    #Adding the hex file with absolute path
    my $absHexFileName = File::Spec->rel2abs($hexfilename);
    $rfpScript =~ s/<HEXFILE>/$absHexFileName/g;

    #Adding the serial number of the tool
    $rfpScript =~ s/<SerialNumE1>/$Renesas_Sl_Num/;

    #Adding the workspace file
    my $abs_rwsFileName = File::Spec->rel2abs($rwsFileName);
    $rfpScript =~ s/<WORKSPACE>/$abs_rwsFileName/;

    # Extended code flash programming (only R1x)
    if ( $extendCodeFlash == 1 ) {
        $rfpScript =~ s/<EXTEND_ENABLE>//g;    # Remove place holder to enable command
    }
    else {
        # Disable extended code flash file in RFP script by commenting out the lines
        $rfpScript =~ s/<EXTEND_ENABLE>/\/\/ /g;
    }

    # Data flash file (only if needed)
    if ( defined($dflashhexfilename) ) {
        my $absDataFlashFile = File::Spec->rel2abs($dflashhexfilename);
        $rfpScript =~ s/<DATAHEXFILE>/$absDataFlashFile/g;
        $rfpScript =~ s/<DF_ENABLE>//g;        # Remove place holder to enable command
    }
    else {

        # Disable data flash file in RFP script by commenting out the lines
        $rfpScript =~ s/<DF_ENABLE>/\/\/ /g;
    }

    my $rfpScriptFile = $temp_directory . "/ecuFlash.rsc";

    #create script file in temporary directory
    S_w2log( 4, "Prepare_RFP_script : The Renesas Script file which has to be passed as an argument to the Renesas .exe is created in location '$rfpScriptFile'\n" );

    unless ( open RSC, ">$rfpScriptFile" ) {
        S_set_error("Prepare_RFP_script : ERROR ! Couldn't open file $rfpScriptFile for writing !");
        return;
    }

    print RSC $rfpScript;
    close(RSC);

    return $rfpScriptFile;
}

=head2 print_RFP_Log

    $absFilePath = print_RFP_Log($absLogFileName);

Prints the RFP result to HTML report.

B<Examples:>

    1 = Check_Result_RFPV3( '\config\Tools\Renesas\vw_flash.rpj', 1, 'C:\temp\Renesas.log');

=cut

sub print_RFP_Log {
    my @args = @_;

    S_checkFunctionArguments( 'print_RFP_Log( $absLogFileName )', @args ) or return;
    $absLogFileName = shift @args;

    unless ( open( LOG, $absLogFileName ) ) {
        S_set_error("print_RFP_Log : Couldn't open log file: $absLogFileName");
        return;
    }

    S_w2log( 2, " print_RFP_Log : LOGFILE OUTPUT from RENESAS FLASH TOOL \n", 'blue' );

    while (<LOG>) {
        s/[^[:ascii:]]+/ /g;    # remove non -ascii characters for printing to html report
        S_w2log( 2, $_, 'blue' );
    }

    close(LOG);

    return 1;
}

=head2 Execute_RFP_script

    $rfpScript = Execute_RFP_script($rfpScriptFile);

This function accepts the RFP script file as input parameter and the RFP.exe is executed with RFP script file as argument.

B<Examples:>

    $rfpScript = Execute_RFP_script( 'C:\temp\LIFT\ecuFlash.rsc'); 

=cut

sub Execute_RFP_script {
    my @args          = @_;
    my $rfpScriptFile = shift @args;
    my $exe_path      = shift @args;

    #flashing the software
    S_w2log( 1, " Execute_RFP_script : Flashing the software...   " );
    my $cmd = '"' . $exe_path . '" ' . $rfpScriptFile;

    #STEP call RFP.exe passing the script created
    S_w2log( 2, " Execute_RFP_script  : Executing $cmd ..\n" );

    return 1 if $main::opt_offline;

    my ( $result, @SCREEN_OUTPUT_LINES ) = S_call_command_NOERROR("$cmd");

    S_w2log( 2, " Execute_RFP_script  : Result of flash tool is $result\n" );

    unless ($result) {
        S_set_error(
            "Execute_RFP_script : Renasas flash tool execution error:
               HINT: 1. check if workspace mismatch with RFP version used.
                     2. Try to disconnect and connect USB of flash tool ( problem occurs when the PC is restarted sometimes)
               Check LOGFILE OUTPUT in BLUE FOR FURTHER DETAILS", 23
        );
    }

    print_RFP_Log($absLogFileName) unless ($result);

    return $result;
}

=head2 Check_Hex_files

    $absFilePath = Check_Hex_files([, $hexfilename]);

Checks the .hex and dflash.hex are present and returns the full path.

B<Examples:>

    ($hexfilename, $dflashhexfilename) = Check_Hex_files( '\config\TO1201_B2_0035_BB100062_Cat3.hex'); 

=cut

sub Check_Hex_files {

    my @args        = @_;
    my $hexfilename = shift @args;

    unless ( defined $hexfilename ) {
        $hexfilename = Prepare_hexFileName_from_SADFileName();
        return unless ($hexfilename);
    }

    my $dflashhexfilename = $hexfilename;
    $dflashhexfilename =~ s/\.hex/\_dflash.hex/;

    #if .hex file and dflash.hex does not exist in mentioned path
    if ( not -e $hexfilename or not -e $dflashhexfilename ) {
        S_set_error( "Check_Hex_files : $hexfilename file or $dflashhexfilename does not exist. Please place the files in correct path", 1 );
        return;
    }

    return ( $hexfilename, $dflashhexfilename );
}

=head2 Check_Result_RFPV3

    $absFilePath = Check_Result_RFPV3($options_href);

Checks the result of flashing and logs the respective result to HTML report.

Takes input of rpj, result of S_call_command and logpath.

B<Examples:>

    1 = Check_Result_RFPV3( {'rpj' => '\config\Tools\Renesas\vw_flash.rpj', 'result' => 1, 'logpath' => 'C:\temp\Renesas.log'}  );

=cut

sub Check_Result_RFPV3 {
    my @args = @_;
    S_checkFunctionArguments( 'Check_Result_RFPV3( $options_href )', @args ) or return;
    my $options_href = shift @args;
    my $rpj          = $options_href->{'rpj'};
    my $result       = $options_href->{'result'};
    my $logPath      = $options_href->{'logpath'};

    unless ($result) {
        return print_RFP_Log($logPath);
    }
    S_w2log( 3, "Check_Result_RFPV3: ECU flashing Done!", 'blue' );
    return 1;
}

=head2 Prepare_hexFileName_from_SADFileName

    Prepare_hexFileName_from_SADFileName();

returns hexfilename from sad file path provided.

=cut

sub Prepare_hexFileName_from_SADFileName {

    my $sadfilename = $LIFT_config::SAD_file;
    unless ( defined $sadfilename ) {
        S_set_error( "Prepare_hexFileName_from_SADFileName : $sadfilename is not a valid SAD file location\n", 108 );
        return;
    }
    S_w2log( 3, "Prepare_hexFileName_from_SADFileName : Since SW HexFile is not passed as a parameter to the function, by default the hex file is taken from the SAD file path:$sadfilename\n" );
    my $hexfilename = $sadfilename;
    $hexfilename =~ s/\.sad$/.hex/i;
    return $hexfilename;
}

=head2 Flashdata

    $absFilePath = Flashdata($options_href);

Flashes the workspace to ECU. Reloads the workspace to original settings after writing *merged.hex file.

returns 1 on success and undef on error.

=cut

sub Flashdata {
    my @args         = @_;
    my $options_href = shift @args;
    $project_Workspace = $options_href->{'project_Workspace'};
    my $hexfilename = $options_href->{'hexfilename'};
    my $exe_path    = $options_href->{'exe_path'};
    my $hexfile     = $options_href->{'hexfile'};
    my $logPath     = $options_href->{'logPath'};

    my ($original_content) = Replace_program_file( $project_Workspace, $hexfilename );

    return unless ($original_content);

    my $cmd = '"' . $exe_path . '"' . ' /silent ' . '"' . $project_Workspace . '"' . $hexfile . ' /log ' . '"' . $logPath . '"';
    S_w2log( 3, "Renesas_ECU_AutoFlash_V3: Starting Flashing of workspace '$project_Workspace' started " );
    my ( $result, @SCREEN_OUTPUT_LINES ) = S_call_command_NOERROR("$cmd");
    unless ($result) {
        S_set_error( "Renesas_ECU_AutoFlash_V3: Flashing of workspace: '$project_Workspace' not successfull check LOGFILE output below for details", 23 );
    }

    my $check_result_href = { 'rpj' => $project_Workspace, 'result' => $result, 'logpath' => $logPath };
    return unless ( Check_Result_RFPV3($check_result_href) );

    # re-write original content to rpj file
    return unless ( Write_content_of_workspace( $project_Workspace, $original_content ) );
    return 1;
}

=head2 Write_content_of_workspace

    $absFilePath = Write_content_of_workspace($project_Workspace, $content_to_be_written);

writes the contents to be written for the workspace.

returns 1 on success and undef on error.

=cut

sub Write_content_of_workspace {
    my @args = @_;
    $project_Workspace = shift @args;
    my $content_to_be_written = shift @args;
    unless ( write_file( $project_Workspace, { err_mode => 'quiet' }, $content_to_be_written ) ) {
        S_set_error( "Could not write content to '$project_Workspace' workspace ", 1 );
        return;
    }
    return 1;
}

=head2 Read_content_of_workspace

    $workspace_content = Read_content_of_workspace($project_Workspace);

returns the content of workspace. undef on error.

=cut

sub Read_content_of_workspace {
    my @args = @_;
    $project_Workspace = shift @args;

    my $workspace_content = read_file( $project_Workspace, { err_mode => "quiet" } );
    if ( not defined $workspace_content ) {
        S_set_error("Read_content_of_workspace: ERROR ! Couldn't open $project_Workspace for reading\n");
        return;
    }
    return $workspace_content;
}

=head2 Replace_program_file

    $workspace_content = Replace_program_file($project_Workspace, $hexFileName);

Fills the <Programfile> field of the workspace with the *merged.hex file path.

Returns the original content of workspace before writing the *merged.hex file. This is done inorder to revert back the input workspace with original settings. 

=cut

sub Replace_program_file {
    my @args = @_;
    $project_Workspace = shift @args;
    my $hexFileName       = shift @args;
    my $workspace_content = Read_content_of_workspace($project_Workspace);
    return unless ($workspace_content);
    my $original_content = $workspace_content;
    $workspace_content =~ s/<ProgramFile>(.*)?((\n)?(\r)?(\s*)?)?<\/ProgramFile>/<ProgramFile>$hexFileName<\/ProgramFile>/g;
    return unless ( Write_content_of_workspace( $project_Workspace, $workspace_content ) );
    return ($original_content);    # required to be replaced with original content in the input workspace after flashing
}

1;
