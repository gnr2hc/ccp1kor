# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_vector_xcp;

use strict;
use Win32::OLE;
use LIFT_general;
use LIFT_vector_cantool;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;
# next 2 lines edited by MKS, DO NOT MODIFY

@ISA = qw(Exporter);
@EXPORT = qw(
             VEX_init

             VEX_read_signal
             VEX_write_signal

             VEX_cmd_reset
             VEX_cmd_setdatatype
             VEX_cmd_setmsgid
             VEX_cmd_connect
             VEX_cmd_disconnect
             VEX_cmd_read
             VEX_cmd_write

          ); # export subs

our $cantool;        ### object reference to CANoe/CANalyzer
our $CAPL;   ### hash reference with all CAPL environment vars

my $CAPL_control;

### maximum wait time for client used as parameter for VEX_wait_for_response($timeout_command)
my $timeout_command = 3000;

### step width for wait loop
my $timeout_step = 30;

### step width for wait loop
my $cmd_rsp_wait_time = 30;


#####################################################################

### CONSTANTS

#----------------------------------------------------------------
#-- Interface Request Command Codes
#----------------------------------------------------------------
use constant CmdReq_Reset       => 0;
use constant CmdReq_SetDataType => 1;
use constant CmdReq_SetMsgId    => 2;
use constant CmdReq_Connect     => 3;
use constant CmdReq_Disconnect  => 4;
use constant CmdReq_Read        => 5;
use constant CmdReq_Write       => 6;
#----------------------------------------------------------------
#-- Data Type Codes
#----------------------------------------------------------------
use constant DataType_Intel     => 0;
use constant DataType_Motorola  => 1;
#----------------------------------------------------------------
#-- Status Response Codes
#----------------------------------------------------------------
use constant StatusRsp_Pending => 0;
use constant StatusRsp_Valid   => 1;
use constant StatusRsp_Invalid => 2;
#----------------------------------------------------------------
#-- Return Value Response Codes
#----------------------------------------------------------------
use constant RetValRsp_Ok  => 0;
use constant RetValRsp_Nok => 1;
#----------------------------------------------------------------
#-- Error Code Response Codes
#----------------------------------------------------------------
use constant ErrCodRsp_Ok              => 0;
use constant ErrCodRsp_Undef           => 1;
use constant ErrCodRsp_Offline         => 2;
use constant ErrCodRsp_Timeout         => 3;
use constant ErrCodRsp_Busy            => 4;
use constant ErrCodRsp_CmdNotSupported => 5;
use constant ErrCodRsp_ParaNotValid    => 6;

#####################################################################

=head1 NAME

LIFT_vector_xcp 

Provide LIFT useful functions for XCP measurement functionality on CANoe

=head1 SYNOPSIS

    use LIFT_vector_xcp;

             VEX_init

             VEX_read_signal
             VEX_write_signal

             VEX_cmd_reset
             VEX_cmd_setdatatype
             VEX_cmd_setmsgid
             VEX_cmd_connect
             VEX_cmd_disconnect
             VEX_cmd_read
             VEX_cmd_write

=cut

#####################################################################

=head2 VEX_init

 VEX_init( CAPL_control_OLE_handles );

=cut

#####################################################################

sub VEX_init
{
   my ( $CAPL_control_OLE_handles ) = shift @_ ;

   unless( defined $CAPL_control_OLE_handles ) {
      S_set_error( " SYNTAX: VEX_init( CAPL_control_OLE_handles )", 110 );
      return 0;
   }

   return 1 if $main::opt_offline; # just return if running in offline mode

   $CAPL_control = $CAPL_control_OLE_handles;

   return 1;
}


#####################################################################

=head2 VEX_read_signal

 $value = VEX_read_signal ( \%ecu_signal );

    %ecu_signal is hash of following structure:

    %ecu_signal = {
            'NAME' => "name_of_ecu_signal",
            'ADDRESS' => "0x01234567",
            'LENGTH' => 3,
            'TYPE' => "INTEL",
    }

=cut

#####################################################################

sub VEX_read_signal {

    my $given_ecu_signal = shift;

    unless (defined( $given_ecu_signal )) {
       S_set_error( "VEX_read_signal: too less parameters ; SYNTAX: VEX_read_signal( \%ecu_signal )", 110 );
       return 0;
    }

    return ( 1 , 1 ) if $main::opt_offline;

    my $ecu_signal_name    = $given_ecu_signal->{'NAME'};
    my $ecu_signal_address = hex( $given_ecu_signal->{'ADDRESS'});
    my $ecu_signal_length  = $given_ecu_signal->{'LENGTH'};
    my $ecu_signal_type    = $given_ecu_signal->{'TYPE'};

    if( defined $ecu_signal_type )
    {
        unless( VEX_cmd_setdatatype( $ecu_signal_type ) )
        {
            S_w2log( 3, " VEX_read_signal :  Set Data Type failed - no signal read done \n" );
             return 0;
        }
    }

    my ( $valid_flag , $signal_value ) = VEX_cmd_read ( $ecu_signal_address , $ecu_signal_length);

    if( $valid_flag )
    {
        S_w2log( 3, "VEX_read_signal: successful -> Signal value = '$signal_value' \n" );
        return ( $valid_flag , $signal_value );
    }
    else
    {
        S_w2log( 3, "VEX_read_signal: not successful \n" );
        return ( 0 );
    }
}

#####################################################################

=head2 VEX_write_signal

 $value = VEX_write_signal ( \%ecu_signal );

    %ecu_signal is hash of following structure:

    %ecu_signal = {
            'NAME'    => "name_of_ecu_signal",
            'ADDRESS' => "0x01234567",
            'VALUE'   => 1234,
            'LENGTH'  => 3,
            'TYPE'    => "INTEL",
    }

=cut

#####################################################################

sub VEX_write_signal {

    my $given_ecu_signal = shift;

    unless (defined( $given_ecu_signal )) {
       S_set_error( "VEX_write_signal: too less parameters ; SYNTAX: VEX_write_signal( \%ecu_signal )", 110 );
       return 0;
    }

    my $ecu_signal_name    = $given_ecu_signal->{'NAME'};
    my $ecu_signal_address = hex( $given_ecu_signal->{'ADDRESS'});
    my $ecu_signal_value   = $given_ecu_signal->{'VALUE'};
    my $ecu_signal_length  = $given_ecu_signal->{'LENGTH'};
    my $ecu_signal_type    = $given_ecu_signal->{'TYPE'};

    if( defined $ecu_signal_type )
    {
        unless( VEX_cmd_setdatatype( $ecu_signal_type ) )
        {
            S_w2log( 3, " VEX_write_signal :  Set Data Type failed - no signal write done \n" );
             return 0;
        }
    }

    my ( $valid_flag ) = VEX_cmd_write ( $ecu_signal_address , $ecu_signal_length , $ecu_signal_value);

    if( $valid_flag )
    {
        S_w2log( 3, "VEX_write_signal: successful \n" );
        return ( $valid_flag );
    }
    else
    {
        S_w2log( 3, "VEX_write_signal: not successful \n" );
        return ( 0 );
    }
}

#####################################################################

=head2 VEX_cmd_connect

    VEX_cmd_connect ( );

Establish XCP connection from XCP client to ECU

=cut

#####################################################################

sub VEX_cmd_connect
{

    my %response;

    S_w2log( 3, " VEX_cmd_connect : Send Command 'Connect' \n" );

    return 1 if $main::opt_offline;

    $CAPL_control->{ 'XCP_CommandReq' }{'Value'} = CmdReq_Connect;

    %response = VEX_wait_for_response( $timeout_command , 'XCP_StatusRsp' , ( StatusRsp_Valid , StatusRsp_Invalid ) );

    unless ( $response{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Ok )
    {
        S_set_error( "VEX_cmd_reset: failed , 'XCP_ReturnvalueRsp' not ok", 140 );
        return 0;
    }

    if ( $response{ 'XCP_StatusRsp' }{'Value'} == StatusRsp_Invalid )
    {
        ### note! no LIFT error , TC have to decide how to proceed again
        S_w2log( 3, "VEX_cmd_connect: ok, 'XCP_StatusRsp' invalid\n" );
        return 0;
    }

    if ( $response{ 'XCP_StatusRsp' }{'Value'} == StatusRsp_Valid )
    {
        S_w2log( 3, "VEX_cmd_connect: ok, connection valid\n" );
        return 1;
    }
    else
    {
        ### unexpected end of function
        S_w2log( 3, "VEX_cmd_connect: unexpected end of function\n" );
        return 0;
    }
}

#####################################################################

=head2 VEX_cmd_disconnect

    VEX_cmd_disconnect ( );

Disconnect XCP connection

=cut

#####################################################################

sub VEX_cmd_disconnect {

    my %response;

    S_w2log( 3, " VEX_cmd_disconnect : Send Command 'Disconnect' \n" );

    return 1 if $main::opt_offline;

    $CAPL_control->{ 'XCP_CommandReq' }{'Value'} = CmdReq_Disconnect;

    %response = VEX_wait_for_response( );

    unless ( $response{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Ok )
    {
        S_set_error( " VEX_cmd_disconnect: failed , 'XCP_ErrcodeRsp' not ok", 140 ); return 0;
    }

    return 1;
}


#####################################################################

=head2 VEX_cmd_setmsgid

    VEX_cmd_setmsgid ( VEX_can_send_id , VEX_can_recv_id );

set the send & receive CAN ids for XCP communication with ECU

=cut

#####################################################################

sub VEX_cmd_setmsgid {

   my $given_send_id = shift;
   my $given_recv_id = shift;

   my %response;

   unless( defined $given_recv_id ) {
     S_set_error( " SYNTAX: VEX_cmd_setmsgid (VEX_can_send_id , VEX_can_recv_id) ", 110 );
     return;
   }

   return 1 if $main::opt_offline;

   unless( $CAPL_control ) {
     S_set_error( " no XCP CAPL control available , use VEX_init() before", 141 );
     return;
   }

   S_w2log( 3, " VEX_cmd_setmsgid : Prepare Parameter 'XCP_XmtIdReq' = $given_send_id \n" );
   $CAPL_control->{ 'XCP_XmtIdReq' }{'Value'} = $given_send_id;

   S_w2log( 3, " VEX_cmd_setmsgid : Prepare Parameter 'XCP_RcvIdReq' = $given_recv_id \n" );
   $CAPL_control->{ 'XCP_RcvIdReq' }{'Value'} = $given_recv_id;

   S_w2log( 3, " VEX_cmd_setmsgid : Send Command 'SetMsgId'  \n" );
   $CAPL_control->{ 'XCP_CommandReq' }{'Value'} = CmdReq_SetMsgId;

   %response = VEX_wait_for_response( );

   unless ( $response{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Ok ) {
      S_set_error( " VEX_cmd_setmsgid: failed , 'XCP_ErrcodeRsp' not ok", 140 );
      return 0;
   }

   return 1;
}

#####################################################################

=head2 VEX_cmd_reset

    VEX_cmd_reset ( );

=cut

#####################################################################

sub VEX_cmd_reset {

    my %response;

    S_w2log( 3, " VEX_cmd_reset : Send Command 'Reset' \n" );

    return 1 if $main::opt_offline;

    $CAPL_control->{ 'XCP_CommandReq' }{'Value'} = CmdReq_Reset;

    %response = VEX_wait_for_response( );

    unless ( $response{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Ok )
    {
        S_set_error( " failed , 'XCP_ErrcodeRsp' not ok", 140 ); return 0;
    }

    return 1;
}


#####################################################################

=head2 VEX_cmd_setdatatype

    VEX_cmd_setdatatype ( 'Intel' );
    VEX_cmd_setdatatype ( 'Motorala' );

Parameter is not case sensitive

=cut

#####################################################################

sub VEX_cmd_setdatatype {

    my $given_data_type = shift;

    my $data_type;
    my %response;

    $data_type = DataType_Intel if $given_data_type =~ /intel/i;
    $data_type = DataType_Motorola if $given_data_type =~ /motorola/i;

    unless( defined $data_type )
    {
        S_set_error( "VEX_cmd_setdatatype: wrong parameter (SYNTAX: VEX_cmd_setdatatype ('Intel') or VEX_cmd_setdatatype ('Motorola') ) ", 110 ); 
        return 0;
    }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEX_cmd_setdatatype : Prepare Parameter 'XCP_DataTypeReq' = $data_type \n" );
    $CAPL_control->{ 'XCP_DataTypeReq' }{'Value'} = $data_type;

    S_w2log( 3, " VEX_cmd_setdatatype : Send Command 'SetDataType'  \n" );
    $CAPL_control->{ 'XCP_CommandReq' }{'Value'} = CmdReq_SetDataType;

    %response = VEX_wait_for_response( );

    unless ( $response{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Ok )
    {
        S_set_error( " failed , 'XCP_ErrcodeRsp' not ok", 140 ); return 0;
    }

    return 1;
}

#####################################################################

=head2 VEX_cmd_read

    VEX_cmd_read ( $ecu_signal_address , $ecu_signal_length );

=cut

#####################################################################

sub VEX_cmd_read {

    my $ecu_signal_address = shift;
    my $ecu_signal_length = shift;

    my %response;

    unless( defined $ecu_signal_length ) {
        S_set_error( "SYNTAX: VEX_cmd_read ($ecu_signal_address , $ecu_signal_length)", 110 );
        return 0;
    }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEX_cmd_read : Prepare Parameter 'XCP_AddressReq' = $ecu_signal_address \n" );
    $CAPL_control->{ 'XCP_AddressReq' }{'Value'} = $ecu_signal_address;

    S_w2log( 3, " VEX_cmd_read : Prepare Parameter 'XCP_LengthReq' = $ecu_signal_length \n" );
    $CAPL_control->{ 'XCP_LengthReq' }{'Value'} = $ecu_signal_length;

    S_w2log( 3, " VEX_cmd_read : Send Command 'Read'  \n" );
    $CAPL_control->{ 'XCP_CommandReq' }{'Value'} = CmdReq_Read;

    %response = VEX_wait_for_response( $timeout_command , 'XCP_StatusRsp' , ( StatusRsp_Valid , StatusRsp_Invalid ) );

    unless ( $response{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Ok )
    {
        S_set_error( " VEX_cmd_read: failed , 'XCP_ErrcodeRsp' not ok", 140 ); return 0;
    }

    if ( $response{ 'XCP_StatusRsp' }{'Value'} == StatusRsp_Invalid )
    {
        ### note! no LIFT error , TC have to decide how to proceed again
        S_w2log( 3, "VEX_cmd_read: failed, 'XCP_StatusRsp' invalid ( = ECU signal value not valid)\n" );
        return 0;
    }

    if ( $response{ 'XCP_StatusRsp' }{'Value'} == StatusRsp_Valid )
    {
        S_w2log( 3, "VEX_cmd_read: ok, signal status valid\n" );
        return ( 1 , $response{ 'XCP_ResultRsp' }{'Value'} );
    }
    else
    {
        ### unexpected end of function
        S_w2log( 3, "VEX_cmd_read: unexpected end of function\n" );
        return 0;
    }


    ### to be continue

    return 1;
}

#####################################################################

=head2 VEX_cmd_write

    VEX_cmd_write ( $ecu_signal_address , $ecu_signal_length );

=cut

#####################################################################

sub VEX_cmd_write {

    my $ecu_signal_address = shift;
    my $ecu_signal_length = shift;
    my $ecu_signal_value = shift;

    my %response;

    unless( defined $ecu_signal_length )
    {
        S_set_error( "VEX_cmd_write: too less parameter (SYNTAX: VEX_cmd_write ($ecu_signal_address , $ecu_signal_length) ) ", 110 ); return 0;
    }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEX_cmd_write : Prepare Parameter 'XCP_AddressReq' = $ecu_signal_address \n" );
    $CAPL_control->{ 'XCP_AddressReq' }{'Value'} = $ecu_signal_address;

    S_w2log( 3, " VEX_cmd_write : Prepare Parameter 'XCP_LengthReq' = $ecu_signal_length \n" );
    $CAPL_control->{ 'XCP_LengthReq' }{'Value'} = $ecu_signal_length;

    S_w2log( 3, " VEX_cmd_write : Prepare Parameter 'XCP_ValueReq' = $ecu_signal_value \n" );
    $CAPL_control->{ 'XCP_ValueReq' }{'Value'} = $ecu_signal_value;

    S_w2log( 3, " VEX_cmd_write : Send Command 'write'  \n" );
    $CAPL_control->{ 'XCP_CommandReq' }{'Value'} = CmdReq_Write;

    %response = VEX_wait_for_response( $timeout_command , 'XCP_StatusRsp' , ( StatusRsp_Valid , StatusRsp_Invalid ) );

    unless ( $response{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Ok )
    {
        S_set_error( " VEX_cmd_write: failed , 'XCP_ErrcodeRsp' not ok", 140 ); return 0;
    }

    if ( $response{ 'XCP_StatusRsp' }{'Value'} == StatusRsp_Invalid )
    {
        ### note! no STEPS error , TC have to decide how to proceed again
        S_w2log( 3, "VEX_cmd_write: failed, 'XCP_StatusRsp' invalid ( = write of ECU signal value not valid)\n" );
        return 0;
    }

    if ( $response{ 'XCP_StatusRsp' }{'Value'} == StatusRsp_Valid )
    {
        S_w2log( 3, "VEX_cmd_write: ok, write of ECU signal valid\n" );
        return ( 1 );
    }
    else
    {
        ### unexpected end of function
        S_w2log( 3, "VEX_cmd_write: unexpected end of function\n" );
        return 0;
    }


    ### to be continue

    return 1;
}

# Preloaded methods go here.

#####################################################################

=head2 VEX_wait_for_response

    %response = VEX_wait_for_response (  $timeout_ms , $check_signal , @valid_values_to_return );

return value is hash with following structure:

    %response = (
        'XCP_ReturnvalueRsp' => ... ,
        'XCP_ErrcodeRsp'     => ... ,
        'XCP_StatusRsp'     => ... ,
        'XCP_ResultRsp'     => ... ,
                )
'VEX_wait_for_response' is not exported; just used for VEX_cmd_...() functions

LIFT error handling only when timeout while waiting for response from XCP client

=cut

#####################################################################

sub VEX_wait_for_response {

    my $timeout           = shift;
    my $check_signal_name = shift;
    my @ret_values        = @_;

    my %response;
    my $expected_signal_found = 0;
    my $timeout_sum = 0;
    my $check_signal_value;
    my $valid_value;

    return 1 if $main::opt_offline; # just return if running in offline mode

    $timeout = $timeout_command unless defined $timeout;

    S_w2log( 5, " VEX_wait_for_response : wait '$cmd_rsp_wait_time' ms before start reading response\n" );
    S_wait_ms ( $cmd_rsp_wait_time );

    S_w2log( 4, " VEX_wait_for_response : Waiting for max. $timeout ms \n" );

    $response{ 'XCP_ErrcodeRsp' }{'Value'}     = $CAPL_control->{ 'XCP_ErrcodeRsp' }{'Value'};
    while( $timeout > 0  and $CAPL_control->{ 'XCP_ErrcodeRsp' }{'Value'} == ErrCodRsp_Undef )
    {
        $check_signal_value = $CAPL_control->{ 'XCP_ErrcodeRsp' }{'Value'};
        S_w2log( 4, " VEX_wait_for_response : 'XCP_ErrcodeRsp' => '$check_signal_value' \n" );
        S_wait_ms( $timeout_step );
        $timeout -= $timeout_step;
        $timeout_sum += $timeout_step;
        S_w2log( 5, " VEX_wait_for_response : wait time -> $timeout_sum ms\n" );
    }


    if ( defined $check_signal_name )
    {

       while ( $timeout > 0  and not $expected_signal_found )
       {
            $response{ 'XCP_ErrcodeRsp' }{'Value'}     = $CAPL_control->{ 'XCP_ErrcodeRsp' }{'Value'};
            $response{ 'XCP_ReturnvalueRsp' }{'Value'} = $CAPL_control->{ 'XCP_ReturnvalueRsp' }{'Value'};
            $response{ 'XCP_ResultRsp' }{'Value'}      = $CAPL_control->{ 'XCP_ResultRsp' }{'Value'};
            $response{ 'XCP_StatusRsp' }{'Value'}      = $CAPL_control->{ 'XCP_StatusRsp' }{'Value'};
            S_w2log( 5, " VEX_wait_for_response : 'XCP_ErrcodeRsp'     -> '".$response{ 'XCP_ErrcodeRsp' }{'Value'}."' \n" );
            S_w2log( 5, " VEX_wait_for_response : 'XCP_ReturnvalueRsp' -> '".$response{ 'XCP_ReturnvalueRsp' }{'Value'}."' \n" );
            S_w2log( 5, " VEX_wait_for_response : 'XCP_ResultRsp'      -> '".$response{ 'XCP_ResultRsp' }{'Value'}."' \n" );
            S_w2log( 5, " VEX_wait_for_response : 'XCP_StatusRsp'      -> '".$response{ 'XCP_StatusRsp' }{'Value'}."' \n" );
            $check_signal_value = $response{ $check_signal_name }{'Value'};
#            S_w2log( 4, " VEX_wait_for_response : '$check_signal_name' => '$check_signal_value' \n" );
            foreach $valid_value ( @ret_values )
            {
                if ( $check_signal_value == $valid_value )
                {
                    S_w2log( 4, " VEX_wait_for_response : '$check_signal_name' => '$check_signal_value' (wait condition passed) \n" );
                    $expected_signal_found = 1;
                }
            }
            unless( $expected_signal_found ) {
                S_wait_ms( $timeout_step ); $timeout -= $timeout_step; $timeout_sum += $timeout_step;
                S_w2log( 5, " VEX_wait_for_response : wait time -> $timeout_sum ms\n" );
            }
       }
    }

    unless( $timeout > 0 )
    {
        S_set_error( " VEX_wait_for_response : timeout while waiting for response from XCP client \n", 140 );
        return 0;
    }

    return %response;
}


1;
__END__


=head1 AUTHORS

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Archana GopalaKrishna, E<lt>Archana.Gopalakrishna@in.bosch.comE<gt>

=head1 SEE ALSO

perl documentation

=cut 
