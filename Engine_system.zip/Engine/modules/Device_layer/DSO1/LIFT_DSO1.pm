# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_DSO1;

use strict;
use warnings;
use LIFT_general;
use Readonly;

use DSO;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  DSO1_connect
  DSO1_disconnect
  DSO1_saveScreen
  DSO1_saveValues
  DSO1_writeString
  DSO1_readString
  DSO1_setTdiv
  DSO1_setVdiv
  DSO1_setSamples
  DSO1_setTriggermode
  DSO1_arm
  DSO1_saveConfig
  DSO1_restoreConfig
  DSO1_get_values
);

our ( $VERSION, $HEADER );

Readonly my $DSO_FAILED => -1;    #Return value when DSO object not available error condition

=head1 NAME

LIFT_DSO1 

Perl extension for LeCroy Data Storage Oscilloscope




=head1 SYNOPSIS

    use LIFT_DSO1;

    my ($string,$value,$DeviceID);

    $DeviceID = DSO1_connect();

    $string = DSO1_readString();
    $value = DSO1_setTdiv('10S');
    $value = DSO1_setVdiv(1,'5V');
    DSO1_saveValues("test1.txt", "1+2+3+4", 50000, 0);
    DSO1_saveScreen("test2.png");
    $data_HoH = DSO1_get_values("test1.txt.unv");
    DSO1_writeString("*IDN?");
    DSO1_setTriggermode('SINGLE');
    DSO1_arm();
    DSO1_setSamples('250K');
    DSO1_saveConfig(... );
    DSO1_restoreConfig(...);
    DSO1_disconnect();

    Testbenchconfig:
    'Devices' => {
        'DSO1' => {
            'connect' => 'GPIB:1',
        },


=head1 DESCRIPTION

remote control functions for LeCroy Data Storage Oscilloscope using ActiveDSO OLE interface

B<NOTE: ActiveDSO, perl modules GD::Graph and Image::Magick have to be installed !>

=cut

my $dso1;
my $Status;
my $ErrorString;

my %valid_Channels = (
                       'C1'  => 1,
                       'C2'  => 1,
                       'C3'  => 1,
                       'C4'  => 1,
                       'M1'  => 1,
                       'M2'  => 1,
                       'M3'  => 1,
                       'M4'  => 1,
                       'TA'  => 1,
                       'TB'  => 1,
                       'TC'  => 1,
                       'TD ' => 1,
);

=head1 METHODS

=head2 DSO1_connect

    $DeviceID = DSO1_connect( [$connection] );

    e.g. $DeviceID = DSO1_connect();
         $DeviceID = DSO1_connect('GPIB:1');
         $DeviceID = DSO1_connect('IP:10.3.40.187');
         $DeviceID = DSO1_connect('COM1: 9600,8,N,1');

    Testbenchconfig:
    'Devices' => {
        'DSO1' => {
            'connect' => 'GPIB:1',
        },


Connnect to DSO via given connection. If no connection given, data is taken from Testbenchconfig.
Reads device identification (*IDN). This method has to be called first before any other method can be used.

Make sure Data Storage Oscilloscope is configured accordingly !

    ActiveDSO help/MakeConnection Method description:

    Interface   Syntax                          Example
    GPIB        GPIBx: nn                       GPIB: 5
                x := 0..3  (optional)
                nn := 1..30
    Network     IP: a.b.c.d                     IP:128.23.24.21
                a,b,c,d := 0 to 255
    RS232       COMn: baud,bits,parity,stop     COM1: 19200,8,N,1
                n := 1..4
                baud := { 300 | 1200 | 2400 |
                4800 | 9600 | 19200 | 57600 |
                115000 }
                bits := 7 | 8
                parity := N | O | E
                stop := 1 | 1.5 | 2


Returns DeviceID

offline_return : 'dummy', return "error" on error

=cut

sub DSO1_connect
{

    my $connection = shift;
    my $deviceID;

    unless ( defined($connection) )
    {
        {
            no warnings;
            $connection = $LIFT_config::LIFT_Testbench->{'Devices'}{'DSO1'}{'connect'};
        }
        unless ($connection)
        {
            S_set_error( "No connection settings for DSO1 in testbench config found", 20 );
            return "error";
        }
        S_w2log( 3, "LIFT_DSO1: no connection given, taking '$connection' from testbench config\n" );
    }

    if ( defined($dso1) )
    {
        S_set_error( "Connection failed, DSO object could not be created, object exists already, DSO1 already initialized", 5 );
        return "error";
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "LIFT_DSO1: DSO1_connect($connection)\n" );
        $dso1 = 1;
        return "dummy";
    }

    $dso1 = DSO->new();

    unless ( defined($dso1) )
    {
        S_set_error( "DSO object could not be created", 5 );
        return "error";
    }
    else
    {
        ( $Status, $deviceID ) = $dso1->connect($connection);
        Check_Status();
        S_w2log( 3, "LIFT_DSO1: DSO1_connected to Device ($deviceID)\n" );
        return $deviceID;
    }
}

=head2 DSO1_disconnect

    DSO1_disconnect( );

Disconnect from DSO:

=cut

sub DSO1_disconnect
{

    unless ( defined($dso1) )
    {
        S_set_error( "Device could not be disconnected, Object does not exist. DSO1 was not initialized", 21 );
        return;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "LIFT_DSO1: Terminating the communication with DSO\n" );
        undef $dso1;
        return 1;
    }
    $Status = $dso1->disconnect();
    Check_Status();

    $dso1 = undef;
    S_w2log( 3, "LIFT_DSO1: Terminated the communication with DSO \n" );

    return 1;
}

=head2 DSO1_get_values

    $data_HoH = DSO1_get_values( $tracefilename );
    e.g. $data_HoH = DSO1_get_values("DSO_SaveValues.txt.unv");

returns structure created from uniview file file to evaluate with EVAL functions.

timebase of structure is in milliseconds

    e.g this uniview file
    TIME;C2;C4;
    s;volt;volt;
    0;59.6875;39.2437515258789;
    4e-005;59.6875;39.2437515258789;

    will lead to this data structure
    000000.000 C2=59.6875 C4=39.2437515258789
    000000.040 C2=59.6875 C4=39.2437515258789

offline_return : { 0 => { 'dummy' => 0 } }

=cut

sub DSO1_get_values
{
    my $filename = shift;
    my $data_HoH = {};
    my ( $line, @names, @values, $count, $time );
    my $data_HoH_dummy;
    $data_HoH_dummy->{0}->{'dummy'} = 0;

    unless ( defined($filename) )
    {
        S_set_error( "! too less parameters ! SYNTAX: data_HoH = DSO1_get_values( tracefilename )", 110 );
        return $data_HoH_dummy;
    }
    unless ( -f $filename )
    {
        S_set_error( "tracefilename $filename not found", 1 );
        return $data_HoH_dummy;
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_get_values data is reading from file $filename \n" );
    @names = ();

    return $data_HoH_dummy if ($main::opt_offline);

    if ( open( IN, "<$filename" ) )
    {
        $line = <IN>;
        @names = split( /;/, $line );
        shift(@names);
        $line = <IN>;

        while ( $line = <IN> )
        {
            @values = split( /;/, $line );
            $time   = shift(@values);
            $time   = sprintf( "%010.3f", ( $time * 1000 ) );
            for ( $count = 0 ; $count < scalar(@names) - 1 ; $count++ )
            {
                $data_HoH->{$time}->{ $names[$count] } = $values[$count];
            }
        }
        close(IN);
    }
    else
    {
        S_set_error( "could not read $filename", 1 );
        return $data_HoH_dummy;
    }

    return ($data_HoH);

}

=head2 DSO1_saveValues

    DSO1_saveValues( $file, $channelstr, $samples, $pic_mode );
    e.g. DSO1_saveValues("test1.txt", "C1+C2+C3+C4", 50000, 0);

Save signals in uniview format, save optional picture. Will save values as *.txt.unv. Any running aquisition will be stopped !!!

$file : full path to save file

$channelstr : which channels to be saved e.g. 'C1+C2+C3+C4' valid channels are { C1 | C2 | C3 | C4 | M1 | M2 | M3 | M4 | TA | TB | TC | TD }

$samples : how many samples to be saved (e.g. >1000000 for 1 Msample)

$pic_mode : 1-save screeen (*.png), 2-create graph from data (*.png), any other value - no picture

=cut

sub DSO1_saveValues
{
    my $file       = shift;
    my $channelstr = shift;
    my $samples    = shift;
    my $pic_mode   = shift;

    unless ( defined($pic_mode) )
    {
        S_set_error( "SYNTAX: DSO1_saveValues( file, channelstr, samples, pic_mode )", 110 );
        return;
    }
    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_saveValues: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }

    foreach my $channel ( split( /\+/, $channelstr ) )
    {
        unless ( exists $valid_Channels{$channel} )
        {
            S_set_error( "channel $channel is invalid", 114 );
            return 0;
        }
    }
    S_w2log( 4, "LIFT_DSO1: DSO1_saveValues($file,$channelstr,$samples,$pic_mode)\n" );

    if ($main::opt_offline)
    {
        $file =~ s/\.\w+$//;    # cut off file extension
        $file =~ s/\//\\/g;     # replace all slashes with backslashes
        S_create_dummy_file( $file . ".txt.unv" );
        S_create_dummy_pic( $file . ".png" );
        return 1;
    }

    $Status = $dso1->saveValues( $file, $channelstr, $samples, $pic_mode );
    Check_Status();

    S_w2log( 3, "LIFT_DSO1: DSO1_saveValues done \n" );

    return 1;
}

=head2 DSO1_saveScreen

    DSO1_saveScreen( $file );
    e.g. DSO1_saveScreen("test2.png");

Save screenshot picture from DSO, format is *.png

$file : full path to save file

=cut

sub DSO1_saveScreen
{
    my $file = shift;

    unless ( defined($file) )
    {
        S_set_error( "SYNTAX: DSO1_saveScreen( file )", 110 );
        return;
    }
    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_saveScreen: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_saveScreen($file)\n" );

    if ($main::opt_offline)
    {
        S_create_dummy_pic($file);
        return 1;
    }
    $Status = $dso1->saveScreen($file);
    Check_Status();
    S_w2log( 5, "Status of DSO savescreen is $Status \n" );

    S_w2log( 3, "LIFT_DSO1: DSO1_saveScreen done \n" );

    return 1;
}

=head2 DSO1_writeString

    DSO1_writeString( $string );
    e.g. DSO1_writeString("*IDN?");

write string directly to DSO

=cut

sub DSO1_writeString
{
    my $string = shift;

    unless ( defined($string) )
    {
        S_set_error( "SYNTAX: DSO1_writeString( string )", 110 );
        return;
    }

    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_writeString: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_writeString($string)\n" );

    return 1 if $main::opt_offline;

    $Status = $dso1->writeString($string);
    Check_Status();
    S_w2log( 5, "Status of DSO writeString is $Status \n" );

    S_w2log( 4, "LIFT_DSO1: DSO1_writeString done \n" );

    return 1;
}

=head2 DSO1_readString

    $string = DSO1_readString( );

read string directly from DSO

offline_return : 'dummy'

=cut

sub DSO1_readString
{
    my $string;

    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_readString: dso object is invalid. DSO1 was not initialized", 21 );
        return "";
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_readString \n" );

    return 'dummy' if $main::opt_offline;

    ( $Status, $string ) = $dso1->readString();
    Check_Status();
    S_w2log( 5, "Status of DSO readString is $Status \n" );
    S_w2log( 5, "LIFT_DSO1: Read string from DSO is $string \n" );

    return $string;
}

=head2 DSO1_setTdiv

    $value = DSO1_setTdiv( $time );
    e.g. $value = DSO1_setTdiv('10S');

set time per division.

valid values (depending on scope) are e.g.:
1NS 2NS 5NS 10NS 20NS 50NS 100NS 200NS 500NS
1US 2US 5US 10US 20US 50US 100US 200US 500US
1MS 2MS 5MS 10MS 20MS 50MS 100MS 200MS 500MS
1S 2S 5S 10S 20S 50S 100S 200S 500S

Returns current value for Time division

offline_return : 1

=cut

sub DSO1_setTdiv
{
    my $time = shift;
    my $result;

    unless ( defined($time) )
    {
        S_set_error( "SYNTAX: value = DSO1_setTdiv( time )", 110 );
        return;
    }

    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_setTdiv: dso object is invalid. DSO1 was not initialized", 21 );
        return $DSO_FAILED;
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_setTdiv($time)\n" );

    return 1 if $main::opt_offline;

    ( $Status, $result ) = $dso1->setTdiv($time);
    Check_Status();
    S_w2log( 5, "Status of DSO setTdiv is $Status \n" );
    S_w2log( 5, "LIFT_DSO1: DSO setTdiv  result is $result \n" );

    return ($result);
}

=head2 DSO1_setVdiv

    $value = DSO1_setVdiv( $channelstr, $volts );
    e.g. $value = DSO1_setVdiv('C1','5V');

set volts per division at given channel and returns current value (probably you have to divide by probe factor to get the required voltage)

valid values (depending on scope) are e.g.: 2MV 5MV 10MV 20MV 50MV 200MV 500MV 1V 2V 5V 10V

$channelstr : which channel to be set e.g. 'C1' valid channels are { C1 | C2 | C3 | C4 }

Returns current value for Voltage division

offline_return : 1

=cut

sub DSO1_setVdiv
{
    my $channel = shift;
    my $volts   = shift;
    my $result;

    unless ( defined($volts) )
    {
        S_set_error( "SYNTAX: value = DSO1_setVdiv( channel, volts )", 110 );
        return;
    }

    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_setVdiv: dso object is invalid. DSO1 was not initialized", 21 );
        return $DSO_FAILED;
    }

    unless ( $channel =~ /^C(\d)$/ )
    {
        S_set_error( "channel $channel is invalid", 114 );
        return 0;
    }
    $channel = $1;

    S_w2log( 4, "LIFT_DSO1: DSO1_setVdiv(C$channel,$volts)\n" );

    return 1 if $main::opt_offline;

    ( $Status, $result ) = $dso1->setVdiv( $channel, $volts );
    Check_Status();
    S_w2log( 5, "Status of DSO setVdiv is $Status \n" );
    S_w2log( 5, "LIFT_DSO1: DSO setVdiv  result is $result \n" );

    return ($result);
}

=head2 DSO1_setSamples

    DSO1_setSamples( $samples );
    e.g. DSO1_setSamples('250K');

set number of samples for recording

valid values (depending on scope) are e.g.: 500 1000 2500 5000 10K 25K 50K 100K 250K

=cut

sub DSO1_setSamples
{
    my $samples = shift;

    unless ( defined($samples) )
    {
        S_set_error( "SYNTAX: DSO1_setSamples( samples )", 110 );
        return;
    }

    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_setSamples: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_setSamples($samples)\n" );
    return 1 if $main::opt_offline;

    $Status = $dso1->setSamples($samples);
    Check_Status();
    S_w2log( 5, "Status of DSO setSamples is $Status \n" );

    return 1;
}

=head2 DSO1_setTriggermode

    DSO1_setTriggermode( $mode );
    e.g. DSO1_setTriggermode('SINGLE');

set trigger mode, valid values are: AUTO NORM SINGLE STOP

=cut

sub DSO1_setTriggermode
{
    my $mode = shift;

    unless ( defined($mode) )
    {
        S_set_error( "SYNTAX: DSO1_setTriggermode( mode )", 110 );
        return;
    }

    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_setTriggermode: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_setTriggermode($mode)\n" );
    return 1 if $main::opt_offline;

    $Status = $dso1->setTriggermode($mode);
    Check_Status();
    S_w2log( 5, "Status of DSO setTriggermode is $Status \n" );

    return 1;
}

=head2 DSO1_arm

    DSO1_arm( );

arm single trigger mode, only working after setTriggermode('SINGLE');

=cut

sub DSO1_arm
{
    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_arm: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }

    S_w2log( 4, "LIFT_DSO1: DSO1_arm \n" );
    return 1 if $main::opt_offline;
    $Status = $dso1->arm();
    Check_Status();
    S_w2log( 5, "Status of DSO arm is $Status \n" );

    return 1;
}

=head2 DSO1_saveConfig

    DSO1_saveConfig( $configfile );
    e.g. DSO1_saveConfig("DSO_SavedConfig.txt");

save panel settings to a config file.

=cut

sub DSO1_saveConfig
{
    my $configfile = shift;
    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_saveConfig: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }

    unless ( defined($configfile) )
    {
        S_set_error( "SYNTAX: DSO1_saveConfig( configfile )", 110 );
        return;
    }
    S_w2log( 4, "LIFT_DSO1: DSO1_saveConfig($configfile)\n" );

    if ($main::opt_offline)
    {
        S_create_dummy_file($configfile);
        return 1;
    }

    $Status = $dso1->saveConfig( $configfile, "created with LIFT_DSO1 $VERSION" );
    Check_Status();
    S_w2log( 5, "Status of DSO saveConfig is $Status \n" );

    return 1;
}

=head2 DSO1_restoreConfig

    DSO1_restoreConfig( $configfile );
    e.g. DSO1_restoreConfig("DSO_SavedConfig.txt");

restore panel settings from a config file.

=cut

sub DSO1_restoreConfig
{
    my $configfile = shift;
    unless ( defined($dso1) )
    {
        S_set_error( "DSO1_restoreConfig: dso object is invalid. DSO1 was not initialized", 21 );
        return;
    }
    unless ( defined($configfile) )
    {
        S_set_error( "SYNTAX: DSO1_restoreConfig( configfile )", 110 );
        return;
    }
    unless ( -f $configfile )
    {
        S_set_error( "configfile $configfile not found", 1 );
        return;
    }
    S_w2log( 4, "LIFT_DSO1: DSO1_restoreConfig($configfile)\n" );
    return 1 if $main::opt_offline;

    $Status = $dso1->restoreConfig($configfile);
    Check_Status();
    S_w2log( 5, "Status of DSO restoreConfig is $Status \n" );

    return 1;
}

############################################################################################################

=head1 not exported functions

=head2 Check_Status

    Check_Status(); not exported

if error occurred, log error string and set INCONC.

=cut

sub Check_Status
{

    return 1 if $main::opt_offline;

    if ( $Status < 0 )
    {
        $ErrorString = dso_getErrorString($Status);
        S_set_error( "DSO: $ErrorString", 5 );
    }

    return 1;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, activeDSO documentation, LeCroy manual.

=cut
