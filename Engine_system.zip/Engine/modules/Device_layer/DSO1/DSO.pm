package DSO;

# added logfile handling

use strict;
use warnings;
use Win32::OLE;
use GD::Graph::linespoints;
#use Image::Magick;


require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use DSO ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
    dso_getErrorString    
);

our ($VERSION,$HEADER);


#Error definitions for LeCroy Data Storage Oscilloscope(s)
my %Error_Hash = (
            0 => "no Error is success",
            -1 => "open File, access error",
            -2 => "Function parameters error",
            -3 => "DSO: Internal function calling error",
            -4 => "Not able to create dir",
            -5 => "DSO: Instance could not be created, please check ActiveDSO ",
            -6 => "DSO: Instance is not defined",
            -7 => "DSO: Connection Error, Device ID could not be read",
            -8 => "DSO: Connection Error, Device is already connected",
            -9 => "DSO: Disconnection error, device was not connected",
            -10 => "DSO: Connection Error, Device is not connected",
            -11 => "DSO: ActiveDSO call failed",
            -12 => "DSO: Internal function calling error, Function checkError has found an Error", 
            -13 => "DSO: Connection Failed (ActiveDSO call failed) ",
            -14 => "DSO: Parameter error, Parameter wrong",
            -15 => "DSO: ERROR String : not defined ****",
            -16 => "DSO: Connection fail, Parameter error, use following function call format: connect(\$connection); Example: \$dso->connect(\"GPIB:1\");",
            -17 => "DSO: saveValues: Parameter error, use following function call format: \$status = \$dso->saveValues(\$file,\$channelstr,\$samples,\$pic_mode); Example: saveValues(\"test1.txt\", \"C1+C2+C3+C4\", 1000000, 0);",
            -18 => "DSO: saveScreen: Parameter error, use following function call format: \$dso->saveScreen(\$file);, Example: saveScreen(\"test2.png\");",
            -19 => "DSO: writeString: Parameter error, use following function call format: \$dso->writeString(\$string); Example: WriteString(\"*IDN?\", 1)",
            -20 => "DSO: readString",
            -21 => "DSO: setTdiv: Parameter error, use following function call format: \$dso->setTdiv(\$time); Example: setTdiv(\"10S\");",
            -22 => "DSO: setVdiv: Parameter error, use following function call format: \$dso->setVdiv(\$channel,\$volts); Example:  setVdiv('C1',\"5V\");",
            -23 => "DSO: setSamples : Parameter error, use following function call format: \$dso->setSamples(\$samples); Example: setSamples(\"250K\") ",
            -24 => "DSO: setTriggermode : Parameter error, use following function call format: \$dso->setTriggermode(\$mode); Example: setTriggermode(\"SINGLE\") ",
            -25 => "DSO: restoreConfig : Parameter error, use following function call format: \$dso->restoreConfig(\$configfile); Example: restoreConfig(\"config.txt\");",
            -26 => "DSO: saveConfig : Parameter error, use following function call format: \$dso->saveConfig(\$configfile, [\$comment]); Example: saveConfig(\"config.txt\",\"some comment\");",
            );
my ($connection, $DSO_handle, $DeviceID, $DeviceModel,$logfile_handle);
my ($ErrorString, $ErrorCode);


=head1 NAME

DSO 

Perl extension for LeCroy Data Storage Oscilloscope(s)

=head1 SYNOPSIS

    use DSO;

    my ($dso, $error, $string, $value, $DeviceID);

    $dso = DSO->new(\*LOG);
    ($status , $DeviceID) = $dso->connect("GPIB:1");    
    $status = $dso->disconnect();    
    $value = $dso->isConnected();
    $status = $dso->saveValues("test1.txt", "C1+C2+C3+C4", 1000000, 0);
    $status = $dso->saveScreen("test2.png");
    $status = $dso->writeString("*IDN?");
    $error = $dso->checkError();
    ($status , $string) = $dso->readString();
    ($status, $value) = $dso->setTdiv('10S');
    ($status, $value) = $dso->setVdiv('C1','5V');
    $status = $dso->setTriggermode('SINGLE');
    $status = $dso->arm();
    $status = $dso->saveConfig("config.txt","some comment");
    $status = $dso->setSamples('250K');
    $status = $dso->restoreConfig("config.txt"); 


    $string = dso_getErrorString($ErrorCode);

=head1 DESCRIPTION

remote control functions for LeCroy scopes using ActiveDSO via OLE

B<NOTE: ActiveDSO, IrfanView (peacy 772), perl modules GD::Graph has to be installed (run_once) !>



=head1 DSO INDEPENDANT METHODS (exported)

=cut

############################################################################################################

=head2 $Response = dso_getErrorString($ErrorCode);

Function returns a string back, which resolves an error code. Error codes are < 0.

Returns 

        Response: Success: String with error definitions,       Error: empty.
        
Error Codes:

            0 => "no Error is success",
            -1 => "open File, access error",
            -2 => "Function parameters error",
            -3 => "DSO: Internal function calling error",
            -4 => "Not able to create dir",
            -5 => "DSO: Instance could not be created, please check ActiveDSO ",
            -6 => "DSO: Instance is not defined",
            -7 => "DSO: Connection Error, Device ID could not be read",
            -8 => "DSO: Connection Error, Device is allready connected",
            -9 => "DSO: Disconnection error, device was not connected",
            -10 => "DSO: Connection Error, Device is not connected",
            -11 => "DSO: ActiveDSO call failed",
            -12 => "DSO: Internal function calling error, Function checkError has found an Error", 
            -13 => "DSO: Connection Failed (ActiveDSO call failed) ",
            -14 => "DSO: Parameter error, Parameter wrong",
            -15 => "DSO: ERROR String : not defined ****",
            -16 => "DSO: Connection fail, Parameter error, use following function call format: connect(\$connection); Example: \$dso->connect(\"GPIB:1\");",
            -17 => "DSO: saveValues: Parameter error, use following function call format: \$status = \$dso->saveValues(\$file,\$channelstr,\$samples,\$pic_mode); Example: saveValues(\"test1.txt\", \"1+2+3+4\", 1000000, 0);",
            -18 => "DSO: saveScreen: Parameter error, use following function call format: \$dso->saveScreen(\$file);, Example: saveScreen(\"test2.png\");",
            -19 => "DSO: writeString: Parameter error, use following function call format: \$dso->writeString(\$string); Example: WriteString(\"*IDN?\", 1)",
            -20 => "DSO: readString",
            -21 => "DSO: setTdiv: Parameter error, use following function call format: \$dso->setTdiv(\$time); Example: setTdiv(\"10S\");",
            -22 => "DSO: setVdiv: Parameter error, use following function call format: \$dso->setVdiv(\$channel,\$volts); Example:  setVdiv(1,\"5V\");",
            -23 => "DSO: setSamples : Parameter error, use following function call format: \$dso->setSamples(\$samples); Example: setSamples(\"250K\") ",
            -24 => "DSO: setTriggermode : Parameter error, use following function call format: \$dso->setTriggermode(\$mode); Example: setTriggermode(\"SINGLE\") ",
            -25 => "DSO: restoreConfig : Parameter error, use following function call format: \$dso->restoreConfig(\$configfile); Example: restoreConfig(\"config.txt\");",
            -26 => "DSO: saveConfig : Parameter error, use following function call format: \$dso->saveConfig(\$configfile, [\$comment]); Example: saveConfig(\"config.txt\",\"some comment\");",

=cut

sub dso_getErrorString
{
    my $ErrorCode = shift;    
    my $Response;
    
    #parameter check
    unless(defined($ErrorCode))
    {           
        return "";
    }
    
    if(($ErrorCode < -26) || ($ErrorCode > 0 ))
    {   
        w2log("Error code out of range, (code not defined) \n"); 
        return ""; 
    }
    else 
    {   
       $Response = $Error_Hash{$ErrorCode};
       unless(defined($Response))
       {
        w2log("Error code is not valid, (code not defined) \n");
        return "";
       }
       else {
        return $Response;           
       }
    }    
}


=head1 CONSTRUCTOR

=head2 $dso = DSO->new(\*LOG);

creates an instance of a DSO object and returns its handle

writes into give logfile, if no filehandle is given log_DSOpm.txt is created.

Returns:

            dso:    success: handle of object,      Error: undef;    

=cut

sub new {
    my $class = shift;
    $logfile_handle=shift;
    
    unless ($logfile_handle) {
        open ( DSOLOG,">log_DSOpm.txt" ) or die "Couldn't open logfile : $@";
        $logfile_handle = \*DSOLOG;
    }
    
    my $self = {};
    bless ($self, $class);
    w2log("creating new DSO instance\n");
    $self->{OLE} = Win32::OLE -> new ('LeCroy.ActiveDSOCtrl.1');
    $self->{connected} = 0; # set connected flag to false
    
    #Error if OLE object is not created
    unless(defined($self->{OLE}) )
    {
        $ErrorCode = -5;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: new: $ErrorString \n");
        return undef;
    }
    else {
        w2log("DSO instance created \n");
        return $self;    
    }
}


=head1 METHODS

=head2 ($status , $DeviceID) = $dso->connect($connection);

Connnect to DSO via given connection, reads DeviceModel and identification (*IDN). 
This method has to be called first before any other method can be used.

Valid connections are e.g. 'GPIB:1' or 'IP:10.3.40.187' or 'COM1:115200,8,N,1'. 
Make sure Scope is configured accordingly !

Returns:
            
            1. Status:              Success: 0,                 Error: Error code < 0.
            
            2. DeviceID:            Success: Device ID,         Error: empty.

=cut

sub connect {
    my $self = shift;
    $connection = shift;

    $DSO_handle = $self->{OLE};

    #Check DSO Handle
    unless (defined ($DSO_handle) )
    {   
        $ErrorCode = -6;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: connect: $ErrorString \n");
        return ($ErrorCode,"");    
    }

    #Check parameter
    unless (defined ($connection) )
    {
        $ErrorCode = -16;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode,"");    
    }
    
    w2log("connecting with DSO via <$connection>\n");
    
    #device is allready connected
    if($self->{connected} == 1)
    {
        $ErrorCode = -8;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: connect: $ErrorString \n");
        return ($ErrorCode,""); 
    }
    
    if($DSO_handle -> MakeConnection ($connection))
    {        
        if ($DSO_handle -> SetRemoteLocal(1))
        {          
            $DeviceModel = $DSO_handle -> DeviceModel();
            $ErrorString = checkError($self);        
            unless($ErrorString eq "" )
            {
                $ErrorCode = -12;
                $ErrorString = dso_getErrorString($ErrorCode);
                w2log("**** ERROR: connect: $ErrorString \n");
                return ($ErrorCode,""); 
            }

            w2log("DeviceModel is <$DeviceModel>\n");

            if($DSO_handle -> WriteString("*IDN?", 1))
            {   
                $DeviceID = $DSO_handle -> ReadString(100);
                if($DeviceID eq "")
                {   
                    $ErrorCode = -7;
                    $ErrorString = dso_getErrorString($ErrorCode);
                    w2log("**** ERROR: connect, $ErrorString \n");
                    checkError($self);
                    
                    return ($ErrorCode,""); 
                }
                else {
                   
                    $DeviceID =~ s/^\*idn\s*//i;
                    w2log("Device is <$DeviceID>\n");
                    $self->{connected} = 1; # set connected flag to true
                    $self->{ID} = "{$DeviceID}";
                    w2log( "connected completed \n");
                    return(0, $DeviceID); 
                }
            }
            else {
                $ErrorCode = -13;
                $ErrorString = dso_getErrorString($ErrorCode);
                w2log("**** ERROR: connect, $ErrorString, WriteString(...) \n");
                checkError($self);
                
                return ($ErrorCode,"");
            }
        }
        else {
            $ErrorCode = -13;
            $ErrorString = dso_getErrorString($ErrorCode);
            w2log("**** ERROR: connect, $ErrorString, SetRemoteLocal(...) \n");
            checkError($self);
            
            return ($ErrorCode,"");
        }
    }
    else {
       $ErrorCode = -13;
       $ErrorString = dso_getErrorString($ErrorCode);
       w2log("**** ERROR: connect, $ErrorString, MakeConnection(...) \n");
       checkError($self);
       
       return ($ErrorCode,"");
    }
}



=head2 $status = $dso->disconnect();

Disconnect from DSO.

Returns: 

            status:  Success: 0,         Error: Error Code < 0. 

=cut

sub disconnect{
    my $self = shift;
    $DSO_handle = $self->{OLE};
        
    if($self->{connected} == 0)
    {
        $ErrorCode = -9;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: disconnect: $ErrorString \n");
        return $ErrorCode; 
    }
    
    w2log("disconnecting DSO $self->{ID}\n");
    
    if($DSO_handle -> SetRemoteLocal(0))
    {        
        if($DSO_handle -> Disconnect())
        {        
            undef $self->{ID};
            $self->{connected} = 0; # set connected flag to true
            w2log("disconnected \n");
            return 0;
        }
        else {
            $ErrorCode = -11;
            $ErrorString = dso_getErrorString($ErrorCode);
            w2log("**** ERROR: disconnect, $ErrorString, Disconnect() \n");
            checkError($self);
            return $ErrorCode;
        }
    }
    else {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: disconnect, $ErrorString, SetRemoteLocal(...) \n");
        checkError($self);
        return $ErrorCode;
    }
}


=head2 $value = $dso->isConnected();

check if DSO is connected.

Returns 

        value: 1 if true, 0 if false

=cut

sub isConnected{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    return($self->{connected});
}



=head2 $status = $dso->saveValues($file,$channelstr,$samples,$pic_mode);

Save signals in uniview format, save optional picture. Will save values as *.txt.unv. Any running aquisistion will be stopped. Write protected files will be overwriten.

$file : full path to save file.

$channelstr : which channels to be saved e.g. 'C1+C2+C3+C4' valid channels are { C1 | C2 | C3 | C4 | M1 | M2 | M3 | M4 | TA | TB | TC | TD }

$samples : how many samples to be saved. 
           LT344: this parameter must be high in order to receive all values (e.g. >1000000 for 1 Msample).
           WS434: error will be set if given number exeeds recorded samples

$pic_mode : 1-save screeen (*.bmp), 2-create graph from data (*.png), any other value - no picture

 NOTE: reduce sample point if you want to evaluate data with DSO1_get_values to avoid long loading time (several hours)
       voltage value will be cut after 5 decimal digits to save memory.

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut


sub saveValues{
    my $self = shift;
    $DSO_handle = $self->{OLE};

    my $file = shift;
    my $channelstr = shift;
    my $samples = shift;
    my $pic_mode = shift;
    my ($i, $k, $channel, $element, $graph, $current_time, @data, $wavearray);
    my (@legend, $DSOtdiv, $DSOsamples, $DSOstepwidth); 
    
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveValues, $ErrorString \n");
        return $ErrorCode; 
    }
    
    #check parameters
    unless ( defined ($pic_mode) )
    {
        $ErrorCode = -17;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }
        
    my @channels = split(/\+/,$channelstr);

    # replace e.g. C:\myhome\myfile.png with C:\myhome\myfile
    $file =~ s/\.\w+$//; # cut off file extension
    $file =~ s/\//\\/g; # replace all slashes with backslashes
    w2log("saveValues: saving DSO $self->{ID} values to $file\n");

    #stop running aquisition to read waveforms
    w2log("stopping aquisition to prevent errors while reading waveform\n");
    
    unless( $DSO_handle -> WriteString("STOP", 1) )
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveValues, $ErrorString \n");
        checkError($self);
        return $ErrorCode;
    }     
                
    # get timestamp for first two points of first channel to get timebase
    my $timewavearray;
    eval '$timewavearray = $DSO_handle -> GetScaledWaveformWithTimes($channels[0], 2, 0)';  
    if ($@){
        $ErrorCode = -12;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveValues, $ErrorString $@\n");
        return $ErrorCode; 
    }
    my $step = $$timewavearray[0][1] - $$timewavearray[0][0]; # 2e-009 is minimum 
    $DSOstepwidth = sprintf("%.9f",$step);
    w2log("time base = $DSOstepwidth sec/point\n");
     
    $k=1;
    foreach $channel (@channels){
        push(@legend,$channel);
        w2log("-> GetScaledWaveform($channel, $samples, 0)\n");        
        
        eval '$wavearray = $DSO_handle -> GetScaledWaveform($channel, $samples, 0)';  
        if ($@){
            $ErrorCode = -12;
            $ErrorString = dso_getErrorString($ErrorCode);
            w2log("**** ERROR: saveValues, $ErrorString $@\n");
            return $ErrorCode; 
        }
        
        $ErrorString =checkError($self);
        unless($ErrorString eq "" )
        {
            $ErrorCode = -12;
            $ErrorString = dso_getErrorString($ErrorCode);
            w2log("**** ERROR: saveValues, $ErrorString \n");
            return $ErrorCode; 
        }    
        
        foreach $element (@$wavearray){
            push (@{$data[$k]},sprintf("%7.5f",$element));
        }
        $k++;     
           
    }
    
    unless (@data){
        $ErrorCode = -12;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveValues, $ErrorString \n");
        return $ErrorCode; 
    }

    #delete file if existing
    unlink("$file.txt.unv");
           
    for ($i=0; $i<@{$data[1]}; $i++){
        push (@{$data[0]},$i*$DSOstepwidth);
    } #END for


   #output file for UNIVIEW
    if( open ( OUT,">$file".".txt.unv" ))
    {
        print OUT "TIME;";
        for ($i=0; $i<@legend; $i++){
            print OUT "$legend[$i];";
        }
        print OUT "\n";
        print OUT "s;";
        for ($i=0; $i<@legend; $i++){
            print OUT "volt;";
        }
        print OUT "\n";

        for ($k=0; $k<@{$data[0]}; $k++)
        {
            for ($i=0; $i<=@legend; $i++)
            {
                print OUT "$data[$i][$k];";
            }
            print OUT "\n";
        }
        close (OUT);
    }
    else {
        $ErrorCode = -1;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveValues: $ErrorString $file.txt.unv \n");
        return $ErrorCode;
    }
    
    w2log("creating PIC ");
    
    if ($pic_mode == 1)
    {
        if(saveScreen($self,$file)<0)
        {
            $ErrorCode = -3;
            $ErrorString = dso_getErrorString($ErrorCode);
            w2log("**** ERROR: saveValues, $ErrorString, saveScreen(...) \n");
            return $ErrorCode; 
        }
    }
    elsif ($pic_mode == 2)
    {
        #create graph
        $graph = GD::Graph::lines->new(640, 480);

          $graph->set( 
              x_label           => "time ",
              title             => 'waveform',
              x_tick_number     => 'auto',
              r_margin      => 10,
              l_margin      => 10,
              b_margin      => 10,
          );

        $graph->set_legend_font(GD::Font->Large);
        $graph->set_legend(@legend);

        if( open ( PIC,">$file.png" ) ) # or die "Couldn't open $_ : $@";
        {
            binmode PIC;
            print PIC $graph->plot(\@data)->png;
            close (PIC);
        }
        else {
            $ErrorCode = -1;
            $ErrorString = dso_getErrorString($ErrorCode);
            w2log("**** ERROR: saveValues: $ErrorString $file.png \n");
            return $ErrorCode;
        }
    }
    else {
        w2log("saveValues: No Pic created, Parameter was not 1 or 2 \n");
    } # create no pic  
    
    w2log("saveValues completed\n");
    
    return 0;
}


=head2 $status = $dso->saveScreen($file);

Save screenshot picture from DSO, format is *.png. Write protected files will be overwriten.

uses C:\Program Files\IrfanView\i_view32.exe to convert bmp to png

$file : full path to save file

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub saveScreen{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $file = shift;
    my $buf="";
    my $data="";
    my $count=0;

    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveScreen, $ErrorString \n");
        return $ErrorCode; 
    }
    
    unless (defined($file))
    {
        $ErrorCode = -18;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }
    
    
    # replace e.g. C:\myhome\myfile.bmp with C:\myhome\myfile
    $file =~ s/\.\w+$//; # cut off file extension
    $file =~ s/\//\\/g; # replace all slashes with backslashes
    
    w2log("saving DSO $self->{ID} screen to $file.bmp\n");
    
    #delete files if existing
    unlink("$file.bmp");
    unlink("$file.png");

    unless( $DSO_handle -> StoreHardcopyToFile("BMP", "", "$file.bmp"))
    {           
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveScreen, $ErrorString \n");
        checkError($self);
        return $ErrorCode;        
    }

    w2log("converting $file.bmp\n to $file.png\n");   
    
    #check if "file.bmp" exists
    unless (-f $file.".bmp")
    {
        $ErrorCode = -1;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveScreen, $ErrorString \n");
        return $ErrorCode;
    } 
              
    # fix for Win7: eval(system('"C:\Program Files\IrfanView\i_view32.exe" '.$file.'.bmp /convert='.$file.'.png')); 
       
    if (-e 'C:\Program Files (x86)\IrfanView\i_view32.exe'){
        system('"C:\Program Files (x86)\IrfanView\i_view32.exe" '.$file.'.bmp /convert='.$file.'.png'); # open in Firefox Win7 
    }
    elsif (-e 'C:\Program Files\IrfanView\i_view32.exe'){
        system('"C:\Program Files\IrfanView\i_view32.exe" '.$file.'.bmp /convert='.$file.'.png'); # open in Firefox
    }
    else{
        w2log( 5, " could not open IrfanView to convert picture\n"); 
    }
   
   if (-e $file.'.png'){
	    w2log("deleting temporary file $file.bmp\n");
	    unlink("$file.bmp");
   }
   
    return 0;
}



=head2 $status = $dso->writeString($string);

write string directly to DSO

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub writeString{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $string = shift;
    
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: writeString, $ErrorString \n");
        return $ErrorCode; 
    }
    
    #check parameters
    unless ( defined ($string) )
    {
        $ErrorCode = -19;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }
    
    w2log("writing <$string> to DSO $self->{ID}\n");
           
    unless ($DSO_handle -> WriteString($string, 1))
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: writeString, $ErrorString \n");
        return $ErrorCode;
    }
    return 0;
}



=head2 ($status , $string) = $dso->readString();

read string directly from DSO

Returns             
            
           1. status:         Success: 0.                     Error: Error Code < 0
           
           2. string:         Success: readed string,         Error: empty.

=cut

sub readString{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $string;

    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: readString, $ErrorString \n");
        return ($ErrorCode,""); 
    }
    
    $string = $DSO_handle -> ReadString(100);    
    if($string eq "") 
    {   
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: readString, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,"");    
    }    
    
    w2log("reading <$string> from DSO $self->{ID}\n");
    return(0,$string);
}




=head2 ($status, $value) = $dso->setTdiv($time);

set time per division.

valid values (depending on scope) are e.g.:

 500PS (min WS434)
 1NS (min LT344),   2NS, 5NS, 10NS, 20NS, 50NS, 100NS, 200NS, 500NS,  
 1US,   2US, 5US, 10US, 20US, 50US, 100US, 200US, 500US,  
 1MS,   2MS, 5MS, 10MS, 20MS, 50MS, 100MS, 200MS, 500MS, 
 1S,    2S,  5S,  10S,  20S,  50S,  100S,  200S,  500S, 
 1000S(Max).

Returns             

            1. status:        Success: 0                        Error: Error code < 0
            
            2. value:         Success: current value            Error: -1 

=cut

sub setTdiv{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $value = shift;
    my $result,    
    my $Number;
    my $String;
          
        
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTdiv, $ErrorString \n");
        return ($ErrorCode,-1); 
    }
    
    #check parameters
    unless ( defined ($value) )
    {
        $ErrorCode = -21;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode,-1);
    }
    
    w2log("setting T/div for DSO $self->{ID} to $value\n");  
    
    unless ($DSO_handle -> WriteString("TDIV $value", 1))
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1); 
    }
    
    unless ($DSO_handle -> WriteString("TDIV?", 1))
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1);  
    }
    
    $result = $DSO_handle -> ReadString(100);    
    if ($result eq "")
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1);  
    }
          
    $result =~ s/^TDIV\s*//i; # drop leading TDIV
    $result =~ s/\s*S$//i; # drop trailing S, result is now a number
    
    #convert given value to number
    $value =~ /(\d+)([PNUMS]+)$/; # match NS
    $Number = $1;
    $String = $2;    
    if ($String eq "PS"){
        $Number = $Number / 1000000000000;
    }elsif ($String eq "NS"){
        $Number = $Number / 1000000000;
    }elsif ($String eq "US"){
        $Number = $Number / 1000000;
    }elsif ($String eq "MS"){
        $Number = $Number / 1000;
    }elsif ($String eq "S"){
    }else{w2log("error, unknown unit $String");}

 
    #compare given value with read value
    if($result == $Number)
    {
        w2log("Tdiv was set to $result S\n");
        return(0, $result);    
    }
    else {
        w2log("Tdiv is <$result> instead of $value\n");
        $ErrorCode = -14;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1);  
    }
}



=head2 ($status, $value )= $dso->setVdiv($channel,$volts);

set volts per division at given channel and returns current value (probably you have to divide by probe factor to get the required voltage)

valid values (depending on scope) are e.g.: 

1MV(min WS434), 2MV(min LT344), 5MV, 10MV, 20MV, 50MV, 200MV, 500MV, 1V, 2V, 5V, 10V(max).

$channel is the number of the channel e.g. '2'

Returns             

            1. status:        Success: 0                                    Error: Error code < 0
            
            2. value:         Success: current value                        Error: -1 

=cut

sub setVdiv{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $channel = shift;
    my $value = shift;
    my $result;
    my $Number;
    my $String;
    my $Help;

    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setVdiv, $ErrorString \n");
        return ($ErrorCode,-1); 
    }
    
    #check parameters
    unless ( defined ($value) )
    {
        $ErrorCode = -22;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return ($ErrorCode,-1);
    }
    
    w2log("setting V/div for DSO $self->{ID} on $channel to $value\n");
    
    unless ($DSO_handle -> WriteString("C$channel:VDIV $value", 1) )
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setVdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1);   
    }
        
    unless ($DSO_handle -> WriteString("C$channel:VDIV?", 1) )
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setVdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1);  
    }
    
    $result = $DSO_handle -> ReadString(100);
    if ($result eq "")
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setVdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1);  
    }
    
    #convert Help to xxxE-y
#    $result =~ /^(\w*):?\s*(VDIV)?\s*(\S+)\s*V?$/;
    $result =~ /(\S+)\s*V?$/;
    $Help= $1;          
    w2log("got <$result> <$value>\n");
    
    #convert given value
    $value =~ /([\d.+-Ee]+)(M?V?)$/; # match 2E-3 MV
    $Number = $1;  #value
    $String = $2;  #unit  
    w2log("got <$Number> <$String>\n");
    if($String eq "MV")
    {        
        $Number = $Number / 1000;
    }

    #compare given value with read value
    if($Help == $Number)
    {
        w2log("Vdiv was set to $result\n");
        return(0, $result);    
    }
    else {
        w2log("Vdiv is '$Help'<$result> instead of $value\n");
        $ErrorCode = -14;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setVdiv, $ErrorString \n");
        checkError($self);
        return ($ErrorCode,-1);  
    }
}


=head2 $status = $dso->setSamples($samples);

set samples for recording

valid values (depending on scope) are e.g.: 

 LT344: 500 1000 2500 5000 10K 25K 50K 100K 250K
 WS434: 10K 250K 2000K


Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setSamples{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $value = shift;
    my $DSOsamples;
    my $Help;
    my $Kilo;
    
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setSamples, $ErrorString \n");
        return $ErrorCode; 
    }
    
    #check parameters
    unless ( defined ($value) )
    {
        $ErrorCode = -23;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }
    
    w2log("setting samples for DSO $self->{ID} to $value\n");
    
    unless ( $DSO_handle -> WriteString("MSIZ $value", 1) )
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setSamples, $ErrorString \n");
        checkError($self);
        return $ErrorCode;   
    }
    
    unless( $DSO_handle -> WriteString("MSIZ?", 1))
    {   
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setSamples, $ErrorString \n");
        checkError($self);
        return $ErrorCode;
    }
        
    $DSOsamples = $DSO_handle -> ReadString(100);
    if($DSOsamples eq "")
    {   
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setSamples, $ErrorString \n");
        checkError($self);
        return $ErrorCode;    
    }
    
    #extract Sample value from String 
    $DSOsamples =~ s/^MSIZ\s*//i; # drop leading MSIZ
    $Help= $DSOsamples;
    
    if ($Help =~ s/K$//i) 
    {
        $Help*=1000; #if kilo, cut off K and multiply with 1000
    }
    
    if ($value =~ s/K$//i) 
    {
        $value*=1000; #if kilo, cut off K and multiply with 1000
    } 
    
    #compare inserted value with readed value
    if($value == $Help)
    {
        w2log("samples was set to $DSOsamples \n");
        return 0;
    }
    else {
        w2log("samples was set to <$DSOsamples> instead of $value\n");
        $ErrorCode = -14;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setSamples, $ErrorString \n");
        checkError($self);
        return $ErrorCode; 
    }     
}


=head2 $status = $dso->setTriggermode($mode);

set trigger mode, valid values are: 

AUTO, NORM, SINGLE, STOP

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub setTriggermode{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $mode = shift;
    my $DSOTrigger;
    my $Help;
    
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTriggermode, $ErrorString \n");
        return $ErrorCode; 
    }
    
    #check parameters
    unless ( defined ($mode) )
    {
        $ErrorCode = -24;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }
    
    w2log("setting trigger mode for DSO $self->{ID} to $mode\n");
    
    unless ($DSO_handle -> WriteString("TRMD $mode", 1) )
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTriggermode, $ErrorString \n");
        checkError($self);
        return $ErrorCode;   
    }
   
    unless ($DSO_handle -> WriteString("TRMD?", 1) )
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTriggermode, $ErrorString \n");
        checkError($self);
        return $ErrorCode;   
    }
    $DSOTrigger = $DSO_handle -> ReadString(100);
    if($DSOTrigger eq "")
    {   
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTriggermode, $ErrorString \n");
        checkError($self);
        return $ErrorCode;    
    }
    $DSOTrigger =~ /(TRMD)?\s*(\S+)$/;  
    $Help= $2;
    if($mode eq $Help)
    {
        w2log("Trigger Mode was set to $DSOTrigger \n");
        return 0;
    }
    else {
        w2log("Trigger Mode is <$DSOTrigger> instead of $mode\n");
        $ErrorCode = -14;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: setTriggermode, $ErrorString \n");
        return $ErrorCode;
    }
}


=head2 $status = $dso->arm();

arm single trigger mode, 
changes trigger mode from stop to single

 LT344: only working after setTriggermode('SINGLE') or setTriggermode('STOP') ;
 WS434: always working.

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub arm{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $DSOTrigger;
    my $Help;
    
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: arm, $ErrorString \n");
        return $ErrorCode; 
    }
    
    w2log("arm for DSO $self->{ID} single trigger\n");
    
    unless ( $DSO_handle -> WriteString("ARM", 1) )
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: arm, $ErrorString \n");
        checkError($self);
        return $ErrorCode;   
    }
     
    
     unless ($DSO_handle -> WriteString("TRMD?", 1) )
    {        
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: arm, $ErrorString \n");
        checkError($self);
        return $ErrorCode;   
    }
    $DSOTrigger = $DSO_handle -> ReadString(100);
    if($DSOTrigger eq "")
    {   
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: arm, $ErrorString \n");
        checkError($self);
        return $ErrorCode;    
    }
    
    #$DSOTrigger =~ /(.+)\s(.+)$/;  
    $DSOTrigger =~ /(TRMD)?\s*(\S+)$/;  
    $Help= $2;
    if("SINGLE" eq $Help)
    {
        w2log("ARM:  Trigger Mode was set to $DSOTrigger  \n");
        return 0;
    }
    else {
        $ErrorCode = -3;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: arm, $ErrorString \n");
        return $ErrorCode;
    }   
}


=head2 $status = $dso->restoreConfig($configfile);

restore panel settings from a config file.

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub restoreConfig{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $setup = shift;
    my (@PanelSettings,$ConfigModel,$Comment,$serialNumber);
    
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: restoreConfig: $ErrorString \n");
        return $ErrorCode; 
    }
    
    unless (defined($setup))
    {
        $ErrorCode = -25;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }    
    
    unless (-f $setup)
    {
        $ErrorCode = -1;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: restoreConfig, $ErrorString \n");
        return $ErrorCode;
    } 
    else {
        if (open ( IN,"<$setup" ) ) 
        {   
            $ConfigModel=<IN>;
            $Comment=<IN>;
            $serialNumber=<IN>;
            #remaining file contains panel settings, either binary or VBScript, depending on device
            @PanelSettings=<IN>;
            close(IN);
        }
        else {
           $ErrorCode = -1;
            $ErrorString = dso_getErrorString($ErrorCode);
            w2log("**** ERROR: restoreConfig, $ErrorString: $@ \n");
            return $ErrorCode; 
        }
    }        
    
    chomp($ConfigModel);
    #chomp($Comment);
    $ConfigModel =~ s/^DeviceModel=//; #cut off tag
    #$Comment =~ s/^Comment=//; #cut off tag


    w2log("restore panel settings from <".$setup.">\n");
        
    unless( $DSO_handle ->SetPanel(join('',@PanelSettings)))
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: restoreConfig, $ErrorString \n");
        checkError($self);
        return $ErrorCode; 
    }        

    if ($DeviceModel ne $ConfigModel)
    {
        w2log("warning: current device is <$DeviceModel> config created with <$ConfigModel>\n");
    }
    else{
        w2log("panel settings restored\n");
    }
    
    return 0;
}




=head2 $status = $dso->saveConfig($configfile, [$comment]);

save panel settings to a config file. Write protected file will be overwriten.

Returns 

            status:     Success : 0,        Error: Error code < 0.

=cut

sub saveConfig{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my $filename = shift;
    my $Comment = shift;
    
    #Check Connection
    if($self->{connected} == 0)
    {
        $ErrorCode = -10;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveConfig: $ErrorString \n");
        return $ErrorCode; 
    }
    
    unless (defined($filename))
    {
        $ErrorCode = -26;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: $ErrorString \n");
        return $ErrorCode;
    }
    
    
    $Comment="" unless (defined $Comment);

    my ($PanelSettings, $DeviceModel, $SerialNumber);
    
    w2log("Saving panel settings to  $filename \n");
    
    $PanelSettings = $DSO_handle ->GetPanel();
    unless ($PanelSettings )
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveConfig, $ErrorString \n");    
        checkError();
        return $ErrorCode;
    }
    
    $DeviceModel = $DSO_handle -> DeviceModel();
    unless ($DeviceModel )
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveConfig, $ErrorString \n");    
        checkError();
        return $ErrorCode;
    }
    $SerialNumber = $DSO_handle -> SerialNumber();
    unless ($SerialNumber )
    {
        $ErrorCode = -11;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveConfig, $ErrorString \n");    
        checkError();
        return $ErrorCode;
    }

    #delete file if existing
    unlink("$filename");
    
    if (open ( OUT,">$filename" ) )
    {
        print OUT "DeviceModel=".$DeviceModel."\n";
        print OUT "Comment=".$Comment."\n";
        print OUT "SerialNumber=".$SerialNumber."\n";
        print OUT $PanelSettings;
        close(OUT);
    }
    else {
        $ErrorCode = -1;
        $ErrorString = dso_getErrorString($ErrorCode);
        w2log("**** ERROR: saveConfig, $ErrorString \n");
        return $ErrorCode;
    }
    w2log("panel settings saved to $filename: $@\n");
    
    return 0;
}



=head2 $error = $dso->checkError();

read error buffer. 

Returns:

            error: String, wich define an Error,        empty string for no error found.

=cut

sub checkError{
    my $self = shift;
    $DSO_handle = $self->{OLE};
    my ($ErrorFlag, $LocErrorString);
    $ErrorFlag = $DSO_handle -> ErrorFlag();
    $LocErrorString = $DSO_handle -> ErrorString();
    
    if($ErrorFlag)
    {
        w2log("!error: $LocErrorString\n");
        return $ErrorString;
    }
    else {
        return('');
    }
}


##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print $logfile_handle $text;
     print $text;
}


# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, activeDSO documentation, LeCroy manual.

=cut
