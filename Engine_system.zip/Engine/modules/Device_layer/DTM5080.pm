package DTM5080;

use strict;
use warnings;

use Win32::SerialPort;
use LIFT_general;
require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  dtm_get_temperature
  dtm_get_info
  dtm_get_error
  dtm_transmit
  dtm_init
);

our ( $VERSION, $HEADER );

my ( $stat, $ret );
my $error_text = "";

############################################################################################################

=head1 NAME

DTM5080 

Perl extension for DTM5080 temperature sensor

=head1 SYNOPSIS

    use DTM5080;

    $port = dtm_init();

    ($stat,$temperature) = dtm_get_temperature($port);

=head1 DESCRIPTION

Control module for DTM5080 temperature sensor via serial (COM port) connection

=head2 Testbench Configuration

=head3 Devices section:

    'Devices' => {
        ...
        'DTM5080' => {
            'connect' => 'COM6',
        },
        ...
    },

=cut

############################################################################################################
######### advanced functions ##########

=head1 ADVANCED METHODS

=head2 dtm_get_temperature

    ($stat,$temperature) = dtm_get_temperature($port);

    e.g. (0, 25.43) = dtm_get_temperature(1);
    
    reads current temperature and return in degree Celsius
    
    A warning "Get temperature from DTM5080 failed" is thrown when temperature -1000 is logged in the following scenarios.
    
    1) When a wrong COM-number is specified in the Testbench
    
    2) When the communication with DTM5080 temperature sensor fails sporadically 
    

=cut

sub dtm_get_temperature {
    my $port = shift;
    ( $stat, $ret ) = dtm_transmit( $port, "D" );
    if ( $stat < 0 ) {
        #CALL dtm_get_temperature
        #IF Is Status negative?
        #IF-YES-START
        #STEP Throw warning message: "Get temperature from DTM5080 failed" when temperature -1000 is logged
        S_set_warning("Get temperature from DTM5080 failed\n");
        return ( $stat, -1000 );
        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END
    if ( $ret !~ /^[0-9+-]+$/i ) {

        #IF Is Status not a digit?
        #IF-YES-START
        #STEP Throw warning message: "Get temperature from DTM5080 failed" when temperature -1000 is logged
        S_set_warning("Get temperature from DTM5080 failed: dtm_get_temperature returned an invalid number: $ret\n");
        return ( -1, -1000 );
        #IF-YES-END
    }
    #IF-NO-START
    #IF-NO-END
    #STEP END
    if   ( $ret == 0 ) { $ret = 0; }
    else               { $ret = $ret / 100; }
    S_w2log( 4, "DTM5080: Current Temperature: $ret\n" );
    return ( $stat, $ret );
}

=head2 dtm_init

  $port = dtm_init();
  
  To get the port number from TestBench Configuration
  
  Succes Return : Port Number
  
  Error Return 1
  
=cut

sub dtm_init {
    my $port;
    unless ( $port = S_get_contents_of_hash( [ 'Devices', 'DTM5080', 'connect' ], $LIFT_config::LIFT_Testbench ) ) {
        S_set_error( "No DTM5080 connection configured in testbench config\n", 20 );
        return 1;
    }
    $port =~ s/com//i;    # drop COM string
    unless ( $port =~ /^\d+$/ ) {
        S_set_error( "COM port number $port is not a number", 109 );
        $port = undef;
        return 1;
    }
    return $port;
}

=head2 dtm_get_info

    ($stat,$SN,$type,$RES) = dtm_get_info($port);

    e.g. (0, '00052', '5080', 4.2) = dtm_get_info(1);

read serial number, type and resolution

=cut

sub dtm_get_info {
    my ( $SN, $type, $RES );
    my $port = shift;
    S_w2log( 4, "DTM5080: Reading information of serial number, type and resolution \n" );
    ( $stat, $SN ) = dtm_transmit( $port, "L" );
    if ( $stat < 0 ) { return ( $stat, 'error', 'error', 'error' ); }
    ( $stat, $type ) = dtm_transmit( $port, "T" );
    if ( $stat < 0 ) { return ( $stat, 'error', 'error', 'error' ); }
    ( $stat, $RES ) = dtm_transmit( $port, "A" );
    if ( $stat < 0 ) { return ( $stat, 'error', 'error', 'error' ); }
    S_w2log( 3, "DTM5080: serial number => $SN, type => $type and resolution => $RES \n" );
    return ( $stat, $SN, $type, $RES );
}

=head2 dtm_get_error

    $errortext = dtm_get_error();

return last error and clear error

=cut

sub dtm_get_error {

    $ret        = $error_text;
    $error_text = "";
    return ($ret);
}

############################################################################################################

################ advanced functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################

=head2 dtm_transmit

    ($stat,$ret) = dtm_transmit($port,$data);

    e.g. (0,'00052')=dtm_transmit(1,"L");

    each communication takes about 0.5 sec due to re-initialisation of COM port for long term stability

Transmits the string $data on the COM port. IMPORTANT: this function attaches \r\n to $data, therefore $data must not contain linebreak.

returns status and return value as single string, where ':' is deleted

=cut

sub dtm_transmit {
    my $port = shift;
    my $data = shift;
    my $received;

    #open and close COM port for each communication due to stability
    S_w2log( 4, "DTM5080: connecting to $port\n" );
    my $COM = new Win32::SerialPort("COM$port");
    unless ($COM) { Set_error("Can't open COM$port: $!"); return ( -1, 'error' ); }

    #CONFIG FROM TESTPROG:
    #OpenComConfig (Comport, Comname, 9600, 0, 8, 1, 512, 512);
    #SetCTSMode    (Comport, LWRS_HWHANDSHAKE_OFF);
    #SetXMode      (Comport, 1);
    #SetComTime    (Comport, 0.2);
    #dcb.XonChar =  0x08;
    #dcb.XoffChar = 0x10;

    # setting up all parameters for COM ports
    $COM->error_msg(1);
    $COM->user_msg(1);
    $COM->baudrate(9600);
    $COM->parity('none');
    $COM->databits(8);
    $COM->stopbits(1);
    $COM->read_const_time(5000);    # total = (avg * bytes) + const => total timeout 5 sec
    $COM->read_interval(200);       # timeout between chars 0.2 sec
    $COM->handshake('xoff');
    $COM->binary('T');
    $COM->pulse_dtr_on(500);        # DTR and DTS are used to power sensor
    $COM->parity_enable('F');
    $COM->xon_char(0x08);
    $COM->xoff_char(0x10);
    $COM->buffers( 512, 512 );
    $stat = $COM->write_settings();
    unless ($stat) { Set_error("Error when configuring COM$port port"); return ( -1, 'error' ); }

    Wait_ms(400);
    $COM->lookclear;                # empty buffers

    $received = '';
    my $retrycount = 0;
    do {
        $retrycount++;
        my $count = $COM->write( $data . "\r\n" );
        unless ($count) {
            Set_error("write COM failed");
            return ( -1, 'error' );
        }
        if ( $count != length($data) + 2 ) {
            Set_error("write COM incomplete");
            return ( -1, 'error' );
        }

        #    print"Tx: $data ($count)\n";
        ( $count, $received ) = $COM->read(10);

        #    print"Rx: $received ($count)\n";
    } while ( $received !~ m/:$/ and $retrycount < 4 );

    unless ( $received =~ s/:// ) {
        Set_error("receive timeout!");
        return ( -1, 'error' );
    }

    $received =~ s/\r//g;    # drop all <Lf>

    #print"ret: >$received<\n";

    $stat = $COM->close;
    S_w2log( 4, "DTM5080: disconnecting to COM$port\n" );
    unless ($stat) { Set_error("Can't close COM$port: $!"); return ( -1, 'error' ); }

    undef $COM;
    Wait_ms(100);            # important for long term stability

    return ( 0, $received );

}

sub Set_error {
    $error_text = shift;
    print "!!!: $error_text\n";
    return 1;
}

sub Wait_ms {
    my $time = shift;
    if ( $time > 0 ) { $time = $time / 1000; }
    select( undef, undef, undef, $time );    #sleep for X ms
    return 1;
}

1;

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, DTM5080 manual.

=cut

