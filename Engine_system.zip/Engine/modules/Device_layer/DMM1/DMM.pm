package DMM;

use strict;
use warnings;
use File::Basename;

# need to add in calling module
#BEGIN
#{
#    # add directories to search path for perl modules
#    unshift @INC, dirname( $0 )."/modules/GPIB";
#    unshift @INC, dirname( $0 )."/modules/GPIB/GPIB";
#}

use GPIB;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use DMM34401A ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
        dmm_checkError
        dmm_connect
        dmm_current_snapshot
        dmm_disconnect
        dmm_isConnected
		dmm_new
        dmm_readString
		dmm_resistance_snapshot
        dmm_voltage_snapshot
		dmm_writeString
);

our ($VERSION,$HEADER);


=head1 NAME

DMM 

Perl extension for Agilent 34401A multimeter(s) (no OO)

=head1 SYNOPSIS

    use DMM;

    my ($dmm, $voltage, $current, $resistance, $status);

    $dmm = 1;
    $status = dmm_new($dmm);
    ($status,$DeviceID) = dmm_connect('GPIB:9',$dmm);

    ($status,$voltage) = dmm_voltage_snapshot(10,$dmm);
    ($status,$current) = dmm_current_snapshot(10,$dmm);
    ($status,$resistance) = dmm_resistance_snapshot(2,100,$dmm);
    ($status,$resistance) = dmm_resistance_snapshot(4,100,$dmm);

    $status = dmm_disconnect($dmm);


=head1 DESCRIPTION

remote control functions for Agilent 34401A multimeter using GPIB.pm

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut


=head1 CONSTRUCTOR

=head2 $status = dmm_new( [$DMMnumber] );

$DMMnumber number of DMM, default is 0

creates internally a DMM object

writes into give logfile, if no filehandle is given log_DMM34401Apm.txt is created, 

=cut


my (@DMM_handle,@DMM_connected,@DeviceID, @DeviceModel,@IDN,@Firmware);
my $logfile_handle;


sub dmm_new {
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    open ( PPSLOG,">log_DMM34401Apm.txt" ) or die "Couldn't open logfile : $@";
    $logfile_handle = \*PPSLOG;

    w2log("creating new DMM34401A instance\n");
    $DMM_connected[$DMMnumber] = 0; # set connencted flag to false
    return 0;
}


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


############################################################################################################

=head2 ($status,$DeviceID) = dmm_connect($connection [, $DMMnumber]);

$DMMnumber number of DMM, default is 0

Connnect to DMM via given connection, reads device identification (*IDN). This method has to be called first before any other method can be used.   

A valid connection is e.g. 'GPIB:3'. Make sure wiring is configured accordingly !

=cut

sub dmm_connect {

    my $ret;
    my $connection = shift;
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    w2log("connecting with DMM34401A via <$connection>\n");

    if($connection =~ /GPIB:\s*(\d+)/i){
        $DMM_handle[$DMMnumber] = GPIB->new("GPIB::ni", 0, $1, 0, GPIB->T300ms, 1, 0);   
        wait_ms(10);
        dmm_writeString("SYST:BEEP:STAT OFF",$DMMnumber);
        wait_ms(10);
        dmm_writeString("*IDN?",$DMMnumber);
        wait_ms(10);
        $IDN[$DMMnumber] = dmm_readString($DMMnumber);
        chomp($IDN[$DMMnumber]);
        w2log("Device IDN answer is <$IDN[$DMMnumber]>\n");      
        (undef,$DeviceModel[$DMMnumber],undef,$Firmware[$DMMnumber]) =split(/,/,$IDN[$DMMnumber]);
   
   #@DeviceID, @DeviceModel,@IDN,@Firmware
        wait_ms(10);
	    dmm_writeString("CAL:STR?",$DMMnumber);
        wait_ms(10);
	    my $temp = dmm_readString($DMMnumber);
	    if ($temp =~ m/SN:(\S+)/){
            $DeviceID[$DMMnumber]=$1;
	    }
	    else{$DeviceID[$DMMnumber] = "unknown"}
	    
        w2log("DeviceID is <$DeviceID[$DMMnumber]> with Firmware <$Firmware[$DMMnumber]> on Device <$DeviceModel[$DMMnumber]>\n");
        
        wait_ms(10);
        dmm_writeString("STAT:QUES:ENAB 515",$DMMnumber);
        wait_ms(10);
        dmm_writeString("*CLS",$DMMnumber);
        wait_ms(10);

#        $DMM_handle -> ibwrt("SYST:VERS?");

        $DMM_connected[$DMMnumber] = 1; # set connencted flag to true
        return(0,$DeviceID[$DMMnumber]);

    }
    else{
      w2log("ERROR: connection error for DMM34401A on <$connection>\n");
      $DMM_connected[$DMMnumber] = 0; # set connencted flag to false
      return(-1,"unknown");
    }

}




############################################################################################################

=head2 $status = dmm_disconnect( [$DMMnumber] );

$DMMnumber number of DMM, default is 0

Disconnect from DMM

=cut

sub dmm_disconnect{
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    w2log("disconnecting DMM34401A $DMMnumber\n");
    $DMM_connected[$DMMnumber] = 0; # set connencted flag to false
    return 0;

}




############################################################################################################

=head2 $value = dmm_checkError( [$DMMnumber] ); TBD

$DMMnumber number of DMM, default is 0

read error status (*ESR?,ERR?) and report error if there is one

=cut

sub dmm_checkError{

    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    my ($ESRresp, $ERRresp);

#        $DMM_handle -> ibwrt("SYST:ERR?");

    $DMM_handle[$DMMnumber]->ibwrt('*ESR?');             
    $ESRresp = dmm_readString($DMMnumber);           # Read result
    unless (defined($ESRresp) ){
        w2log("?retry status check\n");
        $DMM_handle[$DMMnumber]->ibwrt('*ESR?');             
        $ESRresp = dmm_readString($DMMnumber);           # Read result
        unless (defined($ESRresp) ){
            w2log("!comminication error: no staus received\n");
            return;
        }
    }
    chomp($ESRresp);
    if ($ESRresp > 0){
        $DMM_handle[$DMMnumber]->ibwrt('ERR?');             
        $ERRresp = dmm_readString($DMMnumber);           # Read result
        chomp($ERRresp);
        if ($ERRresp !~ /^0,/) {
            w2log("!error: ESR is $ESRresp, ERR is $ERRresp\n");
        }
    }  
}





############################################################################################################

=head2 dmm_voltage_snapshot

    ($status,$voltage) = dmm_voltage_snapshot( [$range, $DMMnumber] );

    $range = measurement range in Volts, default is "AUTO"
	$DMMnumber = number of DMM, default is 0

Measure voltage directly. will return OVERLOAD on overload, ERROR on other error

GPIB commands: MEAS:VOLT:DC?

=cut

sub dmm_voltage_snapshot{
    my $range=shift;
    $range = '' unless(defined($range) );
    $range = '' if (uc($range) eq 'AUTO');
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    my $voltage;

    dmm_writeString("MEAS:VOLT:DC? $range;*OPC?",$DMMnumber);
    $voltage = dmm_readString($DMMnumber);
    if ($voltage =~ s/;1$//){
        w2log("voltage_snapshot: $voltage V\n");
        return (0,$voltage);
    }
    else{
        my $ret;
        dmm_writeString("STAT:QUES:EVEN?",$DMMnumber);
        wait_ms(10);
        (undef,$ret) = dmm_readString($DMMnumber);

        if ($ret == 1){
            w2log("voltage_snapshot: OVERLOAD ($ret)\n");
            $voltage = 'OVERLOAD';
        }
        else{
            w2log("voltage_snapshot: ERROR ($ret)\n");
            $voltage = 'ERROR';
        }

        dmm_writeString("*CLS",$DMMnumber);
        return (-1,$voltage);
    }

}


############################################################################################################

=head2 dmm_current_snapshot

    ($status,$current) = dmm_current_snapshot( [$range, $DMMnumber] );

    $range = measurement range in Amperes, default is "AUTO"
	$DMMnumber = number of DMM, default is 0

Measure current directly. will return OVERLOAD on overload, ERROR on other error

GPIB commands: MEAS:CURR:DC?

=cut

sub dmm_current_snapshot{
    my $range=shift;
    $range = '' unless(defined($range) );
    $range = '' if (uc($range) eq 'AUTO');
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    my $current;

    dmm_writeString("MEAS:CURR:DC? $range;*OPC?",$DMMnumber);
    $current = dmm_readString($DMMnumber);
    if ($current =~ s/;1$//){
        w2log("current_snapshot: $current A\n");
        return (0,$current);
    }
    else{
        my $ret;
        dmm_writeString("STAT:QUES:EVEN?",$DMMnumber);
        wait_ms(10);
        (undef,$ret) = dmm_readString($DMMnumber);

        if ($ret == 2){
            w2log("current_snapshot: OVERLOAD ($ret)\n");
            $current = 'OVERLOAD';
        }
        else{
            w2log("current_snapshot: ERROR ($ret)\n");
            $current = 'ERROR';
        }

        dmm_writeString("*CLS",$DMMnumber);
        return (-1,$current);
    }
}


############################################################################################################

=head2 dmm_resistance_snapshot

    ($status,$resistance) = dmm_resistance_snapshot( [$mode, $range, $DMMnumber] );
    
    $mode = 2 : two wire, 4 : four wire measurement, default is 2
    $range = measurement range in Ohms, default is "AUTO"
    $DMMnumber = number of DMM, default is 0

Measure resistance directly. will return OVERLOAD on overload, ERROR on other error

GPIB commands: MEAS:RES?, MEAS:FRES?

=cut

sub dmm_resistance_snapshot{
    my $mode    = shift;
    $mode=2 unless(defined($mode) );
    my $range=shift;
    $range = '' unless(defined($range) );
    $range = '' if (uc($range) eq 'AUTO');
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    my $resistance;

    if ($mode == 2){
        dmm_writeString("MEAS:RES? $range;*OPC?",$DMMnumber);
    }
    elsif ($mode == 4){    
        dmm_writeString("MEAS:FRES? $range;*OPC?",$DMMnumber);
    }
    else{
        return 'ERROR';
    }
    $resistance = dmm_readString($DMMnumber);
    if ($resistance =~ s/;1$//){
        w2log("resistance_snapshot: $resistance Ohm\n");
        return (0,$resistance);
    }
    else{
        my $ret;
        dmm_writeString("STAT:QUES:EVEN?",$DMMnumber);
        wait_ms(10);
        (undef,$ret) = dmm_readString($DMMnumber);

        if ($ret == 512){
            w2log("resistance_snapshot: OVERLOAD ($ret)\n");
            $resistance = 'OVERLOAD';
        }
        else{
            w2log("resistance_snapshot: ERROR ($ret)\n");
            $resistance = 'ERROR';
        }

        dmm_writeString("*CLS",$DMMnumber);
        return (-1,$resistance);
    }
}




######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut




############################################################################################################

=head2 $status = dmm_writeString($string [, $DMMnumber]);

$DMMnumber number of DMM, default is 0

write string directly to DMM

=cut

sub dmm_writeString{
    my $string = shift;
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    w2log("writing <$string> to $DMMnumber\n");
    $DMM_handle[$DMMnumber] -> ibwrt($string);
    wait_ms(10);
    return 0;
}



############################################################################################################

=head2 ($status,$string) = dmm_readString( [$DMMnumber] );

$DMMnumber number of DMM, default is 0

read string directly from DMM

=cut

sub dmm_readString{
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    my ($string,$STB,$i);
    # poll for MAV bit max 5 sec
    for ($i=0; $i<5000; $i++){
        $STB = ($DMM_handle[$DMMnumber] -> ibrsp());
        last if (($STB & 16) == 16); # stop polling if MAV bit set
 
        # sleep 10 msec
        wait_ms(1);        
    }
## w2log("STB = $STB, i = $i\n");
   
    if ($i>4999){
        w2log("!communication timeout while reading from $DMMnumber\n");
        return(-1,"");
    }
   
    #wait_ms(10);    
    {
    no warnings; # skip warning for uninitialized value
    $string = $DMM_handle[$DMMnumber] -> ibrd(1024);
    $string .= $DMM_handle[$DMMnumber] -> ibrd(1024); # it only works with 2 times reading
    }
    unless (defined($string)){
            w2log("empty response from $DMMnumber\n");
            return(0,"");
    }
    chomp($string);
    w2log("reading <$string> from $DMMnumber\n");
    return(0,$string);
}



############################################################################################################

=head2 $value = dmm_isConnected( [$DMMnumber] );

$DMMnumber number of DMM, default is 0

check if DMM is connected returns 1 if true, 0 if false

=cut

sub dmm_isConnected{
    my $DMMnumber=shift;
    $DMMnumber=0 unless(defined($DMMnumber) );
    return($DMM_connected[$DMMnumber]);
}



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print $logfile_handle $text if (defined $logfile_handle);
     print $text;
}


sub wait_ms{
    my $time = shift;    
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Agilent 34401A multimeter manual.

=cut
