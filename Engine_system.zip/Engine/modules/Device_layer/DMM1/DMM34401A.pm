package DMM34401A;

use strict;
use warnings;
use File::Basename;

# need to add in calling module
#BEGIN
#{
#    # add directories to search path for perl modules
#    unshift @INC, dirname( $0 )."/modules/GPIB";
#    unshift @INC, dirname( $0 )."/modules/GPIB/GPIB";
#}

use GPIB;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use DMM34401A ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
);

our ($VERSION,$HEADER);


=head1 NAME

DMM34401A 

Perl extension for Agilent 34401A multimeter

=head1 SYNOPSIS

    use DMM34401A;

    my ($dmm, $voltage, $current, $resistance);

    $dmm = DMM34401A->new(\*LOG);
    $dmm->connect('GPIB:9');

    $voltage = $dmm->voltage_snapshot();
    $current = $dmm->current_snapshot();
    $resistance = $dmm->resistance_snapshot();
    $resistance = $dmm->resistance_snapshot(4);

    $dmm->disconnect();


=head1 DESCRIPTION

remote control functions for Agilent 34401A multimeter using GPIB.pm

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut


=head1 CONSTRUCTOR

=head2 $dmm = DMM34401A->new(\*LOG);

creates an instance of a DMM object and returns its handle

writes into give logfile, if no filehandle is given log_DMM34401Apm.txt is created, 

=cut


my $DMM_handle;
my $logfile_handle;


sub new {
    my $class = shift;
    $logfile_handle=shift;
    unless ($logfile_handle) {
        open ( PPSLOG,">log_DMM34401Apm.txt" ) or die "Couldn't open logfile : $@";
        $logfile_handle = \*PPSLOG;
    }
    my $self = {};
    bless ($self, $class);
    w2log("creating new DMM34401A instance\n");
    $self->{connected} = 0; # set connencted flag to false
    $self->{ID} = "DMM34401A";
    return $self;
}


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


############################################################################################################

=head2 ($status,$DeviceID) = $dmm->connect($connection);

Connnect to DMM via given connection, reads device identification (*IDN). This method has to be called first before any other method can be used.   

A valid connection is e.g. 'GPIB:3'. Make sure wiring is configured accordingly !

=cut

sub connect {
    my $self = shift;

    my $ret;
    my $connection = shift;
    w2log("connecting with DMM34401A via <$connection>\n");

    if($connection =~ /GPIB:\s*(\d+)/i){
        my $DeviceID;
        $self->{GPIB} = GPIB->new("GPIB::ni", 0, $1, 0, GPIB->T300ms, 1, 0);   
 #       $self->{GPIB} = GPIB->new("GPIB::ni", 0, $1, 0, GPIB->T1s, 1, 0);   # bm7zsi
        $DMM_handle = $self->{GPIB};
        wait_ms(10);
        $self->writeString("*IDN?");
        wait_ms(10);
        $DeviceID = readString($self);
        chomp($DeviceID);
        $self->{ID} = "{$DeviceID}";
        
        w2log("Device is <$DeviceID>\n");

        $self->writeString("STAT:QUES:ENAB 515");
        wait_ms(10);
        $self->writeString("*CLS");
        wait_ms(10);

#        $DMM_handle -> ibwrt("SYST:VERS?");

        $self->{connected} = 1; # set connencted flag to true
        return(0,$DeviceID);

    }
    else{
      w2log("ERROR: connection error for DMM34401A on <$connection>\n");
      $self->{connected} = 0; # set connencted flag to false
      return(-1,"unknown");
    }

}




############################################################################################################

=head2 $dmm->disconnect();

Disconnect from DMM

=cut

sub disconnect{
    my $self = shift;
    $DMM_handle = $self->{GPIB};
    w2log("disconnecting DMM34401A $self->{ID}\n");
    undef $self->{ID};
    $self->{connected} = 0; # set connencted flag to false

}




############################################################################################################

=head2 $value = $dmm->checkError(); NOT IMPLEMENTED, just returns

read error status (*ESR?,ERR?) and report error if there is one

=cut

sub checkError{

    my $self = shift;
    $DMM_handle = $self->{GPIB};
    my ($ESRresp, $ERRresp);

#        $DMM_handle -> ibwrt("SYST:ERR?");

    $DMM_handle->ibwrt('*ESR?');             
    $ESRresp = readString($self);           # Read result
    unless (defined($ESRresp) ){
        w2log("?retry status check\n");
        $DMM_handle->ibwrt('*ESR?');             
        $ESRresp = readString($self);           # Read result
        unless (defined($ESRresp) ){
            w2log("!comminication error: no staus received\n");
            return;
        }
    }
    chomp($ESRresp);
    if ($ESRresp > 0){
        $DMM_handle->ibwrt('ERR?');             
        $ERRresp = readString($self);           # Read result
        chomp($ERRresp);
        if ($ERRresp !~ /^0,/) {
            w2log("!error: ESR is $ESRresp, ERR is $ERRresp\n");
        }
    }  
}





############################################################################################################

=head2 $dmm->voltage_snapshot

    $voltage = $dmm->voltage_snapshot( [$range] );
	
	default $range is AUTO

Measure voltage directly. will return OVERLOAD on overload, ERROR on other error

GPIB commands: MEAS:VOLT:DC?

=cut

sub voltage_snapshot{
    my $self    = shift;
    my $range=shift;
    $range = '' unless(defined($range) );
    $range = '' if (uc($range) eq 'AUTO');
	my $voltage;

    $self->writeString("MEAS:VOLT:DC? $range;*OPC?");
    $voltage = $self->readString();
    if ($voltage =~ s/;1$//){
        w2log("voltage_snapshot: $voltage V\n");
    }
    else{
        my $ret;
        $self->writeString("STAT:QUES:EVEN?");
        wait_ms(10);
        (undef,$ret) = readString($self);

        if ($ret == 1){
            w2log("voltage_snapshot: OVERLOAD ($ret)\n");
            $voltage = 'OVERLOAD';
        }
        else{
            w2log("voltage_snapshot: ERROR ($ret)\n");
            $voltage = 'ERROR';
        }

        $self->writeString("*CLS");
    }
    return $voltage;
}


############################################################################################################

=head2 $dmm->current_snapshot

    $current = $dmm->current_snapshot( [$range] );

	default $range is AUTO
		
Measure current directly. will return OVERLOAD on overload, ERROR on other error

GPIB commands: MEAS:CURR:DC?

=cut

sub current_snapshot{
    my $self    = shift;
    my $range=shift;
    $range = '' unless(defined($range) );
    $range = '' if (uc($range) eq 'AUTO');
    my $current;

    $self->writeString("MEAS:CURR:DC? $range;*OPC?");
    $current = $self->readString();
    if ($current =~ s/;1$//){
        w2log("current_snapshot: $current A\n");
    }
    else{
        my $ret;
        $self->writeString("STAT:QUES:EVEN?");
        wait_ms(10);
        (undef,$ret) = readString($self);

        if ($ret == 2){
            w2log("current_snapshot: OVERLOAD ($ret)\n");
            $current = 'OVERLOAD';
        }
        else{
            w2log("current_snapshot: ERROR ($ret)\n");
            $current = 'ERROR';
        }

        $self->writeString("*CLS");
    }
    return $current;
}


############################################################################################################

=head2 $dmm->resistance_snapshot

    $resistance = $dmm->resistance_snapshot( [$mode], [$range] );
    
    $mode = 2 : two wire, 4 : four wire measurement, default is 2
	default $range is AUTO

Measure resistance directly. will return OVERLOAD on overload, ERROR on other error

GPIB commands: MEAS:RES?, MEAS:FRES?

=cut

sub resistance_snapshot{
    my $self    = shift;
    my $mode    = shift;
    my $range=shift;
    $range = '' unless(defined($range) );
    $range = '' if (uc($range) eq 'AUTO');
    my $resistance;

    if ($mode == 2){
        $self->writeString("MEAS:RES? $range;*OPC?");
    }
    elsif ($mode == 4){    
        $self->writeString("MEAS:FRES? $range;*OPC?");
    }
    else{
        return 'ERROR';
    }
    $resistance = $self->readString();
    if ($resistance =~ s/;1$//){
        w2log("resistance_snapshot: $resistance Ohm\n");
    }
    else{
        my $ret;
        $self->writeString("STAT:QUES:EVEN?");
        wait_ms(10);
        (undef,$ret) = readString($self);

        if ($ret == 512){
            w2log("resistance_snapshot: OVERLOAD ($ret)\n");
            $resistance = 'OVERLOAD';
        }
        else{
            w2log("resistance_snapshot: ERROR ($ret)\n");
            $resistance = 'ERROR';
        }

        $self->writeString("*CLS");
    }
    return $resistance;
}




######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut


=head2 $dmm->local_mode();

set DMM to local mode

=cut

sub local_mode{
  my $self = shift;
  $DMM_handle = $self->{GPIB};
  
   my ($string,$STB,$i);
   $STB = ($DMM_handle -> ibloc());
   w2log("local mode for $self->{ID}\n");
    return(0);
}


############################################################################################################

=head2 $dmm->writeString($string);

write string directly to DMM

=cut

sub writeString{
  my $self = shift;
  $DMM_handle = $self->{GPIB};
  my $string = shift;
  w2log("writing <$string> to $self->{ID}\n");
  $DMM_handle -> ibwrt($string);
  wait_ms(10);
}



############################################################################################################

=head2 $string = $dmm->readString();

read string directly from DMM

=cut

sub readString{
  my $self = shift;
  $DMM_handle = $self->{GPIB};
   my ($string,$STB,$i);
    # poll for MAV bit max 5 sec
    for ($i=0; $i<5000; $i++){
        $STB = ($DMM_handle -> ibrsp());
        last if (($STB & 16) == 16); # stop polling if MAV bit set
 
        # sleep 10 msec
        wait_ms(1);        
    }
## w2log("STB = $STB, i = $i\n");
   
    if ($i>4999){
        w2log("!communication timeout while reading from $self->{ID}\n");
        return(-1,"");
    }
   
    #wait_ms(10);    
    {
    no warnings; # skip warning for uninitialized value
    $string = $DMM_handle -> ibrd(1024);
    $string .= $DMM_handle -> ibrd(1024); # it only works with 2 times reading
    }
    unless (defined($string)){
            w2log("empty response from $self->{ID}\n");
            return(0,"");
    }
    chomp($string);
    w2log("reading <$string> from $self->{ID}\n");
    return(0,$string);
}



############################################################################################################

=head2 $value = $dmm->isConnected();

check if DMM is connected returns 1 if true, 0 if false

=cut

sub isConnected{
    my $self = shift;
    return($self->{connected});
}



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print $logfile_handle $text if (defined $logfile_handle);
     print $text;
}


sub wait_ms{
    my $time = shift;    
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Agilent 34401A multimeter manual.

=cut
