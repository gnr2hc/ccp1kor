package LIFT_DMM1;

use strict;
use warnings;
use File::Basename;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['..\GPIB', '..\GPIB\GPIB', '..\GPIB\Win32' ], []);
}

use DMM34401A;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_DMM1 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  DMM1_connect
  DMM1_disconnect
  DMM1_getVoltage
  DMM1_getCurrent
  DMM1_getResistance
  DMM1_isConnected
  DMM1_readString
  DMM1_writeString
  DMM1_local

);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_DMM1 

Perl extension for Agilent 34401A multimeter

=head1 SYNOPSIS

    use LIFT_DMM1;

    $DeviceID = DMM1_connect('GPIB:8');

    $voltage = DMM1_getVoltage();
    $current = DMM1_getCurrent();
    $resistance = DMM1_getResistance();

    $value = DMM1_isConnected();
    $string = DMM1_readString();
    DMM1_writeString( $string );

    DMM1_disconnect();

=head1 DESCRIPTION

Remote control functions for Agilent 34401A using GPIB.pm

B<LIFT_Testbenches.pm:>

    'Devices' => {
        'DMM1' => {
            'connect' => 'GPIB:9',
            'resistance_mode' => 4, # 2: two wire, 4: four wire measurement
        },

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut

my $dmm1;

#Help Variables
my ( $status, $DeviceID, $ErrorString, $resistance_mode );

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 DMM1_connect

    $DeviceID = DMM1_connect( [$connection] );

    e.g. $DeviceID = DMM1_connect();
       . $DeviceID = DMM1_connect('GPIB:9');

Connnect to DMM via given connection. If no connection given, data is taken from Testbenchconfig.
Reads device identification (*IDN). This method has to be called first before any other method can be used.

Make sure Digital MultiMeter is configured accordingly !

Returns Device ID , on error: empty string, offline return: 'dummy'

=cut

sub DMM1_connect
{

    my $connection = shift;

    unless ( defined($connection) )
    {
        {
            no warnings;
            $connection = $LIFT_config::LIFT_Testbench->{'Devices'}{'DMM1'}{'connect'};
        }
        unless ($connection)
        {
            S_set_error( "No connection settings for DMM1 in testbench config found", 20 );
            return "";
        }
        S_w2log( 4, "no connection given, taking '$connection' from testbench config\n" );
    }

    if ( defined($dmm1) )
    {
        S_set_error( "Connection failed, DMM object could not be created, object exists already", 5 );
        return "";
    }

    $resistance_mode = $LIFT_config::LIFT_Testbench->{'Devices'}{'DMM1'}{'resistance_mode'};
    unless ( defined($resistance_mode) )
    {
        S_set_error( "could not find resistance_mode for DMM1 in testbenchconfig, taking default 2", 0 );    # warning
        $resistance_mode = 2;
    }

    S_w2log( 4, "DMM1_connect($connection): Establishes the connection \n" );

    if ($main::opt_offline)
    {
        $dmm1 = 1;
        return "dummy";
    }

    #avoid more connections
    unless ( defined($dmm1) )
    {
        $dmm1 = DMM34401A->new();
    }

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object could not be created", 1 );
        return "";
    }

    ( $status, $DeviceID ) = $dmm1->connect($connection);

    #check error
    check_Status();
    S_w2log(5,"connect status is $status \n");
    S_w2log( 4, "DMM1_connect: Device ($DeviceID) is connected \n" );
    return $DeviceID;
}

############################################################################################################

=head2 DMM1_disconnect

    DMM1_disconnect( );

Disconnect from DMM


=cut

sub DMM1_disconnect
{

    #fix object error
    S_w2log( 4, "DMM1_disconnect: Terminates the connection with device $DeviceID \n" );

    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return;
    }

    if ($main::opt_offline)
    {
        undef $dmm1;
        return 1;
    }

    $status = $dmm1->disconnect();
    check_Status();
    S_w2log(5,"disconnect status is $status \n");
    undef $dmm1;

    S_w2log( 5, "Device ($DeviceID) is disconnected \n" );

}

=head2 DMM1_local

    DMM1_local( );

set DMM to local mode


=cut

sub DMM1_local
{

    #  S_w2log(4,"DMM1_local()\n");

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return;
    }

    if ($main::opt_offline)
    {
        return 1;
    }

    $status = $dmm1->local_mode();
    check_Status();
    S_w2log(5,"local_mode status is $status \n");
    S_w2log( 4, "DMM1_local: Device in local mode \n" );

}

############################################################################################################

=head2 DMM1_getVoltage

    $voltage = DMM1_getVoltage( [$range] );

Measure voltage directly. will return 9007199254740992 on overload, ERROR on other error

=cut

sub DMM1_getVoltage
{

    my $range = shift;
    $range = '' unless ( defined($range) );
    $range = '' if ( uc($range) eq 'AUTO' );

    #  S_w2log(4,"DMM1_getVoltage($range) \n");

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return 1;
    }
    return 1 if $main::opt_offline;

    my $voltage = $dmm1->voltage_snapshot($range);
    S_set_error( "error in voltage_snapshot", 5 ) if ( $voltage eq 'ERROR' );

    $voltage = 9007199254740992 if ( $voltage eq 'OVERLOAD' );
    S_w2log( 5, "DMM1_getVoltage returned $voltage V\n" );
    return $voltage;
}

=head2 DMM1_getCurrent

    $current = DMM1_getCurrent( [$range] );

Measure current directly. will return 9007199254740992 on overload, ERROR on other error

=cut

sub DMM1_getCurrent
{

    my $range = shift;
    $range = '' unless ( defined($range) );
    $range = '' if ( uc($range) eq 'AUTO' );

    #  S_w2log(4,"DMM1_getCurrent() \n");

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return 1;
    }
    return 1 if $main::opt_offline;

    my $current = $dmm1->current_snapshot($range);
    S_set_error( "error in current_snapshot", 5 ) if ( $current eq 'ERROR' );

    $current = 9007199254740992 if ( $current eq 'OVERLOAD' );
    S_w2log( 5, "DMM1_getCurrent returned $current A\n" );
    return $current;
}

=head2 DMM1_getResistance

    $resistance = DMM1_getResistance( [$range] );

Measure resistance directly. will return 9007199254740992 on OVERLOAD, ERROR on other error

=cut

sub DMM1_getResistance
{

    my $range = shift;
    $range = '' unless ( defined($range) );
    $range = '' if ( uc($range) eq 'AUTO' );

    S_w2log( 4, "DMM1_getResistance($range) \n" );

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return 1;
    }
    return 1 if $main::opt_offline;

    my $resistance = $dmm1->resistance_snapshot( $resistance_mode, $range );
    S_set_error( "error in resistance_snapshot", 5 ) if ( $resistance eq 'ERROR' );

    $resistance = 9007199254740992 if ( $resistance eq 'OVERLOAD' );
    S_w2log( 5, "DMM1_getResistance returned $resistance Ohm\n" );
    return $resistance;
}

######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut

############################################################################################################

=head2 DMM1_writeString

    DMM1_writeString( $string );
    e.g. DMM1_writeString("*IDN?");

write string directly to DMM


=cut

sub DMM1_writeString
{
    my $string = shift;

    unless ( defined($string) )
    {
        S_set_error( "SYNTAX: DMM1_writeString(string)", 110 );
        return 1;
    }

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return 1;
    }

    return 1 if $main::opt_offline;

    $status = $dmm1->writeString($string);
    check_Status();
    S_w2log( 4, "DMM1_writeString ($status)\n" );
}

############################################################################################################

=head2 DMM1_readString

    $string = DMM1_readString( );

read string directly from DMM

Returns string, on error empty string, offline return 'dummy'

=cut

sub DMM1_readString
{

    my $string;

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return 1;
    }

    return 'dummy' if $main::opt_offline;

    ( $status, $string ) = $dmm1->readString();

    check_Status();
    S_w2log(5,"readString status is $status \n");
    S_w2log( 5, "DMM1_readString got: $string \n" );

    return $string;
}

############################################################################################################

=head2 DMM1_isConnected

    $value = DMM1_isConnected( );

check if DMM is connected

Returns 1 if true, 0 if false,  Error: < 0,      offline return: 1

=cut

sub DMM1_isConnected
{

    S_w2log( 4, "DMM1_isConnected: checking for connection.... \n" );

    #fix object error
    unless ( defined($dmm1) )
    {
        S_set_error( "dmm object is invalid", 5 );
        return 1;
    }

    return 1 if $main::opt_offline;
    my $val = $dmm1->isConnected();
    S_w2log( 5, "DMM1_isConnected : $val\n" );
    return ($val);
}

############################################################################################################

=head1 not exported functions

=head2 check_Status

    check_Status( ); not exported

check occurred error and write error message from low level Modul in Report File.

Returns

        offline: 1

=cut

sub check_Status
{

    return 1 if $main::opt_offline;

    if ( $status < 0 )
    {
        $ErrorString = getErrorString($status);
        S_set_error( "DMM1: $ErrorString", 5 );
    }
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Agilent 34401A multimeter manual.

=cut
