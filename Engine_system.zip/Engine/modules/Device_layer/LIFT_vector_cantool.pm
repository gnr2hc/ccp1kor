# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_vector_cantool;

use strict;
use Win32::OLE;
use File::Copy;
use File::Basename;
use FileHandle;
use LIFT_general;
use Data::Dumper;
use LIFT_simulation;
use LIFT_numerics;
use POSIX qw/floor/;

use vars qw( $VERSION $HEADER @ISA @EXPORT );
use Exporter;
# next 2 lines edited by CVS, DO NOT MODIFY

@ISA = qw(Exporter);
@EXPORT = qw(
            VEC_init
            VEC_cantool_init
            VEC_get_OLE_handle
            VEC_start_application
            VEC_close_application
            VEC_get_hostname_for_OLE_handle
            VEC_get_device_for_OLE_handle
            VEC_open_configuration
            VEC_read_configuration
            VEC_start_measurement
            VEC_check_running
            VEC_stop_measurement
            VEC_trace_configure
            VEC_trace_store
            VEC_trace_flxr_store_signals_file
            VEC_trace_can_get_dataref
            VEC_read_can_configure
            VEC_read_can_signal
            VEC_read_can_signal_direct
            VEC_write_can_configure
            VEC_write_can_signal
            VEC_trace_flxr_get_dataref
            VEC_read_flxr_configure
            VEC_read_flxr_signal
            VEC_read_flxr_signal_direct
            VEC_trace_fr_get_signal_data
            VEC_write_flxr_configure
            VEC_write_flxr_signal
            VEC_read_ecu_configure
            VEC_read_ecu_signal
            VEC_write_ecu_configure
            VEC_write_ecu_signal
            
            VEC_get_env_variable
            VEC_set_EnvVar_value_by_type
            VEC_get_EnvVar_value_by_type
            
            VEC_get_sys_variable
            VEC_set_SysVar_value_by_type
            VEC_get_SysVar_value_by_type
            
            VEC_trace_can_get_message_data
            VEC_trace_canfd_get_message_data
            VEC_enable_can_message
            VEC_disable_can_message
            VEC_set_DLC
            VEC_reset_DLC
            VEC_enable_flxr_PDU_update
            VEC_disable_flxr_PDU_update
            VEC_trace_can_get_signal_data
            VEC_read_lin_configure
            VEC_read_lin_signal
            VEC_write_lin_configure
            VEC_write_lin_signal
            VEC_disable_lin_frame
            VEC_enable_lin_frame
            VEC_trace_lin_get_dataref
            VEC_trace_lin_get_message_data
            VEC_trace_lin_get_signal_data
            VEC_LIN_set_DLC
            VEC_LIN_reset_DLC
            VEC_trace_fr_get_PDU_data
            VEC_trace_eval_CAPL_printed_ascii_signal_file
            VEC_reset_flxr_bz_error
			VEC_set_flxr_bz_error
			VEC_reset_flxr_crc_error
			VEC_set_flxr_crc_error
			VEC_reset_can_bz_error
			VEC_set_can_bz_error
			VEC_reset_can_crc_error
			VEC_set_can_crc_error
            VEC_trace_can_analyze_format
            VEC_trace_sysVar_get_data
            
            VEC_set_lin_crc_error
            VEC_reset_lin_crc_error
            VEC_set_lin_bz_error
            VEC_reset_lin_bz_error
            
          ); # export subs

our $Vector_tool_control;

my $dummy_href = {'1'=> '1'};

my $initEquipment_href;

if ( $main::opt_simulation ){
    no strict 'refs';
    # define all functions that should not be redefined (because they work anyway)
    my @exclude = qw(
        VEC_init
    );
    # redefine all functions for simulation mode with default return values, except the functions in @exclude
    foreach my $function (@EXPORT){
        next if grep {/$function/} @exclude;
        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
	             'VEC_cantool_init' => { 'default' => [1]},
	             'VEC_check_running' => { 'default' => [1]},
	             'VEC_trace_store' => { 'default' => ['C:\temp\FR_trace.asc']},
	             'VEC_trace_flxr_store_signals_file' => { 'default' => ['C:\temp\signal_file.asc']},
	             'VEC_write_can_configure' => { 'default' => [1]}, 
	             'VEC_read_flxr_signal' => { 'default' => [1,1]}, 
	             'VEC_write_lin_configure' => { 'default' => [1]}, 
	             'VEC_read_lin_configure' => { 'default' => [1]},
				 'VEC_read_lin_signal' => { 'default' => ['InsErk_Knummer_EndtestCompID','NO_UNIT']},
	             'VEC_disable_lin_frame' => { 'default' => [1]},
	             'VEC_enable_lin_frame' => { 'default' => [1]},
	             'VEC_trace_configure' => { 'default' => [1]},
	             'VEC_start_measurement' => { 'default' => [1]},
	             'VEC_stop_measurement' => { 'default' => [1]},
	             'VEC_reset_can_bz_error' => { 'default' => [1]},
	             'VEC_trace_can_analyze_format' => { 'default' => ['hex', 'absolute' ]},
	             'VEC_read_can_signal' => { 'default' => [1,'dummy_unit']},
	             'VEC_trace_can_get_message_data' => { 'default' => [{
																 '18.222990' => {
																				  'OTHER' => 'Length = 239762 BitCount = 124 ID = 318',
																				  'DLC' => '8',
																				  'DATA' => 'F2 0A 00 00 00 00 00 00  '
																				},
																 '1.223822' => {
																				 'OTHER' => 'Length = 243777 BitCount = 126 ID = 318',
																				 'DLC' => '8',
																				 'DATA' => '18 08 00 00 00 00 00 00  '
																			   },
																 '24.722682' => {
																				  'OTHER' => 'Length = 243777 BitCount = 126 ID = 318',
																				  'DLC' => '8',
																				  'DATA' => 'AE 07 00 00 00 00 00 00  '
																				},
																 '14.723168' => {
																				  'OTHER' => 'Length = 239777 BitCount = 124 ID = 318',
																				  'DLC' => '8',
																				  'DATA' => 'D1 03 00 00 00 00 00 00  '
																				},
													                }]
								                     },
                  'VEC_trace_can_get_signal_data' => { 'default' => [ {        
																'47.853271' => 3,
																'47.273275' => 4,
																'46.763270' => 0,
																'63.773379' => 0,
																'51.273301' => 0,
																'45.273262' => 0,
																'74.773453' => 0,
																'59.773351' => 0,
																'46.823256' => 4,
																}]
												     },	
                 'VEC_trace_fr_get_PDU_data' => { 'default' => [{
                                                                  '0.705337' => {
                                                                                  'DLC_2' => 4,
                                                                                  'HEADER_CRC' => '18c',
                                                                                  'FR_PDU' => 'Klemmen_Status_01',
                                                                                  'DATA' => '7e 0d 02 00',
                                                                                  'DLC_1' => 4
                                                                                },
                                                                  '0.955325' => {
                                                                                  'DLC_2' => 4,
                                                                                  'HEADER_CRC' => '18c',
                                                                                  'FR_PDU' => 'Klemmen_Status_01',
                                                                                  'DATA' => '3b 0f 02 00',
                                                                                  'DLC_1' => 4
                                                                                },
                                                                    }]
                                                      },
                  'VEC_trace_fr_get_signal_data' => { 'default' => [{
                                                                      '0.705337' => 0,
                                                                      '0.955325' => 0,
                                                                     }]
                                                      }, 
	             'VEC_get_SysVar_value_by_type' => { 'default' => [[0, 0 , 1, 1]]},                                                                                              
    };
    SIM_addToValuesTable( $returnValuesTable_href );
        
};

#####################################################################

=head1 NAME

LIFT_vector_cantool 

Provide LIFT useful functions for access to CAN tools of Vector Informatics

=head1 SYNOPSIS

    use LIFT_vector_cantool;

          VEC_cantool_init
          VEC_start_application
          VEC_get_OLE_handle
          VEC_get_device_for_OLE_handle
          VEC_get_hostname_for_OLE_handle
          VEC_close_application
          VEC_open_configuration
          VEC_read_configuration
          VEC_start_measurement
          VEC_stop_measurement
          VEC_check_running
          VEC_trace_configure
          VEC_trace_store
          VEC_trace_flxr_store_signals_file
          VEC_trace_can_get_dataref
          VEC_trace_can_get_message_data
          VEC_trace_can_get_signal_data
          VEC_trace_flxr_get_dataref
		  VEC_trace_fr_get_signal_data
          VEC_trace_eval_CAPL_printed_ascii_signal_file
          VEC_read_can_configure
          VEC_read_can_signal
          VEC_read_can_signal_direct
          VEC_write_can_configure
          VEC_write_can_signal
          VEC_read_flxr_configure
          VEC_read_flxr_signal
          VEC_read_flxr_signal_direct
          VEC_write_flxr_configure
          VEC_write_flxr_signal
          VEC_disable_can_message
          VEC_enable_can_message
          VEC_set_DLC
          VEC_reset_DLC
          VEC_disable_flxr_PDU_update
          VEC_enable_flxr_PDU_update
          VEC_read_ecu_configure
          VEC_read_ecu_signal
          VEC_write_ecu_configure
          VEC_write_ecu_signal
          VEC_get_env_variable
          VEC_read_lin_configure
          VEC_read_lin_signal
          VEC_write_lin_configure
          VEC_write_lin_signal
          VEC_disable_lin_frame
          VEC_enable_lin_frame
          VEC_trace_lin_get_dataref
          VEC_trace_lin_get_message_data
          VEC_trace_lin_get_signal_data
          VEC_LIN_set_DLC
          VEC_LIN_reset_DLC
          VEC_trace_fr_get_PDU_data
          ubit
          VEC_break_measurement
          VEC_compile_all_CAPL_nodes
          VEC_get_application_version
          VEC_get_configuration_mode
          VEC_get_configured_logfile_names
          VEC_get_sys_variable
          VEC_set_configuration_mode
          VEC_start_measurement_offline
          VEC_trace_can_analyze_format
          VEC_trace_create_eval_capl
          VEC_trace_lin_analyze_format
          VEC_trace_run_offline
          VEC_xcp_init
          
          VEC_reset_flxr_bz_error
		  VEC_set_flxr_bz_error
			VEC_reset_flxr_crc_error
			VEC_set_flxr_crc_error
			VEC_reset_can_bz_error
			VEC_set_can_bz_error
			VEC_reset_can_crc_error
			VEC_set_can_crc_error
          

=cut

#####################################################################

=head2 VEC_cantool_init

    VEC_cantool_init ( application , function , type );

    application : expect just 'CANalyzer' + 'CANoe'
    function    : expect just 'read' 'write' 'trace'
    type        : expect just 'ECU' + 'CAN' + 'FlexRay' +'LIN'
    
    organize initialization of CAN tool application

=cut

#####################################################################

sub VEC_cantool_init
{
   my $device = shift;     ## expect just 'CANalyzer' + 'CANoe'
   my $function = shift;   ## expect just 'read' 'write' 'trace'
   my $type = shift;       ## expect just 'ECU' + 'CAN' + 'FlexRay' + 'LIN'

   my (
        $hostname ,
        $online_config ,
        $eval_offline_mode_capl_template ,
        $eval_offline_mode_signal_file ,
        $eval_online_mode_signal_file ,
        $logfile_testBench ,
        $OLE_handle ,
        $currently_loaded_device ,
        @LogFileNames ,
        $default_LOG_FILE ,
        $matched_flag ,
        $Cantool_version ,
        $keep_application_after_test ,
        $flxr_signal ,
        $pdu_name ,
        $frame_name ,
        $all_signals_info ,
       );

   unless( $device =~ /CANalyzer/i || $device =~ /CANoe/i ) {
      S_set_error( " wrong device '$device' (just 'CANalyzer','CANoe' allowed)\n" , 131);
      return;
   }

   my $testbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );

   $default_LOG_FILE = "C:\\temp\\LIFT_CAN_TRACE.asc";
   unless( $hostname = $testbench->{'Devices'}{$device}{'Hostname'} ) {
      S_set_error( " VEC_cantool_init: No 'Hostname' defined for Device '$device'\n" , 131);
      return ;
   }
   return 1 if $main::opt_offline;

   #if( not $currently_loaded_device = $Vector_tool_control->{'Hostname'}{$hostname} ) {
   unless( $currently_loaded_device = $Vector_tool_control->{'Hostname'}{$hostname} ) {
        unless( $OLE_handle = VEC_start_application( $device , $hostname  ) ) {
        	S_set_error( " VEC_cantool_init: Could not start '$device' application on host '$hostname' \n
      				Suggestions : Launch the CANoe manually and check whether its opening successfully without any errors or warnings with the last used CANoe Config\n", 131);
        	return ;
        }
        # just printout version
        VEC_get_application_version ( $OLE_handle , 'FullName' );
        unless( $online_config = $testbench->{'Devices'}{$device}{'Online_Config'} ) {
            unless( $online_config = $testbench->{'Devices'}{$device}{'OnlineOffline_Config'} ) {
               S_set_error( " VEC_cantool_init: No 'Online_Config' or 'OnlineOffline_Config' defined for Device '$device'\n" , 131 );
               return ;
            }
        }
        if( $testbench->{'Devices'}{$device}{'Create_Local_Config_Copy'} ) {
            my($temp_online_config) = fileparse($online_config);
            my $temp_open_local_config = 'c:\\temp\\' . $temp_online_config;
            $temp_online_config ='\\\\'. $hostname . '\\c$\\temp\\' . $temp_online_config;
            S_w2log( 1, " VEC_cantool_init: using $temp_online_config for temp copy of project\n" );
            unless( copy ( $online_config , $temp_online_config)  ) {
                S_set_error( " copy ( $online_config , $temp_online_config ) : $! \n" , 1 );
                return ;
            }
            unless( VEC_open_configuration( $OLE_handle , $temp_open_local_config , 1 ) ) {
                S_set_error(  " VEC_cantool_init: Could not open '$device' configuration '$temp_open_local_config' \n" , 131 );
                return ;
            }
            $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'} = $temp_online_config;
        }

        else {
            unless( VEC_open_configuration( $OLE_handle , $online_config , 1 ) ) {
                S_set_error(  " VEC_cantool_init: Could not open '$device' configuration '$online_config' \n" , 131 );
                return ;
            }
            $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'} = $online_config;
        }
        
        # check only once if the trace file mentioned in test bench is same as configured in CANoe 
        if ( $function =~ /trace/i or $function =~ /basic/i ) {
            unless ( $logfile_testBench = $testbench->{'Devices'}{$device}{'Log_File'} ) {
                S_set_error( " VEC_cantool_init: No 'Log_File' defined for Device '$device' ( needed for function '$function')\n", 131 );
                return;
            }
            @LogFileNames = VEC_get_configured_logfile_names($OLE_handle);
            @LogFileNames = ($logfile_testBench) if $main::opt_offline;
            $matched_flag = 0;
            foreach (@LogFileNames) {

                my $LogFileName = basename($_);
                $LogFileName =~ s/\d+\.asc$/.asc/i;    # remove numbers from CANoe incrementing file

                if ( $LogFileName eq basename($logfile_testBench) ) {
                    S_w2log( 3, " VEC_cantool_init: $device Configuration has Log File $_ configured\n" );
                    $Vector_tool_control->{'Devices'}{$device}{'DefaultLogFile'} = $logfile_testBench;
                    $matched_flag = 1;
                }
            }
            unless ($matched_flag) {
                my $log_files_text = join( " ", @LogFileNames );
                S_set_error( " VEC_cantool_init: Could not find Testbench Log_File '$logfile_testBench' in configured Log_Files ( '$log_files_text' ) of '$device' configuration '$online_config' \n", 131 );
                return;
            }
        }        
   }
   else {
      if( $device =~ /$currently_loaded_device/  )  {
         S_w2log( 1, " VEC_cantool_init: $device application on host '$hostname' already started\n" );
         $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'};
      }
      else {
         S_set_error( " cannot start '$device' application on '$hostname' ('$currently_loaded_device' already loaded)\n" , 131);
         return ;
      }
   }
   if( $type =~ /ECU/i ) {
      unless( VEC_xcp_init( $OLE_handle ) ) {
         S_w2log( 1, " VEC_cantool_init: Could not initialize '$device' XCP functionality \n" );
         return ;
      }
   }
   
#
# reading this section of LIFT_Testbenches :
#
#             'Eval_Offline_Mode_Capl_Template' => '\\\\ABT16211\c$\temp\LIFT_EVAL_CAPL_TEMPLATE.can' ,
#             'Eval_Offline_Mode_Signal_File' => '\\\\ABT16211\c$\temp\LIFT_TEST_SIGNALS.asc',
#             'Eval_Online_Mode_Signal_File' => '\\\\ABT16211\c$\temp\LIFT_TEST_SIGNALS.asc',
#
#   if( $function =~ /trace/i && $type =~ /FlexRay/i ) {
#        unless( $eval_offline_mode_capl_template = $testbench->{'Devices'}{$device}{'Eval_Offline_Mode_Capl_Template'} ) {
#            S_set_error( " VEC_cantool_init: No 'Eval_Offline_Mode_Capl_Template' defined for Device '$device'\n", 131 );
#            return;
#        }



#
#        $Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Mode_Capl_Template'} = $eval_offline_mode_capl_template ;
#        
#        if( my $Eval_Offline_Log_File_Input = $testbench->{'Devices'}{$device}{'Eval_Offline_Log_File_Input'} ) {
#            S_w2log( 3 , " VEC_cantool_init: 'Eval_Offline_Log_File_Input' defined for Device '$device'\n" );
#            $Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Log_File_Input'} = $Eval_Offline_Log_File_Input;
#        } 
#        else { S_w2log( 3 , " VEC_cantool_init: No 'Eval_Offline_Log_File_Input' defined for Device '$device'\n" ) }
#
#        if( $eval_offline_mode_signal_file = $testbench->{'Devices'}{$device}{'Eval_Offline_Mode_Signal_File'} ) {
#            $Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Mode_Signal_File'} = $eval_offline_mode_signal_file ;
#        }
#        else {
#            S_set_error( " VEC_cantool_init: No 'Eval_Offline_Mode_Signal_File' defined for Device '$device'\n", 0 );
#        }
#        
#        if( $eval_online_mode_signal_file = $testbench->{'Devices'}{$device}{'Eval_Online_Mode_Signal_File'} ) {
#            $Vector_tool_control->{'Devices'}{$device}{'Eval_Online_Mode_Signal_File'} = $eval_online_mode_signal_file ;
#        }
#        else {
#            S_set_error( " VEC_cantool_init: No 'Eval_Online_Mode_Signal_File' defined for Device '$device'\n", 0 );
#        }      
#        
#        unless( defined $eval_offline_mode_signal_file or defined $eval_online_mode_signal_file ) {   
#            S_set_error( " VEC_cantool_init: Either 'Eval_Online_Mode_Signal_File' or 'Eval_Offline_Mode_Signal_File' defined for Device '$device' (needed for FlexRay/trace)\n", 131 );
#            return;
#        }
#               
#        if( $testbench->{'Devices'}{$device}{'Generate_Capl_Template'} ) {
#            S_w2log( 3, " VEC_cantool_init: Generate_Capl_Template\n" );
#           
#            foreach $flxr_signal ( keys %{$Flexray_Mapping} )
#            {
#                undef $pdu_name;
#                undef $frame_name;
#
#                $pdu_name = $Flexray_Mapping->{$flxr_signal}{'FR_PDU_NAME'}if ref $Flexray_Mapping->{$flxr_signal} eq 'HASH';
#                $frame_name = $Flexray_Mapping->{$flxr_signal}{'FR_FRAME_NAME'}if ref $Flexray_Mapping->{$flxr_signal} eq 'HASH';
#
#                if( defined $pdu_name ) {
#                     push( @{$all_signals_info->{ 'FrPDU' }{ $pdu_name }{ 'Signals' }} , $flxr_signal );
#                }
#                elsif( defined $frame_name and not defined $pdu_name ) {
#                     push( @{$all_signals_info->{ 'FrFrame' }{ $frame_name }{ 'Signals' }} , $flxr_signal );
#                }
#            }
#
#            VEC_trace_create_eval_capl ( $all_signals_info , $eval_offline_mode_capl_template , 'OfflineOnly' ) if $eval_offline_mode_signal_file;
#            VEC_trace_create_eval_capl ( $all_signals_info , $eval_offline_mode_capl_template , 'OnlineOffline' ) if $eval_online_mode_signal_file;
#
#            S_w2log( 3, " VEC_cantool_init: VEC_compile_all_CAPL_nodes\n" );
#            unless( VEC_compile_all_CAPL_nodes( $OLE_handle ) ) {
#                S_set_error( " call of VEC_compile_all_CAPL_nodes() failed\n" , 109);
#                return;
#            }
#            $Vector_tool_control->{'Devices'}{$device}{'Generate_Capl_Template'} = 1;
#        }else{
#            $Vector_tool_control->{'Devices'}{$device}{'Generate_Capl_Template'} = 0;
#        }
#       
#    }


# commented by kbt1cob to skip this mandatory check



    if( $keep_application_after_test = $testbench->{'Devices'}{$device}{'Keep_Application_After_Test'} ) {
        $Vector_tool_control->{'Devices'}{$device}{'Keep_Application_After_Test'} = 1;
    } else {
        $Vector_tool_control->{'Devices'}{$device}{'Keep_Application_After_Test'} = 0;
    }
   return 1;
}


#####################################################################

=head2 VEC_start_application

    OLE_handle = VEC_start_application ( application , hostname );

    device : 'CANalyzer' or 'CANoe'
    
    start application of CAN tool
    
    return OLE_handle

=cut

#####################################################################

sub VEC_start_application {
    my $device   = shift;    ## expect just 'CANalyzer' + 'CANoe'
    my $hostname = shift;

    my ( $vector_cantool_OLE_call, $device_already_running, $OLE_handle, );
    unless ( $device =~ /CANalyzer/i || $device =~ /CANoe/i ) {
        S_w2log( 2, " VEC_start_application: wrong device '$device' (just 'CANalyzer','CANoe' allowed)\n" );
        return;
    }
    return 1 if $main::opt_offline;

    $vector_cantool_OLE_call = "CANalyzer.Application" if $device =~ /CANalyzer/i;
    $vector_cantool_OLE_call = "CANoe.Application"     if $device =~ /CANoe/i;
    unless ( S_ping($hostname) ) {
        S_set_error( " Could not reach host '$hostname'  \n may be just a network problem with 'ping'-function \n anyway - try to load config again..\n", 0 );

        #      return;
    }
    if ( $device_already_running = $Vector_tool_control->{'Hostname'}{$hostname} ) {
        S_w2log( 1, " VEC_start_application: Couldnt load a second CAN tool application on host '$hostname' ($device_already_running is active) \n" );
        return;
    }

    if ( defined $LIFT_CANoe_device::CANoe_dev_control_href and $device_already_running = $LIFT_CANoe_device::CANoe_dev_control_href->{'Hostname'} ) {
        S_w2log( 1, " VEC_start_application: CAN tool application ($device_already_running) is already running on host '$hostname' (called by LIFT_CANoe_device) \n" );
        $OLE_handle = $LIFT_CANoe_device::CANoe_dev_control_href->{'OLE_handle'};
        $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'}         = $OLE_handle;
        $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'DeviceType'} = $device;
        $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'Hostname'}   = $hostname;
        $Vector_tool_control->{'Hostname'}{$hostname}                    = $device;        
        return $OLE_handle;
    }

    # If the application is running at this point then it was not started by TurboLIFT. In that case kill it.
    S_kill_process($device, $hostname);
    S_wait_ms(1000); # without wait time the application sometimes does not start after kill

    unless ( $OLE_handle = S_create_OLE( $vector_cantool_OLE_call, $hostname, \&VEC_close_application ) ) {
        return;
    }

    #Wait until the OLE handle is fetched properly
    S_wait_ms(1000);
    $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'}         = $OLE_handle;
    $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'DeviceType'} = $device;
    $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'Hostname'}   = $hostname;
    $Vector_tool_control->{'Hostname'}{$hostname}                    = $device;
    return $OLE_handle;

}

#####################################################################

=head2 VEC_get_OLE_handle

     OLE_handle = VEC_get_OLE_handle ( [ application ] );
    
    return OLE_handle for ar given application

=cut

#####################################################################

sub VEC_get_OLE_handle {

    my ( $device ) = shift ;

    if( defined $device ) {
        unless( $device eq 'CANalyzer' or $device eq 'CANoe') {
            S_set_error( " SYNTAX: VEC_get_OLE_handle( CAN_tool_application ) ['CANalyzer or 'CANoe']", 110 );
            return;
        }
        unless( defined $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
            S_set_error( " no OLE handle available for 'Device' $device", 131 );
            return;
        }
    }
    else {
        if( defined $Vector_tool_control->{'Devices'}{'CANalyzer'}{'OLE_handle'} ) {
            $device = 'CANalyzer';
        }
        elsif( defined $Vector_tool_control->{'Devices'}{'CANoe'}{'OLE_handle'} ) {
            $device = 'CANoe';
        }
        else {
            S_set_error( " no OLE handle available for any 'Device'", 131 );
            return;
        }
    }
    S_w2log( 4, " VEC_get_OLE_handle: return OLE handle of 'Device' $device\n" );
    return $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'};
}

#####################################################################

=head2 VEC_get_device_for_OLE_handle

    device = VEC_get_device_for_OLE_handle ( OLE_handle );
    return device for ar given OLE_handle

=cut

######################################################################

sub VEC_get_device_for_OLE_handle {

   my ( $OLE_handle ) = shift @_ ;
   my $device;
   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_get_device_for_OLE_handle( CAN_tool_application ) ['CANalyzer or 'CANoe']", 110 );
      return;
   }
   unless( $device = $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'DeviceType'} ) {
      S_set_error( " Could not get device for OLE_Handle\n" , 131 );
      return;
   }
   return $device;
}

######################################################################

=head2 VEC_get_hostname_for_OLE_handle

    hostname  = VEC_get_hostname_for_OLE_handle ( OLE_handle );
    return hostname for ar given OLE_handle

=cut

######################################################################

sub VEC_get_hostname_for_OLE_handle {

   my ( $OLE_handle ) = shift @_ ;

   my $hostname;

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_get_hostname_for_OLE_handle( CAN_tool_application ) ['CANalyzer or 'CANoe']", 110 );
      return;
   }
   unless( $hostname = $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'Hostname'} ) {
      S_set_error( " Could not get Hostname for OLE_Handle\n" , 131 );
      return;
   }
   return $hostname;
}

######################################################################

=head2 VEC_close_application

    VEC_close_application ( [ OLE_handle ] );
    stops measurement and closes application on CAN tool of given OLE handle
	if OLE handle is not given it will be retrieved from internal structure Vector_tool_control->{'OLE_handles'}

=cut

######################################################################

sub VEC_close_application {

    my ($OLE_handle) = shift @_;

    # ( function called without OLE handle ? )

    return 1 if $main::opt_offline;    # just return if running in offline mode

    unless ( defined $OLE_handle ) {
        S_w2rep("VEC_close_application : trying to get the OLE handle\n");
        print("VEC_close_application : trying to get the OLE handle\n");
        my @all_OLE_handles = keys %{ $Vector_tool_control->{'OLE_handles'} };
        unless ( $OLE_handle = $all_OLE_handles[0] ) {
            S_set_error("Could not resolve OLE handle");
            print("VEC_close_application : ERROR Could not resolve OLE handle\n");
            return;
        }
    }

    my $device   = $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'DeviceType'};
    my $hostname = $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'Hostname'};
    $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'}; # trial to get handle properly
    return if not defined $OLE_handle;

    if ( not defined $OLE_handle->Application ) {
        print( "VEC_close_application : probably CANoe application is alreay closed as object : OLE_handle -> Application not found. \n");
        S_w2log( 4, "VEC_close_application : probably CANoe application is alreay closed as object : OLE_handle -> Application not found");
        return;
    }
    
    if ( defined $OLE_handle->Measurement ) {
        S_w2log( 5, "VEC_close_application: OLE_handle -> Measurement -> Running() .. \n" );
        if ( $OLE_handle->Measurement->Running() ) {
            S_get_LastError_OLE();
            print("VEC_close_application: $device Stop Measurement on $hostname \n");
            S_w2log( 4, "VEC_close_application: $device Stop Measurement on $hostname \n" );
            $OLE_handle->Measurement->Stop();
            S_get_LastError_OLE();
        }
    }
    else {
        print("VEC_close_application: $device on $hostname : Measurement Object not defined !! \n");
    }

    unless ( $Vector_tool_control->{'Devices'}{$device}{'Keep_Application_After_Test'} ) {
        print("VEC_close_application: $device on $hostname Quit Application \n");
        S_w2log( 2, "VEC_close_application: $device on $hostname Quit Application \n" );
        if ( $Vector_tool_control->{'Devices'}{$device}{'Generate_Capl_Template'} ) {
            S_w2log( 2, "VEC_close_application: Store Configuration, because CAPL was updated \n" );

            # $OLE_handle -> Application -> Configuration -> Save (); # exit canoe application with out saving current configuration (for multiple testlists running)
            S_get_LastError_OLE();
        }
        my $result = $OLE_handle->Application->Quit();
        S_get_LastError_OLE();

        #Killing the application if it is still running
        S_wait_ms(1000);
        S_kill_process($device, $hostname);
    }
    delete $Vector_tool_control->{'OLE_handles'}{$OLE_handle};
    delete $Vector_tool_control->{'Hostname'}{$hostname};
    delete $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'};

    return 1;
}

######################################################################

=head2 VEC_open_configuration

 VEC_open_configuration ( $OLE_handle , $config_file [, $visible_mode] );

    Loads configuration on existing CAN-tool OLE object.
    visible_mode -> 0 : non-visible
    visible_mode -> 1 : visible

    A check of the currently loaded config will be done too

=cut

######################################################################

sub VEC_open_configuration {

   my (  $OLE_handle ,$config_file ,$visible_mode ,) = @_ ;
   my (
         $read_config_fullname ,
         $already_running_config ,
      );
   unless( defined $config_file ) {
      S_set_error( " SYNTAX: VEC_open_configuration( cantool_OLE_handle, config_file [, visible_mode])", 110 );
      return;
   }
   my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
   my $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};
   if( $already_running_config = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      if( basename( $already_running_config ) eq basename( $config_file ) ) {
         S_w2log( 4, " VEC_open_configuration: $device config '$config_file' already loaded -> return \n" );
         return 1;
      }
   }
   return 1 if $main::opt_offline; # just return if running in offline mode
   if( $visible_mode ) {
      S_w2log( 4, " VEC_open_configuration: Set $device Visible \n" );
      S_w2log( 5, " VEC_open_configuration: OLE_handle -> Application -> { 'Visible' } = 1 .. \n" );
      $OLE_handle -> Application -> { 'Visible' } = 1;
      S_get_LastError_OLE();
   }
   S_w2log( 4, " VEC_open_configuration: $device on $hostname Opening config (AutoSave=True , PromptUser=False) '$config_file' \n" );
   S_w2log( 5, " VEC_open_configuration: OLE_handle -> Application -> Open( $config_file , 1 , 0 ) .. \n" );
   $OLE_handle -> Application -> Open( $config_file , 1 , 0 );
   S_get_LastError_OLE();

   ## return when no config could be read
   return unless $read_config_fullname = VEC_read_configuration( $OLE_handle );

   return unless $read_config_fullname;
   # return when loaded config doesnt correspond with required config
   #  (CANtool is loading mostly a default config)
  unless( lc basename( $config_file ) eq lc basename( $read_config_fullname ) ) {
       S_wait_ms( 1000 );
       # try to load config 2nd time
       return unless $read_config_fullname = VEC_read_configuration( $OLE_handle );
       unless( lc basename( $config_file ) eq lc basename( $read_config_fullname ) ) {
           S_set_error( " $device Loading config '$config_file' failed (currently loaded config: '$read_config_fullname') ", 131 );
           return;
       }
   }
   # set ONLINE mode (in case config was saved in OFFLINE)
   VEC_set_configuration_mode( $OLE_handle , 0 )
       if VEC_get_application_version ( $OLE_handle , 'Major' ) >= 6;
   $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} = $config_file ;

   return 1;
}

######################################################################

=head2 VEC_read_configuration

    FullName = VEC_read_configuration ( $OLE_handle );

    Read the full name of currently loaded configuration on existing CAN-tool OLE object.

=cut 

######################################################################

sub VEC_read_configuration {

   my ( $OLE_handle ) = shift @_ ;
   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_read_configuration( cantool_OLE_handle )", 110 );
      return;
   }
   my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
   my $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};

   return 1 if $main::opt_offline; # just return if running in offline mode

   S_w2log( 5, " VEC_read_configuration: FullName = OLE_handle -> Application -> Configuration -> { 'FullName' } .. \n" );
  my $FullName = $OLE_handle -> Application -> Configuration -> { 'FullName' };

   S_get_LastError_OLE();
   unless( defined $FullName ) {
      S_set_error( " '$device' on $hostname Couldnt read currently loaded configuration: $! ", 131 );
      return;
   }
   S_w2log( 4, " VEC_read_configuration: $device '$FullName' (host: $hostname)\n" );
   return $FullName;
}


######################################################################

=head2 VEC_start_measurement

      VEC_start_measurement ( $OLE_handle );

    check if measurement is running on CAN tool given by OLE_handle

=cut

######################################################################

sub VEC_start_measurement
{

   my ( $OLE_handle ) = shift @_ ;

   my ( $device , $hostname );

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_start_measurement( cantool_OLE_handle )", 110 );
      return;
   }
   unless( $device = VEC_get_device_for_OLE_handle( $OLE_handle ) ) { return }
   unless( $hostname = VEC_get_hostname_for_OLE_handle( $OLE_handle ) ) { return }

   if( VEC_check_running( $OLE_handle ) ) {
      S_w2log( 4, " VEC_start_measurement : measurement has been started already ( $device on $hostname )\n" );
      return 1;
   }
   S_w2log( 3, " VEC_start_measurement : start $device Measurement on $hostname\n" );
   return 1 if $main::opt_offline; # just return if running in offline mode
   S_w2log( 5, " VEC_start_measurement : OLE_handle -> Measurement -> Start() .. \n" );
   $OLE_handle -> Measurement -> Start();
   if( my $err = S_get_LastError_OLE() ) {
        S_wait_ms( 1000 );
        S_w2log( 5, " VEC_start_measurement : trying 2nd time : OLE_handle -> Measurement -> Start() .. \n" );
        $OLE_handle -> Measurement -> Start();
        if( $err = S_get_LastError_OLE() ) {
            S_set_error( " Couldnt start '$device' CAN measurement on $hostname" , 131 );
            return 0;
        }
   }
   return 1 if VEC_check_running( $OLE_handle );

   S_wait_ms( 200 );
   return 1 if VEC_check_running( $OLE_handle );
   S_wait_ms( 500 );
   return 1 if VEC_check_running( $OLE_handle );
   S_wait_ms( 1500 );
   return 1 if VEC_check_running( $OLE_handle );
   S_wait_ms( 5000 );
   return 1 if VEC_check_running( $OLE_handle );
   S_set_error( " Couldnt start '$device' CAN measurement on '$hostname'" , 131 );
   return 0;
}

######################################################################

=head2 VEC_stop_measurement
    
    $return_value = VEC_stop_measurement ( $OLE_handle );

Check if measurement is running on CAN tool for the given OLE_handle  

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe application. 

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful and Offline , undef : Failure

=back

B<Examples:>  
 
 $return_value = VEC_stop_measurement ( $OLE_handle );
 
=cut

######################################################################

sub VEC_stop_measurement {

    my ($OLE_handle) = shift @_;

    unless ( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VEC_stop_measurement( cantool_OLE_handle )", 110 );
        return;
    }

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 4, " VEC_stop_measurement : measurement has been stopped already \n" );
        return 1;
    }

    my $device   = $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'DeviceType'};
    my $hostname = $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'Hostname'};

    S_w2log( 3, " VEC_stop_measurement : Stop $device Measurement on $hostname .. \n" );

    if ($main::opt_offline) {    # just return if running in offline mode
        S_w2log( 5, "not done in offline mode\n" );
        return 1;
    }

    S_w2log( 5, " VEC_stop_measurement : OLE_handle -> Measurement -> Stop() .. \n" );
    $OLE_handle->Measurement->Stop();

    if ( $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'LogFileConfig'}{'IncrementAfterTrigger'} == 1 ) {
        $OLE_handle->Application->Configuration->Save();    #save the configuration after the measurement is stopped and incase IncrementAfterTrigger option is checked
    }

    S_w2log( 3, "done\n" );
    if ( my $err = S_get_LastError_OLE() ) {
        S_wait_ms(1000);
        S_w2log( 5, " VEC_start_measurement : trying 2nd time : OLE_handle -> Measurement -> Stop() .. \n" );
        $OLE_handle->Measurement->Stop();
        if ( $err = S_get_LastError_OLE() ) {
            S_set_error( " Couldnt stop '$device' CAN measurement on '$hostname'", 131 );
            return 0;
        }
    }

    return 1 unless VEC_check_running($OLE_handle);

    foreach ( ( 100, 200, 500, 1500, 5000, 10000, 10000, 20000, 40000, 80000 ) ) {
        S_wait_ms($_);
        return 1 unless VEC_check_running($OLE_handle);
        S_w2log( 4, " VEC_stop_measurement : measurement is still running ?!?! \n" );
    }
    S_set_error( "could not stop measurement", 131 );
    return;
}
######################################################################

=head2 VEC_check_running

      VEC_check_running ( $OLE_handle );

check if measurement is running on CAN tool given bei OLE_handle

=cut

######################################################################

sub VEC_check_running {

   my ( $OLE_handle ) = shift @_ ;

   my ( $device , $hostname , $status );

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_check_running( cantool_OLE_handle )", 110 );
      return;
   }

   unless( $Vector_tool_control->{'OLE_handles'}{ $OLE_handle } ) {
      S_set_error( " invalid OLE handle ", 109 );
      return;
   }

   return 1 if $main::opt_offline; # just return if running in offline mode

   unless( $device = VEC_get_device_for_OLE_handle( $OLE_handle ) ) { return }
   unless( $hostname = VEC_get_hostname_for_OLE_handle( $OLE_handle ) ) { return }

   S_w2log( 5 , "VEC_check_running : OLE_handle -> Measurement -> Running() .. \n" );
   $status = $OLE_handle -> Measurement -> Running();
   if( my $err = S_get_LastError_OLE() ) {
        S_wait_ms( 1000 );
        S_w2log( 5, " VEC_check_running : trying 2nd time : OLE_handle -> Measurement -> Running() .. \n" );
        $status = $OLE_handle -> Measurement -> Running();
        if( $err = S_get_LastError_OLE() ) {
            S_set_error( " Couldnt check '$device' CAN measurement on $hostname" , 131 );
            return 0;
        }
   }

   if( my $err = S_get_LastError_OLE() ) {  S_set_error( " OLE exception : '$err' (after OLE_handle -> Measurement -> Running())" , 131 ); return }

   if( $status ) {
       S_w2log( 5 , "VEC_check_running : '$device' on '$hostname' is running \n" );
       return 1;
   }
   else {
       S_w2log( 5 , "VEC_check_running : '$device' on $hostname is NOT running \n" );
       return 0;
   }
}

######################################################################

=head2 VEC_trace_configure

    VEC_trace_configure ( CAN_tool );

CAN_tool : "CANalyzer" or "CANoe"

function prepare the CAN tool that the trace can be started immediately with VEC_trace_start

=cut

######################################################################

sub VEC_trace_configure
{

   my $device  = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_trace_configure( CAN_tool )", 110 );
      return;
   }
   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_trace_configure : OnlineConfiguration already loaded \n" );
      }
      else {
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_trace_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   return $OLE_handle;
}

######################################################################

=head2 VEC_trace_store

    $store_file_name = VEC_trace_store ( $OLE_handle ( , [$store_file_name] );

Store the current Logfile of CAN Online Configuration under $store_file_name.
If no store_file_name given then it will be stored under report folder.

return value is the store_file_name

=cut

######################################################################

sub VEC_trace_store
{
   my ( $OLE_handle , $store_file_name ) = @_ ;

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_trace_store ( $OLE_handle [ , $store_file_name ] )", 110 );
      return;
   }

   # log file name to store (if not given then it will be stored under report folder) 
   unless ($store_file_name)    {
        my $date_extension = S_get_date_extension();
        $store_file_name = $main::REPORT_PATH . '\LIFT_can_trace_' . $date_extension . ".asc";
   }

   ## check the user setting for the Logging
   $store_file_name = VEC_logTrace_based_on_Logging_File_Config($OLE_handle, $store_file_name); 

   return $store_file_name;
}





######################################################################

=head2 VEC_trace_flxr_store_signals_file

    $store_signals_file_name = VEC_trace_flxr_store_signals_file ( $OLE_handle );

Store the current SIGANALS FILE of FLXR Online Configuration.
FLXR signals will be stored in Testdocumentation and returned

return value is the store_signals_file_name
return -1 if ONLINE signals file  ('Eval_Online_Mode_Signal_File') is not defined in testbench config

=cut

######################################################################

sub VEC_trace_flxr_store_signals_file
{
    my $OLE_handle = shift ;

    my ( $store_signals_file_name );

    unless( defined $OLE_handle ) {
       S_set_error( " SYNTAX: VEC_trace_flxr_store_signals_file( cantool_OLE_handle )", 110 );
       return;
    }

    my $date_extension = S_get_date_extension(time());
    unless( -d $main::LIFT_ATD_TEMP ) {
       unless( mkdir $main::LIFT_ATD_TEMP ,0777 ) { S_set_error( "mkdir $main::LIFT_ATD_TEMP failed" , 1 ); return }
    }
    # new file name (storage destination)
    $store_signals_file_name = $main::LIFT_ATD_TEMP."LIFT_flxr_signals_file_".$date_extension.".asc";


    my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};

    return 1 if $main::opt_offline; # just return if running in offline mode

    ## default logfile was validated in VEC_cantool_init already
    my $signals_logfile =  $Vector_tool_control->{'Devices'}{$device}{'Eval_Online_Mode_Signal_File'}; # ONLINE MODE !!!

    unless( defined $signals_logfile ) {
       S_set_error( " ONLINE Signals logfile ('Eval_Online_Mode_Signal_File') on '$device' is not defined in Testbench config : '$signals_logfile'\n" , 0 );
       return -1;
    }

    if( -f $signals_logfile ) {
        S_w2log( 4, " VEC_trace_flxr_store_signals_file : Found $device Signals Logfile : $signals_logfile\n" );
    }
    else {
        S_set_error( " Couldnt find '$device' SIgnals logfile : '$signals_logfile'\n" , 131 );
        return;
    }

    S_w2log( 3, " VEC_trace_flxr_store_signals_file : Copy '$signals_logfile' -> $store_signals_file_name \n" );
    unless( copy ( $signals_logfile , $store_signals_file_name ) ) {
        S_set_error( " copy ( '$signals_logfile' , '$store_signals_file_name' ) : $! \n" , 1 );
        return;
    }

    return $store_signals_file_name;

}


######################################################################

=head2 VEC_trace_can_get_dataref

    $trace_data_ref = VEC_trace_can_get_dataref ( $CAN_tool_trace , @CAN_signal_or_message_list );

    Structure of returned trace_data_ref is:

    $trace_data_ref = {
                        'timestamp_1' => {
                                       'message_A' => {
                                                        'DLC_A1' =>'DLC_A1' ,
                                                        'DATA_A1' => 'DATA_1'
                                                      }
                                       'signal_1' => 'phys_value_at_time_1',
                                       'signal_2' => 'phys_value_at_time_1',
                                       'message_B' => {
                                                        'DLC_B1' =>'DLC_B1' ,
                                                        'DATA_B1' => 'DATA_B1'
                                                      },
                                       'signal_3' => 'phys_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                       'message_A' => {
                                                        'DLC_A2' =>'DLC_A2' ,
                                                        'DATA_A2' => 'DATA_A2'
                                                      }
                                       'signal_1' => 'phys_value_at_time_2',
                                       'signal_2' => 'phys_value_at_time_2',
                                       'message_B' => {
                                                        'DLC_B2' =>'DLC_B2' ,
                                                        'DATA_B2' => 'DATA_B2'
                                                      },
                                       'signal_3' => 'phys_value_at_time_2',
                                          },
                     };

=cut

######################################################################

sub VEC_trace_can_get_dataref {
    my $can_trace_file = shift;
    my @given_can_signals_or_messages = @_;

    #
    # if somebody send an ARRAY_REF instead of ARRAY...
    #
    if( ref $given_can_signals_or_messages[0] eq 'ARRAY' ) {
        my @temp = @{ $given_can_signals_or_messages[0] };
        @given_can_signals_or_messages = @temp;
    }

   unless( @given_can_signals_or_messages ) {
      S_set_error( " SYNTAX: VEC_trace_can_get_dataref( '$can_trace_file' , @given_can_signals_or_messages )", 110 ); return;
    }

    my $ReturnDataRef = {};    # < - - declared as hash ref initially

    my (
        $data_format ,
        $timestamps ,
        $can_signal ,
        $NeededMsgs ,
        $msg_name ,
        $DLC ,
        $ID_dec ,
        $ID_hex ,
        $ID ,
        $found_messages ,
        $signal_data_ref ,
        $value ,
        $can_bus_nbr ,
        $can_bus_nbr_2ndtry ,
        $CAN_bus_cables_changed_flag ,
        $just_message_infos ,
        $just_signal_infos ,
        $label_mapping ,
      );

    unless( ( $data_format , $timestamps ) = VEC_trace_can_analyze_format( $can_trace_file ) ) {
      S_set_error( " couldnt determine format of CAN trace '$can_trace_file'" , 131 );
      return;
    }

    unless( $timestamps =~ /absolut/i ) {
      S_set_error( " timestamps in trace must be configured as 'absolute'" , 131 );
      return;
    }
   return $dummy_href if $main::opt_offline; # just return if running in offline mode

    foreach my $can_signal_or_message ( @given_can_signals_or_messages ) {

      if( my $mapped_signal = $main::ProjectDefaults->{'LABEL_MAPPING'}{ $can_signal_or_message } ) {
          S_w2log( 3 , " VEC_trace_can_get_dataref: found mapping '$can_signal_or_message' --> '$mapped_signal'\n" );
          $label_mapping->{ $mapped_signal } = $can_signal_or_message;
          $can_signal_or_message = $mapped_signal;
      }

    my $CAN_Mapping = S_get_contents_of_hash(['Mapping_CAN']);

    unless( $CAN_Mapping ) {
        S_set_error( " LIFT CAN_mapping doesnot exist" , 0 );
    }

      if( $CAN_Mapping ->{ 'CAN_MESSAGES' }{ $can_signal_or_message } ) {
          # message infos are requested
          $msg_name = $can_signal_or_message ;
          undef $can_signal;

          $just_message_infos = 1 ;
          $just_signal_infos = 0 ;
      }
      else {
          # signal infos are requested
          $can_signal = $can_signal_or_message ;
          undef $msg_name;
          unless( $msg_name = $CAN_Mapping ->{$can_signal}{'MESSAGE'} ) {
             S_set_error( " VEC_trace_can_get_signal_data: no 'MESSAGE' defined for CAN signal '$can_signal' in CAN MAPPING\n" , 109);
             return;
          }
          $just_message_infos = 0 ;
          $just_signal_infos = 1 ;
      }

      unless( $can_bus_nbr = $CAN_Mapping->{ 'CAN_MESSAGES' }{ $msg_name }{ 'CAN_BUS_NBR' } ) {
         S_set_error( " VEC_trace_can_get_signal_data: no 'CAN_BUS_NBR' defined for CAN message '$msg_name' in CAN MAPPING\n" , 109);
         return;
      }

#       unless( $can_bus_nbr =~ /1|2/ ) {
#          S_set_error( " VEC_trace_can_get_signal_data: unexpected 'CAN_BUS_NBR' ($can_bus_nbr) defined for CAN message '$msg_name' in CAN MAPPING (only 1 or 2)\n" , 109);
#          return;
#       }

      $ID_dec = $CAN_Mapping->{'CAN_MESSAGES'}{$msg_name}{'ID'};
      if( $ID_dec > 0x1FFFFFFF ) {
          S_w2log( 5, " VEC_trace_can_get_dataref: given ID $ID_dec (dec) / 0x".uc sprintf( "%x" , $ID_dec)." (hex) is greater the 29 bit ; sometime 100 is added to 29bit IDs (EXT identifier)\n" );
          $ID_dec = $ID_dec & 0x1FFFFFFF;  # mask with 29bit
          S_w2log( 5, " VEC_trace_can_get_dataref: changed to $ID_dec (dec) / 0x".uc sprintf( "%x" , $ID_dec)." (hex) \n" );
      }

      $ID_hex = uc sprintf( "%x" , $ID_dec );
      $ID = $ID_dec if $data_format =~ /dec/i ;
      $ID = $ID_hex if $data_format =~ /hex/i ;

      $CAN_bus_cables_changed_flag = 0;

      unless( $found_messages = $NeededMsgs->{ $msg_name }{ 'FOUND' } ) {
         $found_messages = VEC_trace_can_get_message_data( $can_trace_file , $ID , $can_bus_nbr );
         unless( defined $found_messages ) {
            # try another CAN bus nbr in case the cables are wrong
            if( $can_bus_nbr == 1 ) { $can_bus_nbr_2ndtry = 2 } else { $can_bus_nbr_2ndtry = 1 }
            S_w2log( 3, " VEC_trace_can_get_dataref: try another CAN bus nbr : $can_bus_nbr_2ndtry \n" );
            if( $found_messages = VEC_trace_can_get_message_data( $can_trace_file , $ID , $can_bus_nbr_2ndtry ) ) {
                $CAN_bus_cables_changed_flag = 1;
            }
         }

         ## then search with the symbolic name from CAN mapping
         unless( defined $found_messages ) {
            $found_messages = VEC_trace_can_get_message_data( $can_trace_file , $msg_name , $can_bus_nbr );
             unless( defined $found_messages ) {
                # try another CAN bus nbr in case the cables are wrong
                if( $can_bus_nbr == 1 ) { $can_bus_nbr_2ndtry = 2 } else { $can_bus_nbr_2ndtry = 1 }
                S_w2log( 3, " VEC_trace_can_get_dataref: try another CAN bus nbr : $can_bus_nbr_2ndtry \n" );
                if( $found_messages = VEC_trace_can_get_message_data( $can_trace_file , $msg_name , $can_bus_nbr_2ndtry ) ) {
                    $CAN_bus_cables_changed_flag = 1;
                }
             }
         }

         if( $CAN_bus_cables_changed_flag ) {
            S_w2log( 2 , " VEC_trace_can_get_dataref: Signal|Message '$can_signal_or_message' found on another CAN bus nbr ($can_bus_nbr_2ndtry) than expected ($can_bus_nbr)\n ==> CHECK your CAN cables\n " , 'blue' );
         }

         unless( $found_messages )  {
            $NeededMsgs->{ $msg_name }{ 'FOUND' } = 'NOT_FOUND' ;
            S_w2log( 3, " VEC_trace_can_get_dataref : couldnt find CAN message $msg_name \n" ) if $just_message_infos;
            S_w2log( 3, " VEC_trace_can_get_dataref : couldnt find CAN message $msg_name for (signal : $can_signal) \n" ) if $just_signal_infos;
            next;
         }

         $NeededMsgs->{ $msg_name }{ 'FOUND' } = $found_messages ;

          if( $just_message_infos ) {
              foreach my $time_stamp ( sort {$a<=>$b} keys %$found_messages ) {
                 $DLC = $found_messages->{ $time_stamp }{'DLC'};
                 my $data = $found_messages->{ $time_stamp }{'DATA'};
                 $ReturnDataRef->{ $time_stamp }{ $msg_name }{'DLC'} = $DLC;
                 $ReturnDataRef->{ $time_stamp }{ $msg_name }{'DATA'} = $data;
                 if( my $label = $label_mapping->{ $msg_name } )
                    {
                        $ReturnDataRef->{$time_stamp}{$label}{'DLC'} = $DLC;
                        $ReturnDataRef->{$time_stamp}{$label}{'DATA'} = $data;
                    }
              }
              next ;
          }
      }

      if ($NeededMsgs->{ $msg_name }{ 'FOUND' } eq 'NOT_FOUND'){
            S_w2log( 3, " VEC_trace_can_get_dataref : couldnt find CAN message $msg_name \n" ) if $just_message_infos;
            S_w2log( 3, " VEC_trace_can_get_dataref : couldnt find CAN message $msg_name for (signal : $can_signal) \n" ) if $just_signal_infos;
            next;
      }

        $signal_data_ref = VEC_trace_can_get_signal_data( $found_messages , $can_signal , $data_format );

      foreach my $time_stamp ( sort {$a<=>$b} keys %$signal_data_ref ) {
         $value = $signal_data_ref->{ $time_stamp };
         $ReturnDataRef->{ $time_stamp }{ $can_signal } = $value;
         if( my $label = $label_mapping->{ $can_signal } ) { $ReturnDataRef->{$time_stamp}{$label}= $value }
      }
    }

    return $ReturnDataRef;
}

######################################################################

=head2 VEC_trace_can_get_message_data

    $message_ref = VEC_trace_can_get_message_data ( $can_log_file , $can_frame , $can_bus_nbr );

Reads a single frame from a Canalyzer logfile. $can_log_file is the full name of the logfile.
$can_frame is symbolic name or decimal or hexadecimal value of the CAN frame in the logfile.
Returns reference to hash structure:

      $message_ref->{$timestamp}{'DLC'} = DLC;
      $message_ref->{$timestamp}{'DATA'} = raw bytes of message;

=cut

######################################################################

sub VEC_trace_can_get_message_data
{

   my $can_log_file = shift;
   my $can_message  = shift;
   my $can_bus_nbr = shift;

   my ($msg_cnt, $all_msgs, $time_stamp, $dlc, $data, $other);

   unless (defined( $can_message )) {
     S_set_error( "SYNTAX: VEC_trace_can_get_message_data( can_log_file , can_message , can_bus_nbr)", 110 ); return ;
   }

   unless( defined $can_bus_nbr ) {
     $can_bus_nbr = 1;
   }

 #  return $dummy_href if $main::opt_offline; # just return if running in offline mode

   my $Trace_FH = new FileHandle;
   unless( $Trace_FH->open( $can_log_file ) ) { S_set_error( " Couldnt open CAN Trace '$can_log_file' ", 131 ); return; }

   $msg_cnt = 0;
   S_w2log( 4, " VEC_trace_can_get_message_data : Reading CAN frame '$can_message' on Bus-Nbr $can_bus_nbr from $can_log_file)\n" );

   while( <$Trace_FH> ) {
        ## try to match:
        ##      0.0171 1  Bremse_1   Rx   d 8 00 18 00 00 FE FE 00 18
        if( /^
          \s*        # leading spaces
          (\d+\.\d+)    # timestamp
          \s+        # spaces
          $can_bus_nbr     # bus ID must be right !!!
          \s+        # spaces
          $can_message
          x?
          \s+        # spaces
          [TxRq]+      # match Rx or Tx or TxRq
          \s+        # spaces
          d
          \s+        # spaces
          (\d+)      # DLC
          \s+        # spaces
          (.+)$      # all Data and aditional info unil end of line  (e.g. 2A 34 42 FF 20 00  Length = 192000 BitCount = 100)
          /ix )
        {
            $msg_cnt++;
            $time_stamp = $1;
            $dlc = $2;
            $data = $3;

            $data =~ s/(([\da-fA-F]{2}\s*){$dlc})(.*)/$1/;   # extract sequence of bytes (number given by DLC)

            if( $3 ) { $other = $3 } else { undef $other }

            $all_msgs->{$time_stamp}{'DLC'} = $dlc;
            $all_msgs->{$time_stamp}{'DATA'} = $data;
            $all_msgs->{$time_stamp}{'OTHER'} = $other if defined $other;
        }
    }
    $Trace_FH->close;
    S_w2log( 4, " VEC_trace_can_get_message_data : Found $can_message -> $msg_cnt times\n" );

    return $all_msgs;
}


=head2 VEC_trace_canfd_get_message_data

    $canfd_msg_href = VEC_trace_canfd_get_message_data ( $canfd_log_file , $canfd_param_href );

Reads all CANFD frames defined by $canfd_param_href from a CANoe logfile ($canfd_log_file).

B<Arguments:>

=over

=item $canfd_log_file 

full name of the CANoe logfile.

=item $canfd_param_href 

Hash reference to define the CANFD frame to be fetched from log file.

    $canfd_param_href = {
        CANFD_MSG_NAME => <CANFD message name>, 
        CANFD_ID       => <CANFD ID (identifier)>,
        CANFD_CHNL_NBR => <CANFD channel number>,
    };
    
Either CANFD_MSG_NAME or CANFD_ID is required to identify the CANFD frame.
If both are given then both have to match.

If CANFD_CHNL_NBR is not given then 1 is used as default.

=back

B<Return Value:>

=over

=item $returnValue 

Reference to data hash structure:

    $message_ref->{$timestamp}{'DLC'} = <DLC>;
    $message_ref->{$timestamp}{'DATA'} = <string with raw bytes of message separated by whitespace>;

=back

B<Examples:>

    $msg_name = 'GGCC'
    $id = '100'
    $can_bus_nbr = '1'
    $returnValue = VEC_trace_canfd_get_message_data($trace_file_path, {CANFD_MSG_NAME=> $msg_name, CANFD_ID=>$id, CANFD_CHNL_NBR=>$can_bus_nbr}); 

=cut

sub VEC_trace_canfd_get_message_data {

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_trace_canfd_get_message_data ($canfd_log_file, $canfd_param_href)', @args );

    my $canfd_log_file   = shift @args;
    my $canfd_param_href = shift @args;

    #STEP verify CANFD message name and ID  & channel name
    my $canfd_message = $canfd_param_href->{CANFD_MSG_NAME};
    my $canfd_id = $canfd_param_href->{CANFD_ID};

    if( not defined $canfd_message and not defined $canfd_id ) {
        S_set_error( "VEC_trace_canfd_get_message_data: both \$canfd_param_href->{CANFD_MSG_NAME} and \$canfd_param_href->{CANFD_ID} not given. At least one of them has to be given.", 110 );
        return;
    }

    #set default value for regex
    unless ( defined($canfd_message) ) {
        $canfd_message = '\w+';
    }

    #set default value for regex
    unless ( defined($canfd_id) ) {
        $canfd_id = '\w+';
    }
    
    my $canfd_bus_nbr =  $canfd_param_href->{CANFD_CHNL_NBR};
    $canfd_bus_nbr = 1 if not defined $canfd_bus_nbr;

    my $trace_FH = new FileHandle;
    unless ( $trace_FH->open($canfd_log_file) ) { S_set_error( " Couldnt open CANoe Trace '$canfd_log_file' ", 131 ); return; }

    my ( $msg_cnt, $all_msgs, $time_stamp, $dlc, $data, $other, $messageRead );

    $msg_cnt = 0;
    S_w2log( 4, " VEC_trace_canfd_get_message_data: : Reading CANFD message '$canfd_message', CANFD ID = '$canfd_id' on Bus-Nbr '$canfd_bus_nbr' from file '$canfd_log_file')\n" );

    #STEP Parse the CANoe trace & fetch CANFD data for input 'CANFD' message
    while (<$trace_FH>) {
        ## try to match:
        ##   6.249610 CANFD   1 Rx        650  ProDiag_Request                  0 0 8  8 03 00 a5 a8 ff ff ff ff   236015  122   200000     33e8 50052050 4b080250 201f0002 20010104
        ##   1.990428 CANFD   1 Rx        650                                   0 0 8  8 03 00 a5 a8 ff ff ff ff   236000  122   200000     33e8 50052050 4b080250 201f0002 20010104

        if (
            /^
           \s*            # leading spaces
           (\d+\.\d+)     # <TIME>     -> timestamp
           \s+            # spaces
           CANFD          # CANFD      -> Fixed name for CANFD
           \s+            # spaces
           $canfd_bus_nbr # <Channel>  -> bus ID -> CANFD channel
           \s+            # spaces
           [TxRq]+        # <DIR>  match Rx or Tx or TxRq
           \s+            # spaces
           $canfd_id      # <ID>   -> CAN FD ID 
           x?
           \s+?           # spaces, try to match one or more space , but less is better   
           (\s+|$canfd_message)        # <SymbolicName> -> CANFD message name (Optional)
           \s+
           \d+            #  <BRS>  -> not used
           \s+            #  spaces
           \d+            #  <ESI>  -> not used
           \s+            # spaces
           [a-fA-F0-9]+   #  <DLC>  -> ignore this
           \s+            # spaces
           (\d+)          #  <DataLength> data lenth count
           \s+            # spaces
           (.+)$          # all Data and aditional info unil end of line  (e.g. 02 00 00 00 00 00 00 00   246000  126   220040     5f51 50052050 4b080250 201f0002 20010104)
           /ix
          )
        {
            $msg_cnt++;
            $time_stamp  = $1;
            $messageRead = $2;
            $dlc         = $3;
            $data        = $4;

            $data =~ s/(([\da-fA-F]{2}\s*){$dlc})(.*)/$1/;    # extract sequence of bytes (number given by DLC)

            if ($3) { $other = $3 }
            else    { undef $other }

            $all_msgs->{$time_stamp}{'DLC'}   = $dlc;
            $all_msgs->{$time_stamp}{'DATA'}  = $data;
            $all_msgs->{$time_stamp}{'OTHER'} = $other if defined $other;
        }
    }
    $trace_FH->close;
    # STEP return the hash reference with found CANFD data.
    $messageRead = $canfd_id if ( not defined $messageRead or $messageRead =~ /^\s+$/);
    S_w2log( 4, " VEC_trace_canfd_get_message_data : Found message '$messageRead' -> $msg_cnt times\n" );

    return $all_msgs;
}


=head2 VEC_trace_sysVar_get_data

    $all_sysVars_href = VEC_trace_sysVar_get_data($can_log_file, $fullQualifiedSysVarName);

Get system variable time stamp and value from the trace file and return reference to hash structure.

 Return structure : 
      $allSysVar_ref->{$timestamp}{'DATA'} = <value of system variable>;
            
Example :  

  VEC_trace_sysVar_get_data ($can_log_file, 'LIFT_CAN_access::SysVar_Type_Float' )

Remark :
 
 -> One use case :- called by function : "CA_trace_get_dataref" where get the timestamps of system variable(s) along with messages & signals
 -> works only with system variabe of data type int or float    
       
=cut

sub VEC_trace_sysVar_get_data {

   my @args = @_;
   return unless S_checkFunctionArguments( 'VEC_trace_sysVar_get_data ($can_log_file, $fullQualifiedSysVarName)', @args );

   my $can_log_file 			= shift @args;
   my $fullQualifiedSysVarName  = shift @args;

   my ($sysVar_cnt, $all_sysVars_href, $time_stamp, $data );

   my $Trace_FH ;
   unless(open( $Trace_FH , "< $can_log_file")  ) {
        S_set_error( " Couldnt open CAN Trace '$can_log_file' ", 131 );
        return;
   }
   
   $sysVar_cnt = 0;
   S_w2log( 4, " VEC_trace_sysVar_get_data : read system variable '$fullQualifiedSysVarName' from $can_log_file)\n" );

   while( my $line = <$Trace_FH> ) {
        ## try to match:
        ##         0.038080    SV: 2 0 1 ::LIFT_CAN_access::SysVar_Type_Int = ff
        if ($line =~ m/^ 
			\s*        # leading spaces
	        (\d+\.\d+) # timestamp          
			\s+        # some spaces
			SV:        # keyword for system variable    
			\s+        # some spaces
			\d+        # some digit
			\s+        # some spaces
			\d+        # some digit
			\s+		   # some spaces	
			\d+        # some digit 
			\s+        # some spaces    
			[::]+
			$fullQualifiedSysVarName 	# full qualified system variable name
			\s+        # some spaces 
			=
			\s+
			([a-fA-F0-9.]+)    # decimal or hex values
			/x)
	    {
            $sysVar_cnt++;
            $time_stamp = $1;
			$data = $2 ;
			
			$all_sysVars_href->{$time_stamp}{'DATA'} = $data;
        }
    }
    close ($Trace_FH);
    S_w2log( 4, " VEC_trace_sysVar_get_data : Found $fullQualifiedSysVarName -> $sysVar_cnt times\n" , 'GoldenRod');
    return $all_sysVars_href;
	
}



######################################################################

=head2 VEC_trace_can_get_signal_data

    $signal_data_ref = VEC_trace_can_get_signal_data( $found_messages , $can_signal , $data_format );

Reads a single Signal from a message data ref read by VEC_trace_can_get_message_data.

$found_messages = {
                     timestamp1 => {
                                    'DATA' =>  '00 18 00 00 FE FE 00 18',
                                    },
                     timestamp2 => {
                                    'DATA' =>  '00 18 00 00 FE FE 00 18',
                                    },
                 };

$can_signal is the name of CAN signal in LIFT CAN Mapping

$data_format is format of data in CAN trace : 'dec' or 'hex'

Returns hash ref structure:

      $signal_data_ref = {
                           $timestamp1 => $phys_value1,
                           $timestamp2 => $phys_value2,
                        };

The Values are already the needed

=cut

######################################################################

sub VEC_trace_can_get_signal_data
{

    my $all_msgs = shift;
    my $can_signal = shift;
    my $data_format = shift;         ### DEC or HEX

    my (
         $data_raw ,
         @data_list ,
         $signal_length ,
         $signal_factor ,
         $signal_offset ,
         $signal_format ,     ### INTEL or MOTOROLA
         $signal_start_bit ,
         $signal_type ,

         $signal_MX_Master,
         $signal_MX_Master_value_phys ,
         $signal_MX_Master_length ,
         $signal_MX_Master_factor ,
         $signal_MX_Master_offset ,
         $signal_MX_Master_format ,     ### INTEL or MOTOROLA
         $signal_MX_Master_start_bit ,
         $signal_MX_Master_type ,
         $signal_MX_Master_code_value ,
         $multiplex_type ,

         $can_frame_bin ,
         $byte_value ,
         $byte_bin_lsb ,
         $signal_lsb ,
         $signal_msb ,
         $signal_raw_value ,
         $sig_value_phys ,
         $sig_data_ref ,
         $dlc ,
         $temp_sig_pos_start ,
         $temp_can_frame_bin ,
         $signal_msb_without_sign ,
         $signal_msb_without_sign_compl ,
         $sign_factor ,
      );

    unless (defined( $data_format )) {
        S_set_error( "VEC_trace_can_get_signal_data: SYNTAX: VEC_trace_can_get_signal_data ( message_ref, can_signal, base_format )", 110 );
        return;
    }
    
    
    # Here we are using plain integer variables to speed up the loops later.
    # Pattern matching in the loops is too slow
    # Also using constants in the loops is too slow
    my $format_dec = 1;
    my $format_hex = 2;

    if( $data_format =~ /dec/i ) {
        $data_format = $format_dec;
    }
    elsif($data_format =~ /hex/i){
        $data_format = $format_hex;
    }
    else {
        S_set_error( "VEC_trace_can_get_signal_data: parameter 'base' must be 'dec' or 'hex'", 114 ); #110 before
        return;
    }    

    my $CAN_Mapping = S_get_contents_of_hash(['Mapping_CAN']); 

    unless( $CAN_Mapping ) {
        S_set_error( " LIFT CAN_Mapping doesnot exist" , 20 );
        return;
    }

    $signal_length = $CAN_Mapping->{ $can_signal }{'LENGTH'};

    unless( defined $signal_length ) {
       S_set_error( " VEC_trace_can_get_signal_data: no 'LENGTH' defined for CAN signal '$can_signal' in CAN MAPPING\n" , 109);
       return;
    }

    $signal_offset = $CAN_Mapping->{ $can_signal }{'OFFSET'};
    unless( defined $signal_offset ) {
       S_set_error( " VEC_trace_can_get_signal_data: no 'OFFSET' defined for CAN signal '$can_signal' in CAN MAPPING\n" , 109);
       return;
    }

    $signal_factor = $CAN_Mapping->{ $can_signal }{'FACTOR'};
    unless( defined $signal_factor ) {
       S_set_error( " VEC_trace_can_get_signal_data: no 'FACTOR' defined for CAN signal '$can_signal' in CAN MAPPING\n" , 109);
       return;
    }

    $signal_format = $CAN_Mapping->{ $can_signal }{'FORMAT'};
    unless( defined $signal_format ) {
       S_set_error( " VEC_trace_can_get_signal_data: no 'FORMAT' defined for CAN signal '$can_signal' in CAN MAPPING\n" , 109);
       return;
    }
    
    # Here we are using plain integer variables to speed up the loops later.
    # Pattern matching in the loops is too slow
    # Also using constants in the loops is too slow
    my $format_intel = 1;
    my $format_motorola = 2;

    if( $signal_format =~ /INTEL/i ){
        $signal_format = $format_intel;
    }
    elsif( $signal_format =~ /MOTOROLA/i ){
        $signal_format = $format_motorola;
    }
    else{
        S_set_error( "VEC_trace_can_get_signal_data: 'FORMAT' of signal '$can_signal' in CAN Mapping must be INTEL or MOTOROLA", 110 );
        return;
    }

    $signal_start_bit = $CAN_Mapping->{ $can_signal }{'STARTBIT'};
    unless( defined $signal_start_bit ) {
       S_set_error( " VEC_trace_can_get_signal_data: no 'FORMAT' defined for CAN signal '$can_signal' in CAN MAPPING\n" , 109);
       return;
    }

    $signal_type = $CAN_Mapping->{ $can_signal }{'TYPE'};
    unless( defined $signal_type ) {
       S_set_error( " VEC_trace_can_get_signal_data: no 'TYPE' defined for CAN signal '$can_signal' in CAN MAPPING\n" , 109);
       return;
    }
    unless ( $signal_type =~ /^SIGNED/i or $signal_type =~ /^UNSIGNED/i) {
        S_set_error( "VEC_trace_can_get_signal_data: 'TYPE' of signal '$can_signal' in CAN Mapping must be SIGNED or UNSIGNED", 110 );
        return;
    }

    $signal_MX_Master = $CAN_Mapping->{ $can_signal }{'MULTIPLEX'}{'MASTER'};
    $signal_MX_Master_code_value = $CAN_Mapping->{ $can_signal }{'MULTIPLEX'}{'CODE'};
    if(defined $signal_MX_Master and not defined $signal_MX_Master_code_value) {
        $multiplex_type = 'MASTER';
    }elsif(defined $signal_MX_Master and defined $signal_MX_Master_code_value) {
        $multiplex_type = 'SLAVE';
        S_w2log( 3 , " VEC_trace_can_get_signal_data : MULTIPLEX SLAVE signal '$can_signal' (MASTER='$signal_MX_Master' CODE='$signal_MX_Master_code_value')\n"  );
    }elsif(not defined $signal_MX_Master and defined $signal_MX_Master_code_value) {
        S_set_error( "VEC_trace_can_get_signal_data: wrong signal config ('CODE' defined but not 'MASTER' defined)", 110 );
        return;
    }else {
        $multiplex_type = 'NO_MULTIPLEX';
    }


    if( $multiplex_type eq 'SLAVE' ) {

        $signal_MX_Master_length = $CAN_Mapping->{ $signal_MX_Master }{'LENGTH'};
        unless( defined $signal_MX_Master_length ) {
           S_set_error( " VEC_trace_can_get_signal_data: no 'LENGTH' defined for CAN signal '$signal_MX_Master' in CAN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_offset = $CAN_Mapping->{ $signal_MX_Master }{'OFFSET'};
        unless( defined $signal_MX_Master_offset ) {
           S_set_error( " VEC_trace_can_get_signal_data: no 'OFFSET' defined for CAN signal '$signal_MX_Master' in CAN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_factor = $CAN_Mapping->{ $signal_MX_Master }{'FACTOR'};
        unless( defined $signal_MX_Master_factor ) {
           S_set_error( " VEC_trace_can_get_signal_data: no 'FACTOR' defined for CAN signal '$signal_MX_Master' in CAN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_format = $CAN_Mapping->{ $signal_MX_Master }{'FORMAT'};
        unless( defined $signal_MX_Master_format ) {
           S_set_error( " VEC_trace_can_get_signal_data: no 'FORMAT' defined for CAN signal '$signal_MX_Master' in CAN MAPPING\n" , 109);
           return;
        }

        if( $signal_MX_Master_format =~ /INTEL/i ){
            $signal_MX_Master_format = $format_intel;
        }
        elsif( $signal_MX_Master_format =~ /MOTOROLA/i ){
            $signal_MX_Master_format = $format_motorola;
        }
        else{
            S_set_error( "VEC_trace_can_get_signal_data: 'FORMAT' of signal '$signal_MX_Master' in CAN Mapping must be INTEL or MOTOROLA", 110 );
            return;
        }

        $signal_MX_Master_start_bit = $CAN_Mapping->{ $signal_MX_Master }{'STARTBIT'};
        unless( defined $signal_MX_Master_start_bit ) {
           S_set_error( " VEC_trace_can_get_signal_data: no 'FORMAT' defined for CAN signal '$signal_MX_Master' in CAN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_type = $CAN_Mapping->{ $signal_MX_Master }{'TYPE'};
        unless( defined $signal_MX_Master_type ) {
           S_set_error( " VEC_trace_can_get_signal_data: no 'TYPE' defined for CAN signal '$signal_MX_Master' in CAN MAPPING\n" , 109);
           return;
        }
        unless ( $signal_MX_Master_type =~ /^SIGNED/i or $signal_MX_Master_type =~ /^UNSIGNED/i) {
            S_set_error( "VEC_trace_can_get_signal_data: 'TYPE' of signal '$signal_MX_Master' in CAN Mapping must be SIGNED or UNSIGNED", 110 );
            return;
        }
    }

    foreach my $time_stamp ( sort {$a<=>$b} keys %$all_msgs ){
        $data_raw = $all_msgs->{$time_stamp}{ 'DATA' };  $data_raw =~ s/^\s+//g;  ## remove possible leading spaces
        ## convert string to list of data bytes ( $data_list[0] eq CAN Byte 0)
        @data_list = split( /\s+/ , $data_raw);
        $can_frame_bin = "";  ## CAN frame binary format (LSB)

        foreach my $data_byte (@data_list) {
            ## converts 'F0' into '00001111' (LSB format) (starting with lowest significant bit))
            ##   PERL lesson:
            ##                 - 'hex $data_byte' interprete given value as hexadecimal value
            ##                 - 'sprintf( "%08b",...' format the given value into 8bit format (MSB)
            ##                 - 'reverse' sort the given scalar in opposite order (that means: MSB to LSB)
            if( $data_format == $format_hex )     { $byte_value = hex $data_byte; } 
            elsif ( $data_format == $format_dec ) { $byte_value =     $data_byte; }
            if( $signal_format == $format_intel )       { $byte_bin_lsb = reverse sprintf( "%08b" , $byte_value ); }
            elsif( $signal_format == $format_motorola ) { $byte_bin_lsb =         sprintf( "%08b" , $byte_value ); }
            ## create the full CAN message by concatinating all bytes (binary LSB)
            $can_frame_bin .= $byte_bin_lsb;
        }
        # section for MULTIPLEX master in case of SLAVE signal required
        if( $multiplex_type eq 'SLAVE' ) {

            if( $signal_MX_Master_format == $format_intel ) { # INTEL
                $signal_lsb = substr ( $can_frame_bin , $signal_MX_Master_start_bit , $signal_MX_Master_length );
            }
            elsif( $signal_MX_Master_format == $format_motorola ) { # MOTOROLA
                $temp_can_frame_bin = reverse $can_frame_bin;
                $dlc = $all_msgs->{$time_stamp}{ 'DLC' } ;
                $temp_sig_pos_start = $dlc * 8 - ( ( $signal_MX_Master_start_bit>>3 ) << 3 ) - ( 7 + ( ( $signal_MX_Master_start_bit>>3 ) << 3 ) - $signal_MX_Master_start_bit );
                $signal_lsb = substr ( $temp_can_frame_bin , $temp_sig_pos_start - $signal_MX_Master_length , $signal_MX_Master_length );
            }
            $signal_msb = reverse $signal_lsb;
            if( $signal_MX_Master_type eq 'SIGNED' and $signal_msb =~ /^1/ ) {
                $signal_msb_without_sign = substr($signal_msb,1,length($signal_msb)-1);
                $signal_msb_without_sign_compl = ~ $signal_msb_without_sign;   # 2 - complement (change all bits)
                $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb_without_sign_compl , -32)));
                $signal_raw_value = ($signal_raw_value + 1) * -1;  # add 1 due to calculation rule with signed values and multiply with -1

            } else {
                $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb, -32)));
            }
            $signal_MX_Master_value_phys = ($signal_raw_value * $signal_MX_Master_factor) + $signal_MX_Master_offset ;

            unless ( $signal_MX_Master_value_phys == $signal_MX_Master_code_value ) {
                next;
            }
        }
        # end of MULTIPLEX section
        if( $signal_format == $format_intel ) {
            $signal_lsb = substr ( $can_frame_bin , $signal_start_bit , $signal_length );
        }
        elsif( $signal_format == $format_motorola ) {
            $temp_can_frame_bin = reverse $can_frame_bin;
            $dlc = $all_msgs->{$time_stamp}{ 'DLC' } ;
            $temp_sig_pos_start = $dlc * 8 - ( ( $signal_start_bit>>3 ) << 3 ) - ( 7 + ( ( $signal_start_bit>>3 ) << 3 ) - $signal_start_bit );
            $signal_lsb = substr ( $temp_can_frame_bin , $temp_sig_pos_start - $signal_length , $signal_length );
        }
        $signal_msb = reverse $signal_lsb;
        if( $signal_type eq 'SIGNED' and $signal_msb =~ /^1/ ) {
            $signal_msb_without_sign = substr($signal_msb,1,length($signal_msb)-1);
            $signal_msb_without_sign_compl = ~ $signal_msb_without_sign;   # 2 - complement (change all bits)
            $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb_without_sign_compl , -32)));
            $signal_raw_value = ($signal_raw_value + 1) * -1;  # add 1 due to calculation rule with signed values and multiply with -1

        } else {
            $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb, -32)));
        }
        $sig_value_phys = ($signal_raw_value * $signal_factor) + $signal_offset ;
        $sig_data_ref->{ $time_stamp } = $sig_value_phys ;
    }

    unless( $sig_data_ref ) {
        S_w2log( 3, " VEC_trace_can_get_signal_data : could not extract signal $can_signal at startbit: $signal_start_bit, length: $signal_length format: $signal_format\n");
    }

    return $sig_data_ref;
}

######################################################################

=head2 VEC_trace_flxr_get_dataref

    $trace_data_ref = VEC_trace_flxr_get_dataref ( $FlexRay_tool_trace , @FlexRay_signal_or_message_list );

    Structure of returned trace_data_ref is:

    $trace_data_ref = {
                        'timestamp_1' => {
                                        PDU       => "DLC"
                                       'signal_1' => 'phys_value_at_time_1',
                                       'signal_2' => 'phys_value_at_time_1',
                                       'signal_3' => 'phys_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                       'signal_1' => 'phys_value_at_time_2',
                                       'signal_2' => 'phys_value_at_time_2',
                                       'signal_3' => 'phys_value_at_time_2',
                                          },
                     };

=cut

######################################################################

sub VEC_trace_flxr_get_dataref {
    my $OLE_handle = shift;
    my $device = shift;
    my $flxr_trace_or_signals_file = shift;
    my @given_flxr_signals = @_;

    # if somebody send an ARRAY_REF instead of ARRAY...
    if( ref $given_flxr_signals[0] eq 'ARRAY' ) {
        my @temp = @{ $given_flxr_signals[0] };
        @given_flxr_signals = @temp;
    }

    unless( @given_flxr_signals ) {
      S_set_error( " SYNTAX: VEC_trace_flxr_get_dataref( $flxr_trace_or_signals_file , @given_flxr_signals )", 110 ); return;
    }

    my $temp123 = $#given_flxr_signals+1;
    S_w2log( 4, " VEC_trace_flxr_get_dataref: create dataref for ".$temp123." FR signals\n");

    my $ReturnDataRef = {};    # < - - declared as hash ref initially

    my (
        $pdu_name ,
        $frame_name ,
        $all_signals_info ,
        $label_mapping ,
      );

    my $Flexray_Mapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);

    unless( $Flexray_Mapping ) {
        S_set_error( " LIFT Flexray mapping doesnot exist" , 0 );
    }

    ## collect all needed messages
    foreach my $flxr_signal ( @given_flxr_signals ) {

        if( my $mapped_signal = $main::ProjectDefaults->{'LABEL_MAPPING'}{ $flxr_signal } ) {
            S_w2log( 3 , " VEC_trace_flxr_get_dataref: found mapping '$flxr_signal' --> '$mapped_signal'\n" );
            $label_mapping->{ $mapped_signal } = $flxr_signal;
            $flxr_signal = $mapped_signal;
        }

        undef $pdu_name;
        undef $frame_name;
        $pdu_name = $Flexray_Mapping->{$flxr_signal}{'FR_PDU_NAME'};
        $frame_name = $Flexray_Mapping->{$flxr_signal}{'FR_FRAME_NAME'};

        S_w2log( 5, " VEC_trace_flxr_get_dataref: Flexray Signal: '$flxr_signal' => Frame-Name: '$frame_name'\n") if $frame_name;
        S_w2log( 5, " VEC_trace_flxr_get_dataref: Flexray Signal: '$flxr_signal' => PDU-Name: '$pdu_name'\n") if $pdu_name;

        if( defined $pdu_name ) {
             push( @{$all_signals_info->{ 'FrPDU' }{ $pdu_name }{ 'Signals' }} , $flxr_signal );
        }
        elsif( defined $frame_name and not defined $pdu_name ) {
             push( @{$all_signals_info->{ 'FrFrame' }{ $frame_name }{ 'Signals' }} , $flxr_signal );
        }
        else {
            S_set_error( " VEC_trace_flxr_get_dataref: no 'FR_PDU_NAME'/'FR_FRAME_NAME' defined for FlexRay signal '$flxr_signal' in LIFT FlexRay Mapping\n" , 109);
            return;
        }

    }

    return $ReturnDataRef = {} if $main::opt_offline;


    # Either Eval_Online_Mode_Signal_File or Eval_Offline_Mode_Signal_File is defined
    if( defined $Vector_tool_control->{'Devices'}{$device}{'Eval_Online_Mode_Signal_File'} ) {
       $flxr_trace_or_signals_file = $Vector_tool_control->{'Devices'}{$device}{'Eval_Online_Mode_Signal_File'};
       S_w2log( 3 , "VEC_trace_flxr_get_dataref: call VEC_trace_eval_CAPL_printed_ascii_signal_file with '$flxr_trace_or_signals_file'   \n");


        $ReturnDataRef = VEC_trace_eval_CAPL_printed_ascii_signal_file
                                             (
                                                 $all_signals_info ,
                                                 $flxr_trace_or_signals_file ,
                                                  $label_mapping ,
                                              );
    }

    if( defined $Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Mode_Signal_File'} ) {
        if( $Vector_tool_control->{'Devices'}{$device}{'Generate_Capl_Template'} ) {
            S_w2log( 3 , " VEC_trace_flxr_get_dataref: switch 'Generate_Capl_Template' = TRUE -> CAPL was created in VEC_cantool_init() already\n" );
        }
        else {
            S_w2log( 3 , " VEC_trace_flxr_get_dataref: switch 'Generate_Capl_Template' = FALSE -> create always CAPL just with needed signals\n"  );
            unless( VEC_trace_create_eval_capl ( $all_signals_info , $Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Mode_Capl_Template'} , 'OfflineOnly' ) ) {
                S_set_error( " VEC_trace_flxr_get_dataref: call of VEC_trace_run_offline() failed\n" , 109);
                return;
            }
        }

        unless( VEC_trace_run_offline( $OLE_handle , $device , $flxr_trace_or_signals_file  ) ) {
            S_set_error( " VEC_trace_flxr_get_dataref: call of VEC_trace_run_offline() failed\n" , 109);
            return;
        }

        S_w2log( 4 , "VEC_trace_flxr_get_dataref: call VEC_trace_eval_CAPL_printed_ascii_signal_file (".$Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Mode_Signal_File'}.")  \n");
        $ReturnDataRef = VEC_trace_eval_CAPL_printed_ascii_signal_file
                                             (
                                                 $all_signals_info ,
                                                 $Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Mode_Signal_File'} ,
                                                 $label_mapping ,
                                              );
    }

    unless( $ReturnDataRef ) {
        S_set_error( " VEC_trace_flxr_get_dataref: call of VEC_trace_eval_CAPL_printed_ascii_signal_file() failed\n" , 109);
        return;
    }

    ## .d97 file conversion is skipped only if user provides the option NO/no in the ProjectDefaults under 'Flexray_Data_Storage'->{'convert_into_d97_file'}
    if( $LIFT_config::LIFT_ProjectDefaults->{'Flexray_Data_Storage'}{'convert_into_d97_file'} =~ m/^NO$/i ) {
        return $ReturnDataRef;  # no conversion desired
    }

    # calculate trace file size
    my $flxr_file_size = -s $flxr_trace_or_signals_file;    #to obtain size of the flexray trace/signal file.file size will be in bytes say 2458964 bytes
    my $flxr_file_size_in_MB = $flxr_file_size/1000000;     # converting file size in bytes into megabytes.eg: 2458964/1000000 = 2MB
    S_w2log( 4 , " VEC_trace_flxr_get_dataref: size of Flexray trace/signal file is : $flxr_file_size_in_MB MB \n");

    my $maximum_trace_file_size_MB_for_d97_conversion;
    unless( $maximum_trace_file_size_MB_for_d97_conversion = $LIFT_config::LIFT_ProjectDefaults->{'Flexray_Data_Storage'}{'maximum_trace_file_size_MB_for_d97_conversion'} ) {
        $maximum_trace_file_size_MB_for_d97_conversion = 100 ; # default limitation setting
    }

    # file size limitation check
    if( $flxr_file_size_in_MB > $maximum_trace_file_size_MB_for_d97_conversion  ) {
        S_set_error(" VEC_trace_flxr_get_dataref: Flexray trace/signal file with size of $flxr_file_size_in_MB MB is too large to be converted to .d97 form (maximum allowed is $maximum_trace_file_size_MB_for_d97_conversion MB) \n" , 0);
        return $ReturnDataRef;  # no conversion possible - file too big
    }

    my $date_extension = main::get_date_extension(time());
    unless( -d $main::LIFT_ATD_TEMP ) {
        unless( mkdir $main::LIFT_ATD_TEMP ,0777 ) { S_set_error( "mkdir $main::LIFT_ATD_TEMP failed" , 1 ); return }
    }
    my $store_file_name = $main::LIFT_ATD_TEMP."LIFT_flexray_trace_".$date_extension.".d97";

    S_convert_dataref_to_file( $ReturnDataRef , $store_file_name );

    return $ReturnDataRef;
}

######################################################################

=head2 VEC_trace_eval_CAPL_printed_ascii_signal_file

    $trace_data_ref = VEC_trace_eval_CAPL_printed_ascii_signal_file ( $all_signals_info , $eval_offline_mode_signal_file $label_mapping );

    reading signal file into dataref

    //   0.002561  (PDU_ESP_01) ESP_Systemstatus = 0.000000 [ 0 ]
    //   0.017559  (PDU_ESP_04) ABS_Lampe = 0.000000 [ 0 ]


=cut

######################################################################

sub VEC_trace_eval_CAPL_printed_ascii_signal_file {

    my(
        $all_signals_info ,
        $eval_offline_mode_signal_file ,
        $label_mapping ,
        ) = @_ ;


    my (
        $trace_data_ref ,
        $pdu_name ,
        $frame_name ,
        $flxr_signal ,
        $time_stamp ,
        $FR_PDU,
        $sig_value ,
      );

    # check file and wait
    unless( -f $eval_offline_mode_signal_file ) {
        S_w2log( 4 , " VEC_trace_eval_CAPL_printed_ascii_signal_file : file doesnt exists $eval_offline_mode_signal_file ... wait 10sec ..\n" );
        S_wait_ms( 10000 );
    }
    # check file and error
    unless( -f $eval_offline_mode_signal_file ) { S_set_error( "File $eval_offline_mode_signal_file doesnt exist" , 1 ); return }


    S_w2log( 4 , " VEC_trace_eval_CAPL_printed_ascii_signal_file : Opening SIGNALS $eval_offline_mode_signal_file .. \n" );
    unless( open( SIGNALS , "<$eval_offline_mode_signal_file" ) ) { S_set_error( "Failed opening $eval_offline_mode_signal_file" , 1 ); return }

    while( <SIGNALS> ) {

        # matching :  0.002561  (PDU_ESP_01) ESP_Systemstatus = 0.000000 [ 0 ]
        if( /
            (\d+\.\d+)   # 0.002561 -> $1
            \s+
            \((\w+)\)    # (PDU_ESP_01) -> $2
            \s+
            (\w+)    # ESP_Systemstatus -> $3
            \s+
            =
            \s+
            ([+-]?\d+\.?\d*) # 0.000000 -> $4
            \s+
            # \[\s*(\d+)\s*\]  # 0 -> $5 
            /x )
        {
#             S_w2log( 1 , " $1 $2 $3 $4 \n" );
            $time_stamp = $1; $FR_PDU = $2;$flxr_signal = $3; $sig_value = $4;  #my $DLC = $5;

            # remove all ending 0 ( e.g. 12.345000 -> 12.345 or 1.0000 -> 1 )
            if( $sig_value =~ /\./ )
            {
                $sig_value =~ s/[0]+$//g;
                $sig_value =~ s/\.$// unless $sig_value =~ /\.\d+$/;
            }

            $trace_data_ref->{ $time_stamp }{ $flxr_signal } = $sig_value;
            $trace_data_ref->{ $time_stamp }{ $flxr_signal } = $FR_PDU;
           #$trace_data_ref->{ $time_stamp }{ $FR_PDU } = $DLC;   

            if( my $label = $label_mapping->{ $flxr_signal } )
           {
                $trace_data_ref->{$time_stamp}{$label}= $sig_value ;
                $trace_data_ref->{$time_stamp}{$label}= $FR_PDU ;
          }
        }
    }

    S_w2log( 4 , " VEC_trace_eval_CAPL_printed_ascii_signal_file : Closing SIGNALS $eval_offline_mode_signal_file .. \n" );
    unless( close( SIGNALS ) ) { S_set_error( "Failed closing $eval_offline_mode_signal_file" , 1 ); return }

    return $trace_data_ref;
}


######################################################################

=head2 VEC_read_can_configure

    VEC_read_can_configure ( CAN_tool );


=cut

######################################################################

sub VEC_read_can_configure
{
   my $device  = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_read_can_configure( CAN_tool )", 110 );
      return;
   }
   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_read_can_configure : OnlineConfiguration already loaded \n" );
      }
      else {
         ### stop measurement before loading the default configuration
         if( VEC_check_running( $OLE_handle ) ) {
            VEC_stop_measurement( $OLE_handle );
         }
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_read_can_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   unless( VEC_start_measurement( $OLE_handle ) ) {
      S_w2log( 1, " VEC_read_can_configure: Could not start $device measurement\n" );
      return;
   }

   return $OLE_handle;
}


######################################################################


=head2 VEC_read_can_signal
    
    ( $value , $unit ) =  VEC_read_can_signal ( $OLE_handle , $can_signal_name [, mode ] );

Reads can signal from can tool(s) 

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe

=item $can_signal_name 

Name of the CAN signal

=item $mode 

(optional) Phys or hex

=back

B<Return Value:>

=item $returnValue 

Value - either Physical value or Hex value depending on mode.
Unit  - unit of the signal defined in Mapping file(returns only in case of phys mode).

(Value, Unit)  : Successful

(1, undef)     : Offline

(undef, undef) : Failure

=back

B<Examples:> 
  
    ( hex Value )        = VEC_read_can_signal ( $OLE_handle, 'PreCrash_Fo_Kopfstuetze_verfahren', ' hex');
    ( phys Value , Unit) = VEC_read_can_signal ( $OLE_handle, 'PreCrash_Fo_Kopfstuetze_verfahren', 'phys');
 
B<Note:>

Based on whether the old handling of factor and offset calculation has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldSignalFactorOffsetHandling'>  :
  
= B<'Yes'> Uses the old implementation of factor offset calculation for signals.

= B<'No'> Uses the correct(new) implementation of factor and offset calculation for signals.    

=cut

######################################################################

sub VEC_read_can_signal {
    ### DESIGN  ###
   
   # COMMENT-START
        # get arguments 
        # mandatory :   
        # - $ole_handle_mix,
        # - $can_signal_name
        # - $mode
   # COMMENT-END  
    
   # STEP validate arguments
   
   # IF CANoe measuement runing ? 
        #IF-YES-START
           # CALL VEC_get_can_signal_info 
           # CALL VEC_validate_can_signal_info
           # IF old factor & offset handling required ?
            # IF-NO-START
                # STEP Get Both (raw value & phys value) and store
                # CALL VEC_read_bus_signal_direct_raw
                # CALL VEC_calc_phys_from_raw                
            # IF-NO-END
            # IF-YES-START
                # STEP Get Both (raw value & phys value) and store
                # CALL VEC_read_can_signal_direct
            # IF-YES-END
            
            # IF $mode ? 
              # IF-PHYS-START
                    # STEP return the phys value with unit from Mapping
                # IF-PHYS-END        
                # IF-HEX_RAW-START
                     # STEP Return Hex value and unit as undef
                # IF-HEX_RAW-END
        #IF-YES-END
        #IF-NO-START
            # STEP set (read value =  undef, unit = undef) & error CANoe measurement is not running   
        #IF-NO-END
   # STEP Return the read value (raw or phys) & unit

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_read_can_signal ($ole_handle_mix , $can_signal_name , $mode )', @args );

    my $ole_handle_mix  = shift @args;
    my $can_signal_name = shift @args;
    my $mode            = shift @args;

    unless ( defined $mode ) {
        S_w2log( 3, " VEC_read_can_signal : no mode (phys/hex) given , set to 'phys' per default )" );
        $mode = 'phys';
    }

    my ( $hex_value, $return_value, $can_signal_href, $raw_value, $phys_value, $bus_type,);

    unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 1, " VEC_read_can_signal : measurement must be running while reading can signal $can_signal_name \n" );
        return ( undef, undef );
    }

    $bus_type = 'CAN';

    # Get the information about can signal from the can mapping file
    $can_signal_href = VEC_get_bus_signal_info( $can_signal_name, $bus_type );

    #Validate the information about can signal from the can mapping file
    $can_signal_href = VEC_validate_bus_signal_info( $can_signal_href, $can_signal_name, $bus_type );

    unless (%$can_signal_href) {

        return ( undef, undef );
    }

    if ( check_flags ("OldSignalFactorOffsetHandling") == 1 ) {
        ( $phys_value, $raw_value ) = VEC_read_can_signal_direct( $ole_handle_mix, $can_signal_href );

        if ( $phys_value !~ /\d/ and $hex_value !~ /\d/ ) {
            S_w2log( 2, " VEC_read_can_signal : read signal not successful -> wait 1 cycle time ($can_signal_href->{'CYCLE'} ms) and read again\n" );
            S_wait_ms( $can_signal_href->{'CYCLE'} );
            ( $phys_value, $raw_value ) = VEC_read_can_signal_direct( $ole_handle_mix, $can_signal_href );
        }

    }
    else {

        ($raw_value) = VEC_read_bus_signal_direct_raw( $ole_handle_mix, $can_signal_href, $bus_type );

        if ( $raw_value !~ /\d/ ) {
            S_w2log( 2, " VEC_read_can_signal : read signal not successful -> wait 1 cycle time ($can_signal_href->{'CYCLE'} ms) and read again\n" );
            S_wait_ms( $can_signal_href->{'CYCLE'} );
            ($raw_value) = VEC_read_bus_signal_direct_raw( $ole_handle_mix, $can_signal_href, $bus_type );
        }

        $phys_value = VEC_calc_phys_from_raw( $can_signal_href, $raw_value );
    }

    if ( $mode =~ /hex/i ) {
        
        return ( sprintf( "0x%X", $raw_value ), undef ) if defined $raw_value;
    }
    elsif ( $mode =~ /phys/i ) {
        return ( $phys_value, $can_signal_href->{'UNIT'} ) if defined $phys_value;
    }
    else {
        S_w2log( 5, " VEC_read_can_signal : read signal not successful\n" );
        return ( undef, undef );
    }
}

######################################################################

=head2 VEC_read_can_signal_direct
    
    ($phys_value , $raw_value) = VEC_read_can_signal_direct ( $OLE_handle , $can_signal_href);

Reads the physical and raw signal value from CAN tool which must be started already.
If no $bus_number is give the default is 1.

B<Remark> : Interaction layer support should be supported in the CANoe configuration for this functionality.

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe

=item $can_signal_href 

It is a hash reference which contains the info of CAN signal

=back

B<Return Value:>

=item $returnValue 

Phys value - It contains the physical value of the signal.
Hex Value  - It contains the raw value of the signal.

=back

B<Examples:> 
  
    ($phys_value , $raw_value) = VEC_read_can_signal_direct ( $OLE_handle , $can_signal_href);

=cut

######################################################################

sub VEC_read_can_signal_direct {

    ### DESIGN  ###
   
   # COMMENT-START
        # get arguments 
        # mandatory   
        # - $ole_handle_mix,
        # - $can_signal_href (BusNbr, Message, signal_name)
        # optional - none
   # COMMENT-END 

   # STEP Get can signal object.
   # IF SIGNAL object retireved?
        # IF-NO-START
            # STEP WAIT 1 sec
            # STEP try one more time to get the signal object.
        # IF-NO-END 
        # IF-YES-START             
        # IF-YES-END

   # STEP fetch the phys value & raw value from Signal object.
   # IF 'phys value & raw value' from Signal object fetched ?
        # IF-NO-START
            # STEP set Signal (phys value = undef , rawValue = undef). Set error while reading the raw & phys value from CANoe
        # IF-NO-END 
        # IF-YES-START             
        # IF-YES-END   
   # STEP return (phys , 0x'rawValue') value.

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_read_can_signal_direct ($ole_handle_mix , $can_signal_href )', @args );

    my $ole_handle_mix  = shift @args;
    my $can_signal_href = shift @args;

    my ($signal_object);

    S_w2log( 5, " VEC_read_can_signal_direct_raw: OLE_handle -> Bus -> GetSignal( bus_number , message , given_signal ) .. \n" );
    $signal_object = $ole_handle_mix->Bus->GetSignal( $can_signal_href->{'BUS_NBR'}, $can_signal_href->{'PDU_MESSAGE'}, $can_signal_href->{'SIGNAL_NAME'} );

    unless ( defined $signal_object ) {
        sleep 1;
        S_w2log( 5, " VEC_read_can_signal_direct_raw: OLE_handle -> Bus -> GetSignal( bus_number , message , given_signal ) .. \n" );
        $signal_object = $ole_handle_mix->Bus->GetSignal( $can_signal_href->{'BUS_NBR'}, $can_signal_href->{'PDU_MESSAGE'}, $can_signal_href->{'SIGNAL_NAME'} );
    }

    my $phys_value = $signal_object->{"Value"};
    my $raw_value  = $signal_object->{"RawValue"};

    if ( defined $phys_value or defined $raw_value ) {
        S_w2log( 1, " VEC_read_can_signal_direct '$can_signal_href->{'SIGNAL_NAME'}' --> '$phys_value' (phys) , 0x$raw_value (= $raw_value ) (raw)\n" );
    }
    else {
        S_set_error( "VEC_read_can_signal_direct couldn't read '$can_signal_href->{'SIGNAL_NAME'}' from VECTOR CAN-Tool ( GetSignal( bus:$can_signal_href->{'BUS_NBR'} , msg:$can_signal_href->{'PDU_MESSAGE'} , sig:$can_signal_href->{'SIGNAL_NAME'} ) )\n", 0 );
        return ( undef, undef );
    }

    return ( $phys_value, $raw_value );
}


######################################################################

=head2 VEC_write_can_configure

    VEC_write_can_configure ( CAN_tool );


=cut

######################################################################

sub VEC_write_can_configure
{
    my $device  = shift;

    unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_write_can_configure( CAN_tool )", 110 );
      return;
    }

    if( $device =~ /CANoe/i ) {
        S_w2log( 3 , " VEC_write_can_configure: writing via CANoe possible with EnvVar and/or SysVar\n" );
    }
    elsif( $device =~ /CANalyzer/i ) {
        S_w2log( 3 , " VEC_write_can_configure: writing via CANalyzer possible only with SysVar\n" );
    }
    else {
        S_set_error( " CAN signal write only with CANoe or CANalyzer possible", 131 );
        return;
    }

   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_write_can_configure : OnlineConfiguration alwritey loaded \n" );
      }
      else {
         ### stop measurement before loading the default configuration
         if( VEC_check_running( $OLE_handle ) ) {
            VEC_stop_measurement( $OLE_handle );
         }
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_write_can_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   unless( VEC_start_measurement( $OLE_handle ) ) {
      S_w2log( 1, " VEC_write_can_configure: Could not start $device measurement\n" );
      return;
   }

   return $OLE_handle;
}


######################################################################

=head2 VEC_write_can_signal
    
    $returnValue = VEC_write_can_signal ( $ole_handle_mix, $can_signal_name, $signal_value, $mode );

Writes the given value of a CAN signal to the CANoe OLE handle.

B<Note:> Low level funcion, should not called directly in the testscript. use CA_write_can_signal intead.  

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe applicaiton. 

=item $can_signal_name 

Name of the signal 

=item $signal_value 

signal value to be written in CANoe. 

=item $mode 

Phys or hex

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , undef : Failure

=back

B<Examples:> 
 
 my $can_signal_href ; 
 $can_signal_href->{'SIGNAL_NAME'} = "SigStimulus1_CAN"; 
 $can_signal_href->{'CANOE_SYS_VAR'} = "EnvSigStimulus1_CAN";
 
 $status = VEC_write_can_signal (<OLEhandle>, 'SigStimulus1_CAN', '80', 'phys');
 $status = VEC_write_can_signal (<OLEhandle>, 'SigStimulus1_CAN', '0x80', 'hex');
 
B<Note:>

Based on whether the old handling of factor and offset calculation has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldSignalFactorOffsetHandling'>  :
  
= B<'Yes'> Uses the old implementation of factor offset calculation for signals.

= B<'No'> Uses the correct(new) implementation of factor and offset calculation for signals. 
 
=cut

######################################################################
sub VEC_write_can_signal {

    #COMMENT-START
        # get arguments 
        # mandatory   
        # - $ole_handle_mix,
        # - $can_signal_name
        # - $can_signal_value
        # - $mode
        # optional - none
    #COMMENT-END

    # IF CANoe is running?
    # IF-NO-START
        # STEP written status = undef , Error CANoe is not Running 
    # IF-NO-END
    # IF-YES-START
        # CALL VEC_get_can_signal_info
        # CALL VEC_validate_can_signal_info
        
        # IF support old factor & offset handling ?
            # IF-NO-START       
                # CALL VEC_write_can_signal_calcFactorOffset
            # IF-NO-END    
            #IF-YES-START
                # CALL VEC_write_can_signal_oldFactorOffsetHandling
            #IF-YES-END                
    # IF-YES-END    
    # STEP return 1

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_can_signal ( $ole_handle_mix, $can_signal_name, $can_signal_value ,$mode )', @args );

    my $ole_handle_mix   = shift @args;
    my $can_signal_name  = shift @args;
    my $can_signal_value = shift @args;
    my $mode             = shift @args;

    my ( $can_signal_href, $return_value, $bus_type );

    unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 4, " VEC_write_can_signal : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    $bus_type = 'CAN';

    # Get the information about can signal from the can mapping file
    $can_signal_href = VEC_get_bus_signal_info( $can_signal_name, $bus_type );

    #Validate the information about can signal from the can mapping file
    $can_signal_href = VEC_validate_bus_signal_info( $can_signal_href, $can_signal_name, $bus_type );

    unless (%$can_signal_href) {

        return;
    }

    # If (old implementation for Factor and Offset handling used ?)
    if ( check_flags ("OldSignalFactorOffsetHandling") == 1 ) {
        VEC_write_can_signal_oldFactorOffsetHandling( $ole_handle_mix, $can_signal_href, $can_signal_value, $mode );

    }
    else {
        VEC_write_can_signal_calcFactorOffset( $ole_handle_mix, $can_signal_href, $can_signal_value, $mode );
    }

    return 1;

}

#######################################################################

=head2 VEC_write_can_signal_calcFactorOffset
    
    $returnValue = VEC_write_can_signal_calcFactorOffset ( $ole_handle_mix, $can_signal_href, $signal_value, $mode  );

Writes the given value of a CAN signal to the CANoe OLE handle(uses the correct calculation of offset and factor for signal).

B<Note:> Low level funcion, should not called directly in the testscript. use CA_write_can_signal intead.  

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe applicaiton. 

=item $can_signal_href 

This hash reference contains the info of the signal 

=item $signal_value 

signal value to be written in CANoe. 

=item $mode 

Phys or hex

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , undef : Failure

=back

B<Examples:> 
 
 my $can_signal_href ; 
 $can_signal_href->{'SIGNAL_NAME'} = "SigStimulus1_CAN"; 
 $can_signal_href->{'CANOE_SYS_VAR'} = "EnvSigStimulus1_CAN";
 
 $status = VEC_write_can_signal_calcFactorOffset (<OLEhandle>, $can_signal_href, '80', 'phys');
 $status = VEC_write_can_signal_calcFactorOffset (<OLEhandle>, $can_signal_href, '0x80', 'hex');
 
=cut

######################################################################

sub VEC_write_can_signal_calcFactorOffset {

    # STEP write can signal with factor & offset calculation
    # IF $mode ?
       # IF-PHYS-START                 
          # CALL VEC_calc_raw_from_phys
          # STEP write write calculated raw value to '$can_signal_value'
    # IF-PHYS-END   
    # IF-HEX_or_RAW-START                                                                                                      
          # STEP validate if '$can_signal_value' is Hex if Yes proceed to write raw value (no conversion required)
    # IF-HEX_or_RAW-END
    
    # IF IL used ?
        # IF-YES-START
            # STEP write raw value to the signal object 
            # CALL VEC_write_bus_signal_direct_raw
        # IF-YES-END
        # IF-NO-START
            # STEP write to raw value to envionment variable for the corresponding signal defined in mapping
            # CALL VEC_write_can_signal_to_Env_or_Sys_var
        # IF-NO-END
    # STEP return write status

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_can_signal_calcFactorOffset ( $ole_handle_mix, $can_signal_href, $signal_value, $mode )', @args );

    my $ole_handle_mix  = shift @args;
    my $can_signal_href = shift @args;
    my $signal_value    = shift @args;
    my $mode            = shift @args;

    my ( $bus_type );

    unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 4, " VEC_write_can_signal_calcFactorOffset : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    $bus_type = 'CAN';

    if ( $mode =~ /hex/i ) {
        $signal_value = hex($signal_value) if($signal_value =~ /^0x[0-9A-F]+$/i);
    }
    elsif ( $mode =~ /phys/i ) {
        $signal_value = VEC_calc_raw_from_phys( $can_signal_href, $signal_value );
    }

    if ( VEC_check_InteractionLayer_used() == 1 ) {
        unless ( $can_signal_href->{'SIGNAL_NAME'} ) {
            S_set_error( " VEC_write_can_signal_calcFactorOffset : no SIGNAL_NAME available for given can_signal hash ref", 109 );
            return;
        }

        VEC_write_bus_signal_direct_raw( $ole_handle_mix, $bus_type, $can_signal_href, $signal_value );

    }
    else {
        VEC_write_can_signal_to_Env_or_Sys_var( $ole_handle_mix, $can_signal_href, $signal_value );

    }

    return 1;
}

#######################################################################

=head2 VEC_write_can_signal_oldFactorOffsetHandling
    
    $returnValue = VEC_write_can_signal_oldFactorOffsetHandling ( $ole_handle_mix, $can_signal_href, $signal_value, $mode  );    

Writes the given value of a CAN signal to the CANoe OLE handle(uses the old way of calculation of offset and factor for signal).

B<Note:> Low level funcion, should not called directly in the testscript. use CA_write_can_signal intead.  

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe applicaiton. 

=item $can_signal_href 

This hash reference contains the info of the signal 

=item $signal_value 

signal value to be written in CANoe. 

=item $mode 

Phys or hex

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , undef : Failure

=back0

B<Examples:> 
 
 my $can_signal_href ; 
 $can_signal_href->{'SIGNAL_NAME'} = "SigStimulus1_CAN"; 
 $can_signal_href->{'CANOE_SYS_VAR'} = "EnvSigStimulus1_CAN";
 
 $status = VEC_write_can_signal_oldFactorOffsetHandling (<OLEhandle>, $can_signal_href, '80', 'phys');
 $status = VEC_write_can_signal_oldFactorOffsetHandling (<OLEhandle>, $can_signal_href, '0x80', 'hex');
 
=cut

######################################################################

sub VEC_write_can_signal_oldFactorOffsetHandling {

    # STEP handle old writing of can signal with factor & offset calculation
    # IF $mode ?
       # IF-PHYS-START                 
          # STEP passed phys value to '$can_signal_value'
    # IF-PHYS-END   
    # IF-HEX_or_RAW-START                                                                                                      
          # STEP validate if '$can_signal_value' is Hex and write same value to phys 
    # IF-HEX_or_RAW-END
    
    # IF IL used ?
        # IF-YES-START
            # STEP write phys value directly to the signal object
            # CALL VEC_write_can_signal_direct
        # IF-YES-END
        # IF-NO-START
            # STEP write phys value to envionment variable for the corresponding signal defined in mapping
            # CALL VEC_write_can_signal_to_Env_or_Sys_var
        # IF-NO-END
    # STEP return write status 

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_can_signal_oldFactorOffsetHandling ( $ole_handle_mix, $can_signal_href, $signal_value, $mode )', @args );

    my $ole_handle_mix  = shift @args;
    my $can_signal_href = shift @args;
    my $signal_value    = shift @args;
    my $mode            = shift @args;
    my $signal_name;

   unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 4, " VEC_write_can_signal_oldFactorOffsetHandling : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    if ( $mode =~ /hex/i ) {
        $signal_value = hex($signal_value) if($signal_value =~ /^0x[0-9A-F]+$/i);
    }

    if ( VEC_check_InteractionLayer_used() == 1 ) {
        unless ( $signal_name = $can_signal_href->{'SIGNAL_NAME'} ) {
            S_set_error( " no SIGNAL_NAME available for given can_signal hash ref", 109 );
            return;
        }

        VEC_write_can_signal_direct( $ole_handle_mix, $signal_name, $signal_value );
    }
    else {
        VEC_write_can_signal_to_Env_or_Sys_var( $ole_handle_mix, $can_signal_href, $signal_value );
        
    }

    return 1;
}

######################################################

=head2  VEC_set_SysVar_value_by_type
    
    VEC_set_SysVar_value_by_type ( $sys_var_obj, $value);

Sets the value of system variable according to the type (integer, double, string and Data) to the system variable object.

B<Note:> Its a Low level funcion, do not call it directly in the testscript. intead call 'CA_set_SysVar_value'.

Returns 1 on success (and in offline or simulation mode), undef otherwise.

B<Examples:> 
 
$returnValue = VEC_set_SysVar_value_by_type(Sys_Var_Obj, 5) ;        # set integer value

=cut

sub VEC_set_SysVar_value_by_type {
    my @args          = @_;
    my $h_sys_var_obj = shift @args;
    my $value         = shift @args;

    unless ( defined $h_sys_var_obj ) {
        S_set_error( " VEC_set_SysVar_value_by_type : sytem variable handle was not defined ", 109 );
        return;
    }

    my $type = $h_sys_var_obj->Type();    # (0: Integer, 1: Float, 2: String, 4: Float Array, 5: Integer Array, 6: LongLong, 7: Byte Array, 98: Generic Array , 99: Struct , 65535: Invalid  )
    if ( $type == 0 ) {                   # 0: Integer
        $value = int($value);
    }
    elsif ( $type == 1 ) {                # 1: Float
        $value = $value + 1e-99;
    }   
    elsif ( $type == 4 ) {    			  # 4: float array
       if ( ref($value) ne "ARRAY" ) {
            S_set_error( " SysVarValue is not an array reference, but SysVar type is Float array", 114 );
            return;
        }
    	@$value = map {$_ + 1e-99} @$value;  # change each value to float if not, otherwise values won't be set to CANoe 
    	    	    
    }
    elsif ( $type == 5 ) {     # Integer array
        if ( ref($value) ne "ARRAY" ) {
            S_set_error( " SysVarValue is not an array reference, but SysVar type is int array", 114 );
            return;
        }
        
    	@$value = map {int($_)} @$value;  # change each value to int if not, otherwise values won't be set to CANoe  	    
    }
    else {
        # nothing to handled
    	# 2: String
        
        # not cheked yet or teted for :
        # 6: LongLong, 7: Byte Array, 98: Generic Array , 99: Struct , 65535: Invalid 
    }
    
    $h_sys_var_obj->{'Value'} = $value;
    S_w2log( 4, " VEC_set_SysVar_value_by_type -> SysVar type = $type and set to value = '$value'.\n" );

    return 1;
}

######################################################

=head2  VEC_get_SysVar_value_by_type
    
    VEC_get_SysVar_value_by_type ( $h_sys_var_obj, $sysvar);

Gets the value of system variable according to the type (integer, double, string and Data) of the system variable object.

B<Note:> 
its a Low level funcion, should not be called directly in the testscript. instead call 'CA_get_SysVar_value'.

Returns 1 on success (and in offline or simulation mode), undef otherwise.

B<Examples:> 
 
$return_sys_var_value = VEC_get_SysVar_value_by_type( $h_sys_var_obj, $sys_var );

=cut

sub VEC_get_SysVar_value_by_type {

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_get_SysVar_value_by_type ( $h_sys_var_obj_mix, $sysvar)', @args );

    my $h_sys_var_obj = shift @args;
    my $sysvar        = shift @args;

    unless ( defined $h_sys_var_obj ) {
        S_set_error( " VEC_get_SysVar_value_by_type : sytem variable handle was not defined ", 109 );
        return;
    }

    my $type                 = $h_sys_var_obj->Type();      #( 0: Integer, 1: Float, 2: String, 3: Data)
    my $return_sys_var_value = $h_sys_var_obj->{'Value'};
    S_w2log( 4, " VEC_get_SysVar_value_by_type -> '$sysvar' retrieves value = '$return_sys_var_value' of type = $type.\n" );

    return $return_sys_var_value;
}


######################################################

=head2  VEC_set_EnvVar_value_by_type
    
    VEC_set_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var, $value_mix );

Sets the value of Environment variable according to the type (integer, double, string and Data) to the Enviornment variable object.

B<Note:> Its a Low level funcion, do not call it directly in the testscript. intead call 'CA_set_EnvVar_value'.

Returns 1 on success (and in offline or simulation mode), undef otherwise.

B<Examples:> 
 
$returnValue = VEC_set_EnvVar_value_by_type( $handle, $env_var, 5 ); ;        # set integer value

=cut

sub VEC_set_EnvVar_value_by_type {

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_set_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var, $value_mix )', @args );

    my $h_env_var_obj = shift @args;
    my $env_var       = shift @args;
    my $value         = shift @args;

    unless ( defined $h_env_var_obj ) {
        S_set_error( " VEC_set_EnvVar_value_by_type : Environment variable handle was not defined ", 109 );
        return;
    }

    my $type = $h_env_var_obj->Type();    #( 0: Integer, 1: Float, 2: String, 3: Data)
    if ( $type == 3 ) {
        if ( ref($value) ne "ARRAY" ) {
            S_set_error( " EnvVarValue is not an array reference, but EnvVar type is Data", 114 );
            return;
        }
        my @temp = @$value;
        foreach (@temp) {
            $_ = S_0x2dec($_);
        }
        $h_env_var_obj->{'Value'} = \@temp;
        S_w2log( 4, " VEC_set_EnvVar_value_by_type -> '$env_var' set to array = '@temp' of type $type.\n" );

    }
    elsif ( $type == 0 ) {
        $value = S_0x2dec($value);
        $h_env_var_obj->{'Value'} = $value;
        S_w2log( 4, " VEC_set_EnvVar_value_by_type -> '$env_var' set to value = '$value' of type $type.\n" );
    }
    else {
        $h_env_var_obj->{'Value'} = $value;
        S_w2log( 4, " VEC_set_EnvVar_value_by_type -> '$env_var' set to value = '$value' of type $type.\n" );
    }

    return 1;
}

######################################################################

=head2  VEC_get_EnvVar_value_by_type
    
    VEC_get_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var);

Gets the value of Environment variable according to the type (integer, double, string and Data) of the enviroment variable object.

B<Note:> 
its a Low level funcion, should not be called directly in the testscript. instead call 'CA_get_EnvVar_value'.

Returns 1 on success (and in offline or simulation mode), undef otherwise.

B<Examples:>

$return_env_var_value = VEC_get_EnvVar_value_by_type( $handle, $env_var );

=cut

sub VEC_get_EnvVar_value_by_type {
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_get_EnvVar_value_by_type ( $h_env_var_obj_mix, $env_var)', @args );

    my $h_env_var_obj = shift @args;
    my $env_var        = shift @args;
        
    unless ( defined $h_env_var_obj ) {
        S_set_error( " VEC_get_EnvVar_value_by_type -> '$env_var' not defined in CANoe", 114 );
        return 1;
    }

    my $return_env_var_value;

    my $type = $h_env_var_obj -> Type();    #( 0: Integer, 1: Float, 2: String, 3: Data)
    if ( $type == 3 ) {
        my @temp = split( //, $h_env_var_obj -> {'Value'} );
        foreach (@temp) {
            $_ = ord($_);
        }
        $return_env_var_value = \@temp;
        S_w2log( 4, " VEC_get_EnvVar_value_by_type -> '$env_var' retrives array = '@temp' of type $type.\n" );

    }
    else {
        $return_env_var_value = $h_env_var_obj -> {'Value'};
        S_w2log( 4, " VEC_get_EnvVar_value_by_type -> '$env_var' retrieves value = '$return_env_var_value' of type $type.\n" );
    }

    return $return_env_var_value;
}


######################################################################

=head2 VEC_write_can_signal_to_Env_or_Sys_var
    
    $returnValue = VEC_write_can_signal_to_Env_or_Sys_var ( $ole_handle_mix, $can_signal_href, $signal_value );

Writes the given value of a CAN signal to the CANoe Environment or System Variable.

B<Remark> : In CAPL, value from System / Environment variable to CAN signal has to be mapped.

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe applicaiton. 

=item $can_signal_href 

Hash ref of CAN signal. Holding info like signal name , message name, Environment/System variable name for signal signal value to be mapped in CAPL. 

=item $signal_value 

signal value to be written in CANoe. 

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , undef : Failure

=back

B<Examples:> 
 
 my $can_signal_href ; 
 $can_signal_href->{'SIGNAL_NAME'} = "SigStimulus1_CAN"; 
 $can_signal_href->{'CANOE_SYS_VAR'} = "EnvSigStimulus1_CAN";
 
 $status = VEC_write_can_signal_to_Env_or_Sys_var (<OLEhandle>, $can_signal_href, '80');

=cut

######################################################################
sub VEC_write_can_signal_to_Env_or_Sys_var {

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_can_signal_to_Env_or_Sys_var ( $ole_handle_mix, $can_signal_href, $signal_value )', @args );

    my $ole_handle_mix  = shift @args;
    my $can_signal_href = shift @args;
    my $signal_value    = shift @args;

    unless ( ref $can_signal_href eq 'HASH' ) {
        S_set_error( " VEC_write_can_signal_to_Env_or_Sys_var : given can_signal is no hash reference", 109 );
        return;
    }

    my $device = VEC_get_device_for_OLE_handle($ole_handle_mix);
    unless ( defined $device ) {
        S_set_error( " could not get 'Device' for given OLE handle", 109 );
        return;
    }

    my %can_signal = %$can_signal_href;

    my ( $SIGNAL_OBJECT, $signal_name, $EnvVarName, $SysVarName, );

    unless ( $signal_name = $can_signal{'SIGNAL_NAME'} ) {
        S_set_error( " no SIGNAL_NAME available for given can_signal hash ref", 109 );
        return;
    }

    return 1 if $main::opt_offline;

    #Sytem Variable
    if ( $device eq 'CANoe' and not $EnvVarName = $can_signal{'CANOE_ENV_VAR'} ) {
        unless ( $SysVarName = $can_signal{'CANOE_SYS_VAR'} ) {
            S_set_error( " no 'CANOE_SYS_VAR' available for given can_signal '$signal_name'", 109 );
            return;
        }

        unless ( $SIGNAL_OBJECT = VEC_get_sys_variable( $ole_handle_mix, $SysVarName ) ) {
            S_set_error( " error while resolving CAPL environment object of Sysvar '$SysVarName'", 0 );
            return;
        }

        my ( $max_value, $min_value );
        $max_value = $SIGNAL_OBJECT->{'MaxValue'} if defined $SIGNAL_OBJECT->{'MaxValue'};
        if ( defined $max_value and $max_value < $signal_value ) {
            S_set_error( "MaxValue = $max_value of Sysvar '$SysVarName' exceeded ($signal_value)", 0 );
            return;
        }

        $min_value = $SIGNAL_OBJECT->{'MinValue'} if defined $SIGNAL_OBJECT->{'MinValue'};
        if ( defined $min_value and $min_value > $signal_value ) {
            S_set_error( "MinValue = $min_value of Sysvar '$SysVarName' exceeded ($signal_value)", 0 );
            return;
        }

        # WRITING WILL BE DONE HERE AND NOW
        VEC_set_SysVar_value_by_type( $SIGNAL_OBJECT, $signal_value );
        S_w2log( 3, " VEC_write_can_signal_to_Env_or_Sys_var : SysVar $SysVarName = $signal_value set\n" );

        return 1;
    }

    #Environment variable
    if ( $device eq 'CANoe' ) {
        unless ( $EnvVarName = $can_signal{'CANOE_ENV_VAR'} ) {
            S_set_error( " no CANOE_ENV_VAR available for given can_signal '$signal_name'", 109 );
            return;
        }

        unless ( $SIGNAL_OBJECT = VEC_get_env_variable( $ole_handle_mix, $EnvVarName ) ) {
            S_set_error( " error while resolving CAPL environment object of EnvVar '$EnvVarName'", 0 );
            return;
        }

        # WRITING WILL BE DONE HERE AND NOW
        $SIGNAL_OBJECT->{'Value'} = $signal_value * 1.0;
        S_w2log( 3, " VEC_write_can_signal_to_Env_or_Sys_var : EnvVar $EnvVarName = $signal_value set\n" );

    }

    return 1;
}

=head2 VEC_write_can_signal_direct
    
    $returnValue = VEC_write_can_signal_direct ( $ole_handle ,$given_signal, $signal_value );

Writes the given value of a CAN signal to the signal object.

B<Remark> : Interaction layer support should be supported in the CANoe configuration for this functionality.

B<Arguments:>

=over

=item $ole_handle

OLE handle of the CANoe tool.

=item $given_signal 

CAN signal name for which value has to be set. Must be same as in CAN mapping. . 

=item $signal_value 

signal value to be written in CANoe. 

=back

B<Return Value:>

=item $returnValue 
1 : Successful and in offline
undef : Failure

=back

B<Examples:> 
  
    $status = VEC_write_can_signal_direct ($ole_handle_mix, "SigStimulus1_CAN" , '80');        
    $status = VEC_write_can_signal_direct ($ole_handle_mix, "SigStimulus1_CAN" , '0x50');

=cut

######################################################################

sub VEC_write_can_signal_direct {

    # DESIGN
    # COMMENT-START
        # args : 
        # - $ole_handle_mix
        # - $can_signal_href (signal name, message name, busNbr )
        # - $can_signal_value_phys
    # COMMENT-END
    
    # STEP validate arguments
    
    # STEP Get can signal object.   
    # IF SIGNAL object retireved?
        # IF-YES-START
        # IF-YES-END
        # IF-NO-START
            # STEP WAIT 1 sec
            # STEP Try one more time to fetch signal object
        # IF-YES-END
    # STEP write '$can_signal_value_phys' to signal object  
    # STEP return 1
    
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_can_signal_direct ( $ole_handle_mix, $given_signal, $signal_value )', @args );

    my $ole_handle_mix = shift @args;
    my $given_signal   = shift @args;
    my $signal_value   = shift @args;

    my ( $message, $can_signal_name, $can_bus_nbr );

    S_w2log( 4, " VEC_write_can_signal_direct : args ['ole_handle = $ole_handle_mix', 'given_signal = $given_signal', 'signal_value = $signal_value'], \n" );

    my $can_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($can_Mapping) {
        S_set_error( " VEC_write_can_signal_direct : LIFT CAN_mapping doesnot exist \n", 0 );
    }

    unless ( $can_Mapping->{$given_signal} ) {
        S_set_error( " CAN signal $given_signal is not part of LIFT CAN Mapping", 132 );
        return;
    }

    unless ( $can_signal_name = $can_Mapping->{$given_signal}{'SIGNAL_NAME'} ) {
        S_set_error( " no 'SIGNAL_NAME' defined for signal '$can_signal_name'", 109 );
        return;
    }

    unless ( $message = $can_Mapping->{$given_signal}{'MESSAGE'} ) {
        S_set_error( " no 'MESSAGE' defined for signal '$can_signal_name'\n", 109 );
        return;
    }

    unless ( $can_bus_nbr = $can_Mapping->{'CAN_MESSAGES'}{$message}{'CAN_BUS_NBR'} ) {
        S_set_error( " no 'CAN_BUS_NBR' defined for message '$message'\n", 109 );
        return;
    }

    return 1 if $main::opt_offline;

    S_w2log( 5, " VEC_write_can_signal_direct OLE_handle -> Bus -> GetSignal( $can_bus_nbr , $message , $given_signal ) .. \n" );
    my $signal_object = $ole_handle_mix->Bus->GetSignal( $can_bus_nbr, $message, $given_signal );
    S_w2log( 5, " GetSignal: '\$signal_object'--> '$signal_object'\n" );

    unless ( defined $signal_object ) {
        sleep 1;

        S_w2log( 5, " VEC_write_can_signal_direct OLE_handle -> Bus -> GetSignal( $can_bus_nbr , $message , $given_signal ) .. \n" );
        $signal_object = $ole_handle_mix->Bus->GetSignal( $can_bus_nbr, $message, $given_signal );
        S_w2log( 5, " GetSignal: '\$signal_object --> $signal_object' \n" );

    }

    $signal_value = S_0x2dec($signal_value);
    $signal_object->{'Value'} = $signal_value * 1.0;
    S_w2log( 4, " VEC_write_can_signal_direct signal : value = '$signal_value' set to signal object. \n" );

    return 1;
}

######################################################################

=head2 VEC_read_flxr_configure

    VEC_read_flxr_configure ( FlexRay_tool [,'deactivate'] );

    option 'deactivate' stop measurement


=cut

######################################################################

sub VEC_read_flxr_configure
{
   my $device = shift;
   my $action = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_read_flxr_configure( FlexRay_tool )", 110 );
      return;
   }
   return 1 if $main::opt_offline; # just return if running in offline mode

   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_read_flxr_configure : OnlineConfiguration already loaded \n" );
      }
      else {
         ### stop measurement before loading the default configuration
         if( VEC_check_running( $OLE_handle ) ) {
            VEC_stop_measurement( $OLE_handle );
         }
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_read_flxr_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   if( $action =~ /deactivate/ ) {
       unless( VEC_stop_measurement( $OLE_handle ) ) {
          S_w2log( 1, " VEC_read_flxr_configure: Could not stop $device measurement\n" );
          return;
       }
   }
   else {
       unless( VEC_start_measurement( $OLE_handle ) ) {
          S_w2log( 1, " VEC_read_flxr_configure: Could not start $device measurement\n" );
          return;
       }
   }

   return $OLE_handle;
}


######################################################################


=head2 VEC_read_flxr_signal
    
    ( $value , $unit ) =  VEC_read_flxr_signal ( $OLE_handle , $flxr_signal_name [, $mode ] );

Reads the flexray signal from flexray tool(s) 

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe

=item $flxr_signal_name 

Name of the FLEXRAY signal

=item $mode 

(optional) Phys or hex

=back

B<Return Value:>

=item $returnValue 

Value - either Physical value or Hex value depending on mode.
Unit  - unit of the signal defined in Mapping file(returns only in case of phys mode).

(Value, Unit)  : Successful

(1, undef)     : Offline

(undef, undef) : Failure

=back

B<Examples:> 
  
    ( hex Value )        = VEC_read_flxr_signal ( $OLE_handle, 'PreCrash_Fo_Kopfstuetze_verfahren', ' hex');
    ( phys Value , Unit) = VEC_read_flxr_signal ( $OLE_handle, 'PreCrash_Fo_Kopfstuetze_verfahren', 'phys');

=cut

######################################################################

sub VEC_read_flxr_signal {
    ### DESIGN  ###
   
   #COMMENT-START
        # get arguments 
        # mandatory :   
        # - $ole_handle_mix,
        # - $signal_name
        # - $mode
    #COMMENT-END  
    
   # STEP validate arguments
      
   # IF CANoe measuement runing ? 
        #IF-YES-START
           # CALL VEC_get_bus_signal_info 
           # CALL VEC_validate_bus_signal_info             
           # CALL VEC_read_bus_signal_direct_raw
           # IF $mode ? 
              # IF-PHYS-START
            		# STEP GET the signal info from mapping & calculate phys value
            		# CALL VEC_calc_phys_from_raw                         
            		# STEP Return phys value and unit from Mapping
            	# IF-PHYS-END        
            	# IF-HEX_RAW-START
            		 # STEP Return Hex value and unit as undef
            	# IF-HEX_RAW-END           
        #IF-YES-END
        #IF-NO-START
            # STEP set (read value =  undef, unit = undef) & error CANoe measurement is not running   
        #IF-NO-END
   # STEP Return the read value (raw or phys) & unit

    my @args = @_;
    return (undef, undef) unless S_checkFunctionArguments( 'VEC_read_flxr_signal ($ole_handle_mix , $flxr_signal_name , $mode )', @args );

    my $ole_handle_mix   = shift @args;
    my $flxr_signal_name = shift @args;
    my $mode             = shift @args;

    unless ( defined $mode ) {
        S_w2log( 3, " VEC_read_flxr_signal : no mode (phys/hex) given , set to 'phys' per default )" );
        $mode = 'phys';
    }

    my ( $hex_value, $return_value, $flxr_signal_href, $raw_value, $bus_type, );

    unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 1, " VEC_read_flxr_signal : measurement must be running while reading FlexRay signal $flxr_signal_name \n" );
        return ( undef, undef );
    }

    $bus_type = 'FLEXRAY';

    # Get the information about flexray signal from the flexray mapping file
    $flxr_signal_href = VEC_get_bus_signal_info( $flxr_signal_name, $bus_type );

    #Validate the information about flexray signal from the flexray mapping file
    $flxr_signal_href = VEC_validate_bus_signal_info( $flxr_signal_href, $flxr_signal_name, $bus_type );

    unless (%$flxr_signal_href) {

        return ( undef, undef );
    }

    ($raw_value) = VEC_read_bus_signal_direct_raw( $ole_handle_mix, $flxr_signal_href, $bus_type );

    if ( $raw_value !~ /\d/ ) {
        S_w2log( 2, " VEC_read_flxr_signal : read signal not successful -> wait 1 cycle time ($flxr_signal_href->{'CYCLE'} ms) and read again\n" );
        S_wait_ms( $flxr_signal_href->{'CYCLE'} );
        ($raw_value) = VEC_read_bus_signal_direct_raw( $ole_handle_mix, $flxr_signal_href, $bus_type );
    }

    if ( $mode =~ /hex/i ) {
        $hex_value = sprintf( "0x%X", $raw_value );
        $return_value = $hex_value;
        
        return ( $return_value, undef );
    }
    elsif ( $mode =~ /phys/i ) {
        $return_value = VEC_calc_phys_from_raw( $flxr_signal_href, $raw_value );        
        return ( $return_value, $flxr_signal_href->{'UNIT'} );
    }    
    else {
        S_w2log( 5, " VEC_read_flxr_signal : read signal not successful\n" );
        return ( undef, undef );
    }
}

######################################################################


=head2 VEC_read_bus_signal_direct_raw
    
    ($phys_value , $raw_value) = VEC_read_bus_signal_direct_raw ( $ole_handle_mix , $bus_signal_href, $busType);

reads the raw signal value from FlexRay/Lin/Can tool which must be started already.
If no $bus_number is give the default is 1.

B<Remark> : Interaction layer support should be supported in the CANoe configuration for this functionality.

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe

=item $bus_signal_href 

It is a hash reference which contains the info of CAN/FLEXRAY/LIN signal

=item $busType 

It is the type of bus(CAN/LIN/FLEXRAY)

=back

B<Return Value:>

=item $returnValue 

Raw Value  - It contains the raw value of the signal.

=back

B<Examples:> 
  
    ($phys_value , $raw_value) = VEC_read_bus_signal_direct_raw ( $ole_handle_mix , $bus_signal_href, $busType);

=cut

######################################################################

sub VEC_read_bus_signal_direct_raw {
    ### DESIGN  ###
   
   # COMMENT-START
        # get arguments 
        # mandatory   
        # - $ole_handle_mix,
        # - $bus_signal_href (BusNbr, Message or PDU, signal_name)
        # - $busType
        # optional - none
   # COMMENT-END 

    # STEP Get 'bus-object' from $bus_type ($bus_type = CAN/LIN/FlexRay)
    # COMMENT-START
      # $bus_object = $ole_handle-> Bus ('FlexRay') if $bus_type == FlexRay
      # $bus_object = $ole_handle-> Bus ('LIN') if $bus_type  == LIN
      # $bus_object = $ole_handle-> Bus  if $bus_type == CAN
    # COMMENT-END


   # STEP Get 'signal object' from 'bus-object'.
   # IF SIGNAL object retireved?
        # IF-NO-START
            # STEP WAIT 1 sec
            # STEP try one more time to get the signal object.
        # IF-NO-END 
        # IF-YES-START             
        # IF-YES-END

   # STEP fetch the raw value from Signal object.
   # IF raw value from Signal object fetched ?
        # IF-NO-START
            # STEP set Signal raw value = undef. Set error while reading the raw value from CANoe
        # IF-NO-END 
        # IF-YES-START             
        # IF-YES-END   
   # STEP return raw value.

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_read_bus_signal_direct_raw ($ole_handle_mix, $bus_signal_href, $busType )', @args );

    my $ole_handle_mix  = shift @args;
    my $bus_signal_href = shift @args;
    my $busType         = shift @args;

    my ( $signal_object, $bus_Object );
    
    S_w2log( 4, " VEC_read_bus_signal_direct_raw \n" );

    #Get the bus-object
    $bus_Object = $ole_handle_mix->Bus            if ( $busType =~ /CAN/i );
    $bus_Object = $ole_handle_mix->Bus("Lin")     if ( $busType =~ /LIN/i );
    $bus_Object = $ole_handle_mix->Bus("FlexRay") if ( $busType =~ /FLEXRAY/i );
    
    unless ($bus_Object) {
		S_set_error( " VEC_read_bus_signal_direct_raw : Unable to get bus Object for BUS type $busType", 131 );
		return;
	}

    S_w2log( 4, " VEC_read_bus_signal_direct_raw: OLE_handle -> Bus($busType) -> GetSignal( $bus_signal_href->{'BUS_NBR'} , $bus_signal_href->{'PDU_MESSAGE'} , $bus_signal_href->{'SIGNAL_NAME'} ) \n Hint : Please verify if the corresponding mapping file (CAN, LIN or FlexRay) for Signal '$bus_signal_href->{'SIGNAL_NAME'}' has been updated" );
    $signal_object = $bus_Object->GetSignal( $bus_signal_href->{'BUS_NBR'}, $bus_signal_href->{'PDU_MESSAGE'}, $bus_signal_href->{'SIGNAL_NAME'} );
    S_get_LastError_OLE();

    unless ( defined $signal_object ) {
    	S_w2log( 4, " VEC_read_bus_signal_direct_raw: Failed to get Signal object for the First time, Trying to get the Signal object again after 1 Sec \n" );
    	
        sleep 1;
        $signal_object = $bus_Object->GetSignal( $bus_signal_href->{'BUS_NBR'}, $bus_signal_href->{'PDU_MESSAGE'}, $bus_signal_href->{'SIGNAL_NAME'} );
        S_get_LastError_OLE();
    }
    
    unless ($signal_object) {
		S_set_error( " VEC_read_bus_signal_direct_raw: Unable to get Signal Object for Bus nbr $bus_signal_href->{'BUS_NBR'}, Message/PDU $bus_signal_href->{'PDU_MESSAGE'} and Signalname $bus_signal_href->{'SIGNAL_NAME'} even after the second try", 131 );
		return;
	}

    my $raw_value = $signal_object->{"RawValue"};

    unless ( defined $raw_value ) {
        S_set_error( " VEC_read_bus_signal_direct_raw: Could not get the RawValue from the Signal object for the Bus nbr '$bus_signal_href->{'BUS_NBR'}', Message/PDU '$bus_signal_href->{'PDU_MESSAGE'}' and Signalname '$bus_signal_href->{'SIGNAL_NAME'}'\n", 109 );
        return;
    }

    return ($raw_value);
}


######################################################################

=head2 VEC_write_flxr_configure

    VEC_write_flxr_configure ( FlexRay_tool );


=cut

######################################################################

sub VEC_write_flxr_configure
{
   my $device  = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_write_flxr_configure( FlexRay_tool )", 110 );
      return;
   }

   unless( $device =~ /CANoe/i ) {
      S_set_error( " FlexRay signal write just with CANoe and Env variables possible", 109 );
      return;
   }

   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_write_flxr_configure : OnlineConfiguration alwritey loaded \n" );
      }
      else {
         ### stop measurement before loading the default configuration
         if( VEC_check_running( $OLE_handle ) ) {
            VEC_stop_measurement( $OLE_handle );
         }
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_write_flxr_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   unless( VEC_start_measurement( $OLE_handle ) ) {
      S_w2log( 1, " VEC_write_flxr_configure: Could not start $device measurement\n" );
      return;
   }

   return $OLE_handle;
}

######################################################################

=head2 VEC_write_flxr_signal
    
    $return_value = VEC_write_flxr_signal ( $ole_handle_mix , $flxr_signal_name , $signal_value , $mode);

Writes the given value of a FLEXRAY signal to the CANoe OLE handle.

B<Note:> Low level funcion, should not called directly in the testscript. use FR_write_flxr_signal instead.  

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe application. 

=item $flxr_signal_name 

Name of the signal 

=item $signal_value 

signal value to be written in CANoe.

=item $mode 

phys/hex 

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , undef : Failure

=back

B<Examples:> 
 
 my $flxr_signal_href ; 
 $flxr_signal_href->{'SIGNAL_NAME'} = "SigStimlus1ai"; 
 $flxr_signal_href->{'CANOE_ENV_VAR'} = "EnvSigStimulus1_CAN";
 
 $status = VEC_write_flxr_signal (<OLEhandle>, 'SigStimlus1ai', '80', 'hex');
 $status = VEC_write_flxr_signal (<OLEhandle>, 'SigStimlus1ai', '0x80', 'phys');
 
=cut

######################################################################

sub VEC_write_flxr_signal {

    #COMMENT-START
        # get arguments 
        # mandatory   
        # - $ole_handle_mix,
        # - $signal_name
        # - $signal_value
        # - mode
        # optional - none
    #COMMENT-END

    # STEP check if CANoe is running?
    # CALL VEC_get_bus_signal_info
    # CALL VEC_validate_bus_signal_info
    
 	# IF $mode ?
	   # IF-PHYS-START
	                                   
		  # CALL VEC_calc_raw_from_phys
		  # STEP write write calculated raw value to $given_flxr_signal
	# IF-PHYS-END   
	# IF-HEX_or_RAW-START                                                                                                      
		  # STEP validate if $signal_value is Hex if Yes proceed to write raw value (no conversion required)
	# IF-HEX_or_RAW-END
    
    # IF IL used ?
        # IF-YES-START
            # STEP write directly to the signal object
            # CALL VEC_write_bus_signal_direct_raw
        # IF-YES-END
        # IF-NO-START
            # STEP write to envionment variable for the corresponding signal defined in mapping
            # CALL VEC_write_flexray_lin_signal_to_Env_var
        # IF-NO-END
    # STEP return 1

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_flxr_signal ( $ole_handle_mix, $flxr_signal_name, $signal_value, $mode )', @args );

    my $ole_handle_mix   = shift @args;
    my $flxr_signal_name = shift @args;
    my $signal_value     = shift @args;
    my $mode             = shift @args;

    my ( $flxr_signal_href, $bus_type );

    unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 4, " VEC_write_flxr_signal : measurement not running use VEC_write_flxr_configure() before \n" );
        return;
    }

    $bus_type = 'FLEXRAY';
    
    S_w2log( 4, " VEC_write_flxr_signal Writes the FR signal $flxr_signal_name with value $signal_value and mode $mode\n" );

    # Get the information about flexray signal from the flexray mapping file
    $flxr_signal_href = VEC_get_bus_signal_info( $flxr_signal_name, $bus_type );

    #Validate the information about flexray signal from the flexray mapping file
    $flxr_signal_href = VEC_validate_bus_signal_info( $flxr_signal_href, $flxr_signal_name, $bus_type );

    unless (%$flxr_signal_href) {

        return;
    }

    if ( $mode =~ /hex/i ) {
        
        $signal_value = hex($signal_value) if($signal_value =~ /^0x[0-9A-F]+$/i);
    }
    elsif ( $mode =~ /phys/i ) {
        $signal_value = VEC_calc_raw_from_phys( $flxr_signal_href, $signal_value );
    }

    if ( VEC_check_InteractionLayer_used() == 1 ) {
        unless ( $flxr_signal_name = $flxr_signal_href->{'SIGNAL_NAME'} ) {
            S_set_error( " VEC_write_flxr_signal : no SIGNAL_NAME available for given flxr_signal hash ref", 109 );
            return;
        }

        VEC_write_bus_signal_direct_raw( $ole_handle_mix, $bus_type, $flxr_signal_href, $signal_value );

    }
    else {
        VEC_write_flexray_lin_signal_to_Env_var( $ole_handle_mix, $flxr_signal_href, $signal_value );

    }

    return 1;
}

######################################################################

=head2 VEC_write_bus_signal_direct_raw
    
    $returnValue = VEC_write_bus_signal_direct_raw ( $ole_handle, $bus_type, $bus_signal_href, $bus_signal_val_raw );

Writes the given value of a FLEXRAY/CAN/LIN signal to the signal object.

B<Remark> : Interaction layer support should be supported in the CANoe configuration for this functionality.

B<Arguments:>

=over

=item $ole_handle

OLE handle of the CANoe tool.

=item $bus_type

It is the type of the bus(CAN/LIN/FLEXRAY)

=item $bus_signal_href 

This hash reference contains the signal information.

=item $bus_signal_val_raw 

Signal value to be written in CANoe. 

=back

B<Return Value:>

=item $returnValue 

1 : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    $status = VEC_write_bus_signal_direct_raw ($ole_handle_mix, 'CAN, "$bus_signal_href , '80');

=cut

######################################################################

sub VEC_write_bus_signal_direct_raw {

    # DESIGN
    # COMMENT-START
        # args : 
        # - $ole_handle_mix
        # - $bus_type
        # - $bus_signal_href (signal name, message name, busNbr )
        # - $bus_signal_value_raw
    # COMMENT-END
    
    # STEP validate arguments
    
    # STEP Get 'bus-object' from $bus_type ($bus_type = CAN/LIN/FlexRay)
    # COMMENT-START
      # $bus_object = $ole_handle-> Bus ('FlexRay') if $bus_type == FlexRay
      # $bus_object = $ole_handle-> Bus ('LIN') if $bus_type  == LIN
      # $bus_object = $ole_handle-> Bus  if $bus_type == CAN
    # COMMENT-END
    
    # STEP Get 'signal object' from '$bus_object'
    # IF SIGNAL object retireved?
        # IF-YES-START
        # IF-YES-END
        # IF-NO-START
            # STEP WAIT 1 sec
            # STEP Try one more time to fetch signal object
        # IF-YES-END
    # STEP write '$bus_signal_value_raw' to signal object  
    # STEP return 1

	my @args = @_;
	return unless S_checkFunctionArguments( 'VEC_write_bus_signal_direct_raw ( $ole_handle_mix, $bus_type, $bus_signal_href, $bus_signal_val_raw )', @args );

	my $ole_handle_mix     = shift @args;
	my $bus_type           = shift @args;
	my $bus_signal_href    = shift @args;
	my $bus_signal_val_raw = shift @args;

	my ( $bus_Object, $signal_object );

	S_w2log( 4, " VEC_write_bus_signal_direct_raw \n" );

	#Get the bus-object
	$bus_Object = $ole_handle_mix->Bus            if ( $bus_type =~ /CAN/i );
	$bus_Object = $ole_handle_mix->Bus("Lin")     if ( $bus_type =~ /LIN/i );
	$bus_Object = $ole_handle_mix->Bus("FlexRay") if ( $bus_type =~ /FLEXRAY/i );

	unless ($bus_Object) {
		S_set_error( " VEC_write_bus_signal_direct_raw : Unable to get bus Object for BUS type $bus_type", 131 );
		return;
	}

	return 1 if $main::opt_offline;    # just return if running in offline mode

	S_w2log( 4, " VEC_write_bus_signal_direct_raw OLE_handle -> Bus($bus_type) -> GetSignal( $bus_signal_href->{'BUS_NBR'} , $bus_signal_href->{'PDU_MESSAGE'} , $bus_signal_href->{'SIGNAL_NAME'} ) \n Hint : Please verify if the corresponding mapping file (CAN, LIN or FlexRay) for Signal '$bus_signal_href->{'SIGNAL_NAME'}' has been updated" );
	$signal_object = $bus_Object->GetSignal( $bus_signal_href->{'BUS_NBR'}, $bus_signal_href->{'PDU_MESSAGE'}, $bus_signal_href->{'SIGNAL_NAME'} );

	unless ( defined $signal_object ) {		
		S_w2log( 4, " VEC_write_bus_signal_direct_raw : Failed to get Signal object for the First time, Trying to get the Signal object again after 1 Sec\n" );
		
		sleep 1;
		$signal_object = $bus_Object->GetSignal( $bus_signal_href->{'BUS_NBR'}, $bus_signal_href->{'PDU_MESSAGE'}, $bus_signal_href->{'SIGNAL_NAME'} );
	}

	unless ($signal_object) {
		S_set_error( " VEC_write_bus_signal_direct_raw : Unable to get Signal Object for Bus nbr $bus_signal_href->{'BUS_NBR'}, Message/PDU $bus_signal_href->{'PDU_MESSAGE'} and Signalname $bus_signal_href->{'SIGNAL_NAME'} even after the second try", 131 );
		return;
	}

	# WRITING WILL BE DONE HERE AND NOW
	$signal_object->{'RawValue'} = $bus_signal_val_raw * 1.0;
	S_w2log( 4, " VEC_write_bus_signal_direct_raw signal : The value = '$bus_signal_val_raw' is set to signal object for Bus nbr '$bus_signal_href->{'BUS_NBR'}', Message/PDU '$bus_signal_href->{'PDU_MESSAGE'}' and SignalName '$bus_signal_href->{'SIGNAL_NAME'}'..\n" );

	return 1;
}

######################################################################

=head2 VEC_write_flexray_lin_signal_to_Env_var
    
    $returnValue = VEC_write_flexray_lin_signal_to_Env_var ( $ole_handle_mix, $flxr_lin_signal_href, $signal_value );

Writes the given value of a FLEXRAY/LIN signal to the CANoe Environment Variable.

B<Remark> : In CAPL, value from Environment variable to FLEXRAY/LIN signal has to be mapped.

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe applicaiton. 

=item $flexray_lin_signal_href 

Hash ref of FLEXRAY/LIN signal. Holding info like signal name , message name, Environment variable name for signal value to be mapped in CAPL. 

=item $signal_value 

Signal value to be written in CANoe. 

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , undef : Failure

=back

B<Examples:> 
 
 my $flexray_lin_signal_href ; 
 $flexray_lin_signal_href->{'SIGNAL_NAME'} = "SigStimlus1ai"; 
 $flexray_lin_signal_href->{'CANOE_ENV_VAR'} = "EvStartPDU_Stimulus1A";
 
 $status = VEC_write_flexray_lin_signal_to_Env_var (<OLEhandle>, $flexray_lin_signal_href, '80');

=cut

######################################################################

sub VEC_write_flexray_lin_signal_to_Env_var {

   # DESIGN
    # COMMENT-START
        # args : 
        # - $ole_handle_mix
        # - $flxr_lin_signal_ref (key SIGNAL_NAME, CANOE_ENV_VAR )
        # - $signal_value
    # COMMENT-END
    
    # STEP validate arguments 
    
    # IF CANoe is running ?
        # IF-NO-START
            # STEP written status = undef , Error msg - messurement was not running before writing $signal_value.
        # IF-NO-END
        # IF-YES-START
          # STEP validate key 'SIGNAL_NAME' to get the signal name.
          # STEP validate key 'CANOE_ENV_VAR' to get Environemnt variable for 'SIGNAL_NAME'.
          # STEP Get the Environment object
          # STEP write $signal_value to Environment object
        # IF-YES-END  
    # STEP return status

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_flexray_lin_signal_to_Env_var ( $ole_handle_mix, $flxr_lin_signal_href, $signal_value )', @args );

    my $ole_handle_mix      = shift @args;
    my $flxr_lin_signal_ref = shift @args;
    my $signal_value        = shift @args;

    my %flxr_lin_signal = %$flxr_lin_signal_ref;

    my ( $signal_OBJECT, $signal_name, $envVarName, );

    unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 1, " VEC_write_flexray_lin_signal_to_Env_var : measurement not running use VEC_write_flxr_configure() or VEC_write_lin_configure() for FLEXRAY or LIN respectively before \n" );
        return;
    }

    unless ( $signal_name = $flxr_lin_signal{'SIGNAL_NAME'} ) {
        S_set_error( " no SIGNAL_NAME available for given flxr_signal/lin_signal hash ref", 109 );
        return;
    }

    unless ( $envVarName = $flxr_lin_signal{'CANOE_ENV_VAR'} ) {
        S_set_error( " no CANOE_ENV_VAR available for given flxr_signal/lin_signal '$envVarName'", 109 );
        return;
    }

    unless ( $signal_OBJECT = VEC_get_env_variable( $ole_handle_mix, $envVarName ) ) {
        S_set_error( " error while resolving CAPL environment object of '$envVarName'", 0 );
        return;
    }

    return 1 if $main::opt_offline;

    $signal_OBJECT->{'Value'} = $signal_value * 1.0;

    S_w2log( 4, " VEC_write_flexray_lin_signal_to_Env_var : $envVarName = $signal_value set\n" );

    return 1;
}

######################################################################
=head2  VEC_disable_can_message
    
    return_value =  VEC_disable_can_message ( $OLE_handle , $message_name [ , $time_out_info ] );

Sets the value of Environment/System variable (for the key CANOE_DISABLE as defined in LIFT CAN mapping) to 0 ( Old Implementation ) 
Sets the value of Environment/System variable (for the key CANOE_DISABLE as defined in LIFT CAN mapping) to 1 ( New Implementation )

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe application.

=item $message_name 

Name of CAN message as used in LIFT CAN mapping.  

=item $time_out_info 

(optional) time_out_info : additional info value which will be set in CAPL environment variable(CANOE_TIMING as defined in LIFT CAN mapping)
e.g.
- number of timeout cycles
- time value
if not given CAPL env/sys var will be set to 0 

=back

B<Return Value:>

=over

=item $returnValue 

1     : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    return_value =  VEC_disable_can_message ( $OLE_handle , "MsgStimulus1_CAN" [ , $time_out_info ]);

B<Note 1:> Its a Low level funcion, do not call it directly in the testscript. instead call 'CA_disable_message'.

B<Note 2:>

Based on whether the old handling of enabling and disabling the can messages has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling can messages. 

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling can messages.

=cut

######################################################################

sub VEC_disable_can_message {

    my ( $ole_handle, $message_name, $time_out_info, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_disable_can_message( OLE_handle , can_signal_ref , signal_value )", 110 );
        return;
    }

    my (
         $varDisable_CanMsg, $handle_Disable_CanMsg,
         $TimingVarName,     $CAPL_timing_signal_control,    ## TODO -> not used has to be checked
    );

    my $can_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );
    unless ($can_Mapping) {
        S_set_error( " LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $varDisable_CanMsg = $can_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_DISABLE'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_DISABLE' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }
    return 1 if $main::opt_offline;

    unless ( VEC_check_running($ole_handle) ) {
        S_w2log( 1, " VEC_disable_can_message : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    # make CAN/ LIN & FlexRay consistent for enabling & Diabling msg's
    my $disableValue;
    if ( check_flags("OldEnableDisableHandling") == 1 ) {
        $disableValue = 0;
    }
    else {
        $disableValue = 1;
    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $handle_Disable_CanMsg = VEC_get_env_variable( $ole_handle, $varDisable_CanMsg ) if not( $varDisable_CanMsg =~ /::/i );    #System variable  should have :: operator
    if ( defined $handle_Disable_CanMsg ) {
        $handle_Disable_CanMsg->{'Value'} = $disableValue;
    }
    else {
        S_w2log( 4, " VEC_disable_can_message : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $handle_Disable_CanMsg = VEC_get_sys_variable( $ole_handle, $varDisable_CanMsg ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$varDisable_CanMsg'", 0 );
            return;
        }
        VEC_set_SysVar_value_by_type( $handle_Disable_CanMsg, $disableValue );
    }

    S_w2log( 4, " VEC_disable_can_message : set $varDisable_CanMsg = $disableValue \n" );

    # TODO : this has to be checked as no handle for timeout info is there.
    if ($time_out_info) {
        S_w2log( 3, " VEC_disable_can_message : set CAPL $TimingVarName = $time_out_info \n" );
        $CAPL_timing_signal_control->{'Value'} = $time_out_info;
    }

    return 1;
}


######################################################################

=head2  VEC_enable_can_message
    
    return_value =  VEC_enable_can_message ( $OLE_handle , $message_name );

Sets the value of Environment/System variable (for the key CANOE_DISABLE as defined in LIFT CAN mapping) to 1 ( Old Implemenation ) 
Sets the value of Environment/System variable (for the key CANOE_DISABLE as defined in LIFT CAN mapping) to 0 ( New Implemenation )

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe application.

=item $message_name 

Name of CAN message as used in LIFT CAN mapping.  

=back

B<Return Value:>

=over

=item $returnValue 

1     : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    return_value =  VEC_enable_can_message ( $OLE_handle , "MsgStimulus1_CAN");

B<Note 1:> Its a Low level funcion, do not call it directly in the testscript. instead call 'CA_enable_message'.

B<Note 2:>

Based on whether the old handling of enabling and disabling the can messages has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling can messages. 

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling can messages.

=cut

######################################################################

sub VEC_enable_can_message {
    my ( $ole_handle, $message_name, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_enable_can_message( OLE_handle , can_signal_ref , signal_value )", 110 );
        return;
    }
    my ( $varenable_CanMsg, $handle_enable_CanMsg, $TimingVarName, $CAPL_timing_signal_control, );

    my $can_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );
    unless ($can_Mapping) {
        S_set_error( " LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $varenable_CanMsg = $can_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_DISABLE'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_DISABLE' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    return 1 if $main::opt_offline;

    unless ( VEC_check_running($ole_handle) ) {
        S_w2log( 1, " VEC_enable_can_message : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    my $enableValue;
    if ( check_flags("OldEnableDisableHandling") == 1 ) {
        $enableValue = 1;
    }
    else {
        $enableValue = 0;
    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $handle_enable_CanMsg = VEC_get_env_variable( $ole_handle, $varenable_CanMsg ) if not( $varenable_CanMsg =~ /::/i );    #System variable  should have :: operator

    if ( defined $handle_enable_CanMsg ) {
        $handle_enable_CanMsg->{'Value'} = $enableValue;
    }
    else {
        S_w2log( 4, " VEC_enable_can_message : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $handle_enable_CanMsg = VEC_get_sys_variable( $ole_handle, $varenable_CanMsg ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$varenable_CanMsg'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $handle_enable_CanMsg, $enableValue );
    }

    S_w2log( 4, " VEC_enable_can_message : set $varenable_CanMsg = $enableValue \n" );

    return 1;
}


######################################################################

=head2 VEC_set_DLC

    return_value =  VEC_set_DLC ( $OLE_handle , $message_name , DLC [ , $time_out_info ] );

   function controls
     CAPL env/sys variables 'CANOE_DLC' and 'CANOE_TIMING'
   as defined in LIFT CAN mapping

   CAN_message   : name of CAN message as used in LIFT CAN mapping
   DLC           : DLC to be set
   time_out_info : additional info value
                   which will be set in CAPL environment/system variable
                   e.g.
                    - number of timeout cycles
                    - time value

=cut

######################################################################

sub VEC_set_DLC {
    my ( $OLE_handle, $message_name, $given_DLC, $time_out_info, ) = @_;

    unless ( defined $given_DLC ) {
        S_set_error( " SYNTAX: VEC_set_DLC( OLE_handle , message_name , DLC [ , time_out_info ]  )", 110 );
        return;
    }

    my ( $CAPL_DLC_signal_control, $CAPL_timing_signal_control, $DLCVarName, $TimingVarName, );

    my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_Mapping) {
        S_set_error( " LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $DLCVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_DLC'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_DLC' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    unless ( $TimingVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_TIMING'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_TIMING' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    return 1 if $main::opt_offline;

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_set_DLC : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $CAPL_DLC_signal_control = VEC_get_env_variable( $OLE_handle, $DLCVarName ) if not ($DLCVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_DLC_signal_control ) {
        $CAPL_DLC_signal_control->{'Value'} = $given_DLC;
    }
    else {
        S_w2log( 4, " VEC_set_DLC : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_DLC_signal_control = VEC_get_sys_variable( $OLE_handle, $DLCVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$DLCVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_DLC_signal_control, $given_DLC );
    }

    S_w2log( 3, " VEC_set_DLC : set CAPL $DLCVarName = $given_DLC\n" );

    $CAPL_timing_signal_control = VEC_get_env_variable( $OLE_handle, $TimingVarName ) if not ($TimingVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_timing_signal_control ) {
        $CAPL_timing_signal_control->{'Value'} = $time_out_info;
    }
    else {
        S_w2log( 4, " VEC_set_DLC : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_timing_signal_control = VEC_get_sys_variable( $OLE_handle, $TimingVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$TimingVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_timing_signal_control, $time_out_info );
    }

    if ($time_out_info) {
        S_w2log( 3, " VEC_set_DLC : set CAPL $TimingVarName = $time_out_info \n" );
        $CAPL_timing_signal_control->{'Value'} = $time_out_info;
    }

    return 1;
}

######################################################################

=head2 VEC_reset_DLC

    return_value =  VEC_reset_DLC ( $OLE_handle , $message_name [, DLC ] );

   function controls
     CAPL env/sys variables 'CANOE_DLC' and 'CANOE_TIMING'
   as defined in LIFT CAN mapping

   CAN_message   : name of CAN message as used in LIFT CAN mapping
   DLC           : DLC to be set (if not given original one from LIFT CAN mapping will be taken)

=cut

######################################################################

sub VEC_reset_DLC {
    my ( $OLE_handle, $message_name, $given_DLC, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_reset_DLC( $OLE_handle , message_name [, DLC ] )", 110 );
        return;
    }

    my ( $CAPL_DLC_signal_control, $CAPL_timing_signal_control, $DLCVarName, $TimingVarName, $Orig_DLC, );

    my $dlcValue;
    my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_Mapping) {
        S_set_error( " LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $DLCVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_DLC'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_DISABLE' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    unless ( $TimingVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_TIMING'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_DISABLE' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    unless ( defined $given_DLC ) {
        unless ( $Orig_DLC = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'DLC'} ) {
            S_set_error( " no 'DLC' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
            return;
        }
    }

    return 1 if $main::opt_offline;
    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_reset_DLC : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    if ( defined $given_DLC ) {
        $dlcValue = $given_DLC;    ### or set to '0' ??
    }
    else {
        $dlcValue = $Orig_DLC;
    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $CAPL_DLC_signal_control = VEC_get_env_variable( $OLE_handle, $DLCVarName ) if not ($DLCVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_DLC_signal_control ) {
        $CAPL_DLC_signal_control->{'Value'} = $dlcValue;
    }
    else {
        S_w2log( 4, " VEC_reset_DLC : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_DLC_signal_control = VEC_get_sys_variable( $OLE_handle, $DLCVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$DLCVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_DLC_signal_control, $dlcValue );
    }

    S_w2log( 3, " VEC_reset_DLC : set CAPL $DLCVarName = $dlcValue\n" );

    $CAPL_timing_signal_control = VEC_get_env_variable( $OLE_handle, $TimingVarName ) if not ($TimingVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_timing_signal_control ) {
        $CAPL_timing_signal_control->{'Value'} = 0;
    }
    else {
        S_w2log( 4, " VEC_reset_DLC : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_timing_signal_control = VEC_get_sys_variable( $OLE_handle, $TimingVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$TimingVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_timing_signal_control, 0 );
    }

    S_w2log( 4, " VEC_reset_DLC : set $TimingVarName = 0 \n" );

    return 1;
}



######################################################################
=head2  VEC_disable_flxr_PDU_update
    
    return_value =  VEC_disable_flxr_PDU_update ( $OLE_handle , $message_name );                 
    
!!! function not released yet !!!
Sets the value of Environment variable(for the key CANOE_DISABLE as defined in LIFT FLEXRAY mapping ) to 0 ( Old Implementation ) 
Sets the value of Environment variable(for the key CANOE_DISABLE as defined in LIFT FLEXRAY mapping ) to 1 ( New Implementation )

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe application.

=item $message_name 

name of FLEXRAY PDU as used in LIFT FLEXRAY mapping.  

=back

B<Return Value:>

=over

=item $returnValue 

1     : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    return_value =  VEC_disable_flxr_PDU_update ( $OLE_handle , "Stimulus1");

B<Note 1:> Its a Low level funcion, do not call it directly in the testscript. instead call 'FR_disable_PDU_update'.

B<Note 2:>

Based on whether the old handling of enabling and disabling the PDU has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling PDU. 

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling PDU.

=cut

######################################################################

sub VEC_disable_flxr_PDU_update {
    my ( $OLE_handle, $message_name, $time_out_info, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_disable_flxr_PDU_update( OLE_handle , can_signal_ref , signal_value )", 110 );
        return;
    }

    my ( $CAPL_timeout_signal_control, $CAPL_timing_signal_control, $TimeoutEnvVarName, $TimingEnvVarName, );

    my $Flexray_Mapping = S_get_contents_of_hash( ['Mapping_FLEXRAY'] );

    unless ($Flexray_Mapping) {
        S_set_error( " LIFT Flexray mapping doesnot exist", 0 );
    }

    unless ( $TimeoutEnvVarName = $Flexray_Mapping->{'FR_PDU'}{$message_name}{'CANOE_DISABLE'} ) {
        S_set_error( " no EnvVar 'CANOE_DISABLE' available for given message_name '$message_name' in LIFT Flexray mapping", 109 );
        return;
    }

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_disable_flxr_PDU_update : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    unless ( $CAPL_timeout_signal_control = VEC_get_env_variable( $OLE_handle, $TimeoutEnvVarName ) ) {
        S_set_error( " error while resolving CAPL environment object of '$TimeoutEnvVarName'", 0 );
        return;
    }

    return 1 if $main::opt_offline;

    if ( check_flags("OldEnableDisableHandling") eq 1 ) {
        S_w2log( 3, " VEC_disable_flxr_PDU_update : set CAPL $TimeoutEnvVarName = 0 \n" );
        $CAPL_timeout_signal_control->{'Value'} = 0;
    }

    else {
        S_w2log( 3, " VEC_disable_flxr_PDU_update : set CAPL $TimeoutEnvVarName = 1 \n" );
        $CAPL_timeout_signal_control->{'Value'} = 1;
    }

    return 1;
}

######################################################################

=head2  VEC_enable_flxr_PDU_update
    
    return_value =  VEC_enable_flxr_PDU_update ( $OLE_handle , $PDU_name );
    
!!! function not released yet !!!

Sets the value of Environment variable(for the key CANOE_DISABLE as defined in LIFT FLEXRAY mapping ) to 1 ( Old Implementation )
Sets the value of Environment variable(for the key CANOE_DISABLE as defined in LIFT FLEXRAY mapping ) to 0 ( New Implementation )

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe application.

=item $message_name 

name of FLEXRAY PDU as used in LIFT FLEXRAY mapping.  

=back

B<Return Value:>

=over

=item $returnValue 

1     : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    return_value =  VEC_enable_flxr_PDU_update ( $OLE_handle , "Stimulus1");

B<Note 1:> Its a Low level funcion, do not call it directly in the testscript. instead call 'FR_enable_PDU_update'.

B<Note 2:>

Based on whether the old handling of enabling and disabling the PDU has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling PDU. 

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling PDU.

=cut

######################################################################

sub VEC_enable_flxr_PDU_update {
    my ( $OLE_handle, $message_name, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_enable_flxr_PDU_update( OLE_handle , can_signal_ref , signal_value )", 110 );
        return;
    }

    my ( $CAPL_timeout_signal_control, $CAPL_timing_signal_control, $TimeoutEnvVarName, $TimingEnvVarName, );

    my $Flexray_Mapping = S_get_contents_of_hash( ['Mapping_FLEXRAY'] );

    unless ($Flexray_Mapping) {
        S_set_error( " LIFT Flexray mapping doesnot exist", 0 );
    }

    unless ( $TimeoutEnvVarName = $Flexray_Mapping->{'FR_PDU'}{$message_name}{'CANOE_DISABLE'} ) {
        S_set_error( " no EnvVar 'CANOE_DISABLE' available for given message_name '$message_name' in LIFT Flexray mapping", 109 );
        return;
    }

    #   unless( $TimingEnvVarName = $Flexray_Mapping->{'FR_PDU'}{ $message_name }{'CANOE_TIMING'} ) {
    #      S_set_error( " no EnvVar 'CANOE_TIMING' available for given message_name '$message_name' in LIFT Flexray mapping", 109 );
    #      return;
    #   }

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_enable_flxr_PDU_update : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    unless ( $CAPL_timeout_signal_control = VEC_get_env_variable( $OLE_handle, $TimeoutEnvVarName ) ) {
        S_set_error( " error while resolving CAPL environment object of '$TimeoutEnvVarName'", 0 );
        return;
    }

    #   unless( $CAPL_timing_signal_control =  VEC_get_env_variable( $OLE_handle , $TimingEnvVarName ) ) {
    #      S_set_error( " error while resolving CAPL environment object of '$TimingEnvVarName'", 0 );
    #      return;
    #   }

    return 1 if $main::opt_offline;

    if ( check_flags("OldEnableDisableHandling") eq 1 ) {
        S_w2log( 3, " VEC_enable_flxr_PDU_update : set CAPL $TimeoutEnvVarName = 1 \n" );
        $CAPL_timeout_signal_control->{'Value'} = 1;
    }

    else {
        S_w2log( 3, " VEC_enable_flxr_PDU_update : set CAPL $TimeoutEnvVarName = 0 \n" );
        $CAPL_timeout_signal_control->{'Value'} = 0;
    }

    #   S_w2log( 3, " VEC_enable_flxr_PDU_update : set CAPL $TimingEnvVarName = 1 \n" );
    #   $CAPL_timing_signal_control->{'Value'} = 1;

    return 1;
}

######################################################################

=head2 VEC_read_ecu_configure

    OLE_handle = VEC_read_ecu_configure ( CAN_tool );


=cut

######################################################################

sub VEC_read_ecu_configure
{
   my $device  = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_read_ecu_configure( CAN_tool )", 110 );
      return;
   }

   my (
      $OLE_handle ,
      $active_configuration ,
      $default_configuration ,
      $can_xcp_snd_id ,
      $can_xcp_rcv_id ,
      );


   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

   unless( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      ### open default configuration when no config was loaded
      unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
         S_w2log( 1, " VEC_read_ecu_configure: Could not open $device configuration '$default_configuration' \n" );
         return;
      }
      unless( VEC_xcp_init( $OLE_handle ) ) {
         S_w2log( 1, " VEC_read_ecu_configure: Could not initialize $device XCP functionality \n" );
         return;
      }
   }

   if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
      S_w2log( 5, " VEC_read_ecu_configure : OnlineConfiguration already loaded \n" );
   }
   else {
      ### stop measurement before loading the default configuration
      if( VEC_check_running( $OLE_handle ) ) {
         VEC_stop_measurement( $OLE_handle );
      }
      ### open default configuration (unload existing config)
      unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
         S_w2log( 1, " VEC_read_ecu_configure: Could not open $device configuration '$default_configuration' \n" );
         return;
      }
      unless( VEC_xcp_init( $OLE_handle ) ) {
         S_w2log( 1, " VEC_read_ecu_configure: Could not initialize $device XCP functionality \n" );
         return;
      }
   }

   ## start measurement
   unless( VEC_check_running( $OLE_handle ) ) {
      unless( VEC_start_measurement( $OLE_handle ) ) {
         S_w2log( 1, " VEC_read_ecu_configure: Could not start $device measurement \n" );
         return;
      }
      S_w2rep(" --> Wait 1000 ms \n");
      S_wait_ms( 1000 );
   }

   unless( $can_xcp_snd_id = $main::ProjectDefaults->{'XCP_CANTOOL'}{'xcp_snd_id'} ) {
     S_set_error( "no 'xcp_snd_id' found in main::ProjectDefaults->{'XCP_CANTOOL'}", 151 );
     return;
   }
   unless( $can_xcp_rcv_id = $main::ProjectDefaults->{'XCP_CANTOOL'}{'xcp_rcv_id'} ) {
     S_set_error( "no 'xcp_rcv_id' found in main::ProjectDefaults->{'XCP_CANTOOL'}", 151 );
     return;
   }

   unless( VEX_cmd_setmsgid( $can_xcp_snd_id , $can_xcp_rcv_id ) ) {
      S_w2log( 1, " VEC_read_ecu_configure: Could not set XCP_SEND_ID ($can_xcp_snd_id) and XCP_RCV_ID ($can_xcp_rcv_id) on $device\n" );
      return;
   }

   return $OLE_handle;
}


######################################################################

=head2 VEC_read_ecu_signal

    $hex_value =  VEC_read_ecu_signal ( $OLE_handle , \%ecu_signal );

the following XCP interface commands out LIFT_vector_xcp will be started:

   1. XCP connect
   2. XCP read signal
   3. XCP disconnect

the hash ecu_signal must have the following format:
   %ecu_signal = ( 'NAME'=> $given_ECU_SIGNAL ,   # ECU signal name out of EcuSigMapping
                   'ADDRESS'=>$ecu_sig_address ,  # ECU signal memory address
                   'LENGTH'=>$ecu_sig_length ,    # ECU signal length in byte
                   'TYPE'=>$type,                 # ECU signal type [ INTEL , MOTOROLA ]
                 );

just the HEX value will be returned

=cut

######################################################################

sub VEC_read_ecu_signal
{
   my ( $OLE_handle , $ecu_signal  ) = @_ ;

   unless( defined $ecu_signal ) {
      S_set_error( " SYNTAX: VEC_read_ecu_signal( OLE_handle , ecu_signal_hash_ref )", 110 );
      return;
   }

   my (
        $valid_flag ,
        $ecu_sig_value ,
       );


   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_read_ecu_signal : measurement not running use VEC_read_ecu_configure() before \n" );
      return;
   }

   unless( VEX_cmd_connect( ) ) {
      S_set_error( " No valid XCP connection established -> no further XCP action will be proceed \n" , 141);
      return;
   }

   unless ( ( $valid_flag , $ecu_sig_value ) = VEX_read_signal ( $ecu_signal ) )  {
     S_w2log( 1 , " VEC_read_ecu_signal : read of ECU signal failed \n");
     return;
   }

   VEX_cmd_disconnect( );

   return $ecu_sig_value;
}


######################################################################

=head2 VEC_write_ecu_configure

    VEC_write_ecu_configure ( CAN_tool );


=cut

######################################################################

sub VEC_write_ecu_configure
{
   my $device  = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_write_ecu_configure( CAN_tool )", 110 );
      return;
   }
   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_write_ecu_configure : OnlineConfiguration already loaded \n" );
      }
      else {
         ### stop measurement before loading the default configuration
         if( VEC_check_running( $OLE_handle ) ) {
            VEC_stop_measurement( $OLE_handle );
         }
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_write_ecu_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   return $OLE_handle;
}


######################################################################

=head2 VEC_write_ecu_signal

    return_value =  VEC_write_ecu_signal ( $OLE_handle , \%ecu_signal , $hex_signal_value );


the hash ecu_signal must have the following format:

    %ecu_signal = ( 'NAME'   => $given_ecu_signal ,
                    'ADDRESS'=> $ecu_sig_address ,
                    'VALUE'  => $ecu_sig_value_to_write ,
                    'LENGTH' => $ecu_sig_length ,
                    'TYPE'   =>'INTEL',
                   );



=cut

######################################################################

sub VEC_write_ecu_signal
{
   my ( $OLE_handle , $ecu_signal ) = @_ ;

   unless( defined $ecu_signal ) {
      S_set_error( " SYNTAX: VEC_write_ecu_signal( OLE_handle , ecu_signal_hash_ref )", 110 );
      return;
   }

   my (
        $valid_flag ,
        $return_value ,
       );

   return 1 if $main::opt_offline; # just return if running in offline mode

   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_write_ecu_signal : measurement not running use VEC_read_ecu_configure() before \n" );
      return;
   }

   unless( VEX_cmd_connect( ) ) {
      S_set_error( " No valid XCP connection established -> no further XCP action will be proceed \n" , 141);
      return;
   }

   unless ( ( $return_value ) = VEX_write_signal ( $ecu_signal ) )  {
     S_w2log( 1 , " VEC_write_ecu_signal : write of ECU signal failed \n");
     return;
   }

   VEX_cmd_disconnect( );

   return $return_value;
}


######################################################################

=head2 VEC_get_env_variable

 EnvVarObject = VEC_get_env_variable ( OLE_handle , EnvVarName );

=cut

######################################################################

sub VEC_get_env_variable
{
   my ( $OLE_handle , $env_var ) = @_ ;

   unless( defined $env_var ) {
      S_set_error( " SYNTAX: VEC_read_configuration( cantool_OLE_handle , EnvVarName )", 110 );
      return;
   }

   return 1 if $main::opt_offline;

   my ( $return_env_var_handle , $device , $hostname ) ;

   S_w2log( 5, " VEC_get_env_variable: return_env_var_handle = OLE_handle -> Application->Environment->GetVariable( $env_var ) .. \n" );
   unless( $return_env_var_handle = $OLE_handle -> Application -> Environment -> GetVariable( $env_var ) ) {
      $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
      $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};
      S_set_error( " $device application on $hostname : No environment variable '$env_var' available ", 0 );
      return;
   }

   S_w2log( 5, " VEC_get_env_variable: return object handle of EnvVar: $env_var \n" );

   return $return_env_var_handle;
}

######################################################################

=head2 VEC_read_lin_configure

    VEC_read_lin_configure ( LIN_tool );


=cut

######################################################################

sub VEC_read_lin_configure
{
   my $device  = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_read_lin_configure( LIN_tool )", 110 );
      return;
   }
   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_read_lin_configure : OnlineConfiguration already loaded \n" );
      }
      else {
         ### stop measurement before loading the default configuration
         if( VEC_check_running( $OLE_handle ) ) {
            VEC_stop_measurement( $OLE_handle );
         }
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_read_lin_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   unless( VEC_start_measurement( $OLE_handle ) ) {
      S_w2log( 1, " VEC_read_lin_configure: Could not start $device measurement\n" );
      return;
   }

   return $OLE_handle;
}


######################################################################


=head2 VEC_read_lin_signal
    
    ( $value , $unit ) =  VEC_read_lin_signal ( $OLE_handle , $lin_signal_name [, $mode ] );

Reads the lin signal from lin tool(s) 

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe

=item $lin_signal_name 

Name of the LIN signal

=item $mode 

(optional) Phys or hex

=back

B<Return Value:>

=item $returnValue 

Value - either Physical value or Hex value depending on mode.
Unit  - unit of the signal defined in Mapping file(returns only in case of phys mode).

(Value, Unit)  : Successful

(undef, undef) : Failure

=back

B<Examples:> 
  
    ( hex Value )        = VEC_read_lin_signal ( $OLE_handle, 'PreCrash_Fo_Kopfstuetze_verfahren', ' hex');
    ( phys Value , Unit) = VEC_read_lin_signal ( $OLE_handle, 'PreCrash_Fo_Kopfstuetze_verfahren', 'phys');

=cut

######################################################################

sub VEC_read_lin_signal {
    ### DESIGN  ###
   
   # COMMENT-START
        # get arguments 
        # mandatory :   
        # - $ole_handle_mix,
        # - $lin_signal_name
        # - $mode
   # COMMENT-END  
    
   # STEP validate arguments
   
   # IF CANoe measuement runing ? 
        #IF-YES-START
           # CALL VEC_get_lin_signal_info 
           # CALL VEC_validate_lin_signal_info             
           # CALL VEC_read_bus_signal_direct_raw
           # IF $mode ? 
              # IF-PHYS-START
            		# STEP GET the signal info from mapping & calculate phys value
            		# CALL VEC_calc_phys_from_raw                         
            		# STEP Return phys value and unit from Mapping
            	# IF-PHYS-END        
            	# IF-HEX_RAW-START
            		 # STEP Return Hex value and unit as undef
            	# IF-HEX_RAW-END           
        #IF-YES-END
        #IF-NO-START
            # STEP set (read value =  undef, unit = undef) & error CANoe measurement is not running   
        #IF-NO-END
   # STEP Return the read value (raw or phys) & unit

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_read_lin_signal ($OLE_handle_mix , $lin_signal_name , $mode )', @args );

    my $OLE_handle_mix  = shift @args;
    my $lin_signal_name = shift @args;
    my $mode            = shift @args;

    unless ( defined $mode ) {
        S_w2log( 3, " VEC_read_lin_signal : no mode (phys/hex) given , set to 'phys' per default )" );
        $mode = 'phys';
    }

    my ( $hex_value, $return_value, $lin_signal_href, $raw_value, $bus_type, );

    unless ( VEC_check_running($OLE_handle_mix) ) {
        S_w2log( 1, " VEC_read_lin_signal : measurement must be running while reading LIN signal $lin_signal_name \n" );
        return ( undef, undef );
    }

    $bus_type = 'LIN';

    # Get the information about lin signal from the lin mapping file
    $lin_signal_href = VEC_get_bus_signal_info( $lin_signal_name, $bus_type );

    #Validate the information about lin signal from the lin mapping file
    $lin_signal_href = VEC_validate_bus_signal_info( $lin_signal_href, $lin_signal_name, $bus_type );

    unless (%$lin_signal_href) {

        return ( undef, undef );
    }

    ($raw_value) = VEC_read_bus_signal_direct_raw( $OLE_handle_mix, $lin_signal_href, $bus_type );

    if ( $raw_value !~ /\d/ ) {
        S_w2log( 2, " VEC_read_lin_signal : read signal not successful -> wait 1 cycle time ($lin_signal_href->{'CYCLE'} ms) and read again\n" );
        S_wait_ms( $lin_signal_href->{'CYCLE'} );
        ($raw_value) = VEC_read_bus_signal_direct_raw( $OLE_handle_mix, $lin_signal_href, $bus_type );
    }

    if ( $mode =~ /hex/i ) {
        $hex_value = sprintf( "0x%X", $raw_value );
        $return_value = $hex_value;
         return ( $return_value, undef );
    }
    elsif ( $mode =~ /phys/i ) {
        $return_value = VEC_calc_phys_from_raw( $lin_signal_href, $raw_value );
         return ( $return_value, $lin_signal_href->{'UNIT'} );
    }else {
        S_w2log( 5, " VEC_read_lin_signal : read signal not successful\n" );
        return ( undef, undef );
    }

}

######################################################################

=head2 VEC_write_lin_configure

    VEC_write_lin_configure ( LIN_tool );


=cut

######################################################################

sub VEC_write_lin_configure
{
   my $device  = shift;

   unless( defined $device ) {
      S_set_error( " SYNTAX: VEC_write_lin_configure( LIN_tool )", 110 );
      return;
   }

   unless( $device =~ /CANoe/i ) {
      S_set_error( " LIN signal write just with CANoe and Env variables possible", 109 );
      return;
   }

   my ( $OLE_handle , $active_configuration );

   unless( $OLE_handle = $Vector_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
      S_set_error( " no OLE_handle available for '$device'", 131 );
      return;
   }

   if( $active_configuration = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
      my $default_configuration = $Vector_tool_control->{'Devices'}{$device}{'DefaultOnlineConfig'};

      if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
         S_w2log( 5, " VEC_write_lin_configure : OnlineConfiguration already loaded \n" );
      }
      else {
         ### stop measurement before loading the default configuration
         if( VEC_check_running( $OLE_handle ) ) {
            VEC_stop_measurement( $OLE_handle );
         }
         unless( VEC_open_configuration( $OLE_handle , $default_configuration , 1 ) ) {
            S_w2log( 1, " VEC_write_lin_configure: Could not open $device configuration '$default_configuration' \n" );
            return;
         }
      }
   }

   unless( VEC_start_measurement( $OLE_handle ) ) {
      S_w2log( 1, " VEC_write_lin_configure: Could not start $device measurement\n" );
      return;
   }

   return $OLE_handle;
}

######################################################################

=head2 VEC_write_lin_signal
    
    $return_value = VEC_write_lin_signal ( $ole_handle_mix , $lin_signal_name , $signal_value, $mode );

Writes the given value of a LIN signal to the CANoe OLE handle.

B<Note:> Low level funcion, should not be called directly in the testscript. use LIN_write_LIN_signal instead.  

B<Arguments:>

=over

=item $ole_handle_mix 

OLE handle of the CANoe application. 

=item $lin_signal_name 

Name of the signal 

=item $signal_value 

signal value to be written in CANoe. 

=item $mode 

Phys/hex 

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , undef : Failure

=back

B<Examples:> 
 
 my $lin_signal_href ; 
 $lin_signal_href->{'SIGNAL_NAME'} = "SigStimlus1ai"; 
 $lin_signal_href->{'CANOE_ENV_VAR'} = "EnvSigStimulus1_CAN";
 
 $status = VEC_write_lin_signal (<OLEhandle>, 'SigStimlus1ai','80', 'phys');
 $status = VEC_write_lin_signal (<OLEhandle>, 'SigStimlus1ai','0x80', 'hex');
 
=cut

######################################################################

sub VEC_write_lin_signal {

    #COMMENT-START
        # get arguments 
        # mandatory   
        # - $ole_handle_mix,
        # - $lin_signal_name
        # - $lin_signal_value
        # - $mode
        # optional - none
    #COMMENT-END

    # IF CANoe is running?
    # IF-NO-START
        # STEP written status = undef , Error CANoe is not Running 
    # IF-NO-END
    # IF-YES-START
        # CALL VEC_get_lin_signal_info
        # CALL VEC_validate_lin_signal_info
        
     	# IF $mode ?
    	   # IF-PHYS-START
    	                                   
    		  # CALL VEC_calc_raw_from_phys
    		  # STEP write write calculated raw value to $lin_signal_name
    	# IF-PHYS-END   
    	# IF-HEX_or_RAW-START                                                                                                      
    		  # STEP validate if $lin_signal_value is Hex if Yes proceed to write raw value (no conversion required)
    	# IF-HEX_or_RAW-END
        
        # IF IL used ?
            # IF-YES-START
                # STEP write directly to the signal object
                # CALL VEC_write_bus_signal_direct_raw
            # IF-YES-END
            # IF-NO-START
                # STEP write to envionment variable for the corresponding signal defined in mapping
                # CALL VEC_write_flexray_lin_signal_to_Env_var
            # IF-NO-END
        
    # IF-YES-END    
    # STEP return 1

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_write_lin_signal ( $ole_handle_mix, $lin_signal_name, $signal_value, $mode )', @args );

    my $ole_handle_mix  = shift @args;
    my $lin_signal_name = shift @args;
    my $signal_value    = shift @args;
    my $mode            = shift @args;

    my ( $lin_signal_href, $bus_type );

    $bus_type = 'LIN';

    unless ( VEC_check_running($ole_handle_mix) ) {
        S_w2log( 4, " VEC_write_lin_signal : measurement not running use VEC_write_lin_configure() before \n" );
        return;
    }

    # Get the information about flexray signal from the flexray mapping file
    $lin_signal_href = VEC_get_bus_signal_info( $lin_signal_name, $bus_type );

    #Validate the information about flexray signal from the flexray mapping file
    $lin_signal_href = VEC_validate_bus_signal_info( $lin_signal_href, $lin_signal_name, $bus_type );

    unless (%$lin_signal_href) {

        return;
    }

    if ( $mode =~ /hex/i ) {
        $signal_value = hex($signal_value) if($signal_value =~ /^0x[0-9A-F]+$/i);
    }
    elsif ( $mode =~ /phys/i ) {
        $signal_value = VEC_calc_raw_from_phys( $lin_signal_href, $signal_value );
    }

    if ( VEC_check_InteractionLayer_used() == 1 ) {
        unless ( $lin_signal_name = $lin_signal_href->{'SIGNAL_NAME'} ) {
            S_set_error( " VEC_write_lin_signal : no SIGNAL_NAME available for given lin_signal hash ref", 109 );
            return;
        }
        VEC_write_bus_signal_direct_raw( $ole_handle_mix, $bus_type, $lin_signal_href, $signal_value );
    }
    else {
        VEC_write_flexray_lin_signal_to_Env_var( $ole_handle_mix, $lin_signal_href, $signal_value );
    }

    return 1;
}

######################################################################

=head2  VEC_disable_lin_frame
    
    return_value =  VEC_disable_lin_frame ( $OLE_handle , $lin_frame );

Sets the value of Environment variable(for the key CANOE_DISABLE as defined in LIFT LIN mapping) to 1 if the frame has to be disabled .

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe application.

=item $message_name 

Name of LIN message as used in LIFT LIN mapping. 

=back

B<Return Value:>

=over

=item $returnValue 

1     : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    return_value =  VEC_disable_lin_frame ( $OLE_handle , "FrStimulus1_LIN");

B<Note:> Its a Low level funcion, do not call it directly in the testscript. instead call 'LIN_disable_frame'.

=cut

######################################################################

sub VEC_disable_lin_frame {
    my ( $OLE_handle, $lin_frame, $time_out_info, ) = @_;

    unless ( defined $lin_frame ) {
        S_set_error( " SYNTAX: VEC_disable_lin_frame( OLE_handle , lin_signal_ref , signal_value )", 110 );
        return;
    }

    my (
        $CAPL_timeout_signal_control,
        $CAPL_timing_signal_control,
        $TimeoutEnvVarName,

        #        $TimingEnvVarName ,
    );

    my $LIN_Mapping = S_get_contents_of_hash( ['Mapping_LIN'] );

    unless ($LIN_Mapping) {
        S_set_error( " LIFT LIN mapping doesnot exist", 0 );
    }

    unless ( $TimeoutEnvVarName = $LIN_Mapping->{'LIN_MESSAGES'}{$lin_frame}{'CANOE_DISABLE'} ) {
        S_set_error( " no EnvVar 'CANOE_DISABLE' available for given lin_frame '$lin_frame' in LIFT LIN Mapping", 109 );
        return;
    }

    #CANOE_TIMING information is not required since lin frame from slave is enabled only when master puts a header on the bus and
    #a lin frame is not time scheduled
    #   unless( $TimingEnvVarName = $LIN_Mapping->{'LIN_MESSAGES'}{ $lin_frame }{'CANOE_TIMING'} ) {
    #      S_set_error( " no EnvVar 'CANOE_TIMING' available for given lin_frame '$lin_frame' in LIFT LIN mapping", 109 );
    #      return;
    #   }

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_disable_lin_frame : measurement not running use VEC_write_lin_configure() before \n" );
        return;
    }

    unless ( $CAPL_timeout_signal_control = VEC_get_env_variable( $OLE_handle, $TimeoutEnvVarName ) ) {
        S_set_error( " error while resolving CAPL environment object of '$TimeoutEnvVarName'", 0 );
        return;
    }

    #   unless( $CAPL_timing_signal_control =  VEC_get_env_variable( $OLE_handle , $TimingEnvVarName ) ) {
    #      S_set_error( " error while resolving CAPL environment object of '$TimingEnvVarName'", 0 );
    #      return;
    #   }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEC_disable_lin_frame : set CAPL $TimeoutEnvVarName = 1 \n" );
    $CAPL_timeout_signal_control->{'Value'} = 1;

    #   if( $time_out_info ) {
    #      S_w2log( 3, " VEC_disable_lin_frame : set CAPL $TimingEnvVarName = $time_out_info \n" );
    #      $CAPL_timing_signal_control->{'Value'} = $time_out_info;
    #   }
    return 1;
}

######################################################################

=head2  VEC_enable_lin_frame
    
    return_value =  VEC_enable_lin_frame ( $OLE_handle , $lin_frame );

Sets the value of Environment variable(for the key CANOE_DISABLE as defined in LIFT LIN mapping) to 0 if the frame has to be enabled .

B<Arguments:>

=over

=item $OLE_handle 

OLE handle of the CANoe application.

=item $message_name 

Name of LIN message as used in LIFT LIN mapping.  

=back

B<Return Value:>

=over

=item $returnValue 

1     : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    return_value =  VEC_enable_lin_frame ( $OLE_handle , "FrStimulus1_LIN");

B<Note1:> Its a Low level funcion, do not call it directly in the testscript. instead call 'LIN_enable_frame'.

=cut

######################################################################

sub VEC_enable_lin_frame {
    my ( $OLE_handle, $lin_frame, ) = @_;

    unless ( defined $lin_frame ) {
        S_set_error( " SYNTAX: VEC_enable_lin_frame( OLE_handle , lin_signal_ref , signal_value )", 110 );
        return;
    }

    my (
        $CAPL_timeout_signal_control,
        $CAPL_timing_signal_control,
        $TimeoutEnvVarName,

        #       $TimingEnvVarName ,
    );

    my $LIN_Mapping = S_get_contents_of_hash( ['Mapping_LIN'] );

    unless ($LIN_Mapping) {
        S_set_error( " LIFT LIN mapping doesnot exist", 0 );
    }

    unless ( $TimeoutEnvVarName = $LIN_Mapping->{'LIN_MESSAGES'}{$lin_frame}{'CANOE_DISABLE'} ) {
        S_set_error( " no EnvVar 'CANOE_DISABLE' available for given lin_frame '$lin_frame' in LIFT LIN Mapping", 109 );
        return;
    }

    #CANOE_TIMING information is not required since lin frame from slave is enabled only when master puts a header on the bus and
    #a lin frame is not time scheduled
    #   unless( $TimingEnvVarName = $LIN_Mapping->{'LIN_MESSAGES'}{ $lin_frame }{'CANOE_TIMING'} ) {
    #      S_set_error( " no EnvVar 'CANOE_TIMING' available for given lin_frame '$lin_frame' in LIFT LIN mapping", 109 );
    #      return;
    #   }

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_enable_lin_frame : measurement not running use VEC_write_lin_configure() before \n" );
        return;
    }

    unless ( $CAPL_timeout_signal_control = VEC_get_env_variable( $OLE_handle, $TimeoutEnvVarName ) ) {
        S_set_error( " error while resolving CAPL environment object of '$TimeoutEnvVarName'", 0 );
        return;
    }

    #   unless( $CAPL_timing_signal_control =  VEC_get_env_variable( $OLE_handle , $TimingEnvVarName ) ) {
    #      S_set_error( " error while resolving CAPL environment object of '$TimingEnvVarName'", 0 );
    #      return;
    #   }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEC_enable_lin_frame : set CAPL $TimeoutEnvVarName = 0 \n" );
    $CAPL_timeout_signal_control->{'Value'} = 0;

    return 1;
}

######################################################################

=head2 VEC_trace_lin_get_dataref

    $trace_data_ref = VEC_trace_lin_get_dataref ( $LIN_tool_trace , @lin_signal_or_message_list );

    Structure of returned trace_data_ref is:

    $trace_data_ref = {
                        'timestamp_1' => {
                                       'message_A' => 'DLC_A1' ,
                                       'signal_1' => 'phys_value_at_time_1',
                                       'signal_2' => 'phys_value_at_time_1',
                                       'message_B' => 'DLC_B1' ,
                                       'signal_3' => 'phys_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                       'message_A' => 'DLC_A2' ,
                                       'signal_1' => 'phys_value_at_time_2',
                                       'signal_2' => 'phys_value_at_time_2',
                                       'message_B' => 'DLC_B2' ,
                                       'signal_3' => 'phys_value_at_time_2',
                                          },
                     };

=cut

######################################################################

sub VEC_trace_lin_get_dataref {
    my $lin_trace_file = shift;
    my @given_lin_signals_or_messages = @_;

    #
    # if somebody send an ARRAY_REF instead of ARRAY...
    #
    if( ref $given_lin_signals_or_messages[0] eq 'ARRAY' ) {
        my @temp = @{ $given_lin_signals_or_messages[0] };
        @given_lin_signals_or_messages = @temp;
    }
    # convert the ARRAY_REF to ARRAY
    #

    unless( @given_lin_signals_or_messages ) {
      S_set_error( " SYNTAX: VEC_trace_lin_get_dataref( '$lin_trace_file' , @given_lin_signals_or_messages )", 110 ); return;
    }

    my $ReturnDataRef = {};    # < - - declared as hash ref initially

    my (
        $data_format ,
        $timestamps ,
        $lin_signal ,
        $NeededMsgs ,
        $msg_name ,
        $DATA,
        $DLC ,
        $ID_dec ,
        $ID_hex ,
        $ID ,
        $found_messages ,
        $signal_data_ref ,
        $value ,
        $LIN_bus_cables_changed_flag ,
        $just_message_infos ,
        $just_signal_infos ,
        $label_mapping ,
      );

    return $signal_data_ref = {} if $main::opt_offline;

    my $LIN_Mapping = S_get_contents_of_hash(['Mapping_LIN']);

    unless( $LIN_Mapping ) {
        S_set_error( " LIFT LIN mapping doesnot exist" ,0 );
    }

    unless( ( $data_format , $timestamps ) = VEC_trace_lin_analyze_format( $lin_trace_file ) ) {
      S_set_error( " couldnt determine format of LIN trace '$lin_trace_file'" , 131 ); return;
    }

    unless( $timestamps =~ /absolut/i ) {
      S_set_error( " timestamps in trace must be configured as 'absolute'" , 131 ); return;
    }

    ## collect all needed messages
    foreach my $lin_signal_or_message ( @given_lin_signals_or_messages ) {

      if( my $mapped_signal = $main::ProjectDefaults->{'LABEL_MAPPING'}{ $lin_signal_or_message } ) {
          S_w2log( 3 , " VEC_trace_lin_get_dataref: found mapping '$lin_signal_or_message' --> '$mapped_signal'\n" );
          $label_mapping->{ $mapped_signal } = $lin_signal_or_message;
          $lin_signal_or_message = $mapped_signal;
      }

      if( $LIN_Mapping->{ 'LIN_MESSAGES' }{ $lin_signal_or_message } ) {
          # message infos are requested
          $msg_name = $lin_signal_or_message ;
          undef $lin_signal;

          $just_message_infos = 1 ;
          $just_signal_infos = 0 ;

      }
      else {
          # signal infos are requested
          $lin_signal = $lin_signal_or_message ;
          undef $msg_name;
          unless( $msg_name = $LIN_Mapping->{$lin_signal}{'MESSAGE'} ) {
             S_set_error( " VEC_trace_lin_get_signal_data: no 'MESSAGE' defined for LIN signal '$lin_signal' in LIN MAPPING\n" , 109);
             return;
          }
          $just_message_infos = 0 ;
          $just_signal_infos = 1 ;
      }

      $ID_dec = $LIN_Mapping->{'LIN_MESSAGES'}{$msg_name}{'ID'};

#find out 'if' loop is required
      if( $ID_dec > 0xFF ) {
          S_w2log( 5, " VEC_trace_lin_get_dataref: given ID $ID_dec (dec) / 0x".uc sprintf( "%x" , $ID_dec)." (hex) is greater the 8 bit \n" );
          $ID_dec = $ID_dec & 0xFF;  # mask with 8bit
          S_w2log( 5, " VEC_trace_lin_get_dataref: changed to $ID_dec (dec) / 0x".uc sprintf( "%x" , $ID_dec)." (hex) \n" );
      }

      $ID_hex = uc sprintf( "%x" , $ID_dec );
      $ID = $ID_dec if $data_format =~ /dec/i ;
      $ID = $ID_hex if $data_format =~ /hex/i ;

      $LIN_bus_cables_changed_flag = 0;

      unless( $found_messages = $NeededMsgs->{ $msg_name }{ 'FOUND' } ) {
         $found_messages = VEC_trace_lin_get_message_data( $lin_trace_file , $ID );

         ## then search with the symbolic name from LIN mapping
         unless( defined $found_messages ) {
            $found_messages = VEC_trace_lin_get_message_data( $lin_trace_file , $msg_name );
         }

         unless( $found_messages )  {
            S_w2log( 3, " VEC_trace_lin_get_dataref : couldnt find LIN message $msg_name \n" ) if $just_message_infos;
            S_w2log( 3, " VEC_trace_lin_get_dataref : couldnt find LIN message $msg_name for (signal : $lin_signal) \n" ) if $just_signal_infos;
            next;
         }

         $NeededMsgs->{ $msg_name }{ 'FOUND' } = $found_messages ;

          if( $just_message_infos ) {
              foreach my $time_stamp ( sort {$a<=>$b} keys %$found_messages ) {
                 $DATA = $found_messages->{ $time_stamp }{'DATA'};
                 #S_w2log( 5, " VEC_trace_lin_get_dataref : add $time_stamp : $msg_name  = $DATA \n" );
                 $ReturnDataRef->{ $time_stamp }{ $msg_name."_DATA" } = $DATA;

                 $DLC = $found_messages->{ $time_stamp }{'DLC'};
                 #S_w2log( 5, " VEC_trace_lin_get_dataref : add $time_stamp : $msg_name  = $DLC \n" );
                 $ReturnDataRef->{ $time_stamp }{ $msg_name."_DLC" } = $DLC;
                 if( my $label = $label_mapping->{ $msg_name."_DLC" } ) { $ReturnDataRef->{$time_stamp}{$label}= $DLC }
              }
              next ;
          }

      }


      $signal_data_ref = VEC_trace_lin_get_signal_data( $found_messages , $lin_signal , $data_format );
      foreach my $time_stamp ( sort {$a<=>$b} keys %$signal_data_ref ) {
         $value = $signal_data_ref->{ $time_stamp };
    #         S_w2log( 5, " VEC_trace_lin_get_dataref : add $time_stamp : $lin_signal  = $value \n" );
         $ReturnDataRef->{ $time_stamp }{ $lin_signal } = $value;
         if( my $label = $label_mapping->{ $lin_signal } ) { $ReturnDataRef->{$time_stamp}{$label}= $value }
      }
    }

    return $ReturnDataRef;
}

######################################################################

=head2 VEC_trace_lin_get_message_data

    $message_ref = VEC_trace_lin_get_message_data ( $lin_log_file , $lin_frame );

Reads a single frame from a Canalyzer logfile. $lin_log_file is the full name of the logfile.
$lin_frame is symbolic name or decimal or hexadecimal value of the LIN frame in the logfile.
Returns reference to hash structure:

      $message_ref->{$timestamp}{'DLC'} = DLC;
      $message_ref->{$timestamp}{'DATA'} = raw bytes of message;

=cut

######################################################################

sub VEC_trace_lin_get_message_data
{

   my $lin_log_file = shift;
   my $lin_message  = shift;

   my ($msg_cnt, $all_msgs);

   unless (defined( $lin_message )) {
     S_set_error( "SYNTAX: VEC_trace_lin_get_message_data( lin_log_file , lin_message , lin_bus_nbr)", 110 ); return ;
   }

   return 1 if $main::opt_offline; # just return if running in offline mode

   my $Trace_FH = new FileHandle;
   unless( $Trace_FH->open( $lin_log_file ) ) { S_set_error( " Couldnt open LIN Trace '$lin_log_file' ", 131 ); return; }

   $msg_cnt = 0;

   S_w2log( 3, " VEC_trace_lin_get_message_data : Reading LIN frame '$lin_message' from $lin_log_file)\n" );

   while( <$Trace_FH> ) {
        ## try to match:
        ##      3.688702 Li 31              Tx     8 00 00 e0 ff fe fe b3 ff  checksum = bb
        if( /^
          \s*        # leading spaces
          (\d+\.\d+)    # timestamp
          \s+        # spaces
           Li        # must be Li for lin
          \s+        # spaces
          $lin_message        
          \s+        # spaces
          [TxRq]+      # match Rx or Tx or TxRq
          \s+        # spaces                 
          (\d+)      # DLC
          ((\s+[\da-fA-F]{2})+)      # only Data bytes are considered
          /ix )
        {
            $msg_cnt++;
            $all_msgs->{$1}{'DLC'} = $2;
            $all_msgs->{$1}{'DATA'} = $3;
        }
    }
    $Trace_FH->close;

    S_w2log( 4, " VEC_trace_lin_get_message_data : Found $lin_message -> $msg_cnt times\n" );

    return $all_msgs;
}

######################################################################

=head2 VEC_trace_lin_get_signal_data

    $signal_data_ref = VEC_trace_lin_get_signal_data( $found_messages , $lin_signal , $data_format );

Reads a single Signal from a message data ref read by VEC_trace_lin_get_message_data.

$found_messages = {
                     timestamp1 => {
                                    'DATA' =>  '00 18 00 00 FE FE 00 18',
                                    },
                     timestamp2 => {
                                    'DATA' =>  '00 18 00 00 FE FE 00 18',
                                    },
                 };

$lin_signal is the name of LIN signal in LIFT LIN Mapping

$data_format is format of data in LIN trace : 'dec' or 'hex'

Returns hash ref structure:

      $signal_data_ref = {
                           $timestamp1 => $phys_value1,
                           $timestamp2 => $phys_value2,
                        };

The Values are already the needed

=cut

######################################################################

sub VEC_trace_lin_get_signal_data
{

    my $all_msgs = shift;
    my $lin_signal = shift;
    my $data_format = shift;         ### DEC or HEX

    my (
         $data_raw ,
         @data_list ,
         $signal_length ,
         $signal_factor ,
         $signal_offset ,
         $signal_format ,     ### INTEL or MOTOROLA
         $signal_start_bit ,
         $signal_type ,

         $signal_MX_Master,
         $signal_MX_Master_value_phys ,
         $signal_MX_Master_length ,
         $signal_MX_Master_factor ,
         $signal_MX_Master_offset ,
         $signal_MX_Master_format ,     ### INTEL or MOTOROLA
         $signal_MX_Master_start_bit ,
         $signal_MX_Master_type ,
         $signal_MX_Master_code_value ,
         $multiplex_type ,

         $lin_frame_bin ,
         $byte_value ,
         $byte_bin_lsb ,
         $signal_lsb ,
         $signal_msb ,
         $signal_raw_value ,
         $sig_value_phys ,
         $sig_data_ref ,
         $dlc ,
         $temp_sig_pos_start ,
         $temp_lin_frame_bin ,
         $signal_msb_without_sign ,
         $signal_msb_without_sign_compl ,
         $sign_factor ,
      );


    unless (defined( $data_format )) {
        S_set_error( "VEC_trace_lin_get_signal_data: SYNTAX: VEC_trace_lin_get_signal_data ( message_ref, lin_signal, base_format )", 110 );
        return;
    }

    # Here we are using plain integer variables to speed up the loops later.
    # Pattern matching in the loops is too slow
    # Also using constants in the loops is too slow
    my $format_dec = 1;
    my $format_hex = 2;

    if( $data_format =~ /dec/i ) {
        $data_format = $format_dec;
    }
    elsif($data_format =~ /hex/i){
        $data_format = $format_hex;
    }
    else {
        S_set_error( "VEC_trace_lin_get_signal_data: parameter 'base' must be 'dec' or 'hex'", 114 ); #110 before
        return;
    }

    my $LIN_Mapping = S_get_contents_of_hash(['Mapping_LIN']);

    unless( $LIN_Mapping ) {
        S_set_error( " LIFT LIN mapping doesnot exist" ,0 );
    }

    $signal_length = $LIN_Mapping->{ $lin_signal }{'LENGTH'};
    unless( defined $signal_length ) {
       S_set_error( " VEC_trace_lin_get_signal_data: no 'LENGTH' defined for LIN signal '$lin_signal' in LIN MAPPING\n" , 109);
       return;
    }

    $signal_offset = $LIN_Mapping->{ $lin_signal }{'OFFSET'};
    unless( defined $signal_offset ) {
       S_set_error( " VEC_trace_lin_get_signal_data: no 'OFFSET' defined for LIN signal '$lin_signal' in LIN MAPPING\n" , 109);
       return;
    }

    $signal_factor = $LIN_Mapping->{ $lin_signal }{'FACTOR'};
    unless( defined $signal_factor ) {
       S_set_error( " VEC_trace_lin_get_signal_data: no 'FACTOR' defined for LIN signal '$lin_signal' in LIN MAPPING\n" , 109);
       return;
    }

    $signal_format = $LIN_Mapping->{ $lin_signal }{'FORMAT'};
    unless( defined $signal_format ) {
       S_set_error( " VEC_trace_lin_get_signal_data: no 'FORMAT' defined for LIN signal '$lin_signal' in LIN MAPPING\n" , 109);
       return;
    }
   
    # Here we are using plain integer variables to speed up the loops later.
    # Pattern matching in the loops is too slow
    # Also using constants in the loops is too slow
    my $format_intel = 1;
    my $format_motorola = 2;

    if( $signal_format =~ /INTEL/i ){
        $signal_format = $format_intel;
    }
    elsif( $signal_format =~ /MOTOROLA/i ){
        $signal_format = $format_motorola;
    }
    else{
        S_set_error( "VEC_trace_lin_get_signal_data: 'FORMAT' of signal '$lin_signal' in LIN Mapping must be INTEL or MOTOROLA", 110 );
        return;
    }   

    $signal_start_bit = $LIN_Mapping->{ $lin_signal }{'STARTBIT'};
    unless( defined $signal_start_bit ) {
       S_set_error( " VEC_trace_lin_get_signal_data: no 'FORMAT' defined for LIN signal '$lin_signal' in LIN MAPPING\n" , 109);
       return;
    }

    $signal_type = $LIN_Mapping->{ $lin_signal }{'TYPE'};
    unless( defined $signal_type ) {
       S_set_error( " VEC_trace_lin_get_signal_data: no 'TYPE' defined for LIN signal '$lin_signal' in LIN MAPPING\n" , 109);
       return;
    }
    unless ( $signal_type =~ /^SIGNED/i or $signal_type =~ /^UNSIGNED/i) {
        S_set_error( "VEC_trace_lin_get_signal_data: 'TYPE' of signal '$lin_signal' in LIN Mapping must be SIGNED or UNSIGNED", 110 );
        return;
    }

    $signal_MX_Master = $LIN_Mapping->{ $lin_signal }{'MULTIPLEX'}{'MASTER'};
    $signal_MX_Master_code_value = $LIN_Mapping->{ $lin_signal }{'MULTIPLEX'}{'CODE'};
    if(defined $signal_MX_Master and not defined $signal_MX_Master_code_value) {
        $multiplex_type = 'MASTER';
    }elsif(defined $signal_MX_Master and defined $signal_MX_Master_code_value) {
        $multiplex_type = 'SLAVE';
        S_w2log( 3 , " VEC_trace_lin_get_signal_data : MULTIPLEX SLAVE signal '$lin_signal' (MASTER='$signal_MX_Master' CODE='$signal_MX_Master_code_value')\n"  );
    }elsif(not defined $signal_MX_Master and defined $signal_MX_Master_code_value) {
        S_set_error( "VEC_trace_lin_get_signal_data: wrong signal config ('CODE' defined but not 'MASTER' defined)", 110 );
        return;
    }else {
        $multiplex_type = 'NO_MULTIPLEX';
    }


    if( $multiplex_type eq 'SLAVE' ) {

        $signal_MX_Master_length = $LIN_Mapping->{ $signal_MX_Master }{'LENGTH'};
        unless( defined $signal_MX_Master_length ) {
           S_set_error( " VEC_trace_lin_get_signal_data: no 'LENGTH' defined for LIN signal '$signal_MX_Master' in LIN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_offset = $LIN_Mapping->{ $signal_MX_Master }{'OFFSET'};
        unless( defined $signal_MX_Master_offset ) {
           S_set_error( " VEC_trace_lin_get_signal_data: no 'OFFSET' defined for LIN signal '$signal_MX_Master' in LIN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_factor = $LIN_Mapping->{ $signal_MX_Master }{'FACTOR'};
        unless( defined $signal_MX_Master_factor ) {
           S_set_error( " VEC_trace_lin_get_signal_data: no 'FACTOR' defined for LIN signal '$signal_MX_Master' in LIN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_format = $LIN_Mapping->{ $signal_MX_Master }{'FORMAT'};
        unless( defined $signal_MX_Master_format ) {
           S_set_error( " VEC_trace_lin_get_signal_data: no 'FORMAT' defined for LIN signal '$signal_MX_Master' in LIN MAPPING\n" , 109);
           return;
        }

        if( $signal_MX_Master_format =~ /INTEL/i ){
            $signal_MX_Master_format = $format_intel;
        }
        elsif( $signal_MX_Master_format =~ /MOTOROLA/i ){
            $signal_MX_Master_format = $format_motorola;
        }
        else{
            S_set_error( "VEC_trace_lin_get_signal_data: 'FORMAT' of signal '$signal_MX_Master' in LIN Mapping must be INTEL or MOTOROLA", 110 );
            return;
        }

        $signal_MX_Master_start_bit = $LIN_Mapping->{ $signal_MX_Master }{'STARTBIT'};
        unless( defined $signal_MX_Master_start_bit ) {
           S_set_error( " VEC_trace_lin_get_signal_data: no 'FORMAT' defined for LIN signal '$signal_MX_Master' in LIN MAPPING\n" , 109);
           return;
        }

        $signal_MX_Master_type = $LIN_Mapping->{ $signal_MX_Master }{'TYPE'};
        unless( defined $signal_MX_Master_type ) {
           S_set_error( " VEC_trace_lin_get_signal_data: no 'TYPE' defined for LIN signal '$signal_MX_Master' in LIN MAPPING\n" , 109);
           return;
        }
        unless ( $signal_MX_Master_type =~ /^SIGNED/i or $signal_MX_Master_type =~ /^UNSIGNED/i) {
            S_set_error( "VEC_trace_lin_get_signal_data: 'TYPE' of signal '$signal_MX_Master' in LIN Mapping must be SIGNED or UNSIGNED", 110 );
            return;
        }
    }

    return 1 if $main::opt_offline; # just return if running in offline mode

    foreach my $time_stamp ( sort {$a<=>$b} keys %$all_msgs ){
        $data_raw = $all_msgs->{$time_stamp}{ 'DATA' };  $data_raw =~ s/^\s+//g;  ## remove possible leading spaces
#         S_w2log( 1, " data_raw  : $data_raw  \n" );
        ## convert string to list of data bytes ( $data_list[0] eq CAN Byte 0)
        @data_list = split( /\s+/ , $data_raw);
        $lin_frame_bin = "";  ## LIN frame binary format (LSB)

        foreach my $data_byte (@data_list) {
            ## converts 'F0' into '00001111' (LSB format) (starting with lowest significant bit))
            ##   PERL lesson:
            ##                 - 'hex $data_byte' interprete given value as hexadecimal value
            ##                 - 'sprintf( "%08b",...' format the given value into 8bit format (MSB)
            ##                 - 'reverse' sort the given scalar in opposite order (that means: MSB to LSB)
            if( $data_format == $format_hex )     { $byte_value = hex $data_byte; }  # format hex
            elsif ( $data_format == $format_dec ) { $byte_value =     $data_byte; }  # format dec
            if( $signal_format == $format_intel )       { $byte_bin_lsb = reverse sprintf( "%08b" , $byte_value ); }
            elsif( $signal_format == $format_motorola) { $byte_bin_lsb =         sprintf( "%08b" , $byte_value ); }
#             S_w2log( 1, " byte_bin_lsb : $byte_bin_lsb ($data_byte , $byte_value )\n" );
            ## create the full LIN message by concatinating all bytes (binary LSB)
            $lin_frame_bin .= $byte_bin_lsb;
        }

        #
        # section for MULTIPLEX master in case of SLAVE signal required
        #
        if( $multiplex_type eq 'SLAVE' ) {

            if( $signal_MX_Master_format == $format_intel ) { # INTEL
                $signal_lsb = substr ( $lin_frame_bin , $signal_MX_Master_start_bit , $signal_MX_Master_length );
            }
            elsif( $signal_MX_Master_format == $format_motorola ) { # MOTOROLA
                $temp_lin_frame_bin = reverse $lin_frame_bin;
                $dlc = $all_msgs->{$time_stamp}{ 'DLC' } ;
                $temp_sig_pos_start = $dlc * 8 - ( ( $signal_MX_Master_start_bit>>3 ) << 3 ) - ( 7 + ( ( $signal_MX_Master_start_bit>>3 ) << 3 ) - $signal_MX_Master_start_bit );
                $signal_lsb = substr ( $temp_lin_frame_bin , $temp_sig_pos_start - $signal_MX_Master_length , $signal_MX_Master_length );
            }
            $signal_msb = reverse $signal_lsb;
            if( $signal_MX_Master_type eq 'SIGNED' and $signal_msb =~ /^1/ ) {
                $signal_msb_without_sign = substr($signal_msb,1,length($signal_msb)-1);
    #             S_w2log( 1, " VEC_trace_lin_get_signal_data: signal_msb_without_sign = $signal_msb_without_sign  \n");
                $signal_msb_without_sign_compl = ~ $signal_msb_without_sign;   # 2 - complement (change all bits)
                $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb_without_sign_compl , -32)));
    #             S_w2log( 1, " VEC_trace_lin_get_signal_data: signal_raw_value = $signal_raw_value  \n");
                $signal_raw_value = ($signal_raw_value + 1) * -1;  # add 1 due to calculation rule with signed values and multiply with -1

            } else {
                $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb, -32)));
            }
            $signal_MX_Master_value_phys = ($signal_raw_value * $signal_MX_Master_factor) + $signal_MX_Master_offset ;

            unless ( $signal_MX_Master_value_phys == $signal_MX_Master_code_value ) {
#                 S_w2log( 5 , " VEC_trace_lin_get_signal_data:  [$time_stamp] no signal for '$can_signal' ( Master = $signal_MX_Master_value_phys ) \n" );
                next;
            }
        }
        #
        # end of MULTIPLEX section
        #

        if( $signal_format == $format_intel ) {
            $signal_lsb = substr ( $lin_frame_bin , $signal_start_bit , $signal_length );
        }
        elsif( $signal_format == $format_motorola  ) {
            $temp_lin_frame_bin = reverse $lin_frame_bin;
            $dlc = $all_msgs->{$time_stamp}{ 'DLC' } ;
            $temp_sig_pos_start = $dlc * 8 - ( ( $signal_start_bit>>3 ) << 3 ) - ( 7 + ( ( $signal_start_bit>>3 ) << 3 ) - $signal_start_bit );
            $signal_lsb = substr ( $temp_lin_frame_bin , $temp_sig_pos_start - $signal_length , $signal_length );
        }
        $signal_msb = reverse $signal_lsb;
        if( $signal_type eq 'SIGNED' and $signal_msb =~ /^1/ ) {
            $signal_msb_without_sign = substr($signal_msb,1,length($signal_msb)-1);
#             S_w2log( 1, " VEC_trace_lin_get_signal_data: signal_msb_without_sign = $signal_msb_without_sign  \n");
            $signal_msb_without_sign_compl = ~ $signal_msb_without_sign;   # 2 - complement (change all bits)
            $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb_without_sign_compl , -32)));
#             S_w2log( 1, " VEC_trace_lin_get_signal_data: signal_raw_value = $signal_raw_value  \n");
            $signal_raw_value = ($signal_raw_value + 1) * -1;  # add 1 due to calculation rule with signed values and multiply with -1

        } else {
            $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb, -32)));
        }
        $sig_value_phys = ($signal_raw_value * $signal_factor) + $signal_offset ;
        $sig_data_ref->{ $time_stamp } = $sig_value_phys ;
    }

    unless( $sig_data_ref ) {
        S_w2log( 3, " VEC_trace_lin_get_signal_data : could not extract signal $lin_signal at startbit: $signal_start_bit, length: $signal_length format: $signal_format\n");
    }

    return $sig_data_ref;
}

######################################################################

=head2 VEC_LIN_set_DLC

    return_value =  VEC_LIN_set_DLC ( $OLE_handle , $message_name , DLC);

   function controls
     CAPL env variables 'CANOE_DLC' as defined in LIFT NET Mapping

   CAN_message   : name of LIN message as used in LIFT NET Mapping
   DLC           : DLC to be set

=cut

######################################################################

sub VEC_LIN_set_DLC
{
   my (
         $OLE_handle ,
         $message_name ,
         $given_DLC ,
         ) = @_ ;

   unless( defined $given_DLC ) {
      S_set_error( " SYNTAX: VEC_LIN_set_DLC( OLE_handle , message_name , DLC )", 110 );
      return;
   }

   my (
        $CAPL_DLC_signal_control ,
        $DLCEnvVarName ,
       );

    my $LIN_Mapping = S_get_contents_of_hash(['Mapping_LIN']);

    unless( $LIN_Mapping ) {
        S_set_error( " LIFT LIN mapping doesnot exist" ,0 );
    }

   unless( $DLCEnvVarName = $LIN_Mapping->{'LIN_MESSAGES'}{ $message_name }{'CANOE_DLC'} ) {
      S_set_error( " no EnvVar 'CANOE_DLC' available for given message_name '$message_name' in LIFT NET Mapping", 109 );
      return;
   }

   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_LIN_set_DLC : measurement not running use VEC_write_lin_configure() before \n" );
      return;
   }

   unless( $CAPL_DLC_signal_control =  VEC_get_env_variable( $OLE_handle , $DLCEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$DLCEnvVarName'", 0 );
      return;
   }

   return 1 if $main::opt_offline;

   S_w2log( 5, " VEC_LIN_set_DLC : set CAPL $DLCEnvVarName = $given_DLC \n" );
   $CAPL_DLC_signal_control->{'Value'} = $given_DLC ;

   return 1;
}

######################################################################

=head2 VEC_LIN_reset_DLC

    return_value =  VEC_LIN_reset_DLC ( $OLE_handle , $message_name [, DLC ] );

   function controls
     CAPL env variables 'CANOE_DLC' as defined in LIFT NET Mapping

   LIN_message   : name of LIN message as used in LIFT NET Mapping
   DLC           : DLC to be set (if not given original one from LIFT LIN mapping will be taken)

=cut

######################################################################

sub VEC_LIN_reset_DLC
{
   my (
         $OLE_handle ,
         $message_name ,
         $given_DLC ,
      ) = @_ ;

   unless( defined $message_name ) {
      S_set_error( " SYNTAX: VEC_LIN_reset_DLC( $OLE_handle , message_name [, DLC ] )", 110 );
      return;
   }

   my (
        $CAPL_DLC_signal_control ,
        $DLCEnvVarName ,
        $Orig_DLC ,
       );

    my $LIN_Mapping = S_get_contents_of_hash(['Mapping_LIN']);

    unless( $LIN_Mapping ) {
        S_set_error( " LIFT LIN mapping doesnot exist" ,0 );
    }

   unless( $DLCEnvVarName = $LIN_Mapping->{'LIN_MESSAGES'}{ $message_name }{'CANOE_DLC'} ) {
      S_set_error( " no EnvVar 'CANOE_DISABLE' available for given message_name '$message_name' in LIFT NET Mapping", 109 );
      return;
   }

   unless( defined $given_DLC ) {
      unless( $Orig_DLC = $LIN_Mapping->{'LIN_MESSAGES'}{ $message_name }{'DLC'} ) {
         S_set_error( " no 'DLC' available for given message_name '$message_name' in LIFT NET Mapping", 109 );
         return;
      }
   }

   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_LIN_reset_DLC : measurement not running use VEC_write_lin_configure() before \n" );
      return;
   }

   unless( $CAPL_DLC_signal_control =  VEC_get_env_variable( $OLE_handle , $DLCEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$DLCEnvVarName'", 0 );
      return;
   }

   return 1 if $main::opt_offline;

   if( defined $given_DLC ) {
      S_w2log( 3, " VEC_LIN_reset_DLC : set CAPL $DLCEnvVarName = $given_DLC \n" );
      $CAPL_DLC_signal_control->{'Value'} = $given_DLC ;   ### or set to '0' ??
   }
   else {
      S_w2log( 3, " VEC_LIN_reset_DLC : set CAPL $DLCEnvVarName = $Orig_DLC (orig from CAN mapping)\n" );
      $CAPL_DLC_signal_control->{'Value'} = $Orig_DLC ;
   }

   return 1;
}

######################################################################


=head2 VEC_trace_fr_get_PDU_data

    $message_ref = VEC_trace_fr_get_PDU_data ( $fr_log_file , $fr_PDU , $fr_bus_nbr , $fr_ignore_uBit);

Reads a single FlexRay PDU information from a Canalyzer logfile. 

B<Arguments:>

=over

=item $fr_log_file

-Full name of the logfile.

=item $fr_PDU

-PDU to be searched in Log

=item $fr_bus_nbr

-FlexRay bus number

=item $fr_ignore_uBit

-FlexRay ignore ubit

=back

B<Return Value:>

=over

=item $message_ref 

-Returns reference to hash structure with information on Flexray PDU

    $message_ref->{$timestamp}{'FR_PDU'} = FR_PDU;
    $message_ref->{$timestamp}{'HEADER_CRC'} = HEADER_CRC;
    $message_ref->{$timestamp}{'DLC_1'} = DLC_1;
    $message_ref->{$timestamp}{'DLC_2'} = DLC_2;
    $message_ref->{$timestamp}{'DATA'} = raw bytes of message;
      
=back

=cut

######################################################################
sub VEC_trace_fr_get_PDU_data {
	my $fr_log_file    = shift;
	my $fr_PDU         = shift;
	my $fr_bus_nbr     = shift;
	my $fr_ignore_uBit = shift;    #will not save the value if (update bit of the PDU = 0) AND ($fr_ignore_uBit = 1)
	my $force_frame_based = shift // 0;

	unless ( defined($fr_PDU) ) {
		S_set_error( "SYNTAX: VEC_trace_fr_get_PDU_data( fr_log_file , fr_PDU , fr_bus_nbr)", 110 );
		return;
	}

	# STEP Get the PDU to be read
	# STEP Get the PDU information from the flexray mapping(ID,Frame)
	# IF Log file is FRAME Based?
	# IF-YES-START
	#   STEP For each line in the log file(FRAME based), Convert into the PDU based trace and try to get the PDU data
	#   STEP Proceed to convert into PDU based log only if the frame of PDU matches the line
	#   STEP Match each line for the intended PDU data
	#   STEP Fill in the values if the PDU is matched
	# IF-YES-END
	# IF-NO-START
	#   STEP Match each line for the intended PDU data
	#   STEP Fill in the values if the PDU is matched
	# IF-NO-END
	# STEP Return PDU data
	# STEP END

	$fr_ignore_uBit = 1 unless defined($fr_ignore_uBit);

	unless ( defined $fr_bus_nbr ) {
		$fr_bus_nbr = "Fr";
	}

	my $trace_FH = new FileHandle;
	unless ( $trace_FH->open($fr_log_file) ) { S_set_error( " Couldnt open CAN Trace '$fr_log_file' ", 131 ); return; }

	my $msg_cnt = 0;
	S_w2log( 4, " VEC_trace_fr_get_PDU_data : Reading FlexRay PDU '$fr_PDU' on Bus  $fr_bus_nbr from $fr_log_file)\n" );

	#Get the FLEXRAY mapping details
	my $flexray_Mapping = S_get_contents_of_hash( ['Mapping_FLEXRAY'] );
	unless ($flexray_Mapping) {
		S_set_error( " LIFT Flexray mapping doesnot exist", 0 );
		return;
	}

	my $frame_based_log = 0;
	my $checkUpdateBit  = 0;

	$frame_based_log = 1 if ( $flexray_Mapping->{'AUTOSAR_SCHEMA_VERSION'} =~ /^AUTOSAR_4-3-0$/i or $force_frame_based);

	my ($framePduInfo);
	if ($frame_based_log) {

		unless ( $flexray_Mapping->{'FR_PDU'}{$fr_PDU}{'PDU_ID_SHORT_HEADER'} ) {
			S_w2log(2, "No PDU_ID_SHORT_HEADER found for the PDU '$fr_PDU' in Mapping_FLEXRAY !!\n");
		}
		if ( $flexray_Mapping->{'FR_PDU'}{$fr_PDU}{'UPDATE-INDICATION-BIT-POSITION'} ) {
			$checkUpdateBit = 1;
			my $updateBit = $flexray_Mapping->{'FR_PDU'}{$fr_PDU}{'UPDATE-INDICATION-BIT-POSITION'};
			my $startBit = $flexray_Mapping->{'FR_PDU'}{$fr_PDU}{'START-BIT-POSITION'};
			my $length   = $flexray_Mapping->{'FR_PDU'}{$fr_PDU}{'DLC'};
			if ( !defined $startBit or ( defined $startBit && $startBit !~ /^\d+$/ ) or !$length ) {
				S_set_error(" VEC_trace_fr_get_PDU_data : START-BIT-POSITION/DLC information is not present for PDU '$fr_PDU'. Please verify your FlexRay mapping!", 20);
				return;
			}
			my $frameName = $flexray_Mapping->{'FR_PDU'}{$fr_PDU}{'FRAME_NAME'};
			S_w2log( 3, "VEC_trace_fr_get_PDU_data : Update bit:'$updateBit', Start Bit:'$startBit', Length:'$length' for PDU '$frameName\:\:$fr_PDU' '\n" );
		}
		$framePduInfo = GetFrameInfoForFrameBasedLog( $flexray_Mapping, $fr_PDU );
	}

    my $all_msgs = {};

	while ( my $line = <$trace_FH> ) {

		my $pdu_line = $line;
		if ($frame_based_log) {
			if ($checkUpdateBit) {
				$pdu_line = PreparePDULineUsingUpdateBit( { line => $line, framePduInfo => $framePduInfo, pdu => $fr_PDU } );
			}
			else {
				$pdu_line = GetPDULineFromFrame( $line, $framePduInfo, $fr_PDU );
			}
		}

		my $pdu_info;
		$pdu_info = GetPDUInfoFromLog( $pdu_line, $fr_PDU, $fr_bus_nbr ) if $pdu_line;

		if ($pdu_info) {

			if ( $fr_ignore_uBit or ubit( $pdu_info->{'BIN'} ) ) {
				my $timestamp = $pdu_info->{'TIME'};
				$msg_cnt++;

				#Save info in the hash
				$all_msgs->{$timestamp}{'FR_PDU'}     = $fr_PDU;
				$all_msgs->{$timestamp}{'HEADER_CRC'} = $pdu_info->{'CRC'};
				$all_msgs->{$timestamp}{'DLC_1'}      = $pdu_info->{'DLC1'};
				$all_msgs->{$timestamp}{'DLC_2'}      = $pdu_info->{'DLC2'};
				$all_msgs->{$timestamp}{'DATA'}       = $pdu_info->{'DATA'};

				#Check of good build (DLC values vs DATA size)
				my $dlc_minus_1 = $all_msgs->{$timestamp}{'DLC_1'} - 1;
				unless ( ( $all_msgs->{$timestamp}{'DLC_1'} == $all_msgs->{$timestamp}{'DLC_2'} )
					&& ( $all_msgs->{$timestamp}{'DATA'} =~ m/^([0-9a-fA-F]{2}\s){$dlc_minus_1}[0-9a-f]{2}$/ix ) )
				{
					S_w2log( 3, "Mismatched between DLC and DATA lenght or between the 2 DLC values\n" );
					$all_msgs->{$timestamp}{'MALFORMED'} = 1;
				}
			}
		}
	}
	S_w2log( 4, " VEC_trace_fr_get_PDU_data : Found " . $fr_PDU . " -> " . $msg_cnt . " times\n" );
	$trace_FH->close;
	return $all_msgs;
}

# Preloaded methods go here.

######################################################################

sub ubit{
    my $testedInfoBin = sprintf("%024b", hex(shift));

    return ($testedInfoBin =~ m/[01]{6}1[01]{17}/i );
}

######################################################################

=head2 VEC_break_measurement

      VEC_break_measurement ( $OLE_handle );

stop the offline measurement CAN tool

=cut

######################################################################

sub VEC_break_measurement {

   my ( $OLE_handle ) = shift @_ ;

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_break_measurement( cantool_OLE_handle )", 110 );
      return;
   }

#    unless( VEC_check_running( $OLE_handle ) ) {
#       S_w2log( 4, " VEC_break_measurement : measurement has been breakped already \n" );
#       return 1;
#    }

   my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
   my $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};

   S_w2log( 3, " VEC_break_measurement : Break $device Offline Measurement on $hostname .. \n" );

   if ( $main::opt_offline ) {   # just return if running in offline mode
        S_w2log( 3, " VEC_break_measurement : .. not done in offline mode\n" );
        return 1;
   }

   S_w2log( 5, " VEC_break_measurement : OLE_handle -> Measurement -> Break() .. \n" );
   $OLE_handle -> Measurement -> Break();
   S_w2log( 3, "done\n" );
   S_get_LastError_OLE();
   return 1;
}

######################################################################

=head2 VEC_compile_all_CAPL_nodes

      VEC_compile_all_CAPL_nodes ( $OLE_handle );

compile all CAPL nodes of given CAN tool ( OLE_handle )

=cut

######################################################################

sub VEC_compile_all_CAPL_nodes {

   my ( $OLE_handle ) = shift @_ ;

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_compile_all_CAPL_nodes( cantool_OLE_handle )", 110 );
      return;
   }

   unless( $Vector_tool_control->{'OLE_handles'}{ $OLE_handle } ) {
      S_set_error( " invalid OLE handle ", 109 );
      return;
   }

   return 1 if $main::opt_offline; # just return if running in offline mode

   S_w2log( 3 , "VEC_compile_all_CAPL_nodes : OLE_handle -> CAPL -> Compile() .. \n" );
   $OLE_handle -> CAPL -> Compile();
   if( my $err = S_get_LastError_OLE() ) {
        S_wait_ms( 1000 );
        S_w2log( 5, " VEC_compile_all_CAPL_nodes : trying 2nd time : OLE_handle -> CAPL -> Compile() .. \n" );
        $OLE_handle -> CAPL -> Compile();
        if( $err = S_get_LastError_OLE() ) {
            S_set_error( " Couldnt compile CAPL nodes" , 131 );
            return 0;
        }
   }

#        # note : Compile has no return value
#        S_w2log( 3 , "VEC_compile_all_CAPL_nodes : failed \n" );
#        return 0;

   S_w2log( 5 , "VEC_compile_all_CAPL_nodes : done \n" );

   return 1;
}

#####################################################################

=head2 VEC_get_application_version

    VERSION = VEC_get_application_version ( OLE_handle , 'FullName'|'Major' );

=cut

#####################################################################

sub VEC_get_application_version
{
    my $OLE_handle = shift;
    my $Type = shift ;

    my $Cantool_version;
    my $version_object;

   # return if $main::opt_offline;

    unless( $version_object = $OLE_handle -> Application -> Version ) {
        S_set_error( "could not get object : OLE_handle -> Application -> Version ; not supported from CAN tool", 0 );
        return;
    }

    if( $Type =~ /major/i ) {
        S_w2log( 5, " VEC_get_application_version: OLE_handle -> Application -> Version -> { 'Major' } .. \n" );
        $Cantool_version = $OLE_handle -> Application -> Version -> { 'Major' };
        S_w2log( 3, " VEC_get_application_version: 'Major' version $Cantool_version \n" );
    }

    if( not defined $Type || $Type =~ /fullname/i ) {
        S_w2log( 5, " VEC_get_application_version: OLE_handle -> Application -> Version -> { 'FullName' } .. \n" );
        $Cantool_version = $OLE_handle -> Application -> Version -> { 'FullName' };
        S_w2log( 3, " VEC_get_application_version: 'FullName' version $Cantool_version \n" );
    }

    return $Cantool_version;
}

######################################################################

=head2 VEC_get_configuration_mode

    return_value = VEC_get_configuration_mode ( $OLE_handle );

    Change the mode of currently loaded configuration on existing CAN-tool OLE object.
    
    MODE :
        return_value = 0  : ONLINE mode
        return_value = 1  : OFFLINE mode

=cut

######################################################################

sub VEC_get_configuration_mode {

   my ( $OLE_handle ) = @_ ;

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_get_configuration_mode( cantool_OLE_handle )", 110 );
      return;
   }

   my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
   my $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};

   return 1 if $main::opt_offline; # just return if running in offline mode

   S_w2log( 5 , " VEC_get_configuration_mode : current_mode = OLE_handle -> Application -> Configuration -> { 'Mode' } .. \n" );
   my $current_mode = $OLE_handle -> Application -> Configuration -> { 'Mode' };
   S_get_LastError_OLE();

   unless( defined $current_mode ) {
      S_set_error( " '$device' on '$hostname' Couldnt read currently loaded configuration mode: $! ", 131 );
      return;
   }

   if( $current_mode == 0 ) {
        S_w2log( 4 , " VEC_get_configuration_mode : current mode is ONLINE mode ($current_mode)\n" );
   } elsif ( $current_mode == 1 ) {
        S_w2log( 4 , " VEC_get_configuration_mode : current mode is OFFLINE mode ($current_mode)\n" );
   } else {
        S_set_error( "Unexpected value for current mode ('$current_mode')" , 0 );
        return;
   }

   return $current_mode;
}

######################################################################

=head2 VEC_get_configured_logfile_names

 @LogFileNames = VEC_get_configured_logfile_names ( $OLE_handle );

Read the full name of currently loaded configuration on existing CAN-tool OLE object.

=cut

######################################################################

sub VEC_get_configured_logfile_names {

   my ( $OLE_handle ) = shift @_ ;
   my $FileNameOptions_handle  ;  

   unless( defined $OLE_handle ) {
      S_set_error( " VEC_get_configured_logfile_names( cantool_OLE_handle )", 110 );
      return;
   }

   my @returned_LogFileNames ;
   my $Logging_handle ;

   return 1 if $main::opt_offline; # just return if running in offline mode

   S_w2log( 5 , "VEC_get_configured_logfile_names: nbr_of_looging_objects = OLE_handle -> Configuration -> OnlineSetup -> LoggingCollection -> Count() \n");
   my $nbr_looging_objects = $OLE_handle -> Configuration -> OnlineSetup -> LoggingCollection -> Count();
   S_get_LastError_OLE();

   S_w2log( 5 , "VEC_get_configured_logfile_names: nbr of logging objects = $nbr_looging_objects \n");

   for( 1 .. $nbr_looging_objects ) {
      S_w2log( 5 , "VEC_get_configured_logfile_names: Logging_handle = OLE_handle -> Configuration -> OnlineSetup -> LoggingCollection -> Item($_) .. \n");
      $Logging_handle = $OLE_handle -> Configuration -> OnlineSetup -> LoggingCollection -> Item($_);
      S_get_LastError_OLE();
      $Logging_handle = $OLE_handle -> Configuration -> OnlineSetup -> LoggingCollection($_);
      S_get_LastError_OLE();
      push( @returned_LogFileNames , $Logging_handle->{'FullName'} );
      
      $FileNameOptions_handle = $Logging_handle -> FileNameOptions;
      
      if ( $FileNameOptions_handle -> IncrementAfterTrigger == 1 ) {
          $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'LogFileConfig'}{'IncrementAfterTrigger'} =  1; 
          S_w2log( 3, " VEC_get_configured_logfile_names: : for $Logging_handle->{'FullName'}  increment options is true \n" );
      }
      else {
          S_w2log( 3, " VEC_get_configured_logfile_names: : for $Logging_handle->{'FullName'}  increment options is False \n" );
          $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'LogFileConfig'}{'IncrementAfterTrigger'} =  0;
      }

      S_w2log( 5 , "VEC_get_configured_logfile_names: ".$Logging_handle->{'FullName'}." \n");
   }

   return @returned_LogFileNames;
}

######################################################################

=head2 VEC_get_sys_variable

 SysVarObject = VEC_get_sys_variable ( OLE_handle , SysVarName );

 SysVarName : <NAMESPACE::VAR_NAME>
 
 e.g. possible  'GW_Routing_PAG_PF::SysMO_Drehzahl_01_'

=cut

######################################################################

sub VEC_get_sys_variable
{
    my ( $OLE_handle , $ns_sys_var ) = @_ ;

    unless( defined $ns_sys_var ) {
      S_set_error( " SYNTAX: VEC_get_sys_variable( cantool_OLE_handle , SysVarName )", 110 );
      return;
    }

    my @given_ns= split( "::" , $ns_sys_var );
    my $used_sysvar_name = pop(@given_ns);

    return 1 if $main::opt_offline;

    my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
    my $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};

#     System 
#         Namespaces -> Count 
#             Namespace -> Item (index)
#                 Variables -> Count
#                     Variable -> Item (index)

    my $object = $OLE_handle -> System();
    S_get_LastError_OLE();
    return unless defined $object;

    my $ns_name = "";
	foreach my $name (@given_ns){
		my $found;
		foreach my $ns_index ( 1 .. $object -> Namespaces -> Count( ) ){
        	$ns_name = $object -> Namespaces -> Item($ns_index) -> Name( );
        	if ( $ns_name eq $name){
        		 S_w2log( 3 , "VEC_get_sys_variable: Found NAMESPACE '$ns_name' .. \n");
        		$found = 1;
				$object = $object -> Namespaces -> Item($ns_index);
        		last;
        	}
		}
		
		unless ($found){
		    S_set_error( "Could not find system variable namespace $name (on $device (host:$hostname)\nPlease check if a proper TurboLIFT sysvar file (e.g. ComCtrlSysVars.xml) is included in your $device config.", 131 );
    		return;	
		}
	}
	
	foreach my $sysvars_index ( 1 .. $object -> Variables -> Count( ) ) {
    	my $sysvar_handle = $object -> Variables -> Item($sysvars_index);    S_get_LastError_OLE(); return unless defined $sysvar_handle;
        my $sysvar_name = $sysvar_handle -> Name( );                 S_get_LastError_OLE(); return unless defined $sysvar_name;
        next unless $sysvar_name eq $used_sysvar_name;
        S_w2log( 3 , "VEC_get_sys_variable: Found SYSVAR '$ns_name::$sysvar_name' .. \n");
        return $sysvar_handle;
	}
	
    S_set_error( "Could not find system variable $used_sysvar_name (on $device (host:$hostname)\n\nPlease check if an up-to-date TurboLIFT sysvar file (e.g. ComCtrlSysVars.xml) is included in your $device config.", 131 );
    return;
}

######################################################################

=head2 VEC_set_configuration_mode

    VEC_set_configuration_mode ( $OLE_handle , <MODE> );

    Change the mode of currently loaded configuration on existing CAN-tool OLE object.
    
    MODE :
        0  : ONLINE mode
        1  : OFFLINE mode

=cut

######################################################################

sub VEC_set_configuration_mode {

   my ( $OLE_handle , $given_mode ) = @_ ;

   unless( $given_mode == 1 or $given_mode == 0 ) {
      S_set_error( " SYNTAX: VEC_set_configuration_mode( cantool_OLE_handle , 0|1 )", 110 );
      return;
   }

   my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
   my $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};

  # return 1 if $main::opt_offline; # just return if running in offline mode

   my $current_mode = VEC_get_configuration_mode( $OLE_handle );

   if( $current_mode == $given_mode ) {
        S_w2log( 3 , " VEC_set_configuration_mode : required mode ($given_mode) already set \n" );
        return 1;
   }

   S_w2log( 3 , " VEC_set_configuration_mode : setting mode = $given_mode (device/host : $device/$hostname)\n" );
   S_w2log( 5 , " VEC_set_configuration_mode : OLE_handle -> Application -> Configuration -> { 'Mode' } = $given_mode .. \n" );
   $OLE_handle -> Application -> Configuration -> { 'Mode' } = $given_mode;
   S_get_LastError_OLE();
   S_w2log( 3 , " VEC_set_configuration_mode : config must be saved .. \n" );
   S_w2log( 5 , " VEC_set_configuration_mode : OLE_handle -> Application -> Configuration -> Save() .. \n" );
   $OLE_handle -> Application -> Configuration -> Save ();
   S_get_LastError_OLE();
#    unless( $OLE_handle -> Application -> Configuration -> Save () ) {
#         S_set_error( " config couldnt be saved " , 109 );
#         return;
#    }

   $current_mode = VEC_get_configuration_mode( $OLE_handle );

   unless( $current_mode == $given_mode ) {
        S_set_error( " error while setting new mode " , 109 );
        return;
   }

   return 1;
}

######################################################################

=head2 VEC_start_measurement_offline

      VEC_start_measurement_offline ( $OLE_handle );

=cut

######################################################################

sub VEC_start_measurement_offline
{

   my ( $OLE_handle ) = shift @_ ;

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_start_measurement_offline( cantool_OLE_handle )", 110 );
      return;
   }

   if( VEC_check_running( $OLE_handle ) ) {
      S_w2log( 4, " VEC_start_measurement_offline : measurement has been started already \n" );
      return 1;
   }

   my $device = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
   my $hostname = $Vector_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};

   S_w2log( 3, " VEC_start_measurement_offline : start $device Measurement on $hostname\n" );

   return 1 if $main::opt_offline; # just return if running in offline mode

   S_w2log( 5, " VEC_start_measurement_offline : OLE_handle -> Measurement -> Start() .. \n" );
   $OLE_handle -> Measurement -> Start();
   S_get_LastError_OLE();

   return 1 if VEC_check_running( $OLE_handle );

   return 1;

#    S_wait_ms( 200 );
#    return 1 if VEC_check_running( $OLE_handle );
#
#    S_wait_ms( 500 );
#    return 1 if VEC_check_running( $OLE_handle );
#
#    S_wait_ms( 1500 );
#    return 1 if VEC_check_running( $OLE_handle );
#
#    S_wait_ms( 5000 );
#    return 1 if VEC_check_running( $OLE_handle );
#
#    S_set_error( " Couldnt start $device CAN measurement on $hostname" , 131 );
#
#    return 0;
}

######################################################################

=head2 VEC_trace_can_analyze_format

    ( base-type , timestamp-type ) = VEC_trace_can_analyze_format ( $can_trace_file );


=cut

######################################################################

sub VEC_trace_can_analyze_format {
   my $can_trace_file = shift;

   unless( defined $can_trace_file ) {
      S_set_error( " SYNTAX: VEC_trace_can_analyze_format( $can_trace_file )", 110 ); return (undef, undef);
   }

   # return 1 if $main::opt_offline;

   my $Trace_FH = new FileHandle;
   unless( $Trace_FH->open( $can_trace_file ) ) {
      S_set_error( " Couldnt open CAN Trace '$can_trace_file' ", 131 ); return(undef, undef);
   }

   my $data_format; my $timestamps;
   while( <$Trace_FH> ) {
      if( /base\s+(\S+)\s+timestamps\s+(\S+)/ ) {  $data_format = $1; $timestamps = $2; last; }
   }

   $Trace_FH->close;

   unless( defined $timestamps ) {
      S_set_error( " Couldnt determine base and timestamps format in '$can_trace_file' ", 131 ); return(undef, undef);
   }

   S_w2log( 3, " VEC_trace_can_analyze_format : base = $data_format timestamps = $timestamps \n" );
   return ( $data_format , $timestamps );

}

######################################################################

=head2 VEC_trace_create_eval_capl

    VEC_trace_create_eval_capl ( $all_signals_info , $eval_offline_mode_capl_template , $operating_mode );
	
    $operating_mode     ->  'OnlineOffline' or 'OfflineOnly'

    for Offline : isOfflineMode() will prohibit the calculation Offline


=cut

######################################################################

sub VEC_trace_create_eval_capl {

    my(
        $all_signals_info ,
        $eval_offline_mode_capl_template ,
        $operating_mode ,    #  'OnlineOffline' or 'OfflineOnly'
        ) = @_ ;

    my $Flexray_Mapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);

    unless( $Flexray_Mapping ) {
        S_set_error( " LIFT Flexray mapping doesnot exist" , 0 );
    }

    my (
        $frames_written2capl, ## frames stored in capl
        $pdu_written2capl,    ## pdu stored in capl
        $CAPL_works_in_Online ,
      );
    $frames_written2capl = 0; ## frames stored in capl
    $pdu_written2capl = 0;    ## pdu stored in capl

    if    ( $operating_mode eq 'OnlineOffline' )  { S_w2log( 3 , " VEC_trace_create_eval_capl: mode = 'OnlineOffline'\n" ); $CAPL_works_in_Online = 1 }
    elsif ( $operating_mode eq 'OfflineOnly' )    { S_w2log( 3 , " VEC_trace_create_eval_capl: mode = 'OfflineOnly'\n" ); $CAPL_works_in_Online = 0 }
    else                                          { S_w2log( 3 , " VEC_trace_create_eval_capl: mode = default 'OnlineOffline'\n" ); $CAPL_works_in_Online = 1 }

    S_w2log( 4 , " VEC_trace_create_eval_capl : Opening CAPL $eval_offline_mode_capl_template .. \n" );
    unless( open( CAPL , ">$eval_offline_mode_capl_template" ) ) { S_set_error( "Failed opening $eval_offline_mode_capl_template" , 1 ); return }

    print CAPL "// THIS CAPL IS GENERATED BY LIFT_vector_cantool::VEC_trace_create_eval_capl()";
    print CAPL "\n";
    print CAPL "/*\@\@startStart:Start:*/";

    print CAPL "on start { write ( \"NOTE : this CAPL write Signals in Online & Offline Mode\" ); }" if $CAPL_works_in_Online;
    print CAPL "on start { write ( \"NOTE : this CAPL write Signals only in Offline Mode\" ); }" unless $CAPL_works_in_Online;
    print CAPL "/*\@\@end*/";
    print CAPL "\n";

    foreach my $pdu_name ( keys %{$all_signals_info->{ 'FrPDU' }} ) {
        print CAPL "on FrPDU $pdu_name\n";
        print CAPL "{\n";
        #
        # check the PDU Update-Bit = 1 first before evaluating the signals
        #
        print CAPL "  if( this.updateBit ) {\n"                       if $CAPL_works_in_Online;
        print CAPL "  if( this.updateBit && isOfflineMode() ) {\n"    unless $CAPL_works_in_Online;

        foreach my $flxr_signal ( @{$all_signals_info->{ 'FrPDU' }{ $pdu_name }{ 'Signals' }} ) {
            my $flxr_signal_raw = $Flexray_Mapping->{$flxr_signal}{'SIGNAL_NAME'};
            print CAPL "    writeToLog\n";
            print CAPL "    (\n";
            print CAPL "     \" (%s) %s = %f [ %d ] \"  , \n";
            print CAPL "     \"$pdu_name\" , \n";
            print CAPL "     \"$flxr_signal\" , \n";
            print CAPL "      this.$flxr_signal_raw.phys , \n";
            print CAPL "      this.$flxr_signal_raw \n";
            print CAPL "    );\n";
        }
        print CAPL "  }\n";
        print CAPL "}\n";
        $pdu_written2capl=1;
    }

    foreach my $frame_name ( keys %{$all_signals_info->{ 'FrFrame' }} ) {
        print CAPL "on FRFrame $frame_name\n";
        print CAPL "{\n";
        foreach my $flxr_signal ( @{$all_signals_info->{ 'FrFrame' }{ $frame_name }{ 'Signals' }} ) {
            my $flxr_signal_raw = $Flexray_Mapping->{$flxr_signal}{'SIGNAL_NAME'};
            print CAPL "  writeToLog\n";
            print CAPL "  (\n";
            print CAPL "   \" (%s) %s = %f [ %d ] \"  , \n";
            print CAPL "   \"$frame_name\" , \n";
            print CAPL "   \"$flxr_signal\" , \n";
            print CAPL "    this.$flxr_signal_raw.phys , \n";
            print CAPL "    this.$flxr_signal_raw \n";
            print CAPL "  );\n";
        }
        print CAPL "}\n";
        $frames_written2capl=1;
    }

#     S_w2log( 3 , " VEC_trace_create_eval_capl : Closing CAPL $eval_offline_mode_capl_template frames_written2capl='$frames_written2capl' and pdu_written2capl='$pdu_written2capl' .. \n" );
    S_w2log( 4 , " VEC_trace_create_eval_capl : Closing CAPL $eval_offline_mode_capl_template .. \n" );

    unless( close( CAPL ) ) { S_set_error( "Failed closing $eval_offline_mode_capl_template" , 1 ); return }

    return 1;
}

######################################################################

=head2 VEC_trace_lin_analyze_format

    ( base-type , timestamp-type ) = VEC_trace_lin_analyze_format ( $lin_trace_file );


=cut

######################################################################

sub VEC_trace_lin_analyze_format {
   my $lin_trace_file = shift;

   unless( defined $lin_trace_file ) {
      S_set_error( " SYNTAX: VEC_trace_lin_analyze_format( $lin_trace_file )", 110 ); return;
   }

   return 1 if $main::opt_offline;

   my $Trace_FH = new FileHandle;
   unless( $Trace_FH->open( $lin_trace_file ) ) {
      S_set_error( " Couldnt open LIN Trace '$lin_trace_file' ", 131 ); return;
   }

   my $data_format; my $timestamps;
   while( <$Trace_FH> ) {
      if( /base\s+(\S+)\s+timestamps\s+(\S+)/ ) {  $data_format = $1; $timestamps = $2; last; }
   }
   $Trace_FH->close;

   unless( defined $timestamps ) {
      S_set_error( " Couldnt determine base and timestamps format in '$lin_trace_file' ", 131 ); return;
   }

   S_w2log( 3, " VEC_trace_lin_analyze_format : base = $data_format timestamps = $timestamps \n" );
   return ( $data_format , $timestamps );

}

######################################################################

=head2 VEC_trace_run_offline

    VEC_trace_run_offline ( $OLE_handle , $device );


=cut

######################################################################

sub VEC_trace_run_offline {

    my $OLE_handle = shift;
    my $device = shift;
    my $flxr_trace_file = shift;

    VEC_stop_measurement( $OLE_handle ) if VEC_check_running( $OLE_handle ) ;

    # set mode to OFFLINE
    unless( VEC_set_configuration_mode( $OLE_handle , 1 ) ) {
        S_set_error( " VEC_trace_run_offline: call of VEC_set_configuration_mode failed (OFFLINE) \n" , 109);
        return;
    }

    #------------------------------------------------------------------------
    #
    # copy/move the right trace file as input of offline config
    #
    ## default logfile was validated in VEC_cantool_init alsready
    my $default_logfile =  $Vector_tool_control->{'Devices'}{$device}{'DefaultLogFile'};

    if( -f $default_logfile ) {
        S_w2log( 5, " VEC_trace_run_offline : Found $device Logfile : $default_logfile\n" );
    }
    else {
        S_set_error( " Couldnt find $device logfile : $default_logfile\n" , 131 );
        return;
    }

    if( ref $flxr_trace_file ) {
        S_set_error( "Haeh ? This must be a filename and not a Reference !!!" , 131 );
        return;
    }

    unless( -f $default_logfile ) {
        # is not completely clear why this copy action was there (therefore is the -f file check before)
        S_w2log( 3, " VEC_trace_run_offline : Copy '$flxr_trace_file' -> $default_logfile \n" );
        unless( copy ( $flxr_trace_file , $default_logfile ) ) {
            S_set_error( " copy ( $flxr_trace_file , $default_logfile ) : $! \n" , 1 );
            return;
        }
    }

    if( my $flxr_trace_file_offline_input = $Vector_tool_control->{'Devices'}{$device}{'Eval_Offline_Log_File_Input'} ) {
        S_w2log( 4, " VEC_trace_run_offline: CANalyzer config is evaluating CAPL in Offline Mode only -> 'Eval_Offline_Log_File_Input' is defined as another Offline Source Input \n" );
        S_w2log( 3, " VEC_trace_run_offline : move '$flxr_trace_file' -> $flxr_trace_file_offline_input \n" );
        unless( move( $default_logfile , $flxr_trace_file_offline_input )  ) {
            S_set_error( " move ( $flxr_trace_file , $flxr_trace_file_offline_input ) : $! \n" , 1 );
            return;
        }
    }
    else {
        S_w2log( 4 , " VEC_trace_run_offline: CANalyzer config is evaluating CAPL in Offline Mode only -> 'Eval_Offline_Log_File_Input' is NOT defined as another Offline Source Input; the Original trace file must be configued in CAN-Tool\n" );
    }
    #
    #------------------------------------------------------------------------


    unless( VEC_compile_all_CAPL_nodes( $OLE_handle ) ) {
        S_set_error( " VEC_trace_run_offline: call of VEC_compile_all_CAPL_nodes() failed\n" , 109);
        return;
    }

    unless( VEC_start_measurement_offline( $OLE_handle ) ) {
        S_set_error( " VEC_trace_run_offline: call of VEC_start_measurement() failed\n" , 109);
        return;
    }

    use File::stat;
    my $sb = stat($flxr_trace_file);
    S_w2log( 5, sprintf(
                            " VEC_trace_run_offline : Tracefile is %s -> size is %s bytes\n",
                            $flxr_trace_file,
                            $sb->size,
                        ));
    my $wait_time_ms = int( $sb->size / 1000 ) + 5000;
    S_w2log( 5, " Wait $wait_time_ms ms = filesize / 1000 + 5000 ( ".$sb->size." / 1000 + 5000) \n" );
    S_wait_ms( $wait_time_ms );

    # set mode back to ONLINE
    unless( VEC_set_configuration_mode( $OLE_handle , 0 ) ) {
        S_set_error( " VEC_trace_run_offline: call of VEC_set_configuration_mode failed (ONLINE) \n" , 109);
        return;
    }


    return 1;
}

######################################################################

=head2 VEC_xcp_init

 VEC_xcp_init( cantool_OLE_handle );


=cut

######################################################################

sub VEC_xcp_init
{
   my ( $OLE_handle ) = shift @_ ;

   unless( defined $OLE_handle ) {
      S_set_error( " SYNTAX: VEC_xcp_init( cantool_OLE_handle )", 110 );
      return;
   }

   my $CAPL_control;

   return 1 if $main::opt_offline; # just return if running in offline mode

   ### initialize CAPL var objects (have to be declared in Xcp.dbc)
   S_w2log( 2, " VEC_xcp_init: Initialize CAPL var objects \n" );
   $CAPL_control->{ 'XCP_CommandReq' }     = VEC_get_env_variable( $OLE_handle , "XCP_CommandReq");
   $CAPL_control->{ 'XCP_DataTypeReq' }    = VEC_get_env_variable( $OLE_handle , "XCP_DataTypeReq");
   $CAPL_control->{ 'XCP_XmtIdReq' }       = VEC_get_env_variable( $OLE_handle , "XCP_XmtIdReq");
   $CAPL_control->{ 'XCP_RcvIdReq' }       = VEC_get_env_variable( $OLE_handle , "XCP_RcvIdReq");
   $CAPL_control->{ 'XCP_AddressReq' }     = VEC_get_env_variable( $OLE_handle , "XCP_AddressReq");
   $CAPL_control->{ 'XCP_LengthReq' }      = VEC_get_env_variable( $OLE_handle , "XCP_LengthReq");
   $CAPL_control->{ 'XCP_ValueReq' }       = VEC_get_env_variable( $OLE_handle , "XCP_ValueReq");

   $CAPL_control->{ 'XCP_ResultRsp' }      = VEC_get_env_variable( $OLE_handle , "XCP_ResultRsp");
   $CAPL_control->{ 'XCP_ErrcodeRsp' }     = VEC_get_env_variable( $OLE_handle , "XCP_ErrcodeRsp");
   $CAPL_control->{ 'XCP_StatusRsp' }      = VEC_get_env_variable( $OLE_handle , "XCP_StatusRsp");
   $CAPL_control->{ 'XCP_ReturnvalueRsp' } = VEC_get_env_variable( $OLE_handle , "XCP_ReturnvalueRsp");

   unless( VEX_init( $CAPL_control ) ) {
      S_set_error( "Couldnt initialize XCP CAPL_control", 141);
      return;
   }

   return 1;
}

######################################################################

=head2 VEC_trace_fr_get_signal_data

    Function Name    :: VEC_trace_fr_get_signal_data
    Description      :: extracts the data reference of FR signal. This function shall be called after FR_trace_get_PDU_data. 
    Syntax           :: $sig_data_ref = VEC_trace_fr_get_signal_data( $all_PDUs,$fr_signal,$data_format); 
    Input Arguments  :: $all_PDUs - data reference of the PDU data
                        $fr_signal - FR signal whose data refernce needs to be extracted
                        $data_format - DEC or HEX
    Return Value(s)  :: $sig_data_ref - hash reference of the data of the required signals

     $trace_data_ref = {
                        'timestamp_1' => {
                                       'signal_1' => 'phys_value_at_time_1',
                                       'signal_2' => 'phys_value_at_time_1',
                                       'signal_3' => 'phys_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                       'signal_1' => 'phys_value_at_time_2',
                                       'signal_2' => 'phys_value_at_time_2',
                                       'signal_3' => 'phys_value_at_time_2',
                                          },
                     };

=cut

######################################################################

sub VEC_trace_fr_get_signal_data
{

    my $all_PDUs = shift;
    my $fr_signal = shift;
    my $data_format = shift;         ### DEC or HEX

    my (
         $data_raw ,
         @data_list ,
         $signal_length ,
         $signal_factor ,
         $signal_offset ,
         $signal_format ,     ### INTEL or MOTOROLA
         $signal_start_bit ,
         $signal_type ,

         $signal_MX_Master,
         $signal_MX_Master_value_phys ,
         $signal_MX_Master_length ,
         $signal_MX_Master_factor ,
         $signal_MX_Master_offset ,
         $signal_MX_Master_format ,     ### INTEL or MOTOROLA
         $signal_MX_Master_start_bit ,
         $signal_MX_Master_type ,
         $signal_MX_Master_code_value ,
         $multiplex_type ,

         $fr_frame_bin ,
         $byte_value ,
         $byte_bin_lsb ,
         $signal_lsb ,
         $signal_msb ,
         $signal_raw_value ,
         $sig_value_phys ,
         $sig_data_ref ,
         $dlc ,
         $temp_sig_pos_start ,
         $temp_fr_frame_bin ,
         $signal_msb_without_sign ,
         $signal_msb_without_sign_compl ,
         $sign_factor ,
      );


    unless (defined( $data_format )) {
        S_set_error( "Too Less Parameters ! VEC_trace_fr_get_signal_data: SYNTAX: VEC_trace_fr_get_signal_data ( message_ref, fr_signal, base_format )", 110 );
        return;
    }

    # Here we are using plain integer variables to speed up the loops later.
    # Pattern matching in the loops is too slow
    # Also using constants in the loops is too slow
    my $format_dec = 1;
    my $format_hex = 2;

    if( $data_format =~ /dec/i ) {
        $data_format = $format_dec;
    }
    elsif($data_format =~ /hex/i){
        $data_format = $format_hex;
    }
    else {
        S_set_error( "VEC_trace_fr_get_signal_data: parameter 'base' must be 'dec' or 'hex'", 114 ); #110 before
        return;
    }

    my $Flexray_Mapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);

    unless( $Flexray_Mapping ) {
        S_set_error( " LIFT Flexray mapping doesnot exist" , 0 );
    }

    $signal_length = $Flexray_Mapping->{ $fr_signal }{'LENGTH'};

    unless( defined $signal_length ) {
       S_set_error( " VEC_trace_fr_get_signal_data: no 'LENGTH' defined for FR signal '$fr_signal' in FR MAPPING\n" , 109);
       return;
    }

    $signal_offset = $Flexray_Mapping->{ $fr_signal }{'OFFSET'};
    unless( defined $signal_offset ) {
       S_set_error( " VEC_trace_fr_get_signal_data: no 'OFFSET' defined for FR signal '$fr_signal' in FR MAPPING\n" , 109);
       return;
    }

    $signal_factor = $Flexray_Mapping->{ $fr_signal }{'FACTOR'};
    unless( defined $signal_factor ) {
       S_set_error( " VEC_trace_fr_get_signal_data: no 'FACTOR' defined for FR signal '$fr_signal' in FR MAPPING\n" , 109);
       return;
    }

    $signal_format = $Flexray_Mapping->{ $fr_signal }{'FORMAT'};
    unless( defined $signal_format ) {
       S_set_error( " VEC_trace_fr_get_signal_data: no 'FORMAT' defined for FR signal '$fr_signal' in FR MAPPING\n" , 109);
       return;
    }

    # Here we are using plain integer variables to speed up the loops later.
    # Pattern matching in the loops is too slow
    # Also using constants in the loops is too slow
    my $format_intel = 1;
    my $format_motorola = 2;

    if( $signal_format =~ /INTEL/i ){
        $signal_format = $format_intel;
    }
    elsif( $signal_format =~ /MOTOROLA/i ){
        $signal_format = $format_motorola;
    }
    else{
        S_set_error( "VEC_trace_fr_get_signal_data: 'FORMAT' of signal '$fr_signal' in FR Mapping must be INTEL or MOTOROLA", 110 );
        return;
    }

    $signal_start_bit = $Flexray_Mapping->{ $fr_signal }{'STARTBIT'};
    unless( defined $signal_start_bit ) {
       S_set_error( " VEC_trace_fr_get_signal_data: no 'FORMAT' defined for FR signal '$fr_signal' in FR MAPPING\n" , 109);
       return;
    }

    $signal_type = $Flexray_Mapping->{ $fr_signal }{'TYPE'};

    unless( defined $signal_type ) {
       S_set_error( " VEC_trace_fr_get_signal_data: no 'TYPE' defined for FR signal '$fr_signal' in FR MAPPING\n" , 109);
       return;
    }
    unless ( $signal_type =~ /^SIGNED/i or $signal_type =~ /^UNSIGNED/i) {
        S_set_error( "VEC_trace_fr_get_signal_data: 'TYPE' of signal '$fr_signal' in FR Mapping must be SIGNED or UNSIGNED", 114 ); #110 before
        return;
    }

    $signal_MX_Master = $Flexray_Mapping->{ $fr_signal }{'MULTIPLEX'}{'MASTER'};
    $signal_MX_Master_code_value = $Flexray_Mapping->{ $fr_signal }{'MULTIPLEX'}{'CODE'};

    if(defined $signal_MX_Master and not defined $signal_MX_Master_code_value)
    {
        $multiplex_type = 'MASTER';
    }
    elsif(defined $signal_MX_Master and defined $signal_MX_Master_code_value)
    {
        $multiplex_type = 'SLAVE';
        S_w2log( 3 , " VEC_trace_fr_get_signal_data : MULTIPLEX SLAVE signal '$fr_signal' (MASTER='$signal_MX_Master' CODE='$signal_MX_Master_code_value')\n"  );
    }
    elsif(not defined $signal_MX_Master and defined $signal_MX_Master_code_value)
    {
        S_set_error( "VEC_trace_fr_get_signal_data: wrong signal config ('CODE' defined but not 'MASTER' defined)", 110 );
        return;
    }
    else
    {
        $multiplex_type = 'NO_MULTIPLEX';
    }

    if( $multiplex_type eq 'SLAVE' ) {

        $signal_MX_Master_length = $Flexray_Mapping->{ $signal_MX_Master }{'LENGTH'};
        unless( defined $signal_MX_Master_length ) {
           S_set_error( " VEC_trace_fr_get_signal_data: no 'LENGTH' defined for FR signal '$signal_MX_Master' in FR MAPPING\n" , 110);
           return;
        }

        $signal_MX_Master_offset = $Flexray_Mapping->{ $signal_MX_Master }{'OFFSET'};
        unless( defined $signal_MX_Master_offset ) {
           S_set_error( " VEC_trace_fr_get_signal_data: no 'OFFSET' defined for FR signal '$signal_MX_Master' in FR MAPPING\n" , 110);
           return;
        }

        $signal_MX_Master_factor = $Flexray_Mapping->{ $signal_MX_Master }{'FACTOR'};
        unless( defined $signal_MX_Master_factor ) {
           S_set_error( " VEC_trace_fr_get_signal_data: no 'FACTOR' defined for FR signal '$signal_MX_Master' in FR MAPPING\n" , 110);
           return;
        }

        $signal_MX_Master_format = $Flexray_Mapping->{ $signal_MX_Master }{'FORMAT'};
        unless( defined $signal_MX_Master_format ) {
           S_set_error( " VEC_trace_fr_get_signal_data: no 'FORMAT' defined for FR signal '$signal_MX_Master' in FR MAPPING\n" , 110);
           return;
        }

        if( $signal_MX_Master_format =~ /INTEL/i ){
            $signal_MX_Master_format = $format_intel;
        }
        elsif( $signal_MX_Master_format =~ /MOTOROLA/i ){
            $signal_MX_Master_format = $format_motorola;
        }
        else{
            S_set_error( "VEC_trace_fr_get_signal_data: 'FORMAT' of signal '$signal_MX_Master' in FR Mapping must be INTEL or MOTOROLA", 109 );
            return;
        }

        $signal_MX_Master_start_bit = $Flexray_Mapping->{ $signal_MX_Master }{'STARTBIT'};
        unless( defined $signal_MX_Master_start_bit ) {
           S_set_error( " VEC_trace_fr_get_signal_data: no 'FORMAT' defined for FR signal '$signal_MX_Master' in FR MAPPING\n" , 110);
           return;
        }

        $signal_MX_Master_type = $Flexray_Mapping->{ $signal_MX_Master }{'TYPE'};
        unless( defined $signal_MX_Master_type ) {
           S_set_error( " VEC_trace_fr_get_signal_data: no 'TYPE' defined for FR signal '$signal_MX_Master' in FR MAPPING\n" , 110);
           return;
        }
        unless ( $signal_MX_Master_type =~ /^SIGNED/i or $signal_MX_Master_type =~ /^UNSIGNED/i) {
            S_set_error( "VEC_trace_fr_get_signal_data: 'TYPE' of signal '$signal_MX_Master' in FR Mapping must be SIGNED or UNSIGNED", 109 );
            return;
        }
    }


    foreach my $time_stamp ( sort {$a<=>$b} keys %$all_PDUs )
    {
        $data_raw = $all_PDUs->{$time_stamp}{ 'DATA' };
        $data_raw =~ s/^\s+//g;  ## remove possible leading spaces
        @data_list = split( /\s+/ , $data_raw);
        $fr_frame_bin = "";  ## FR frame binary format (LSB)
        my $byte_bin_lsb1;
        foreach my $data_byte (@data_list)
       {
            ## converts 'F0' into '00001111' (LSB format) (starting with lowest significant bit))
            ##   PERL lesson:
            ##                 - 'hex $data_byte' interprete given value as hexadecimal value
            ##                 - 'sprintf( "%08b",...' format the given value into 8bit format (MSB)
            ##                 - 'reverse' sort the given scalar in opposite order (that means: MSB to LSB)

            if( $data_format == $format_hex )     { $byte_value = hex $data_byte; } # HEX format
            elsif ( $data_format == $format_dec ) { $byte_value =     $data_byte; } # DEC format
            if( $signal_format == $format_intel )       { $byte_bin_lsb1 = reverse sprintf( "%08b" , $byte_value ); } # INTEL
            elsif( $signal_format == $format_motorola ) { $byte_bin_lsb1 =         sprintf( "%08b" , $byte_value ); } # MOTOROLA
            $fr_frame_bin .= $byte_bin_lsb1;
        }
        # section for MULTIPLEX master in case of SLAVE signal required

        if( $multiplex_type eq 'SLAVE' )
        {

            if( $signal_MX_Master_format == $format_intel ) { # INTEL
                $signal_lsb = substr ( $fr_frame_bin , $signal_MX_Master_start_bit , $signal_MX_Master_length );
            }
            elsif( $signal_MX_Master_format == $format_motorola ) { # MOTOROLA
                $temp_fr_frame_bin = reverse $fr_frame_bin;
                $dlc = $all_PDUs->{$time_stamp}{ 'DLC' } ;
                $dlc = 0 if not defined $dlc; # to avoid undef in $temp_sig_pos_start calculation
                $temp_sig_pos_start = $dlc * 8 - ( ( $signal_MX_Master_start_bit>>3 ) << 3 ) - ( 7 + ( ( $signal_MX_Master_start_bit>>3 ) << 3 ) - $signal_MX_Master_start_bit );
                $signal_lsb = substr ( $temp_fr_frame_bin , $temp_sig_pos_start - $signal_MX_Master_length , $signal_MX_Master_length );
            }
            $signal_msb = reverse $signal_lsb;
            if( $signal_MX_Master_type eq 'SIGNED' and $signal_msb =~ /^1/ ) {
                $signal_msb_without_sign = substr($signal_msb,1,length($signal_msb)-1);
                $signal_msb_without_sign_compl = ~ $signal_msb_without_sign;   # 2 - complement (change all bits)
                $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb_without_sign_compl , -32)));
                $signal_raw_value = ($signal_raw_value + 1) * -1;  # add 1 due to calculation rule with signed values and multiply with -1

            } else {
                $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb, -32)));
            }
            $signal_MX_Master_value_phys = ($signal_raw_value * $signal_MX_Master_factor) + $signal_MX_Master_offset ;

            unless ( $signal_MX_Master_value_phys == $signal_MX_Master_code_value ) {
                next;
            }
        }

        # end of MULTIPLEX section

        if( $signal_format == $format_intel ) # INTEL
        {
           $signal_lsb = substr ( $fr_frame_bin , $signal_start_bit , $signal_length );
       }
        elsif( $signal_format == $format_motorola ) { # MOTOROLA
            $temp_fr_frame_bin = reverse $fr_frame_bin;
            $dlc = $all_PDUs->{$time_stamp}{ 'DLC' } ;
            $dlc = 0 if not defined $dlc; # to avoid undef in $temp_sig_pos_start calculation
            $temp_sig_pos_start = $dlc * 8 - ( ( $signal_start_bit>>3 ) << 3 ) - ( 7 + ( ( $signal_start_bit>>3 ) << 3 ) - $signal_start_bit );
            $signal_lsb = substr ( $temp_fr_frame_bin , $temp_sig_pos_start - $signal_length , $signal_length );
        }
        $signal_msb = reverse $signal_lsb;
       if( $signal_type eq 'SIGNED' and $signal_msb =~ /^1/ )
       {
            $signal_msb_without_sign = substr($signal_msb,1,length($signal_msb)-1);
            $signal_msb_without_sign_compl = ~ $signal_msb_without_sign;   # 2 - complement (change all bits)
            $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb_without_sign_compl , -32)));
            $signal_raw_value = ($signal_raw_value + 1) * -1;  # add 1 due to calculation rule with signed values and multiply with -1
        }
       else
       {
            $signal_raw_value = unpack("N", pack("B32", substr("0" x 32 . $signal_msb, -32)));
        }
        $sig_value_phys = ($signal_raw_value * $signal_factor) + $signal_offset ;
        $sig_data_ref->{ $time_stamp } = $sig_value_phys ;

    }

    unless( $sig_data_ref )
   {
        S_w2log( 3, " VEC_trace_fr_get_signal_data : could not extract signal $fr_signal at startbit: $signal_start_bit, length: $signal_length format: $signal_format\n");
    }
    return $sig_data_ref;
}





######################################################################

=head2 VEC_set_can_crc_error

    return_value =  VEC_set_can_crc_error ( $OLE_handle , $message_name [ , $method, $NbOfCycles ] );

=cut

######################################################################

sub VEC_set_can_crc_error {
    my ( $OLE_handle, $message_name, $method, $NbOfCycles, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_set_can_crc_error( OLE_handle , message_name )", 110 );
        return;
    }

    my ( $CAPL_crc_signal_control, $CAPL_crc_method, $CAPL_crc_NbOfCycles_control, $CRCVarName, $Env_Sys_NbOfCycles, $MethodVarName, );

    my $setValue = 0;
    my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_Mapping) {
        S_set_error( " VEC_set_can_crc_error : LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $CRCVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_VALIDCRC'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_VALIDCRC' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    if ( defined $NbOfCycles ) {
        unless ( $Env_Sys_NbOfCycles = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_NoInvCRC'} ) {
            S_set_error( " no EnvVar/SysVar 'CANOE_NoInvCRC' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
            return;
        }
    }
    unless ( $MethodVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_CRC_METHOD'} ) {
        S_w2rep( " no EnvVar 'CANOE_CRC_METHOD' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        $MethodVarName = undef;

    }

    return 1 if $main::opt_offline;

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_set_can_crc_error : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $CAPL_crc_signal_control = VEC_get_env_variable( $OLE_handle, $CRCVarName ) if not ($CRCVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_crc_signal_control ) {
        $CAPL_crc_signal_control->{'Value'} = $setValue;
    }
    else {
        S_w2log( 4, " VEC_set_can_crc_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_crc_signal_control = VEC_get_sys_variable( $OLE_handle, $CRCVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$CRCVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_crc_signal_control, $setValue );
    }

    S_w2log( 4, " VEC_set_can_crc_error : clear $CRCVarName = $setValue \n" );

    if ( defined $NbOfCycles ) {

        $CAPL_crc_NbOfCycles_control = VEC_get_env_variable( $OLE_handle, $Env_Sys_NbOfCycles ) if not ($Env_Sys_NbOfCycles =~ /::/i); #System variable  should have :: operator
        if ( defined $CAPL_crc_NbOfCycles_control ) {
            $CAPL_crc_NbOfCycles_control->{'Value'} = $NbOfCycles;
        }
        else {
            S_w2log( 4, " VEC_set_can_crc_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
            unless ( defined( $CAPL_crc_NbOfCycles_control = VEC_get_sys_variable( $OLE_handle, $Env_Sys_NbOfCycles ) ) ) {
                S_set_error( " error while resolving CAPL environment or system object of '$Env_Sys_NbOfCycles'", 0 );
                return;
            }

            VEC_set_SysVar_value_by_type( $CAPL_crc_NbOfCycles_control, $NbOfCycles );
        }

        S_w2log( 4, " VEC_set_can_crc_error : set $CAPL_crc_NbOfCycles_control = $NbOfCycles \n" );

    }

    if ( defined $MethodVarName ) {
        $CAPL_crc_method = VEC_get_env_variable( $OLE_handle, $MethodVarName ) if not ($MethodVarName =~ /::/i); #System variable  should have :: operator
        if ( defined $CAPL_crc_method ) {
            $CAPL_crc_method->{'Value'} = $method;
        }
        else {
            S_w2log( 4, " VEC_set_can_crc_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
            unless ( defined( $CAPL_crc_method = VEC_get_sys_variable( $OLE_handle, $MethodVarName ) ) ) {
                S_set_error( " error while resolving CAPL environment or system object of '$MethodVarName'", 0 );
                return;
            }

            VEC_set_SysVar_value_by_type( $CAPL_crc_method, $method );
        }

        S_w2log( 4, " VEC_set_can_crc_error : set $MethodVarName = $method \n" );
    }

    return 1;
}





######################################################################

=head2 VEC_reset_can_crc_error

    return_value =  VEC_reset_can_crc_error ( $OLE_handle , $message_name );

=cut

######################################################################

sub VEC_reset_can_crc_error {
    my ( $OLE_handle, $message_name, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_reset_can_crc_error( OLE_handle , can_signal_ref , signal_value )", 110 );
        return;
    }

    my ( $CAPL_crc_signal_control, $CAPL_crc_method, $CRCVarName, );

    my $resetValue = 1;
    my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_Mapping) {
        S_set_error( " LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $CRCVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_VALIDCRC'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_VALIDCRC' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    return 1 if $main::opt_offline;

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_reset_can_crc_error : measurement not running use VEC_write_can_configure() before \n" );
        return;

    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $CAPL_crc_signal_control = VEC_get_env_variable( $OLE_handle, $CRCVarName ) if not ($CRCVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_crc_signal_control ) {
        $CAPL_crc_signal_control->{'Value'} = $resetValue;
    }
    else {
        S_w2log( 4, " VEC_reset_can_crc_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_crc_signal_control = VEC_get_sys_variable( $OLE_handle, $CRCVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$CRCVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_crc_signal_control, $resetValue );
    }

    S_w2log( 4, " VEC_reset_can_crc_error : set $CRCVarName = $resetValue \n" );

    return 1;
}




######################################################################

=head2 VEC_set_can_bz_error

    return_value =  VEC_set_can_bz_error ( $OLE_handle , $message_name [ , $method , $NbOfCycles] );

=cut

######################################################################

sub VEC_set_can_bz_error {
    my ( $OLE_handle, $message_name, $method, $NbOfCycles, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_set_can_bz_error( OLE_handle , message_name )", 110 );
        return;
    }

    my ( $CAPL_bz_signal_control, $CAPL_bz_NbOfCycles_control, $CAPL_bz_method, $BZVarName, $Env_Sys_NbOfCycles, $MethodVarName, );

    my $setValue = 0;
    my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_Mapping) {
        S_set_error( " LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $BZVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_VALIDBZ'} ) {
        S_set_error( " no EnvVar/SysVar CANOE_VALIDBZ' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    if ( defined $NbOfCycles ) {
        unless ( $Env_Sys_NbOfCycles = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_NoInvBZ'} ) {
            S_set_error( " no EnvVar/Sys 'CANOE_NoInvBZ' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
            return;
        }
    }
    unless ( $MethodVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_BZ_METHOD'} ) {
        S_w2rep( " no EnvVar/SysVar 'CANOE_BZ_METHOD' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        $MethodVarName = undef;

    }

    return 1 if $main::opt_offline;

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_set_can_bz_error : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $CAPL_bz_signal_control = VEC_get_env_variable( $OLE_handle, $BZVarName ) if not ($BZVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_bz_signal_control ) {
        $CAPL_bz_signal_control->{'Value'} = $setValue;
    }
    else {
        S_w2log( 4, " VEC_set_can_bz_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_bz_signal_control = VEC_get_sys_variable( $OLE_handle, $BZVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$BZVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_bz_signal_control, $setValue );
    }

    S_w2log( 4, " VEC_set_can_bz_error : clear $BZVarName = $setValue \n" );

    if ( defined $NbOfCycles ) {

        $CAPL_bz_NbOfCycles_control = VEC_get_env_variable( $OLE_handle, $Env_Sys_NbOfCycles ) if not ($Env_Sys_NbOfCycles =~ /::/i); #System variable  should have :: operator
        if ( defined $CAPL_bz_NbOfCycles_control ) {
            $CAPL_bz_NbOfCycles_control->{'Value'} = $NbOfCycles;
        }
        else {
            S_w2log( 4, " VEC_set_can_bz_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
            unless ( defined( $CAPL_bz_NbOfCycles_control = VEC_get_sys_variable( $OLE_handle, $Env_Sys_NbOfCycles ) ) ) {
                S_set_error( " error while resolving CAPL environment or system object of '$Env_Sys_NbOfCycles'", 0 );
                return;
            }

            VEC_set_SysVar_value_by_type( $CAPL_bz_NbOfCycles_control, $NbOfCycles );
        }

        S_w2log( 4, " VEC_set_can_bz_error : set $CAPL_bz_NbOfCycles_control = $NbOfCycles \n" );

    }

    if ( defined $MethodVarName ) {
        $CAPL_bz_method = VEC_get_env_variable( $OLE_handle, $MethodVarName ) if not ($MethodVarName =~ /::/i); #System variable  should have :: operator
        if ( defined $CAPL_bz_method ) {
            $CAPL_bz_method->{'Value'} = $method;
        }
        else {
            S_w2log( 4, " VEC_set_can_bz_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
            unless ( defined( $CAPL_bz_method = VEC_get_sys_variable( $OLE_handle, $MethodVarName ) ) ) {
                S_set_error( " error while resolving CAPL environment or system object of '$MethodVarName'", 0 );
                return;
            }

            VEC_set_SysVar_value_by_type( $CAPL_bz_method, $method );
        }

        S_w2log( 4, " VEC_set_can_bz_error : set $MethodVarName = $method \n" );
    }

    return 1;
}




######################################################################

=head2 VEC_reset_can_bz_error

    return_value =  VEC_reset_can_bz_error ( $OLE_handle , $message_name );

=cut

######################################################################

sub VEC_reset_can_bz_error {
    my ( $OLE_handle, $message_name, ) = @_;

    unless ( defined $message_name ) {
        S_set_error( " SYNTAX: VEC_reset_can_bz_error( OLE_handle , can_signal_ref , signal_value )", 110 );
        return;
    }

    my (
        $CAPL_bz_signal_control,
        $CAPL_bz_method,
        $BZVarName,

        #$MethodEnvVarName ,
    );

    my $resetValue = 1;
    my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_Mapping) {
        S_set_error( " LIFT CAN_mapping doesnot exist", 0 );
    }

    unless ( $BZVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$message_name}{'CANOE_VALIDBZ'} ) {
        S_set_error( " no EnvVar/SysVar 'CANOE_VALIDBZ' available for given message_name '$message_name' in LIFT CAN mapping", 109 );
        return;
    }

    return 1 if $main::opt_offline;

    unless ( VEC_check_running($OLE_handle) ) {
        S_w2log( 1, " VEC_reset_can_bz_error : measurement not running use VEC_write_can_configure() before \n" );
        return;
    }

    #
    # check if Environment variable has been used then set the value to it otherwise set to system variable
    #

    $CAPL_bz_signal_control = VEC_get_env_variable( $OLE_handle, $BZVarName ) if not ($BZVarName =~ /::/i); #System variable  should have :: operator
    if ( defined $CAPL_bz_signal_control ) {
        $CAPL_bz_signal_control->{'Value'} = $resetValue;
    }
    else {
        S_w2log( 4, " VEC_reset_can_bz_error : Mapping file Environment not found for $message_name, now looking for System variable. \n" );
        unless ( defined( $CAPL_bz_signal_control = VEC_get_sys_variable( $OLE_handle, $BZVarName ) ) ) {
            S_set_error( " error while resolving CAPL environment or system object of '$BZVarName'", 0 );
            return;
        }

        VEC_set_SysVar_value_by_type( $CAPL_bz_signal_control, $resetValue );
    }

    S_w2log( 4, " VEC_reset_can_bz_error : set $BZVarName = $resetValue \n" );

    return 1;
}




######################################################################

=head2 VEC_set_flxr_crc_error

    return_value =  VEC_set_flxr_crc_error ( $OLE_handle , $message_name [ , $method ] );

=cut

######################################################################

sub VEC_set_flxr_crc_error
{
   my (
         $OLE_handle ,
         $message_name ,
         $method ,
         ) = @_ ;

   unless( defined $message_name ) {
      S_set_error( " SYNTAX: VEC_disable_flxr_message( OLE_handle , flxr_signal_ref , signal_value )", 110 );
      return;
   }

   my (
        $CAPL_crc_signal_control ,
        $CAPL_crc_method,
        $CRCEnvVarName ,
        $MethodEnvVarName ,
       );

    my $Flexray_Mapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);

    unless( $Flexray_Mapping ) {
        S_set_error( " LIFT Flexray mapping doesnot exist" , 0 );
    }

   unless( $CRCEnvVarName =  $Flexray_Mapping->{'FR_PDU'}{ $message_name }{'CANOE_VALIDCRC'} ) {
      S_set_error( " no EnvVar 'CANOE_VALIDCRC' available for given message_name '$message_name' in LIFT Flexray Mapping", 109 );
      return;
   }

   unless( $MethodEnvVarName =  $Flexray_Mapping->{'FR_PDU'}{ $message_name }{'CANOE_CRC_METHOD'} ) {
      S_w2rep( " no EnvVar 'CANOE_CRC_METHOD' available for given message_name '$message_name' in LIFT Flexray Mapping", 109 );
      $MethodEnvVarName = undef;

   }

   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_set_flxr_crc_error : measurement not running use VEC_write_flxr_configure() before \n" );
      return;
   }

   unless( $CAPL_crc_signal_control =  VEC_get_env_variable( $OLE_handle , $CRCEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$CRCEnvVarName'", 0 );
      return;
   }


   if(defined $MethodEnvVarName)
   {
   unless( $CAPL_crc_method =  VEC_get_env_variable( $OLE_handle , $MethodEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$MethodEnvVarName'", 0 );
      return;
   }
   }
   return 1 if $main::opt_offline;

   S_w2log( 3, " VEC_set_flxr_crc_error : clear CAPL $CRCEnvVarName = 0\n" );
   $CAPL_crc_signal_control->{'Value'} = 0;

   if( $MethodEnvVarName ) {
      S_w2log( 3, " VEC_set_flxr_crc_error : set CAPL $MethodEnvVarName = $method \n" );
      $CAPL_crc_method->{'Value'} = $method;
   }

   return 1;
}





######################################################################

=head2 VEC_reset_flxr_crc_error

    return_value =  VEC_reset_flxr_crc_error ( $OLE_handle , $message_name );

=cut

######################################################################

sub VEC_reset_flxr_crc_error
{
   my (
         $OLE_handle ,
         $message_name ,
       ) = @_ ;

   unless( defined $message_name ) {
      S_set_error( " SYNTAX: VEC_disable_flxr_message( OLE_handle , flxr_signal_ref , signal_value )", 110 );
      return;
   }

   my (
        $CAPL_crc_signal_control ,
        $CAPL_crc_method,
        $CRCEnvVarName ,
        $MethodEnvVarName ,
       );

    my $Flexray_Mapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);

    unless( $Flexray_Mapping ) {
        S_set_error( " LIFT Flexray mapping doesnot exist" , 0 );
    }

   unless( $CRCEnvVarName =  $Flexray_Mapping->{'FR_PDU'}{ $message_name }{'CANOE_VALIDCRC'} ) {
      S_set_error( " no EnvVar 'CANOE_VALIDCRC' available for given message_name '$message_name' in LIFT Flexray Mapping", 109 );
      return;
   }



   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_set_flxr_crc_error : measurement not running use VEC_write_flxr_configure() before \n" );
      return;
   }

   unless( $CAPL_crc_signal_control =  VEC_get_env_variable( $OLE_handle , $CRCEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$CRCEnvVarName'", 0 );
      return;
   }



   return 1 if $main::opt_offline;

   S_w2log( 3, " VEC_set_flxr_crc_error : set CAPL $CRCEnvVarName =1\n" );
   $CAPL_crc_signal_control->{'Value'} = 1;



   return 1;
}




######################################################################

=head2 VEC_set_flxr_bz_error

    return_value =  VEC_set_flxr_bz_error ( $OLE_handle , $message_name [ , $method ] );

=cut

######################################################################

sub VEC_set_flxr_bz_error
{
   my (
         $OLE_handle ,
         $message_name ,
         $method ,
         ) = @_ ;

   unless( defined $message_name ) {
      S_set_error( " SYNTAX: VEC_disable_flxr_message( OLE_handle , flxr_signal_ref , signal_value )", 110 );
      return;
   }

   my (
        $CAPL_bz_signal_control ,
        $CAPL_bz_method,
        $BZEnvVarName ,
        $MethodEnvVarName ,
       );

    my $Flexray_Mapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);

    unless( $Flexray_Mapping ) {
        S_set_error( " LIFT Flexray mapping doesnot exist" , 0 );
    }

   unless( $BZEnvVarName =  $Flexray_Mapping->{'FR_PDU'}{ $message_name }{'CANOE_VALIDBZ'} ) {
      S_set_error( " no EnvVar 'CANOE_VALIDBZ' available for given message_name '$message_name' in LIFT Flexray Mapping", 109 );
      return;
   }

   unless( $MethodEnvVarName =  $Flexray_Mapping->{'FR_PDU'}{ $message_name }{'CANOE_BZ_METHOD'} ) {
      S_w2rep( " no EnvVar 'CANOE_BZ_METHOD' available for given message_name '$message_name' in LIFT Flexray Mapping", 109 );
      $MethodEnvVarName = undef;

   }

   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_set_flxr_bz_error : measurement not running use VEC_write_flxr_configure() before \n" );
      return;
   }

   unless( $CAPL_bz_signal_control =  VEC_get_env_variable( $OLE_handle , $BZEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$BZEnvVarName'", 0 );
      return;
   }


   if(defined $MethodEnvVarName)
   {
   unless( $CAPL_bz_method =  VEC_get_env_variable( $OLE_handle , $MethodEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$MethodEnvVarName'", 0 );
      return;
   }
   }
   return 1 if $main::opt_offline;

   S_w2log( 3, " VEC_set_flxr_bz_error : clear CAPL $BZEnvVarName = 0\n" );
   $CAPL_bz_signal_control->{'Value'} = 0;

   if( $MethodEnvVarName ) {
      S_w2log( 3, " VEC_set_flxr_bz_error : set CAPL $MethodEnvVarName = $method \n" );
      $CAPL_bz_method->{'Value'} = $method;
   }

   return 1;
}




######################################################################

=head2 VEC_reset_flxr_bz_error

    return_value =  VEC_reset_flxr_bz_error ( $OLE_handle , $message_name );

=cut

######################################################################

sub VEC_reset_flxr_bz_error
{
   my (
         $OLE_handle ,
         $message_name ,
       ) = @_ ;

   unless( defined $message_name ) {
      S_set_error( " SYNTAX: VEC_disable_flxr_message( OLE_handle , flxr_signal_ref , signal_value )", 110 );
      return;
   }

   my (
        $CAPL_bz_signal_control ,
        $CAPL_bz_method,
        $BZEnvVarName ,
        $MethodEnvVarName ,
       );

    my $Flexray_Mapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);

    unless( $Flexray_Mapping ) {
        S_set_error( " LIFT Flexray mapping doesnot exist" , 0 );
    }

   unless( $BZEnvVarName =  $Flexray_Mapping->{'FR_PDU'}{ $message_name }{'CANOE_VALIDBZ'} ) {
      S_set_error( " no EnvVar 'CANOE_VALIDBZ' available for given message_name '$message_name' in LIFT Flexray Mapping", 109 );
      return;
   }

   unless( VEC_check_running ( $OLE_handle ) ) {
      S_w2log( 1, " VEC_set_flxr_bz_error : measurement not running use VEC_write_flxr_configure() before \n" );
      return;
   }

   unless( $CAPL_bz_signal_control =  VEC_get_env_variable( $OLE_handle , $BZEnvVarName ) ) {
      S_set_error( " error while resolving CAPL environment object of '$BZEnvVarName'", 0 );
      return;
   }



   return 1 if $main::opt_offline;

   S_w2log( 3, " VEC_set_flxr_bz_error : set CAPL $BZEnvVarName =1\n" );
   $CAPL_bz_signal_control->{'Value'} = 1;



   return 1;
}




=head2 VEC_init

    $functionAreas_href = VEC_init ( $function_area );

Initialize the device(s) for the given function area ($function_area). 
$function_area can be one of the following: CAN_Access, FlexRay_Access, LIN_Access.
The devices are defined in LIFT_testbenches:

    '<function area>' => {
       'basic' =>  'CANoe',     # function groups: read, write, trace, simulation
       'stimulate' => 'CANoe',  # function group stimulate
    },

The reason for the differentiation between 'basic' and 'stimulate' is that different libraries are used.

For backwards compatibility the old way of function configuration is also supported, 
but only for the function groups read, write and trace:

    '<function area>' => {
	   'read' =>  [ 'CANoe' ],
	   'write' => [ 'CANoe' ],
	   'trace' => [ 'CANoe' ],
    },

The device that is usually used for all function groups is currently 'CANoe'.

=cut

sub VEC_init {
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_init ( $function_area )', @args );

    my $function_area = shift @args;

    my $bus;
    if ( $function_area =~ /^(CAN|FlexRay|LIN)_Access$/ ) {
        $bus = $1;
    }
    else {
        S_set_error( "Given \$function_area = $function_area is not one of: CAN_Access, FlexRay_Access, LIN_Access ", 20 );
        return;
    }

    my $testbench_href = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );
    my $device_cnt;

    S_w2log( 4, "\n Starting Vector_init for function area '$function_area'...\n" );

    foreach my $function ( keys %{ $testbench_href->{'Functions'}{$function_area} } ) {
        $device_cnt = 0;
        my @devices;
        my $devices_mix = $testbench_href->{'Functions'}{$function_area}{$function};
        if( ref( $devices_mix ) eq 'ARRAY' ) {
            @devices = @{ $devices_mix };
        }
        elsif( ref( $devices_mix ) eq '' ) {
            push( @devices, $devices_mix );
        }
        else{
            S_set_error( "For \$function_area = '$function_area' and function group = '$function' the device(s) given are neither a scalar nor an array reference", 20 );
            return;
        }

        foreach my $device ( @devices ) {

            Init_device ( $function_area, $function, $device );

        }
    }
    return $initEquipment_href->{'FunctionAreas'}{$function_area};
}

sub Init_device{
    my @args = @_;
    return unless S_checkFunctionArguments( 'Init_device ( $function_area, $function, $device )', @args );

    my $function_area = shift @args;
    my $function = shift @args;
    my $device = shift @args;

    my $bus;
    if ( $function_area =~ /^(CAN|FlexRay|LIN)_Access$/ ) {
        $bus = $1;
    }

    unless ( defined $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} ) {
        my $success;
        if( $device =~ /^(CANalyzer|CANoe)$/ ) {
            $success = VEC_cantool_init( $device, $function, $bus );
        }
        elsif ( $device eq 'CANStress' ) {
            $success = VCS_canstress_init( $device, $function )
        }
        else{
            S_set_error( "Unknown device ('$device') configured for \$function_area = $function_area and function group = '$function' in LIFT_Testbenches.pm", 20 );
            return;
        }

        if ( $success ) {

            $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} = 1;
            S_w2log( 3, " Vector_init for $function_area : Function '$function' -> Device is '$device'\n" );
            $initEquipment_href->{'FunctionAreas'}{$function_area}{$function} = [$device];
            if( $function eq 'basic' ) {
                $initEquipment_href->{'FunctionAreas'}{$function_area}{'read'} = [$device];
                $initEquipment_href->{'FunctionAreas'}{$function_area}{'trace'} = [$device];
                $initEquipment_href->{'FunctionAreas'}{$function_area}{'write'} = [$device];
                $initEquipment_href->{'FunctionAreas'}{$function_area}{'simulation'} = [$device];
            }
        }
        else {
            S_w2log( 3, " Vector_init for $function_area : VEC_cantool_init not successful\n" );
            return;
        }
    }
    else {
        # function on device was already initialized
        S_w2log( 3, " Vector_init for $function_area : Function '$function' -> Device is '$device'\n" );
    }

    return 1;
}

=head2 VEC_logTrace_based_on_Logging_File_Config

    $store_file_name = VEC_logTrace_based_on_Logging_File_Config ( $OLE_handle, $store_file_name);

It logs the CANoe trace based on the setting's done in the CANoe for "Logging File Configuration".

 Check : what user has configured for the logging file ?  
  Measurement setup -> Logging Block > Logging File Configuration
  --> if option "After each trigger block"  is :
      --> checked : RBS will not be stopped to take the log file.
      --> unchecked : stop the RBS & take the log file.
 
 success return value is  : $store_file_name name
 offline return : 'dummy_Log'. 
 Error return : undef.

=cut
    
sub VEC_logTrace_based_on_Logging_File_Config {

    my @args = @_;

    my $OLE_handle      = shift @args;
    my $store_file_name = shift @args;    # already checked in the calling function..

    my $dummy_ret = 'dummy_Log';
    my $LogFile_CANoe;
    my $trace_matched_flag = 0;
    my $SYSVAR_OBJECT_LOGING;
    my $SysVarName = 'LIFT_CAN_access::SysVar_logging_control';    # used system variable

    S_w2log( 5, "VEC_logTrace_based_on_Logging_File_Config :  start .. \n" );

    return $dummy_ret if $main::opt_offline;                       # just return if running in offline mode

    # default log file from Test bench ( -> already checked in VEC_cantool_init)
    my $device            = VEC_get_device_for_OLE_handle($OLE_handle);
    my $LogFile_TestBench = $Vector_tool_control->{'Devices'}{$device}{'DefaultLogFile'};

    ##  Check : what user has configured for the logging file ?
    #------------------------------------------------------------------
    #   Measurement setup -> Logging Block > Logging File Configuration
    #   --> if option "After each trigger block"  is :
    #        --> checked : RBS need not to be stopped to take the log file.
    #        --> unchecked : stop RBS & take the log file
    # -----------------------------------------------------------------

    if ( $Vector_tool_control->{'OLE_handles'}{$OLE_handle}{'LogFileConfig'}{'IncrementAfterTrigger'} == 1 ) {

        # stop logging ..
        # write the system variable = 'LIFT_CAN_access::SysVar_logging_control' = 0
        unless ( $SYSVAR_OBJECT_LOGING = VEC_get_sys_variable( $OLE_handle, $SysVarName ) ) {
            S_set_error( " VEC_logTrace_based_on_Logging_File_Config : error while resolving CAPL environment object of Sysvar '$SysVarName'", 0 );
            return;
        }

        # this will stop the trace logging
        $SYSVAR_OBJECT_LOGING->{'Value'} = 0;    # WRITING WILL BE DONE HERE AND NOW
        $store_file_name = VEC_trace_store_without_stop_measurement( $OLE_handle, $store_file_name, $LogFile_TestBench );

    }
    else {

        ### Logging with stopping the measurement
        $store_file_name = VEC_trace_store_with_stop_measurement( $OLE_handle, $store_file_name, $LogFile_TestBench );
    }

    S_w2log( 5, "VEC_logTrace_based_on_Logging_File_Config : end.  Returned store file is $store_file_name  \n" );

    return $store_file_name;
}

=head2 VEC_trace_store_with_stop_measurement

    $store_file_name = VEC_trace_store_with_stop_measurement ( $OLE_handle, $store_file_name, $LogFile_TestBench);

Log file configured in testBench "$LogFile_TestBench" will be copied to location "$store_file_name".

 Remark :
 1) It stops the RBS / measurement before taking the trace log file.
 2) called by function "VEC_logTrace_based_on_Logging_File_Config".   
  
 success return value is  : $store_file_name name
 offline return : 'dummy_Log'. 
 Error return : undef.

=cut

sub VEC_trace_store_with_stop_measurement {

    my @args = @_;

    my $OLE_handle        = shift @args;    # already checked in the calling function..
    my $store_file_name   = shift @args;    # already checked in the calling function..
    my $LogFile_TestBench = shift @args;    # already checked in the calling function..

    my $dummy_ret = 'dummy_Log';

    return $dummy_ret if $main::opt_offline;                               # just return if running in offline mode
    VEC_stop_measurement($OLE_handle) if VEC_check_running($OLE_handle);

    S_w2log( 3, " VEC_trace_store_with_stop_measurement : Copy '$LogFile_TestBench' -> $store_file_name \n" );
    
    VEC_check_trace_file_length ($LogFile_TestBench) ;
    VEC_check_trace_file_length ($store_file_name) ;
    
    unless ( copy( $LogFile_TestBench, $store_file_name ) ) {
        S_set_error( " VEC_trace_store_with_stop_measurement : copy ( '$LogFile_TestBench', '$store_file_name' ) : $! \n", 1 );
        return;
    }

    return $store_file_name;
}




=head2 VEC_trace_store_without_stop_measurement

    $store_file_name = VEC_trace_store_without_stop_measurement ( $OLE_handle, $store_file_name, $LogFile_TestBench);

Log file configured in testBench "$LogFile_TestBench" will be copied to location "$store_file_name".

 Remark : 
 1) It doesnot stops the RBS / measurement before taking the trace log file.
 2) called by function "VEC_logTrace_based_on_Logging_File_Config".     
  
 success return value is  : $store_file_name name
 offline return : 'dummy_Log'. 
 Error return : undef.

=cut

sub VEC_trace_store_without_stop_measurement {

    my @args = @_;

    my $OLE_handle        = shift @args;    # already checked in the calling function..
    my $store_file_name   = shift @args;    # already checked in the calling function..
    my $LogFile_TestBench = shift @args;    # already checked in the calling function..

    my @LogFileNames;
    my $matched_flag;
    my $incremented_LogFile_CANoe;
    my $dummy_ret = 'dummy_Log';

    return $dummy_ret if $main::opt_offline;    # just return if running in offline mode

    @LogFileNames = VEC_get_configured_logfile_names($OLE_handle);
    @LogFileNames = ($dummy_ret) if $main::opt_offline;

    $matched_flag = 0;
    foreach (@LogFileNames) {

        $incremented_LogFile_CANoe = $_;        # use it later to store this file
        my $LogFileName = basename($_);
        $LogFileName =~ s/\d+\.asc$/.asc/i;     # remove numbers from CANoe incrementing file
        if ( $LogFileName eq basename($LogFile_TestBench) ) {
            $matched_flag = 1;                  # same log file as from CANoe and Testbench
        }
    }

    unless ($matched_flag) {
        my $log_files_text = join( " ", @LogFileNames );
        S_set_error( " VEC_trace_store_without_stop_measurement : Could not find Testbench Log_File '$LogFile_TestBench' in configured Log_Files ( '$log_files_text' ).  \n", 131 );
        return;
    }

	VEC_check_trace_file_length ($incremented_LogFile_CANoe) ;
	VEC_check_trace_file_length ($store_file_name) ;

    S_w2log( 3, " VEC_trace_store_without_stop_measurement : Copy '$incremented_LogFile_CANoe' -> $store_file_name \n" );
    unless ( copy( $incremented_LogFile_CANoe, $store_file_name ) ) {
        S_set_error( " copy ( '$incremented_LogFile_CANoe' , '$store_file_name' ) : $! \n", 1 );
        return $dummy_ret;
    }

    return $store_file_name;
}

###############################################################################################

=head2 VEC_set_lin_crc_error

    return_value = VEC_set_lin_crc_error ( OLE_handle , lin message [ , method, number Of Cycles ] );

Set CRC error to lin_message.

B<Arguments:>

=over

=item OLE Handle

OLE handle of the CANoe.  
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

value for method

=item  number_of_cycles

Number of cycles for which it should be made invalid 

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = VEC_set_lin_crc_error ( $LIN_control->{'write'}{$device}{'OLE_handle'}, 'seating', 'constant', 24 );

=cut 

###############################################################################################

sub VEC_set_lin_crc_error {
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_set_lin_crc_error( $ole_handle_mix , $lin_message [ ,$method, $nbOfCycles ] )', @args );

    my $ole_handle   = shift @args;
    my $message_name = shift @args;
    my $method       = shift @args;
    my $nbOfCycles   = shift @args;

    my ( $capl_crc_signal_control, $crcEnvVarName, $capl_crc_NbOfCycles_control, $envNbOfCycles, $methodVarName );

    my $lin_Mapping = S_get_contents_of_hash( ['Mapping_LIN'] );

    unless ( defined $lin_Mapping ) {
        S_set_warning( " VEC_set_lin_crc_error : LIFT LIN_mapping doesnot exist");
    }

    unless ( $crcEnvVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_VALIDCRC'} ) {
        S_set_error( " no EnvVar 'CANOE_VALIDCRC' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
        return;
    }

    unless ( VEC_check_running($ole_handle) ) {
        S_w2log( 1, " VEC_set_lin_crc_error : measurement not running use VEC_write_lin_configure() before \n" );
        return;
    }

    unless ( $methodVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_CRC_METHOD'} ) {
        S_w2rep( " no EnvVar/SysVar 'CANOE_CRC_METHOD' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
    }

    unless ( $capl_crc_signal_control = VEC_get_env_variable( $ole_handle, $crcEnvVarName ) ) {
        S_set_warning( " error while resolving CAPL environment object of '$crcEnvVarName'" );
        return;
    }
    if ( defined $nbOfCycles ) {

        unless ( $envNbOfCycles = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_NoInvCRC'} ) {
            S_set_error( " no EnvVar 'CANOE_NoInvCRC' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
            return;
        }

        unless ( $capl_crc_NbOfCycles_control = VEC_get_env_variable( $ole_handle, $envNbOfCycles ) ) {
            S_set_error( " error while resolving CAPL environment object of '$envNbOfCycles'", 0 );
            return;
        }
    }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEC_set_lin_crc_error : clear CAPL $crcEnvVarName = 0\n" );
    $capl_crc_signal_control->{'Value'} = 0;
    if ( defined $nbOfCycles ) {
        S_w2log( 3, " VEC_set_lin_crc_error : set CAPL $envNbOfCycles = $nbOfCycles\n" );
        $capl_crc_NbOfCycles_control->{'Value'} = $nbOfCycles;
    }

    return 1;
}


######################################################################

=head2 VEC_reset_lin_crc_error

    return_value = VEC_reset_lin_crc_error ( OLE_handle , LIN_message [, method ] );

Remove CRC error from lin_message.

B<Arguments:>

=over

=item OLE Handle

OLE handle of the CANoe.  
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

value for method

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = VEC_reset_lin_crc_error ( $LIN_control->{'write'}{$device}{'OLE_handle'}, 'seating');

=cut 

######################################################################

sub VEC_reset_lin_crc_error {
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_reset_lin_crc_error( $ole_handle_mix , $lin_message [, $method ])', @args );

    my $ole_handle   = shift @args;
    my $message_name = shift @args;
    my $method       = shift @args;

    my ( $capl_crc_signal_control, $crcEnvVarName, $methodVarName );

    my $lin_Mapping = S_get_contents_of_hash( ['Mapping_LIN'] );

    unless ( defined $lin_Mapping ) {
        S_set_warning( " VEC_reset_lin_crc_error : LIFT LIN_mapping doesnot exist" );
    }

    unless ( $crcEnvVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_VALIDCRC'} ) {
        S_set_error( " no EnvVar 'CANOE_VALIDCRC' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
        return;
    }

    unless ( $methodVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_CRC_METHOD'} ) {
        S_w2rep( " no EnvVar/SysVar 'CANOE_CRC_METHOD' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
    }

    unless ( VEC_check_running($ole_handle) ) {
        S_w2log( 1, " VEC_set_can_crc_error : measurement not running use VEC_write_can_configure() before \n" );
        return;

    }

    unless ( $capl_crc_signal_control = VEC_get_env_variable( $ole_handle, $crcEnvVarName ) ) {
        S_set_warning( " error while resolving CAPL environment object of '$crcEnvVarName'");
        return;
    }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEC_set_lin_crc_error : set CAPL $crcEnvVarName =1\n" );
    $capl_crc_signal_control->{'Value'} = 1;

    return 1;
}


###############################################################################################

=head2 VEC_set_lin_bz_error

    return_value = VEC_set_lin_bz_error ( OLE_handle , lin message [ , method, number Of Cycles ] );

Set BZ error to lin_message.

B<Arguments:>

=over

=item OLE Handle

OLE handle of the CANoe.  
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

LIN Message name as in LIN mapping file

=item  number_of_cycles

Number of cycles for which it should be made invalid 

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = VEC_set_lin_bz_error ( $LIN_control->{'write'}{$device}{'OLE_handle'}, 'seating', 'constant', 24 );

=cut 

###############################################################################################

sub VEC_set_lin_bz_error {
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_set_lin_bz_error( $ole_handle_mix , $lin_message [ ,$method, $nbOfCycles ] )', @args );

    my $ole_handle   = shift @args;
    my $message_name = shift @args;
    my $method       = shift @args;
    my $nbOfCycles   = shift @args;

    my ( $capl_bz_signal_control, $bzEnvVarName, $capl_bz_NbOfCycles_control, $envNbOfCycles, $methodVarName, );

    my $lin_Mapping = S_get_contents_of_hash( ['Mapping_LIN'] );

    unless (defined $lin_Mapping ) {
        S_set_warning( " VEC_set_lin_bz_error : LIFT LIN_mapping doesnot exist" );
    }

    unless ( $bzEnvVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_VALIDBZ'} ) {
        S_set_error( " no EnvVar 'CANOE_VALIDBZ' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
        return;
    }

    unless ( $methodVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_BZ_METHOD'} ) {
        S_w2rep( " no EnvVar/SysVar 'CANOE_BZ_METHOD' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
    }

    unless ( VEC_check_running($ole_handle) ) {
        S_w2log( 1, " VEC_set_lin_bz_error : measurement not running use VEC_write_lin_configure() before \n" );
        return;
    }

    unless ( $capl_bz_signal_control = VEC_get_env_variable( $ole_handle, $bzEnvVarName ) ) {
        S_set_warning( " error while resolving CAPL environment object of '$bzEnvVarName'" );
        return;
    }
    if ( defined $nbOfCycles ) {
        unless ( $envNbOfCycles = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_NoInvBZ'} ) {
            S_set_error( " no EnvVar 'CANOE_NoInvBZ' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
            return;
        }

        unless ( $capl_bz_NbOfCycles_control = VEC_get_env_variable( $ole_handle, $envNbOfCycles ) ) {
            S_set_error( " error while resolving CAPL environment object of '$envNbOfCycles'", 0 );
            return;
        }
    }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEC_set_lin_bz_error : clear CAPL $bzEnvVarName = 0\n" );
    $capl_bz_signal_control->{'Value'} = 0;

    if ( defined $nbOfCycles ) {
        S_w2log( 3, " VEC_set_lin_bz_error : set CAPL $envNbOfCycles = $nbOfCycles\n" );
        $capl_bz_NbOfCycles_control->{'Value'} = $nbOfCycles;
    }
    return 1;
}

######################################################################

=head2 VEC_reset_lin_bz_error

    return_value = VEC_reset_lin_bz_error ( OLE_handle , LIN_message [, method] );

Remove BZ error from lin_message.

B<Arguments:>

=over

=item OLE Handle

OLE handle of the CANoe.  
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

value for method

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = VEC_reset_lin_bz_error ( $LIN_control->{'write'}{$device}{'OLE_handle'}, 'seating', 'constant');

=cut

######################################################################

sub VEC_reset_lin_bz_error {
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_reset_lin_bz_error( $ole_handle_mix , $lin_message [, $method]  )', @args );

    my $ole_handle   = shift @args;
    my $message_name = shift @args;
    my $method       = shift @args;

    my ( $capl_bz_signal_control, $bzEnvVarName, $methodVarName );

    my $lin_Mapping = S_get_contents_of_hash( ['Mapping_LIN'] );

    unless ( defined $lin_Mapping ) {
        S_set_warning( " VEC_reset_lin_bz_error : LIFT LIN_mapping doesnot exist");
    }

    unless ( $bzEnvVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_VALIDBZ'} ) {
        S_set_error( " no EnvVar 'CANOE_VALIDBZ' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
        return;
    }

    unless ( $methodVarName = $lin_Mapping->{'LIN_MESSAGES'}{$message_name}{'CANOE_BZ_METHOD'} ) {
        S_w2rep( " no EnvVar/SysVar 'CANOE_BZ_METHOD' available for given message_name '$message_name' in LIFT LIN mapping", 109 );
    }

    unless ( VEC_check_running($ole_handle) ) {
        S_w2log( 1, " VEC_set_lin_bz_error : measurement not running use VEC_write_lin_configure() before \n" );
        return;
    }

    unless ( $capl_bz_signal_control = VEC_get_env_variable( $ole_handle, $bzEnvVarName ) ) {
        S_set_warning( " error while resolving CAPL environment object of '$bzEnvVarName'" );
        return;
    }

    return 1 if $main::opt_offline;

    S_w2log( 3, " VEC_set_lin_bz_error : set CAPL $bzEnvVarName =1\n" );
    $capl_bz_signal_control->{'Value'} = 1;

    return 1;
}

######################################################################

=head2 VEC_trace_lin_analyze_format

    ( base-type , timestamp-type ) = VEC_trace_lin_analyze_format ( $lin_trace_file );


=cut

######################################################################

sub VEC_trace_lin_analyze_format {
   my $lin_trace_file = shift;

   unless( defined $lin_trace_file ) {
      S_set_error( " SYNTAX: VEC_trace_lin_analyze_format( lin_trace_file )", 110 ); return (undef, undef);
   }

   # return 1 if $main::opt_offline;

   my $Trace_FH = new FileHandle;
   unless( $Trace_FH->open( $lin_trace_file ) ) {
      S_set_error( " Couldnt open LIN Trace '$lin_trace_file' ", 131 ); return(undef, undef);
   }

   my $data_format; my $timestamps;
   while( <$Trace_FH> ) {
      if( /base\s+(\S+)\s+timestamps\s+(\S+)/ ) {  $data_format = $1; $timestamps = $2; last; }
   }

   $Trace_FH->close;

   unless( defined $timestamps ) {
      S_set_error( " Couldnt determine base and timestamps format in '$lin_trace_file' ", 131 ); return(undef, undef);
   }

   S_w2log( 3, " VEC_trace_lin_analyze_format : base = $data_format timestamps = $timestamps \n" );
   return ( $data_format , $timestamps );

}


=head2 VEC_check_trace_file_length

    VEC_check_trace_file_length ($traceFileName) ;

Perform the trace file length check. If it is greater than 255 characters then it throws warning. 

=cut
sub VEC_check_trace_file_length
{
    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_check_trace_file_length ($traceFileName)', @args );
    
    my $traceFileName = shift @args ;    
    my $traceFile_length = length ( $traceFileName ) ;
    
    S_w2log( 4, " VEC_check_trace_file_length : file length of '$traceFileName' = $traceFile_length \n" );
    
    if ($traceFile_length > 255 ) {
	  S_set_error( " VEC_check_trace_file_length : ( file length of '$traceFileName' = $traceFile_length > 255. (remark - it will an error if > 259) ) \n", 0 );
	  return ;
    }
    
    return 1;
}



=head2 VEC_check_InteractionLayer_used

    $returnValue = VEC_check_InteractionLayer_used( );

It checks whether if the Interaction layer has been used or not for the RBS.

=cut

sub VEC_check_InteractionLayer_used {

    my $flag_IL_used = 0;
    my $testbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );

    $flag_IL_used = 0 unless ( defined $testbench->{'Devices'}{'CANoe'}{'ILUsed'} );

    if ( $testbench->{'Devices'}{'CANoe'}{'ILUsed'} =~ /yes/i ) {
        $flag_IL_used = 1;
    }

    return $flag_IL_used;
}


#####################################################################################################################
=head2 VEC_get_bus_signal_info
    
    $returned_sig_info = VEC_get_bus_signal_info ( $bus_signal_name, $bus_type );

Gets the hash reference containing the signal info from LIFT FlexRay/CAN/LIN Mapping module plus the message info

B<Arguments:>

=over

=item $bus_signal_name 

It is the name of the signal 

=item $bus_type 

It is the type of the bus(CAN/LIN/FLEXRAY)

=back

B<Return Value:>

=item $returnValue 

Success : $returned_sig_info - hash reference of signal data info
Failure : undef

=back

B<Examples:> 
  
    $returned_sig_info = VEC_get_bus_signal_info ( 'Blinken_li_Kombi_Takt', 'CAN' );

=cut

sub VEC_get_bus_signal_info {

    # STEP get agruments - $flxr_signal_name
  
   # IF mapping defined ?
       # IF-NO-START
            # STEP $signalInfo_href = undef, set error Mapping flexRay/Lin/Can not defiend                                    
       # IF-NO-END    
       # IF-YES-START
            # STEP fill '$signalInfo_href' for '$signal_name' from Mapping file. 
            # STEP Get corresponding message or PDU for '$signal_name' via '$signalInfo_href'->{FR_PDU_NAME/MESSAGE}
            # IF PDU or message found?
                # IF-NO-START 
                    # STEP $signalInfo_href = undef, set error 'FR_PDU_NAME/MESSAGE' not defined for  $signal_name
                # IF-NO-END
                # IF-YES-START
                    # IF section 'FR_PDU/MESSAGE' defined in Mapping ?
                        # IF-NO-START
                            # STEP $signalInfo_href = undef, set error 'FR_PDU/MESSAGE' section not defined in mapping
                        # IF-NO-END
                        # IF-YES-START
                            # STEP retive PDU or message info for '$signal_name'
                            # STEP append PDU/MESSAGE info to '$signalInfo_href'
                        # IF-YES-END
                    
                # IF-YES-END
            
       # IF-YES-END    

   # STEP return signal_href

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'VEC_get_bus_signal_info ($signal_name, $bus_type )', @args );

    my $signal_name = shift @args;
    my $bus_type    = shift @args;

    my ( $pdu_msg_or_frame_label, $pdu_msg_or_frame_name, $msg_pdu, $signalInfo_href );

    S_w2log( 4, " VEC_get_bus_signal_info: Reads signal and message info from $bus_type mapping \n" );

    $bus_type = uc($bus_type);
    my $bus_Mapping = S_get_contents_of_hash( [ 'Mapping_' . "$bus_type" ] );

    unless (%$bus_Mapping) {
        S_set_error( " LIFT $bus_type Mapping is not defined", 20 );
        return;
    }

    unless ( $signalInfo_href->{$signal_name} = $bus_Mapping->{$signal_name} ) {
        S_set_error( " LIFT_$bus_type Mapping doesnot contain info for signal : '$signal_name'", 20 );
        return;
    }

    if ( $bus_type =~ /FLEXRAY/i && defined $bus_Mapping->{'FR_PDU'} ) {
        ## Incase if user has defined $message under label 'FR_PDU' in FlexrayMapping file
        $pdu_msg_or_frame_label = 'FR_PDU';
        $pdu_msg_or_frame_name  = 'FR_PDU_NAME';    ## In FlexrayMapping file message name of the signal is defined under 'FR_PDU_NAME'
    }
    elsif ( $bus_type =~ /LIN/i && defined $bus_Mapping->{'LIN_MESSAGES'} ) {
        $pdu_msg_or_frame_label = 'LIN_MESSAGES';
        $pdu_msg_or_frame_name  = 'MESSAGE';        ## In LinMapping file message name of the signal is defined under 'LIN_MESSAGES'
    }
    elsif ( $bus_type =~ /CAN/i && defined $bus_Mapping->{'CAN_MESSAGES'} ) {
        $pdu_msg_or_frame_label = 'CAN_MESSAGES';
        $pdu_msg_or_frame_name  = 'MESSAGE';        ## In LinMapping file message name of the signal is defined under 'CAN_MESSAGES'
    }

    unless ( $msg_pdu = $signalInfo_href->{$signal_name}{$pdu_msg_or_frame_name} ) {
        S_set_error( " LIFT_$bus_type Mapping doesnot contain 'PDU_MSG_NAME' info for signal : '$signal_name'", 20 );
        return;
    }
    unless ( $signalInfo_href->{'PDU_MSG_INFO'} = $bus_Mapping->{$pdu_msg_or_frame_label}{$msg_pdu} ) {
        S_set_error( "'MSG_PDU' in LIFT_$bus_type Mapping doesnot contain info for message : '$msg_pdu'", 20 );
        return;
    }

    return $signalInfo_href;

}

#####################################################################################################################

=head2 VEC_validate_bus_signal_info
    
    $returned_sig_info = VEC_validate_bus_signal_info ( $signal_href, $signal_name, $bus_type );
    
This functions validates the signal information obtained from the mapping file

B<Arguments:>

=over

=item $signal_href 

This hash reference contains the information of a signal 

=item $signal_name 

It is the name of the signal 

=item $bus_type 

It is the type of the bus(CAN/LIN/FLEXRAY)

=back

B<Return Value:>

=item $returnValue 

Success : $returned_sig_info - validated hash reference of signal data info
Failure : undef

=back

B<Examples:> 
  
    $returned_sig_info = VEC_validate_bus_signal_info ( $signal_href, 'Blinken_li_Kombi_Takt', 'CAN' );

=cut

sub VEC_validate_bus_signal_info {

    # STEP get agruments - signal_hash_ref, signal_name 

   # STEP validate agruments
   # IF signal_hash_ref exists in mapping ?
   # IF-YES-START
        # IF key 'SIGNAL_NAME' defined in mapping ?        
              # IF-YES-START                    
                    # IF key 'FR_PDU_NAME/MESSAGE' defined in mapping ?
                        # IF-YES-START                            
                            # IF key 'BUS_NBR' defined in mapping ? 
                                # IF-YES-START 
                                    # STEP return validated signal_hash_ref                                  
                                # IF-YES-END
                                # IF-NO-START
                                    # STEP set Bus_Nbr = 1 & set waring as 'BUS_NBR' was not found in Mapping for $signal_name.
                                # IF-NO-END   
                        # IF-YES-END
                        # IF-NO-START
                            # STEP set signal_hash_ref = undef and set Error - FR_PDU_NAME/MESSAGE not defined Mapping for $signal_name
                        # IF-NO-END 
              # IF-YES-END
              # IF-NO-START
                   # STEP set signal_hash_ref = undef and set Error - SIGNAL_NAME not defined Mapping for $signal_name    
              # IF-NO-END                    
   # IF-YES-END
   # IF-NO-START
        # STEP set signal_hash_ref = undef and Error = $signal_name is not part of Mapping 
   # IF-NO-END  
   # STEP return 'signal_hash_ref' after validation

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_validate_bus_signal_info ($signal_href, $signal_name, $bus_type )', @args );

    my $signal_href = shift @args;
    my $signal_name = shift @args;
    my $bus_type    = shift @args;

    my ( $msg_pdu, $signal_vali_href );

    $bus_type = uc($bus_type);

    # apply label mapping if defined for current label in project defaults
    if ( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{$signal_name} ) {
        $signal_name = $main::ProjectDefaults->{'LABEL_MAPPING'}{$signal_name};
    }

    unless (%$signal_href) {
        S_set_error( " LIFT $bus_type Mapping is not defined", 20 );
        return;
    }

    # STEP validate if signal name part of mapping?
    unless ( $signal_href->{$signal_name} ) {
        S_set_error( " $bus_type signal $signal_name is not part of LIFT $bus_type Mapping", 132 );
        return;
    }

    unless ( $signal_vali_href->{'SIGNAL_NAME'} = $signal_href->{$signal_name}{'SIGNAL_NAME'} ) {
        S_set_error( " no 'SIGNAL_NAME' defined for signal '$signal_name' in the LIFT $bus_type Mapping", 109 );
        return;
    }

   unless( $bus_type !~ /FLEXRAY/ || ($msg_pdu = $signal_href->{ $signal_name }{ 'FR_PDU_NAME' }) )  {
        S_set_error( " no 'FR_PDU_NAME' defined for signal '$signal_name' in the LIFT $bus_type Mapping\n", 109 );
        return;
    }

   unless( $bus_type !~ /LIN|CAN/ || ($msg_pdu = $signal_href->{ $signal_name }{ 'MESSAGE' }) )  {
        S_set_error( " no 'MESSAGE' defined for signal '$signal_name' in the LIFT $bus_type Mapping\n", 109 );
        return;
    }

    $signal_vali_href->{'PDU_MESSAGE'}   = $msg_pdu;
    $signal_vali_href->{'UNIT'}          = $signal_href->{$signal_name}{'UNIT'};
    $signal_vali_href->{'OFFSET'}        = $signal_href->{$signal_name}{'OFFSET'};
    $signal_vali_href->{'FACTOR'}        = $signal_href->{$signal_name}{'FACTOR'};
    $signal_vali_href->{'CANOE_ENV_VAR'} = $signal_href->{$signal_name}{'CANOE_ENV_VAR'};
    $signal_vali_href->{'CANOE_SYS_VAR'} = $signal_href->{$signal_name}{'CANOE_SYS_VAR'};

    if ( $bus_type =~ /FLEXRAY/ ) {
        $signal_vali_href->{'BUS_NBR'} = $signal_href->{'PDU_MSG_INFO'}{'FlexRay_BUS_NBR'};
    }
    elsif ( $bus_type =~ /LIN/ ) {
        $signal_vali_href->{'BUS_NBR'} = $signal_href->{'PDU_MSG_INFO'}{'LIN_BUS_NBR'};
    }
    elsif ( $bus_type =~ /CAN/ ) {
        $signal_vali_href->{'BUS_NBR'} = $signal_href->{'PDU_MSG_INFO'}{'CAN_BUS_NBR'};
    }

    unless ( $signal_vali_href->{'BUS_NBR'} ) {
        S_set_warning(" no 'BUS_NBR' defined for PDU/MSG '$msg_pdu'. Assuming Bus number as 1\n");
        $signal_vali_href->{'BUS_NBR'} = 1;
    }

    unless ( $signal_vali_href->{'CYCLE'} = $signal_href->{'PDU_MSG_INFO'}{'CYCLE'} ) {
        S_set_error( " no 'CYCLE' defined for PDU/MSG '$msg_pdu' in the $bus_type Mapping\n", 109 );
        return;
    }

    return $signal_vali_href;

}

#####################################################################################################################

=head2 VEC_calc_phys_from_raw
    
    $phys_value = VEC_calc_phys_from_raw ( $signal_info_href , $raw_value );
    
Converts the phys Value from its raw Value dependendly from the format of the FlexRay/CAN/LIN signal.

B<Arguments:>

=over

=item $signal_info_href 

It is a hash reference containing the signal info from LIFT FlexRay/CAN/LIN Mapping module plus the message info 

=item $raw_value 

raw value of the signal 

=back

B<Return Value:>

=item $returnValue 

Success : $phys_value = physical value of the given $raw_value 
Failure : undef

=back

B<Examples:> 
  
    $phys_value = VEC_calc_phys_from_raw ( $signal_info_href , $raw_value );

=cut

####################################################################################################################

sub VEC_calc_phys_from_raw {

     # COMMENT-START
    # args:
       # - signalInfo_href   
       # - $raw_value
    # COMMENT-END    
    
    # STEP validate arguments - signalInfo_href, $raw_value
    # STEP validate 'SIGNAL_NAME' & fetch signal name from signalInfo_href
    # STEP validate 'OFFSET' & fetch offset value from signalInfo_href
    # STEP validate 'TYPE' & fetch Type value from signalInfo_href
    # STEP validate 'FACTOR' & fetch factor value from signalInfo_href
    # STEP calculate phys value from raw. Formula : phys = (hex * factor) + offset
    # STEP return phys value

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_calc_phys_from_raw ( $signal_info_href, $raw_value)', @args );

    S_w2log( 4, " VEC_calc_phys_from_raw\n" );

    my $signal_info_href = shift @args;
    my $raw_value        = shift @args;

    my ( $phys_value, $sig_offset, $sig_factor, $signal_name, );

    unless ( defined( $signal_name = $signal_info_href->{'SIGNAL_NAME'} ) ) {
        S_set_error( " no 'SIGNAL_NAME' defined for given FlexRay signal\n", 109 );
        return;
    }
    unless ( defined( $sig_offset = $signal_info_href->{'OFFSET'} ) ) {
        S_set_error( " no 'OFFSET' defined for signal '$signal_name' \n", 109 );
        return;
    }

    $sig_factor = $signal_info_href->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 ) {
        S_set_error( " no 'FACTOR' defined or '0.0' for signal '$signal_name' \n", 109 );
        return;
    }

    $phys_value = ( $raw_value * $sig_factor ) + $sig_offset;

    S_w2log( 4, "   Transformation '$signal_name' : $phys_value (phys) = ( $raw_value (raw) * $sig_factor (factor) + $sig_offset (offset) \n" );

    return $phys_value;

}

#####################################################################################################################

=head2 VEC_calc_raw_from_phys
    
    $phys_value = VEC_calc_raw_from_phys ( $signal_info_href , $phys_value );
    
Converts the raw Value from its physical Value dependendly from the format of the FlexRay/CAN/LIN signal.

B<Arguments:>

=over

=item $signal_info_href 

It is a hash reference containing the signal info from LIFT FlexRay/CAN/LIN Mapping module plus the message info 

=item $phys_value 

physical value of the signal 

=back

B<Return Value:>

=item $returnValue 

$raw_value = raw value of the given $phys_value.

=back

B<Examples:> 
  
    $phys_value = VEC_calc_raw_from_phys ( $signal_info_href , $phys_value );

=cut

sub VEC_calc_raw_from_phys {

    # COMMENT-START
    # args:
       # - $signal_info   
       # - $phys_value
    # COMMENT-END
    
    # STEP validate arguments - $signal_info, -$phys_value
    # STEP validate 'SIGNAL_NAME' & fetch signal name from $signal_info

    # STEP validate 'OFFSET' & fetch offset value from $signal_info
    
    # STEP validate 'TYPE' & fetch Type value from $signal_info
    
    # STEP validate 'FACTOR' & fetch factor value from $signal_info  

    # STEP calculate raw value from phys . Formula : raw = (phys - offset) / factor
        
    # STEP round the calcualted raw value
    # TODO : round the calcualted raw value
    
    # STEP return calculated raw value

    my @args = @_;
    return unless S_checkFunctionArguments( 'VEC_calc_raw_from_phys ( $signal_info_href, $phys_value)', @args );

    S_w2log( 4, " VEC_calc_raw_from_phys\n" );

    my $signal_info_href = shift;
    my $phys_value       = shift;

    my ( $raw_value, $sig_offset, $sig_factor, $signal_name );

    unless ( $signal_name = $signal_info_href->{'SIGNAL_NAME'} ) {
        S_set_error( " no 'SIGNAL_NAME' defined for given  CAN signal\n", 109 );
        return;
    }
    $sig_offset = $signal_info_href->{'OFFSET'};
    unless ( defined $sig_offset ) {
        S_set_error( " no 'OFFSET' defined for signal '$signal_name' \n", 109 );
        return;
    }

    $sig_factor = $signal_info_href->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 ) {
        S_set_error( " no 'FACTOR' defined or '0.0' for signal '$signal_name' \n", 109 );
        return;
    }

    $raw_value = NUM_round2Int( ( $phys_value - $sig_offset ) / $sig_factor );
    S_w2log( 4, "   Transformation '$signal_name' : $raw_value (raw) = ( $phys_value (phys) - $sig_offset (offset) / $sig_factor (factor) \n" );
    return $raw_value;

}

####################################################################################################################################

=head2 check_flags
    
    $old_impl_flag = check_flags ( $flag_to_be_checked );
    
It is the flag in testbench which checks 
1.whether old implementation or the new implementation for factor and offset calculation has to be used(only for CAN)
2.whether old implementation or the new implementation for having common enabling and disabling for CAN/LIN/FR  

B<Arguments:>

=over 

=back

B<Return Value:>

=item $returnValue 

$old_impl_flag = 1 : If old implementation is used for ( factor and offset calculation ) or ( enable and disable handling ). 
                 0 : If new implementation is used for ( factor and offset calculation ) or ( enable and disable handling ).

=back

B<Examples:> 
  
    $old_impl_flag = check_flags ( "OldSignalFactorOffsetHandling" );
    $old_impl_flag = check_flags ( "OldEnableDisableHandling" );

=cut

sub check_flags {

    my @args = @_;
    return unless S_checkFunctionArguments( 'check_flags ( $flag_to_be_checked )', @args );

    S_w2log( 4, " Checking if flag is set for old implementation\n" );

    my $flag_to_be_checked = shift;
      
    # STEP : check if to handle oldSignalFactorOffsetHandling ? or oldEnableDisableHandling? 
    my $flag_handle = 0;    # by default : consider option is not given to handle previous implementation of signal offset & factor
                            #            : so we handle new & correct offset & factor calculation

    my $testbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );
    
    if ( $testbench->{'Devices'}{'CANoe'}{$flag_to_be_checked} =~ /yes/i ) {
        $flag_handle = 1;
    }

    return $flag_handle;    
}
########################################################################################################################################

=head2 GetFrameInfoForFrameBasedLog

    $framePduLookup_href = GetFrameInfoForFrameBasedLog ( $flexray_Mapping_href, $pduToSearch)
    
Returns the Frame information from the Flexray Mapping

B<Arguments:>

=over

=item $flexray_Mapping_href

-FlexRay mapping hash reference

=item $pduToSearch

-PDU to be searched in log

=back

B<Return Value:>

=over

=item $framePduLookup_href 

-Reference to the PDU data present in frame 

=back

Called internally by L</"VEC_trace_fr_get_PDU_data">.

=cut

########################################################################################################################################
sub GetFrameInfoForFrameBasedLog {
    my $flexray_Mapping = shift;
    my $pduToSearch     = shift;

    my $pdu_frame = $flexray_Mapping->{'FR_PDU'}{$pduToSearch}{'FRAME_NAME'};
    my $framePduLookup_href;
    foreach my $pdu_name ( keys %{ $flexray_Mapping->{'FR_PDU'} } ) {
        my $pdu_hash = $flexray_Mapping->{'FR_PDU'}{$pdu_name};
        if ( $pdu_hash->{'FRAME_NAME'} =~ /^$pdu_frame$/ ) {
            my $pdu_ID = $pdu_hash->{'PDU_ID_SHORT_HEADER'};
			if ( $pdu_ID ){
	            $pdu_ID =~ s/0x//;
	            $pdu_ID = '0' . $pdu_ID if ( length($pdu_ID) % 2 == 1 );
	            $framePduLookup_href->{$pdu_frame}{$pdu_name}{'ID'} = join( " ", ( $pdu_ID =~ m/../g ) );
			}

            my $pdu_dlc_dec = $pdu_hash->{'DLC'};
            $framePduLookup_href->{$pdu_frame}{$pdu_name}{'LENGTH'} = sprintf( "%02X", $pdu_dlc_dec );
            $framePduLookup_href->{$pdu_frame}{$pdu_name}{'UPDATE-INDICATION-BIT-POSITION'} = $pdu_hash->{'UPDATE-INDICATION-BIT-POSITION'};
            $framePduLookup_href->{$pdu_frame}{$pdu_name}{'START-BIT-POSITION'} = $pdu_hash->{'START-BIT-POSITION'};
            $framePduLookup_href->{$pdu_frame}{$pdu_name}{'LENGTH_DEC'} = $pdu_dlc_dec
        }
    }

    $framePduLookup_href->{'PDU_NAME'}   = $pduToSearch;
    $framePduLookup_href->{'FRAME_NAME'} = $pdu_frame;

    return $framePduLookup_href;
}
###############################################################################################################################

=head2 PreparePDULineUsingUpdateBit

    $framePduLookup_href = PreparePDULineUsingUpdateBit ( $params )
    
Function to get the PDU log exracted from the frame based log when PDU_ID is not present and update bit information is given

B<Arguments:>

=over

=item $params->{'line'}

-Line from log file(Frame based)

=item $params->{'framePduInfo'}

-Frame information from the Flexray Mapping. Returned from L</"GetFrameInfoForFrameBasedLog">.

=item $params->{'pdu'}

-PDU to be searched in Log

=back

B<Return Value:>

=over

=item $pdu_line 

-PDU line extracted from the frame based log

=back

Called internally by L</"VEC_trace_fr_get_PDU_data">.

=cut

sub PreparePDULineUsingUpdateBit {
	my @args         = @_;
	my $params       = shift;
	my $frameLine    = $params->{'line'};
	my $framePduInfo = $params->{'framePduInfo'};
	my $pduToSearch  = $params->{'pdu'};

	my $pdu_frame = $framePduInfo->{'FRAME_NAME'};
	my $pdu_line;
	my $updateBitSet = 0;

	#ex line: 1.113735 Fr RMSG  0 0 1 1 22 1c Rx 0 e 5  20  681 ORC_CHASSIS_COM_Frame1_ST3 40 40 00 03 f3 2b 00 00 06 1a 88 52 2f 00 00 90 49 28 bf ff 0d 00 00 00 00 ff ff ff ff 00 06 ff ff ff ff ff ff 00 06 ff ff ff ff ff ff 00 06 ff ff 06 17 5d e8 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
	if (
		$frameLine =~ /^(
                \s*(?:\d+\.\d+)			#Timestamp
                \s+(?:Fr)
                \s+(?:RMSG)				#Keyword
                \s+(?:\w+\s+\w+\s+\w+\s+\w+\s+\w+\s+\w+)
                \s+(?:Tx|Rx|TxRq)		#match Rx or Tx or TxRq
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)		#contains at least the update bit information
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)		#Frame state
                \s+(?:[0-9a-f]+)		#CRC header
                \s+)(?:$pdu_frame)		#Framename
                \s+(?:[0-9a-f]+)		#DLC1
                \s+(?:[0-9a-f]+)		#DLC2
                (.*)/ix
	  )
	{
		#Matches: 3702.756816 Fr RMSG  0 0 1 1 8 b Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40
		my $line_data_prefix = $1;

		#Remaining string will have PDU info
		# 00 03 37 80 01 08 c4 f8 f9 00 00 00 00 00 3c 00 01 0e 56 55 55 55 4d ff ff ff ff ff 00 00 00 00 06 00 80 da 7f ff 7f ff ff e0 7f 00 00 00 00 47 8d 07 0a 8b 8e f9 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
		my $remaining_string = $2;
		$line_data_prefix =~ s/RMSG/PDU/;

		$remaining_string =~ s/^\s//;

		my @bytesHexarr = split( /\s+/, $remaining_string );

		#get start bit and length of PDU
		my $startBit = $framePduInfo->{$pdu_frame}{$pduToSearch}{'START-BIT-POSITION'};
		my $length   = $framePduInfo->{$pdu_frame}{$pduToSearch}{'LENGTH_DEC'};

		#Check if Update bit is set
		my $updateBit = $framePduInfo->{$pdu_frame}{$pduToSearch}{'UPDATE-INDICATION-BIT-POSITION'};
		my $offset    = $updateBit % 8;

		#Find exactly which byte we need to convert to binary to verify update bit is set/not(for better performance)
		my $updatebitdata_byte = floor( $updateBit / 8 );

		#Fetch the specific byte where update bit shall be checked, in case 00 03, we need 03 => 0000 0011
		my $updatebitByte = hex( $bytesHexarr[$updatebitdata_byte] );

		# order starts from 7-0, So if update bit is 8 => bit to check is 0, 9 -> bit to check is 1
		# now prepare the mask by shifting bit to relevent position
		# if Update bit is 9, Mast should be 00000010
		# shift left by the $updateBit % 8
		my $one = 1;
		my $bitmask = $offset ? $one << $offset : $one;
		$updateBitSet = 1 if ( $updatebitByte & $bitmask );

		if ($updateBitSet) {
			my $finalPDUdata = [];
			if ( $startBit % 8  == 0 ) {

				#Start bit is multiple of 8
				my $startByte = $startBit / 8;    #starts from 0-7, if bit is 8 => byte to start is 1 , 16 -> byte to start is 3
				push @$finalPDUdata, splice( @bytesHexarr, $startByte, $length );
			}
			else {
				
				#When Start bit is not multiple of 8(This takes little more time than when start bit is not multiple of 8)
				#convert each byte to binary
				my @bytesBinarr = map { sprintf( "%08b", hex($_) ) } @bytesHexarr;

				#create an array of each bits from each binary byte
				my $bitBinarr;
				map { push( @$bitBinarr, split( //, $_ ) ) } @bytesBinarr;
				
				#fetch each byte(8bit) from bitarray from the start bit
				foreach ( 1 .. $length ) {
					my $pduByte = join( '', splice( @$bitBinarr, $startBit, 8 ) );
					
					#Convert fetched byte to hex value
					my $hexData = sprintf( "%02x", oct( "0b" . $pduByte ) );
					push( @$finalPDUdata, $hexData );
				}
			}

			#now prepare the PDU log
			my $pduLengthHex = $framePduInfo->{$pdu_frame}{$pduToSearch}{'LENGTH'};
			$pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex " . join( ' ', @$finalPDUdata ) . "  0  0  0";
		}
		else {
			return;
		}
	}
	return $pdu_line;
}


###############################################################################################################################
=head2 GetPDULineFromFrame

    $pdu_line = GetPDULineFromFrame ( $frameLine, $framePduInfo_href, $pduToSearch)
    
Function to get the PDU log exracted from the frame based log

B<Arguments:>

=over

=item $frameLine

-Line from log file(Frame based)

=item $framePduInfo_href

-Frame information from the Flexray Mapping. Returned from L</"GetFrameInfoForFrameBasedLog">.

=item $pduToSearch

-PDU to be searched in Log

=back

B<Return Value:>

=over

=item $pdu_line 

-PDU line extracted from the frame based log

=back

Called internally by L</"VEC_trace_fr_get_PDU_data">.

=cut

###############################################################################################################################
sub GetPDULineFromFrame {
    my $frameLine    = shift;
    my $framePduInfo = shift;
    my $pduToSearch  = shift;

    my $pdu_frame = $framePduInfo->{'FRAME_NAME'};
    my $pdu_line;

    #ex line: 3702.756816 Fr RMSG  0 0 1 1 8 b Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40 37 80 01 08 c4 f8 f9 00 00 00 00 00 3c 00 01 0e 56 55 55 55 4d ff ff ff ff ff 00 00 00 00 06 00 80 da 7f ff 7f ff ff e0 7f 00 00 00 00 47 8d 07 0a 8b 8e f9 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0

    if (
        $frameLine =~ /^(
                \s*(?:\d+\.\d+)
                \s+(?:Fr)
                \s+(?:RMSG)
                \s+(?:\w+\s+\w+\s+\w+\s+\w+\s+\w+\s+\w+)
                \s+(?:Tx|Rx|TxRq)
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)
                \s+(?:[0-9a-f]+)
                \s+)(?:$pdu_frame)
                \s+(?:[0-9a-f]+)
                \s+(?:[0-9a-f]+)
                (.*)/ix
      )
    {
        #Matches: 3702.756816 Fr RMSG  0 0 1 1 8 b Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40
        my $line_data_prefix = $1;

        #Remaining string will have PDU info
        # 37 80 01 08 c4 f8 f9 00 00 00 00 00 3c 00 01 0e 56 55 55 55 4d ff ff ff ff ff 00 00 00 00 06 00 80 da 7f ff 7f ff ff e0 7f 00 00 00 00 47 8d 07 0a 8b 8e f9 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
        my $remaining_string = $2;
        $line_data_prefix =~ s/RMSG/PDU/;

        my $pduIdToSearch = $framePduInfo->{$pdu_frame}{$pduToSearch}{'ID'};
        my $pduLengthHex  = $framePduInfo->{$pdu_frame}{$pduToSearch}{'LENGTH'};
        my $pduLengthDec  = hex($pduLengthHex);

        if ( $pdu_frame eq $pduToSearch ) {

            # The frame is the PDU: Go ahead with returning the whole frame
            $remaining_string =~ /\s*((..\s){$pduLengthDec})(.*)?/i;
            $pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex $1" . "0  0  0   0\n";
            return $pdu_line;
        }

        #Match with the ID and length : 37 80 01 08 -> Check if how many times this pattern is present ( 37 80 01-ID, 08-Length)
        my $matchedCount = my @match = $remaining_string =~ /\s*$pduIdToSearch\s$pduLengthHex\s/gi;
        return unless $matchedCount;    #return if there is no match found

        if ( $matchedCount == 1 ) {

            #Matched only once -> Go ahead with returning the value
            #Match: 37 80 01 08 c4 f8 f9 00 00 00 00 00
            $remaining_string =~ /\s*$pduIdToSearch\s$pduLengthHex\s((..\s){$pduLengthDec})(.*)?/i;
            $pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex $1" . "0  0  0   0\n";
            return $pdu_line;
        }
        else {

            #Mached more than once -> Find out the proper position of PDU and get info
            my $i       = 0;
            my @pdu_arr = keys %{ $framePduInfo->{$pdu_frame} };
            for ( $i = 0 ; $i < ( scalar @pdu_arr ) ; $i++ ) {
                my $pdu_name      = $pdu_arr[$i];
                my $pdu_info_hash = $framePduInfo->{$pdu_frame}{$pdu_name};
                my $pdu_id        = $pdu_info_hash->{'ID'};
                my $length_hex    = $pdu_info_hash->{'LENGTH'};
                my $length_dec    = hex($length_hex);

                #Get other PDU's present in the FRAME and try to match the remaining string to start with any of these PDUs
                if ( $remaining_string =~ /^\s*$pdu_id\s$length_hex\s((..\s){$length_dec})(.*)?/i ) {
                    $remaining_string = $3;
                    my $data = $1;
                    if ( $pdu_name =~ /^$pduToSearch$/ ) {
                        $pdu_line = $line_data_prefix . "$pduToSearch $length_hex $length_hex $data" . "0  0  0   0\n";
                        last;
                    }
                    @pdu_arr = grep { $_ !~ /^$pdu_name$/ } @pdu_arr;
                    $i = -1;
                }

                #If there is no PDU match Search the PDU pattern in remaining string
                if ( $i == $#pdu_arr ) {

                    #try to find out if the PDU can be found anywhere in the line
                    if ( $remaining_string =~ /\s*$pduIdToSearch\s$pduLengthHex\s((..\s){$pduLengthDec})(.*)?/i ) {
                        $pdu_line = $line_data_prefix . "$pduToSearch $pduLengthHex $pduLengthHex $1" . "0  0  0   0\n";
                        last;
                    }
                }
            }
        }

    }
    return $pdu_line;
}
#####################################################################################################################################################

=head2 GetPDUInfoFromLog

    $pduInfoHref = GetPDUInfoFromLog ( $pdu_line, $pduToSearch, $fr_bus_nbr)
    
Function to get the matched PDU data such as CRC,DLC1,DLC2 and timing information from the PDU based log

B<Arguments:>

=over

=item $pdu_line

-PDU log line to be matched against PDU regex

=item $pduToSearch

-PDU to be searched from log line.

=item $fr_bus_nbr

-FlexRay bus number where the PDU to be matched

=back

B<Return Value:>

=over

=item $pduInfoHref 

-Hash reference of data such as CRC,DLC1,DLC2 and timing information from the PDU based log

=back

Called internally by L</"VEC_trace_fr_get_PDU_data">.

=cut

#####################################################################################################################################################
sub GetPDUInfoFromLog {
    my $pdu_line    = shift;
    my $pduToSearch = shift;
    my $fr_bus_nbr  = shift;

    my $pduInfoHref;

    ## try to match PDU based logfile:
    ##      timestamp    Bus    keyword   frame information?        Tx/Rx info     ????????????   Frame state      HEADER_CRC     PDU_name  DLC_1   DLC_2   DATA (DLC_1 bytes)    ????????????????????
    ##      0.038955     Fr     PDU       0 0 1 1 19 26             Rx             0 438002 5     20               3a6            FD_ESP    1       1       00                    b980d5  1  43125  32
    # 438002
    # 0100001110000000000010
    #       ^
    if (
        $pdu_line =~ /^
            \s*        
          (\d+\.\d+)  # Timestamp
            \s+        
           (?:$fr_bus_nbr) # Bus ID
            \s+        
          (?:PDU)        # Keyword
            \s+        
(\w+\s+\w+\s+\w+\s+\w+\s+\w+\s+\w+)  #what is it:timing info???
            \s+        
          (?:Tx|Rx|TxRq)      # match Rx or Tx or TxRq
            \s+        
(?:\d+)    # what is it:info???
            \s+
          ([0-9a-f]+)       # contains at least the update bit information
            \s+
(?:\d+)     # what is it:info???
            \s+        
          [0-9a-f]+                     # Frame state: not useful
            \s+        
          ([0-9a-f]+)                   # CRC header
            \s+        
          (?:$pduToSearch)                   # searched PDU
            \s+        
          ([0-9a-f]+)                   # DLC 1
            \s+        
          ([0-9a-f]+)                   # DLC 2
            \s+
          (([0-9a-f]{2}(\s))*[0-9a-f]{2}) # DATA
            \s+
          .+$       # all Data until end of line
          /ix
      )
    {
        $pduInfoHref->{'BIN'}  = $3;
        $pduInfoHref->{'TIME'} = $1;
        $pduInfoHref->{'CRC'}  = $4;
        $pduInfoHref->{'DLC1'} = hex($5);
        $pduInfoHref->{'DLC2'} = hex($6);
        $pduInfoHref->{'DATA'} = $7;
    }
    return $pduInfoHref;
}

1;
__END__


=head1 AUTHORS

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Archana GopalaKrishna, E<lt>Archana.Gopalakrishna@in.bosch.comE<gt>

=head1 NOTES

The "BEGIN" section contains the Statements which to be executed before the start of program execution

=head1 SEE ALSO

perl documentation

=cut
