package LIFT_TRAVELLOGIC;

use strict;
use warnings;

use File::Basename;
use Cwd 'abs_path';
use File::Basename;
my $addpath;

BEGIN
{
	use LIFT_general;
	S_add_paths2INC(['./Win32'], ['./Win32']);
}

use TRAVELLOGIC;
require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_TRAVELLOGIC ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  TL_End
  TL_DumpData
  TL_Start
  TL_Capture
  TL_decode
);


my ( $status, %label2pin );
my $TL_initialized = 0;

=head1 NAME

LIFT_TRAVELLOGIC 

Perl extension for ACUTE TRAVELLOGIC logic analyzer

=head1 SYNOPSIS

    use LIFT_TRAVELLOGIC;

    TL_Start();
    TL_Capture('02_MOSI1_12','rising',['00_MISO1_9','01_CLK1_11','02_MOSI1_12','03_CS6in_25','04_FR_25','05_CAN'], 'TR8');
    sleep(1);
    TL_DumpData("$log_path/dump.txt.unv", ['00_MISO1_9','01_CLK1_11','02_MOSI1_12','03_CS6in_25','04_FR_25','05_CAN'] );
    TL_decode("$log_path/dump.txt.unv",['03_CS6in_25'],'00_MISO1_9','02_MOSI1_12','01_CLK1_11','04_FR_25',[18],'05_CAN',[64]);
    TL_End();

    ProjectConst:
    'TRAVELLOGIC' => {
                        '00_MISO1_9'  => 0,
                        '01_CLK1_11'  => 1,
                        '02_MOSI1_12' => 2,
                        '03_CS6in_25' => 3,
                        '04_FR_25'    => 4,
                        '05_CAN'      => 5,
                       },


=head1 DESCRIPTION

remote control functions for ACUTE TRAVELLOGIC logic analyzer

=cut

=head2 TL_End

 $status = TL_End();

close application, should be called in End Campaign

=cut

sub TL_End
{
    unless ($TL_initialized)
    {
        S_set_error( "TL not initialized", 120 );
        return 0;
    }
    if ($main::opt_offline)
    {
        $TL_initialized = 0;
        return 1;
    }

    $status = tl_Shutdown();
    check_status($status);
    S_w2log( 5, "($status) TL_End\n" );

    $TL_initialized = 0;

    S_w2log( 4, "TL_End: Closed the application \n" );
}

=head2 TL_DumpData

    TL_DumpData($filename,$Names_aref)

    e.g.  TL_DumpData( "dump.txt.unv", ['00_MISO1_9','01_CLK1_11','02_MOSI1_12','03_CS6in_25','04_FR_25','05_CAN'] );

dump pins in uniview format (you have to give .txt.unv as file extension)

=cut

sub TL_DumpData
{
    my $filename   = shift;
    my $Names_aref = shift;
    my ( $name, $pin );

    unless ( defined($Names_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: TL_DumpData( \$filename, \$Names_aref )", 110 );
        return 0;
    }

    #check $Pins_aref for undef elements and aref
    if ( S_check_array( $Names_aref, "\$Names_aref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    unless (@$Names_aref)
    {
        S_set_error( " Names_aref is empty", 114 );
        return 0;
    }
    my @pins = ();
    foreach $name (@$Names_aref)
    {
        #map pin if necessary
        if ( not defined( $pin = $label2pin{$name} ) )
        {
            unless ( $name =~ /^\d+$/ )
            {
                S_set_error( "Pin Mapping for \"$name\" is not found in Project Constants and also, \"$name\" is not a valid number", 114 );
                return 0;
            }
            $pin = $name;
        }
        else
        {
            unless ( $pin =~ /^\d+$/ )
            {
                S_set_error( "The Pin \"$pin\" found for \"$name\" in Project Constants is not a valid number", 20 );
                return 0;
            }
        }
        push( @pins, $pin );
    }

    unless ($TL_initialized)
    {
        S_set_error( "TL not initialized", 120 );
        return 0;
    }

    unless ( $filename =~ m/\.txt\.unv$/ )
    {
        S_set_error( "filename $filename does not end with .txt.unv", 114 );
    }

    S_w2log( 5, "TL_DumpData\n" );

    if ($main::opt_offline)
    {
        S_create_dummy_file($filename);
        return 1;
    }

    $status = tl_Dump( $filename, \@pins, $Names_aref );
    check_status($status);
    S_w2log( 5, "tl_Dump status ($status)\n" );

    S_w2log( 4, "TL_DumpData: Dumped data to file $filename \n" );
}

=head2 TL_Start

 $status = TL_Start();

start application, will read name2pin mapping form ProjectConst

    ProjectConst:
    'TRAVELLOGIC' => {
                        '00_MISO1_9'  => 0,
                        '01_CLK1_11'  => 1,
                        '02_MOSI1_12' => 2,
                        '03_CS6in_25' => 3,
                        '04_FR_25'    => 4,
                        '05_CAN'      => 5,
                       },


=cut

sub TL_Start
{
    my ( $name, $num );
    my ( %pins, $pin );

    S_w2log( 4, "TL_Start: Starts the application \n" );

    if ( not defined( $main::ProjectDefaults->{'TRAVELLOGIC'} ) )
    {
        S_set_error( "No TRAVELLOGIC settings found in Project Constants", 20 );
        return [0];
    }

    %label2pin = %{ $main::ProjectDefaults->{'TRAVELLOGIC'} };

    #check if each pin is listed only once
    foreach $pin ( sort keys %label2pin )
    {
        if ( exists $pins{$pin} )
        {
            S_set_error( " Pin $pin listed twice in ProjectConst", 114 );
            return 0;
        }
        else
        {
            $pins{$pin} = 1;
        }

    }

    if ($TL_initialized)
    {
        S_set_error( "TL already initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $TL_initialized = 1;
        return 1;
    }

    S_w2log( 5, "TL PM-" . tl_getPMrevision() . " XS-" . tl_getXSrevision() . " CW-" . tl_getCWrevision() . "\n" );
    $status = tl_Start();
    check_status($status);
    $status = tl_Init();
    check_status($status);

    $status = tl_Threshold( 0, 1600 );    # 1.6V (TTL)
    check_status($status);
    $status = tl_Threshold( 1, 1600 );    # 1.6V (TTL)
    check_status($status);
    $status = tl_Threshold( 2, 1600 );    # 1.6V (TTL)
    check_status($status);
    $status = tl_Threshold( 3, 1600 );    # 1.6V (TTL)
    check_status($status);

    ($num) = tl_GetHwInfo(0);

    ( $status, $name ) = tl_GetModelName();
    check_status($status);

    if ( $status < 0 )
    {
        S_set_error( "could not initialize TL", 5 );
        $TL_initialized = 0;
    }

    $TL_initialized = 1;
    S_w2log( 4, "TL_Start: TL ($name) application started \n" );
}

=head2 TL_Capture

 TL_Capture( $trigger_pin, $trigger_edge, $Pins_aref, $mode );

    e.g.
    TL_Capture('02_MOSI1_12','rising',[ '00_MISO1_9','01_CLK1_11','02_MOSI1_12','03_CS6in_25','04_FR_25','05_CAN', ], 'TR8');

    trigger_pin, Pins_aref: names from ProjectConst mapping
    trigger_edge: falling or rising
    mode: TR36 or TR8

    ProjectConst:
    'TRAVELLOGIC' => {
                        '00_MISO1_9'  => 0,
                        '01_CLK1_11'  => 1,
                        '02_MOSI1_12' => 2,
                        '03_CS6in_25' => 3,
                        '04_FR_25'    => 4,
                        '05_CAN'      => 5,
                       },

start measurement

=cut

sub TL_Capture
{
    my ( $trigger_pin, $trigger_edge, $Pins_aref, $mode ) = @_;
    my ( $pin, $name );

    unless ( defined($mode) )
    {
        S_set_error( "! too less parameters ! SYNTAX: TL_Capture( \$trigger_pin, \$trigger_edge, \$Pins_aref, \$mode )", 110 );
        return 0;
    }

    #check $Pins_aref for undef elements and aref
    if ( S_check_array( $Pins_aref, "\$Pins_aref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    unless (@$Pins_aref)
    {
        S_set_error( " data_aref is empty", 114 );
        return 0;
    }

    my @pins = ();
    foreach $name (@$Pins_aref)
    {
        #map pin if necessary
        if ( not defined( $pin = $label2pin{$name} ) )
        {
            unless ( $name =~ /^\d+$/ )
            {
                S_set_error( "Pin Mapping for \"$name\" is not found in Project Constants and also, \"$name\" is not a valid number", 114 );
                return 0;
            }
            $pin = $name;
        }
        else
        {
            unless ( $pin =~ /^\d+$/ )
            {
                S_set_error( "The Pin \"$pin\" found for \"$name\" in Project Constants is not a valid number", 20 );
                return 0;
            }
        }
        push( @pins, $pin );
    }

    #map trigger_pin if necessary
    if ( not defined( $pin = $label2pin{$trigger_pin} ) )
    {
        unless ( $trigger_pin =~ /^\d+$/ )
        {
            S_set_error( "Pin Mapping for \"$trigger_pin\" is not found in Project Constants and also, \"$trigger_pin\" is not a valid number", 114 );
            return 0;
        }
    }
    else
    {
        unless ( $pin =~ /^\d+$/ )
        {
            S_set_error( "The Pin \"$pin\" found for \"$trigger_pin\" in Project Constants is not a valid number", 20 );
            return 0;
        }
        $trigger_pin = $pin;
    }

    if ( $mode eq 'TR36' )
    {
        $mode = 510;
    }
    elsif ( $mode eq 'TR8' )
    {
        $mode = 511;
    }
    else
    {
        S_set_error( " mode $mode unknown/not supported", 114 );
    }

    if ( $trigger_edge eq 'falling' or $trigger_edge eq '0' )
    {
        $trigger_edge = 0;
    }
    elsif ( $trigger_edge eq 'rising' or $trigger_edge eq '1' )
    {
        $trigger_edge = 1;
    }
    else
    {
        S_set_error( " trigger_edge $trigger_edge unknown/not supported", 114 );
    }

    unless ($TL_initialized)
    {
        S_set_error( "TL not initialized", 120 );
        return 0;
    }

    S_w2log( 4, "TL_Capture\n" );
    return 1 if $main::opt_offline;

    $status = tl_Capture( $trigger_pin, $trigger_edge, \@pins, $mode );
    check_status($status);
    S_w2log( 4, "TL_Capture status ($status) \n" );
}

=head2 TL_decode

    TL_decode( $infile, \@CS_pins, $MISO_pin, $MOSI_pin, $CLK_pin, $FR_pin, \@FR_IDs, $CAN_pin, \@CAN_IDs );

    e.g. TL_decode('decode_test.txt.unv',['11_CS6in_25'],'2_MISO1_9','05_MOSI1_12','04_CLK1_11',0,[0],0,[0]);
         TL_decode('dump.txt.unv',['12_CS6in_25'],'2_MISO1_9','05_MOSI1_12','04_CLK1_11','13_CS7in_25',[18],'14_CAN',[64]);

    to suppress FR/CAN decoding set $FR_pin/$CAN_pin to 0
    to suppress SPI decoding leave @CS_pins empty

    FR_IDs and CAN_IDs in decimal !

    file example.txt.unv with heading
      TIME;00_MISO1_9;01_CLK1_11;02_MOSI1_12;03_CS6in_25;04_FR_25;05_QTtrig
    decoded with
      TL_decode('example.txt.unv',['03_CS6in_25'],'00_MISO1_9','02_MOSI1_12','01_CLK1_11','04_FR_25',[18],0,[0]);
    will create files
      decoded_FR_04_FR_25.csv
      decoded_FR_04_FR_25.txt
      decoded_SPI_03_CS6in_25.csv
      decoded_SPI_03_CS6in_25.txt

    hard coded settings:
    $CANbaudrate = 500000;
    $CANIDlength = 11;
    $FRbaudrate = 10000000;

 infile = .unv file
 Timestamp in ms
 @CS_pins, $MISO_pin, $MOSI_pin, $CLK_pin, $FR_pin, $CAN_pin = signal name from uniview file

 CAN has to be taken from Tx pin of CAN traceiver to get proper levels

will create $infile folder with decoded files

=cut

sub TL_decode
{
    my ( $infile, $CS_ref, $MISO_pin, $MOSI_pin, $CLK_pin, $FR_pin, $FR_ref, $CAN_pin, $CAN_ref ) = @_;

    unless ( defined($CAN_ref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: TL_decode( \$infile, \$CS_pins_aref, \$MISO_pin, \$MOSI_pin, \$CLK_pin, \$FR_pin, \$FR_IDs_aref, $CAN_pin, \$CAN_IDs_aref )", 110 );
        return 0;
    }

    #check for undef elements and aref
    if ( S_check_array( $CS_ref, "\$CS_ref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }
    if ( S_check_array( $FR_ref, "\$FR_ref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }
    if ( S_check_array( $CAN_ref, "\$CAN_ref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    unless ($TL_initialized)
    {
        S_set_error( "TL not initialized", 120 );
        return 0;
    }

    unless ( $infile =~ m/\.txt\.unv$/ )
    {
        S_set_error( "filename $infile does not end with .txt.unv", 114 );
    }
    S_w2log( 4, "TL_decode\n" );

    # create dummy files in offline mode
    if ($main::opt_offline)
    {
        my $oputpath = $infile;
        $oputpath = abs_path( dirname($oputpath) ) . '/' . basename($oputpath);
        $oputpath =~ s/\//\\/g;           # replace all slashes with backslashes
        $oputpath =~ s/\.txt\.unv+$//;    #remove extension
        unless ( -d $oputpath )
        {
            system("mkdir $oputpath");
        }
        my $CANOUT = "$oputpath/decoded_CAN_$CAN_pin";
        my $FROUT  = "$oputpath/decoded_FR_$FR_pin";
        S_create_dummy_file("$CANOUT.txt");
        S_create_dummy_file("$CANOUT.csv");
        S_create_dummy_file("$FROUT.txt");
        S_create_dummy_file("$FROUT.csv");

        foreach (@$CS_ref)
        {
            my $SPIOUT = "$oputpath/decoded_SPI_" . $_;
            S_create_dummy_file("$SPIOUT.txt");
            S_create_dummy_file("$SPIOUT.csv");
        }
        return 1;
    }

    $status = tl_decode( $infile, $CS_ref, $MISO_pin, $MOSI_pin, $CLK_pin, $FR_pin, $FR_ref, $CAN_pin, $CAN_ref );
    check_status($status);
    S_w2log( 4, "TL_decode status($status)\n" );

}

=head1 not exported functions

=head2 check_status

 check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub check_status
{
    my $status = shift;

    return 1 if $main::opt_offline;
    if ( $status < 0 )
    {
        #my $errortext = TL_GetLastError();
        my $errortext = "TRAVELLOGIC error occured";
        S_set_error( "ATL ($status): $errortext", 5 );

    }

}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, ACUTE TRAVELLOGIC logic analyzer manual.

=cut
