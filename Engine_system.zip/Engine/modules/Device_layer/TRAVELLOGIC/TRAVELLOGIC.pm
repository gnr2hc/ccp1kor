package TRAVELLOGIC;

use strict;
use warnings;
use Cwd 'abs_path';
use File::Basename;
use FileHandle;

require Exporter;
require DynaLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use TRAVELLOGIC ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
    tl_getPMrevision
    tl_getXSrevision
    tl_getCWrevision
    tl_Init
    tl_Shutdown
    tl_GetHwInfo
    tl_Start
    tl_GetModelName
    tl_Capture
    tl_Threshold
    tl_SetHwInfo
    tl_Dump
    tl_decode
);
our $VERSION = '0.01';

bootstrap TRAVELLOGIC $VERSION;

# Preloaded methods go here.

sub tl_getPMrevision{
    return ('SCM');
}

sub tl_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub tl_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

=head2  tl_decode()

    tl_decode( $infile, \@CS_pins, $MISO_pin, $MOSI_pin, $CLK_pin, $FR_pin, \@FR_IDs, $CAN_pin, \@CAN_IDs );

    e.g. tl_decode('decode_test.txt.unv',['11_CS6in_25'],'2_MISO1_9','05_MOSI1_12','04_CLK1_11',0,[0],0,[0]); # no CAN, no FR
         tl_decode('dump.txt.unv',['12_CS6in_25'],'2_MISO1_9','05_MOSI1_12','04_CLK1_11','13_CS7in_25',[18],'14_CAN',[64]);

    to suppress FR/CAN decoding set $FR_pin/$CAN_pin to 0 

    FR_IDs and CAN_IDs in decimal !

    hard coded settings:
    $CANbaudrate = 500000;
    $CANIDlength = 11;
    $FRbaudrate = 10000000;

    file example.txt.unv with heading
      TIME;00_MISO1_9;01_CLK1_11;02_MOSI1_12;03_CS6in_25;04_FR_25;05_QTtrig
    decoded with
      tl_decode('example.txt.unv',['03_CS6in_25'],'00_MISO1_9','02_MOSI1_12','01_CLK1_11','04_FR_25',[18],0,[0]);
    will create files
      decoded_FR_04_FR_25.csv
      decoded_FR_04_FR_25.txt
      decoded_SPI_03_CS6in_25.csv
      decoded_SPI_03_CS6in_25.txt

    infile = .unv file
    Timestamp in ms

    @CS_pins, $MISO_pin, $MOSI_pin, $CLK_pin, $FR_pin, $CAN_pin = signal name from uniview file 

    CAN has to be taken from Tx pin of CAN traceiver to get proper levels

will create folder with decoded files 

=cut

sub tl_decode{

my $CANbaudrate=500000;
my $IDlength = 11;
my $FRbaudrate=10000000;

my $FRbittime = 1000.0/$FRbaudrate;
my $CANbittime =1000.0/$CANbaudrate;

    my $INFILE = shift;
    # get full path
    $INFILE = abs_path(dirname($INFILE)).'/'.basename($INFILE);
    $INFILE =~ s/\//\\/g; # replace all slashes with backslashes
    my $CS_ref= shift;
    my @CS_pin= @$CS_ref;

    my $MISO_pin=shift;
    my $MOSI_pin=shift;
    my $CLK_pin=shift;
    my $FR_pin=shift;
    my $FRID_ref= shift;
    my @FR_filter_IDs= @$FRID_ref;
    my $CAN_pin=shift;
    my $CANID_ref= shift;
    my @CAN_filter_IDs= @$CANID_ref;

    my @CS_label = @CS_pin;
    my $FR_label = $FR_pin;
    my $CAN_label = $CAN_pin;
    
    my $oputpath=$INFILE;
    $oputpath=~ s/\.\S+$//; #remove extension

    unless (-d $oputpath) {
        system( "mkdir $oputpath"); 
    }
    my (@CSV,@FH,@CS_Curr,@CS_Prev, @Start, @Stop, @Clk_Prev);
    my $count;

    my ($Clk_Curr,$Mosi_Curr,$Miso_Curr,@MOSI,@MISO);
    my $Mosi_Cmd=0; 
    my $Miso_Cmd=0;
    my ($line,@value,$Timestamp,$lastmessagetime,$messagetime);

    my ($CAN_Curr,@framebits,$CANframe);
    my $CANlastvalue=5; # not 0 or 1, so next bit will update value
    my $CANlasttime=0;
    my ($FR_Curr,@FRbits,$FRframe,$FRmessagetime);
    my $FRlastvalue=5; # not 0 or 1, so next bit will update value
    my $FRlasttime=0;
    my $TSScount=0;
    my $TSSflag=0;

    my $stuffbit_expected = 0;

    $lastmessagetime=$messagetime= 0;
    @CSV=@FH=@CS_Curr=@CS_Prev=@Start=@Stop=@Clk_Prev=@FRbits=@framebits=@MOSI=@MISO=();

    open(INFILE,"<$INFILE") or die("Could not open file.");

    # skip first two lines and extract names
    # TIME;PIN_2;PIN_3;PIN_4;PIN_5;PIN_11;PIN_13;PIN_10
    # ms;-;-;-;-;-;-;-

    $line=<INFILE>;
    chomp $line; # remove newline
    my @name = split(/;/,$line);
    shift(@name); # drop TIME
    <INFILE>; # skip ms line

    #map names to array index
    my %names;
    for($count=0;$count<scalar(@name);$count++){
        $names{$name[$count]} = $count;
    }    

    $CLK_pin = $names{$CLK_pin} if defined $names{$CLK_pin};  
    $MOSI_pin = $names{$MOSI_pin} if defined $names{$MOSI_pin};  
    $MISO_pin = $names{$MISO_pin} if defined $names{$MISO_pin};  
    $CAN_pin = $names{$CAN_pin} if defined $names{$CAN_pin};  
    $FR_pin = $names{$FR_pin} if defined $names{$FR_pin};  
    _check_number($CLK_pin) or die "ERROR: CLK_pin $CLK_pin is not a number";
    _check_number($MOSI_pin) or die "ERROR: MOSI_pin $MOSI_pin is not a number";
    _check_number($MISO_pin) or die "ERROR: MISO_pin $MISO_pin is not a number";
    _check_number($CAN_pin) or die "ERROR: CAN_pin $CAN_pin is not a number";
    _check_number($FR_pin) or die "ERROR: FR_pin $FR_pin is not a number";
    foreach (@CS_pin){
        $_= $names{$_} if defined $names{$_};  
        _check_number($_) or die "ERROR: CS $_ is not a number";
    }

    my $CANOUT = "$oputpath/decoded_CAN_$CAN_label";
    my $FROUT  = "$oputpath/decoded_FR_$FR_label";

    for($count=0;$count<scalar(@CS_pin);$count++){
        $CS_Prev[$count]=0;
        $Clk_Prev[$count]=0;
        @{$MOSI[$count]}=();
        @{$MISO[$count]}=();

        my $SPIOUT="$oputpath/decoded_SPI_".$CS_label[$count];
        print"\n... writing to $SPIOUT\n";

        $FH[$count] = FileHandle->new("> $SPIOUT.txt") or die "$SPIOUT: $!";
        $FH[$count]->printf ("%10s\t%64s\t%64s\n",'Timestamp_ms','MOSI','MISO');
        $CSV[$count] = FileHandle->new("> $SPIOUT.csv") or die "$SPIOUT: $!";
        $CSV[$count]->printf ("Timestamp_ms;MOSI bin;MISO bin;MOSI hex;MISO hex\n");
    }

    if($CAN_pin > 0){
        print"\n... writing to $CANOUT  (bittime is $CANbittime ms)\n";
        open(CANOUT,">$CANOUT.txt") or die("Could not open file.");
        open(CANDEBUG,">$oputpath/CAN_debug.txt") or die("Could not open file.");
        print CANOUT sprintf("%10s\t%5s %2s %22s  %s %s",'Timestamp_ms',"ID","DLC","hex DATA","- ACK","EOF bits"),"\n";
        open(CANCSV,">$CANOUT.csv") or die("Could not open file.");
        print CANCSV "Timestamp_ms;CAN_ID;payload\n";
    }
    if($FR_pin > 0){
        print"\n... writing to $FROUT (bittime is $FRbittime ms)\n";
        open(FROUT,">$FROUT.txt") or die("Could not open file.");
        print FROUT sprintf("%10s\t%4s %4s %4s %s - %s -",'Timestamp_ms',"ID","cyc","len","iBits","DATA (hex)"),"\n";
        open(FRCSV,">$FROUT.csv") or die("Could not open file.");
        print FRCSV "Timestamp_ms;FR_ID;payload\n";
    }



    while ($line=<INFILE>) 
    {

        #line e.g.: 0.000000;0;0;0;1;0;0;0
        chomp($line); # drop newline
        @value = split(/;/,$line);
        $Timestamp = shift(@value);

        $Clk_Curr  = $value[$CLK_pin];   
        $Mosi_Curr = $value[$MOSI_pin]; 
        $Miso_Curr = $value[$MISO_pin];    
        $CAN_Curr  = $value[$CAN_pin];    
        $FR_Curr   = $value[$FR_pin];    

        #loop over all given chip selects and store corresponding values in arrays
        for($count=0;$count<scalar(@CS_pin);$count++){
            $CS_Curr[$count]   = $value[$CS_pin[$count]];     

            if(($CS_Prev[$count] == 1) && ($CS_Curr[$count]==0)){
                $Start[$count]=1;
                $Stop[$count]=0;
            }

            if(($CS_Prev[$count] ==0)&&($CS_Curr[$count]==1)){
                $Start[$count]=0;
                $Stop[$count]=1;
            }

            $CS_Prev[$count] =$CS_Curr[$count];

            if($Start[$count]){
                if((($Clk_Prev[$count]==0) &&($Clk_Curr==1))||(($Clk_Prev[$count]==1) &&($Clk_Curr==0))){
                    if($Clk_Curr==0){
                        push(@{$MOSI[$count]},$Mosi_Curr);
                        push(@{$MISO[$count]},$Miso_Curr);
                    }
                    $Clk_Prev[$count]=$Clk_Curr;
                }
            }
            elsif($Stop[$count] and scalar(@{$MOSI[$count]})> 0 ){         
                    $Mosi_Cmd = join('',@{$MOSI[$count]});
                    $Miso_Cmd = join('',@{$MISO[$count]});
                    $FH[$count]->printf ("%012.6f\t%64s\t%64s\n",$Timestamp,$Mosi_Cmd,$Miso_Cmd);
                    my $XLtime = $Timestamp;

###                    $XLtime =~ s/\./,/;

                    ## example taken form perlmonks.org: 
                    ## How can I split a string into chunks of size n bytes?        
                    ## my $string = "1234567890abcdefghijABCDEFGHIJK";
                    ## my $n = 2;    # $n is group size.
                    ## my @groups = unpack "a$n" x (length( $string ) /$n ), $string;
                    my @MOSI_bytes = unpack "a8" x (length( $Mosi_Cmd ) /8 ), $Mosi_Cmd;
                    my $Mosi_Bin = join(' ',@MOSI_bytes);
                    foreach my $byte (@MOSI_bytes){
                        $byte = sprintf ("%02X",oct('0b'.$byte));
                    }
                    my $Mosi_Hex = join(' ',@MOSI_bytes);

                    my @MISO_bytes = unpack "a8" x (length( $Miso_Cmd ) /8 ), $Miso_Cmd;
                    my $Miso_Bin = join(' ',@MISO_bytes);
                    foreach my $byte (@MISO_bytes){
                        $byte = sprintf ("%02X",oct('0b'.$byte));
                    }
                    my $Miso_Hex = join(' ',@MISO_bytes);

                    $CSV[$count]->print ("$XLtime;$Mosi_Bin;$Miso_Bin;$Mosi_Hex;$Miso_Hex\n");
                    
                    @{$MOSI[$count]}=();
                    @{$MISO[$count]}=();

                    $Stop[$count]=0;
              }
        }


        if($FR_pin > 0){
         print FROUT "ERROR: timewarp $Timestamp < $FRlasttime !!!\n" if ($Timestamp < $FRlasttime and $FRlasttime>0);
            if($FR_Curr != $FRlastvalue){

                    #check for TSS (more than 2 bits 0 after CID)  
                    # this will match DTS (dynamic trailing sequence) sometimes, too !
                    # so only first TSS timestamp will be taken
                    if ($Timestamp-$FRlasttime>=3*$FRbittime and $FRlastvalue == 0 and $TSSflag == 0){
                        # disable TSS flag and skip copying of bits
      #     print FROUT "got TSS at $Timestamp\n";
                            $TSSflag = 1;
                    }



                    #check for CID (more than 10 bits 1)
                    elsif ($Timestamp-$FRlasttime>10*$FRbittime and $FRlastvalue == 1){
     #    print FROUT "got CID at $Timestamp\n";

                        $TSSflag = 0; # enable next TSS

                        if (scalar(@FRbits) > 53 ){

     #    print FROUT "FRbits =  @FRbits\n";
                            # get timestamp from last bit before CID
                            $FRmessagetime=$FRlasttime;

                            # extract 5 byte header
                            my @FRheader = ();
                            #drop leading FS and BSS (3 bits)
                            splice(@FRbits,0,3);
                            foreach (1..5){
                                #move 8 bits
                                push(@FRheader, splice(@FRbits,0,8));
                                #drop leading BSS (2 bits)
                                splice(@FRbits,0,2);
                            }

                            #cut header in pieces and convert to decimal
                            my $indiBits = join('','0b',splice(@FRheader,0,5));
                            my $FR_ID = oct(join('','0b',splice(@FRheader,0,11)));
                            my $FR_len = oct(join('','0b',splice(@FRheader,0,7))) * 2; # convert words to bytes
                            my $FR_CRC = join('','0b',splice(@FRheader,0,11));
                            my $FR_cycle = oct(join('','0b',splice(@FRheader,0,6)));

                            print FROUT "ERROR: header length error !!!\n" if (scalar(@FRheader) > 0);


                            # extract $FR_len bytes data, if no nullframe
                            my @FRdata = ();
                            if ( (oct($indiBits) & 0b100) != 0){
                                foreach (1..$FR_len){
                                    #move 8 bits
                                    push(@FRdata, sprintf("%02X",oct(join('','0b',splice(@FRbits,0,8))))); #hex
        #                            push(@FRdata, oct(join('','0b',splice(@FRbits,0,8)))); #dec
                                    #drop leading BSS (2 bits)
                                    splice(@FRbits,0,2);
                                }
                            }

                            print FROUT sprintf("%012.6f\t%4d %4d %4d %s - %s - ", $FRmessagetime, $FR_ID, $FR_cycle, $FR_len, $indiBits, join(' ',@FRdata)),"\n";

                            foreach my $filter_ID (@FR_filter_IDs){
                                print FRCSV "$FRmessagetime;$FR_ID;@FRdata\n" if ($FR_ID eq $filter_ID);
                            }

                        }
                        # empty array for next frame
                        @FRbits=();
                    }
                    else{
                        my $bitcount=sprintf("%d",(($Timestamp-$FRlasttime) / $FRbittime +0.5) ); # round bits for error correction
      #    print FROUT "$FRlasttime  $FRlastvalue bitcount =  $bitcount (".(($Timestamp-$FRlasttime) / $FRbittime).") dt ".($Timestamp-$FRlasttime)."\n";
                        push(@FRbits,($FRlastvalue) x $bitcount ) if ($FRlastvalue != 5);
                    }
                $FRlasttime=$Timestamp;
                $FRlastvalue=$FR_Curr;
            }

        } #endif($flexraydecode_flag)





        if($CAN_pin > 0){
         print CANDEBUG "ERROR: timewarp $Timestamp < $CANlasttime !!!\n" if ($Timestamp < $CANlasttime and $CANlasttime>0);

            if($CAN_Curr != $CANlastvalue){


                if ($CANlasttime>0){


                    #check for IFS (more than 10 times 1)
                    if ($Timestamp-$CANlasttime>10*$CANbittime){

                        if ($CANlastvalue != 1){
                            print CANDEBUG "ERROR: too many zeroes without stuffing !!!\n";
                        }

        # print CANDEBUG "d IFS = ".(($Timestamp-$CANlasttime))." x 1  cl $CANlasttime\n";

                        #frame has leading SOF!
                        my $ID='';
                        my $DLC=0;
                        my ($Flastbit,$Fbitcount,$x);
                        $Fbitcount=0;
                        $Flastbit=3;
                        $stuffbit_expected = 0;
                        my $header='';
                        for($x=0;$x<scalar(@framebits);$x++){
                            if ($stuffbit_expected){
                                #replace first bit with nothing to avoid deletion of multibit pattern
                                #because @framebits may contain several bytes !
                                unless ($DLC>0 and length($header)>1+$IDlength+1+6+$DLC*8+15){
                                $framebits[$x] =~ s/^\d/-/;
        # print CANDEBUG "stuff ".length($header)."\n";
                                }
                                if (length($framebits[$x]) >= 5){
                                    $stuffbit_expected = 1;
                                }
                                else{$stuffbit_expected = 0;}
                            }
                            elsif (length($framebits[$x]) == 5){
                                $stuffbit_expected = 1;
                           }
                            elsif (length($framebits[$x]) > 5 and length($header)<1+$IDlength+1+6+$DLC*8+15){
                                $stuffbit_expected = 1;
                                print CANDEBUG "ERROR: more than 5 bits $framebits[$x] with same value : $header\n";
                           }
                           $header .= $framebits[$x];
                           $header=~ s/-//g; # drop stuffbit markers
                           #extrcat DLC if > SOF+ID+RTR+CTRL
                           if (length($header)>=$IDlength+1+1+6){
                            $header =~ /^\d(\d{$IDlength})\d\d{2}(\d{4})/;
                            $ID=oct('0b'.$1);
                            $DLC=oct('0b'.$2);
                           }
                        }

                        # add dummy IFS at end of frame to set default ACK and EOF, 
                        #if all is ok there will be only 1s which can not be distinguished from normal IFS -> therefore the dummy
                        #if there was a problem (at least one 0) the bits were collected and the dummy is just concatinated which will not be evaluated ...
                       push(@framebits,1 x 30 );  

        printf CANDEBUG ("store frame 0x%X $DLC\n", $ID);
                        my $datalen = $DLC*8;
                        my ($ACK,$EOF,$DATA,@rest);
                        $ACK=$EOF=0;
                        $DATA='';
                        $CANframe=join('',@framebits);
       # print CANDEBUG sprintf("%09d %s",$CANlasttime,$CANframe),"\n";
                        $CANframe=~ s/-//g; # drop stuffbit markers
       # print CANDEBUG "IDlength $IDlength  datalen $datalen $CANframe\n";
       # print CANDEBUG "framelength ".length($CANframe)." req1 = ".($IDlength+8+$datalen+18+7)." req2 = ".($IDlength+8+18+7)."\n";
                        if ( $CANframe =~ /^(\d)(\d{$IDlength})(\d)(\d{2})(\d{4})(\d{$datalen})(\d{15})(\d)(\d{2})(\d{7})/ ){
       # print CANDEBUG sprintf("%012.6f $1.$2.$3.$4.$5.$6.$7.$8.$9.$10",($CANlasttime)),"\n";
        print CANDEBUG sprintf("%012.6f SOF $1 ID $2 RTR $3 r10 $4 DLC $5 data $6 CRC $7 crcD $8 ACK $9 EOF $10",($CANlasttime)),"\n";
                            @rest = unpack ("a8" x $DLC ,$6);
                            $ACK = $9;
                            $EOF = $10;

                            foreach (@rest){
                             $DATA .= " ".sprintf("%02X",oct('0b'.$_))
                            }
                        }
                        else{
                            print CANDEBUG "something wrong in $CANframe\n";
                        }
                        #drop leading SOF

         # print CANDEBUG "store frame $CANlasttime $CANframe\n";

                        $messagetime=$CANlasttime;


                       #store frame
                       if ($ACK eq '11'){
                            print CANDEBUG sprintf("%012.6f\t%15s %2s %24s - %s %s",$messagetime,$ID,$DLC,$DATA, $ACK,$EOF),"\n";
                            print CANOUT sprintf("%012.6f\t%5s %2s %24s - %s %s",$messagetime,$ID,$DLC,$DATA, $ACK,$EOF),"\n";
                            $DATA =~ s/^\s+//;

                            foreach my $CANfilter_ID (@CAN_filter_IDs){
                                print CANCSV "$messagetime;$ID;$DATA\n" if ($ID eq $CANfilter_ID);
                            }

                        }
                        elsif ($ACK eq '00'){
                            print CANDEBUG sprintf("%012.6f  $CANlasttime \t ACK ERROR in frame: $CANframe ",$messagetime ),"\n";
                        }
                        else{
                            print CANDEBUG sprintf("%012.6f\t%15s %2s %24s - %s %s",$messagetime,'errorframe-'.$ID,$DLC,$DATA, $ACK,$EOF),"\n";
                        }

                            #store frame
        # print CANDEBUG "$CANlasttime $ID $DLC $DATA\n";
                        #empty framefuffer
                        @framebits=();
                    } 
                    else{ # no IFS
                        my $bitcount=sprintf("%d",(($Timestamp-$CANlasttime) / $CANbittime + 0.5));
      #    print CANDEBUG "$CANlasttime  $CANlastvalue bitcount =  $bitcount (".(($Timestamp-$CANlasttime) / $CANbittime).") dt ".($Timestamp-$CANlasttime)."\n";
                        push(@framebits,$CANlastvalue x $bitcount );
                    }
                } #endif ($CANlasttime>0)


                #save timestamp for last CAN frame

                $CANlasttime=$Timestamp;
                $CANlastvalue=$CAN_Curr;

            } #endif($CAN_Curr != $CANlastvalue)

        } #endif($candecode_flag)


    }


    for($count=0;$count<scalar(@CS_pin);$count++){
        $FH[$count]->close;
    }


    close(INFILE);

    if($CAN_pin > 0){
        close(CANOUT);
        close(CANDEBUG);
        close(CANCSV);
    }

    if($FR_pin > 0){
        close(FROUT);
        close(FRCSV);
    }

}



sub _check_number{
    my $test = shift;
    if ($test =~ /^\d+$/){
        return 1;
    }
    else{
        return 0;
    }
}


1;
__END__

=head1 NAME

TRAVELLOGIC - Perl extension for Acute TravelLogic Logic Analyzer

=head1 SYNOPSIS

  use TRAVELLOGIC;

=head1 DESCRIPTION

All these functions are wrapped around LaRun DLL APIs.


model:

    0x2036 "TL2036" 
    0x2136 "TL2136" 
    0x2236 "TL2236" 
    0x1032 "LA1032" 
    0x1064 "LA1064" 
    0x2032 "LA2032" 
    0x2064 "LA2064" 
    0x2132 "LA2132" 
    0x2164 "LA2164" 
    0x1116 "PKLA1116"
    0x1216 "PKLA1216"
    0x1616 "PKLA1616"



=head2 tl_Capture

    tl_Capture($trigger_pin, $trigger_edge, $Pins_aref, mode );

    e.g.  tl_Capture(11,0,[2,3,4,5,11,13,10],510);

trigger pin: 0..35 , trigger edge 0 = falling, 1 = rising

mode: 510 = TR-36, 511 = TR-8


=head2 tl_Dump

    tl_Dump($filename,$Pins_aref,$Names_aref)

    e.g.  tl_Dump("dump.txt.unv", [2,3,4,5,11,13,10],[ qw(2_MISO1_9 03_reset_10 04_CLK1_11 05_MOSI1_12 11_CS6in_25 13_CS7in_25 10) ]);

dump pins in uniview format           

=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

L<perl>.

=cut
