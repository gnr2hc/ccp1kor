package GOS64D42P;

use strict;
use warnings;
use File::Basename;

# need to add in calling module
#BEGIN
#{
#    # add directories to search path for perl modules
#    unshift @INC, dirname( $0 )."/modules/GPIB";
#    unshift @INC, dirname( $0 )."/modules/GPIB/GPIB";
#}

use GPIB;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use GOS64D42P ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
);

our ($VERSION,$HEADER);


=head1 NAME

GOS64D42P 

Perl extension for GOSSEN power supply 64 D 42 P

=head1 SYNOPSIS

    use GOS64D42P;

    my ($pps, $value, $string, $duration);

    $pps = GOS64D42P->new(\*LOG);
    $pps->connect('GPIB:8');

    $pps->voltage(12.4);     
    $pps->on(); 
    $pps->off(); 

    $pps->disconnect();


=head1 DESCRIPTION

remote control functions for GOSSEN power supply using GPIB.pm

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut


=head1 CONSTRUCTOR

=head2 $pps = GOS64D42P->new(\*LOG);

creates an instance of a PPS object and returns its handle

writes into give logfile, if no filehandle is given log_GOS64D42Ppm.txt is created, 

=cut


my $PPS_handle;
my $logfile_handle;


sub new {
    my $class = shift;
    $logfile_handle=shift;
    unless ($logfile_handle) {
        open ( PPSLOG,">log_GOS64D42Ppm.txt" ) or die "Couldn't open logfile : $@";
        $logfile_handle = \*PPSLOG;
    }
    my $self = {};
    bless ($self, $class);
    w2log("creating new GOS64D42P instance\n");
    $self->{connected} = 0; # set connencted flag to false
    $self->{ID} = "";
    return $self;
}


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


############################################################################################################

=head2 $DeviceID = $pps->connect($connection);

Connnect to PPS via given connection, reads device identification (*IDN). This method has to be called first before any other method can be used.   

A valid connection is e.g. 'GPIB:3'. Make sure power supply is configured accordingly !

=cut

sub connect {
    my $self = shift;

    my $mode;
    my $connection = shift;
    w2log("connecting with GOS64D42P via <$connection>\n");

    if($connection =~ /GPIB:\s*(\d+)/i){
        my $DeviceID;
        my $maxTries=3;
        
        # The Gossen was found sometimes not to be "communicative" at first try
        # therefore we try again...
        while ($maxTries>0) {
            $self->{GPIB} = GPIB->new("GPIB::ni", 0, $1, 0, GPIB->T300ms, 1, 0);   
            $PPS_handle = $self->{GPIB};
            wait_ms(10);
            $PPS_handle -> ibwrt("*IDN?");
            wait_ms(10);
            $DeviceID = readString($self);
            chomp($DeviceID);
            if ($DeviceID eq "") { $maxTries--; }
            else { $maxTries=0; }
        }
        
        w2log("Device is <$DeviceID>\n");
        $self->{connected} = 1; # set connencted flag to true
        $self->{ID} = "{$DeviceID}";
        return($DeviceID);

    }
    else{
      w2log("ERROR: connection error for GOS64D42P on <$connection>\n");
      $self->{connected} = 0; # set connencted flag to false
    }

}




############################################################################################################

=head2 $pps->disconnect();

Disconnect from PPS

=cut

sub disconnect{
    my $self = shift;
    $PPS_handle = $self->{GPIB};
    w2log("disconnecting GOS64D42P $self->{ID}\n");
    undef $self->{ID};
    $self->{connected} = 0; # set connencted flag to false

}


############################################################################################################

=head2 $pps->saveConfig($configfile, [$comment]); NOT TESTED

save configuration to file

=cut

sub saveConfig{
    my $self = shift;
    $PPS_handle = $self->{GPIB};
    my $filename = shift;
    my $Comment = shift;
    $Comment = "" unless (defined $Comment);

    $PPS_handle -> ibwrt("*LRN?");
    my $config = readString($self);

    open ( OUT,">$filename" ) or die "Couldn't open $_ : $@";
    print OUT "DeviceModel=".$self->{ID}."\n";
    print OUT "Comment=".$Comment."\n";
    print OUT $config."\n";
    close(OUT);

    w2log("settings saved to $filename\n");
}



############################################################################################################

=head2 $dso->restoreConfig($configfile); NOT TESTED

restore configuration from file.

=cut

sub restoreConfig{
    my $self = shift;
    $PPS_handle = $self->{GPIB};
    my $setup = shift;
    my ($Settings,$ConfigModel,$Comment);
    open ( IN,"<$setup" ) or die "Couldn't open $_ : $@";
    $ConfigModel=<IN>;
    $Comment=<IN>;
    $Settings=<IN>;
    close(IN);
    chomp($Settings);
    chomp($ConfigModel);
    chomp($Comment);
    $ConfigModel =~ s/^DeviceModel=//; #cut off tag
    $Comment =~ s/^Comment=//; #cut off tag

    w2log("restore settings from <".$setup.">\n");
    # write Settings as query
#    writeString($self,$Settings);
#    checkError($self);
    my $command;
    foreach $command (split(/;/, $Settings)) {
        writeString($self, $command);
        wait_ms(100);
    }

    if ($self->{ID} ne $ConfigModel){
        w2log("warning: current device is <".($self->{ID})."> config created with <$ConfigModel>\n");
    }
    else{w2log("settings restored\n");}

}



############################################################################################################

=head2 $value = $pps->checkError(); NOT IMPLEMENTED, just returns

read error status (*ESR?,ERR?) and report error if there is one

=cut

sub checkError{
    return;

    my $self = shift;
    $PPS_handle = $self->{GPIB};
    my ($ESRresp, $ERRresp);

    $PPS_handle->ibwrt('*ESR?');             
    $ESRresp = readString($self);           # Read result
    unless (defined($ESRresp) ){
        w2log("?retry status check\n");
        $PPS_handle->ibwrt('*ESR?');             
        $ESRresp = readString($self);           # Read result
        unless (defined($ESRresp) ){
            w2log("!comminication error: no staus received\n");
            return;
        }
    }
    chomp($ESRresp);
    if ($ESRresp > 0){
        $PPS_handle->ibwrt('ERR?');             
        $ERRresp = readString($self);           # Read result
        chomp($ERRresp);
        if ($ERRresp !~ /^0,/) {
            w2log("!error: ESR is $ESRresp, ERR is $ERRresp\n");
        }
    }  
}



############################################################################################################

=head2 $pps->on([$channel]);

set output to ON, if $channel is not defined, $channel=4 is used.

GPIB commands: OUTPUT $channel,on

=cut

sub on{
    my $self = shift;
    my $channel = shift;

    $channel = 4 unless (defined $channel);
    w2log("Gossen: channel $channel ON\n");

    $self->writeString("OUTPUT $channel,on");
}



############################################################################################################

=head2 $pps->off([$channel]);

set output to OFF, if $channel is not defined, $channel=4 is used.

GPIB commands: OUTPUT $channel,off

=cut

sub off{
    my $self = shift;
    my $channel = shift;

    $channel = 4 unless (defined $channel);
    w2log("Gossen: channel $channel OFF\n");

    $self->writeString("OUTPUT $channel,off");
}


############################################################################################################

=head2 $pps->voltage($voltage[, $channel[,$maxcurrent]]);

set output voltage to $voltage on $channel, if $channel is not defined, $channel=4 is used.

If $maxcurrent is not defined, 4A is used for current limitation. Note that the
supply is set to CV (controlled voltage) mode.

GPIB commands: ILIM $channel,$maxcurrent; ISET $channel,$maxcurrent; MODE $channel,CV; USET $channel,$voltage

=cut

sub voltage{
    my $self       = shift;
    my $voltage    = shift;
    my $channel    = shift;
    my $maxcurrent = shift;

    $maxcurrent = 4 unless (defined $maxcurrent);
    $channel    = 4 unless (defined $channel);
    w2log("Gossen: channel $channel set to $voltage V, current limitation $maxcurrent A\n");

    $self->writeString("ILIM $channel,$maxcurrent; ISET $channel,$maxcurrent; MODE $channel,CV; USET $channel,$voltage");
}


############################################################################################################

=head2 $pps->current($current[, $channel[,$maxvoltage]]);

set output current to $current on $channel, if $channel is not defined, $channel=4 is used.

If $maxvoltage is not defined, 30V is used for voltage limitation. Note that the
supply is set to CC (controlled current) mode.

GPIB commands: ULIM $channel,$maxvoltage; USET $channel,$maxvoltage; MODE $channel,CC; ISET $channel,$current

=cut

sub current{
    my $self       = shift;
    my $current    = shift;
    my $channel    = shift;
    my $maxvoltage = shift;

    $maxvoltage = 30 unless (defined $maxvoltage);
    $channel    = 4 unless (defined $channel);
    w2log("Gossen: channel $channel set to $current A, voltage limitation $maxvoltage V\n");

    $self->writeString("ULIM $channel,$maxvoltage; USET $channel,$maxvoltage; MODE $channel,CC; ISET $channel,$current");
}


############################################################################################################

=head2 $pps->measureVoltage([$channel]);

Measure output voltage, if $channel is not defined, $channel=4 is used.

GPIB commands: MEASURE $channel; UOUT?

=cut

sub measureVoltage{
    my $self    = shift;
    my $channel = shift;
    my $voltage;

    $channel = 4 unless (defined $channel);
    $self->writeString("MEASURE $channel; UOUT?");
    $voltage = readString();
    w2log("Gossen: voltage at channel $channel: $voltage V\n");
    return $voltage;
}


############################################################################################################

=head2 $pps->measureCurrent([$channel]);

Measure output current, if $channel is not defined, $channel=4 is used.

GPIB commands: MEASURE $channel; IOUT?

=cut

sub measureCurrent{
    my $self    = shift;
    my $channel = shift;
    my $current;

    $channel = 4 unless (defined $channel);
    $self->writeString("MEASURE $channel; IOUT?");
    $current = readString();
    w2log("Gossen: current at channel $channel: $current A\n");
    return $current;
}


############################################################################################################

=head2 $pps->measurePower([$channel]);

Measure output power, if $channel is not defined, $channel=4 is used.

GPIB commands: MEASURE $channel; POUT?

=cut

sub measurePower{
    my $self    = shift;
    my $channel = shift;
    my $power;

    $channel = 4 unless (defined $channel);
    $self->writeString("MEASURE $channel; POUT?");
    $power = readString();
    w2log("Gossen: power at channel $channel: $power W\n");
    return $power;
}




######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut




############################################################################################################

=head2 $pps->writeString($string);

write string directly to PPS

=cut

sub writeString{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
  my $string = shift;
  w2log("writing <$string> to $self->{ID}\n");
  $PPS_handle -> ibwrt($string);
  wait_ms(10);
}



############################################################################################################

=head2 $string = $pps->readString();

read string directly from PPS

=cut

sub readString{
  my $self = shift;
  $PPS_handle = $self->{GPIB};
   my ($string,$STB,$i);
    # poll for MAV bit max 5 sec
    for ($i=0; $i<500; $i++){
        $STB = 256+($PPS_handle -> ibrsp());
        last if (($STB & 16) == 16);
        # sleep 10 msec
        wait_ms(10);        
    }
   
    if ($i>499){
        w2log("!communication timeout while reading from $self->{ID}\n");
        return("");
    }
   
    wait_ms(10);        
    $string = $PPS_handle -> ibrd(1024);
    unless (defined($string)){
        w2log("?retry reading from $self->{ID}\n");
        $string = $PPS_handle -> ibrd(1024);
        unless (defined($string)){
            w2log("!communication error while reading from $self->{ID}\n");
            return("");
        }
    }
    chomp($string);
    w2log("reading <$string> from $self->{ID}\n");
    return($string);
}



############################################################################################################

=head2 $value = $pps->isConnected();

check if PPS is connected returns 1 if true, 0 if false

=cut

sub isConnected{
    my $self = shift;
    return($self->{connected});
}



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print $logfile_handle $text if (defined $logfile_handle);
     print $text;
}


sub wait_ms{
    my $time = shift;    
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Roger Hartmann, E<lt>Roger.Hartmann@de.BOSCH.comE<gt>
Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Gossen manual.

=cut
