# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_GOS1;

use strict;
use warnings;
use File::Basename;
use Readonly;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['..\GPIB', '..\GPIB\GPIB', '..\GPIB\Win32' ], []);
}

use GOS64D42P;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_GOS1 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  GOS1_connect
  GOS1_disconnect
  GOS1_readString
  GOS1_writeString
  GOS1_measurePower
  GOS1_measureCurrent
  GOS1_measureVoltage
  GOS1_current
  GOS1_voltage
  GOS1_off
  GOS1_on
  GOS1_checkError
  GOS1_restoreConfig
  GOS1_saveConfig
);

our ( $VERSION, $HEADER );

#Constant variables used in module
Readonly my $GOS_DEFAULT_CHANNEL     => 4;
Readonly my $GOS_DEFAULT_MAX_CURRENT => 4;
Readonly my $GOS_DEFAULT_MAX_VOLTAGE => 30;

=head1 NAME

LIFT_GOS1 

Perl extension for GOSSEN power supply


=head1 SYNOPSIS

    use LIFT_GOS1;

    GOS1_connect('GPIB:8');

    GOS1_saveConfig("GOS1_save.cfg");
    GOS1_restoreConfig("GOS1.cfg");
    GOS1_checkError();
    GOS1_off();
    GOS1_on();
    GOS1_voltage(12.5);
    GOS1_current(4);
    $value = GOS1_measureVoltage();
    $value = GOS1_measureCurrent();
    $value = GOS1_measurePower();

    GOS1_writeString('*IDN');
    $value = GOS1_readString();

    GOS1_disconnect();


=head1 DESCRIPTION

remote control functions for GOSSEN power supply using GPIB.pm

=cut

my $pps1;

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 GOS1_connect

    $DeviceID = GOS1_connect( $connection );

Connnect to Gossen via given connection, reads device identification (*IDN).
This method has to be called first before any other method can be used.

A valid connection is e.g. 'GPIB:3'. Make sure power supply is configured accordingly !

=cut

sub GOS1_connect
{
    my $connection = shift;

    unless ( defined($connection) )
    {
        S_set_error( " SYNTAX: DeviceID = GOS1_connect(connection);", 110 );
        return "";
    }

    if ( defined($pps1) )
    {
        S_set_error( "Connection failed, GOS object could not be created, object exists already", 5 );
        return "";
    }

    if ($main::opt_offline)
    {
        $pps1 = 1;
        S_w2log( 3, "GOS1_connect: Established the connection with Gossen \n" );
        return "dummy";
    }

    $pps1 = GOS64D42P->new();
    unless ( defined($pps1) )
    {
        S_set_error( "pps object could not be created", 1 );
        return "";
    }

    S_w2log( 3, "GOS1_connect: Established the connection with Gossen \n" );

    return ( $pps1->connect($connection) );
}

############################################################################################################

=head2 GOS1_disconnect

    GOS1_disconnect();

Disconnect from Gossen

=cut

sub GOS1_disconnect
{
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return;
    }

    if ($main::opt_offline)
    {
        undef $pps1;
        S_w2log( 3, "GOS1_disconnect: Disconnected the Gossen \n" );
        return 1;
    }
    $pps1->disconnect();
    undef $pps1;

    S_w2log( 3, "GOS1_disconnect: Gossen Device disconnected \n" );

    return 1;
}

############################################################################################################

=head2 GOS1_saveConfig

    GOS1_saveConfig( $configfile, [$comment] );

save configuration to file

=cut

sub GOS1_saveConfig
{
    my $filename = shift;
    my $comment  = shift;
    unless ( defined($filename) )
    {
        S_set_error( " SYNTAX: GOS1_saveConfig(configfile, [comment])", 110 );
        return "";
    }
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    if ($main::opt_offline)
    {
        S_create_dummy_file($filename);
        S_w2log( 3, "GOS1_saveConfig: saved configuration to file $filename\n" );
        return 1;
    }
    $pps1->saveConfig( $filename, $comment );

    S_w2log( 3, "GOS1_saveConfig: saved configuration to file $filename\n" );

    return 1;
}

############################################################################################################

=head2 GOS1_restoreConfig

    GOS1_restoreConfig( $configfile );

restore configuration from file.

=cut

sub GOS1_restoreConfig
{
    my $setup = shift;
    unless ( defined($setup) )
    {
        S_set_error( " SYNTAX: GOS1_restoreConfig( configfile )", 110 );
        return "";
    }
    unless ( -f $setup )
    {
        S_set_error( "TOE1_setCurveFile, could not access $setup", 1 );
        return 1;
    }

    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1_restoreConfig: restored configuration from file $setup\n" );
        return 1;
    }

    $pps1->restoreConfig($setup);

    S_w2log( 3, "GOS1_restoreConfig: restored configuration from file $setup\n" );

    return 1;
}

############################################################################################################

=head2 GOS1_checkError

    $value = GOS1_checkError(); TO BE CHECKED, NOT REALLY IMPLEMENTED YET

(does not return anything, just calls $pps1->checkError();)

read error status (*ESR?,ERR?) and report error if there is one

=cut

sub GOS1_checkError
{
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    S_w2log( 3, "GOS1: check Error: NOT IMPLEMENTED YET\n" );
    return 1 if $main::opt_offline;
    $pps1->checkError();

    return 1;
}

############################################################################################################

=head2 GOS1_on

    GOS1_on( [$channel] );

set output to ON, if $channel is not defined, $channel=4 is used.

=cut

sub GOS1_on
{
    my $channel = shift;

    $channel = $GOS_DEFAULT_CHANNEL unless ( defined $channel );
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1_on:  output $channel ON \n" );
        return 1;
    }

    $pps1->on($channel);
    S_w2log( 3, "GOS1_on:  output $channel ON \n" );

    return 1;
}

############################################################################################################

=head2 GOS1_off

    GOS1_off( [$channel] );

set output to OFF, if $channel is not defined, $channel=4 is used.

=cut

sub GOS1_off
{
    my $channel = shift;

    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    $channel = $GOS_DEFAULT_CHANNEL unless ( defined $channel );

    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1_off: output $channel OFF \n" );
        return 1;
    }

    $pps1->off($channel);
    S_w2log( 3, "GOS1_off: output $channel OFF \n" );

    return 1;
}

############################################################################################################

=head2 GOS1_voltage

    GOS1_voltage( $voltage [, $channel[,$maxcurrent] ] );

set output voltage to $voltage on $channel, if $channel is not defined, $channel=4 is used.

If $maxcurrent is not defined, 4A is used for current limitation. Note that the
supply is set to CV (controlled voltage) mode.

=cut

sub GOS1_voltage
{
    my $voltage    = shift;
    my $channel    = shift;
    my $maxcurrent = shift;

    unless ( defined($voltage) )
    {
        S_set_error( " SYNTAX: GOS1_voltage( voltage [, channel[,maxcurrent]] )", 110 );
        return "";
    }
    $channel    = $GOS_DEFAULT_CHANNEL     unless ( defined $channel );
    $maxcurrent = $GOS_DEFAULT_MAX_CURRENT unless ( defined $maxcurrent );
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1_voltage:  $voltage V at output $channel (current limited to $maxcurrent A) \n" );
        return 1;
    }

    $pps1->voltage( $voltage, $channel, $maxcurrent );
    S_w2log( 3, "GOS1_voltage:  $voltage V at output $channel (current limited to $maxcurrent A) is set \n" );

    return 1;
}

############################################################################################################

=head2 GOS1_current

    GOS1_current( $current[, $channel[,$maxvoltage]] );

set output current to $current on $channel, if $channel is not defined, $channel=4 is used.

If $maxvoltage is not defined, 30V is used for voltage limitation. Note that the
supply is set to CC (controlled current) mode.

=cut

sub GOS1_current
{
    my $current    = shift;
    my $channel    = shift;
    my $maxvoltage = shift;

    unless ( defined($current) )
    {
        S_set_error( " SYNTAX: GOS1_current( current [, channel[,maxvoltage]] )", 110 );
        return "";
    }
    $channel    = $GOS_DEFAULT_CHANNEL     unless ( defined $channel );
    $maxvoltage = $GOS_DEFAULT_MAX_VOLTAGE unless ( defined $maxvoltage );
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1_current:  $current A at output $channel (voltage limited to $maxvoltage V) \n" );
        return 1;
    }
    $pps1->current( $current, $channel, $maxvoltage );
    S_w2log( 3, "GOS1_current:  $current A at output $channel (voltage limited to $maxvoltage V) is set \n" );

    return 1;
}

############################################################################################################

=head2 GOS1_measureVoltage

    $value = GOS1_measureVoltage( [$channel] );

Measure output voltage, if $channel is not defined, $channel=4 is used.

offline return: 1

=cut

sub GOS1_measureVoltage
{
    my $channel = shift;
    my $result;

    $channel = $GOS_DEFAULT_CHANNEL unless ( defined $channel );
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1: (offline mode) V measured at output $channel\n" );
        return 1;
    }
    $result = $pps1->measureVoltage($channel);
    S_w2log( 3, "GOS1: $result V measured at output $channel\n" );

    return $result;
}

############################################################################################################

=head2 GOS1_measureCurrent

    $value = GOS1_measureCurrent( [$channel] );

Measure output current, if $channel is not defined, $channel=4 is used.

offline return: 1

=cut

sub GOS1_measureCurrent
{
    my $channel = shift;
    my $result;

    $channel = $GOS_DEFAULT_CHANNEL unless ( defined $channel );
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1: (offline mode) A measured at output $channel\n" );
        return 1;
    }
    $result = $pps1->measureCurrent($channel);
    S_w2log( 3, "GOS1: $result A measured at output $channel\n" );

    return $result;
}

############################################################################################################

=head2 GOS1_measurePower

    $value = GOS1_measurePower( [$channel] );

Measure output power, if $channel is not defined, $channel=4 is used.

offline return: 1

=cut

sub GOS1_measurePower
{
    my $channel = shift;
    my $result;

    $channel = $GOS_DEFAULT_CHANNEL unless ( defined $channel );
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1: (offline mode) W measured at output $channel\n" );
        return 1;
    }
    $result = $pps1->measurePower($channel);
    S_w2log( 3, "GOS1: $result W measured at output $channel\n" );

    return $result;
}

######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut

############################################################################################################

=head2 GOS1_writeString

    GOS1_writeString( $string );

write string directly to Gossen

=cut

sub GOS1_writeString
{
    my $string = shift;
    unless ( defined($string) )
    {
        S_set_error( " SYNTAX: GOS1_writeString( string )", 110 );
        return "";
    }
    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    S_w2log( 3, "GOS1: writeString function: $string\n" );
    return 1 if $main::opt_offline;
    $pps1->writeString($string);

    return 1;
}

############################################################################################################

=head2 GOS1_readString

    $string = GOS1_readString();

read string directly from Gossen

offline return: 'dummy'

=cut

sub GOS1_readString
{
    my $string = "";

    unless ( defined($pps1) )
    {
        S_set_error( "pps object is invalid", 5 );
        return 1;
    }
    if ($main::opt_offline)
    {
        S_w2log( 3, "GOS1: readString function: (empty in offline mode)\n" );
        return "dummy";
    }
    $string = $pps1->readString();
    S_w2log( 3, "GOS1: readString function: $string\n" );
    return ($string);
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Gossen manual.

=cut
