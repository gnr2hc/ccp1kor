# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CDLayer;

use strict;
use warnings;
use LIFT_general;
use LIFT_simulation;
use LIFT_stringProcessing;
use Win32::OLE;
use Win32::OLE::Variant;
Win32::OLE->Option( Warn => \&CatchOleException );
use version;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  CDL_init
  CDL_exit
  CDL_send_request_wait_response
  CDL_send_single_frame
);

our ( $VERSION, $HEADER );

my $noResponseRegex = "timed out|queue empty|LOGIN_HAS_FAILED|RECEIVE_QUEUE_EMPTY";
my $lastResponse_href;
my $bytesPerFrame = 8;

=head1 NAME

LIFT_CDLayer 

=head1 SYNOPSIS

    use LIFT_CDLayer

    ($diagHandle_href) = CDL_init( $handleName, $busName, $communicationParameters_href );
    $success = CDL_exit( $diagHandle_href );
    $response_href = CDL_send_request_wait_response( $diagHandle_href, $request_aref [, $options_href ] );

=head1 DESCRIPTION

Perl interface to the CDLayer.dll (CDLayer.Pd4Com) via COM.

Most of the functions return the ECU response as hashref:

    $response_href = {
        'CdLength'           => <first byte of response>,        # decimal number
        'Id'                 => <second byte of response>,       # decimal number
        'Checksum'           => <last byte of response>,         # decimal number
        'PdPayload'          => [<remaining bytes of response>], # array reference, decimal numbers
        'CompleteCdMsg'      => [<all bytes of response>],       # array reference, decimal numbers
        'Status'             => <status of response>,            # number, >=0 is OK, <0 is error
        'ErrorDescription'   => <error description>,             # string, according to 'Status'
        'IsCheckConsistency' => <???>,                           # boolean, 0|1
    };

=head1 FUNCTIONS



=head2 CDL_init

    $diagHandle_href = CDL_init( $handleName, $busName, $communicationParameters_href );

Creates a COM connection to CDLayer.dll (CDLayer.Pd4Com) and creates a COM handle with the name $handleName for subsequent usage of the connection.
Tries to initialize communication on the bus $busName using $communicationParameters_href.

B<Arguments:>

=over

=item $handleName

name of the handle

=item $busName

bus type for initializing communication (CAN)
    
=item $communicationParameters_href

For CAN, communication parameters looks like this,
    
    $communication_params_href = {
        'BAUDRATE'   => 7A120,
        'TSEG1'      => C,
        'TSEG2'      => 3,
        'SJW'        => 3,
        'SAM'        => 1,
        'REQUEST'    => 650,
        'RESPONSE1'  => 651,
        'RESPONSE2'  => 652,
        'RESPONSE3'  => 653,
        'RESPONSE4'  => 654,
    }

=back

B<Return Values:>

=over

=item $diagHandle_href

    $diagHandle_href = {
        'name' => <name of handle>,          # name as given in $communicationParameters_href
        'OLE_handle' => <Win32::OLE object>, # Win32::OLE object for access to CDLayer.dll
        'status' => <status of the function call>
    }

=back

B<Examples:>

    $result = CDL_init( 'PD', 'CAN', $comm_href ); 

=cut

sub CDL_init {
    my @args = @_;

    S_checkFunctionArguments( 'CDL_init( $handleName, $busName, $communicationParameters_href [, $nolog ]  )', @args ) or return;
    my $handleName                   = shift @args;
    my $busName                      = shift @args;
    my $communicationParameters_href = shift @args;
    my $nolog                        = shift @args;

    # offline handling
    my $diagHandle_href;
    if ($main::opt_offline) {
        $diagHandle_href = {
            'name'       => $handleName,
            'OLE_handle' => 1,
            'status'     => 1,
        };
        return $diagHandle_href;
    }

    #CALL CheckRegisteredCOMdll to check if the registered COM dll matches the corresponding Engine dll
    my $dllName = 'Cd4Com.Cd4Com.1.0';
    #CheckRegisteredCOMdll($dllName) or return;

    #CALL GetOleObject (CDLayer.Pd4Com.1.0) to get Pd4Com object
    S_w2log( 3, "CDL_init: Creating a connection to COM class '$dllName' for handle '$handleName' ...\n" ) unless $nolog;
    my $cdLayer_obj = GetOleObject($dllName) or return;

    #STEP Create diag handle with Pd4Com object
    $diagHandle_href = {
        'name'       => $handleName,
        'OLE_handle' => $cdLayer_obj,
    };

    S_w2log( 3, "CDL_init: Connection to COM class '$dllName' for handle '$handleName' created. Initializing communication on bus '$busName'...\n" ) unless $nolog;

    #CALL GetOleObject ('CDLayer.Pd4Com.ComPdParam') to get ComPdParam object
    my $comCdParam_obj = GetOleObject('Cd4Com.ComCdParam.1.0') or return;    # first prototype

    #STEP Fill the ComPdParam object with communication parameters
    #CALL SetComPdParam (ComPdParam object, $communicationParameters_href)
    SetComCdParam( $comCdParam_obj, $communicationParameters_href );

    #STEP Initialize communication on the bus using the ComPdParam object
    #CALL CallObjMethod (Pd4Com object, 'InitializeEcuCommunication', [ $busName, ComPdParam object ])
    my $initStatus = CallObjMethod( $cdLayer_obj, 'InitializeEcuCommunication', [ $busName, $comCdParam_obj ] ) // -1;
    if ( $initStatus < 0 ) {
        my $errorDescription = CallObjMethod( $cdLayer_obj, 'GetErrorDescription', [$initStatus] );
        S_set_error( "Status '$initStatus' after 'InitializeEcuCommunication' on CDLayer handle '$handleName'. Error description: $errorDescription", 109 );
        $diagHandle_href->{status} = $initStatus;
        return $diagHandle_href;
    }
    S_w2log( 3, "CDL_init: Communication with request ID '$communicationParameters_href->{REQUEST}' and response ID '$communicationParameters_href->{RESPONSE1}' on bus '$busName' established.\n" ) unless $nolog;
    $diagHandle_href->{status} = 1;

    #my $getMainVersionOfPdDll  = CallObjMethod( $cdLayer_obj, 'GetMainVersionOfPdDll' )  // 'Error-GetMainVersionOfPdDll';
    #my $getMainVersionOfVxlapi = CallObjMethod( $cdLayer_obj, 'GetMainVersionOfVxlapi' ) // 'Error-GetMainVersionOfVxlapi';
    #S_w2log( 3, "CDL_init: version information for 'CDLayer = $getMainVersionOfPdDll' and 'vxlapi = $getMainVersionOfVxlapi'.\n" );

    #STEP Return diag handle
    return $diagHandle_href;
}

=head2 CDL_exit

    $success = CDL_exit( $diagHandle_href );


B<Arguments:>

=over

=item $diagHandle_href

=back
B<Return Values:>

=over

=item $success

$success is 1 on success
$success is undef on failure

=back

B<Examples:>

    $success = CDL_exit( $diagHandle_href );
    
=cut

sub CDL_exit {
    my @args = @_;
    #S_checkFunctionArguments( 'CDL_exit( $diagHandle_href [, $nolog ] )', @args ) or return;
    my $diagHandle_href = shift @args;
    my $nolog           = shift @args;

    #S_checkFunctionArgumentHashKeys( "CDL_exit", $diagHandle_href, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 }, { 'name' => 1, 'OLE_handle' => 1 } ) or return;

    S_w2log( 4, "Calling CDL_exit to close the diagnosis handle.." ) unless $nolog;

    # offline handling
    return 1 if ($main::opt_offline);

    #STEP Uninitialize the OLE object in the diagHandle
    my $cdLayer_obj = $diagHandle_href->{OLE_handle};
    CallObjMethod( $cdLayer_obj, 'UnInitializeEcuCommunication' );
    $cdLayer_obj = undef;

    return 1;
}

=head2 CDL_send_request_wait_response

    $response_href = CDL_send_request_wait_response( $diagHandle_href, $request_aref [, $options_href ] );

Sends the request bytes $request_aref to the device defined by $diagHandle_href, waits for a response, 
and returns the response data as $response_href.

B<Arguments:>

=over

=item $diagHandle_href

=item $request_aref

=item $options_href

=back


B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

B<Notes:> 

=cut

sub CDL_send_request_wait_response {
    my @args = @_;
    S_checkFunctionArguments( 'CDL_send_request_wait_response( $diagHandle_href, $request_aref )', @args ) or return;
    my $diagHandle_href = shift @args;
    my $request_aref    = shift @args;

    my $oleOptions_aref = [ VT_ARRAY | VT_I4 ];
    S_checkFunctionArgumentHashKeys( "CDL_send_request_wait_response", $diagHandle_href, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 }, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 } ) or return;

    my $handleName    = $diagHandle_href->{'name'};
    my $requestString = STR_Aref2HexString($request_aref);

    my $response_href;
    my $individualFrames_href = {};
    my $requestLength = @$request_aref;
    if( $requestLength < $bytesPerFrame ) {
        # single frame request
        S_w2log( 3, "CDL_send_request_wait_response: Sending single frame request '$requestString' to CDLayer...\n" );
        my @frame = @$request_aref;
        unshift(@frame, $requestLength);
        @frame = (@frame, (0) x ($bytesPerFrame-@frame)); # fill with zeros
        $response_href = SendServiceReceiveResponse( $diagHandle_href, 'SendReceiveSingleFrame', [\@frame], $oleOptions_aref );
        AddIndividualResonse($individualFrames_href, $response_href);
    }
    else{
        # multi frame request
        S_w2log( 3, "CDL_send_request_wait_response: Sending multi frame request '$requestString' to CDLayer...\n" );    
        my $pciHigh = 0x10 | int($requestLength/256);
        my $pciLow  = $requestLength % 256;
        my @frame = ($pciHigh, $pciLow, splice(@$request_aref, 0, $bytesPerFrame-2));
        $response_href = SendServiceReceiveResponse( $diagHandle_href, 'SendReceiveSingleFrame', [\@frame], $oleOptions_aref );
        AddIndividualResonse($individualFrames_href, $response_href);

        my $sn = 1;
        while(@$request_aref > 0){
            my $pci = 0x20 | ($sn % 16);
            if( @$request_aref >= $bytesPerFrame-1 ) {
                @frame = ($pci, splice(@$request_aref, 0, $bytesPerFrame-1));
                $response_href = SendServiceReceiveResponse( $diagHandle_href, 'SendReceiveSingleFrame', [\@frame], $oleOptions_aref );
                AddIndividualResonse($individualFrames_href, $response_href);
                if( @$request_aref == 0 ){
                    $sn++;
                    $pci = 0x20 | ($sn % 16);
                    @frame = ($pci, (0) x ($bytesPerFrame-1));
                }
            }
            else{
                @frame = ($pci, splice(@$request_aref, 0, scalar( @$request_aref )));
                @frame = (@frame, (0) x ($bytesPerFrame-@frame)); # fill with zeros
                $response_href = SendServiceReceiveResponse( $diagHandle_href, 'SendReceiveSingleFrame', [\@frame], $oleOptions_aref );
                AddIndividualResonse($individualFrames_href, $response_href);
            }
            $sn++;
        }        
    }    

    unless ( defined $response_href and defined $response_href->{Status} and $response_href->{Status} == 0 ) {
        S_w2log( 3, "CDL_send_request_wait_response: Received no response.\n" );
        return $response_href;
    }

    my @firstFrameBytes = @{$response_href->{'FrameBytes'}};
    
    if( $firstFrameBytes[1] == 0x7F and $firstFrameBytes[3] == 0x78 ){
        # response pending
        $response_href = SendServiceReceiveResponse( $diagHandle_href, 'ReceiveSingleFrame', [], $oleOptions_aref );
        AddIndividualResonse($individualFrames_href, $response_href);
        @firstFrameBytes = @{$response_href->{'FrameBytes'}};
    }

    if( $firstFrameBytes[0] & 0x10 ) {
        # multi frame response
        my $byte0 = shift @firstFrameBytes;
        my $byte1 = shift @firstFrameBytes;
        my $expectedResponseBytes = ($byte0 & 0x0F)*256 + $byte1;
        my $expectedConsecutiveFrames = ($expectedResponseBytes-$bytesPerFrame+2)/($bytesPerFrame-1);
        my @frame = (0x30, 0x00, 0x01); # send rest of the frames
        @frame = (@frame, (0) x ($bytesPerFrame-@frame)); # fill with zeros
        $response_href = SendServiceReceiveResponse( $diagHandle_href, 'SendReceiveData', [\@frame], $oleOptions_aref );
        AddIndividualResonse($individualFrames_href, $response_href);
        unshift(@{$response_href->{'ResponseBytes'}}, @firstFrameBytes);
    }

    my $responseString = STR_Aref2HexString( $response_href->{'ResponseBytes'} );
    S_w2log( 3, "CDL_send_request_wait_response: Received response: '$responseString'.\n" );

    $response_href->{IndividualFrames} = $individualFrames_href;
    return $response_href;
}

sub AddIndividualResonse{
    my $individualFrames_href = shift;
    my $response_href = shift;
    
    my $timeStamp = $response_href->{TimeStamp};
    $individualFrames_href->{$timeStamp} = $response_href->{FrameBytes},
    return 1;
}

sub CDL_send_single_frame {
    my @args = @_;
    S_checkFunctionArguments( 'CDL_send_single_frame( $diagHandle_href, $request_aref )', @args ) or return;
    my $diagHandle_href = shift @args;
    my $request_aref    = shift @args;

    S_checkFunctionArgumentHashKeys( "CDL_send_single_frame", $diagHandle_href, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 }, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 } ) or return;

    my $handleName    = $diagHandle_href->{'name'};
    my $requestString = STR_Aref2HexString($request_aref);
    my $asciiRequest = pack "C*", @$request_aref;

    my $response_href = SendServiceReceiveResponse( $diagHandle_href, 'SendReceiveSingleFrame', [$request_aref], [ VT_ARRAY | VT_I4 ] );

    my $logString = "CDL_send_single_frame: Request '$requestString' (ASCII: '$asciiRequest') received response: ";

    if ( defined $response_href and defined $response_href->{Status} and $response_href->{Status} == 0 ) {
        my $responseMessage_aref = $response_href->{CompleteCdMsg};
        my $responseString = STR_Aref2HexString($responseMessage_aref);
        my $asciiResponse = pack "C*", @$responseMessage_aref;
        $logString .= "'$responseString' (ASCII: '$asciiResponse')\n";
    }
    else{
        $logString .= "no response\n";
    }
    S_w2log( 3, $logString );

    return $response_href;
}

=head1 Not exported functions

=head2 Get_OleObject

    $object = Get_OleObject( $dllName );

Gets the COM/OLE object from the $dllName.  

B<Examples:>

    $cdLayer_obj = Get_OleObject( 'CDLayer.ProductionDiagnosis.1.3' )  

=cut

sub GetOleObject {
    my @args = @_;

    return unless S_checkFunctionArguments( 'GetOleObject ( $dllName )', @args );
    my $dllName = shift @args;

    #STEP Create a new Win32::OLE object for $dllName
    my $object = Win32::OLE->new($dllName);

    #IF Object is defined?
    if ( not defined $object ) {

        #IF-NO-START
        #STEP Throw error and return
        S_set_error( "Could not create COM connection to dll $dllName : " . Win32::OLE->LastError(), 111 );
        return;

        #IF-NO-END
    }

    #IF-YES-START

    #STEP Return object
    return $object;

    #IF-YES-END
    #STEP End
}

=head2 GetObjProperty

    $propertyValue = GetObjProperty ($object_mix, $property);

retrieves directly the value of COM '$property' from the object '$object_mix'.    

B<Examples:>

    my $raw_value = GetObjProperty( $signal_object, 'RawValue' );

=cut

sub GetObjProperty {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetObjProperty ($object_mix, $property)', @args );
    my $object   = shift @args;
    my $property = shift @args;

    my $propertyValue;
    $propertyValue = $object->{$property};
    return $propertyValue;
}

=head2 SetObjProperty

    SetObjProperty ($object_mix, $property, $propertyValue);

Set directly the '$propertyValue' to COM '$property' of object '$object_mix'.

B<Examples:>

    SetObjProperty( $signal_object, 'RawValue', $signal_value_raw_to_wr );    
    
=cut

sub SetObjProperty {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SetObjProperty ($object_mix, $property, $propertyValue_mix)', @args );
    my $object        = shift @args;
    my $property      = shift @args;
    my $propertyValue = shift @args;

    $object->{$property} = $propertyValue;
    return 1;
}

=head2 CallObjMethod

    $result = CallObjMethod ($object_mix, $methodName, [, $methodArgs_aref]);
    ($result, $argByRef1, ...) = CallObjMethod ($object_mix, $methodName, [, $methodArgs_aref, $argTypes_aref]);

Invokes on the object $object_mix the method $methodName. Arguments for the method (if required) can be given in $methodArgs_aref.
If arguments are arrays and/or shall be passed by reference then the argument types must be defined in $argTypes_aref.

B<Arguments:>

=over

=item $object_mix

OLE object on which the method shall be called.

=item $methodName

Name of the method that shall be called.

=item $methodArgs_aref

(Optional) List of arguments for the method. Arguments can be scalars or OLE objects or array references.
If arguments are arrays and/or shall be passed by reference then the argument types must be defined in $argTypes_aref.
In that case for each element of $methodArgs_aref the type must be defined in $argTypes_aref. 

=item $argTypes_aref

(Optional) List of argument types. 
The type of an argument can be either 0 if the argument is neither array nor by reference. 
Or the type can be described by the constants defined in 
L<Win32::OLE::Variant|http://search.cpan.org/~jdb/Win32-OLE-0.1712/lib/Win32/OLE/Variant.pm#Constants> (see last example).

=back


B<Return Values:>

=over

=item $result

Return value of the method call. Is either a scalar or an OLE object.

=item arguments passed by reference

If any arguments are passed by reference then they are additionaly returned in the order in which they were given.

=back

B<Examples:>

    my $result = CallObjMethod( $object, 'method1' );        
    my $result = CallObjMethod( $object, 'method2', [$scalarArg] );        
    my ($result, $integerByRef) = CallObjMethod( $object, 'method3', [$scalarArg, \@listOfStrings, $integerByRef], [0 , VT_ARRAY | VT_BSTR , VT_I4 | VT_BYREF] );        
    
=cut

sub CallObjMethod {
    my @args = @_;

    return unless S_checkFunctionArguments( 'CallObjMethod ( $object_mix, $methodName [, $methodArgs_aref, $argTypes_aref])', @args );
    my $object          = shift @args;
    my $methodName      = shift @args;
    my $methodArgs_aref = shift @args;
    my $argTypes_aref   = shift @args;
    my $result;

    #S_w2log( 5, "Calling method '$methodName' on object '$object' ...\n" );
    # Invoke the method
    if ( not defined $methodArgs_aref ) {

        #STEP On object $object_mix call method $methodName without arguments
        $result = $object->$methodName();
        #S_w2log( 5, "Call of method '$methodName' results in: '$result'\n" );
        return $result;
    }
    elsif ( not defined $argTypes_aref ) {

        #STEP On object $object_mix call method $methodName with argument array as it is (assuming only scalar arguments)
        $result = $object->$methodName(@$methodArgs_aref);
        #S_w2log( 5, "Call of method '$methodName' with arguments '@$methodArgs_aref' results in: '$result'\n" );
        return $result;
    }
    else {
        if ( scalar(@$methodArgs_aref) != scalar(@$argTypes_aref) ) {
            S_set_error( "Given number of arguments does not match given number of argument types.", 109 );
            return;
        }
        my @variantArgs;
        foreach my $argumentIndex ( 0 .. @$methodArgs_aref - 1 ) {
            my $argumentValue = $$methodArgs_aref[$argumentIndex];
            my $argumentType  = $$argTypes_aref[$argumentIndex];
            if ( $argumentType == 0 ) {
                push( @variantArgs, $argumentValue );
            }
            else {
                my $values_OLEvariant;
                if ( ref($argumentValue) eq 'ARRAY' ) {
                    $values_OLEvariant = Variant( $argumentType, scalar(@$argumentValue) );
                }
                else {
                    $values_OLEvariant = Variant( $argumentType, $argumentValue );
                }
                $values_OLEvariant->Put($argumentValue);
                push( @variantArgs, $values_OLEvariant );
            }
        }

        #STEP On object $object_mix call method $methodName with argument array
        $result = $object->$methodName(@variantArgs);
        my @returnList = ($result);
        foreach my $argumentIndex ( 0 .. @$methodArgs_aref - 1 ) {
            my $argumentType = $$argTypes_aref[$argumentIndex];
            if ( $argumentType & VT_BYREF ) {
                my $variant = $variantArgs[$argumentIndex];
                my $value   = $variant->Value();
                push( @returnList, $value );
            }
        }
        #S_w2log( 5, "Call of method '$methodName' with arguments '@$methodArgs_aref' results in: '@returnList'\n" );
        return @returnList;
    }

}

sub Dec2HexString {
    my $decNumber      = shift;
    my $numberOfDigits = shift;

    my $format;
    if ( defined $numberOfDigits ) {
        $format = '%0' . $numberOfDigits . 'X';
    }
    else {
        $format = '%X';
    }

    my $hexString = '0x' . sprintf( $format, $decNumber );

    return $hexString;
}

sub ResponseObj2href {
    my $response_obj       = shift;
    my $cdLayer_obj        = shift;
    my $onlyStatusExpected = shift;

    my $response_href = {};
    $lastResponse_href = $response_href;    # creates a global pointer to $response_href, so everything that will be done with $response_href
                                            # will be visible also in $lastResponse_href

    if ( $response_obj eq 'offline' ) {
        $response_href->{Id}               = 80;
        $response_href->{Length}           = 3;
        $response_href->{CdLength}         = 2;
        $response_href->{CompleteCdMsg}    = [ 2, 80, 1 ];
        $response_href->{ErrorDescription} = 'OK';
        $response_href->{Status}           = 0;
        return $response_href;
    }

    if ( ref($response_obj) ne 'Win32::OLE' and substr($response_obj, 0, 10) ne 'simulation' ) {    # $response_obj ne 'simulation' is to have no error in simulation mode, but 'simulation' has to be set actively using SIM_setReturnValues
        $response_href->{Status}           = -999;
        $response_href->{ErrorDescription} = "No Win32::OLE object returned from CDLayer.dll";
        return $response_href;
    }

    $response_href->{Status} = CallObjMethod( $response_obj, 'GetStatus' );

    if ( defined $response_href->{Status} ) {
        $response_href->{ErrorDescription} = CallObjMethod( $cdLayer_obj, 'GetErrorDescription', [ $response_href->{Status} ] );
    }
    else {
        $response_href->{Status}           = -998;
        $response_href->{ErrorDescription} = "No object status returned from CDLayer.dll";
        $onlyStatusExpected                = 1;
    }

    #In case of queue empty or timeout only status and error description is expected
    if ( $response_href->{ErrorDescription} =~ /$noResponseRegex/ ) {
        $onlyStatusExpected = 1;
    }

    if ($onlyStatusExpected) {
        $response_href->{Id}            = undef;
        $response_href->{Length}        = undef;
        $response_href->{CdLength}      = undef;
        $response_href->{CompleteCdMsg} = [];

        return $response_href;
    }

    my $method4attribute_href = {

        # <key of data hash> => <object method>
        'Id'            => 'Id',
        'Length'        => 'Length',
        'CdLength'      => 'CdLength',
        'FrameBytes'    => 'GetCompleteCdMsg',
        'TimeStamp'     => 'GetTimeStamp',
    };

    foreach my $key ( sort keys %{$method4attribute_href} ) {
        my $method = $method4attribute_href->{$key};
        #select(undef, undef, undef, 0.010);
        $response_href->{$key} = CallObjMethod( $response_obj, $method );
    }

    return $response_href;
}

sub SetComCdParam {
    my $comCdParam_obj = shift;
    my $busParams_href = shift;

    #LOOP-START Loop over keys of $busParams_href
    foreach my $busParameter ( keys %{$busParams_href} ) {

        #next if $busParameter eq 'name';
        my $value = $busParams_href->{$busParameter};

        #CALL CallObjMethod ($comCdParam_obj, 'SetParam', [ key, value ] )
        CallObjMethod( $comCdParam_obj, 'SetParam', [ $busParameter, $value ] );
    }

    #LOOP-END Last key?

    #STEP End
    return 1;
}

sub SendServiceReceiveResponse {
    my $diagHandle_href    = shift;
    my $serviceName        = shift;
    my $arguments_aref     = shift;
    my $argumentTypes_aref = shift;
    my $onlyStatusExpected = shift;

    my $handleName = $diagHandle_href->{name};

    my $argumentString = join( ' ', map { sprintf '%02X', $_ } @{$$arguments_aref[0]}); 
    S_w2log( 4, "SendServiceReceiveResponse: Sending service '$serviceName' to CDLayer handle '$handleName' with argument '$argumentString' ...\n" );

    my $response_href;
    if ($main::opt_offline) {
        $response_href = ResponseObj2href('offline');
        return $response_href;
    }

    #CALL CallObjMethod ($pdDiagHandle_href->{'OLE_handle'}, $serviceName, $arguments_aref) to get a response object
    my ($response_obj) = CallObjMethod( $diagHandle_href->{'OLE_handle'}, $serviceName, $arguments_aref, $argumentTypes_aref );

    #CALL ResponseObj2href (response object) to get a response hash
    $response_href = ResponseObj2href( $response_obj, $diagHandle_href->{'OLE_handle'}, $onlyStatusExpected );

    #STEP write complete response (if defined) to log
    if ( defined $response_href->{'FrameBytes'} and @{$response_href->{'FrameBytes'}} > 0) {
        my $completeMessageString = STR_Aref2HexString( $response_href->{'FrameBytes'} );
        S_w2log( 4, "SendServiceReceiveResponse: Received '$completeMessageString'\n" );
    }

    #CALL CheckResponseForError
    CheckResponseForError( $response_href, $serviceName, $handleName ) or return;

    if( not defined $response_href->{'FrameBytes'} ) {
        S_w2log( 4, "SendServiceReceiveResponse: Received no response\n" );
        $response_href->{'FrameBytes'} = [];
        return $response_href;
    }

    my @frameBytes = @{$response_href->{'FrameBytes'}};
    my @responseBytes;
    if( @frameBytes <= $bytesPerFrame ) {
        # single frame response
        my $length = $frameBytes[0];
        @responseBytes = @frameBytes[1 .. $length];
    }
    else{
        # consecutive frames
        shift @frameBytes; # remove first byte added by CDLayer.dll
        while( @frameBytes > 0 ){
            shift @frameBytes; # remove header byte
            my @bytes = splice(@frameBytes, 0, $bytesPerFrame-1);
            push( @responseBytes, @bytes );
        }
    }
    $response_href->{'ResponseBytes'} = \@responseBytes;

    #STEP Return response hash
    return $response_href;
}

=head2 CheckResponseForError

    $success = CheckResponseForError($response_href, $serviceName, $handleName);

Checks if an error needs to be thrown for response $response_href and service $serviceName.
If so it creates the error message and throws the error.

Returns 1 if the response is no error, otherwise undef. 

=cut

sub CheckResponseForError {
    my $response_href = shift;
    my $serviceName   = shift;
    my $handleName    = shift;

    my $responseStatus = $response_href->{Status};

    #STEP if service is "SendReceiveData" and status is -941 then do not throw an error
    if ( $responseStatus == -911 and $serviceName eq "SendReceiveSingleFrame" ) {
        #S_w2log( 4, "SendServiceReceiveResponse: No response received on request 'SendReceiveSingleFrame'.\n" );
        return 1;
    }

    #IF response status is < 0 or == 160?
    if ( $responseStatus < 0 or $responseStatus == 160 ) {

        #IF-YES-START
        #STEP set general error text
        my $errorDescription = $response_href->{ErrorDescription};
        my $errorText        = "Response status '$responseStatus' after sending service '$serviceName' to CDLayer handle '$handleName'. Error description: $errorDescription";

        #STEP special error text for status -974 (no PIN)
        if ( $responseStatus == -974 ) {
            $errorText = "ECU is locked but no PIN was provided for secure login using smartcard and PIN. Please call the function for secure PIN entry before diagnosis login.\n" . $errorText;
        }

        #STEP special error text for status 160 (wrong PIN)
        elsif ( $responseStatus == 160 ) {
            $errorText =
"ECU is locked and wrong PIN was provided for secure login using smartcard and PIN. Please repeat the test and provide the correct PIN for the given smartcard. Please note that the smartcard is locked after 3 times providing the wrong PIN. In such cases also this error will come. To check if a smartcard is locked can be done using C:\\ubkpki_pkcs11provider\\MiddlewareVerifier.exe. If the smartcard is locked you can unlock it using your PUK according to the procedure shown in the link under point 7: https://inside-docupedia.bosch.com/confluence/display/escryptitoperations/Smartcard+Guide .\n"
              . $errorText;
        }

        #STEP special error text for no response
        elsif ( $errorDescription =~ /$noResponseRegex/ ) {
            $errorText = "No (proper) response from ECU.
            This may be due to any of the below reasons:
            1. ECU is OFF at this instant (most probable if communication was successful before)
            2. In project const section: 'ProdDiag' a wrong 'ProjectName' is configured
            3. In LIFT_testbenches.pm section: 'Devices' => 'CDLayer' a wrong 'BusType', 'Channel_Nbr_0-based' or 'Hw_Serial_Nbr' is given
            \n" . $errorText;
        }

        #STEP Throw error and return
        S_set_error( $errorText, 109 );
        #return;

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    #STEP return 1
    return 1;
}

sub AddMemoryData2Response {
    my $response_href = shift;
    my $format_data_by_endianness = shift // 1;

    # get data bytes from payload
    my $payload_aref = $response_href->{PdPayload};
    my @dataBytes    = @$payload_aref;
    shift @dataBytes;    # remove ID

    if ($main::opt_offline) {
        $response_href->{DataBytes} = [1];
        return [1];
    }

    # correct order of bytes in data, depending on endianness
    my $dataBytesCorr_aref;
    if ($format_data_by_endianness) {

        # correct for endianness
        $dataBytesCorr_aref = FormatMemoryDatabyEndianness( \@dataBytes );
    }
    else {
        # take data bytes as they are
        $dataBytesCorr_aref = \@dataBytes;
    }

    $response_href->{DataBytes} = $dataBytesCorr_aref;

    return $dataBytesCorr_aref;
}

sub CatchOleException {
    my $errorText = Win32::OLE->LastError();

    return 1 if $errorText !~ /CDLayer/; # only react on OLE exceptions from CDLayer

    if ( $errorText =~ /Invalid pointer|Invalid index/ ) {
        S_w2log( 3, "$errorText" );
    }
    else {
        S_set_error( "$errorText", 23 );
    }
    return;
}

=head2 CheckRegisteredCOMdll

    $success = CheckRegisteredCOMdll( $dllName );
    
Check if path and version of the registered COM dll ($dllName) matches the corresponding Engine dll.

    If path of registered dll == path of Engine dll then OK.
    Else:
        If version of the registered dll == version of the Engine dll then OK
        If version of the registered dll > version of the Engine dll then OK, but Warning
        If version of the registered dll < version of the Engine dll then Error

B<Arguments:>

=over

=item $dllName

Program ID of the registered CDLayer dll

=back

B<Return Values:>

=over

=item $success

1 on success, undef otherwise

=back

B<Note: Not exported function>

=cut

sub CheckRegisteredCOMdll {
    my $dllName = shift;

    #CALL LIFT_general::S_get_version_and_path_of_registered_COM_dll with $dllName
    my $versionPathRegisteredDll_href = S_get_version_and_path_of_registered_COM_dll($dllName);

    #STEP Error if $dllName is not registered
    if ( not defined $versionPathRegisteredDll_href->{fullPath} ) {
        S_set_error( "CDLayer.dll ($dllName) is not registered as COM dll on this computer. Please run in your sandbox 'Engine\\run_once\\register_com_dlls.bat' as administrator to register the version of CDLayer.dll in your sandbox.", 109 );
        return;
    }
    S_w2log( 3, "CDL_init: Using registered dll " . $versionPathRegisteredDll_href->{fullPath} . " version " . $versionPathRegisteredDll_href->{version} . "\n" );

    #CALL LIFT_general::S_get_version_and_path_of_dll_on_file_system with absolute path of registered dll
    my $realVersionPathRegisteredDll_href = S_get_version_and_path_of_dll_on_file_system( $versionPathRegisteredDll_href->{fullPath} );
    S_w2log( 3, "CDL_init: Real version of registered dll on disk is " . $realVersionPathRegisteredDll_href->{version} . "\n" );

    #CALL LIFT_general::S_get_version_and_path_of_dll_on_file_system with relative path of registered dll
    my $versionPathEngineDll_href = S_get_version_and_path_of_dll_on_file_system( $versionPathRegisteredDll_href->{relativePath} );

    #IF path of registered dll != path of Engine dll?
    if ( $versionPathRegisteredDll_href->{fullPath} ne $versionPathEngineDll_href->{fullPath} ) {

        #IF-YES-START
        S_w2log( 3, "CDL_init: INFO:     Engine dll " . $versionPathEngineDll_href->{fullPath} . " is not the registered dll.\n" );

        #STEP Throw error if version of the registered dll < version of the Engine dll and return
        if ( version->parse( $realVersionPathRegisteredDll_href->{version} ) < version->parse( $versionPathEngineDll_href->{version} ) ) {
            S_set_error(
                "The version number ("
                  . $realVersionPathRegisteredDll_href->{version}
                  . ") of the registered dll ("
                  . $versionPathRegisteredDll_href->{fullPath}
                  . ")\n is lower than the version number ("
                  . $versionPathEngineDll_href->{version}
                  . ") of the Engine dll ("
                  . $versionPathEngineDll_href->{fullPath}
                  . ").\nPlease run in your sandbox 'Engine\\run_once\\register_com_dlls.bat' as administrator to register the version of CDLayer.dll in your sandbox.",
                109
            );
            return;
        }

        #STEP Throw warning if version of the registered dll > version of the Engine dll
        elsif ( version->parse( $realVersionPathRegisteredDll_href->{version} ) > version->parse( $versionPathEngineDll_href->{version} ) ) {
            S_set_warning( "The version number ("
                  . $realVersionPathRegisteredDll_href->{version}
                  . ") of the registered dll ("
                  . $versionPathRegisteredDll_href->{fullPath}
                  . ")\n  is higher than the version number ("
                  . $versionPathEngineDll_href->{version}
                  . ") of the Engine dll ("
                  . $versionPathEngineDll_href->{fullPath}
                  . ").\nYou may want to run in your sandbox 'Engine\\run_once\\register_com_dlls.bat' as administrator to register the version of CDLayer.dll in your sandbox." );
        }

        #STEP Print info if version of the registered dll == version of the Engine dll
        else {
            S_w2log( 3, "CDL_init: The registered dll and the Engine dll have the same version number (" . $realVersionPathRegisteredDll_href->{version} . "). Looks OK.\n" );
        }

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    #STEP Return 1
    return 1;
}

############################################################################################################
#
#
# Simulation mode
#
#
############################################################################################################

if ($main::opt_simulation) {

    my @redefinedFunctions = qw(
      GetOleObject
      GetObjProperty
      SetObjProperty
      CallObjMethod
    );

    # redefine functions for simulation mode with default return values
    foreach my $function (@redefinedFunctions) {
        no strict 'refs';

        # each function specifed is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {};
    SIM_addToValuesTable($returnValuesTable_href);
}

1;
