# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CD_CANoeCANFD;

use strict;
use warnings;
use LIFT_general;
use LIFT_can_access;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  CD_CANoeCANFD_init
  CD_CANoeCANFD_exit
  CD_CANoeCANFD_start_simulation
  CD_CANoeCANFD_send_message
  CD_CANoeCANFD_stop_message
  CD_CANoeCANFD_send_request_wait_response
  CD_CANoeCANFD_send_request_get_all_response_timestamp
  CD_CANoeCANFD_set_addressing_mode
);

our ( $VERSION, $HEADER );

my $mapCANoeCDPanel_EnvVar_href = {

    'TesterPresent' => 'EvTesterPresentTx',    # flag tester present
                                               # 'TesterPresent_Cyclic' => '4800',    # cyclic value for Tester present

    'Message_CycleTime'   => 'ENV_CyclicMsgFrequency',
    'EnableCyclicMessage' => 'ENV_Enable_Cyclic_Message',

    'RequestData'  => 'EvTxMesgBox',
    'ResponseData' => 'EvRxMesgBox',
    'SendData'     => 'EvTxButton',

    'AddressingMode' => 'EvFunc',

    # 'TesterAddress'  => 'EvFunc',

    'Default_Session'     => '',
    'Extended_Session'    => '',
    'Programming_Session' => '',

    'ECU-Lock'   => '',
    'ECU-UnLock' => '',

};

my $cd_CANoeCANFD_disabled;
my $cd_CANoeCANFD_initialized;
my $cd_CANoeCANFD_RequestID;     # req ID
my $cd_CANoeCANFD_ResponseID;    # resp ID
my $cd_CANoeCANFD_FlowControlID;
my $cd_CANoeCANFD_Timeout;
my $cd_CANoeCANFD_P3_mintime;

# my $cd_CANoeCANFD_addressingMode_aref;
# my $cd_CANoeCANFD_testerAddr_aref;

=head1 NAME

LIFT_CD_CANoeCANFD $Revision: 1.2
 
=head1 SYNOPSIS

    use LIFT_CD_CANoeCANFD

    CD_CANoeCANFD_init();
    CD_CANoeCANFD_exit();
    CD_CANoeCANFD_start_simulation();    
    ($response_aref, $time_aref) = CD_CANoeCANFD_send_request_wait_response( $request_aref [, $RequestID [, $flowcontrol_ID [, $ResponseID [, $Timeout_ms ]]]] );

=head1 DESCRIPTION

Perl extension for Customer Diagnosis using CANoe FlexRay as an interface.


=head2 ProjectConst:
    
    'CUSTOMER_DIAGNOSIS' => {
        'RequestID_physical'      => '0x6dc',           #as hex string
        'ResponseID_physical'     => '0x4fc',           #as hex string
        'FlowControlID_physical'  => '0x6dc',           #as hex string
        'Timeout_physical'        => 10000,             #in milliseconds
        'P3_mintime_physical'     => 200,               #in milliseconds(by default its 0)
        'AddressingMode_physical' => 'physical',        # default is physical
        'TesterAddress_physical'  => 'functional',      # default is functional 

        'RequestID_functional'     => '0x6dc',          #as hex string
        'ResponseID_functional'    => '0x4fc',          #as hex string
        'FlowControlID_functional' => '0x6dc',          #as hex string
        'Timeout_functional'       => 10000,            #in milliseconds
        'P3_mintime_functional'    => 400,              #in milli seconds (by default its 0)
        'AddressingMode_functional' => [ 0xFF, 0xFF ],    # 2 bytes as array ref, dummy values
        'TesterAddress_functional'  => [ 0xEF, 0xEF ],    # 2 bytes as array ref, dummy values 

        'AddressingMode_disposal' => [ 0xAA, 0xAA ],    # 2 bytes as array ref, dummy values
        'TesterAddress_disposal'  => [ 0xBB, 0xBB ],    # 2 bytes as array ref, dummy values        

        'FlowControl' => [ 0x30, 0x0f, 0x01 ],          #3 Bytes as array ref
        'clearDTC' => [ 0x14, 0xff, 0xff, 0xff ],       #Bytes as array ref
        'SAM'                   => 1,
        'SJW'                   => 3,
        'Tseg1'                 => 0xc,
        'Tseg2'                 => 3,
        'Baudrate'              => 500000,
        'DLCmode'               => 0,                   # 0 for 8 byte, 1 for dynamic DLC
        'DTCdefaultstate'       => 0x8,
        'DTCdefaultsubfunction' => 0x2,
        'DTCbytes'              => 3,                   # bytes per DTC
        'ExtID'                 => 0,                   # 1 for Extended Identifier, 0 for Standard
        'ExtAddressing'         => 1,                   # 1 for Extended Addressing, 0 for Normal
        'EcuAddr'               => 0x01,                # ECU id for Extended Addressing.
        'TargetAddr'            => 0xF1,                # Target address for Extended Addressing.

        'DISABLE' => 0,                                 # optional, to disable all CD features (similar to offline mode)
    },

=head2 TestBench Config:
   
    'Devices' => {
      'CANoe' => {
        'Hostname'      => 'BMH1045912',
        'Online_Config' => 'C:\TurboLIFT_TSG4\Engine\test\CANoe\LIFT_CAN_access\COMDemo.cfg',
        'Log_File'      => 'C:\temp\CANOE_log.asc',
      },
    },

   'Functions' => {
        'CD'         => 'CANoeCANFD',
        'CAN_Access' => {
            'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
            'stimulate' => 'CANoe',    # function groups: Stimulate signals ,CAPL
        }
   },


=head1 FUNCTIONS

=head2 CD_CANoeCANFD_init

    CD_CANoeCANFD_init ();

Initialize customer diagnosis via CANoe FlexRay.     

B<Examples:>

    CD_CANoeCANFD_init();

B<Notes:> 

- CANoe must be running before calling the function see Function section of LIFT_CAN_access

=cut

sub CD_CANoeCANFD_init {
    $cd_CANoeCANFD_disabled = Rd_CD_ProjConstEntry('DISABLE');
    $cd_CANoeCANFD_disabled = 0 if not defined $cd_CANoeCANFD_disabled;    # set default

    if ($cd_CANoeCANFD_disabled) {
        S_w2log( 3, "CD_CANoeCANFD_init skipped because CD is DISABLED\n" );
        return 1;
    }

    if ($cd_CANoeCANFD_initialized) {
        S_set_warning("CD via CD_CANoeCANFD_init already initialized");
        return;
    }

    if ($main::opt_offline) {
        S_w2log( 4, "CD_CANoeCANFD_init : Initialized successfully \n" );
        $cd_CANoeCANFD_initialized = 1;
        return 1;
    }

    CA_init();
    $cd_CANoeCANFD_initialized = 1;
    S_w2log( 3, "CD_CANoeCANFD_init: Initialized successfully \n" );
    return 1;
}

=head2 CD_CANoeCANFD_exit

    CD_CANoeCANFD_exit ();

Uninitializes the customer diagnosis via CANoe FlexRay. Basically sets the flags to 0.   

B<Examples:>

    CD_CANoeCANFD_exit ();

=cut

sub CD_CANoeCANFD_exit {
    $cd_CANoeCANFD_initialized = 0;

    if ($cd_CANoeCANFD_disabled) {
        S_w2log( 3, "CD_CANoeCANFD_exit skipped because CD is DISABLED\n" );
        return 1;
    }

    unless ($cd_CANoeCANFD_initialized) {
        S_set_error( "CD via CD_CANoeCANFD_init is not initialized", 0 );
        return;
    }

    #reset flags
    $cd_CANoeCANFD_initialized = 0;
    S_w2log( 4, "CD_CANoeCANFD_exit: terminated \n" );

    return 1;
}

=head2 CD_CANoeCANFD_start_simulation

    CD_CANoeCANFD_start_simulation();
    
CD 'physical' request settings are taken as default. It can be changed by L</"CD_CANoeCANFD_set_addressing_mode">.

It starts the CANoe measurement if not running before.

B<Examples:>

    CD_CANoeCANFD_start_simulation();

=cut

sub CD_CANoeCANFD_start_simulation {
    S_w2log( 4, "CD_CANoeCANFD_start_simulation start \n" );

    if ($cd_CANoeCANFD_disabled) {
        S_w2log( 3, "CD_CANoeCANFD_start_simulation skipped because CD is DISABLED\n" );
        return 1;
    }

    unless ($cd_CANoeCANFD_initialized) {
        S_set_error( "CD via CD_CANoeCANFD_init is not initialized", 131 );
        return;
    }

    CA_simulation_start() if not CA_trace_check_running();

    my $canscript = shift;
    if ( defined $canscript ) {
        S_set_error( "CANscript was not used for CD_CANoeCANFD", 0 );
        return 0;
    }

    CD_CANoeCANFD_set_addressing_mode('physical');

    # if needed add it later
    # $FlowControl= Rd_CD_ProjConstEntry('FlowControl');
    # if     ( ref($FlowControl) ne "ARRAY" ) { S_set_error( " FlowControl is not an array reference", 114 ); return 0; }

    return 1;
}

=head2 CD_CANoeCANFD_send_message

    $msg_handle = CD_CANoeCANFD_send_message( $request_aref, $msg_ID, $cycletime_ms ); 

Sends any request or Tester Present Message cyclically.

B<Arguments:>

=over

=item $request_aref

Array reference to the request array, Pass a empty request array to send Tester present

=item $msg_ID

(optional) Unused for this module. Hardcoded value in CAPL, Kept for the compatibility with LIFT_CD_CAN.  

=item $cycletime_ms

Cycle time to send message cyclically $cycletime_ms

=back

B<Return Values:>

=over

=item $msg_handle 

Success : Returns the message handle of the message sent

Returns undef on error condition

=back

B<Examples:>

$msg_handle = CD_send_message( [0x80,0x40], 0x650 , 400 );

$msg_handle_TesterPresent = CD_send_message( [] , 0x650 , 800 );

0x650 => Dummy request ID

B<Notes:>

To stop sending message, use L</CD_CANoeCANFD_stop_message>

CD_CANoeCANFD_stop_message($msg_handle);

=cut

sub CD_CANoeCANFD_send_message {
    my @args = @_;

    # STEP Get the input message and cycletime as parameters, Ignore Msg Request ID - This request ID in can. In flex ray, this is slot ID and initiallized in CAPL
    # STEP Check if CANoe FR is initialized
    # IF request is filled or empty
    # IF-YES-START
    #      STEP Reset the SendData ENV variable to 0
    #      STEP Set the request messsage to CAPL
    #      STEP Enable sending of cyclic message
    #      STEP Set message handle of cyclic message
    # IF-YES-END
    # IF-NO-START
    #      STEP Enable Tester Present Environment variable
    #      STEP Set Message handle
    # IF-NO-END
    # STEP return message handle of tester present

    S_checkFunctionArguments( 'CD_CANoeCANFD_send_message( $payload_aref, $msg_ID, $cycletime_ms )', @args ) or return;
    my $payload_aref = shift @args;
    my $requestID    = shift @args;
    my $cycletime    = shift @args;
    my $msg_handle;

    if ($cd_CANoeCANFD_disabled) {
        S_w2log( 1, "CD_CANoeCANFD_send_message skipped because CD is DISABLED\n" );
        return;
    }

    unless ($cd_CANoeCANFD_initialized) {
        S_set_error( "CD not initialized", 120 );
        return;
    }

    if ( ( scalar @$payload_aref ) > 0 ) {
        Set_CDcmd_To_EnvVar( 'SendData', 0 );

        # Set_CDcmd_To_EnvVar( 'AddressingMode', $cd_CANoeCANFD_addressingMode_aref ); # default physical in CAPL, evn variable EvnFunc
        Set_CDcmd_To_EnvVar( 'RequestData', $payload_aref );
        Set_CDcmd_To_EnvVar( 'SendData',    1 );
        if ( $cycletime > 0 ) {
            Set_CDcmd_To_EnvVar( 'Message_CycleTime',   $cycletime );    # cyclic duration for Cyclic message
            Set_CDcmd_To_EnvVar( 'EnableCyclicMessage', 1 );             # Enable Cyclic Message
        }

        $msg_handle = 'EnableCyclicMessage';

    }
    else {
        # Set_CDcmd_To_EnvVar( 'TesterPresent_Cyclic', $cycletime );                        # cyclic value for Tester present
        Set_CDcmd_To_EnvVar( 'TesterPresent', 1 );                       #send out Tester Present function mode in CAPL                              # Enable tester present
        $msg_handle = 'TesterPresent';
    }
    return $msg_handle;
}

=head2 CD_CANoeCANFD_stop_message

    CD_CANoeCANFD_stop_message($msg_handle);
    
stop cyclic message referred by $MSG_handle

B<Arguments:>

=over

=item $msg_handle

Message handle obtained from L</CD_CANoeCANFD_send_message>

=back

=cut

sub CD_CANoeCANFD_stop_message {
    my @args = @_;
    S_checkFunctionArguments( 'CD_CANoeCANFD_stop_message($msg_handle)', @args ) or return;
    my $msg_handle = shift @args;
    Set_CDcmd_To_EnvVar( $msg_handle, 0 );    # Disable tester present
    return 1;
}

=head2 CD_CANoeCANFD_send_request_wait_response

    ($response_aref, $time_aref) = CD_CANoeCANFD_send_request_wait_response( $request_aref [, $RequestID [, $flowcontrol_ID [, $ResponseID [, $Timeout_ms ]]]] );

Sends request and waits for response. 

B<Arguments:>

=over

=item $request_aref

Array reference to the request array

=item $RequestID

(optional) Unused for this module. Hardcoded value in CAPL, Kept for the compatibility with LIFT_CD_CAN.  

=item $flowcontrol_ID

(optional) Unused for this module. Hardcoded value in CAPL, Kept for the compatibility with LIFT_CD_CAN.

=item $ResponseID

(optional) Unused for this module. Hardcoded value in CAPL, Kept for the compatibility with LIFT_CD_CAN.

=item $Timeout_ms

(optional) Unused for this module. Hardcoded value in CAPL, Kept for the compatibility with LIFT_CD_CAN.

=back

B<Return Values:>

=over

=item $status 

Success : Returns the status of the obtained response

Returns 0 if Got positive response

Returns 1 if Got response after pending

Returns 2 if Got negative response

=item $time_aref 

unused

=item $response_aref 

Success : Returns reference of response array => response data (or) [] if receive timeout

Offline : (1, [], [] )

Error : undef

=back

B<Examples:>

B<Notes:> 

=cut

sub CD_CANoeCANFD_send_request_wait_response {
    my @args = @_;
    return ( undef, [], [] ) unless S_checkFunctionArguments( 'CD_CANoeCANFD_send_request_wait_response( $request_aref [, $RequestID [, $flowcontrol_ID [, $ResponseID [, $Timeout_ms ]]]] )', @args );
    my $request_aref   = shift @args;
    my $RequestID      = shift @args;
    my $flowcontrol_ID = shift @args;
    my $ResponseID     = shift @args;
    my $Timeout_ms     = shift @args;

    if ($cd_CANoeCANFD_disabled) {
        S_w2log( 1, "CD_CANoeCANFD_send_request_wait_response skipped because CD is DISABLED\n" );
        return ( undef, [], [] );
    }

    unless ($cd_CANoeCANFD_initialized) {
        S_set_error( "CD not initialized", 120 );
        return ( undef, [], [] );
    }
	
    Set_CDcmd_To_EnvVar( 'SendData', 0 );    #reset the value

    my ($response_aref);
	# Set_CDcmd_To_EnvVar( 'AddressingMode', $cd_CANoeCANFD_addressingMode_aref ); 
	Set_CDcmd_To_EnvVar( 'RequestData', $request_aref );
    Set_CDcmd_To_EnvVar( 'SendData',    1 );

    # fill some dummy data for offline
    return ( 1, [], [] ) if ($main::opt_offline);

    my $time_ms_elasped;
    my $response_status = 0;

    # Try to get the response data
    foreach ( (200, 500, 1000, 1500 ) ) {
        S_wait_ms($_);
        $response_aref = Get_CDcmd_From_EnvVar('ResponseData');

        # no data , try again
        next if scalar @$response_aref == 0;

        $time_ms_elasped += $_;
        if ( $response_aref->[0] == 0x7F ) {

            # Response pending ..
            if ( $response_aref->[2] == 0x78 ) {
                my @hex_resp_pending = DecBytes_2_formatted_hex_str($response_aref);
                S_w2log( 4, "Response = '@hex_resp_pending' is still pending after '$time_ms_elasped ms' Now trying again to get the data.. ", 'blue' );
                $response_status = 1;
            }
            else {
                $response_status = 2;    # got negative response
                S_w2log( 3, "Received NRC (other than response pending '0x78') = 0x" . sprintf( "%02X", $response_aref->[2] ), 'blue' );
                last;                    # exit the loop if the NRC is other than 0x78.
            }
        }

        last if ( $response_aref->[0] != 0x7F );    # positive response
    }

    if ( scalar @$response_aref == 0 ) {
        S_set_error( "CD_CANoeCANFD_send_request_wait_response - response not obtained even after 3.3 sec (100 + 200 + 500 + 1000 + 1500 , ms) \n", 0 );
        $response_status = 3;                       #no response.
    }

    # check the response status
    if ( $response_status == 1 ) {
        S_w2log( 3, "CD_CANoeCANFD_send_request_wait_response  : got response after pending\n",, 'blue' );
    }
    elsif ( $response_status == 2 ) {
        S_w2log( 3, "CD_CANoeCANFD_send_request_wait_response : got negative response\n", 'blue' );
    }
    elsif ( $response_status == 3 ) {
        S_w2log( 3, "CD_CANoeCANFD_send_request_wait_response : got no response\n", 'blue' );
        return ( $response_status, [], [] );
    }

    my @hex_resp = DecBytes_2_formatted_hex_str($response_aref);
    S_w2log( 3, "CD_CANoeCANFD_send_request_wait_response <-Response (" . scalar(@hex_resp) . ") @hex_resp\n", 'blue' );

    my $time_aref;    # un-used values

    return ( $response_status, $time_aref, $response_aref );
}

=head2 CD_CANoeCANFD_send_request_get_all_response_timestamp

    ($status, $response_timestamp_href) = CD_CANoeCANFD_send_request_get_all_response_timestamp( $request_aref [,$options_href] )     

Sends request and fetches response. Sends flow control, if response is of Multiple frames (response code : 0x78)

Fetches all types of response(negative/positive/pending) and their coressponding inter-Can-frame timings 

B<Arguments:>

=over

=item $request_aref 

Array reference to the request array

=item $options_href 

(optional) This is a hash reference containing the values for optional parameters.

Below are the optional parameters in the hash reference
           
=> $options_href->{'Manipulated_length'} : This holds the value to manipulate the request length(valid range = 0-255(0x00-0xFF))
                                           and if the value is not provided , then the request length will not be manipulated.

=back

B<Return Value:>

=over

=item $status 

Success : Returns the status of the obtained response

Returns 0 if Got positive response

Returns 1 if Got response after pending

Returns 2 if Got negative response

Returns undef if Got no response

Offline : 1

Error : undef

=item $response_timestamp_href 

Success : Returns Hash reference of all response and their respective inter-CAN-frame timings (with precision of +2 or -2 ms) in milliseconds
          $response_timestamp_href->{$response_sequence}->{time} = [response];

Offline : {}

Error : undef

=back

B<Examples:>

    (1, $response_timestamp_href) = CD_CANoeCANFD_send_request_get_all_response_timestamp( [0x19,0x1,0x20] );
    
    $options_href->{'Manipulated_length'} = '0x03'
    (1, $response_timestamp_href) = CD_CANoeCANFD_send_request_get_all_response_timestamp( [0x19,0x1,0x20], $options_href);

=cut

sub CD_CANoeCANFD_send_request_get_all_response_timestamp {

    my @args = @_;
    return ( undef, undef ) unless S_checkFunctionArguments( 'CD_CANoeCANFD_send_request_get_all_response_timestamp( $request_aref [,$options_href] )', @args );

    my $request_aref = shift @args;
    my $options_href = shift @args;

    S_set_error( "CD_CANoeCANFD_send_request_get_all_response_timestamp : This function is not yet implemented.Please raise a request", 120 );
    return ( undef, undef );
}

=head2 CD_CANoeCANFD_set_addressing_mode

    ($RequestID, $FlowControlID, $ResponseID, $Timeout, $P3_mintime) = CD_CANoeCANFD_set_addressing_mode( $address_mode );

sets the addressing mode to $address_mode

B<Arguments:>

=over

=item $address_mode

Address mode to be set. shall be either physical, functional or disposal (case sensitive).

=back

B<Return Values:>

=over

=item $RequestID 

Request ID from the project constant.

=item $FlowControlID

Flow Control ID from the project constant.

=item $ResponseID

Response ID from the project constant.

=item $Timeout

Timeout from the project constant.

=item $P3_mintime

Mintime from the project constant.

=back

B<Examples:>

    ($RequestID, $FlowControlID, $ResponseID, $Timeout, $P3_mintime) = CD_CANoeCANFD_set_addressing_mode( 'physical' );

=cut

sub CD_CANoeCANFD_set_addressing_mode {
    my @args = @_;
    S_checkFunctionArguments( 'CD_CANoeCANFD_set_addressing_mode( $address_mode )', @args ) or return;
    my $address_mode = shift @args;

    if ($cd_CANoeCANFD_disabled) {
        S_w2log( 3, "CD_CANoeCANFD_set_addressing_mode skipped because CD is DISABLED\n" );
        return;
    }

    # supported address mode is : $address_mode
    my @supportedAddrMode = qw (physical functional disposal);
    unless ( $address_mode =~ /^(physical|functional|disposal)$/i ) {
        S_set_error( "CD_CANoeCANFD_set_addressing_mode - passed address mode = '$address_mode' is not valid. It must be one of these '@supportedAddrMode'", 109 );
        return;
    }

    # all mandatory entries
    return unless defined( $cd_CANoeCANFD_RequestID     = Rd_CD_ProjConstEntry( 'RequestID_' . $address_mode,     { 'SetErrIfNotFound' => 'Yes' } ) );
    return unless defined( $cd_CANoeCANFD_ResponseID    = Rd_CD_ProjConstEntry( 'ResponseID_' . $address_mode,    { 'SetErrIfNotFound' => 'Yes' } ) );
    return unless defined( $cd_CANoeCANFD_FlowControlID = Rd_CD_ProjConstEntry( 'FlowControlID_' . $address_mode, { 'SetErrIfNotFound' => 'Yes' } ) );
    return unless defined( $cd_CANoeCANFD_Timeout       = Rd_CD_ProjConstEntry( 'Timeout_' . $address_mode,       { 'SetErrIfNotFound' => 'Yes' } ) );
    return unless defined( $cd_CANoeCANFD_P3_mintime    = Rd_CD_ProjConstEntry( 'P3_mintime_' . $address_mode,    { 'SetErrIfNotFound' => 'Yes' } ) );
    if ( $cd_CANoeCANFD_P3_mintime < 0 ) {
        S_set_error( "! 'P3_mintime_' . $address_mode is -ve. 'P3_mintime_' . $address_mode set to Zero", 0 );
        $cd_CANoeCANFD_P3_mintime = 0;
    }
    if ( $address_mode eq 'functional' ) {
        Set_CDcmd_To_EnvVar( 'AddressingMode', 1 );
    }
    elsif ( $address_mode eq 'physical' ) {
        Set_CDcmd_To_EnvVar( 'AddressingMode', 0 );    #default mode is physcial in CAPL, env variable EvnFunc=0;
    }

    my $infoMsg = "Request ID: $cd_CANoeCANFD_RequestID, Flowcontrol ID: $cd_CANoeCANFD_FlowControlID, Response ID: $cd_CANoeCANFD_ResponseID, Timeout: $cd_CANoeCANFD_Timeout millisecond(s) , " . "P3_mintime: $cd_CANoeCANFD_P3_mintime milliseconds(s), AddressingMode: $address_mode";
    S_w2log( 4, "CD addressing mode set to '$address_mode'\n -> $infoMsg \n" );

    return ( $cd_CANoeCANFD_RequestID, $cd_CANoeCANFD_FlowControlID, $cd_CANoeCANFD_ResponseID, $cd_CANoeCANFD_Timeout, $cd_CANoeCANFD_P3_mintime, $address_mode );
}

sub Set_CDcmd_To_EnvVar {
    my @args = @_;
    S_checkFunctionArguments( 'Set_CDcmd_To_EnvVar( $cd_cmd, $cd_cmd_Value_mix )', @args ) or return;
    my $cd_cmd       = shift @args;
    my $cd_cmd_Value = shift @args;

    if ( my $envVar_CDcmd = $mapCANoeCDPanel_EnvVar_href->{$cd_cmd} ) {
        S_w2log( 5, "set $cd_cmd :- $envVar_CDcmd - $cd_cmd_Value.", 'grey' );
        CA_set_EnvVar_value( $envVar_CDcmd, $cd_cmd_Value );
    }
    else {
        S_set_error( "Set_CDcmd_To_EnvVar : Mapping to Envionemnt variable for '$cd_cmd' not found", 0 );
    }
    return 1;
}

sub Get_CDcmd_From_EnvVar {
    my @args = @_;
    S_checkFunctionArguments( 'Get_CDcmd_From_EnvVar( $cd_cmd )', @args ) or return;
    my $cd_cmd = shift @args;

    my $cdCmd_EnvValue;
    my $envVar_CDcmd;
    if ( $envVar_CDcmd = $mapCANoeCDPanel_EnvVar_href->{$cd_cmd} ) {
        $cdCmd_EnvValue = CA_get_EnvVar_value($envVar_CDcmd);
    }
    else {
        S_set_error( "Get_CDcmd_From_EnvVar : Mapping to Envionemnt variable for '$cd_cmd' not found", 0 );
    }

    if ( $cdCmd_EnvValue =~ /ARRAY/i ) {
        S_w2log( 5, "Get $cd_cmd :- $envVar_CDcmd - @$cdCmd_EnvValue." );
    }
    else {
        S_w2log( 5, "Get $cd_cmd :- $envVar_CDcmd - $cdCmd_EnvValue." );
    }

    return $cdCmd_EnvValue;
}

sub Rd_CD_ProjConstEntry {
    my @args = @_;
    S_checkFunctionArguments( 'Rd_CD_ProjConstEntry( $cdPrjCont_entry, [$options_href] )', @args ) or return;
    my $cdPrjCont_entry       = shift @args;
    my $options_href          = shift @args;
    my $read_CD_PrjCont_value = S_get_contents_of_hash_NOERROR( [ 'CUSTOMER_DIAGNOSIS', $cdPrjCont_entry ] );

    if ( defined $options_href->{'SetErrIfNotFound'} ) {
        unless ( defined $read_CD_PrjCont_value ) {
            S_set_error( "CD CANoeCANFD : Entry '$cdPrjCont_entry' for CUSTOMER_DIAGNOSIS not found in ProjectConst. ", 114 );
            return;
        }
    }

    # Check if array reference
    if ( defined $options_href->{'CheckIfArrayRef'} ) {
        if ( ref $read_CD_PrjCont_value ne 'ARRAY' ) {
            S_set_error( "CD CANoeCANFD : Entry '$cdPrjCont_entry' for CUSTOMER_DIAGNOSIS is not an array reference. ", 114 );
            return;
        }
    }

    return $read_CD_PrjCont_value;
}

sub DecBytes_2_formatted_hex_str {
    my @args = @_;
    S_checkFunctionArguments( 'DecBytes_2_formatted_hex_str( $response_aref )', @args ) or return;
    my $response_aref = shift @args;
    my @hex_resp      = (@$response_aref);
    foreach (@hex_resp) { $_ = "0x" . sprintf( "%02X", $_ ); }
    return @hex_resp;
}

1;
