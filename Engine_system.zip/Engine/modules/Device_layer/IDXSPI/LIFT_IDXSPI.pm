# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_IDXSPI;

use strict;
use warnings;
use LIFT_general;
use File::Basename;
my $addpath;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['./Win32'], ['./Win32']);
}

use IDXSPI;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_IDEFIX ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  IXS_CloseHW
  IXS_DecodeEEPROM
  IXS_ExportCSV
  IXS_GetValues
  IXS_InitHW
  IXS_SetOutput
  IXS_SetSPIConfiguration
  IXS_StartRecording
  IXS_StopRecording
);

our ( $VERSION, $HEADER );

my ( $stat, $IXS_initialized );
my %CS_table;

$IXS_initialized = 0;

=head1 NAME

LIFT_IDXSPI 

Perl extension for IDEfix SPI monitor

=head1 SYNOPSIS

    use LIFT_IDXSPI;

    IXS_InitHW();

    IXS_SetSPIConfiguration(['AB+','SISSI','EEPROM'],['EEPROM']);
    IXS_SetOutput(1,1);
    IXS_StartRecording("IXS_trace.bin");
    sleep(1);
    IXS_StopRecording();
    IXS_ExportCSV(['AB+','SISSI','EEPROM','EEPROMdata'], "IXS_trace.bin", "IXS_trace.csv");
    IXS_ExportCSV(['AB+','EEPROM','EEPROMdata'], "IXS_trace.bin", "IXS_trace_AB+.csv");
    IXS_DecodeEEPROM("IXS_trace_AB+.csv", "IXS_EEPROM.txt");
    $data_HoH=IXS_GetValues("IXS_trace_AB+.csv");

    IXS_CloseHW();


    ProjectConst:
        'IXS_MAPPING' => {
                                'CS1'  => 'SISSI',
                                'CS6'  => 'AB+',
                                'CS4'  => 'SMB470',
                                'CS12' => 'EEPROM',
                                'CS13' => 'EEPROMdata',    # virtual chip select
                        },


=head1 DESCRIPTION

You need to program IDEfix with latest SPI monitor firmware before it will work as SPI monitor

=for html
check
<a href="\\siz1130\aerse$\Support\Tools\CoreAssetTest\01_IDEfix\02_SPIMonitor\A_InstallationFiles\IdefixSPIMonitor\Delivery\2009_11_26\Firmware" target="blank">firmware folder</a>
or //siz1130\aerse$\Support\Tools\CoreAssetTest\01_IDEfix\02_SPIMonitor\A_InstallationFiles\IdefixSPIMonitor\Delivery

=head2 IXS_CloseHW

    IXS_CloseHW();

has to be called at the end, will unload IdefixSPI.dll. should be called in ENDcampaign. should have at least 1 second delay to previous IXS function call.

=cut

sub IXS_CloseHW
{

    unless ($IXS_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $IXS_initialized = 0;
        S_w2log( 3, "IXS_CloseHW: Terminated IdefixSPI communication \n" );
        return 1;
    }

    $stat = ixs_End();
    check_status($stat);
    S_w2log( 5, "IXS End staus=$stat\n" );
    $IXS_initialized = 0;
    S_w2log( 3, "IXS_CloseHW: Terminated IdefixSPI communication \n" );

    return 1;
}

=head2 IXS_DecodeEEPROM

    IXS_DecodeEEPROM( $CSVname, $OUTfile [, $SADfile] );

    e.g. IXS_DecodeEEPROM("IXS_trace_AB+.csv", "IXS_EEPROM.txt");

convert CSV file to readable EEPROM trace, if SAD file is given, address symbol names will be shown

NOTE: for EEPROM both chip selects have to be exported to CSV file for decoding

=cut

sub IXS_DecodeEEPROM
{
    my $CSVname = shift;
    my $OUTfile = shift;
    my $SADfile = shift;

    unless ( defined($OUTfile) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IXS_DecodeEEPROM( CSVname, OUTfile [, SADfile] )", 110 );
        return 1;
    }

    unless ( -f $CSVname )
    {
        S_set_error( "CSV_file $CSVname not found", 1 );
        return 1;
    }

    if ($main::opt_offline)
    {
        S_create_dummy_file($OUTfile);
        S_w2log( 3, "IXS_DecodeEEPROM: Converted CSV file to readable EEPROM \n" );
        return 1;
    }

    $stat = ixs_decodeEEPROM( $CSVname, $OUTfile, $SADfile );
    check_status($stat);
    S_w2log( 5, "ixs_decodeEEPROM staus=$stat\n" );
    S_w2log( 3, "IXS_DecodeEEPROM: Converted CSV file to readable EEPROM \n" );

    return 1;
}

=head2 IXS_ExportCSV

    IXS_ExportCSV( $FilterCS_aref, $SPITraceFilename, $CSVname );

    e.g. IXS_ExportCSV(['AB+','EEPROM','EEPROMdata'], "IXS_trace.bin", "IXS_trace_AB+.csv");

        'IXS_MAPPING' => {
                                'CS1'  => 'SISSI',
                                'CS6'  => 'AB+',
                                'CS4'  => 'SMB470',
                                'CS12' => 'EEPROM',
                                'CS13' => 'EEPROMdata',    # virtual chip select
                        },

covert binary SPI trace file to CSV file, also virtual chip selects (> 12) are possible

NOTE: for EEPROM both chip selects have to be exported to CSV file for decoding

=cut

sub IXS_ExportCSV
{
    my $FilterCS_aref    = shift;
    my $SPITraceFilename = shift;
    my $CSVname          = shift;

    my $FilterCS = 0;

    unless ( defined($CSVname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IXS_ExportCSV( FilterCS_aref, SPITraceFilename, CSVname )", 110 );
        return 0;
    }
    if ( ref($FilterCS_aref) ne "ARRAY" )
    {
        S_set_error( " FilterCS_aref is not an array reference", 114 );
        return 0;
    }
    if ( scalar(@$FilterCS_aref) < 1 )
    {
        S_set_error( " FilterCS_aref contains no values", 114 );
        return 0;
    }
    unless ( -f $SPITraceFilename )
    {
        S_set_error( "SPITraceFilename $SPITraceFilename not found", 1 );
        return 0;
    }

    my ($CS);
    foreach my $rawCS (@$FilterCS_aref)
    {
        #map CS if necessary
        unless ( defined( $CS = $CS_table{$rawCS} ) )
        {
            if ( $rawCS =~ /^\d+$/ )
            {
                $CS = $rawCS;
            }
            else
            {
                S_set_error( "could not resolve Chip_select_number $rawCS", 114 );
                return 1;
            }
        }
        $FilterCS += 2**$CS;
    }

    unless ($IXS_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_create_dummy_file($CSVname);
        S_w2log( 3, "IXS_ExportCSV: Converted SPI trace file to CSV file \n" );
        return 1;
    }

    $stat = ixs_ExportSelectedCS( $FilterCS, $SPITraceFilename, $CSVname );
    check_status($stat);
    S_w2log( 5, "ixs_ExportSelectedCS staus=$stat\n" );
    S_w2log( 3, "IXS_ExportCSV: Converted SPI trace file to CSV file \n" );

    return 1;
}

=head2 IXS_GetValues

    $data_HoH = IXS_GetValues( $CSVname ) ;

    e.g.  $data_HoH=IXS_GetValues("IXS_trace_AB+.csv");

returns structure of recorded data by SPI recorder. Sensors and commands are mapped from project defaults. Structure can be evaluated with EVAL functions.
Three logic channels will be added to structure: 2 free channels (CH0,CH1) and CSmon (chip select monitoring). Structure will conatin decoded EEprom communication.

timebase of structure is in milliseconds

    $data_HoH={
          time1 => {"SENSOR1:COMMAND:MOSI" => VALUE, "SENSOR1:COMMAND:MISO" => VALUE, "_LA:CSmon" => VALUE,"_LA:CH1" => VALUE,"_LA:CH0" => VALUE},
          time2 => {"SENSOR2:COMMAND:MOSI" => VALUE, "SENSOR2:COMMAND:MISO" => VALUE, "_LA:CSmon" => VALUE,"_LA:CH1" => VALUE,"_LA:CH0" => VALUE},
          };

    for AB+ RD_INT_DATA additionally _P{EEPROMaddress} is added to COMMAND to identify sensor EEPROM location
    e.g. "PITCH:RD_INT_DATA_P3:MISO"
    VALUE will be in binary e.g. 0b11100000 or hex e.g. 0xDE

 the sensor name will be taken from ProjectDefaults->{'IXS_MAPPING'}CSx, depending on chip select in SPI trace
 the Instruction name will be taken from ProjectDefaults->{sensor name'_COMMAND'}Instruction (7 bits, no parity bit)
 also extended instructions are supported (16 bits) but then use only extended format for this instruction.

 if sensor name is 'AB+' the sensor name will be taken from ProjectDefaults->{'AB+_SENSOR'}Address
 and Instruction will be taken from ProjectDefaults->{'AB+_COMMAND'}, no extended instructions

 NOTE: you have to use 'AB+' for ABplus and 'EEPROM' and 'EEPROMdata' and 'LA' as labels to ensure decoding is done correctly

    example data:

    000002.170 ALL:DATA_CAPTURE:MISO=0b11111000 ALL:DATA_CAPTURE:MOSI=0b11100000 _LA:CH0=0b1 _LA:CH1=0b1 _LA:CSmon=0b1
    000002.200 LIN_X:RD_DATA:MISO=0b0000001111111100010101111100001111101011 LIN_X:RD_DATA:MOSI=0b1001001000000000000000000000000000000010 _LA:CH0=0b1 _LA:CH1=0b1 _LA:CSmon=0b1
    000658.039 _LA:CH0=0b1 _LA:CH1=0b1 _LA:CSmon=0b1
    000658.041 _LA:CH0=0b1 _LA:CH1=0b1 _LA:CSmon=0b1
    000658.048 _LA:CH0=0b1 _LA:CH1=0b1 _LA:CSmon=0b1
    000658.056 _EE:ADDR=0x4000002 _EE:READ=0xDE _LA:CH0=0b1 _LA:CH1=0b1 _LA:CSmon=0b1

            'IXS_MAPPING' => {
                                    'CS6' => 'AB+',
                                    'CS4' => 'SMB470',
                                    'CS12' => 'EEPROM',
                                    'CS13' => 'EEPROMdata',
                                    'CS15' => 'LA',
                             },
            'AB+_SENSOR' =>  {
                                    '100' => 'LIN_X',
                             },
            'AB+_COMMAND' => {
                                    '00000' => 'DATA_CAPTURE',
                             },
            'SMB470_COMMAND' => {
                                    '0000000' => 'RD_DEVICE_ID',
                                },
            'SMG100_COMMAND' => {
                                    '0000000'          => 'RD_DEVICE_ID',       # normal instruction
                                    '0011100000000001' => 'WR_BITE_TEST_POS',   # extended instruction
                                    '0011100000000010' => 'WR_BITE_TEST_NEG',
                                    '0011100000000000' => 'WR_BITE_TEST_OFF',
                                },


=cut

sub IXS_GetValues
{
    my $CSVname = shift;
    my ( $data_HoH, %errormsg );

    my $data_HoH_dummy;
    $data_HoH_dummy->{0}->{'dummy'} = 0;

    unless ( defined($CSVname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: data_HoH = IXS_GetValues( CSVname )", 110 );
        return ($data_HoH_dummy);
    }
    unless ( -f $CSVname )
    {
        S_set_error( "CSV_file $CSVname not found", 1 );
        return ($data_HoH_dummy);
    }

    if ($main::opt_offline)
    {
        return ($data_HoH_dummy);
    }

    if ( open( IN, "<$CSVname" ) )
    {
        my ( $dummy, $time, $CS, $burst, $bits, $MOSI1, $MOSI2, $MISO1, $MISO2, $error, $line, $signalname, $Address, $Instruction, $sensorname, $Page, $MOSIbits, $MISObits, $CH2, $CH1, $CH0 );
        my ( @eeMOSI, @eeMISO, $last_command, $last_time, $heading, $extended_format );
        $last_command = $last_time = 0;
        $heading = <IN>;    # read header
        if ( $heading =~ /;Burst;/ )
        {
            #Time[usec];CSIndex;Burst;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1
            $extended_format = 1;
            print "found extended format\n";
        }
        else
        {
            #Time[usec];CSIndex;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1
            $extended_format = 0;
            $burst           = 0;    # will not be read, therefore set it to default
            print "found normal format\n";
        }

        while ( $line = <IN> )
        {
            chomp($line);
            if ($extended_format)
            {
                ( $time, $CS, $burst, $bits, $MOSI1, $MOSI2, $MISO1, $MISO2, $error, $CH2, $CH1, $CH0 ) = split( /;/, $line );
            }
            else
            {
                ( $time, $CS, $bits, $MOSI1, $MOSI2, $MISO1, $MISO2, $error, $CH2, $CH1, $CH0 ) = split( /;/, $line );
            }
            $dummy = sprintf( "%016b", hex($MOSI1) ) . sprintf( "%032b", hex($MOSI2) );    # convert to 48 bits
            $dummy =~ /(\d{$bits})$/;                                                      # extract used bits only
            $MOSIbits = $1;
            $dummy = sprintf( "%016b", hex($MISO1) ) . sprintf( "%032b", hex($MISO2) );    # convert to 48 bits
            $dummy =~ /(\d{$bits})$/;    # extract used bits only
            $MISObits = $1;

            $CS = hex($CS);              # convert to dec

            $time = sprintf( "%010.3f", $time / 1000.0 );    # convert to msec

            unless ($error)
            {

                if ( defined $main::ProjectDefaults->{'IXS_MAPPING'}{ "CS" . $CS } )
                {
                    $sensorname = $main::ProjectDefaults->{'IXS_MAPPING'}{ "CS" . $CS };
                }
                else
                {
                    $errormsg{ "ProjectDefaults->{'IXS_MAPPING'}{CS" . $CS . "} not defined" }++;
                    $sensorname = "undef";
                }

                if ( $sensorname eq 'EEPROM' )
                {
                    $last_time = $time if ( $last_time == 0 );

                    if ( $last_command != 0 )
                    {
                        if ( $last_command == 1 )
                        {
                            $data_HoH->{$last_time}->{'_EE:WRSR'} = '0x' . join( '', @eeMOSI );
                        }
                        elsif ( $last_command == 2 )
                        {
                            my $start = shift(@eeMOSI);
                            $start .= shift(@eeMOSI);

                            $data_HoH->{$last_time}->{'_EE:WRITE'} = '0x' . join( '', @eeMOSI );
                            $data_HoH->{$last_time}->{'_EE:ADDR'} = '0x400' . $start;

                        }
                        elsif ( $last_command == 3 )
                        {
                            my $start = shift(@eeMOSI);
                            $start .= shift(@eeMOSI);
                            shift(@eeMISO);
                            shift(@eeMISO);

                            $data_HoH->{$last_time}->{'_EE:READ'} = '0x' . join( '', @eeMISO );
                            $data_HoH->{$last_time}->{'_EE:ADDR'} = '0x400' . $start;
                        }
                        elsif ( $last_command == 4 )
                        {
                            $data_HoH->{$last_time}->{'_EE:WRDI'} = '';
                        }
                        elsif ( $last_command == 5 )
                        {
                            $data_HoH->{$last_time}->{'_EE:RDSR'} = '0x' . join( '', @eeMISO );
                        }
                        elsif ( $last_command == 6 )
                        {
                            $data_HoH->{$last_time}->{'_EE:WREN'} = '';
                        }
                        else { $errormsg{"unknown EE command $last_command"}++; }

                        @eeMOSI = @eeMISO = ();
                    }
                    $last_command = hex($MOSI2);

                }
                elsif ( $sensorname eq 'EEPROMdata' )
                {
                    push( @eeMOSI, sprintf( "%02X", hex($MOSI2) ) );
                    push( @eeMISO, sprintf( "%02X", hex($MISO2) ) );
                    $last_time = $time;
                }
                elsif ( $sensorname eq 'AB+' )
                {

                    $MOSIbits =~ /^(\d{3})(\d{5})(\d{0,4})/;
                    $Address     = $1;
                    $Instruction = $2;
                    $Page        = $3;

                    if ( defined $main::ProjectDefaults->{'AB+_SENSOR'}{$Address} )
                    {
                        $signalname = $main::ProjectDefaults->{'AB+_SENSOR'}{$Address};
                    }
                    else
                    {
                        $errormsg{"ProjectDefaults->{'AB+_SENSOR'}{$Address} not defined"}++;
                        $sensorname = "undef";
                    }

                    if ( defined $main::ProjectDefaults->{'AB+_COMMAND'}{$Instruction} )
                    {
                        $signalname .= ":" . $main::ProjectDefaults->{'AB+_COMMAND'}{$Instruction};
                    }
                    else
                    {
                        $errormsg{"ProjectDefaults->{'AB+_COMMAND'}{$Instruction} not defined"}++;
                        $signalname .= ":undef";
                    }

                    if ( $Instruction eq '01001' )
                    {
                        $signalname .= "_P" . oct( '0b' . $Page );
                    }

                    $data_HoH->{$time}->{ $signalname . ':MOSI' } = '0b' . $MOSIbits;
                    $data_HoH->{$time}->{ $signalname . ':MISO' } = '0b' . $MISObits;
                }
                elsif ( $sensorname eq 'LA' )
                {
                    $data_HoH->{$time}->{ $sensorname . ':data:MOSI' } = '0b' . $MOSIbits;
                    $data_HoH->{$time}->{ $sensorname . ':data:MISO' } = '0b' . $MISObits;
                }
                else
                {
                    my $ExtendedInstruction = '';
                    $MOSIbits =~ /^(\d{7})(\d{9})/;
                    $Instruction = $1;
                    if ( $bits > 15 )
                    {
                        $ExtendedInstruction = $1 . $2;
                    }

                    if ( defined $main::ProjectDefaults->{ $sensorname . '_COMMAND' }{$Instruction} )
                    {
                        $signalname = $sensorname . ":" . $main::ProjectDefaults->{ $sensorname . '_COMMAND' }{$Instruction};
                    }
                    elsif ( defined $main::ProjectDefaults->{ $sensorname . '_COMMAND' }{$ExtendedInstruction} )
                    {
                        $signalname = $sensorname . ":" . $main::ProjectDefaults->{ $sensorname . '_COMMAND' }{$ExtendedInstruction};
                    }
                    else
                    {
                        $errormsg{ "ProjectDefaults->{" . $sensorname . "_COMMAND}{$Instruction} not defined" }++;
                        $signalname = $sensorname . ":undef";
                    }
                    $data_HoH->{$time}->{ $signalname . ':MOSI' } = '0b' . $MOSIbits;
                    $data_HoH->{$time}->{ $signalname . ':MISO' } = '0b' . $MISObits;
                }

                $data_HoH->{$time}->{'_LA:CSmon'} = '0b' . $CH2;
                $data_HoH->{$time}->{'_LA:CH1'}   = '0b' . $CH1;
                $data_HoH->{$time}->{'_LA:CH0'}   = '0b' . $CH0;

            }
            else
            {
                $errormsg{"error bit set in CSV"}++;
            }
        }
    }
    else
    {
        S_set_error( "could not open $CSVname", 1 );
        return ($data_HoH_dummy);
    }

    foreach ( sort keys %errormsg )
    {
        S_w2rep( "$_ : $errormsg{$_}\n", "red" );
    }

    return ($data_HoH);
}

=head2 IXS_InitHW

    IXS_InitHW();

initialize IDEfix hardware

has to be called before any other IXS command, will load IdefixSPI.dll should be called in INITcampaign

=cut

sub IXS_InitHW
{
    if ($IXS_initialized)
    {
        S_set_warning( "IDEfix already initialized", 120 );
        return;
    }

    S_w2log( 4, "creatign CS table ...\n" );

    #initialize %CS_table from ProjectDefaults->{'IXS_MAPPING'}
    my %helper = %{ $main::ProjectDefaults->{'IXS_MAPPING'} };

    %CS_table = ();
    foreach my $key ( keys %helper )
    {
        unless ( defined $CS_table{ $helper{$key} } )
        {
            no warnings;
            $key =~ /CS(\d+)/;    # extract numbers
            $CS_table{ $helper{$key} } = $1;
            S_w2log( 4, "$helper{$key} -> $CS_table{$helper{$key}}\n" );
        }
        else
        {
            S_set_error( "value $helper{$key} defined more than once in ProjectDefaults->{'IXS_MAPPING'}", 5 );
        }
    }

    if ($main::opt_offline)
    {
        $IXS_initialized = 1;
        S_w2log( 3, "IXS_InitHW: Initialized communication with idefixSPI \n" );
        return 1;
    }

    my ( $ret, $version, $device );
    $ret = ixs_getPMrevision();
    S_w2log( 5, "PM $ret\n" );
    $ret = ixs_getXSrevision();
    S_w2log( 5, "XS $ret\n" );
    $ret = ixs_getCWrevision();
    S_w2log( 5, "CW $ret\n" );

    $stat = ixs_Start();
    check_status($stat);
    S_w2log( 5, "($stat) ixs_Start\n" );

    $stat = ixs_IniUSB();
    check_status($stat);
    S_w2log( 5, "($stat) ixs_IniUSB\n" );

    ( $stat, $device ) = ixs_GetDescription();
    check_status($stat);
    S_w2log( 5, "($stat) ixs_GetDescription\n" );

    ( $stat, $version ) = ixs_GetFirmware();
    check_status($stat);
    S_w2log( 4, "($stat) Idefix $device Firmware version:\n $version\n\n" );

    $IXS_initialized = 1;

    if ( $stat < 0 )
    {
        S_set_error( "could not initialize IDEfix", 5 );
        $IXS_initialized = 0;
    }

    ( $stat, $version ) = ixs_GetVersion();
    check_status($stat);
    S_w2log( 5, "($stat) IdefixSPI DLL version:\n $version\n\n" );
    S_w2log( 3, "IXS_InitHW: Initialized communication with idefixSPI \n" );

    return 1;
}

=head2 IXS_SetOutput

    IXS_SetOutput($Out1, $Out2);

    e.g.  IXS_SetOutput(1,1);

Set the Ouput of the connectors Out1 and Out2

 Arguments: $Out1   : 1= HighLevel, else LowLevel
            $Out2   : 1= HighLevel, else LowLevel

=cut

sub IXS_SetOutput
{
    my $Out1 = shift;
    my $Out2 = shift;

    S_w2log( 3, "IXS_SetOutput ($Out1, $Out2)\n" );

    unless ( defined($Out2) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IXS_SetOutput( Out1, Out2 )", 110 );
        return 0;
    }

    unless ( $Out1 =~ /^\d+$/ )
    {
        S_set_error( "Out1 $Out1 is not a number", 114 );
        return 1;

    }
    unless ( $Out2 =~ /^\d+$/ )
    {
        S_set_error( "Out1 $Out1 is not a number", 114 );
        return 1;

    }

    #parameter range check
    if ( $Out1 > 1 or $Out1 < 0 )
    {
        S_set_error( "Out1 $Out1 out of range  (0<=x<=1)", 114 );
        return 1;
    }
    if ( $Out2 > 1 or $Out2 < 0 )
    {
        S_set_error( "Out2 $Out1 out of range  (0<=x<=1)", 114 );
        return 1;
    }
    unless ($IXS_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        return 1;
    }

    $stat = ixs_SetOutput( $Out1, $Out2 );
    check_status($stat);
    S_w2log( 5, "ixs_SetOutput staus=$stat\n" );

    return 1;
}

=head2 IXS_SetSPIConfiguration

    IXS_SetSPIConfiguration();

    $status = ixs_SetSPIConfiguration( $FilterCS_aref [, $SPI2_aref, $LAMask ]);

    $LAMask(7 downto 0)      : LA Mask, if Bit is cleared channel is cleared

set SPI monitoring mode. @FilterCS = list of single CS to be monitored, @SPI2 = these CS are on SPI2 all others on SPI1

 @FilterCS and @SPI2 will be mapped via ProjectDefaults->{'IXS_MAPPING'}

 maximum number for Filter CS is 12

  e.g.
      IXS_SetSPIConfiguration(['AB+','SISSI','EEPROM'],['EEPROM']);

        'IXS_MAPPING' => {
                                'CS1'  => 'SISSI',
                                'CS6'  => 'AB+',
                                'CS4'  => 'SMB470',
                                'CS12' => 'EEPROM',
                                'CS13' => 'EEPROMdata',    # virtual chip select
                        },



=cut

sub IXS_SetSPIConfiguration
{
    my $FilterCS_aref = shift;
    my $SPI2_aref     = shift;
    my $LAMask        = shift;

    my ( $FilterCS, $SPI2 );
    $FilterCS = 0;
    $SPI2     = 0;

    unless ( defined($FilterCS_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IXS_SetSPIConfiguration( FilterCS_aref [, SPI2_aref, LAMask ] )", 110 );
        return 0;
    }
    if ( ref($FilterCS_aref) ne "ARRAY" )
    {
        S_set_error( " FilterCS_aref is not an array reference", 114 );
        return 0;
    }
    if ( scalar(@$FilterCS_aref) < 1 )
    {
        S_set_error( " FilterCS_aref contains no values", 114 );
        return 0;
    }

    my ($CS);
    foreach my $rawCS (@$FilterCS_aref)
    {
        #map CS if necessary
        unless ( defined( $CS = $CS_table{$rawCS} ) )
        {
            if ( $rawCS =~ /^\d+$/ )
            {
                $CS = $rawCS;
            }
            else
            {
                S_set_error( "could not resolve Chip_select_number $rawCS", 114 );
                return 1;
            }
        }

        #parameter range check
        if ( $CS > 12 or $CS < 0 )
        {
            S_set_error( "Chip_select_number $CS($rawCS) out of range  (0<=x<=12)", 114 );
            return 1;
        }
        $FilterCS += 2**$CS;
    }

    if ( defined($SPI2_aref) )
    {
        if ( ref($SPI2_aref) ne "ARRAY" )
        {
            S_set_error( " SPI2_aref is not an array reference", 114 );
            return 0;
        }
        foreach my $rawCS (@$SPI2_aref)
        {
            #map CS if necessary
            unless ( defined( $CS = $CS_table{$rawCS} ) )
            {
                if ( $rawCS =~ /^\d+$/ )
                {
                    $CS = $rawCS;
                }
                else
                {
                    S_set_error( "could not resolve Chip_select_number $rawCS", 114 );
                    return 1;
                }
            }

            #parameter range check
            if ( $CS > 12 or $CS < 0 )
            {
                S_set_error( "Chip_select_number $CS($rawCS) out of range  (0<=x<=12)", 114 );
                return 1;
            }
            $SPI2 += 2**$CS;
        }
    }

    $LAMask = 0 unless ( defined $LAMask );

    unless ($IXS_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_w2log( 4, "IXS_SetSPIConfiguration  ($FilterCS $SPI2 $LAMask) \n" );
        return 1;
    }

    $stat = ixs_SetSPIConfiguration( $FilterCS, 0, IDM_CS12, $SPI2, $LAMask );
    check_status($stat);
    S_w2log( 5,  "IXS_SetSPIConfiguration ($FilterCS $SPI2 $LAMask) staus=$stat\n" );

    return 1;
}

=head2 IXS_StartRecording

    IXS_StartRecording($filename);

    e.g. IXS_StartRecording("IXS_trace.bin");

Start dumping SPI trace to file

=cut

sub IXS_StartRecording
{
    my $SPITraceFilename = shift;

    unless ( defined($SPITraceFilename) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IXS_StartRecording( filename )", 110 );
        return 0;
    }

    unless ($IXS_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_create_dummy_file($SPITraceFilename);
        S_w2log( 3, "IXS_StartRecording ($SPITraceFilename)\n" );
        return 1;
    }

    $stat = ixs_StartMeasurementThread($SPITraceFilename);
    check_status($stat);
    S_w2log( 5, "ixs_StartMeasurementThread staus=$stat\n" );
    S_w2log( 3, "IXS_StartRecording: dumped SPI trace to file $SPITraceFilename \n" );

    return 1;
}

=head2 IXS_StopRecording

    IXS_StopRecording();

Stop dumping SPI trace to file

=cut

sub IXS_StopRecording
{

    unless ($IXS_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "IXS_StopRecording: Stopped dumping SPI trace to file\n" );
        return 1;

    }

    $stat = ixs_StopMeasurementThread();
    check_status($stat);
    S_w2log( 5, "ixs_StopMeasurementThread staus=$stat\n" );
    S_w2log( 3, "IXS_StopRecording: Stopped dumping SPI trace to file\n" );

    return 1;
}

=head1 not exported functions

=head2 check_status

 check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub check_status
{
    my $status = shift;

    return 1 if $main::opt_offline;
    if ( $status < 0 )
    {
        my $errortext = ixs_GetErrortext($status);
        S_set_error( "IDX ($status): $errortext", 5 );

    }

    return 1;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

