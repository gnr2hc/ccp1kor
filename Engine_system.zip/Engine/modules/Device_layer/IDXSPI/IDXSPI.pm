package IDXSPI;

use strict;
use warnings;

require Exporter;
require DynaLoader;


 use constant IDM_CS0  => 1;
 use constant IDM_CS1  => 2;
 use constant IDM_CS2  => 4;
 use constant IDM_CS3  => 8;
 use constant IDM_CS4  => 16;
 use constant IDM_CS5  => 32;
 use constant IDM_CS6  => 64;
 use constant IDM_CS7  => 128;
 use constant IDM_CS8  => 256;
 use constant IDM_CS9  => 512;
 use constant IDM_CS10 => 1024;
 use constant IDM_CS11 => 2048;
 use constant IDM_CS12 => 4096;
 use constant IDM_CS13 => 8192;
 use constant IDM_CS14 => 16384;
 use constant IDM_CS15 => 32768;

 use constant IDM_LA0  => 1;
 use constant IDM_LA1  => 2;
 use constant IDM_LA2  => 4;
 use constant IDM_LA3  => 8;
 use constant IDM_LA4  => 16;
 use constant IDM_LA5  => 32;
 use constant IDM_LA6  => 64;
 use constant IDM_LA7  => 128;
 
our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use IDXSPI ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
                ixs_decodeEEPROM
                ixs_decodeLA
                ixs_End
                ixs_ExportSelectedCS
                ixs_GetDescription
                ixs_GetErrortext
                ixs_GetFirmware
                ixs_GetVersion
                ixs_IniUSB
                ixs_ReadByAddress
                ixs_SendUserScript
                ixs_SetOutput
                ixs_SetSPIConfiguration
                ixs_Start
                ixs_StartMeasurementThread
                ixs_StartSPIMonitoring
                ixs_StopMeasurementThread
                ixs_StopSPIMonitoring
                ixs_WriteByAddress
                ixs_WriteDebugFile
                ixs_getCWrevision
                ixs_getPMrevision
                ixs_getXSrevision
                IDM_CS0  
                IDM_CS1  
                IDM_CS2  
                IDM_CS3  
                IDM_CS4  
                IDM_CS5  
                IDM_CS6  
                IDM_CS7  
                IDM_CS8  
                IDM_CS9  
                IDM_CS10 
                IDM_CS11 
                IDM_CS12 
                IDM_CS13 
                IDM_CS14 
                IDM_CS15 
                IDM_LA0  
                IDM_LA1  
                IDM_LA2  
                IDM_LA3  
                IDM_LA4  
                IDM_LA5  
                IDM_LA6  
                IDM_LA7  
);
our $VERSION = '1.0';

bootstrap IDXSPI $VERSION;

# Preloaded methods go here.

sub ixs_getPMrevision{
    return ('SCM');
}

sub ixs_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub ixs_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

sub ixs_decodeEEPROM{
    my $csv = shift;
    my $out = shift;
    my $sad = shift;
    my ($line,$time,$CS,$bits,$MOSI2,$MOSI1,$MISO2,$MISO1,$error,@MOSI, @MISO, $last_command, $last_time, $errorcount,%EEmap,%EEcount);
    
    if (defined $sad){
        open ( SAD,"<$sad" ) or print "Couldn't open $_ : $@";
        #A_DistMemCounter_U8E(0),04000418, 0 Disturb counters,,,,,,,,,
        while($line = <SAD>){ 
            if ($line =~ /^([^,]+),0(4\w+)/){
                $EEmap{hex($2)}=$1;
            }
        }
        close (SAD);
    }
    
    
    open ( OUT,">$out" ) or print "Couldn't open $_ : $@";
    print OUT"time [usec] : errorcounter : command \n";
    print OUT"====================================\n\n";
    open ( IN,"<$csv" ) or print "Couldn't open $_ : $@";
    <IN>; # skip header
    $last_command = $last_time = $errorcount = 0;
    
    while($line = <IN>){ 
        #Time[usec];CSIndex;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1
        #e.g. 195074.000000;0x0c;8;0x00;0x0003;0x00;0x00ff;0;1;1;1
        ($time,$CS,$bits,$MOSI1,$MOSI2,$MISO1,$MISO2,$error) = split(/;/,$line);
        if (hex($CS)==0x0c){
            if ($last_command != 0){

                $last_time = sprintf("%011d",$time) if ($last_time == 0);
                if ($last_command == 1){
                    print OUT"$last_time : $errorcount : WRSR write status register : @MOSI \n";
                }
                elsif ($last_command == 2){
                    my $start = shift(@MOSI);
                    $start.= shift(@MOSI);
                    
                    print OUT"$last_time : $errorcount : WRITE write to memory array : 400$start : @MOSI \n";
                    my $EEstart= hex("400$start");
                    my $count;
                    for ($count=0;$count<scalar(@MOSI);$count++){
                        $EEcount{$EEstart+$count}++; # increase write couter for current cell
                        if (defined $sad){
                            no warnings;
                            printf (OUT"                                                %X %s %s \n",($EEstart+$count),$MOSI[$count],$EEmap{$EEstart+$count} );
                        }
                    }
                    
                }
                elsif ($last_command == 3){
                    my $start = shift(@MOSI);
                    $start.= shift(@MOSI);
                    shift(@MISO);
                    shift(@MISO);
                    
                    print OUT"$last_time : $errorcount : READ read from memory array : 400$start : @MISO \n";
                    if (defined $sad){
                        my $EEstart= hex("400$start");
                        my $count;
                        for ($count=0;$count<scalar(@MISO);$count++){
                            no warnings;
                            printf (OUT"                                                %X %s %s \n",($EEstart+$count),$MISO[$count],$EEmap{$EEstart+$count} );
                        }
                    }
                }
                elsif ($last_command == 4){
                    print OUT"$last_time : $errorcount : WRDI write disable \n";
                }
                elsif ($last_command == 5){
                    print OUT"$last_time : $errorcount : RDSR read status register   : @MISO \n";
                }
                elsif ($last_command == 6){
                    print OUT"$last_time : $errorcount : WREN write enable \n";
                }
                else {print OUT"$last_time : ERROR: unknown command $last_command ! \n";}

                @MOSI=@MISO=();
            }
            $last_command = hex($MOSI2);
            $errorcount = 0;
        }
        elsif (hex($CS)==0x0d){
            ### push (@MOSI,sprintf("%04X",hex($MOSI1)).sprintf("%04X",hex($MOSI2)));
            ### push (@MISO,sprintf("%04X",hex($MISO1)).sprintf("%04X",hex($MISO2)));
           
            #only single bytes are used, so this is sufficient:
            push (@MOSI,sprintf("%02X",hex($MOSI2)));
            push (@MISO,sprintf("%02X",hex($MISO2)));
            $last_time = sprintf("%011d",$time);
        }
        $errorcount += $error;

    }    
    print OUT"\n\n\n----------------------------------------------------------------------------------------\n\n";
    print OUT"address : write_counter : label\n===============================\n\n";
    
    foreach (sort keys %EEcount){
        no warnings;
        printf (OUT"%X : %d : %s \n",$_,$EEcount{$_},$EEmap{$_} );
    }
    
    
    close (IN);
    close (OUT);
    
    return 1;
}



sub ixs_decodeLA{
    my $csv = shift;
    my $out = shift;
    my ($line,$time,$CS,$bits,$MOSI2,$MOSI1,$MISO2,$MISO1,$error,@MOSI, @MISO);
    
    open ( OUT,">$out" ) or print "Couldn't open $_ : $@";
    print OUT"time [usec] : LA_ch7 : LA_ch6 : LA_ch5 : LA_ch4 : LA_ch3 : LA_ch2 : LA_ch1 : LA_ch0 : (error) \n";
    print OUT"====================================\n\n";
    open ( IN,"<$csv" ) or print "Couldn't open $_ : $@";
    <IN>; # skip header
    
    while($line = <IN>){ 
        #Time[usec];CSIndex;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1
        #102974.000000;0x0f;8;0x00;0x001e;0x00;0x0000;0;1;1;1
        ($time,$CS,$bits,$MOSI1,$MOSI2,$MISO1,$MISO2,$error) = split(/;/,$line);
        # decode only CS15 (LA channel)
        if (hex($CS)==0x0f){
            my $dummy=join(' : ',split(//,sprintf("%08b",hex($MOSI2))));
            printf (OUT"%011d : %s : (%d)\n",$time,$dummy,$error);
        }
    }
    close (IN);
    close (OUT);
    return 1;

}

1;
__END__

=head1 NAME

IDXSPI - Perl extension for IDEfix SPI monitor

=head1 SYNOPSIS

  use IDXSPI;

=head1 DESCRIPTION

All these functions are wrapped around IdefixInterface.dll APIs.



=head2 ixs_decodeEEPROM

    ixs_decodeEEPROM( $CSVfile, $decoded_file [, $SADfile] );

    e.g. ixs_decodeEEPROM( "0_20_CS12EE.csv", "EEdecoded.txt" );

create decoded EEPORM file from CSV, if SAD file is given, address symbol names will be shown



=head2 ixs_decodeLA

    ixs_decodeLA( $CSVfile, $decoded_file );

    e.g. ixs_decodeLA( "CS15LA.csv", "LAdecoded.txt" );

create decoded (channel separated) logic analyzer file from CSV. Will only select virtual CS 15.



=head2 ixs_End

    $status = ixs_End();

unload IdefixInterface.DLL



=head2 ixs_ExportSelectedCS

    $status = ixs_ExportSelectedCS( $csmask, $SPITraceFilename, $OutFilename )

    you can use predefined constants IDM_CS0 to IDM_CS15
  
  e.g.
  $status = ixs_ExportSelectedCS( IDM_CS12|IDM_CS13, "measure.bin", "0_20_CS12EE.csv" );

create CSV file for selected chipselects from binary dumpfile


=head2 ixs_GetDescription

    ($status, $SerialNumber) = ixs_GetDescription();

Gets the serial number (as string) of the requested USB device.

status: = 0 valid,  -1 Error



=head2 ixs_GetErrortext

    $Errortext = ixs_GetErrortext( $errornumber );

Returns the Description of any error code (<0)



=head2 ixs_GetFirmware

    $Firmware = ixs_GetFirmware());

Gets the firmware revision (as string) of the requested USB device.


=head2 ixs_GetVersion

    ($status, $version) = ixs_GetVersion();

returns IdefixInterface.DLL version



=head2 ixs_IniUSB

    $Devices = ixs_IniUSB();

Initialize the USB Interface and searches for the Idefix Devices, call only once at the beginning before any other function   

Return: >= 0 Number of Idefix Devices,  -1 Error



=head2 ixs_ReadByAddress

    ($status, $value) = ixs_ReadByAddress($address);
    e.g.: ($stat, $value) = ixs_ReadByAddress(hex("0x00509A80"));

reads RAM cell (32 bit) (as string) of the requested USB device. 

Return: = 0 valid,  -1 Error



=head2 ixs_SendUserScript

    $status = ixs_SendUserScript($scriptfile);



=head2 ixs_SetOutput

    $status = ixs_SetOutput($Out1, $Out2);
    e.g.: $status = ixs_SetOutput(1, 1);

Set the Ouput of the connectors Out1 and Out2

 Arguments: $Out1   : 1= HighLevel, else LowLevel
            $Out2   : 1= HighLevel, else LowLevel

Return: 0 valid or -1 on any Error


=head2 ixs_SetSPIConfiguration

    $status = ixs_SetSPIConfiguration( $CSEnabled, $CSPolarity, $SCKPolarity, $Bus0orBus1, $LAMask);

    $CSEnabled(12 downto 0)  : Bit is 1: channel is enabled
                               you can use predefined constants IDM_CS0 to IDM_CS12
    $CSPolarity(12 downto 0) : CS Polarity:  0 = CS is low aktiv, 1 = high active
                               you can use predefined constants IDM_CS0 to IDM_CS12
    $SCKPolarity(12 downto 0): SCK Ploarity: 0 = sample on falling edge, 1 = sample on rising edge
                               you can use predefined constants IDM_CS0 to IDM_CS12
    $Bus0orBus1(12 downto 0) : BUS Assignment: 0 = SPI1, 1 = SPI2
    $LAMask(7 downto 0)      : LA Mask, if Bit is cleared channel is cleared
                               you can use predefined constants IDM_LA0 to IDM_LA7
   e.g.:
  $stat = ixs_SetSPIConfiguration(IDM_CS5|IDM_CS12, 0, IDM_CS12, IDM_CS12, 0); # extended line, EEPROM on SPI2
  $stat = ixs_SetSPIConfiguration(IDM_CS5|IDM_CS12, 0, IDM_CS12, 0, 0); # Fo1000, EEPROM on SPI1



=head2 ixs_Start

    $status = ixs_Start();

load IdefixInterface.DLL and initalize function pointers



=head2 ixs_StartMeasurementThread

     $status = ixs_StartMeasurementThread( $SPITraceFilename );

start dump SPI trace to binaryfile



=head2 ixs_StartSPIMonitoring

    $status = ixs_StartSPIMonitoring();

(experimental) start online monitoring



=head2 ixs_StopMeasurementThread

     $status = ixs_StopMeasurementThread();

stop dump SPI trace to binaryfile



=head2 ixs_StopSPIMonitoring

    $status = ixs_StopSPIMonitoring();

(experimental) stop online monitoring



=head2 ixs_WriteByAddress

    $status = ixs_WriteByAddress($address, $value);
    e.g. $status = ixs_WriteByAddress(hex("0x00509A80"),1);    

Adress to Write (32 Bit), Write Value (32 Bit)

writes RAM cell (32 bit) of the requested USB device. 

Return: = 0 valid,  -1 Error
              


=head2 ixs_WriteDebugFile

    $status = ixs_WriteDebugFile($SPITraceFilename, $OutFilename)


=head1 TRACEABILITY FUNCTIONS

=head2 ixs_getPMrevision

returns MKS revision number of .pm file

=head2 ixs_getXSrevision

returns MKS revision number of .xs file


=head2 ixs_getCWrevision

returns MKS revision number of .c wrapper file


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, IDEfix documentation

=cut
