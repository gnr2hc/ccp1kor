
About TRC_Manager.dll:
	It is 64-bit TRC Manager DLL used to communicate with MF Transient recorder.
	It makes use of the Driver library(TPC_Access.dll) provided by MF Intruments to communicate with the 
	server software (installed in MF TransCom equipment) and control(configure channels & trigger, start/stop recording) 
	the Transient recorder.
	
About TPC_Access.dll:
	A 64-bit C Library to communicate with TransCom server software. 
	It gives APIs for the low level communication.

About MFTRC.dll:
	A 64-bit perl wrapper dll for C-functions in TRC_Manager.dll.
	It is compiled using Perl 5.12, 64-bit