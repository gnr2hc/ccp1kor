package MFTRC;

use 5.006000;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use MFTRC ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	mftrc_getPMrevision
	mftrc_getXSrevision
	mftrc_getCWrevision
	mftrc_Start
	mftrc_GetDLLVersion
	mftrc_InitTRC
	mftrc_GetDeviceDetails
    mftrc_ClearChannelsAndSetDefaults
	mftrc_ConfigureTransi
	mftrc_ConfigureRecordingChannel
	mftrc_ConfigureTrigger
	mftrc_InitNewMeasurement
	mftrc_SendSWTrigger
	mftrc_StopMeasurement
	mftrc_GetRecordedData
	mftrc_PlotUNVForAllChannels
	mftrc_GetErrorString
	mftrc_ExitTRC
	mftrc_End
);

our $VERSION = '0.01';

require XSLoader;
XSLoader::load('MFTRC', $VERSION);

# Preloaded methods go here.

sub mftrc_getPMrevision{
    return ('SCM');
}

sub mftrc_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub mftrc_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}



1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

MFTRC - Perl extension for TRC_Manager.dll (Low level control DLL for MF transcom transient recorder)

=head1 SYNOPSIS

  use MFTRC;
  my ($status, $version, $data_aref); 
  my ($DeviceId, $ServerSWVersion, $MACAddress, $NumOfChannels, $MaxMemory_byte, $MaxSpeed_Hz);
  
  $status = mftrc_Start();
  ($status, $version) = mftrc_GetDLLVersion();  
  
  $status = mftrc_InitTRC('10.40.5.18:10010');
  ($status, $DeviceId, $ServerSWVersion, $MACAddress, $NumOfChannels, $MaxMemory_byte, $MaxSpeed_Hz) = mftrc_GetDeviceDetails();
  
  $status = mftrc_ClearChannelsAndSetDefaults();  # clear all the settings available and set configs to default
  
  $status = mftrc_ConfigureTransi(1000000 , 2097152, -30);	# 1MHz, 2MB, -30%
  
  $status = mftrc_ConfigureRecordingChannel("AB1FD", 2, 2, 2, 5, 0);	# (2, 2, 2, 5, 0) = CHANNEL-2, DC coupling, Differential, 5V range, 0% offset
  $status = mftrc_ConfigureRecordingChannel("BT1FD", 5, 2, 2, 10, 10);	# (5, 2, 2, 5, 0) = CHANNEL-5, DC coupling, Differential, 10V range, 10% offset
  
  $status = mftrc_ConfigureTrigger("AB1FD", 3.5, 3.0, 1);	#3.5V trigger voltage, 3V Hysteresis, +ve slope
  $status = mftrc_ConfigureTrigger("EXTERNAL", 0, 0, 2);	#-ve slope TTL external trigger
  
  $status = mftrc_InitNewMeasurement();
  sleep(2);
  
  $status = mftrc_SendSWTrigger();
  ($status, $data_aref) = mftrc_GetRecordedData("AB1FD", 5000);	# wait 5 seconds and retrieve the data
  
  $status = mftrc_PlotUNVForAllChannels('C:\\TRC_UNVPlot.txt.unv', 2000);
  
  $status = mftrc_StopMeasurement();	# stop measurement incase if it is running
  
  $status = mftrc_End();


=head1 DESCRIPTION

The functions in this module are given as a Perl wrapper for the functions available in TRC_Manage.dll.
Refer to the User manual of TRC_Manager.dll for further information about parameter details and validation ideas.

=head2 mftrc_ClearChannelsAndSetDefaults

    $status = mftrc_ClearChannelsAndSetDefaults();

to clear all the configurations that are done previously & set the values to default. 

    Default values:

    TRANSIPC_DEFAULT_SAMPLING_FREQ = 100 KHz
    TRANSIPC_DEFAULT_MEMORY_SIZE   = 64 KB
    TRANSIPC_DEFAULT_TRIGGER_DELAY = -25%

    By default, every transi channel will be 

    -> Off, 
    -> DC coupling
    -> 5V range, 
    -> 0% offset


=head2 mftrc_ConfigureRecordingChannel

	$status = mftrc_ConfigureRecordingChannel($ChannelName, $InputChannelNumber, $InputCouplingMode, $InputSignalMode, $InputVoltageRange, $InputOffset);


To configure a recording channel

	$ChannelName 		:	should be unique name (the name "EXTERNAL" is reserved (refer mftrc_ConfigureTrigger()) and shall not be used as a channel name)
	$InputChannelNumber	:	1 to Maximum allowed channels for connected TRC
	$InputCouplingMode	:	1 = AC, 2 = DC
	$InputSignalMode	:	1 = single-ended, 2 = differential
	$InputVoltageRange	:	one of 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100 (in volts)
	$InputOffset		:	0 to 100%

=head2 mftrc_ConfigureTransi

	$status = mftrc_ConfigureTransi($SamplingFrequency, $MemorySize, $TriggerDelay);

sets the sampling frequency, memory size for recording, trigger delay for the connected MF TransCom.
In Addition, refer to default TRC configuration (L</"mftrc_InitTRC">)

	$SamplingFrequency	:	in Hz
	$MemorySize		:	in bytes
	$TriggerDelay		:	in %

=head2 mftrc_ConfigureTrigger

	$status = mftrc_ConfigureTrigger($TriggerChannelName, $TriggerVoltage, $Hysterisis, $SlopeType);

To configure a recording channel as a Trigger, or External trigger.

	$TriggerChannelName	:	If channel name is given, it should be already configured for recording or use "EXTERNAL" for external trigger
	$TriggerVoltage		: 	voltage level for the trigger (not necessary for external trigger) in Volts
	$Hysterisis		:	Filtering (or protection) voltage level for trigger (not necessary for external trigger) in Volts
	$SlopeType		:	1 = positive, 2 = negative

Two or more trigger shall also be configured. In this case, all the trigger conditions will be OR-ed (TRC will be triggered if anyone of the trigger is obtained).

=head2 mftrc_End
	
	$status = mftrc_End();

Unloads the loaded DLL from process memory and deletes all function pointers.

=head2 mftrc_ExitTRC

	$status = mftrc_ExitTRC();

Removes all the configured channels and removes all the configuration details.

=head2 mftrc_GetDLLVersion

	($status, $version) = mftrc_GetDLLVersion();

returns version of TRC_Manager.dll 

=head2 mftrc_GetDeviceDetails

	($status, $DeviceId, $ServerSWVersion, $MACAddress, $NumOfChannels, $MaxMemory_byte, $MaxSpeed_Hz) = mftrc_GetDeviceDetails();

returns Device internal details for the connected MF Transient recorder.

=head2 mftrc_GetErrorString

    $errortext = mftrc_GetErrorString($status);

To get error string, if $status < 0

=head2 mftrc_GetRecordedData

	($status, $data_aref) = mftrc_GetRecordedData($ChannelName, $MinimumWaitTime_ms);

Returns the recorded data from previous measurement. If succeeded, $status will contain the number of signals & $data_aref will contain the recorded signals.

=head2 mftrc_PlotUNVForAllChannels

	$status = mftrc_PlotUNVForAllChannels($FileName, $MinimumWaitTime_ms);

Plots all the recorded signals of configured channels into a File with semi-colon seperated format (like .csv files).

=head2 mftrc_InitNewMeasurement

	$status = mftrc_InitNewMeasurement();

Initialize new measurement and wait for trigger

=head2 mftrc_InitTRC

	$status = mftrc_InitTRC($IPAddress);

Initializes the MF Transient recorder with default settings. 

By Default,

	* All recording channels will be set to OFF
	* All triggers will be OFF
	* Default sampling frequency = 0.1 MHz, Memory size = 64KB, Trigger delay = -25% 
	(records approximately 655 milliseconds)

=head2 mftrc_SendSWTrigger

	$status = mftrc_SendSWTrigger();

Sends a trigger by Software, if the measurement is already started and waiting for trigger.
If the measurement is not started, this function returns error.

=head2 mftrc_Start

	$status = mftrc_Start();

Loads the TRC_Manager.dll into Memory of the loading process. Initializes all function pointers for the low level DLL.
This function should be called before using any other functions (refer to example in L</"SYNOPSIS">)

=head2 mftrc_StopMeasurement

	$status = mftrc_StopMeasurement();

stops the on-going measurement


=head1 TRACEABILITY FUNCTIONS

=head2 mftrc_getCWrevision

returns MKS revision number of Interface.c file

=head2 mftrc_getPMrevision

returns MKS revision number of .pm file

=head2 mftrc_getXSrevision

returns MKS revision number of .xs file

=head1 AUTHOR

Arulkumar S, E<lt>Arulkumar.S@in.bosch.comE<gt>


=head1 SEE ALSO

perl, TRC_Manager.dll User Manual

=cut
