# *****************************************************************************************************
#
#  Copyright (c) 2014  Robert Bosch  GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_NIDAQ;

use strict;
use warnings;
use File::Basename;

BEGIN {
    use LIFT_general;
    S_add_paths2INC( ['./Win32'], ['./Win32'] );
}

use NIDAQ;
use LIFT_general;
use LIFT_numerics;
use Readonly;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_NIDAQ ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  NIDAQ_exit
  NIDAQ_init
  NIDAQ_INITArbitrary
  NIDAQ_SetVoltage
  NIDAQ_StartArbitrary
  NIDAQ_StopArbitrary
  NIDAQ_GetAnalogInputVoltage
  NIDAQ_StartAnalogInput
  NIDAQ_StopAnalogInput
  NIDAQ_SendSwTrigger
  NIDAQ_StoreAnalogInput
  NIDAQ_GetValues
  NIDAQ_ConfigureChannels

  $NIDAQ_FAILED
  $NIDAQ_OFFLINE

);

our ( $VERSION, $HEADER );

#Global variable accessible inside of package
Readonly my $DEVICE_NDX              => 1;         #DeviceIndex for NIDAQ Hardware
Readonly my $CURVE_DETAILS           => -1;        # Read curve details from Curve file (.svtc)
Readonly my $CHANNEL_NUMBER          => 1;         # Channel Number (AO0) of NIDAQ Hardware
Readonly my $CURRENT_VALUE           => 1;         #  Channel Number of NIDAQ Hardware
Readonly my $MAXMEASUREDURATION_SEC  => 900;       # 15 minutes(900 sec)is the maximum measurement duration in data acqusition
Readonly my $MAXNUMSAMPSFORGRAPHPLOT => 500000;    #500000 is the Maximum Number of points S_create_graph can take at once
my ( $NIDAQ_Init, $StartArbitrary, $InitArbitrary, $Dev_ID, %Channel, $amplifierTypeConfirmedByUser, $StartMeasurement, $ReadingMeasurement, $ChannelsConfigured, $Num_Channels_For_Acq, @channels_for_DataAcq, @channel_dividers );

$NIDAQ_Init                   = 0;                 #NIDAQ Initialization flag, default: uninitialised state
$StartArbitrary               = 0;                 #NIDAQ start Arbitrary flag, default: stop arbitrary state
$InitArbitrary                = 0;                 #NIDAQ init Arbitrary flag, default: Non-init arbitrary state
$amplifierTypeConfirmedByUser = 0;                 # Chosen amplifier type confirmed by user flag, default: not yet confirmed
$StartMeasurement             = 0;                 #A flag to tell that startAnalogInput was called
$ReadingMeasurement           = 0;                 #A flag to tell that SendSwTrigger was called
$Num_Channels_For_Acq         = 0;                 # number of channels configured for data acquisition

# variable description ::
# $Dev_ID; #Holds the numeric value of the device ID name given in testbench
# %Channel = (); #Holds the numeric value of the channel number given in testbench

=head1 NAME

LIFT_NIDAQ 

=head1 DESCRIPTION

      Perl extension for NIDAQ. This module helps in controlling of NIDAQ hardware through interface DLLs.

=head1 SYNOPSIS

    NIDAQ_init();
    NIDAQ_SetVoltage(8.0,'AO0');
    voltage_value = NIDAQ_GetAnalogInputVoltage('AO0');
    NIDAQ_INITArbitrary(36060, 1, 0.1, [17.0,17.0,17.0], 'AUDI_lv124_e_01_long_term_over_voltage');
    NIDAQ_StartArbitrary(36060, 1, 0.1);
    NIDAQ_StopArbitrary();
    NIDAQ_StartAnalogInput('AO0');
    NIDAQ_SendSwTrigger();
    NIDAQ_StopAnalogInput();
    NIDAQ_StoreAnalogInput("PlotFileName");
    NIDAQ_GetValues();
    NIDAQ_ConfigureChannels();
    NIDAQ_exit();

=head2 Testbench Configuration

    'Devices' =>{
	    'NIDAQ' => {
			'Device_ID'    =>"M6251",       # Devices can be :: NI-DAQmx and M6251
			'Amplifier'    => "Servowatt",  # Amplifiers can be: Servowatt and TOE7621_32
			#for the input channels used in data acquisition, provide the channel divider factor if you are using any.
			#if not provided, it will be considered as 1.
			'Channel_Input_Divider' => {
				'ai0' => 10,
				'ai1' => 5,
			},
	    },
    };
    
=head2 Project Configuration

    $Defaults = {	
    	  'NIDAQ' => {
            'ENABLE_LOG_FILE' => 0,                     # OPTIONAL (default: 0): 0=disable | 1=enable
			'Channel_Names_Acq' => ['ai0','ai1','ai2'], # channels names for data acquisition (AI0-AI15)
			# hardware trigger has priorty over Sw trigger
			# do not configure in case of Sw trigger
			'HwTrigger' => {
				'Trigger_channel' =>  "apfi0",     # apfi0 : external trigger (possible values : apfi0 , AI0, .. , AI15) 
				'TriggerValue_V'  =>  3,           # -10 to +10
				'TriggerSlope'    => 'positive',   # 'positive' or 'negative'
			},		
		},
    }; 
	
B<Notes:> 

The external trigger channel for M-series NIDAQ is B<"APFI0">.

=head1 Exported Subroutines


=head2 NIDAQ_exit

    NIDAQ_exit();

Disconnects the NIDAQ hardware and closes the connection.  

B<Arguments:>

=over

=item None 

=back

B<Return Value:>

=over

=item Pass
	: 1
	 
=item Error
	: undef
	
=item Offline mode
	: 1
	 
=back

B<Examples:>

    NIDAQ_exit();

=cut

sub NIDAQ_exit {

    unless ($NIDAQ_Init) {
        S_set_error( " NIDAQ not initialized \n", 120 );
        return;
    }

    if ($StartArbitrary) {
        NIDAQ_StopArbitrary();
    }

    if ($StartMeasurement) {
        NIDAQ_StopAnalogInput();
    }

    if ($ChannelsConfigured) {
        $ChannelsConfigured = 0;
    }

    if ($main::opt_offline) {
        $NIDAQ_Init = 0;
        S_w2log( 5, "NIDAQ_exit :: Communication with NIDAQ is closed \n" );
        return 1;
    }

    #Freeing hardware
    my $status = nidaq_freeHW($Dev_ID);
    CheckStatus($status);
    S_w2log( 5, "Status of nidaq_freeHW ($Dev_ID) :: $status \n" );

    #Disconnecting DLL
    my $end_status = nidaq_end();
    CheckStatus($end_status);
    S_w2log( 5, "Status of nidaq_end :: $end_status \n" );

    if ( $end_status >= 0 && $status >= 0 ) {
        $NIDAQ_Init = 0;
    }

    S_w2log( 5, "NIDAQ_exit :: Communication with NIDAQ is closed \n" );
    return 1;
}

=head2 NIDAQ_init

    iStatus = NIDAQ_init ();

Initializes the NIDAQ hardware.  

B<Arguments:>

=over

=item None 

=back

B<Return Value:>

=over

=item Pass
	: 1
	 
=item Error
	: undef
	
=item Offline mode
	: 1
	 
=back

B<Examples:>

    iStatus = NIDAQ_init();

=cut 

sub NIDAQ_init {
    S_w2log( 4, "NIDAQ_init :: Initializes the communication with NIDAQ hardware \n" );

    my $deviceID      = S_get_contents_of_hash( [ 'Devices', 'NIDAQ', 'Device_ID' ], $LIFT_config::LIFT_Testbench );
    my $amplifierName = S_get_contents_of_hash( [ 'Devices', 'NIDAQ', 'Amplifier' ], $LIFT_config::LIFT_Testbench );

    #both the channels are configured and both are initialized
    my $channelName = [ 'ao0', 'ao1' ];

    my $status;

    if ($NIDAQ_Init) {
        S_set_warning( " NIDAQ is already Initialized \n", 120 );
        return 1;
    }

    unless ( defined $deviceID ) {
        S_set_error( "LIFT_Testbench->{'Devices'}{'NIDAQ'}{'Device_ID'} is not given in testbench \n", 5 );
        return;
    }

    unless ( defined $amplifierName ) {
        S_set_error( "LIFT_Testbench->{'Devices'}{'NIDAQ'}{'Amplifier'} is not given in testbench \n", 5 );
        return;
    }

    $status = nidaq_setAmplifierName($amplifierName);

    if ( $status < 0 ) {
        $NIDAQ_Init = 0;
        S_set_error( "Specified amplifier name '$amplifierName' is unknown, see API documentation about testbench keys (choose only 'Servowatt' or 'TOE7621_32')\n", 5 );
        return;
    }

    # Changing the name into respective device number
    if ( $deviceID =~ /^NI-DAQmx$/ || $deviceID =~ /^M6251$/ ) {
        $Dev_ID = 1;
    }
    else {
        S_set_error( "The Device_ID ($deviceID) is not a valid Device, Valid NIDAQ devices are NI-DAQmx and M6251 \n", 114 );
        return;
    }

    my $index = 0;
    my @isInputChannel;

    #Changing the name into respective channel number
    foreach my $channel_name (@$channelName) {
        if ( $channel_name =~ /^AO0$/i ) {
            $Channel{ uc($channel_name) } = 1;
            $isInputChannel[$index] = 0;
        }
        elsif ( $channel_name =~ /^AO1$/i ) {
            $Channel{ uc($channel_name) } = 2;
            $isInputChannel[$index] = 0;
        }
        $index++;
    }

    my $version;
    $version = nidaq_getPMrevision();
    S_w2log( 5, "PM $version\n" );

    $version = nidaq_getXSrevision();
    S_w2log( 5, "XS $version\n" );

    $version = nidaq_getCWrevision();
    S_w2log( 5, "CW $version\n" );

    #starts the NIDAQ.

    my $start_status = nidaq_start();
    CheckStatus($start_status);
    S_w2log( 5, "Status of nidaq_start :: $start_status \n" );

    my $flagEnableLogFile = $main::ProjectDefaults->{'NIDAQ'}{'ENABLE_LOG_FILE'};
    if ( not defined($flagEnableLogFile) or $flagEnableLogFile != 1 ) { $flagEnableLogFile = 0; }
    my $snapshot_directory = "$main::REPORT_PATH/_snapshot_";
    unless ( -e $snapshot_directory or mkdir $snapshot_directory ) {
        S_set_error("Snapshot Directory: $snapshot_directory does not exist and could not be created\n");
        return;
    }
    $snapshot_directory =~ s/\//\\/g;    # replace all slashes by backslashes
    nidaq_LogFile_Enable( $flagEnableLogFile, $snapshot_directory );

    if ($main::opt_offline) {
        S_w2log( 4, "NIDAQ_init: NIDAQ is initialized \n" );
        $NIDAQ_Init = 1;

        #        %Channel = ( 'AO0' => 1, 'AO1' => 2 );

        return 1;
    }

    $index = 0;

    #Initialize the given channels in Testbench on NIDAQ hardware for given device
    foreach my $channel_name (@$channelName) {

        $status = nidaq_initHW( $Dev_ID, $Channel{ uc($channel_name) }, $isInputChannel[$index] );
        CheckStatus($status);
        S_w2log( 5, "Status of nidaq_initHW ($Dev_ID,$channel_name,$isInputChannel[$index]) :: $status \n" );
        $index++;

    }

    #sets the flag to true after success of nidaq start and init
    $NIDAQ_Init = 1 if ( $start_status >= 0 && $status >= 0 );

    if ($NIDAQ_Init) {
        my $hwInfos = nidaq_getHwInfos();
        S_w2log( 1, "NIDAQ-HW-Infos:\n$hwInfos\n" );
    }

    $amplifierTypeConfirmedByUser = CheckAmplificationFeedbackLoop();

    # Ask user only once per engine test-run (not for each call of NIDAQ_init again and again, if called several times in one engine test-run)
    unless ( $amplifierTypeConfirmedByUser ) {

        # Get user confirmation once for chosen amplifier type (incl. warning about different voltage factors of HW)
        my $message = sprintf <<DOC_NI_AMP;
Amplifier from testbench file is '$amplifierName'. Is this correct?
Click button 'No', if not sure, to avoid HW damage.


        More details:
        
        Amplification factors applied to
        niDaq-Output: -10V ... +10V are
        
            Servowatt:  x -5.0
            TOE7621_32: x  3.2
        
        ECU/HW-Damage easily possible, if type specified
        in Testbench-File is unequal real connected type.
DOC_NI_AMP
        my $response;
        $response = S_user_action( $message, 'YesNo' ) if !( $main::opt_offline || $main::opt_simulation );
        if ( $response eq 'yes' || $main::opt_offline || $main::opt_simulation ) {
            $amplifierTypeConfirmedByUser = 1;
        }
        else {
            $NIDAQ_Init = 0;
            S_set_error( "Selected amplifier type to be verified in testbench, in order to avoid ECU/periphery damage by out of range UBat\n", 5 );
            return;
        }
    }

    S_w2log( 4, "NIDAQ_init: NIDAQ is initialized \n" );
    return 1;
}

=head2 NIDAQ_INITArbitrary

    NIDAQ_INITArbitrary(iteration, time_s, voltage_aref, curve_name);

Initializes the arbitrary.  

B<Arguments:>

=over

=item 	iteration, time_s, voltage_aref, curve_name for required curve which are read from curve file 

=back

B<Return Value:>

=over

=item Pass
	: 1
	 
=item Error
	: undef
	
=item Offline mode
	: 1
	 
=back

B<Examples:>

    NIDAQ_INITArbitrary(iteration, time, voltage_aref, curve_name);

=cut 

sub NIDAQ_INITArbitrary {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NIDAQ_INITArbitrary( $iteration, $time_s, $voltage_aref, $curve_name )', @args );

    my $iteration    = shift @args;
    my $time_s       = shift @args;
    my $voltage_aref = shift @args;
    my $curve_name   = shift @args;

    unless ($NIDAQ_Init) {
        S_set_error( " NIDAQ not initialized \n", 120 );
        return;
    }

    if ($InitArbitrary) {
        S_set_error( "Arbitrary is already Initialized \n", 120 );
        return;
    }

    S_w2log( 4, "NIDAQ_INITArbitrary: Initialize the arbitrary of curve $curve_name with NIDAQ hardware \n" );

    #1,2,3 ...
    unless ( $iteration =~ /^\d+$/ ) {
        S_set_error( "Iteration ($iteration) should be numeric ", 114 );
        return;
    }

    #$time = 1.1, 2.2, 3 ... 1, 1.1 , .1, 0.1,
    unless ( ( $time_s !~ /^$/ ) && ( $time_s =~ /^\d*\.?\d*$/ ) ) {
        S_set_error( "time ($time_s) should be numeric ", 114 );
        return;
    }

    my $voltage_aref_count = scalar(@$voltage_aref);
    if ( $voltage_aref_count == 0 ) {
        S_set_error( "Voltage value is an empty", 114 );
        return;
    }

    if ($main::opt_offline) {
        $InitArbitrary = 1;
        S_w2log( 4, "NIDAQ_INITArbitrary:: Arbitrary is initialized \n" );
        return 1;
    }

    my $arb_curve_csv_path = $main::save_name . "\\arbitrary_data_Dump\\";    #saves the arbitrary CSV file in the reports folder.
    S_w2log( 5, "arb_curve_csv_path :: $arb_curve_csv_path \n" );
    unless ( -d $arb_curve_csv_path ) {
        mkdir $arb_curve_csv_path;
    }

    #Intialize the arbitrary
    my $initarb_status = nidaq_initArbitrary( $DEVICE_NDX, $voltage_aref_count, $iteration, $CURVE_DETAILS, $arb_curve_csv_path );
    CheckStatus($initarb_status);
    S_w2log( 5, "Status of nidaq_initArbitrary ($DEVICE_NDX,$voltage_aref_count,$iteration,$CURVE_DETAILS) :: $initarb_status \n" );
    S_w2log( 5, "loading the curve details into NIDAQ hardware, it takes few seconds...\n" );

    #Loads the voltage values into NIDAQ
    my $status = nidaq_programArbitrary( $DEVICE_NDX, $CHANNEL_NUMBER, $voltage_aref, $time_s, $CURRENT_VALUE );    # possibility to program vol curve or not
    CheckStatus($status);
    S_w2log( 5, "Status of nidaq_programArbitrary ($DEVICE_NDX,$CHANNEL_NUMBER, $voltage_aref,$time_s,$CURRENT_VALUE) :: $status \n" );

    #sets the flag to true after success of init  and program arbitrary
    $InitArbitrary = 1 if ( ( $initarb_status >= 0 ) && ( $status >= 0 ) );

    S_w2log( 4, "NIDAQ_INITArbitrary:: Arbitrary is initialized \n" );

    return 1;
}

=head2 NIDAQ_SetVoltage

	NIDAQ_SetVoltage($voltage [, $channel_name]);
	
Sets given voltage to required channel.
	
B<Arguments:>

=over

=item 	$voltage 
		Voltage value to set for the channel

=item 	$channel_name 
		(optional) 
		Channel name where the voltage is to be set.
    	(If not given, by default voltage set on channels configured in Testbench) 

=back

B<Return Value:>

=over

=item Pass
	: 1
	 
=item Error
	: undef
	
=item Offline mode
	: 1
	 
=back

B<Examples:>

    NIDAQ_SetVoltage(8.0,'AO0');

=cut 

sub NIDAQ_SetVoltage {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NIDAQ_SetVoltage( $voltage [, $channel_name] )', @args );

    my $voltage      = shift @args;
    my $channel_name = shift @args;

    my $status;

    unless ($NIDAQ_Init) {
        S_set_error( " NIDAQ not initialized \n", 120 );
        return;
    }

    # examples - 1, 3, 1.2, 1557.2254
    unless ( $voltage =~ /^[-]?\d+\.?\d*$/ ) {
        S_set_error( "Invalid voltage values: $voltage\n", 114 );
        return;
    }

    #Sets the voltage for the given channel
    if ( defined $channel_name ) {

        unless ( grep { /^$channel_name$/i } keys(%Channel) ) {
            S_set_error( "Given wrong channel name($channel_name). Given channel name doesnot exists in testbench configuration \n", 114 );
            return;
        }

        if ($main::opt_offline) {
            S_w2log( 5, "Voltage $voltage set to NIDAQ on channel $channel_name\n" );
            return 1;
        }

        $status = nidaq_setVoltage( $Dev_ID, $voltage, $Channel{ uc($channel_name) } );
        CheckStatus($status);
        S_w2log( 5, "Status of nidaq_setVoltage ($Dev_ID, $voltage, $channel_name) :: $status \n" );
    }

    #If specific channel is not given, voltage will be set to all the configured channels in testbench
    else {

        if ($main::opt_offline) {
            S_w2log( 5, "No channels given. Voltage $voltage set on channels configured in Testbench\n" );
            return 1;
        }

        foreach my $ch_name ( keys %Channel ) {
            $status = nidaq_setVoltage( $Dev_ID, $voltage, $Channel{ uc($ch_name) } );
            CheckStatus($status);
            S_w2log( 5, "Status of nidaq_setVoltage ($Dev_ID, $voltage, $ch_name) :: $status \n" );
        }
    }

    S_w2log( 4, "NIDAQ_SetVoltage: Voltage $voltage is set to NIDAQ \n" );

    return 1;
}

=head2 NIDAQ_StartArbitrary

    $success = NIDAQ_StartArbitrary( $samples, $iteration, $time_s );

Starts the curve that has been defined in NIDAQ_INITArbitrary to the arbitrary(always AO0 channel).
The parameters $samples, $iteration and $time_s are used to calculate the curve duration :  
duration = ($samples * $iteration * $time_s) in seconds.
The function waits for the calculated duration after starting the curve.
If $samples, $iteration and $time_s are all 0 then the function does not wait after 
starting the curve but returns immediately.  

B<Arguments:>

=over

=item 	$samples, $iteration and $time_s 

=back

B<Return Value:>

=over

=item Pass
	: 1
	 
=item Error
	: undef
	
=item Offline mode
	: 1
	 
=back

B<Examples:>

    NIDAQ_StartArbitrary(100, 2, 1.0);  # waits for 200sec
    NIDAQ_StartArbitrary(0, 0, 0);      # does not wait

=cut 

sub NIDAQ_StartArbitrary {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NIDAQ_StartArbitrary( $samples, $iteration, $time_s )', @args );

    my $samples   = shift @args;
    my $iteration = shift @args;
    my $time_s    = shift @args;

    S_w2log( 4, "NIDAQ_StartArbitrary: Starts loading the arbitrary curve \n" );

    unless ($InitArbitrary) {
        S_set_error( " Arbitrary is not Initialized \n", 120 );
        return;
    }

    if ($StartArbitrary) {
        S_set_error( " Arbitrary is already started \n", 120 );
        return;
    }

    #1,2,3 ...
    unless ( $iteration =~ /\d+/ ) {
        S_set_error( "Iteration ($iteration) should be numeric ", 114 );
        return;
    }

    unless ( $samples =~ /\d+/ ) {
        S_set_error( "samples ($samples) should be numeric ", 114 );
        return;
    }

    #1.1, 2.2, 3 ...
    unless ( $time_s =~ /^\d*\.?\d*$/ ) {
        S_set_error( "time ($time_s) should be numeric ", 114 );
        return;
    }

    if ($main::opt_offline) {
        S_w2log( 4, "NIDAQ_StartArbitrary: Started arbitrary curve \n" );
        $StartArbitrary = 1;
        return 1;
    }

    my $duration = $samples * $iteration * $time_s;
    S_w2log( 5, "The arbitrary is going to output the curve. Wait time after curve start is $duration seconds \n" );

    #Loading of arbitrary voltage for specific duration.
    my $status = nidaq_startArbitrary($Dev_ID);
    CheckStatus($status);
    S_w2log( 5, "Status of nidaq_startArbitrary ($Dev_ID,$duration): $status \n" );
    if ( $status >= 0 ) {
        $StartArbitrary = 1;
        S_w2log( 4, "NIDAQ_StartArbitrary: Started arbitrary curve \n" );
        S_wait_ms( $duration * 1000 );
        return 1;
    }
    else {
        S_w2log( 4, "NIDAQ_StartArbitrary: Error while starting the curve \n" );
        return;
    }
}

=head2 NIDAQ_StopArbitrary

    NIDAQ_StopArbitrary();

Stops the execution of arbitrary.

B<Arguments:>

=over

=item 	None 

=back

B<Return Value:>

=over

=item Pass
	: 1
	 
=item Error
	: undef
	
=item Offline mode
	: 1
	 
=back

B<Examples:>

    NIDAQ_StopArbitrary();  
    
=cut 

sub NIDAQ_StopArbitrary {
    unless ($StartArbitrary) {
        S_set_error( " Arbitrary is not started \n", 120 );
        return;
    }

    if ($main::opt_offline) {
        $StartArbitrary = $InitArbitrary = 0;
        S_w2log( 4, "NIDAQ_StopArbitrary: Stopped the execution of arbitrary \n" );
        return 1;
    }

    my $status = nidaq_stopArbitrary($Dev_ID);
    CheckStatus($status);
    S_w2log( 5, "Status of nidaq_stopArbitrary ($Dev_ID) :: $status \n" );

    #Un-initializing and stopping of arbitrary
    if ( $status >= 0 ) {
        $StartArbitrary = $InitArbitrary = 0;
        S_w2log( 4, "NIDAQ_StopArbitrary: Stopped the execution of arbitrary \n" );
        return 1;
    }
    else {
        S_w2log( 4, "NIDAQ_StopArbitrary: Failed to stop the execution of arbitrary \n" );
        return;
    }

}

=head2 NIDAQ_GetAnalogInputVoltage

    $return_voltage = NIDAQ_GetAnalogInputVoltage($channel_name);

It reads the analog voltage value from the $channel_name passed as an argument. 
The function can be used to read the voltage either from input or output channel.  

B<Arguments:>

=over

=item $channel_name

	 - Channel name from where the voltage is to be read.
	 
=back

B<Return Value:>

=over

=item Pass
	: $return_voltage - Voltage value read at the specified channel.
	 
=item Error
	: undef
	
=item Offline mode
	: 1
	 
=back

B<Examples:>

    8.00356 = NIDAQ_GetAnalogInputVoltage('AI0');
    6.50352 = NIDAQ_GetAnalogInputVoltage('AO0');

=cut

sub NIDAQ_GetAnalogInputVoltage {

    my @args = @_;
    return unless S_checkFunctionArguments( 'NIDAQ_GetAnalogInputVoltage($channel_name)', @args );
    my $channel_name = shift @args;    # volt source output channel where the voltage curve will be injected

    unless ($NIDAQ_Init) {

        S_set_error( "NIDAQ not initialized \n", 120 );
        return;
    }

    unless ( $channel_name =~ m/^AI([0-9]|1[0-5])$/i || grep { /^$channel_name$/i } keys(%Channel) ) {
        S_set_error( "Given wrong channel name($channel_name). Given channel name is not AO0/AO1/AI0-AI15 \n", 114 );
        return;
    }

    S_w2log( 5, "Get analog voltage of NIDAQ \n" );
    return 1 if ($main::opt_offline);

    my $isOutput = 0;
    if ( $channel_name =~ /^AI(\d+)$/i ) {

        $isOutput = 0;    #AnalogInput =0
    }

    else {
        $isOutput = 1;    #AnalogOutput =1
    }

    my $voltage = nidaq_getAnalogInputVoltage( $Dev_ID, $Channel{ uc($channel_name) }, $isOutput );
    my $decimal_precision = 5;
    $voltage = substr( $voltage, 0, index( $voltage, '.' ) + $decimal_precision );
    if ( $voltage =~ /^[0-9]\d*(\.\d+)?$/ ) {
        S_w2log( 4, "Get analog voltage of NIDAQ for device $Dev_ID and channel $channel_name is $voltage \n" );
        return ($voltage);
    }
    else {
        S_set_error( "Invalid voltage value obtained. \n", 120 );
        return;
    }
}

=head2 NIDAQ_StartAnalogInput

    $returnValue = NIDAQ_StartAnalogInput();

Starts a new measurement and waits for trigger. Unless a Software trigger or a Hardware trigger is obtained , the NIDAQ will not start recording the data.

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $status 

1 - success

undef - error

1 - offline mode

=back

B<Examples:>

    $status = NIDAQ_StartAnalogInput();

=cut

sub NIDAQ_StartAnalogInput {

    unless ($NIDAQ_Init) {
        S_set_error( "NIDAQ not initialized \n", 120 );
        return;
    }

    if ($StartMeasurement) {
        S_set_warning("Data acquisition is already started \n");
        return 1;
    }

    unless ($ChannelsConfigured) {
        S_set_error( " Channels for acquisition is not yet configured. Please call NIDAQ_ConfigureChannels() first and make sure that NIDAQ section is present in Project constant file. \n", 120 );
        return;
    }

    S_w2log( 5, "Start analog input of NIDAQ \n" );
    $StartMeasurement = 0;
    if ($main::opt_offline) {
        $StartMeasurement = 1;
        return 1;
    }

    my $status = nidaq_startAnalogInput($Dev_ID);
    CheckStatus($status);

    S_w2log( 5, "Status of nidaq_startAnalogInput ($Dev_ID) :: $status \n" );
    $StartMeasurement = 1 if ( $status >= 0 );

    return 1;
}

=head2 NIDAQ_StopAnalogInput

    $returnValue = NIDAQ_StopAnalogInput();

This function stops the measurement that has already started.

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $status 

1 - success

undef - error

1 - offline mode

=back

B<Examples:>

     $status = NIDAQ_StopAnalogInput();

=cut

sub NIDAQ_StopAnalogInput {

    unless ($StartMeasurement) {
        S_set_warning("Data acquisition is not started. Please call StartAnalogInput() first\n");
        return 1;
    }

    S_w2log( 5, "Stop analog input of NIDAQ \n" );

    if ($main::opt_offline) {
        $StartMeasurement   = 0;
        $ReadingMeasurement = 0;
        return 1;
    }

    my $status = nidaq_stopAnalogInput($Dev_ID);
    CheckStatus($status);
    S_w2log( 5, "Status of nidaq_stopAnalogInput ($Dev_ID) :: $status \n" );

    if ( $status >= 0 ) {
        $StartMeasurement   = 0;
        $ReadingMeasurement = 0;
    }

    return 1;
}

=head2 NIDAQ_SendSwTrigger

    $returnValue = NIDAQ_SendSwTrigger();

This function sends a software trigger after which the analog measurment starts.

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $status 

1 - success

undef - error

1 - offline mode

=back

B<Examples:>

    $status = NIDAQ_SendSwTrigger();
    
B<Notes:> 

Can be called only after L</"NIDAQ_StartAnalogInput">

=cut

sub NIDAQ_SendSwTrigger {

    unless ($StartMeasurement) {
        S_set_error( "Data acquisition is not started. Please call StartAnalogInput() first\n", 120 );
        return;
    }

    if ($ReadingMeasurement) {
        S_set_error( "StopAnalogInput was not called after the previous measurement.Please call StopAnalogInput()\n", 120 );
        return;

    }

    S_w2log( 5, "Send software trigger of NIDAQ \n" );

    if ($main::opt_offline) {
        $ReadingMeasurement = 1;
        return 1;
    }

    my $status = nidaq_sendSwTrigger($Dev_ID);
    CheckStatus($status);
    S_w2log( 5, "Status of nidaq_sendSwTrigger ( $Dev_ID ) :: $status \n" );

    $ReadingMeasurement = 1 if ( $status >= 0 );
    return 1;
}

=head2 NIDAQ_GetValues

    $time_volt_href = NIDAQ_GetValues();

This function returns a hash reference of time and voltage values read during the continous data acquisition.

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $time_volt_href 

Hash reference containing the arrays of time and voltage values - success

undef - error

Hash reference containing the arrays of time and voltage values taking value 1 - offline mode

=back

B<Examples:>

    $time_volt_href = NIDAQ_GetValues();
	Example Hash Structure : 
	$time_volt_href = { 
		'time'=>{ 
			1.0, 
			1.1,
			1.2,
			1.3,
		}
		'AO0'=>{ 
			8.20001,
			8.19999,
			8.20002,
			8.18999,
		}
		'AI0'=>{ 
			4.30000,
			4.29898,
			4.29999,
			4.30002,
		}
	}
	
	Offline Mode : 
	$time_volt_href = { 
		'time'=>{ 
			1.0, 			
		}
		'channels_configured'=>{ 
			1.00000,
		}
	}
											
B<Notes:> 

Can be called only after L</"NIDAQ_StopAnalogInput">
Once the data has been retreived the buffer containing the read data will be cleared. 
So, calling this function twice continously will result in wrong/empty data. 

=cut

sub NIDAQ_GetValues {

    # STEP get config source : -  Channel_Names_Acq
    my $config_source = $main::ProjectDefaults->{'NIDAQ'};    #configure for NIDAQ

    # IF check NIDAQ Initialized?
    # IF-NO-START
    unless ($NIDAQ_Init) {
        S_set_error( " NIDAQ not initialized \n", 120 );

        # STEP NIDAQ is not initialized
        return;
    }

    # IF-NO-END

    # IF-YES-START
    # STEP NIDAQ is initialized

    # IF check Measurement Stopped?
    # IF-NO-START
    if ($StartMeasurement) {
        S_set_error("Data acquisition is not stopped. Please call StopAnalogInput() first and then get values.\n");

        # STEP Measurement is not stopped
        return;
    }

    # IF-NO-END

    # IF-YES-START
    # STEP Measurement is stopped

    # IF check channels configured?
    # IF-NO-START
    unless ($ChannelsConfigured) {
        S_set_error("Measurement did not happen as channels are not configured. Please configure the channels and call measuremnt functions\n");

        # STEP Measurement is not configured
        return;
    }

    # IF-NO-END

    # IF-YES-START
    # STEP Channels are configured.

    my $counter = 1;
    my ( $dataPoints_href, $data_href );
    my ( $sampNum, $index ) = 0;

    # IF check Online or offline ?
    # IF-OFFLINE-START
    # STEP return a unit hash containing unit values for time and channels_configured

    if ($main::opt_offline) {
        my $unit_tv_href = {
            'time'                => 1.0,
            'channels_configured' => 1.0,
        };
        return $unit_tv_href;
    }

    # IF-OFFLINE-END

    # IF-ONLINE-START

    my $samples = niDaqGetNumSamples($Dev_ID);

    # STEP obtain the time and voltage data recorded.
    my ( $status, $time_aref, $vol_aref ) = niDaq_getValues( $Dev_ID, $samples, $Num_Channels_For_Acq );

    unless ( defined(@$time_aref) && defined(@$vol_aref) ) {
        S_set_error( "Data acqusition has not happened or trigger was not obtained. Please call measurement functions to get values. \n", 23 );
        return;
    }

    # STEP store the obtained TIME data to final storage
    $data_href = { 'time' => $time_aref };

    #LOOP-OUTER-START read from each channel until all channels configured are read.
    for ( $counter = 1 ; $counter <= $Num_Channels_For_Acq ; $counter++ ) {

        #LOOP-INNER-START read sample of voltage data obtained that particular channel until all samples are over .
        for ( $index = 0 ; $index < $samples ; $index += $Num_Channels_For_Acq ) {

            #STEP gather and store the sample read at corresponding channel
            push @{ $dataPoints_href->{$counter} }, ( $$vol_aref[ $index + ( $counter - 1 ) ] );
        }

        #LOOP-INNER-END  reading voltage data sample from a particular channel over?
    }

    #LOOP-OUTER-END reading from last channel over?

    #building the hash ref for plotting the graph
    $counter = 1;

    #LOOP-START read channel corresponding voltage one by one and store it until it is read from all channels
    while ( $counter <= $Num_Channels_For_Acq ) {

        # multiplying the obtained voltage values with the channel input divider factor
        my @voltage_arr = map { $_ * $channel_dividers[ $counter - 1 ] } @{ $dataPoints_href->{$counter} };

        #STEP store the voltage samples read and add it to final storage
        $data_href->{ $channels_for_DataAcq[ $counter - 1 ] } = [@voltage_arr];
        $counter++;
    }

    # LOOP-END all channels read ?

    # IF-ONLINE-END
    # STEP return stored time and voltage data
    # IF-YES-END
    # IF-YES-END
    # IF-YES-END
    # STEP END
    return $data_href;
}

=head2 NIDAQ_StoreAnalogInput

    $returnValue = NIDAQ_StoreAnalogInput($plotFileName);

This function creates "Graphs" folder inside the report folder. And stores the continuously acquired data into a .unv file and .png file in the "Graphs" folder with the name user specifies.

B<Arguments:>

=over

=item $plotFileName 

File name with which a .png and .unv file are created for the continuously acquired data in the "Graphs" folder.
If the graphs are long ( meaning, number of samples exceeding the maximum limit ) , it resamples the continously acquired data and plots the graph. 

=back

B<Return Value:>

=over

=item $status 

1 - success

undef - error

1 - offline mode

=back

B<Examples:>

     $status = NIDAQ_StoreAnalogInput("plotFileName"); 

B<Notes:> 

Can be called only after L</"NIDAQ_StopAnalogInput"> i.e, once the acquisition of data is over.

=cut

sub NIDAQ_StoreAnalogInput {

    my @args = @_;
    my $maxNumSampsForPlot;
    my $numSamps_acquired;
    my $time_volt_href          = {};
    my $time_volt_for_plot_href = {};
    return unless S_checkFunctionArguments( 'NIDAQ_StoreAnalogInput( $file )', @args );
    my $plotFilename = shift @args;

    unless ($NIDAQ_Init) {
        S_set_error( " NIDAQ not initialized \n", 120 );
        return;
    }

    if ($StartMeasurement) {
        S_set_error("Data acquisition is not stopped. Please call StopAnalogInput() first and then store\n");
        return;
    }

    my $snapshot_directory = "$main::REPORT_PATH/Graphs";
    unless ( -e $snapshot_directory or mkdir $snapshot_directory ) {
        S_set_error("Unable to create $snapshot_directory\n");
        return;
    }

    my $curveFile = $snapshot_directory . "\\$plotFilename";
    $curveFile =~ s/\.\w+$//;    # cut off file extension
                                 # creates a dummy pic for offline mode and adds the same to report
    if ($main::opt_offline) {
        S_create_dummy_file( $curveFile . ".txt.unv" );
        S_create_dummy_pic( $curveFile . ".png" );
        S_add_pic2html( "file:///$curveFile.png", 'width=700', "file:///$curveFile.txt.unv", 'TYPE="text/unv"', 1 );
        return 1;
    }

    S_w2log( 5, "Store analog input of NIDAQ \n" );

    if ($Num_Channels_For_Acq) {
        $maxNumSampsForPlot = ( $MAXNUMSAMPSFORGRAPHPLOT / $Num_Channels_For_Acq );
        $numSamps_acquired  = ( niDaqGetNumSamples($Dev_ID) / $Num_Channels_For_Acq );
    }
    else {
        S_set_error( " Channels not configured. Number of channels for acquisition is 0. Please mention the channels in Project Defualts \n", 120 );
        return 0;
    }

    $time_volt_href = NIDAQ_GetValues();

    my $resampled_time_volt_href = {};

    #If the number of samples acquired is more than the maximum number of points the plotting function can take ( = 500000 )
    if ( $numSamps_acquired > $maxNumSampsForPlot ) {

        S_w2log( 5, " The number of samples obtained exceeds the memory limit (=$maxNumSampsForPlot). Hence needs Re-sampling..\n " );

        my $res_factor             = $numSamps_acquired / $maxNumSampsForPlot;
        my $resampled_time_aref    = $time_volt_href->{'time'};
        my $total_elapsed_time_sec = @$resampled_time_aref[ $numSamps_acquired - 1 ];
        my $mean_time_sec          = ( $total_elapsed_time_sec / $numSamps_acquired );
        my $dtOut_sec              = $mean_time_sec * $res_factor;

        foreach my $chnl_name ( keys(%$time_volt_href) ) {
            if ( $chnl_name ne 'time' ) {
                my $dataIn_aref = $time_volt_href->{$chnl_name};

                $resampled_time_volt_href = {
                    'dataIn_aref' => $dataIn_aref,
                    'dtIn_sec'    => $mean_time_sec,
                    'dtOut_sec'   => $dtOut_sec,
                };
                $resampled_time_volt_href = NUM_ResampleData($resampled_time_volt_href);
                my $resampled_voltages_aref = $resampled_time_volt_href->{dataOutValues_aref};

                $numSamps_acquired = scalar(@$resampled_voltages_aref);

                if ( $resampled_time_volt_href->{status} != 1 || $numSamps_acquired > $maxNumSampsForPlot ) {
                    S_set_warning(" '$curveFile' contains too many values ( $numSamps_acquired ) to plot and hence plotting not possible \n");
                    return;
                }
                else {
                    $time_volt_href->{$chnl_name} = $resampled_voltages_aref;
                }
            }
        }
        $time_volt_href->{'time'} = $resampled_time_volt_href->{dataOutTimes_aref};
    }

    S_w2rep("Plot for Curve File : $curveFile\n");
    my $status = S_create_graph( $time_volt_href, $curveFile, 'Continuous Data Acquisition Plot', 'white', 'no_interpolation', 'Voltage in v' );
    S_add_pic2html( "file:///$curveFile.png", 'width=600', "file:///$curveFile.txt.unv", 'TYPE="text/unv"', 1 );
    CheckStatus($status);
    S_w2log( 5, "Status of S_create_graph ($time_volt_href, $plotFilename) :: $status \n" );

    return 1;
}

=head2 NIDAQ_ConfigureChannels

    $returnValue = NIDAQ_ConfigureChannels([config_href]);

This function validates & configures all channels mentioned in ProjectConst or the hash ref(if passed as parameter). Configures the Trigger based on the mentioned configuration.

B<Arguments:>

=over

=item data_href(optional) 

The hash reference having the details on the configuration for data acquisition.

Example :
 
	my $config_href = {
		'Channel_Names_Acq' => ['ai0','ai1','ai2'], # channels names for data acquisition (AI0-AI15)	
		# hardware trigger has priorty over Sw trigger
		# do not configure in case of Sw trigger				
		'HwTrigger' => {					
			'Trigger_channel' =>  "apfi0",     # apfi0 : external trigger (possible values : apfi0 , AI0, .. , AI15)
			'TriggerValue_V'  =>  3,           # -10 to +10
			'TriggerSlope'    => 'positive',   # 'positive' or 'negative'					
		},
	};	
				

=back

B<Return Value:>

=over

=item $status 

1 - success

0 - error

1 - offline mode

=back

B<Examples:>

     $status = NIDAQ_ConfigureChannels([config_href]);
    
B<Notes:> 

1. Before calling L</"NIDAQ_ConfigureChannels">, L</"NIDAQ_StopAnalogInput"> must be called if any previous measurement is in progress state.

2. Before calling L</"NIDAQ_StartAnalogInput">, L</"NIDAQ_ConfigureChannels"> must be called.

=cut

sub NIDAQ_ConfigureChannels {

    my @args        = @_;
    my $config_href = shift @args;
    unless ($NIDAQ_Init) {
        S_set_error( " NIDAQ not initialized \n", 120 );
        return;
    }

    if ($StartMeasurement) {
        S_set_error(" Measurement is not stopped. Please call StopAnalogInput. \n");
        return;
    }

    S_w2log( 5, "Configure channels of NIDAQ \n" );
    my $config_source    = $main::ProjectDefaults->{'NIDAQ'};
    my $testbench_source = $LIFT_config::LIFT_Testbench->{'Devices'}->{'NIDAQ'};

    #if parameter is passed, use that as the config source
    if ( defined $config_href ) {
        $config_source = $config_href;
    }

    my $channelsForAcq = $config_source->{'Channel_Names_Acq'};
    my $trig_chn       = $config_source->{'HwTrigger'}{'Trigger_channel'};
    my $trig_volt_val  = $config_source->{'HwTrigger'}{'TriggerValue_V'};
    my $slope          = $config_source->{'HwTrigger'}{'TriggerSlope'};

    if ( defined $slope ) {

        #validate slope type
        unless ( $slope =~ /positive/i || $slope =~ /negative/i ) {
            S_set_error( "Invalid 'SlopeType' specified for ProjectDefaults->{'NIDAQ'}{'HwTrigger'}{'slope'}. 'Slope' shall be 'positive' or 'negative'", 20 );
            return;
        }
    }

    unless ($channelsForAcq) {
        S_set_error( "Channel_Names_Acq in project defaults or in the hash reference is empty. Please provide the channels for acquisition\n", 114 );
        return;
    }

    foreach my $chan_name (@$channelsForAcq) {
        unless ( $chan_name =~ m/^AI([0-9]|1[0-5])$/i ) {
            S_set_error( "Given invalid channel name ($chan_name) in Project defaults. \n Valid channel names are:AI0-AI15 \n", 114 );
            return;
        }
    }

    unless ($trig_chn) {
        $trig_chn      = "none";
        $trig_volt_val = 100;
        S_set_warning("The trigger channel is not mentioned in ProjectDefaults->{'NIDAQ'}{'HwTrigger'}{'Trigger_channel'}. So the acqusition will wait for a SW trigger. \n");
    }

    if ( defined $trig_chn ) {
        unless ( defined $trig_volt_val ) {
            S_set_error( "Given trigger channel name ($trig_chn). But trigger voltage is not mentioned in ProjectDefaults->{'NIDAQ'}{'HwTrigger'}{'TriggerValue_V'}.\n", 114 );
            return;
        }
    }

    $Num_Channels_For_Acq = scalar(@$channelsForAcq);

    my $trig_slope;

    unless ( defined $slope ) {
        $trig_slope = 1;
        S_set_warning("The slope for trigger is not menioned in ProjectDefaults->{'NIDAQ'}{'HwTrigger'}{'TriggerSlope'}. So by default a positive slope is considered. \n");
    }
    if ( $slope ~~ m/positive/i ) {
        $trig_slope = 1;
    }
    if ( $slope ~~ m/negative/i ) {
        $trig_slope = 0;
    }

    #the trigger channel if not apfi0, should be the first channel configured for the task
    #so checking if the trigger channel already exists in the channels for acquisition, if yes, making it the first element in the array.
    if ( defined $trig_chn && ( $trig_chn ne "none" ) ) {
        my ($index_match) = grep { @$channelsForAcq[$_] =~ m/$trig_chn/i } 0 .. $#$channelsForAcq;
        if ( defined $index_match ) {
            splice @$channelsForAcq, $index_match, 1;    #splicing the element from the array
            unshift @$channelsForAcq, $trig_chn;         #adding it as the first element
        }
        else {
            unless ( $trig_chn =~ m/^apfi0$/i ) {
                unshift( @$channelsForAcq, $trig_chn );
                $Num_Channels_For_Acq++;
            }
        }
    }

    #Check if the divider factor is configured for the acquisition channels, if not consider it to be 1
    map {
        if ( $testbench_source->{'Channel_Input_Divider'}->{$_} ) {
            push @channel_dividers, $testbench_source->{'Channel_Input_Divider'}->{$_};
        }
        else {
            push @channel_dividers, 1;
        }
    } @$channelsForAcq;

    if ($main::opt_offline) {
        $ChannelsConfigured = 1;
        return 1;
    }

    my $index = 0;
    my ( @chnType, @channels );

    #Changing the name into respective channel number
    foreach my $chan_name (@$channelsForAcq) {
        $channels_for_DataAcq[$index] = $chan_name;
        if ( $chan_name =~ /^AI(\d+)$/i ) {
            $channels[$index] = ( $1 + 1 );
            $chnType[$index]  = 0;
        }
        $index++;
    }

    my $status = nidaq_configureChannels( $Dev_ID, \@channels, \@chnType, $trig_chn, $trig_volt_val, $trig_slope );

    if ( $status >= 0 ) {
        $ChannelsConfigured = 1;
        S_w2log( 5, "Configured channels of NIDAQ \n" );
        return 1;
    }
    else {
        S_set_error( "Configuring channels of NIDAQ failed\n", 114 );
        return;
    }

}

=head1 Non_Exported Subroutines

=head2 CheckStatus

    $error_msg = CheckStatus($status);

Checks the status of given value and throws an error message

B<Arguments:>

=over

=item $status 

status value

=back

B<Return Value:>

=over

=item $error_msg 

1 -success

error_msg :: Respective error message of status value passed

1 :: offline mode

=back

B<Examples:>

     $error_msg = CheckStatus(-10);

=cut

sub CheckStatus {
    my $status = shift;

    return 1 if $main::opt_offline;

    if ( $status < 0 ) {
        my $errortext = nidaq_getErrorString($status);
        S_set_error( "NIDAQ ($status): $errortext \n", 5 );
    }

    return 1;
}

=head2 CheckAmplificationFeedbackLoop

    $success = CheckAmplificationFeedbackLoop();

Checks if Amplification can successfull be measured by using the feedback loop measurement via Ai0.

B<Return Value:>

=over

=item $success 

1 :: success

0 :: measuring via feedback loop not successfull

=back

B<Examples:>

     $success = CheckAmplificationFeedbackLoop();

=cut

sub CheckAmplificationFeedbackLoop {
    my $amplifierName = S_get_contents_of_hash( [ 'Devices', 'NIDAQ', 'Amplifier' ], $LIFT_config::LIFT_Testbench );
    
    return 0 unless $amplifierName eq "TOE7621_32";
    return 0 unless CheckAmplificationFeedbackLoopSingleVoltage(0);
    return 0 unless CheckAmplificationFeedbackLoopSingleVoltage(-0.1);
    return 0 unless CheckAmplificationFeedbackLoopSingleVoltage(0.1);
    return 0 unless CheckAmplificationFeedbackLoopSingleVoltage(1);
    return 0 unless CheckAmplificationFeedbackLoopSingleVoltage(13);

    S_w2log(3, "CheckAmplificationFeedbackLoop successfull for all 5 voltages '0V | -0.1V | 0.1V | 1V | 13'\n");

    return 1;
}

=head2 CheckAmplificationFeedbackLoopSingleVoltage

    $success = CheckAmplificationFeedbackLoopSingleVoltage( $voltage);

Checks if Amplification can successfull be measured by using the feedback loop measurement via Ai0.

B<Return Value:>

=over

=item $success 

1 :: success

0 :: measuring via feedback loop not successfull

=back

B<Examples:>

     $success = CheckAmplificationFeedbackLoop();

=cut

sub CheckAmplificationFeedbackLoopSingleVoltage {
    my $voltage_V = shift;
    my ( $sum, $last_average );
    my $failed = 0;

    S_w2log(5, "CheckAmplificationFeedbackLoopSingleVoltage started for \$voltage_V = '$voltage_V'\n");
	
    NIDAQ_SetVoltage($voltage_V);
    NIDAQ_ConfigureChannels({Channel_Names_Acq => ['ai0']});
    NIDAQ_StartAnalogInput();
    S_wait_ms(50);
    NIDAQ_SendSwTrigger();
    S_wait_ms(100);
    NIDAQ_StopAnalogInput();
    NIDAQ_SetVoltage(0);
    my $time_volt_href = NIDAQ_GetValues();

    foreach my $i ( 0 .. $#{ $time_volt_href->{"ai0"} } ) {
        my $value =$time_volt_href->{"ai0"}[$i]; 
        S_w2log(5, "CheckAmplificationFeedbackLoopSingleVoltage value '$i' at voltage '$voltage_V V' = '$value V'\n");
        $sum += $value;
        $last_average = $sum / ( $i + 1 );
        next if ( $value < $voltage_V + 0.03 and $value > $voltage_V - 0.03 );
        S_w2log(3, "CheckAmplificationFeedbackLoopSingleVoltage failed at voltage '$voltage_V V' for value '$i' with \$value = '$value V'\n");
        return 0;
    }
    
    S_w2log(5, "CheckAmplificationFeedbackLoopSingleVoltage calculated average at voltage '$voltage_V V' = '$last_average V'\n");
    unless ( $last_average < $voltage_V + 0.01 and $last_average > $voltage_V - 0.01 ){
        return 0; 
        S_w2log(3, "CheckAmplificationFeedbackLoopSingleVoltage failed at voltage '$voltage_V V' for average = '$last_average V'\n");    
    }

    return 1;
}

1;

__END__

=head1 AUTHORS

Puneeth BA, E<lt> PuneethB.Amarnath@in.bosch.com E<gt>
Gayathri Harikrishna, E<lt> Gayathri.Harikrishna@in.bosch.com E<gt>

=head1 NOTES

B<ReturnValue>

offline mode :: B<1>

Failure of subroutine execution :: B<-1000>

=head1 SEE ALSO

    perl documentation

=cut

