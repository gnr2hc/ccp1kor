package NIDAQ;

use strict;
use warnings;
use Carp;
use LIFT_simulation;
no strict 'refs';

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use NIDAQ ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
            nidaq_getPMrevision
            nidaq_getXSrevision
            nidaq_getCWrevision
            nidaq_start
			nidaq_LogFile_Enable
            nidaq_end
            nidaq_initHW
            nidaq_setAmplifierName
			nidaq_setInputChnlDivider
            nidaq_getHwInfos
            nidaq_setVoltage
            nidaq_initArbitrary
            nidaq_programArbitrary
            nidaq_startArbitrary
            nidaq_stopArbitrary
            nidaq_freeHW
            nidaq_getErrorString
			nidaq_getAnalogInputVoltage
			nidaq_startAnalogInput
			nidaq_sendSwTrigger
			nidaq_stopAnalogInput
			niDaq_getValues
			niDaqGetNumSamples
			nidaq_configureChannels
);

our $VERSION = '0.01';
our $amplifier={
	'Servowatt' =>
				{
	            'volt_factor' => -5.0,  # Servowatt amplifier voltage factor value
 				},
    'TOE7621_32' =>
                {
                'volt_factor' => 3.2,  # TOE7621_32 amplifier voltage factor value
                },
    };

my $amplifierName = 'unknown';

require XSLoader;
XSLoader::load('NIDAQ', $VERSION);

if ( $main::opt_simulation ){
	# redefine all functions for simulation mode with default return values
	foreach my $function (@EXPORT){
		# each function in @EXPORT is redefined using SIM_returnValues
		*{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
	}

	# define return values table (especially for default values) and pass it to simulation module
	my $returnValuesTable_href = {
		'nidaq_getPMrevision' => { 'default' => ['simu 1.0']},
		'nidaq_getXSrevision' => { 'default' => ['simu 1.0']},
		'nidaq_getCWrevision' => { 'default' => ['simu 1.0']},
		'nidaq_start' => { 'default' => [1]},
		'nidaq_end' => { 'default' => [1]},
		'nidaq_initHW' => { 'default' => [1]},
		'nidaq_getHwInfos' => { 'default' => ['HW Infos']},
		'nidaq_setVoltage' => { 'default' => [1]},
		'nidaq_initArbitrary' => { 'default' => [1]},
		'nidaq_programArbitrary' => { 'default' => [1]},
		'nidaq_startArbitrary' => { 'default' => [1]},
		'nidaq_stopArbitrary' => { 'default' => [1]},
		'nidaq_freeHW' => { 'default' => [1]},
		'nidaq_getErrorString' => { 'default' => ['Error message']},
		'nidaq_getAnalogInputVoltage' => { 'default' => [1]},
		'nidaq_startAnalogInput' => { 'default' => [1]},
		'nidaq_stopAnalogInput' => { 'default' => [1]},
		'nidaq_sendSwTrigger' => { 'default' => [1]},
		'niDaq_getValues' => { 'default' => [1,[1],[1]]},
		'niDaqGetNumSamples' => { 'default' => [1]},
		'nidaq_configureChannels' => { 'default' => [1]}
	};

	SIM_addToValuesTable( $returnValuesTable_href );
};

# Preloaded methods go here.

sub nidaq_getPMrevision{
    return ('SCM');
}

sub nidaq_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub nidaq_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

sub nidaq_setAmplifierName
{
    $amplifierName = shift;
	# Reject unknown amplifier names
	unless  ( exists $amplifier->{$amplifierName} )
    {
        return -1;
    }
    return 1;
}

sub nidaq_setVoltage{

	my ($Dev_ID, $voltage, $channel_name) = @_;
	
    if ( exists $amplifier->{$amplifierName} )
    {
    	$voltage /= $amplifier->{$amplifierName}{'volt_factor'};
        nidaq_lowlevel_setVoltage($Dev_ID, $voltage, $channel_name);
    }
}

sub nidaq_programArbitrary{

	my ($Dev_ID, $channel_name, $voltage_aref,$time, $current) = @_;
    my $status = 0;
    if ( exists $amplifier->{$amplifierName} )
    {
        # apply the amplification factor
        foreach my $voltage_value (@$voltage_aref)
        {
           $voltage_value /= $amplifier->{$amplifierName}{'volt_factor'};
        }
        $status = nidaq_lowlevel_programArbitrary($Dev_ID,$channel_name, $voltage_aref,$time,$current);
    }
    else
    {
        $status = -1;
    }

	return $status;
}

sub nidaq_getAnalogInputVoltage{	
	my ($Dev_ID, $channel_name, $MeasType) = @_;
	my $voltage = niDaq_getAnlgInputVoltage($Dev_ID, $channel_name, $MeasType);
	
	if ( ( $MeasType == 1 ) && exists $amplifier->{$amplifierName} ){
		return ( $voltage * $amplifier->{$amplifierName}{'volt_factor'} );
    }
    else{
    	return $voltage;
    }
}

sub nidaq_startAnalogInput{
	my ($dev_ID) = @_;

    my $status = niDaq_startAnalogInput($dev_ID);
	return $status;
}

sub nidaq_stopAnalogInput{
	my ($Dev_ID) = @_;
	my $status = niDaq_stopAnalogInput($Dev_ID);
	return $status;
}

sub nidaq_sendSwTrigger{
	my ($dev_ID) = @_;
	my $status = niDaq_sendSwTrigger($dev_ID);
	return $status;
}

sub nidaq_configureChannels{
	my ($dev_ID, $channels,$chnType, $trig_chn, $trig_volt_val, $slope) = @_;
	my $status = niDaq_configureChannels($dev_ID, $channels,$chnType, $trig_chn, $trig_volt_val, $slope);
	return $status;
}

1;

__END__

=head1 NAME

NIDAQ - Perl extension for NIDAQ DLL

=head1 SYNOPSIS

  use NIDAQ;

  $version = nidaq_getPMrevision();
  print "PM $version\n";

  $version = nidaq_getXSrevision();
  print "XS $version\n";

  $version = nidaq_getCWrevision();
  print "CW $version\n";

  $status = nidaq_start();
  print "perl: ($status)  NIDAQ Start";

  $status = nidaq_LogFile_Enable(0, $logFilePath);

  $status = nidaq_initHW(1,1,1);
  print "perl: ($status)  NIDAQ INIT Hardware";
  
  $hwInfos = nidaq_getHwInfos();
  print "perl: ($hwInfos)  Text of HW infos";

  $status = nidaq_setVoltage(1, 8.0, 1);
  print "perl: ($status)  NIDAQ Set Voltage";

  $status = nidaq_initArbitrary(1,10,1,-1);
  print "perl: ($status)  NIDAQ INIT Arbitary";

  ($status) = nidaq_programArbitrary(1,1,1,AO0,[10,10,10],1,1);
  print "perl: ($status)  NIDAQ Program Arbitrary";

  $status = nidaq_startArbitrary(1);
  print "perl: ($status)  NIDAQ Start Arbitary";

  $status = nidaq_stopArbitrary(1);
  print "perl: ($status)  NIDAQ Stop Arbitary";

  $status = nidaq_freeHW(1);
  print "perl: ($status)  NIDAQ Free Hardware";
  
  $status = nidaq_startAnalogInput(1);
  print "perl: ($status)  NIDAQ Start Analog Input";
  
  $status = nidaq_sendSwTrigger(1);
  print "perl: ($status)  NIDAQ send software trigger";
  
  $status = nidaq_stopAnalogInput(1);
  print "perl: ($status)  NIDAQ Stop Analog Input";
  
  $status = nidaq_configureChannels(1,[1,1],[0,1],"apfi0",5,"positive");
  print "perl: ($status)  NIDAQ Configure channels";

  $status = nidaq_end();
  print "perl: ($status)  NIDAQ End";

  $error_text = nidaq_getErrorString($status);
  print "perl: ($error_text)  Error text of read status";

  $voltage = nidaq_getAnalogInputVoltage(1,1,0);
  print "perl: ($voltage)  NIDAQ Get Analog Input Voltage";

=head1 DESCRIPTION

All functions are wrapper around NIDAQ DLL APIs

=head2 nidaq_start

    Initialize the nidaq wrapper DLL. This must be done before any other call of a function of the DLL.

=head2 nidaq_LogFile_Enable

    $status = nidaq_LogFile_Enable($enable, $logFilePath);

Set or Reset flag to enable (1) or disable (0) the log file (path without terminating backslash)

=head2 nidaq_initHW

    Initialize the nidaq Hardware.

=head2 nidaq_getHwInfos

    Gets the HW infos text response from nidaq dll.

=head2 nidaq_setVoltage

    Sets required voltage to the corresponding channel.

=head2 nidaq_readVoltage

    Read voltage from the required channel of device.

=head2 nidaq_initArbitrary

    Initializes variables for arbitrary waveform generation.

=head2 nidaq_programArbitrary

    Program the arbitrary waveform to the device.

=head2 nidaq_startArbitrary

    Sends command to the power supply to run arbitrary.

=head2 nidaq_stopArbitrary

    Stops the inactive arbitrary functional sequence.

=head2 nidaq_startAnalogInput

    Configures for the continuous data measurement.

=head2 nidaq_sendSwTrigger

    Sends the trigger and starts measuring.
	
=head2 nidaq_getValues

    Gets the time and voltage data read during Continous Data Acquisition.
	
=head2 niDaqGetNumSamples

    Gets the number of samples of time and voltage data read during Continous Data Acquisition.
	
=head2 nidaq_stopAnalogInput

    Stops  the continuous data measurement.

=head2 nidaq_freeHW

    Release resouces used by the Hardware.

=head2 nidaq_end

    Uninitialize the nidaq wrapper dll.

=head2 nidaq_getErrorString

    Gets the error text response from nidaq dll.

=head2 nidaq_getAnalogInputVoltage

    Gets the single sample Analog Input Voltage from the NIDAQ Input or output channel through nidaq dll.	
    
=head2 nidaq_configureChannels

    validates & configures all channels mentioned in the ProjectConst. Configures the Trigger based on the mentioned configuration.	

=head1 SEE ALSO

Perl documentation

=head1 AUTHOR

Puneeth BA, E<lt> PuneethB.Amarnath@in.bosch.com E<gt>
Gayathri Harikrishna, E<lt> Gayathri.Harikrishna@in.bosch.com E<gt>
=head1 COPYRIGHT AND LICENSE

Copyright (c) 2014  Robert Bosch GmBH

=cut



