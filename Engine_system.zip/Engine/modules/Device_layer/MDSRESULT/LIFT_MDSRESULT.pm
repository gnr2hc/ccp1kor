# *****************************************************************************************************
#
#  Copyright (c) 2013  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_MDSRESULT;

use strict;
use warnings;
use File::Basename;
use Math::Interpolate qw(linear_interpolate);
use Win32::Filenames qw(validate sanitize);
use HTML::Table;
use Readonly;

BEGIN {
    use LIFT_general;
    S_add_paths2INC( ['./Win32'], ['./Win32'] );
}

use LIFT_general;
use MDSResult;

use constant NO_FILTERING     => 0x0001;
use constant NO_ROTATION      => 0x0002;
use constant NO_AMPLIFICATION => 0x0004;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_MDSRESULT ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [qw( )] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  MDSRESULT_Exit
  MDSRESULT_GetAllRawSignals
  MDSRESULT_GetAlgoIDs
  MDSRESULT_GetAllUsedDeviceNames
  MDSRESULT_GetCrashDetails
  MDSRESULT_GetDeploymentForSimDevice
  MDSRESULT_GetSignalsForSensor
  MDSRESULT_GetStateOfEnvVariable
  MDSRESULT_Init
  MDSRESULT_PlotSensorSignals

  NO_FILTERING
  NO_ROTATION
  NO_AMPLIFICATION

  $OVERLOAD_CH_NAME_PREFIX
  $NOFIRE_SIMDEVICE
  $FIRE_SIMDEVICE
  $CANFIRE_SIMDEVICE
);

our ( $VERSION, $HEADER );

my %ResultDBCrashes = ();    #Internal hash, holds the crash names and ids

my $isMDSInitialized    = 0; #Init flag
my $IsMDSDLLInitialized = 0; # to indicate whether the MDS DLL is initialized & configured based on MDS type used

use constant DEFAULT => 'DEFAULT';

# Returns these dummy values when error is generated
my $FAILED = '-1';

my $CurrentUsedMDS = MDS;    # constant taken from low level module MDSResult.pm

Readonly our $OVERLOAD_CH_NAME_PREFIX => "ECU: Valid";
Readonly our $NOFIRE_SIMDEVICE        => 0;
Readonly our $FIRE_SIMDEVICE          => 1;
Readonly our $CANFIRE_SIMDEVICE       => 2;

=head1 NAME

LIFT_MDSRESULT 

Perl extension for parsing MDSResult DB and retrieve information from the MDS result DB.

See also:

https://inside-docupedia.bosch.com/confluence/display/aeos/MDS+Interface

https://connect.bosch.com/wikis/home?lang=de-de#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/LIFT_MDSRESULT

=head1 SYNOPSIS

    use LIFT_MDSRESULT;

    MDSRESULT_Init();

    my $CrashSettingsHash =  MDSRESULT_GetCrashDetails( { "RESULTDB" => 'D:\Projects\MDSResult\Y352-default.mdb',
                                                       "MDSTYPE"    => "MDS",
                                                       'CRASHNAME' => 'FrontCrash',
                                                       'STATEVARIATION' => 1, } );  # from result database 'D:\Projects\MDSResult\Y352-default.mdb'

    my ($SensorName_aref, $SimDevices_aref, $EnvNameConst_aref, $EnvNameDynamic_aref) = MDSRESULT_GetAllUsedDeviceNames();   # MDSRESULT_GetCrashDetails() to be called before calling this API

    my $sensorsignals_href = MDSRESULT_GetSignalsForSensor($CrashSettingsHash, 'PASFL:Acc:-Y:UFS3R');

    my ($minTime_ms, $maxTime_ms, $isDeployed) = MDSRESULT_GetDeploymentForSimDevice($CrashSettingsHash, 'SA1FL');

    my $envState = MDSRESULT_GetStateOfEnvVariable($CrashSettingsHash, 'BT1FP_SquibResistance');

    my $AllRawSignal_href = MDSRESULT_GetAllRawSignals('Y352_LMHS_90K_15KG_RHS');

    MDSRESULT_Exit();

=head1 DESCRIPTION

Infomation accessible with the module includes,

   1. All crashes present in the result DB

   2. The deployment times, Environment settings, Velocity, Sensor signals for a particular crash

   3. Raw signals from Local DB with a parcular Crash name

=head2 Prerequisites

Before using the APIs from this module, make sure that the below files are available.

=over 3

=item * a MDS result file (.mdb)

It is the Result Database (RSDB) file created using MDS, MDSNG or MDSNG64.

It will contain set of Single (or) Merged crashes simulated with No variation(SCI) / Multiple variations(DCI) of Environment states.

=item * MDS configuration file (Traditional MDS, MDSNG or MDSNG64)

.mds / .mdsng / .mdsng64 files

Make sure that MDS/MDSNG/MDSNG64) is installed in the Test system & given .mds/.mdsng/.mdsng64 configuration is opened atleast once to

synchronize the crashes, sensor related filters from Global MDS/MDSNG/MDSNG64 Database.

=item * Algo parameter file (.alg)

Algo relevant parameter files which shall be loaded into MDS/MDSNG/MDSNG64 project for simulating the crashes.

=back

=head2 ProjectConst configuration

    $Defaults->{'MDSRESULT'} = {
        "ENABLE_DEBUG_LOG_FILE"        => '0',       # OPTIONAL (default: 0): '0' for disable | '1' for enable
        "MAX_FILTER_SIGNAL_SLICE_SIZE" => "default", # OPTIONAL (default: 100000): "default" | number > 1000
        "RESULTS" => {
            "DEFAULT"     => { "PATH" => 'D:\Projects\MDSResult\Y352-default.mdb', "MDSTYPE" => "MDS" },
            "CrashType-A" => { "PATH" => 'D:\Projects\MDSResult\Y352-typeA.mdb',   "MDSTYPE" => "MDS" },
            "CrashType-B" => { "PATH" => 'D:\Projects\MDSResult\Y352-typeB.mdb',   "MDSTYPE" => "MDSNG" },
            "CrashType-C" => { "PATH" => 'D:\Projects\MDSResult\Y352-typeC.mdb',   "MDSTYPE" => "MDSNG64" },
        },
    };

=cut

=head1 Exported Subroutines

=head2 MDSRESULT_Exit

    MDSRESULT_Exit();

To end the MDSRESULT processing & unload the low level DLL

=cut

sub MDSRESULT_Exit {
    my $status;

    S_w2log( 4, "MDSRESULT_Exit : unloading the low level DLL and other resources \n" );

    # IF MDSResultProcess DLL & MDSResult is initialized
    # IF-NO-START
    # STEP Set Error
    unless ( $isMDSInitialized && $IsMDSDLLInitialized ) {
        S_set_error( "MDS is not intialized ", 120 );
        return $FAILED;
    }

    # IF-NO-END
    # IF-YES-START
    # STEP call the low level API to unload the loaded MDS Result DB
    $status = mdsresult_CloseResult();

    # STEP log the status of low level API to report
    _MDSRESULT_Check_status($status);
    S_w2log( 4, "Status of mdsresult_CloseResult : $status \n" );

    # STEP call the low level API to unload the MDSResultProcess DLL
    $status = mdsresult_End();
    _MDSRESULT_Check_status($status);
    S_w2log( 4, "Status of mdsresult_End : $status \n" );

    # STEP reset the flags to indicate that the module is deinitialized
    $isMDSInitialized    = 0;
    $IsMDSDLLInitialized = 0;
    %ResultDBCrashes     = ();

    # IF-YES-END

    # STEP return
    return;
}

=head2 MDSRESULT_GetAllRawSignals

    $AllRawSignal_href = MDSRESULT_GetAllRawSignals($crashName [, $strMDSType]);

    $crashname         -> Crash name for which setting to be retrieved

    $strMDSType        -> MDS Type (to determine the folder location), if not given, taken from $ProjectDefaults->{MDSRESULT}{RESULTS}{DEFAULT}{MDSTYPE}

    $AllRawSignal_href -> It is hash reference, contains the information of channel location, CHANNELDIRECTION, SIGNALS and SAMPLETIME_US of each sensor

Retrives all raw sensor details from the crash database. The hash contains the Sensor's channel location, direction, signals and sampling time

    $AllRawSignal_href = MDSRESULT_GetAllRawSignals('Y352_LMHS_90K_15KG_RHS');

    $AllRawSignal_href = MDSRESULT_GetAllRawSignals('Y352_LMHS_90K_15KG_RHS', MDSNG);

    $AllRawSignal_href = {
         'CHANNELS' => {
              'LH C-Pillar Crash sensor unit Acc Y' => {
                             'CHANNELDIRECTION' => 'Y',
                             'SAMPLETIME_US' => '62.5',
                             'SIGNALS' => [
                                    '1.09655531243671',
                                    '1.09655531243671',
                                    '1.09655531243671',
                              ],
              }
         },

         'CRASHNAME' => '103027'
    };

B<NOTE:> the Crash whose raw signal has to be retrieved must be resynchronized from MDS Global database to Local MDS Database prior to the usage of this API.

Either opening a MDS configuration (.mds, .mdsng, .mdsng64) which contains Particular crash (or) Crashbench tool will help in synchronizing the Crash.

=cut

sub MDSRESULT_GetAllRawSignals {
    my $crashName  = shift;
    my $strMDSType = shift;

    my $status;
    my ( $channelLocations, $channelDirections, $sensorSignals, $samplingTime_us );
    my %hAllRawSignal;
    my $dummy_href = {
        'CHANNELS' => {
            'Channel1' => {
                'CHANNELDIRECTION' => 'Y',
                'SAMPLETIME_US'    => '62.5',
                'SIGNALS'          => [ '1.09655', '1.09655', '1.09655', ],
            }
        }
    };

    unless ( defined $crashName ) {
        S_set_error( " ! too less parameters ! SYNTAX: MDSRESULT_GetAllRawSignals(crashname) ", 110 );
        return;
    }

    my $nMDSTypeNumber = 0;

    # if MDSType is not passed as parameter, then read the default MDS type from ProjectDefaults
    if ( !defined $strMDSType ) {
        ( $nMDSTypeNumber, $strMDSType ) = _MDSRESULT_ReadUsedMDSType(DEFAULT);
    }
    else {
        # if MDSType is given, validate the same
        $nMDSTypeNumber = _MDSRESULT_ValidateMDSType( $strMDSType, "parameter \$MDSType" );
    }

    # if the result MDSType validation/reading is not successful, return
    if ( ( $nMDSTypeNumber != MDS ) && ( $nMDSTypeNumber != MDSNG ) && ( $nMDSTypeNumber != MDSNG64 ) ) {
        S_set_error( "unable to execute: MDSRESULT_GetAllRawSignals($crashName). Reason: MDSType is unknown  ", 110 );
        return;
    }

    S_w2log( 4, "MDSRESULT_GetAllRawSignals (CRASH: $crashName, MDSType: $strMDSType) \n" );

    # check if the MDSResultProcess low level DLL is already initialized, if not, initialize it
    unless ($IsMDSDLLInitialized) {
        _MDSRESULT_InitMDSResultProcessDLL();
    }

    # configure the MDS type from where the raw Crash data has to be read
    $status = mdsresult_ConfigureUsedMDSType($nMDSTypeNumber);
    S_w2log( 5, "mdsresult_ConfigureUsedMDSType ( $strMDSType ($nMDSTypeNumber) ) : $status \n" );
    _MDSRESULT_Check_status($status);

    #Fetch raw Signals details for Crash from database
    ( $status, $channelLocations, $channelDirections, $sensorSignals, $samplingTime_us ) = mdsresult_GetAllRawSignalsForCrash($crashName);
    _MDSRESULT_Check_status($status);
    S_w2log( 4, "Status of mdsresult_GetAllRawSignalsForCrash : $status \n" );

    #creation of AllRawSignal hash
    $hAllRawSignal{'CRASHNAME'} = $crashName;
    for ( my $ndx = 0 ; $ndx < scalar(@$sensorSignals) ; $ndx++ ) {
        $hAllRawSignal{'CHANNELS'}{ $$channelLocations[$ndx] }{'SIGNALS'}          = $$sensorSignals[$ndx];
        $hAllRawSignal{'CHANNELS'}{ $$channelLocations[$ndx] }{'SAMPLETIME_US'}    = $$samplingTime_us[$ndx];
        $hAllRawSignal{'CHANNELS'}{ $$channelLocations[$ndx] }{'CHANNELDIRECTION'} = $$channelDirections[$ndx];
    }

    return ( \%hAllRawSignal );
}

=head2 MDSRESULT_GetAlgoIDs

    $algoIDs_href = MDSRESULT_GetAlgoIDs();

Returns all algo IDs as hash reference and writes them to log (level 3)

B<Return Value(s) :>

    $algoIDs_href = Reference to hash of key-value-pairs
                    keys are strings
                    values are integers (decimal)
                       If used for comparison with ECU IDs in a string context,
                       take care to bring both to same data format (hex preferred as in <MDS-Result>.mdb)

I<B<Examples :>>

    $algoIDs_href = MDSRESULT_GetAlgoIDs();

=cut

sub MDSRESULT_GetAlgoIDs {
    my $ids_href;
    $ids_href = mdsresult_GetAlgoIDs();

    S_w2log( 3, "MDSRESULT_GetAlgoIDs from MDS result DB\n" );
    my $count = 0;
    for my $algoID ( sort keys %{$ids_href} ) {
        $count++;
        my $logText = sprintf( "%02d: %25s: 0x%02X\n", $count, $algoID, $ids_href->{$algoID} );
        S_w2log( 3, "$logText" );
    }

    return $ids_href;
}

=head2 MDSRESULT_GetAllUsedDeviceNames

    ($SensorName_aref, $SimDevices_aref, $EnvNameConst_aref, $EnvNameDynamic_aref) = MDSRESULT_GetAllUsedDeviceNames();

     $SensorName_aref      = It is array reference, contains the names of all used sensors

     $SimDevices_aref      = It is array reference, contains the names of all used simdevices

     $EnvNameConst_aref   = It is array reference, contains the names of all constant environmental names

     $EnvNameDynamic_aref = It is array reference, contains the names of all dynamic environmental names

Retrives all used devices details from the crash database. Used devices are sensors names, sim device names, constant and dynamic environmental names

    ($SensorName_aref, $SimDevices_aref, $EnvNameConst_aref, $EnvNameDynamic_aref) = MDSRESULT_GetAllUsedDeviceNames();

B<NOTE:> The device names are retrieved from the MDS RESULTDB which is already loaded by using the API MDSRESULT_GetCrashDetails()

=cut

sub MDSRESULT_GetAllUsedDeviceNames {
    my ( $status, $moduleNames, $sensorNames, $sensorDirections, $sensorTypes );
    my ( $simDevices_aref,   @actualSensorNames );
    my ( $envNameConst_aref, $envVals );
    my ($envNameDynamic_aref);

    S_w2log( 4, "MDSRESULT_GetAllUsedDeviceNames(): fetching all device names from the given MDSResult database \n" );

    # check if MDSResultProcess DLL & MDSResult is initialized
    unless ( $isMDSInitialized && $IsMDSDLLInitialized ) {
        S_set_error( "MDS is not intialized. call MDSRESULT_Init() & MDSRESULT_GetCrashDetails() before calling this API. ", 120 );
        return ( undef, undef, undef, undef );
    }

    ( $status, $moduleNames, $sensorNames, $sensorDirections, $sensorTypes ) = mdsresult_GetSensorDetails();
    _MDSRESULT_Check_status($status);

    # form the sensor names
    for ( my $index = 0 ; $index < $status ; $index++ ) {

        # ATTENTION: Do not modify format, without modifying any potential extractors of this string, e.g. CREIS, EDR functions, and so on
        push( @actualSensorNames, qq/$$moduleNames[$index]: $$sensorNames[$index]: $$sensorDirections[$index]: $$sensorTypes[$index]/ );
    }

    S_w2log( 5, "Status of mdsresult_GetSensorDetails : $status \n" );

    ( $status, $simDevices_aref ) = mdsresult_GetSimDevices();
    _MDSRESULT_Check_status($status);
    S_w2log( 5, "Status of mdsresult_GetSimDevices : $status \n" );

    ( $status, $envNameConst_aref, $envVals ) = mdsresult_GetConstantEnvParams();
    _MDSRESULT_Check_status($status);
    S_w2log( 5, "Status of mdsresult_GetConstantEnvParams :: $status \n" );

    ( $status, $envNameDynamic_aref ) = mdsresult_GetDynamicEnvParams();
    _MDSRESULT_Check_status($status);
    S_w2log( 5, "Status of mdsresult_GetDynamicEnvParams :: $status \n" );

    return ( \@actualSensorNames, $simDevices_aref, $envNameConst_aref, $envNameDynamic_aref );
}

=head2 MDSRESULT_GetCrashDetails

I<B<Syntax : >>

    $CrashSettingsHash =  MDSRESULT_GetCrashDetails( $CrashIdentifyParams_href [, $Options, $sensorProperties_href, $sensorPropertyKeys_aref]);

I<B<Arguments    : >>

 $CrashIdentifyParams_href  =   It is Hash reference containing specific Keys (of any of the below combinations (see examples below).

 $Options                   =   (optional) to influence the data process done to Sensor signals (NO_ROTATION | NO_FILTERING | NO_AMPLIFICATION)

    { 'CRASHNAME' => 'FrontCrash' }      # from 'DEFAULT' result database. by default, STATEVARIATION = 1

    { 'CRASHNAME' => 'FrontCrash', 'STATEVARIATION' => 1, }   # from 'DEFAULT' result database

    { "RESULTDB" => 'CrashType-A', 'CRASHNAME' => 'FrontCrash', 'STATEVARIATION' => 1, } );  # from result database 'CrashType-A'

    { "RESULTDB" => 'D:\Projects\MDSResult\Y352-default.mdb',
        "MDSTYPE"    => "MDS",
        'CRASHNAME' => 'FrontCrash',
        'STATEVARIATION' => 1, }   # from result database 'D:\Projects\MDSResult\Y352-default.mdb'

    $Options                   =   (optional) to influence the data process done to Sensor signals (NO_ROTATION | NO_FILTERING | NO_AMPLIFICATION)

    $sensorProperties_href     =   (optional) to influence the VDA- and/or Classic(NULL)-Filter based on configured QuaTe-Device type (EDIF-Netlist- or PSI5DEVICE-Type) in MDSResult
 

    $sensorProperties_href = { "ECU: Acc_HG: M45: SMA660_sync_axay_96g_426Hz" => { AMPLITUDE        => 1.0,
                                                                                   CORRECTION_ANGLE => 0.0,
                                                                                   CRASH_DEVICE     => 1,
    	                                                                           DEV_TYPE_INTERN  => 0,
                                                                                   INPUT_BIT_WIDTH  => 12,
                                                                                   OFFSET           => 0.0,
                                                                                 },
                               "ECU: Acc_HG: P45: SMA660_sync_axay_96g_426Hz" => { AMPLITUDE        => 1.0,
                                                                                   CORRECTION_ANGLE => 0.0,
                                                                                   CRASH_DEVICE     => 1,
                               	                                                   DEV_TYPE_INTERN  => 0,
                                                                                   INPUT_BIT_WIDTH  => 12,
                                                                                   OFFSET           => 0.0,
                                                                                 },};

    $sensorPropertyKeys_aref = (optional) list of property names (only passed for convenience of easier usage of these keys, i.e. no need to know any sensor channel name as key in sensorProperties_href)

    $sensorPropertyKeys_aref = ["AMPLITUDE", "CORRECTION_ANGLE", "CRASH_DEVICE", "DEV_TYPE_INTERN", "INPUT_BIT_WIDTH", , "OFFSET"]

B<Crash Identification (Either one):>

    CRASHNAME      :  Crash code

    CRASHINDEX     :  Index of the crash from MDS Result Database (usually 1, 2, 3 ... )

B<Environment State variation specification (optional):>

    STATEVARIATION : the index of Environment state variation (decided by Algo Engineer)
                     ( usually 1, 2, 3 ... , default = 1 )

B<MDS Result Database Identification :>

    RESULTDB       : Either a configuration from $Defaults->{'MDSRESULT'}{"RESULTS"} Mapping (or) the file path of MDS result database,

                    If not given, takes the settings from

    MDSTYPE        : Only needed, if "RESULTDB" contains a file path

I<B<Description :>>

Retrieves Crash settings for a particular Crash and State Variation Number from Given/configured MDS result database.

I<B<Return values :>>

    $CrashSettingsHash  = Contains crash setting information such as Crash name, description, Sensor details, SimDevices details and Enviromental setting details

        $CrashSettingsHash =  MDSRESULT_GetCrashDetails('1', '1');

    $CrashSettingsHash => {

        'CRASH_PARA_VALID' => 0|1,

        'CRASHNAME' => 'Y352_LMHS_90K_15KG_RHS',

        'STATEVARIATION' => 1,

        'DESCRIPTION' => 'description if any, for reporting',

        'VELOCITY'  => [40,],

        'VELOCITY_X_kmh'  => [40,],

        'VELOCITY_CLOSING_kmh'  => [40,],

        'TEMPERATURE_degCelsius'  => [22.6,],

        'TIMESHIFT' => 0,

        'ISMERGECRASH' => 0,

        'SENSORS' => {
            'ECU:Acc_HG:X:SMB460' =>{
                'SAMPLETIME_US' => 24000,
                'SIGNALS' => [0, -0.125, 0.324, ...],
            },
            'ECU:Acc_HG:Y:SMB460' =>{
                'SAMPLETIME_US' => 12000,
                'SIGNALS' => [ ...],
            },
            .
                .
        },

        'SIMDEVICES' => {
                    'AB1FD' =>{
                        'MINT' =>  28.8118,
                        'MAXT' => 30.5953,
                        'ISDEPLOYED' =>  1,
                    },
                    .
                    .
                    .
        },

        'ENVIRONMENT' => {
            'state_Pes3Config' => '1',
             'state_Pes1ErrorStart' => '0',
             'BBRC_Valid' => '1',
             'state_Pes8ErrorBehaviour' => '1',
             'state_Pes7ErrorStart' => '0',
             'state_EcuYrdConfigured' => '0',
             .
             .
             .
             .

        },
    };

I<B<Examples :>>

=over 3

=item * Combination 1

    $CrashSettingsHash =  MDSRESULT_GetCrashDetails( { 'CRASHNAME' => 'FrontCrash'} );      # from 'DEFAULT' result file

The "DEFAULT" MDS result database path & used MDS type will be taken from ProjectDefaults, STATEVARIATION will be taken as 1.

    $Defaults->{'MDSRESULT'} = {
        "RESULTS" => {
            "DEFAULT"     => { "PATH" => 'D:\Projects\MDSResult\Y352-default.mdb', "MDSTYPE" => "MDS" },

=item * Combination 2

    $CrashSettingsHash =  MDSRESULT_GetCrashDetails( { 'CRASHNAME' => 'FrontCrash',
                                                       'STATEVARIATION' => 1, } );   # from 'DEFAULT' result file

The "DEFAULT" MDS result database path & used MDS type will be taken from ProjectDefaults.

    $Defaults->{'MDSRESULT'} = {
        "RESULTS" => {
            "DEFAULT"     => { "PATH" => 'D:\Projects\MDSResult\Y352-default.mdb', "MDSTYPE" => "MDS" },

=item * Combination 3

    $CrashSettingsHash =  MDSRESULT_GetCrashDetails( { "RESULTDB" => 'CrashType-A',
                                                       'CRASHNAME' => 'FrontCrash',
                                                       'STATEVARIATION' => 1, } );  # from result file 'CrashType-A'

The configured 'CrashType-A' MDS result database path & used MDS type will be taken from ProjectDefaults.

    $Defaults->{'MDSRESULT'} = {
        "RESULTS" => {
            "CrashType-A" => { "PATH" => 'D:\Projects\MDSResult\Y352-typeA.mdb',   "MDSTYPE" => "MDS" },

=item * Combination 4

    $CrashSettingsHash =  MDSRESULT_GetCrashDetails( { "RESULTDB" => 'D:\Projects\MDSResult\Y352-default.mdb',
                                                       "MDSTYPE"    => "MDS",
                                                       'CRASHNAME' => 'FrontCrash',
                                                       'STATEVARIATION' => 1, } );  # from result database 'D:\Projects\MDSResult\Y352-default.mdb'

Used to directly specify the MDS result database path & retrieve the crash signals.

=back

=cut

sub MDSRESULT_GetCrashDetails {
    my $crashIdentifyParams_href = shift;    # A hash passed to the API to identify the particular crash
    my $options                  = shift;    # optional
    my $sensorProperties_href    = shift;    # required, if NO_FILTERING = 0, otherwise optional
    my $sensorPropertyKeys_aref  = shift;    # required, if NO_FILTERING = 0, otherwise optional (only passed for convenience of easier usage of these keys, i.e. no need to know any sensor channel name as key in sensorProperties_href)

    my $status;

    # STEP validate if all the required parameters are received correctly
    unless ( S_checkFunctionArguments( 'MDSRESULT_GetCrashDetails( $CrashIdentifyParams_href [, $Options, $sensorProperties_href, $sensorPropertyKeys_aref])', $crashIdentifyParams_href, $options, $sensorProperties_href, $sensorPropertyKeys_aref ) ) {
        return;
    }

    my $availableStateVariations = 0;
    my $crashDetailsHash;
    $crashDetailsHash->{'CRASH_PARA_VALID'} = 1;    # assume valid

    # STEP validate the parameters provided
    # - either CRASHNAME or CRASHINDEX has to be present, if both are present, it is an error
    my $crashName  = $crashIdentifyParams_href->{'CRASHNAME'};
    my $crashIndex = $crashIdentifyParams_href->{'CRASHINDEX'};

    # STEP determine State variation number, if not given. default $stateVariationIndex=1
    my $stateVariationIndex = $crashIdentifyParams_href->{'STATEVARIATION'};
    $stateVariationIndex = 1 unless ( defined $stateVariationIndex );

    # IF Is both CRASHNAME & CRASHINDEX are present?
    if ( defined $crashName && defined $crashIndex ) {

        # IF-YES-START
        # STEP both CRASHNAME & CRASHINDEX should not be present. throw error
        S_set_error( "! redundant params provided (CRASHNAME & CRASHINDEX) ! either crashIdentifyParams_href->{'CRASHNAME'} or  crashIdentifyParams_href->{'CRASHINDEX'} can be present, but not both", 109 );
        return;

        # IF-YES-END
    }

    # IF-NO-START
    # IF Is both CRASHNAME & CRASHINDEX are not present?
    if ( !defined $crashName && !defined $crashIndex ) {

        # IF-YES-START
        # STEP throw error, since we need either CRASHNAME or CRASHINDEX
        S_set_error( "! Crash identification param (CRASHNAME & CRASHINDEX) not present ! either crashIdentifyParams_href->{'CRASHNAME'} or  crashIdentifyParams_href->{'CRASHINDEX'} should be present", 109 );
        return;

        # IF-YES-END

    }

    # IF-NO-START
    # STEP now we have either CRASHINDEX or CRASHNAME
    # STEP return dummy reference, if MDSDLL is not initialized yet
    unless ($IsMDSDLLInitialized) {
        S_set_error( "MDS is not intialized ", 120 );
        return;
    }

    # STEP log the parameters into test report
    S_w2log( 4, "MDSRESULT_GetCrashDetails (CRASHNAME => " . ( defined($crashName) ? $crashName : "NA" ) . ", CRASHINDEX => " . ( defined($crashIndex) ? $crashIndex : "NA" ) . ", STATEVARIATION => " . ($stateVariationIndex) . ")\n" );

    # STEP try to load the given MDS Result Database
    $status = _MDSRESULT_LoadMDSResultDatabase( $crashIdentifyParams_href->{'RESULTDB'}, $crashIdentifyParams_href->{'MDSTYPE'} );
    if ( $status == $FAILED ) { return; }

    # STEP when MDSResult DB is successfully loaded, proceed to extract information
    # IF Is CRASHNAME given as parameter?
    if ( defined $crashName ) {

        # IF-YES-START
        # STEP find the appropriate CrashIndex (_MDSRESULT_GetCrashIndexFromCrashName)
        ( $crashIndex, $availableStateVariations ) = _MDSRESULT_GetCrashIndexFromCrashName($crashName);

        # IF-YES-END
    }
    else {
        # IF-NO-START
        # STEP find the appropriate CrashName (_MDSRESULT_GetCrashNameFromCrashIndex)
        ( $crashName, $availableStateVariations ) = _MDSRESULT_GetCrashNameFromCrashIndex($crashIndex);

        # IF-NO-END
    }

    # STEP if determining $crashName, or $crashIndex is failed, return
    if ( $crashName eq "$FAILED" || $crashIndex == $FAILED ) {
        return;
    }

    # STEP if there is no options for signal processing specified, then by default all the process will be performed
    $options = 0 unless ( defined($options) );

    # if the OPTIONS is non-zero, then it has to be the combination of NO_ROTATION, NO_FILTERING, NO_AMPLIFICATION
    # if it is neither, then there is an error
    if ( $options != 0 && ( $options & ~( NO_ROTATION | NO_FILTERING | NO_AMPLIFICATION ) ) != 0 ) {
        S_set_error( "given \$options ($options) is invalid. it shall be combination of NO_ROTATION, NO_FILTERING, NO_AMPLIFICATION", 109 );
        return;
    }

    # STEP if requested state variation index is greater than total number of statevariations available, throw error
    if ( $stateVariationIndex > $availableStateVariations ) {
        S_set_error( "State variation index ($stateVariationIndex) passed to function is greater than number of StateVariations available ($availableStateVariations) for crash $crashName, Maximum number of State variations is $availableStateVariations", 109 );
        return;
    }

    #Create the output $CrashSettingsHash
    $crashDetailsHash->{'CRASHNAME'}      = $crashName;
    $crashDetailsHash->{'CRASHINDEX'}     = $crashIndex;
    $crashDetailsHash->{'STATEVARIATION'} = $stateVariationIndex;

    # Option: Pass sensor properties to MDSRESULT.dll (in index order of dll)
    if ($sensorProperties_href) {

        # Transform name based hash $sensorProperties_href to index based properties for %sensorProperties4MDSRESULT
        my ( $sensorName_dll_aref, $simDevices_aref, $envName_Const_aref, $envName_Dynamic_aref ) = MDSRESULT_GetAllUsedDeviceNames();
        my @propertyValuesByIdx;
        my %propertyNames;
        my $sensIdx = 0;
        foreach my $sensorName_dll (@$sensorName_dll_aref) {
            if ( exists $sensorProperties_href->{$sensorName_dll} || $sensorName_dll =~ $OVERLOAD_CH_NAME_PREFIX ) {
                if ( $sensorName_dll =~ $OVERLOAD_CH_NAME_PREFIX ) {
                    if ( !$sensorPropertyKeys_aref ) {
                        S_set_error( "Array of sensorPropertyKeys is undefined, reqired for '$OVERLOAD_CH_NAME_PREFIX'", 109 );
                        return;
                    }

                    # Fill $OVERLOAD_CH_NAME_PREFIX sensorName with dummy entries, in order to keep the index order for DLL without gap
                    foreach my $property ( sort @$sensorPropertyKeys_aref ) {
                        if ( $property =~ /amplitude/i ) {
                            $sensorProperties_href->{$sensorName_dll}{$property} = 1.0;    # any 'amplitude' property set to 1.0 (= no impact)
                        }

                        else {
                            $sensorProperties_href->{$sensorName_dll}{$property} = 0.0;    # includes any 'offset' property set to 0.0 (= no impact)
                        }
                    }
                }
                my $propIdx = 0;
                foreach my $property ( sort keys %{ $sensorProperties_href->{$sensorName_dll} } ) {
                    $propertyNames{$property} = 1;
                    my $value = $sensorProperties_href->{$sensorName_dll}{$property};
                    $propertyValuesByIdx[$propIdx][$sensIdx] = $value;
                    $propIdx++;
                }
            }
            else {
                S_set_error( "MDSResult sensor name '$sensorName_dll' does not exist in sensorPorperties-Hash", 109 );
                return;
            }
            $sensIdx++;
        }

        my %sensorProperties4MDSRESULT;
        my $propIdx = 0;
        foreach my $property ( sort keys %propertyNames ) {
            $sensorProperties4MDSRESULT{$property} = $propertyValuesByIdx[$propIdx];
            $propIdx++;
        }
        $status = _MDSRESULT_ApplySensorProperties( \%sensorProperties4MDSRESULT );
        if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    }

    # If sensor properties are omitted and flag NO_FILTERING is NOT set
    elsif ( !( $options & NO_FILTERING ) ) {
        S_set_error( "If sensor filtering is enabled (= default for CREIS), the function argument 'sensorProperties_href' has to be valid (Crashname = $crashIdentifyParams_href->{'CRASHNAME'} in $crashIdentifyParams_href->{'RESULTDB'})", 109 );
    }

    # STEP Fetch all Sensor Details from database
    my ( $moduleName, $sensorName, $sensorDirection, $sensorType );
    ( $status, $moduleName, $sensorName, $sensorDirection, $sensorType ) = mdsresult_GetSensorDetails();
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "Status of mdsresult_GetSensorDetails : $status \n" );

    # STEP Fetch all SIMDevice Details from database
    my $simDevices;
    ( $status, $simDevices ) = mdsresult_GetSimDevices();
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "Status of mdsresult_GetSimDevices : $status \n" );

    # STEP Fetch Constant EnvParams from database
    my ( $envnamesConst, $envVals );
    ( $status, $envnamesConst, $envVals ) = mdsresult_GetConstantEnvParams();
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "Status of mdsresult_GetConstantEnvParams : $status \n" );

    # STEP fill the constant Environment states into 'EnvSettings' key
    for ( my $ndx = 0 ; $ndx < $status ; $ndx++ ) {
        $crashDetailsHash->{'ENVIRONMENT'}{ $$envnamesConst[$ndx] } = $$envVals[$ndx];
    }

    # STEP Fetch Dynamic EnvParams from database
    my $envnamesDynamic;
    ( $status, $envnamesDynamic ) = mdsresult_GetDynamicEnvParams();
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "Status of mdsresult_GetDynamicEnvParams : $status \n" );

    # STEP Get SimDevice result for a particular Crash from database
    my ( $simDevNames, $mintMs, $maxtMs, $isDeployed );
    ( $status, $simDevNames, $mintMs, $maxtMs, $isDeployed ) = mdsresult_GetSimDevResultsForCrash( $crashIndex, $stateVariationIndex );
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 1, "Status of mdsresult_GetSimDevResultsForCrash : $status \n" );

    # STEP fill the simdevice results into 'SimDevices' key
    for ( my $index = 0 ; $index < $status ; $index++ ) {
        $crashDetailsHash->{'SIMDEVICES'}{ $$simDevNames[$index] }{'MINT'}       = $$mintMs[$index];
        $crashDetailsHash->{'SIMDEVICES'}{ $$simDevNames[$index] }{'MAXT'}       = $$maxtMs[$index];
        $crashDetailsHash->{'SIMDEVICES'}{ $$simDevNames[$index] }{'ISDEPLOYED'} = $$isDeployed[$index];
    }

    # STEP Get the Environment Settings for a particular Crash from database
    my ( $moduleNames, $envNames, $envValues );
    ( $status, $moduleNames, $envNames, $envValues ) = mdsresult_GetEnvironmentSettingsForCrash( $crashIndex, $stateVariationIndex );
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "Status of mdsresult_GetEnvironmentSettingsForCrash : $status \n" );

    # STEP fill the Dynamic Environment states into 'EnvSettings' key
    for ( my $ndx = 0 ; $ndx < $status ; $ndx++ ) {
        $crashDetailsHash->{'ENVIRONMENT'}{ $$envNames[$ndx] } = $$envValues[$ndx];
    }

    # STEP Fetch Sensor Signals for Crash from database
    my ( $sensorSignals, $sampleTime_us );
    ( $status, $sensorSignals, $sampleTime_us ) = mdsresult_GetSensorSignalsForCrash( $crashIndex, $stateVariationIndex, $options );
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "Status of mdsresult_GetSensorSignalsForCrash : $status \n" );

    # STEP fill the sensor signals into 'Sensors' key
    for ( my $ndx = 0 ; $ndx < $status ; $ndx++ ) {

        # the name is encoded into specific format (colon seperated)
        # this is the name used to identify the sensors in ProjectDefauts->{CREIS}{INPUT} mapping
        # ATTENTION: Do not modify format, without modifying any potential extractors of this string, e.g. CREIS, EDR functions, and so on
        my $sensorDetails = qq/$$moduleName[$ndx]: $$sensorName[$ndx]: $$sensorDirection[$ndx]: $$sensorType[$ndx]/;

        # truncate sampletime to 3 digits
        $$sampleTime_us[$ndx] = sprintf( "%.03f", $$sampleTime_us[$ndx] );
        $crashDetailsHash->{'SENSORS'}{$sensorDetails}{'SAMPLETIME_US'} = $$sampleTime_us[$ndx];
        $crashDetailsHash->{'SENSORS'}{$sensorDetails}{'SIGNALS'}       = $$sensorSignals[$ndx];
    }

    # STEP get the velocity related info from MDS, and put them into structure
    my ( $velocity_kmh, $timeshift_ms );
    ( $status, $velocity_kmh, $timeshift_ms ) = mdsresult_GetCrashVelocity_kmh( $crashIndex, $stateVariationIndex );
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "mdsresult_GetCrashVelocity_kmh (status= $status): velocity_kmh: @$velocity_kmh, timeshift: $timeshift_ms \n" );

    $crashDetailsHash->{'VELOCITY_kmh'} = $velocity_kmh;
    $crashDetailsHash->{'TIMESHIFT_ms'} = $timeshift_ms;

    # STEP get the speed(s) in X direction of crash(es), and put them into structure
    my $velocity_X_kmh_aref;
    ( $status, $velocity_X_kmh_aref ) = mdsresult_GetCrashVelocity_X_kmh($crashIndex);
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "mdsresult_GetCrashVelocity_X_kmh (status= $status): velocity_X_kmh: @$velocity_X_kmh_aref \n" );

    $crashDetailsHash->{'VELOCITY_X_kmh'} = $velocity_X_kmh_aref;

    # STEP get the closing speed(s) of crash(es), and put them into structure
    my $velocity_closing_kmh_aref;
    ( $status, $velocity_closing_kmh_aref ) = mdsresult_GetCrashVelocity_Closing_kmh($crashIndex);
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "mdsresult_GetCrashVelocity_Closing_kmh (status= $status): velocity_closing_kmh: @$velocity_closing_kmh_aref \n" );

    $crashDetailsHash->{'VELOCITY_CLOSING_kmh'} = $velocity_closing_kmh_aref;

    # STEP get the temperature(s) of crash(es), and put them into structure
    my $temperature_degCelsius_aref;
    ( $status, $temperature_degCelsius_aref ) = mdsresult_GetCrashTemperature_degCelsius($crashIndex);
    _MDSRESULT_Check_status($status);
    if ( $status < 0 ) { $crashDetailsHash->{'CRASH_PARA_VALID'} = 0; }
    S_w2log( 4, "mdsresult_GetCrashTemperature_degCelsius (status= $status): temperature_degCelsius: @$temperature_degCelsius_aref \n" );

    $crashDetailsHash->{'TEMPERATURE_degCelsius'} = $temperature_degCelsius_aref;

    # STEP get the CrashAssingmentComment(s) of crash(es), and put them into structure
    my $crashAssignmentComment_aref;
    ( $status, $crashAssignmentComment_aref ) = mdsresult_GetCrashAssignmentComment($crashIndex);
    _MDSRESULT_Check_status($status);
    if ( $status > 0 ) {
        $crashDetailsHash->{'CRASH_ASSIGNMENT_COMMENT'} = $crashAssignmentComment_aref;
        my $i = 0;
        foreach my $count ( 0 .. $status - 1 ) {
            S_w2log( 4, "mdsresult_GetCrashAssignmentComment (status= $status): CrashAssignmentComment[$count]: @$crashAssignmentComment_aref[$i] \n" );
            $i++;
        }
    }
    else {
        $crashDetailsHash->{'CRASH_PARA_VALID'}         = 0;
        $crashDetailsHash->{'CRASH_ASSIGNMENT_COMMENT'} = "invalid";
    }

    # STEP set the merge crash status according to the return value from low level DLL
    if ( $status == 1 ) {

        # single crash
        $crashDetailsHash->{'ISMERGECRASH'} = 0;
    }
    elsif ( $status == 2 ) {

        # merge crash
        $crashDetailsHash->{'ISMERGECRASH'} = 1;
    }

    # If description is available in database below code is considered, way of accessing may change
    #TODO: crash description to be retrieved from MDS DB (changes in low level DLL)
    #    unless ( defined($CrashDescription) ) {
    #        $CrashDetailsHash->{'Description'} = "Description is not given regarding this Crash";
    #    }

    # STEP finally, return the create hash to the user
    return ($crashDetailsHash);

    # IF-NO-END
    # IF-NO-END

    #STEP End of API
}

=head2 MDSRESULT_PlotSensorSignals

    MDSRESULT_PlotSensorSignals($crashdetails_href [, $htmlFileName]);

Plots all the sensor signals into individual images per sensor & collects them into a HTML file with the given HTML name

The images & HTML file will be created under current test run's report folder ($main::REPORT_PATH).

    $crashdetails_href = It is hash reference, contains the crash info such as Sensor details, SimDevices details and Enviromental setting details

                        $crashdetails_href is the return value got from MDSRESULT_GetCrashDetails()

    $htmlFileName      = name of the HTML file in which all the sensor signals have to be plotted

                       if not given, the HTML file name is considered as "CRASHNAME + S_get_date_extension().html"

B<Return Value(s) :>

    1 = success

    0 = failure

I<B<Examples :>>

    MDSRESULT_PlotSensorSignals($crashdetails_href);

    MDSRESULT_PlotSensorSignals($crashdetails_href, "SideCrash.html");

B<CAUTION!>

This API is still experimental. This needs LIFT_general version 2.87.2.1 which is using ZedGraph for S_create_graph() rather than GD::Graph to overcome out-of-memory exception

also \TurboLIFT\System\Engine\modules\DLLs\ZedGraphLib folder needs to be synchronized.

!! USE WITH CARE !!

=cut

sub MDSRESULT_PlotSensorSignals {
    my $crashDetails_href = shift;
    my $htmlFileName      = shift;

    # STEP validate if parameters are received correctly
    unless ( S_checkFunctionArguments( 'MDSRESULT_PlotSensorSignals($crashdetails_href [, $htmlFileName])', $crashDetails_href, $htmlFileName ) ) {
        return 0;
    }

    # STEP print the API name to report
    S_w2log( 5, "MDSRESULT_PlotSensorSignals($htmlFileName) -> start collecting the sensor names and data to plot \n" );

    return 1 if ($main::offline);

    my $table1 = new HTML::Table(
        -align   => 'center',
        -rules   => 'rows',
        -border  => 0,
        -width   => '50%',
        -spacing => 0,
        -padding => 0,
        -style   => 'color: blue',
    );

    # STEP determine the ideal maximum sampling time in us
    my $maxSamplingTime_us = 0;
    my $maxEndTime_us      = 0;

    my @allSensors = sort keys( %{ $crashDetails_href->{'SENSORS'} } );

    # go-through all the sensors, and find out the maximum sampling time
    # Here we assume that if we take maximum sampling time, we will not get out of memory runtime exception
    # but in practical, the maximum sampling time can also be a very small value, which could lead to out of memory exception (no such crash found so far in testing)
    for ( my $index = 0 ; $index < scalar(@allSensors) ; $index++ ) {
        my $sensorname = $allSensors[$index];

        # get the details (sampling time, signal array) for particular sensor
        my $sensorsignals_href = MDSRESULT_GetSignalsForSensor( $crashDetails_href, $sensorname );

        my $currentSampleTime_us = $sensorsignals_href->{'SAMPLETIME_US'};
        my $currentSignalsCount  = scalar( @{ $sensorsignals_href->{'SIGNALS'} } );

        # note down the Max End time for resampling the other lower sample timed signals until max end time
        my $endTime_us = $currentSignalsCount * $currentSampleTime_us;
        $maxEndTime_us = $endTime_us if ( $maxEndTime_us < $endTime_us );

        # note down the Max sampling time for resampling the other lower sample timed signals to max sampling time(to reduce chance of out of memory runtime exception)
        $maxSamplingTime_us = $currentSampleTime_us if ( $index == 0 );
        $maxSamplingTime_us = $currentSampleTime_us if ( $maxSamplingTime_us <= $currentSampleTime_us );
    }

    # prepare the sensor signals hash to be plotted
    # STEP for each sensor, interpolate the data for the determined sampling time & fill the hash
    my $dumpPicture_href = {};
    my @timeArray        = ();

    my $tempTime_us = 0.00;

    # prepare the time array by considering the maximum sampling time
    # this time array will be used later (below) to interpolate the sensor signals
    while ( $tempTime_us < $maxEndTime_us ) {
        push( @timeArray, $tempTime_us );
        $tempTime_us = $tempTime_us + $maxSamplingTime_us;
    }

    my $length = scalar(@timeArray);

    # for each sensor, interpolate the signals based on determined time array
    for ( my $index = 0 ; $index < scalar(@allSensors) ; $index++ ) {
        my $sensorname = $allSensors[$index];

        undef $dumpPicture_href;
        $dumpPicture_href->{'time'} = \@timeArray;
        my $currentTime_us = 0.00;
        my $sensorsignals_href = MDSRESULT_GetSignalsForSensor( $crashDetails_href, $sensorname );

        my $currentSampleTime_us = $sensorsignals_href->{'SAMPLETIME_US'};
        my $numsignals           = scalar( @{ $sensorsignals_href->{'SIGNALS'} } );

        # for zero emulated signal skip the picture to avoid divide by zero exception
        next if ( $numsignals <= 0 );

        # assume that the first signal starts at time 0
        #prepare the sensor time array based on actual sampling of this particular sensor, so that we can pass this to "linear_interpolate" API
        my @sensorTimeArray = ( 0 .. ( scalar( @{ $sensorsignals_href->{'SIGNALS'} } ) - 1 ) );

        # create exact time array from sampling time in us
        foreach my $temp (@sensorTimeArray) { $temp = $temp * $currentSampleTime_us; }

        my $unspacedsensorname = $sensorname;
        $unspacedsensorname =~ s/\s*//gi;

        # for each time (created based on max sampling time of all sensors)
        foreach my $time_us (@timeArray) {
            my ( $linear_y, $linear_dy ) = linear_interpolate( $time_us, \@sensorTimeArray, $sensorsignals_href->{'SIGNALS'} );
            push( @{ $dumpPicture_href->{$unspacedsensorname} }, $linear_y );
        }

        # sanitize the sensor name to eliminate unwanted characters, to be able to create a file with that name
        $unspacedsensorname = sanitize( $unspacedsensorname . "_" . S_get_date_extension(), "_" );
        my $filepath = $main::REPORT_PATH . '\\' . "$unspacedsensorname.png";
        S_create_graph( $dumpPicture_href, $filepath );
        S_w2log( 5, "plotted  -> $filepath \n" );
        $table1->addRow( ("<img src='$unspacedsensorname.png'></img>") );
    }

    # get the crash name to print into HTML file
    my $crashName = $crashDetails_href->{"CRASHNAME"};

    # remove the given extension and append ".html"
    $htmlFileName =~ s/(\.[^\.]*)/\.html/i if ( defined($htmlFileName) );

    # prepare HTML file name from crash name, if no file name is given in parameter
    $htmlFileName = sanitize( $crashName . "_" . S_get_date_extension() . ".html", "_" ) unless ( defined($htmlFileName) );
    my $htmlfile = $main::REPORT_PATH . '\\' . $htmlFileName;

    # open the HTML file and print the HTML table contents
    if ( open FILE, ">$htmlfile" ) {
        S_w2log( 5, "HTML file : $htmlfile \n" );
        S_w2rep( join( '', "<div class='w2rep'><a href='$htmlfile'> $crashName : Sensor curves to be injected </a></div>", "\n" ) );
        print FILE "<html><body><div style='text-align:center; font-weight:bold;'><p>$crashName</p></div>" . $table1->getTable() . "</body></html>";
        close(FILE);
    }
    else {
        S_set_error( "unable to create HTML file with path : $htmlfile ", 21 );
    }

    return 1;

}

=head2 MDSRESULT_GetDeploymentForSimDevice

    ($minTime_ms, $maxTime_ms, $isDeployed) = MDSRESULT_GetDeploymentForSimDevice($crashdetails_href, $simDeviceName);

Retrieves the min time, max time and isDeployed for the given sim device name from the  crash settings

    $crashdetails_href = It is hash reference, contains the crash info such as Sensor details, SimDevices details and Enviromental setting details

                        $crashdetails_href is the return value got from MDSRESULT_GetCrashDetails()

    $simDeviceName     = Sim device name to which the deployment details to be retrieved

B<Return Value(s) :>
    $minTime_ms = Minimum time for the given sim device in milli seconds

    $maxTime_ms = Maximum time for the given sim device in milli seconds

    $isDeployed = Deployed value for the given sim device (values: $NOFIRE_SIMDEVICE (=0), $FIRE_SIMDEVICE (=1), $CANFIRE_SIMDEVICE (=2))

=cut

sub MDSRESULT_GetDeploymentForSimDevice {
    my $crashDetails_href = shift;
    my $simDevice         = shift;
    my ( $minTime_ms, $maxTime_ms, $isDeployed );

    # STEP validate if parameters are received correctly
    unless ( S_checkFunctionArguments( 'MDSRESULT_GetDeploymentForSimDevice($crashDetails_href, $simDevice)', $crashDetails_href, $simDevice ) ) {
        return ( $FAILED, $FAILED, $FAILED );
    }

    S_w2log( 4, "MDSRESULT_GetDeploymentForSimDevice (SIMDEVICE: $simDevice) fetching the details from given Hash reference \n" );

    $minTime_ms = $crashDetails_href->{'SIMDEVICES'}->{$simDevice}{'MINT'};
    $maxTime_ms = $crashDetails_href->{'SIMDEVICES'}->{$simDevice}{'MAXT'};
    $isDeployed = $crashDetails_href->{'SIMDEVICES'}->{$simDevice}{'ISDEPLOYED'};

    unless ( defined($minTime_ms) && defined($maxTime_ms) && defined($isDeployed) ) {

        S_set_error( "MIN deployment time for sim device doesn't exist in given Crashsettings for $simDevice", 114 ) unless ( defined($minTime_ms) );
        S_set_error( "MAX deployment time for sim device doesn't exist in given Crashsettings for $simDevice", 114 ) unless ( defined($maxTime_ms) );
        S_set_error( "Deployment status for '$simDevice' doesn't exist in given Crashsettings",                114 ) unless ( defined($isDeployed) );
        return ( $FAILED, $FAILED, $FAILED );
    }

    S_w2log( 4, "MDSRESULT_GetDeploymentForSimDevice (SIMDEVICE: $simDevice) : min time = $minTime_ms ms, max time(ms) = $maxTime_ms ms, deployment status (No(0) / Yes(1) / Can fire(2) = $isDeployed \n" );

    return ( $minTime_ms, $maxTime_ms, $isDeployed );
}

=head2 MDSRESULT_GetSignalsForSensor

    $sensorsignals_href = MDSRESULT_GetSignalsForSensor($crashdetails_href, $sensorname);

Retrieves the sensor signals and sampling interval (in micro seconds) of the given sensor

    $crashdetails_href = It is hash reference, contains the crash info such as Sensor details, SimDevices details and Enviromental setting details

                        ($crashdetails_href is the return value got from MDSRESULT_GetCrashDetails subroutine)

    $sensorname        = Sensor name to which the signal details to be retrieved

B<I<Return Value(s) :>>

    $sensorsignals_href = It is hash refernce, contains the signals (array reference) and sampling interval (in micro seconds)

B<I<Examples :>>

    $sensorsignals_href = MDSRESULT_GetSignalsForSensor($crashdetails_href, $sensorname);

        $sensorsignals_href = {
            'SAMPLETIME_US' => 24000,
            'SIGNALS' => [0, -0.125, 0.324, ...],
        };

=cut

sub MDSRESULT_GetSignalsForSensor {
    my $crashDetails_href = shift;
    my $sensorName        = shift;
    my ($sensorsignals_href);

    # STEP validate if parameters are received correctly
    unless ( S_checkFunctionArguments( 'MDSRESULT_GetSignalsForSensor($crashDetails_href, $sensorName)', $crashDetails_href, $sensorName ) ) {
        return;
    }

    S_w2log( 4, "MDSRESULT_GetSignalsForSensor ($sensorName) fetching the sensor signals from given hash reference\n" );

    $sensorsignals_href = $crashDetails_href->{'SENSORS'}{$sensorName};

    # STEP if the sensor signals are not available, throw error
    unless ( defined $sensorsignals_href ) {
        S_set_error( "Sensor details of Sensor $sensorName does not exist in the given \$crashDetails_href", 114 );
        return;
    }

    S_w2log( 4, "MDSRESULT_GetSignalsForSensor ($sensorName) : sampling time in us = " . $sensorsignals_href->{'SAMPLETIME_US'} . ", number of points = " . scalar( @{ $sensorsignals_href->{'SIGNALS'} } ) . "\n" );

    # STEP if the sensor signals available, return it to user
    return ($sensorsignals_href);
}

=head2 MDSRESULT_GetStateOfEnvVariable


I<B<Syntax : >>

    $envState = MDSRESULT_GetStateOfEnvVariable($crashdetails_href, $EnvVariableName);

I<B<Arguments    : >>

    $crashDetails_href = A self contained Hash reference about a Crash (returned by MDSRESULT_GetCrashDetails())

    $EnvVariableName   = MDS environment variable name (e.g., BLFD_State)

I<B<Description :>>

Retrieves the state of the MDS environmental variable from the given crash settings ($crashdetails_href)

I<B<Return values :>>

    $envState   =  value configured for the given Environment parameter within $crashdetails_href

I<B<Examples :>>

    $envState = MDSRESULT_GetStateOfEnvVariable($crashdetails_href, 'BT1FP_SquibResistance');

=cut

sub MDSRESULT_GetStateOfEnvVariable {
    my $crashDetails_href = shift;
    my $envVariableName   = shift;
    my ($envState);

    # STEP validate if parameters are received correctly
    unless ( S_checkFunctionArguments( 'MDSRESULT_GetStateOfEnvVariable($crashDetails_href, $envVariableName)', $crashDetails_href, $envVariableName ) ) {
        return;
    }

    $envState = $crashDetails_href->{'ENVIRONMENT'}{$envVariableName};

    unless ( defined $envState ) {
        S_set_error( "The environmental state for $envVariableName is not found in the given \$crashdetails_href", 114 );
        return $FAILED;
    }

    return $envState;
}

=head2 MDSRESULT_Init

I<B<Syntax : >>

    MDSRESULT_Init();

I<B<Arguments    : >>

None

I<B<Description :>>

Initializes the low level MDSResultProcess DLL & logs the versions of low level PM, XS, CW, DLL to test report

I<B<Return values :>>

None

I<B<Examples :>>

    MDSRESULT_Init();

=cut

sub MDSRESULT_Init {
    S_w2log( 5, "MDSRESULT_Init : loading the low level DLL \n" );

    # log the versions for traceability
    my $version;
    $version = mdsresult_getPMrevision();
    S_w2log( 4, "PM $version\n" );
    $version = mdsresult_getXSrevision();
    S_w2log( 4, "XS $version\n" );
    $version = mdsresult_getCWrevision();
    S_w2log( 4, "CW $version\n" );

    # init the Low level MDSResult process DLL
    _MDSRESULT_InitMDSResultProcessDLL();

    return;

}

=head1 Non Exported Subroutines

=head2 _MDSRESULT_GetCrashIndexFromCrashName

    $crashIndex = _MDSRESULT_GetCrashIndexFromCrashName( $crashName );

return the Crash index corresponding to particular Crash name given.

Throws a warning, if the given CrashName is redundant in the loaded MDS Result DB & The last crash index is returned incase if the Crash name is redundant.

=cut

sub _MDSRESULT_GetCrashIndexFromCrashName {
    my $crashName = shift;

    my $crashNameDetails = $ResultDBCrashes{'CRASHNAME_BASED'}{$crashName};

    # validate if crash exists in the loaded result DB
    if ( !defined $crashNameDetails ) {
        S_set_error( "The given CRASHNAME '$crashName' is not available in the loaded MDS Result DB $ResultDBCrashes{'RESULTDB'}", 5 );
        return $FAILED;
    }

    my $redundantIndexes = $crashNameDetails->{"REDUNDANTS"};

    # validate redundant crash names
    if ( defined $redundantIndexes && scalar(@$redundantIndexes) > 1 ) {
        S_set_error( "The given CRASHNAME '$crashName' is redundant in the loaded MDS Result DB $ResultDBCrashes{'RESULTDB'}. try CRASHINDEX as [@$redundantIndexes] to get relevant crash details.", 21 );
    }

    return ( $crashNameDetails->{'INDEX'}, $crashNameDetails->{'STATEVARIATIONS'} );
}

=head2 _MDSRESULT_GetCrashNameFromCrashIndex

    $crashName = _MDSRESULT_GetCrashNameFromCrashIndex( $crashIndex );

return the Crash name corresponding to particular Crash index given.

Throws error, if the given CrashIndex is redundant in the loaded MDS Result DB

=cut

sub _MDSRESULT_GetCrashNameFromCrashIndex {
    my $crashIndex = shift;

    my $crashIndexDetails = $ResultDBCrashes{'CRASHINDEX_BASED'}{$crashIndex};
    my $availableStateVariations;

    # STEP validate, if the given/determined Crash index, a proper number?
    unless ( $crashIndex =~ /^\d+$/ ) {

        # throw error that Crash index should be a number
        S_set_error( "The given CRASHINDEX '$crashIndex' is not a number", 109 );
        return $FAILED;
    }

    # validate if crash exists in the loaded result DB
    if ( !defined $crashIndexDetails ) {
        S_set_error("The given CRASHINDEX '$crashIndex' is not available in the loaded MDS Result DB $ResultDBCrashes{'RESULTDB'}");
        return $FAILED;
    }

    my $redundantIndexes = $crashIndexDetails->{"REDUNDANTS"};

    # validate redundant crash names for same index, although it is not expected to happen in the result DB due to primary key constraints
    if ( defined $redundantIndexes && scalar(@$redundantIndexes) > 1 ) {
        S_set_error( "The given CRASHINDEX '$crashIndex' is redundant in the loaded MDS Result DB $ResultDBCrashes{'RESULTDB'}.", 0 );
    }

    return ( $crashIndexDetails->{'NAME'}, $crashIndexDetails->{'STATEVARIATIONS'} );
}

=head2 _MDSRESULT_Check_status

 _MDSRESULT_Check_status($status);

  $status = Status to be validated

enquires about the error string for given status code with the underlying low level DLL

logs error, if the error code is negative and set verdict to INCONC

=cut

sub _MDSRESULT_Check_status {
    my $status = shift;

    if ( $status < 0 ) {
        my $errortext = mdsresult_GetErrorString($status);
        S_set_error( "MDS ($status): $errortext", 5 );
    }

    return;
}

=head2 _MDSRESULT_InitMDSResultProcessDLL

    MDStype = _MDSRESULT_InitMDSResultProcessDLL();

Loads the DLL, initializes the Low level DLL functiona pointers, logs the version of low level DLL used

=cut

sub _MDSRESULT_InitMDSResultProcessDLL {

    if ($IsMDSDLLInitialized) {
        S_w2log( 5, "Low level MDSResultprocess DLL is already initialized!\n" );
        return;
    }

    my ( $status, $version );

    $status = mdsresult_Start();
    _MDSRESULT_Check_status($status);
    S_w2log( 5, "Status of mdsresult_Start: $status \n" );

    my $flagEnableDebugLogFile = $main::ProjectDefaults->{'MDSRESULT'}{'ENABLE_DEBUG_LOG_FILE'};
    if ( not defined($flagEnableDebugLogFile) or $flagEnableDebugLogFile != 1 ) { $flagEnableDebugLogFile = 0; }
    my $snapshot_directory = "$main::REPORT_PATH/_snapshot_";
    unless ( -e $snapshot_directory or mkdir $snapshot_directory ) {
        S_set_error("Snapshot Directory: $snapshot_directory does not exist and could not be created\n");
        return;
    }
    $snapshot_directory =~ s/\//\\/g;    # replace all slashes by backslashes
    mdsresult_SetFlagPrintDbgInfosEnabled( $flagEnableDebugLogFile, $snapshot_directory );

    my $iMaxSignalSliceSize = $main::ProjectDefaults->{'MDSRESULT'}{'MAX_FILTER_SIGNAL_SLICE_SIZE'};
    if ( defined($iMaxSignalSliceSize) and $iMaxSignalSliceSize ne "default" ) {
        mdsresult_SetMaxFilterSignalSliceSize($iMaxSignalSliceSize);
    }

    ( $status, $version ) = mdsresult_GetDLLVersion();
    S_w2log( 4, "MDSResultProcess DLL: $version\n" );

    # if DLL loading & version retrieval is successful, then set the flag
    if ( $status >= 0 ) {

        # indicate that the MDSResult DLL & Result process are initialized
        $IsMDSDLLInitialized = 1;
    }

    return;
}

=head2 _MDSRESULT_ReadUsedMDSType

    MDStype = _MDSRESULT_ReadUsedMDSType( $ResultFile_Label );

return MDS, MDSNG or MDSNG64 if the configured ProjectDefaults->{'MDSRESULT'}{"$resultFileLabel"}{'MDSTYPE'} is defined & valid

return $FAILED on invalid ProjectDefaults->{'MDSRESULT'}{"$resultFileLabel"}{'MDSTYPE'} setting

=cut

sub _MDSRESULT_ReadUsedMDSType {
    my $resultFileLabel = shift;

    my $usedMDS = S_get_contents_of_hash( [ 'MDSRESULT', "RESULTS", "$resultFileLabel", 'MDSTYPE' ] );

    # validate the 'MDSTYPE' existence
    unless ( defined $usedMDS ) {
        S_set_error( "'MDSTYPE' is not configured (ProjectDefaults->{'MDSRESULT'}{'$resultFileLabel'}{'MDSTYPE'}). it shall be MDS, MDSNG or MDSNG64", 5 );
        return ( $FAILED, $usedMDS );
    }

    # call the atomic API to validate MDS type
    my $usedMDSType = _MDSRESULT_ValidateMDSType( $usedMDS, "ProjectDefaults->{'MDSRESULT'}{'$resultFileLabel'}{'MDSTYPE'}" );

    return ( $usedMDSType, $usedMDS );
}

=head2 _MDSRESULT_ValidateMDSType

    MDStype = _MDSRESULT_ValidateMDSType( $usedMDS, $reasonString );

return MDS, MDSNG or MDSNG64 if the given $usedMDS is valid

return $FAILED on invalid $usedMDS

=cut

sub _MDSRESULT_ValidateMDSType {

    my $usedMDS      = shift;
    my $reasonString = shift;

    # validate the value of UsedMDS. it shall be mds/mdsng/mdsng64
    unless ( $usedMDS =~ /^mds$/i || $usedMDS =~ /^mdsng$/i || $usedMDS =~ /^mdsng64$/i ) {
        S_set_error( "MDSTYPE '$usedMDS' is not valid. check $reasonString. it shall be MDS, MDSNG or MDSNG64", 5 );
        return $FAILED;
    }

    # return MDS type based on the configuration
    my $usedMDSType;
    if    ( $usedMDS =~ /^mds$/i )     { $usedMDSType = MDS; }
    elsif ( $usedMDS =~ /^mdsng$/i )   { $usedMDSType = MDSNG; }
    elsif ( $usedMDS =~ /^mdsng64$/i ) { $usedMDSType = MDSNG64; }

    return $usedMDSType;

}

=head2 _MDSRESULT_LoadMDSResultDatabase

    $status = _MDSRESULT_LoadMDSResultDatabase( $mdbfile, $nMDSType );

loads the given MDS result database (.mdb) file & prepares the global hash to be used for successive MDSRESULT_GetCrashDetails() API calls

=cut

sub _MDSRESULT_LoadMDSResultDatabase {

    # STEP receive the parameters Result DB path, MDS Type
    my $resultDB = shift;
    my $nMDSType = shift;

    my ( $status, $crashEntityIDs, $crashEntityNames, $numOfIterations );

    my $currentMDSDB = $ResultDBCrashes{'RESULTDB'};
    my ( $newMDSDB, $newMDSType, $newMDSTypeNumber );

    # STEP if $resultDB is not given, we take the DEFAULT configuration from result DB collection (ProjectDefaults->{'MDSRESULT'}{'RESULTS'})
    unless ( defined($resultDB) ) {
        S_w2log( 4, "MDSResult DB is not passed as a Parameter. Assuming ProjectDefaults->{'MDSRESULT'}{'DEFAULT'} configuration from ProjectDefaults.\n" );

        $resultDB = DEFAULT;

        ( $newMDSTypeNumber, $newMDSType ) = _MDSRESULT_ReadUsedMDSType($resultDB);

        # IF the reading of MDS type failed from ProjectDefaults->{'MDSRESULT'}{'RESULTS'}{'DEFAULT'}
        if ( $newMDSTypeNumber == $FAILED ) {
            return $FAILED;
        }

    }

    my $resultDBCollection = S_get_contents_of_hash_NOERROR( [ 'MDSRESULT', 'RESULTS' ] );

    if ( defined($resultDBCollection) && grep { /^\Q$resultDB\E$/i } keys(%$resultDBCollection) ) {

        # IF-YES-START
        # if the given result DB is configured in ResultDB collection of ProjectDefaults, then retrieve the particular MDS DB
        my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$resultDB" ] );
        $newMDSDB = $resultDBDetails->{'PATH'};

        # STEP if ProjectDefaults->{'MDSRESULT'}{'RESULTS'}{"DEFAULT"} is also not defined, return error
        if ( !defined $newMDSDB ) {
            S_set_error( "ProjectDefaults->{'MDSRESULT'}{'RESULTS'}{'$resultDB'}{'PATH'} is not defined", 20 );
            return $FAILED;
        }

        ( $newMDSTypeNumber, $newMDSType ) = _MDSRESULT_ReadUsedMDSType($resultDB);

        # if the reading of MDS type failed, return
        if ( $newMDSTypeNumber == $FAILED ) {
            return $FAILED;
        }

        # IF-YES-END
    }
    else {
        # IF-NO-START
        # if ProjectDefaults->{'MDSRESULT'}{'RESULTS'}{"$resultDB"} is also not defined, then assume it as a pure file path
        S_w2log( 4, "! Result DB configuration ProjectDefaults->{'MDSRESULT'}{'RESULTS'}{$resultDB} is not defined. Assuming $resultDB as result DB path\n" );

        $newMDSDB   = $resultDB;
        $newMDSType = $nMDSType;

        # STEP validate that the MDSTYPE for DIRECT MDSRESULT path is provided as parameter
        unless ( defined $newMDSType ) {
            S_set_error( "! MDSTYPE is not provided as parameter for direct RESULTDB path '$newMDSDB'", 109 );
            return $FAILED;
        }

        # STEP validate the given MDSTYPE for the local result DB
        $newMDSTypeNumber = _MDSRESULT_ValidateMDSType( $newMDSType, "given MDS Type \$newMDSType" );

        # STEP throw error if MDSTYPE validation fails
        if ( $newMDSTypeNumber == $FAILED ) {
            return $FAILED;
        }

        # IF-NO-END
    }

    #prepare the paths in a standard format for comparing (ALWAYS TAKE ABSOLUTE PATH WITH '\')
    $newMDSDB = File::Spec->rel2abs($newMDSDB);

    S_w2log( 4, "MDSRESULT_LoadMDSResultDatabase (RESULTDB => $newMDSDB, MDSTYPE => $newMDSType) \n" );

    # replace all forward slashes '/' to backward slashes '\'
    $newMDSDB =~ s/\//\\/ig;

    # if the currently initialized CRASHDB is same as the given mdbfile, return
    if ( defined($currentMDSDB) && $currentMDSDB eq $newMDSDB ) {
        S_w2log( 5, "$newMDSDB is already loaded\n" );

        # Setting MDSTYPE to make sure that it is not disturbed by MDSRESULT_GetAllRawSignals()
        $status = mdsresult_ConfigureUsedMDSType( $ResultDBCrashes{'MDSTYPENUMBER'} );
        S_w2log( 4, "mdsresult_ConfigureUsedMDSType ($ResultDBCrashes{'MDSTYPE'} ($ResultDBCrashes{'MDSTYPENUMBER'}) ) : $status \n" );
        _MDSRESULT_Check_status($status);
        return 1;
    }

    # unload already loaded result database
    if ($isMDSInitialized) {
        S_w2log( 4, "unloading already loaded MDS result database ($currentMDSDB) \n" );
        $status = mdsresult_CloseResult();
        _MDSRESULT_Check_status($status);
        S_w2log( 4, "Status of mdsresult_CloseResult : $status \n" );
        $isMDSInitialized = 0;
    }

    # empty the already existing configurations
    %ResultDBCrashes = ();

    # if CRASHDB is not loaded (CRASHDB = undef) (or) the currently initialized CRASHDB is not same as the given mdbfile, (re)load the given mdb file
    $status = mdsresult_ConfigureUsedMDSType($newMDSTypeNumber);
    S_w2log( 5, "mdsresult_ConfigureUsedMDSType ( $newMDSType ($newMDSTypeNumber) ) : $status \n" );
    _MDSRESULT_Check_status($status);

    $status = mdsresult_InitResult($newMDSDB);
    _MDSRESULT_Check_status($status);
    S_w2log( 4, "Status of mdsresult_InitResult ($newMDSDB) : $status \n" );

    if ( $status >= 0 ) {
        $status = S_add_file_to_snapshot($newMDSDB);

        # indicate that the MDSResult Result process are initialized
        $isMDSInitialized                 = 1;
        $ResultDBCrashes{'RESULTDB'}      = $newMDSDB;
        $ResultDBCrashes{'MDSTYPE'}       = $newMDSType;
        $ResultDBCrashes{'MDSTYPENUMBER'} = $newMDSTypeNumber;
    }
    else {
        return $FAILED;
    }

    # Fetch all the Crash Entity details from database
    ( $status, $crashEntityIDs, $crashEntityNames, $numOfIterations ) = mdsresult_GetCrashEntityIterations();
    _MDSRESULT_Check_status($status);
    S_w2log( 5, "Status of mdsresult_GetCrashEntityIterations : $status \n" );

    #Creates an hash with entity name and entity Id as key and value(Internal to this module)
    if ( scalar(@$crashEntityNames) == scalar(@$crashEntityIDs) ) {

        # create the crash entity maps in backup hash both based on names & indices
        $ResultDBCrashes{'CRASHINDEX_BASED'} = {};
        $ResultDBCrashes{'CRASHNAME_BASED'}  = {};

        foreach ( my $ndx = 0 ; $ndx < scalar(@$crashEntityNames) ; $ndx++ ) {

            # note down the redundant names , to show error in future
            push( @{ $ResultDBCrashes{'CRASHINDEX_BASED'}{ $$crashEntityIDs[$ndx] }{'REDUNDANTS'} }, $$crashEntityNames[$ndx] );
            $ResultDBCrashes{'CRASHINDEX_BASED'}{ $$crashEntityIDs[$ndx] }{'NAME'}            = $$crashEntityNames[$ndx];
            $ResultDBCrashes{'CRASHINDEX_BASED'}{ $$crashEntityIDs[$ndx] }{'STATEVARIATIONS'} = $$numOfIterations[$ndx];
        }

        foreach ( my $ndx = 0 ; $ndx < scalar(@$crashEntityNames) ; $ndx++ ) {

            # note down the redundant names , to show error in future
            push( @{ $ResultDBCrashes{'CRASHNAME_BASED'}{ $$crashEntityNames[$ndx] }{'REDUNDANTS'} }, $$crashEntityIDs[$ndx] );
            $ResultDBCrashes{'CRASHNAME_BASED'}{ $$crashEntityNames[$ndx] }{'INDEX'}           = $$crashEntityIDs[$ndx];
            $ResultDBCrashes{'CRASHNAME_BASED'}{ $$crashEntityNames[$ndx] }{'STATEVARIATIONS'} = $$numOfIterations[$ndx];
        }
    }
    else {
        %ResultDBCrashes = {};
        S_set_error( "Number of entries of CrashEntityNames and CrashEntityIDs are unequal ", 114 );
        return $FAILED;
    }

    # STEP return
    return 1;

}

=head2 _MDSRESULT_ApplySensorProperties

I<B<Syntax : >>

    $status = _MDSRESULT_ApplySensorProperties( $sensorProperties_href );

I<B<Arguments    : >>

    $sensorProperties_href : Hash reference to sensor properties (content: see example below with 10 sensors)

I<B<Description :>>


Applies sensor properties in MDSResultProcess.dll

B<Return Value(s) :>

    $status = error code (>=0: no error, < 0: error)

I<B<Example :>>

    $status =
    _MDSRESULT_ApplySensorProperties ( { AMPLITUDE        => [ 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 ],
                                         CORRECTION_ANGLE => [ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ],
                                         CRASH_DEVICE     => [   1,   1,   1,   1,   2,   2,   1,   1,   1,   1 ],
                                         DEV_TYPE_INTERN  => [   0,   0,   0,   0,   0,   0,   0,   0,   0,   0 ],
                                         INPUT_BIT_WIDTH  => [  12,  12,  12,  12,  12,  12,  12,  12,  12,  12 ],
                                         OFFSET           => [ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ],
                                       } );
	Note: Table column = sensor index inside MDSResultProcess.dll (each with its own property values).
	
	CRASH_DEVICE = 0: QuaTe-analog, 1: QuaTe-digital, 2: Bus

=cut

sub _MDSRESULT_ApplySensorProperties {
    my $sensorProperties_href = shift;

    # Log transfered properties to test report
    S_w2log( 3, "_MDSRESULT_ApplySensorProperties:\n" );
    for my $sensorProperty ( sort keys %{$sensorProperties_href} ) {
        my @array = @{ $sensorProperties_href->{$sensorProperty} };

        my $logText;
        $logText = sprintf( "%18s (%d sensors): ", $sensorProperty, scalar(@array) );

        # properties of type integer
        if ( $sensorProperty eq "DEV_TYPE_INTERN" || $sensorProperty eq "INPUT_BIT_WIDTH" || $sensorProperty eq "CRASH_DEVICE" ) {
            $logText .= sprintf " %d", $_ for @array;
        }

        # properties of type float
        else {
            $logText .= sprintf " %.3f", $_ for @array;
        }
        S_w2log( 3, "$logText\n" );
    }

    my $status = mdsresult_ApplySensorProperties($sensorProperties_href);
    _MDSRESULT_Check_status($status);

    return $status;
}

1;

__END__

=head1 AUTHORS

G V Sriram, E<lt> VeerabhadraSriram.Grandhi@in.bosch.com E<gt>

Arulkumar S, E<lt> Arulkumar.S@in.bosch.com E<gt>


=head1 SEE ALSO

Perl documentation

=cut
