package MDSResult;

use 5.006000;
use strict;
use warnings;
use LIFT_simulation;

use constant MDS     => 0;
use constant MDSNG   => 1;
use constant MDSNG64 => 2;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use MDSResult ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  mdsresult_getPMrevision
  mdsresult_getXSrevision
  mdsresult_getCWrevision
  mdsresult_Start
  mdsresult_SetFlagPrintDbgInfosEnabled
  mdsresult_GetDLLVersion
  mdsresult_InitResult
  mdsresult_SetMaxFilterSignalSliceSize
  mdsresult_ApplySensorProperties
  mdsresult_ConfigureUsedMDSType
  mdsresult_GetAlgoIDs
  mdsresult_GetConstantEnvParams
  mdsresult_GetDynamicEnvParams
  mdsresult_GetSimDevices
  mdsresult_GetSensorSignalsForCrash
  mdsresult_GetAllRawSignalsForCrash
  mdsresult_GetSimDevResultsForCrash
  mdsresult_GetEnvironmentSettingsForCrash
  mdsresult_GetCrashVelocity_kmh
  mdsresult_GetCrashVelocity_X_kmh
  mdsresult_GetCrashVelocity_Closing_kmh
  mdsresult_GetCrashTemperature_degCelsius
  mdsresult_GetCrashAssignmentComment
  mdsresult_GetSensorDetails
  mdsresult_GetCrashEntityIterations
  mdsresult_CloseResult
  mdsresult_GetErrorString
  mdsresult_End
  MDS
  MDSNG
  MDSNG64
);

# ATTENTION:
# 1. $VERSION has to be identical to the $VERSION in the MDSResult.pm, which is used during rebuild.bat of XS-Wrapper MDSResult.dll,
#    otherwise DynaLoader.pm (Function: bootstrap) will throw the error "MDSResult object version 0.012345 does not match bootstrap parameter 1.0 at C:/TurboLIFT/Perl512/lib/DynaLoader.pm line 224".
# 2. $VERSION has to contain only numerical values and dots,
#    otherwise DynaLoader.pm (Function: bootstrap) will throw the error "Invalid version format (non-numeric data) at C:/TurboLIFT/Perl512/lib/DynaLoader.pm line 224.".
# 3. Even introducing a 2nd $VERSION_XS will not work, if given to bootstrap command below, because $VERSION is (seems to be) implicitly used for XS purpose!
our ( $VERSION, $HEADER );
$VERSION = '1.0';

require XSLoader;
XSLoader::load( 'MDSResult', $VERSION );

# Preloaded methods go here.

sub mdsresult_getPMrevision {
    return ('SCM');
}

sub mdsresult_getXSrevision {
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub mdsresult_getCWrevision {
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

#
# simulation functions start here
#

if ($main::opt_simulation) {

    # redefine all functions for simulation mode with default return values
    foreach my $function (@EXPORT) {
        no strict 'refs';
        next if ( $function !~ /^mdsresult/ );

        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
        'mdsresult_GetCrashEntityIterations' => { 'default' => [ 0, [1], [1], [1] ], },
        'mdsresult_GetSensorDetails' => { 'default' => [ 1, [1], [1], [1], [1] ], },
        'mdsresult_GetSimDevices'                  => { 'default' => [ 0, [1] ], },
        'mdsresult_GetConstantEnvParams'           => { 'default' => [ 0, [1], [1] ], },
        'mdsresult_GetDynamicEnvParams'            => { 'default' => [ 0, [1] ], },
        'mdsresult_GetCrashVelocity_kmh'           => { 'default' => [ 0, [1], 1 ], },
        'mdsresult_GetCrashVelocity_X_kmh'         => { 'default' => [ 0, [1] ], },
        'mdsresult_GetCrashVelocity_Closing_kmh'   => { 'default' => [ 0, [1] ], },
        'mdsresult_GetCrashTemperature_degCelsius' => { 'default' => [ 0, [1] ], },
        'mdsresult_GetCrashAssignmentComment'      => { 'default' => [ 0, [1] ], },
        'mdsresult_GetAlgoIDs' => { 'default' => [ { 1 => 1 } ], },
        'mdsresult_GetSensorSignalsForCrash' => { 'default' => [ 1, [1], [1] ], },
    };
    SIM_addToValuesTable($returnValuesTable_href);

}

1;
__END__

=head1 NAME

MDSResult - Perl extension for generic MDSResultProcess dll

=head1 SYNOPSIS

  use MDSResult;

	my ($version,$status);
	my($CrashEntityIDs, $CrashEntityNames, $NumOfIterations, $EnvName_Dynamic,, $SimDevices);
	my($SensorSignals, $SamplingTime_us, $ModuleName, $SensorName, $SensorDirection,$SensorType);
	my($ChannelLocations, $ChannelDirections, $SimDevNames, $MinT_ms, $MaxT_ms, $isDeployed);
	my($ModuleNames, $EnvNames, $EnvValues, $errortext);
	my %SensorProperties;

	$version = mdsresult_getPMrevision();
	print "PM $version\n";
	$version = mdsresult_getXSrevision();
	print "XS $version\n";
	$version = mdsresult_getCWrevision();
	print "CW $version\n";

    $status = mdsresult_SetFlagPrintDbgInfosEnabled(0, $logFilePath);

	($status, $version) = mdsresult_GetDLLVersion();
	print "MDSResultprocess DLL $version\n";

	$status = mdsresult_Start();
	print "mdsresult_Start: ($status) \n";

	$status = mdsresult_ConfigureUsedMDSType(MDSNG);
	print "mdsresult_ConfigureUsedMDSType ($status) \n" . mdsresult_GetErrorString($status);

	$status = mdsresult_InitResult("D:\\Sriram\\Projects\\MDSResult\\Y352-1.mdb");
	print "perl: ($status) init\n";

    $status = mdsresult_SetMaxFilterSignalSliceSize(100000);
    print "perl: ($status) SetMaxFilterSignalSliceSize\n";

	$status = mdsresult_ApplySensorProperties(\%SensorProperties);
	print "perl: ($status) ApplySensorProperties\n";

	($status, $CrashEntityIDs, $CrashEntityNames, $NumOfIterations) = mdsresult_GetCrashEntityIterations();
	print "perl: ($status) GetCrashEntityIterations\n";

    $algoIDs_href = mdsresult_GetAlgoIDs();
    print "perl: mdsresult_GetAlgoIDs\n";
    
	($status, $EnvNames_const, $EnvValues_const) = mdsresult_GetConstantEnvParams();

	($status, $EnvName_Dynamic) = mdsresult_GetDynamicEnvParams();
	print "perl: ($status) GetDynamicEnvParams\n";

	($status, $SimDevices) = mdsresult_GetSimDevices();
	print "perl: ($status) GetSimDevices\n";

	($status, $ModuleName, $SensorName, $SensorDirection,$SensorType) = mdsresult_GetSensorDetails();
	print "perl: ($status) GetSensorDetails\n";

	($status, $SensorSignals, $SamplingTime_us) = mdsresult_GetSensorSignalsForCrash( $crashid, $iterationnumber, $options );
	print "perl: ($status) GetSensorSignalsForCrash\n";

	($status, $ChannelLocations, $ChannelDirections, $SensorSignals, $SamplingTime_us) = mdsresult_GetAllRawSignalsForCrash($crashname);
	print "perl: ($status) GetAllRawSignalsForCrash\n";

	($status,$SimDevNames, $MinT_ms, $MaxT_ms, $isDeployed) = mdsresult_GetSimDevResultsForCrash( $crashid, $iterationnumber );
	print "perl: ($status) GetSimDevResultsForCrash\n";

	($status,$ModuleNames, $EnvNames, $EnvValues)= mdsresult_GetEnvironmentSettingsForCrash( $crashid,$iterationnumber );
	print "perl: ($status) GetEnvironmentSettingsForCrash\n";

	($status, $velocity, $timeshift) = mdsresult_GetCrashVelocity_kmh(1, 1);
	
	($status, $velocity_x_kmh) = mdsresult_GetCrashVelocity_X_kmh(1);

    ($status, $velocity_x_kmh) = mdsresult_GetCrashVelocity_Closing_kmh(1);
    
    ($status, $temperature_degCelsius_aref) = mdsresult_GetCrashTemperature_degCelsius(1);
    
    ($status, $crashAssignmentComment_aref) = mdsresult_GetCrashAssignmentComment(1);

	$status = mdsresult_CloseResult();
	print "perl: ($status) close result\n";

	my $errortext = mdsresult_GetErrorString($status);
	print "perl: ($errortext) GetErrorString\n";

=head1 DESCRIPTION

All these functions are wrapped around MDSResultProcess DLL APIs

=head2 CONSTANTS (MDS, MDSNG, MDSNG64)

    MDS - The constant to indicate the Type for old MDS

    MDSNG - The constant to indicate the Type for MDSNG
    
    MDSNG64 - The constant to indicate the Type for MDSNG64

These constants are assigned to DLL understandable values (MDS = 0, MDSNG = 1, , MDSNG64 = 2). These constant will be needed for the function mdsresult_ConfigureUsedMDSType()

=head2 mdsresult_Start

	$status = mdsresult_Start();

Starts the MDS database

=head2 mdsresult_SetFlagPrintDbgInfosEnabled

    $status = mdsresult_SetFlagPrintDbgInfosEnabled($enable, $logFilePath);

Set or Reset flag to enable (1) or disable (0) the debug log file (path without terminating backslash)

=head2 mdsresult_GetDLLVersion

    ($status, $version) = mdsresult_GetDLLVersion();

Retrieves the version number from low level MDSResultProcess DLL

=head2 mdsresult_ConfigureUsedMDSType

    $status = mdsresult_ConfigureUsedMDSType(MDSNG);

To configure the MDSResult Process DLL to make use of particular type of MDS (MDS, MDSNG or MDSNG64)

=head2 mdsresult_InitResult

	$status = mdsresult_InitResult("D:\\Sriram\\Projects\\MDSResult\\Y352-1.mdb");

Loads the mdb file

=head2 mdsresult_SetMaxFilterSignalSliceSize

    $status = mdsresult_SetMaxFilterSignalSliceSize(100000);

Configures the maximum filter signal slice size

=head2 mdsresult_ApplySensorProperties

    $status = mdsresult_ApplySensorProperties(\%SensorProperties);

Transfer some sensor properties for each sensor

=head2 mdsresult_GetCrashEntityIterations

	($status, $CrashEntityIDs,	$CrashEntityNames, $NumOfIterations) = mdsresult_GetCrashEntityIterations();

Fetch all Crash Entity details from database

=head2 mdsresult_GetAlgoIDs

    $algoIDs_href = mdsresult_GetAlgoIDs();

Fetch all algo IDs from database

=head2 mdsresult_GetConstantEnvParams

    ($status, $EnvNames_const, $EnvValues_const) = mdsresult_GetConstantEnvParams();

Fetch all constant environment parameter names & values from MDS Result database

=head2 mdsresult_GetDynamicEnvParams

	($status, $EnvName_Dynamic) = mdsresult_GetDynamicEnvParams();

Fetch all dynamic environment parameters from database

=head2 mdsresult_GetSimDevices

	($status, $SimDevices) = mdsresult_GetSimDevices();

Fetch all SIMDevice Details from database

=head2 mdsresult_GetSensorDetails

	($status, $ModuleName, $SensorName, $SensorDirection,$SensorType) = mdsresult_GetSensorDetails();

Fetch all Sensor Details from database

=head2 mdsresult_GetSensorSignalsForCrash

	($status, $SensorSignals, $SamplingTime_us) = mdsresult_GetSensorSignalsForCrash( $crashid, $iterationnumber, $options );

Fetch Sensor Signals for Crash from database

    $options = combination of 0x0001 (NO_ROTATION) | 0x0002 (NO_FILTERING) | 0x0004 (NO_AMPLIFICATION)

=head2 mdsresult_GetAllRawSignalsForCrash

	($status, $ChannelLocations, $ChannelDirections, $SensorSignals, $SamplingTime_us) = mdsresult_GetAllRawSignalsForCrash($crashname);

Fetch raw Signals details for Crash from database

=head2 mdsresult_GetSimDevResultsForCrash

	($status,$SimDevNames, $MinT_ms, $MaxT_ms, $isDeployed) = mdsresult_GetSimDevResultsForCrash( $crashid, $iterationnumber );

Get SimDevice result for a particular Crash from database

=head2 mdsresult_GetEnvironmentSettingsForCrash

	($status,$ModuleNames, $EnvNames, $EnvValues)= mdsresult_GetEnvironmentSettingsForCrash( $crashid,$iterationnumber );

Get the Environment Settings for a particular Crash from database

=head2 mdsresult_GetCrashVelocity_kmh

    ($status, $velocity_aref, $timeshift_ms) = mdsresult_GetCrashVelocity_kmh($crashid, $iterationnumber);

Retrieve the velocity involved in a particular Crash.

Incase of Single crash, $velocity_aref will contain one element,  $timeshift_ms will be 0.

Incase of Merged crash, $velocity_aref will contain two elements,  $timeshift_ms will be containing the timeshift between two crashes in ms.

=head2 mdsresult_GetCrashVelocity_X_kmh

    ($status, $velocity_X_kmh_aref) = mdsresult_GetCrashVelocity_X_kmh($crashid);

Retrieve the velocity in X direction involved in a particular Crash.

Incase of Single crash, $velocity_X_kmh_aref will contain one element.

Incase of Merged crash, $velocity_X_kmh_aref will contain two elements.

=head2 mdsresult_GetCrashVelocity_Closing_kmh

    ($status, $velocity_Closing_kmh_aref) = mdsresult_GetCrashVelocity_Closing_kmh($crashid);

Retrieve the closing velocity involved in a particular Crash.

Incase of Single crash, $velocity_Closing_kmh_aref will contain one element.

Incase of Merged crash, $velocity_Closing_kmh_aref will contain two elements.

=head2 mdsresult_GetCrashTemperature_degCelsius

    ($status, $temperature_degCelsius_aref) = mdsresult_GetCrashTemperature_degCelsius($crashid);

Retrieve the temperature involved in a particular Crash.

Incase of Single crash, $temperature_degCelsius_aref will contain one element.

Incase of Merged crash, $temperature_degCelsius_aref will contain two elements.

=head2 mdsresult_GetCrashAssignmentComment

    ($status, $CrashAssignmentComment_aref) = mdsresult_GetCrashAssignmentComment($crashid);

Retrieve the CrashAssignmentComment of Crash.

Incase of Single crash, $CrashAssignmentComment_aref will contain one element.

Incase of Merged crash, $CrashAssignmentComment_aref will contain two elements.

=head2 mdsresult_CloseResult

	$status = mdsresult_CloseResult();

Close the MDS database

=head2 mdsresult_GetErrorString

	 my $errortext = mdsresult_GetErrorString($status);

Retrieves the error text for given status

=head2 mdsresult_End

    $status = mdsresult_End();

Unloads the MDSResult Process DLL


=head1 TRACEABILITY FUNCTIONS

=head2 mdsresult_getPMrevision

    my $version;
    $version = mdsresult_getPMrevision();

returns MKS revision number of .pm file

=head2 mdsresult_getXSrevision

    my $version;
    $version = mdsresult_getXSrevision();

returns MKS revision number of .xs file

=head2 mdsresult_getCWrevision

    my $version;
    $version = mdsresult_getCWrevision();

returns MKS revision number of Interface.c file

=cut

=head1 SEE ALSO

Perl documentation

=head1 AUTHOR

G V Sriram, E<lt> VeerabhadraSriram.Grandhi@in.bosch.com E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2013  Robert Bosch GmBH

=cut

