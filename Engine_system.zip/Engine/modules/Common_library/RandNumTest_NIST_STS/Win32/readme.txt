NIST = National Institute of Standards and Technology
https://www.nist.gov/


NIST_STS.dll:             NIST Statistical Test Suite (C-code exe project provided by NIST) packaged into a DLL (C/C++)
RandNumTest_NIST_STS.dll: COM Wrapper DLL (C# Class Library) for TurboLIFT (Perl) tool adaption


More infos:
https://inside-docupedia.bosch.com/confluence/display/aeos/Random+Number+Generator+Test



RandNumTest_NIST_STS.dll API functions
--------------------------------------

	string NIST_STS_getDllInfos();
    
    int NIST_STS_SetLogFilePath(string path);

	int NIST_STS_invokeTestSuite(int[] streams, string inputFile, int streamLength_bytes, int numOfBitStreams, int[] testSelection);

/*
	Input Parameters
	streams:            One or more streams concatenated (contains bits coming as bytes to be tested).
	inputFile:          [OPTIONAL] If given, random streams are read from this file and parameter streams will be ignored
	streamLength_bytes: length of *ONE* bit stream within streams, counted as number of bytes
	numOfBitStreams:    Number of bit streams within streams
	testSelection:      index: 0, 1...15 specifies test #1 to #15
	                    0 = 0: run selected test, = 1: run all tests (index 1...15 ignored)
	                    1: Frequency
						2: Block Frequency
						3: Cumulative Sums
						4: Runs
						5: Longest Run of Ones
						6: Rank
						7: Discrete Fourier Transform
						8: Nonperiodic Template Matchings
						9: Overlapping Template Matchings
						10: Universal Statistical
						11: Approximate Entropy
						12: Random Excursions
						13: Random Excursions Variant
						14: Serial
						15: Linear Complexity
	Return = 1: success, 0: fail


	To run an internal self test, choose following input parameters

		streams[0]         = 0: array of length 1 containing one element = 0
		streamLength_bytes = 0
		numOfBitStreams    = 0
		testSelection[0]   = 0: array of length 1 containing one element = 0

	The self test requires following input files:
	data\data.e, data.pi, data.sha1, data.sqrt2, data.sqrt3
	templates\template9 (function: NonOverlappingTemplateMatchings uses per default: NonOverlapping Template Test - block length(m): 9)
*/	
	// To be called if any API function returns failed (0), instead of success (1)
	string NIST_STS_getLastErrorString();

