package ZEDGRAPH;

use strict;
use warnings;
use File::Basename;


BEGIN 
{
	use LIFT_general;
    S_add_paths2INC(['../Device_layer/ZedGraphLib',  '../Device_layer/ZedGraphLib/Win32'], ['../Device_layer/ZedGraphLib/Win32']);
}

use ZedGraphLib;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  ZED_create_graph
);

our ( $VERSION, $HEADER );

my $isInitialized = 0;
my @errors        = ();
my @COLORS        = qw(
  yellow
  blue
  aqua
  blueviolet
  darkred
  olive
  dodgerblue
  darkslategray
  skyblue
  darkgreen
  chocolate
  indigo
  goldenrod
  cadetblue
  darkcyan
  lime
  black
  crimson
  steelblue
  hotpink
  aquamarine
  darksalmon
  skyblue
  maroon
  deeppink
  firebrick
  goldenrod
  indianred
  mediumblue

);

=head1 NAME

LIFT_general 

Provide general useful functions of LIFT

=head1 SYNOPSIS

    use LIFT_ZEDGRAPH;

=cut

=head2 ZED_CreateGraph

    ZED_create_graph(($data_href, $plotfilename [, $title, $bg_colour, $curve_colors]);


    e.g.;

        ZED_create_graph($data_href, $plotfilename);

        $data_href ={
            'signal' => \@values,
        };

    e.g.
    my @time =(10,20,30);        # in millisec
    my  $data1={
       'time' => \@time,
       'val1'=> [100,200,300],
       'val2'=> [@time],
    };

    ZED_create_graph($data1,"test1.txt");

B<Background color & Curve colors:>

    (optional) $bg_colour = "steelblue"  # by default, $bg_colour is "white"

    (optional) $curve_colors = {
       'val1'=> 'yellow',
       'val2'=> 'blue',
    };

If not given, random colors will be choosen for graphing the curves.

Background color & Curve colors can be any of the below:

  aqua         aquamarine    black         blue          blueviolet       cadetblue     chocolate     crimson
  darkcyan     darkgreen     darkred       darksalmon    darkslategray    deeppink      dodgerblue    firebrick
  goldenrod    goldenrod     hotpink       indianred     indigo           lime          maroon        mediumblue
  olive        skyblue       skyblue       steelblue     white            yellow


=cut

sub ZED_create_graph
{
    my $data_href    = shift;
    my $plotfilename = shift;
    my $title        = shift;
    my $bg_colour    = shift;
    my $curve_colors = shift;

    # S_checkFunctionArguments is not called to avoid circular dependency between the modules ZEDGRAPH & LIFT_general
    unless ( defined $plotfilename )
    {
        return -1;
    }

    #replace .txt to .png
    $plotfilename =~ s/(.*?)\.txt$/$1\.png/i;

    my $status;

    if ( $isInitialized == 0 )
    {
        $status = zedgraphlib_Init();
        check_status($status);
        if ( $status >= 0 )
        {
            $isInitialized = 1;
        }
        else
        {
            return;
        }
    }

    $title     = ""      unless defined $title;
    $bg_colour = "white" unless defined $bg_colour;

    my @labels = sort keys(%$data_href);

    unless ( defined $data_href->{'time'} )
    {
        return "'time' key not defined in the given data_href : labels : @labels \n";
    }

    $status = zedgraphlib_StartGraph( "$title", "time in ms", "values"); #, $bg_colour);

    check_status($status);

    foreach my $label ( sort keys(%$data_href) )
    {
        if ( $label !~ /^time$/i )
        {
            if ( defined $data_href->{$label} )
            {
                my $curve_color = defined($curve_colors->{$label}) ? $curve_colors->{$label} : $COLORS[int(rand(scalar(@COLORS)))];
                $status = zedgraphlib_AppendPoints( $label, $data_href->{'time'}, $data_href->{$label}, "green");
                check_status($status);
            }
            else
            {
                return "'$label' key not defined in the given data_href : labels : @labels \n";
            }
        }

    }

    $status = zedgraphlib_PublishGraph($plotfilename);
    check_status($status);
    return "drawn successfully : labels : @labels \n";

}

=head1 not exported functions

=head2 check_status

 check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub check_status
{
    my $status = shift;

    if ( $status < 0 )
    {
        #  my $errortext = mftrc_GetErrorString($status);
        my $errortext = "Unknown error! create an API in ZedGraphLib to get error string";
        S_set_error( "ZedGraphLib ($status): $errortext", 5 );

    }

}

1;

__END__

=head1 AUTHOR

Arulkumar S, E<lt>Arulkumar.S@in.bosch.comE<gt>


=head1 SEE ALSO


=cut
