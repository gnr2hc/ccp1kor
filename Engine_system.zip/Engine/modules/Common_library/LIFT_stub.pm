package LIFT_stub;

use strict;
use warnings;
my $FULLPATH;

BEGIN {
    use Cwd 'abs_path';
    use File::Basename;
    $FULLPATH = abs_path( dirname(__FILE__) );
}

=head1 NAME

LIFT_stub 

Provide stub functions to use LIFT functions without LIFT engine

=head1 SYNOPSIS

  use LIFT_stub;

    STUB_init
    STUB_end

=cut

=head1 USAGE

 # use following header for your script
 # don't forget to put CFG_dummy.pm in same directory as your script and modify it according to your settings

    BEGIN
    {
        my ($Registry,$LIFT_exec_path);
        use Win32::TieRegistry ( TiedRef=>\$Registry);

        $LIFT_exec_path = $Registry->{"HKEY_CURRENT_USER\\Software\\Bosch\\LIFT\\\\EnginePath"};

        if (defined $LIFT_exec_path){
            print"$LIFT_exec_path\n";
        }
        else{
           print"EnginePath missing in registry, please install and run LIFT_engine once\n";
           exit();
        }

        # add directories to search path for LIFT modules
        unshift @INC, "$LIFT_exec_path/modules";

    }

    use strict;
    use warnings;
    use LIFT_general;
    use LIFT_stub;
    require "./CFG_dummy.pm";
    our $ProjectDefaults = $LIFT_config::LIFT_ProjectDefaults;
    our $opt_offline = 0; # $opt_offline = 1; # set offline mode
	our $opt_silent = 1; # $opt_silent = 1; # set silent mode (logging will not print)
    our $save_name; # name of log/report/result-files, given from user or Testlist will be taken
	our $CURRENT_TC = 'test';

 # one simple example

    STUB_init();
    S_user_action("hello world");
    STUB_end();


  STUB_reset() will do the following
  - set verdict back to VERDICT_NONE
  - set system state to SYS_INIT (same sates as STUB_init)
  - clear @TC_HTML_TEXT (delete HTML report content)


=cut

=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

use LIFT_general;
use File::Basename;
use Cwd 'abs_path';
use PadWalker qw(closed_over set_closed_over);
use Test::More;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

# next 2 lines edited by CVS, DO NOT MODIFY

@ISA    = qw(Exporter);
@EXPORT = qw(
  STUB_init
  STUB_end
  STUB_reset
  STUB_getFunctionVariable
  STUB_setFunctionVariable
  STUB_checkResults
  );    # export subs and constants

$LIFT_config::LIFT_exec_path = $FULLPATH;

my $logname    = 'dummy';
my $resetcount = 0;

#####################################
#####################################
## Functions in alphabetical order ##
#####################################
#####################################

=head2 STUB_init

    STUB_init();

Prepares the TurboLIFT environment for unit tests:
Defines paths, logs and sets sys and verdict state.

=cut

sub STUB_init {

    # get name of the calling function from calling stack
    my ( undef, $callingFunction ) = caller();

    $logname = basename($callingFunction);
    $logname =~ s/\./_/g;

    unless ( -d 'c:\temp\LIFT' ) {
        system('mkdir c:\temp\LIFT');
    }
    unless ( -d '.\STUBlog' ) {
        system('mkdir .\STUBlog');
    }

    S_reset_TC_time();

    # pass the html file path to S_open_log
    S_open_log("./STUBlog/$logname.html");
    S_open_result("./STUBlog/dummy");    # hack to be able to unlink not required files

    # LIFT_stub will be mostly used by .t files
    # so, setting the log path ($main::save_name) to Engine/test/log path
    $main::save_name   = "./STUBlog";
    $main::REPORT_PATH = "./STUBlog";
    $main::file_prefix_number = '0815';

    S_set_sys_state(SYS_INIT);

    S_init_LIFT_error_list("$LIFT_config::LIFT_exec_path\\LIFT_error_codes.txt");
    return 1;
}

=head2 STUB_reset

    STUB_reset();

Resets sys state, sets verdict to VERDICT_NONE and empties the html report.

=cut

sub STUB_reset {

    $SYS_STATE = SYS_INIT;
    $VERDICT   = VERDICT_NONE;

    # empty the HTML text array
    @TC_HTML_TEXT = ();
    $resetcount++;

    return 1;
}

=head2 STUB_end

    STUB_end();

Fishes and closes all TurboLIFT reports.

=cut

sub STUB_end {

    my $tc_start_text_in_html_log = <<EOHTML;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Start HTML Header -->
    <HTML><HEAD>
    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1252">
    <META NAME="Generator" CONTENT="LIFT exec engine $VERSION">
    <TITLE>LIFT dummy Testcase Report</TITLE>
    <link rel="stylesheet" href="../../htmldata/css/style.css" type="text/css" media="print, projection, screen" >
    </HEAD>
<!-- End HTML Header -->
<!-- Start HTML Body -->
<BODY DIR="LTR" BGCOLOR="#FFFFFF" > 
<div id="content">
<A NAME="TOP"></A>
<TABLE>
  <TR>
    <TD></TD>
    <TD WIDTH="100%">
      <div style="font-family:Arial; color:grey; font-size:x-large; font-weight:bold; text-align:center">LIFT dummy Testcase Report</div>
      <div style="font-family:Arial; font-weight:bold; text-align:center">created by STUB_end fucntion of LIFT_stub.pm</div>
    </TD>
    <TD></TD>
  </TR>
</TABLE>    <HR>
<div style="font-family:Arial; color:grey; font-size:x-large; text-align:center">if you don't find any content below, check if you cleared report by using STUB_reset ($resetcount x called)</div>
    <HR>
EOHTML

    ## put the header on the top of collected tc log text
    unshift( @TC_HTML_TEXT, $tc_start_text_in_html_log );

    S_w2tc_html("./STUBlog/TC_$logname.html");
    S_close_all();    # hack to be able to unlink not required files

    # hack to be able to unlink not required files:
    my $result_html = "./STUBlog/$logname.html";
    $result_html = abs_path($result_html);
    $result_html =~ s/\//\\/g;    # replace all slashes with backslahes
    unlink($result_html) or warn "couldn not remove $result_html\n";
    $result_html =~ s/$logname\.html/dummy__result.txt/g;    # replace all slashes with backslahes
    unlink($result_html) or warn "couldn not remove $result_html\n";

    return 1;
}

=head2 STUB_getFunctionVariable

    $value = STUB_getFunctionVariable( $function, $variable );

Returns the value of the variable $variable which is used in the function $function but defined outside
(i.e. package local variables).
Variables that are declared inside a function cannot be accessed.
This can be very useful to check values of package local variables in the module under test.

B<Arguments:>

=over

=item $function 

Fully qualified name ('<package>::<function>') of the function from which the variable will be read.

=item $variable 

Name of the variable which will be read, including $, @ or %. 

=back

B<Return Value:>

=over

=item $value 

Value of the variable.
If $variable is a list or a hash then the return value will be a list reference or a hash reference respectively.
Returns undef if $function is not defined or if $variable is not defined in $function.

=back

B<Examples:>

    $test_href = STUB_getFunctionVariable('LIFT_labcar::CheckAndStoreConfiguredDevice', '$configuredDevices_href'); 

=cut

sub STUB_getFunctionVariable {
    my $function = shift;
    my $variable = shift;

    # check if function exists
    return if not exists &$function;

    my $allLocalVars_href;
    {
        # get all variables from package
        no strict 'refs';
        $allLocalVars_href = closed_over( \&$function );
    }

    my $variable_ref = $allLocalVars_href->{$variable};

    # check if variable is defined
    return if not defined $variable_ref;

    # get value of variable
    my $variableValue;
    if ( ref($variable_ref) eq 'ARRAY' ) {
        @{$variableValue} = @{$variable_ref};
    }
    elsif ( ref($variable_ref) eq 'HASH' ) {
        %{$variableValue} = %{$variable_ref};
    }
    else {
        $variableValue = ${$variable_ref};
    }

    return $variableValue;
}

=head2 STUB_setFunctionVariable

    $success = STUB_setFunctionVariable( $function, $variable, $value );

Sets the value of the variable $variable which is used in the function $function but defined outside
(i.e. package local variables) to the value $value.
The variable $variable will be set in the scope of the function $function.
Variables that are declared inside a function cannot be set.
This can be very useful to modify values of package local variables in the module under test.

B<Arguments:>

=over

=item $function 

Fully qualified name ('<package>::<function>') of the function in which the variable will be set.

=item $variable 

Name of the variable which will be set, including $, @ or %. 

=item $value 

Value of the variable to be set. 
If $variable is a list or a hash then $value must be a list reference or a hash reference respectively.

=back

B<Return Value:>

=over

=item $success 

1 on success and 0 on error (if $function is not defined or if $variable is not defined in $function).

=back

B<Examples:>

    $success = STUB_setFunctionVariable('LIFT_labcar::CheckAndStoreConfiguredDevice', '$configuredDevices_href', {}); 

=cut

sub STUB_setFunctionVariable {
    my $function = shift;
    my $variable = shift;
    my $newValue = shift;

    # check if function exists
    return 0 if not exists &$function;

    my $allLocalVars_href;

    {
        # get all variables from package
        no strict 'refs';
        $allLocalVars_href = closed_over( \&$function );
    }

    my $variable_ref = $allLocalVars_href->{$variable};

    # check if variable is defined
    return 0 if not defined $variable_ref;

    # set new value for variable in $allLocalVars_href
    if ( ref($variable_ref) eq 'ARRAY' ) {
        @{$variable_ref} = @{$newValue};
    }
    elsif ( ref($variable_ref) eq 'HASH' ) {
        %{$variable_ref} = %{$newValue};
    }
    else {
        ${$variable_ref} = $newValue;
    }

    {
        # set new value for all variables in package
        no strict 'refs';
        set_closed_over( \&$function, $allLocalVars_href );
    }

    return 1;
}

=head2 STUB_checkResults

    $success = STUB_checkResults( $test, $results_href );

Checks return value and/or verdict and/or html report content against given expected values for the unit test $test.
Detected return value and all expected values are defined in $results_href, see below.
Calls internally 'is', 'is_deeply' or 'cmp_ok' to set unit test results ('ok' or 'not ok') in the Test::More framework.

B<Arguments:>

=over

=item $test 

Name of the test, just used for printout.

=item $results_href 

Hash reference with the following possible keys:

    return_detected  => <value1>,  : detected value (of the function under test)
    return_expected  => <value2>,  : expected value (of the function under test)
    verdict_expected => <verdict>, : expected verdict
    report_regex     => <regex>,   : regular expression for html report check
    coverage_info    => <string>,  : contains requirement-IDs in the form "<requirement-ID1> <requirement-ID2> ..."
                                       also design IDs could be mentioned here

If both 'return_detected' and 'return_expected' exist then their values will be compared against each other using 'is' if both are scalar 
or using 'is_deeply' otherwise.

If 'verdict_expected' is defined then its value will be checked against the current verdict.

If 'report_regex' is defined then its value will be used in S_checkTextInHtml and it will be checked that the number of matches is > 0. 

=back

B<Return Value:>

=over

=item $success 

1 on success and undef on error.

=back

B<Examples:>

    STUB_checkResults("$function -> good case", {return_detected => $result, return_expected => 1, verdict_expected => VERDICT_NONE, report_regex => 'initialized', coverage_info => 'TRS_Engine_57 TRS_Engine_58' }); 

=cut

sub STUB_checkResults {
    my @args = @_;
    unless ( S_checkFunctionArguments( 'STUB_checkResults( $test, $results_href )', @args ) ) {
        fail("Syntax error in STUB_checkResults( @args )");
        return;
    }

    my $test         = shift @args;
    my $results_href = shift @args;

    my @allowedKeys = qw(return_detected return_expected verdict_expected report_regex coverage_info);
    foreach my $resultsKey ( keys %{$results_href} ) {
        unless ( grep { $resultsKey eq $_ } @allowedKeys ) {
            fail("$test -> Unknown keyword '$resultsKey' used in STUB_checkResults, allowed keywords are: @allowedKeys");
            return;
        }
    }

    my $coverageString = '';
    if ( exists $results_href->{'coverage_info'} ) {
        my $coverageInfo = $results_href->{'coverage_info'};
        $coverageString = "-> covers requirement/design-IDs: $coverageInfo";
    }

    if ( exists $results_href->{'return_detected'} and exists $results_href->{'return_expected'} ) {
        my $return_detected = $results_href->{'return_detected'};
        my $return_expected = $results_href->{'return_expected'};
        my $ref_detected    = ref($return_detected);
        my $ref_expected    = ref($return_expected);
        if ( $ref_detected =~ /ARRAY|HASH/ or $ref_expected =~ /ARRAY|HASH/ ) {
            is_deeply( $return_detected, $return_expected, "$test -> return value check, expected: $ref_expected $coverageString" );
        }
        else {
            my $return_detected4print = $return_detected // '<undef>';
            my $return_expected4print = $return_expected // '<undef>';
            is( $return_detected, $return_expected, "$test -> return value check, detected: '$return_detected4print', expected: '$return_expected4print' $coverageString" );
        }
    }

    my $verdict_expected = $results_href->{'verdict_expected'};
    if ( defined $verdict_expected ) {
        my $verdict_detected = S_get_current_verdict();
        is( $verdict_detected, $verdict_expected, "$test -> verdict check: detected: '$verdict_detected', expected: '$verdict_expected' $coverageString" );
    }

    my $report_regex = $results_href->{'report_regex'};
    if ( defined $report_regex ) {
        my $numberOfMatches = S_checkTextInHtml($report_regex);
        cmp_ok( $numberOfMatches, '>', 0, "$test -> expected report output: expression '$report_regex' matched $numberOfMatches time(s) $coverageString" );
    }

    return 1;
}

1;

