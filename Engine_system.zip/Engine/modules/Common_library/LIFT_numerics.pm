#*****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_numerics;

=head1 NAME

LIFT_numerics 

Provides numeric functions

=head1 SYNOPSIS

  use LIFT_numerics;

    $iVal = NUM_round2Int($dblVal);
    $retVals_href = NUM_downsampleInactiveRegions( $args_href );
    $retVals_href = NUM_ResampleData( $args_href );
    $integer = NUM_ListOfBytes2Integer( $listOfBytes_aref, $type );
    $listOfBytes_aref = NUM_Integer2ListOfBytes( $integer, $type );
    $unsignedInt = NUM_SignedInt2UnsignedInt( $signedInt, $numRelevantBits );
    $signedInt = NUM_UnsignedInt2SignedInt( $unsignedInt, $numRelevantBits );
    $random_value = NUM_RandomNumber( $value_max, $options_href );

=head1 DESCRIPTION

This is a library of numerical processing functions

=cut

use strict;
use warnings;
use LIFT_general;
use Readonly;
use Math::BigFloat;
use POSIX;
use LIFT_stringProcessing;    #This we need only for converting list of unsigned int to list of Hex
use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

@ISA    = qw(Exporter);
@EXPORT = qw(
  NUM_round2Int
  NUM_downsampleInactiveRegions
  NUM_ResampleData
  NUM_ListOfBytes2Integer
  NUM_UnsignedInt2SignedInt
  NUM_Integer2ListOfBytes
  NUM_SignedInt2UnsignedInt
  NUM_RandomNumber
  $NUM_SYS_INT_MAX
  $NUM_SYS_INT_MIN
  $NUM_INT16_MIN
  $NUM_INT16_MAX
  $NUM_EPSILON_1E_MINUS_6
  );    # export subs and constants

###----------------------------------------------------------------------------

Readonly our $NUM_INT16_MAX => 0x7FFF;
Readonly our $NUM_INT16_MIN => ( -$NUM_INT16_MAX - 1 );

Readonly our $NUM_SYS_INT_MAX        => ~0 >> 1;
Readonly our $NUM_SYS_INT_MIN        => -$NUM_SYS_INT_MAX - 1;
Readonly our $NUM_EPSILON_1E_MINUS_6 => 0.000001;

Readonly my $NUM_ROUND_THRESHOLD => 0.5;
Readonly my $NUM_ERR_CODE_1      => -1;
Readonly my $NUM_ERR_CODE_2      => -2;

=head2 NUM_round2Int

 Function Name   : NUM_round2Int

 Description     : Rounds floating point value to integer

 Syntax          : $iVal = NUM_round2Int($dblVal)

 Input Arguments : $dblVal = floating point value

 Return Value(s) : $iVal   = �nteger value

 Example         : 5 = NUM_round2Int(4.5);

=cut

sub NUM_round2Int {
    my $dblVal = shift;

    my $roundedInt = 0;

    # Round double value to integer
    if ( $dblVal >= 0.0 ) {
        $dblVal += $NUM_ROUND_THRESHOLD;
    }
    else {
        $dblVal -= $NUM_ROUND_THRESHOLD;
    }

    # If necessary, limit it to interval [$intMin, $intMax]
    if ( $dblVal > $NUM_SYS_INT_MAX ) {
        $dblVal = $NUM_SYS_INT_MAX;
    }
    elsif ( $dblVal < $NUM_SYS_INT_MIN ) {
        $dblVal = $NUM_SYS_INT_MIN;
    }

    $roundedInt = int($dblVal);

    return $roundedInt;
}

=head2 NUM_downsampleInactiveRegions

    Syntax : ( $retVals_href ) = NUM_downsampleInactiveRegions( $args_href );

Downsamples Inactive Regions. Inactive regions are

    (1) regions with constant values (no signal change) or

    (2) inactive values (signal value equal to 'inactiveValue').

The method (1) or (2) is chosen by optional parameter inactiveValue passed or not.
Downsampling means, that the number of points from input array is reduced by the
factor (dtFast_s / dtSlow_s) in output array, using linear interpolation.

Input arguments :

   $args_href = {
      'dtSlow_s'               => $dtSlow_s,               # slow cycle time in seconds
      'dtSlowResolution_s'     => $dtSlowResolution_s,     # OPTIONAL: Minimum resolution of dtSlow_s
                                                           # (choose a value, which avoids integer
                                                           # overflow in fraction
                                                           # dtSlow_s / dtSlowResolution_s
                                                           #      < $INT_MAX = 2147483647)
                                                           # and take care dtOut_sec >> dtResolution_sec
                                                           # DEFAULT, if omitted: $dtSlow_s / (INT_MAX-1)
      'dtFast_s'               => $dtFast_s,               # fast input cycle time in seconds
      'inactiveValue'          => $inactiveValue,          # OPTIONAL: Inactive value (type: floating point)
                                                           # if not defined: Downsample all constant regions
                                                           # if defined:     Downsample only inactive regions
                                                           #                 equal to inactiveValue
      'numRepetitionsOnChange' => $numRepetitionsOnChange, # OPTIONAL: number of repetitions of changed value
      'dataInValues_aref'      => $dataInValues_aref,      # input data (type: floating point), which has to
                                                           # be resampled (time base: equidistant as dtFast_s)
      }

Calling function :

    NUM_ResampleData (\@inactiveRegion, $dtFast_s, $dtSlowResolution_s, $dtSlow_s)

Return values :

    success : $retVals_href
    
    error : 0

Example (success) :

   $retVals_href  = {
      'dataOutValues_aref'  => [],                  # type: floating point
      'dataOutTimes_aref'   => [],                  # type: floating point 
      'anyModificationDone' => 0|>0                 #  0: no modification
                                                    # >0: downsampling was necessary and done
                                                    #     (= number of output points)
      }

Example Use Case: Switchable cycle times on bus

    Crash-DB signal (fixed cycle), which has to be adapted to a bus signal with switchable cycle time

    Goal: Downsample all constant regions, without repetition on change

    Signal input array (contains three const. regions: zeros, eights, zeros and two ramps):

    const.    ramp-up  const.  ramp-down  const.
    00000000001234567888888888876543210000000000�<- IN

    Signal output array (3 constant regions downsampled to reduced number of points):
          
    0 0 0 0 0 12345678 8 8 8 8 76543210 0 0 0 0  <- OUT (array formatted here with spaces)

    in:  equidistant samples with fast cycle time
    out: bus signal (flexible cycletime, rebuilt by RBS-time scheduler through event-driven timing)

    my $retVals_href = NUM_downsampleInactiveRegions(
        {
        'dtSlow_s'           => 20E-3,
        'dtSlowResolution_s' => 1E-6,
        'dtFast_s'           => 10E-3,
        'dataInValues_aref'  =>
             [0,0,0,0,0,0,0,0,0,0,1,2,3,4,5,6,7,8,8,8,8,8,8,8,8,8,8,7,6,5,4,3,2,1,0,0,0,0,0,0,0,0,0,0],
        }
    );

    Expected output 'dataOutValues_aref' (formatted with spaces, to show relation to input signal):
           [0,  0,  0,  0,  0,  1,2,3,4,5,6,7,8,  8,  8,  8,  8,  7,6,5,4,3,2,1,0,  0,  0,  0,  0];
    Expected output 'dataOutTimes_aref'
           [0.0,0.02,0.04,0.06,0.08,0.09,0.10,0.11,0.12,0.13,0.14,0.15,0.16,0.18,0.20,0.22,0.24,0.25,
                0.26,0.27,0.28,0.29,0.30,0.31,0.32,0.34,0.36,0.38,0.40],
                
    Expected return in 'anyModificationDone' is 29 for numPts in dataOutValues_aref

=cut

sub NUM_downsampleInactiveRegions {

    my @args = @_;

    return 0 unless S_checkFunctionArguments( 'NUM_downsampleInactiveRegions( $args_href )', @args );

    my $inArgs_href = shift;
    my %retVals_href;

    # hash defines the set of valid keys
    my $valid_in_arg_keys = {
        'dtSlow_s'               => 1,
        'dtSlowResolution_s'     => 1,
        'dtFast_s'               => 1,
        'inactiveValue'          => 1,
        'numRepetitionsOnChange' => 1,
        'dataInValues_aref'      => 1
    };
    my $mandatory_keys = {
        'dtSlow_s'          => 1,
        'dtFast_s'          => 1,
        'dataInValues_aref' => 1
    };

    return 0 unless S_checkFunctionArgumentHashKeys( "NUM_downsampleInactiveRegions", $inArgs_href, $valid_in_arg_keys, $mandatory_keys );

    my $dtSlow_s               = $inArgs_href->{'dtSlow_s'};
    my $dtSlowResolution_s     = $inArgs_href->{'dtSlowResolution_s'};
    my $dtFast_s               = $inArgs_href->{'dtFast_s'};
    my $inactiveValue          = $inArgs_href->{'inactiveValue'};
    my $inactiveValueValid     = 0;
    my $numRepetitionsOnChange = $inArgs_href->{'numRepetitionsOnChange'};
    my $dataInValues_aref      = $inArgs_href->{'dataInValues_aref'};

    if ( defined $inactiveValue ) { $inactiveValueValid = 1; }
    if ( not defined $numRepetitionsOnChange ) { $numRepetitionsOnChange = 0; }
    if ( not defined $dtSlowResolution_s ) { $dtSlowResolution_s = $dtSlow_s / ( $NUM_SYS_INT_MAX - 1 ); }

    my $numPtsIn = scalar(@$dataInValues_aref);
    my $status;     # return parameter 1
    my @dataOut;    # return parameter 2
    my @timeOut;    # return parameter 3
    my $indexOut                 = $NUM_ERR_CODE_1;    # index in @dataOut
    my $anyModificationDone      = 0;
    my $lastPointIsOfActiveState = 0;
    my $firstActiveStateIndex    = $NUM_ERR_CODE_1;
    my @dataInCopy               = ();
    my @inactiveRegion           = ();
    my $numPtsInactiveRegion     = 0;

    my $dtOut_sec;
    my $compareValue;

    # Create copy of input buffer with one more point, since collecting in inactiveRegion ("collecting" buffer) is one point behind
    @dataInCopy = @$dataInValues_aref;
    $dataInCopy[$numPtsIn] = $$dataInValues_aref[ $numPtsIn - 1 ];

    # Initialize comparison value (in case of !iInactiveValueValid)
    $inactiveRegion[0] = $dataInCopy[0];

    # loop intentionally runs over $numPtsIn + 1 values!
    foreach my $indexIn ( 0 .. $numPtsIn ) {
        my $flagInactiveRegionBufferAppended = 0;
        if   ($inactiveValueValid) { $compareValue = $inactiveValue; }
        else                       { $compareValue = $inactiveRegion[0]; }

        # Next point changed to ACTIVE state (*UNEQUAL* to current @inactiveRegion buffer values) OR end of array
        if ( abs( $dataInCopy[$indexIn] - $compareValue ) > $NUM_EPSILON_1E_MINUS_6 || $indexIn == $numPtsIn ) {
            $firstActiveStateIndex = $indexIn;

            # Process collected @inactiveRegion buffer
            if ( $numPtsInactiveRegion > 1 ) {
                $status = DownsampleInactiveRegion(
                    {
                        'inactiveRegion_aref'                  => \@inactiveRegion,
                        'dtFast_s'                             => $dtFast_s,
                        'dtSlow_s'                             => $dtSlow_s,
                        'dtSlowResolution_s'                   => $dtSlowResolution_s,
                        'indexOut_ref'                         => \$indexOut,
                        'dataOut_aref'                         => \@dataOut,
                        'timeOut_aref'                         => \@timeOut,
                        'flagInactiveRegionBufferAppended_ref' => \$flagInactiveRegionBufferAppended,
                        'anyModificationDone_ref'              => \$anyModificationDone
                    }
                );
                if ( $status == 0 ) { return 0; }    # Error already handled inside previous function
            }

            # @inactiveRegion buffer re-sampling skipped => direct copy to out-buffer
            if ( !$flagInactiveRegionBufferAppended ) {
                foreach my $i ( 0 .. $numPtsInactiveRegion - 1 ) {
                    $indexOut++;
                    $dataOut[$indexOut] = $inactiveRegion[$i];
                    $timeOut[$indexOut] = $indexOut > 0 ? $timeOut[ $indexOut - 1 ] + $dtFast_s : 0;
                }
            }

            # Start new @inactiveRegion buffer with this new ACTIVE point
            $numPtsInactiveRegion = 1;
            if ( $numPtsInactiveRegion + $numRepetitionsOnChange < scalar(@inactiveRegion) ) {
                splice @inactiveRegion, ( $numPtsInactiveRegion + $numRepetitionsOnChange );    # reduce array
            }
            $inactiveRegion[0] = $dataInCopy[$indexIn];
            $lastPointIsOfActiveState = 1;

            # Option: numRepetitionsOnChange
            if ( $numRepetitionsOnChange > 0 && $firstActiveStateIndex < $numPtsIn ) {
                $anyModificationDone = 1;
                foreach ( 0 .. $numRepetitionsOnChange - 1 ) {
                    $indexOut++;
                    $dataOut[$indexOut] = $dataInCopy[$indexIn];                                       # Add this new active point repeatedly to output buffer
                    $timeOut[$indexOut] = $indexOut > 0 ? $timeOut[ $indexOut - 1 ] + $dtFast_s : 0;
                }
            }
        }

        # Next point to be put into INACTIVE buffer values in @inactiveRegion
        else {
            # If last point was active, move it directly to out buffer and restart @inactiveRegion buffer
            if ( $inactiveValueValid && $lastPointIsOfActiveState ) {
                $indexOut++;
                $dataOut[$indexOut]   = $inactiveRegion[0];
                $timeOut[$indexOut]   = $indexOut > 0 ? $timeOut[ $indexOut - 1 ] + $dtFast_s : 0;
                $numPtsInactiveRegion = 0;
            }
            $numPtsInactiveRegion++;
            if ( $numPtsInactiveRegion < scalar(@inactiveRegion) ) {
                splice @inactiveRegion, $numPtsInactiveRegion;    # reduce array
            }
            $inactiveRegion[ $numPtsInactiveRegion - 1 ] = $dataInCopy[$indexIn];
            $lastPointIsOfActiveState = 0;
        }
    }
    my $numPtsOut = $indexOut + 1;

    if   ($anyModificationDone) { $status = $numPtsOut; }
    else                        { $status = 0; }

    $retVals_href{'anyModificationDone'} = $status;
    $retVals_href{'dataOutValues_aref'}  = \@dataOut;
    $retVals_href{'dataOutTimes_aref'}   = \@timeOut;

    return ( \%retVals_href );
}

=head2 NUM_ResampleData

Resamples the data to required cycle time, using linear interpolation.

    Syntax : $retVals_href = NUM_ResampleData( $args_href )

Input Arguments :

   $args_href = {
        'dataIn_aref'      =>  $dataIn_aref,      # input data, to be resampled (type: floating point)
        'dtIn_sec'         =>  $dtIn_sec,         # input cycle
        'dtOut_sec'        =>  $dtOut_sec,        # desired output cycle,
        'dtResolution_sec' =>  $dtResolution_sec, # OPTION: Used for adapting the resolution of dtOut_sec,
                                                  # if it is required to have a defined output rate resolution.
                                                  # Choose a value, which avoids integer overflow in fraction
                                                  # dtOut_sec / dtResolution_sec < INT_MAX(=2147483647)
                                                  # and take care dtOut_sec > dtResolution_sec
                                                  # (the smaller, against dtOut_sec, the better;
                                                  # typically used examples: 1E-6, 1E-9, 1E-12)
                                                  # DEFAULT, if omitted: dtOut_sec / (INT_MAX-1)
                                                  # (-1 avoids rounding effects at the border value)
   }

Return values :

   $retVals_href  = {
       'status'       => $status,    # -1: Error with input argument args_href
                                     # -2: Integer overflow, try different dtResolution_sec,
                                     #     which is closer to dtOut_sec
                                     #  0: no re-sampling done, because unnecessary
                                     #  1: re-sampling done
       'dataOutValues_aref' => [],   # Array reference to resampled data (type: floating point)
       'dataOutTimes_aref'  => []    # Array reference to new time values (type: floating point)
   }

Example (success) :

    # Doubles the sampling rate
    $retVals_href = NUM_ResampleData(
                                        {
                                        'dataIn_aref'        => [1, 2, 3, 4, 5], 
                                        'dtIn_sec'           => 2.4,
                                        'dtOut_sec'          => 1.2,
                                        'dtResolution_sec'   => 0.1,
                                        }
    );

    $retVals_href = {
        'status'             => 1,
        'dataOutValues_aref' => [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.0]
        'dataOutTimes_aref'  => [0.0, 1.2, 2.4, 3.6, 4.8, 6.0, 7.2, 8.4, 9.6, 10.8]
    }

Return values (error) :

    $retVals_href = 0 : Error with keys inside argument hash (wrong keys listed in error message in report)

    $retVals_href->{'status'} = -1 : Error with input argument 'args_href' itself

    $retVals_href->{'status'} = -2 : 'dtResolution_sec' out of range: [dtOut_sec / (INT_MAX-1) ... dtOut_sec].

=cut

sub NUM_ResampleData {
    my @args = @_;
    my %retVals_href;

    unless ( S_checkFunctionArguments( 'NUM_ResampleData( $args_href )', @args ) ) {
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    my $inArgs_href = shift;

    # hash defines the set of valid keys
    my $valid_in_arg_keys = {
        'dataIn_aref'      => 1,
        'dtIn_sec'         => 1,
        'dtOut_sec'        => 1,
        'dtResolution_sec' => 1
    };
    my $mandatory_keys = {
        'dataIn_aref' => 1,
        'dtIn_sec'    => 1,
        'dtOut_sec'   => 1
    };

    return 0 unless S_checkFunctionArgumentHashKeys( "NUM_ResampleData", $inArgs_href, $valid_in_arg_keys, $mandatory_keys );

    my $dataIn_aref      = $inArgs_href->{'dataIn_aref'};         # signal data to sample array reference
    my $dtIn_sec         = $inArgs_href->{'dtIn_sec'};            # cycle_time data in
    my $dtResolution_sec = $inArgs_href->{'dtResolution_sec'};    # min resolution
    my $dtOut_sec        = $inArgs_href->{'dtOut_sec'};           # cycle time data out
    my $status           = $NUM_ERR_CODE_1;
    my ( $resampleFactor, $quotient, $delta, $dtOutInMinResolution_sec, @dataOut, $numPtsOut, $numPtsIn );

    unless ( ref $dataIn_aref eq "ARRAY" ) {
        S_set_error( "dataIn_aref is not an array reference \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    $numPtsIn = scalar(@$dataIn_aref);
    if ( $numPtsIn <= 0 ) {
        S_set_error( "dataIn_aref is an empty array reference \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    if ( $dtIn_sec <= 0 ) {
        S_set_error( "dtIn_sec should be greater than zero \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    if ( not defined $dtResolution_sec ) { $dtResolution_sec = $dtOut_sec / ( $NUM_SYS_INT_MAX - 1 ); }

    if ( $dtResolution_sec <= 0 ) {
        S_set_error( "dtResolution_sec should be greater than zero \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    S_w2log( 3, " NUM_ResampleData : No of points $numPtsIn \n" );

    $quotient = $dtOut_sec / $dtResolution_sec;

    if ( $quotient < 1 || $quotient > $NUM_SYS_INT_MAX ) {
        my $minRes = $dtOut_sec / ( $NUM_SYS_INT_MAX - 1 );
        S_set_error( "dtResolution_sec = $dtResolution_sec s out of allowed range: [$minRes s ... $dtOut_sec s], see hint in API documentation \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_2;
        return ( \%retVals_href );
    }

    $quotient = NUM_round2Int($quotient);

    $dtOutInMinResolution_sec = $quotient * $dtResolution_sec;
    $resampleFactor           = $dtOutInMinResolution_sec / $dtIn_sec;
    $delta                    = abs( $resampleFactor - 1.0 );

    if ( $delta > $NUM_EPSILON_1E_MINUS_6 ) {
        $status    = 1;                                              #re-sampling necessary
        $numPtsOut = NUM_round2Int( $numPtsIn / $resampleFactor );
    }
    else {
        $status = 0;                                                 #re-sampling unnecessary
    }

    if ( $status == 1 ) {
        foreach my $i ( 0 .. $numPtsOut - 1 ) {

            #Calculate next x0, x, x1, based on next index and re-sampling factor
            #Converted x-position used as basis to calculate the re-sampled curve
            my $x  = $i * $resampleFactor;
            my $x0 = int($x);                #integral value (index) left from x
            my $x1 = $x0 + 1;                #integral value (index) right from x

            #if x0 and x1 are both within pdDataIn
            if ( $x1 < $numPtsIn ) {

                #Calculate output curve from input curve by linear interpolation
                $dataOut[$i] = $$dataIn_aref[$x0] + ( $x - $x0 ) * ( $$dataIn_aref[$x1] - $$dataIn_aref[$x0] );
            }
            elsif ( $x0 < $numPtsIn ) {
                $dataOut[$i] = $$dataIn_aref[$x0];
            }
        }

        # Last point in output and input shall be identical
        $delta = abs( $dataOut[-1] - $$dataIn_aref[-1] );
        if ( $delta > $NUM_EPSILON_1E_MINUS_6 ) {
            $dataOut[-1] = $$dataIn_aref[-1];
        }
    }
    else {
        @dataOut = @$dataIn_aref;    # output = Input  as no re-sampling needed
        S_w2log( 3, " NUM_ResampleData: As no re-sampling needed Output data is same as Input data\n" );
    }

    my @timeOut_s;
    foreach my $i ( 0 .. scalar(@dataOut) - 1 ) {
        $timeOut_s[$i] = $i * $dtOutInMinResolution_sec;
    }

    $retVals_href{'status'}             = $status;
    $retVals_href{'dataOutValues_aref'} = \@dataOut;
    $retVals_href{'dataOutTimes_aref'}  = \@timeOut_s;

    return ( \%retVals_href );
}

# Internal functions, which are not exported

sub DownsampleInactiveRegion {
    my $inArgs_href = shift;

    my $inactiveRegion_aref                  = $inArgs_href->{'inactiveRegion_aref'};
    my $dtFast_s                             = $inArgs_href->{'dtFast_s'};
    my $dtSlow_s                             = $inArgs_href->{'dtSlow_s'};
    my $dtSlowResolution_s                   = $inArgs_href->{'dtSlowResolution_s'};
    my $indexOut_ref                         = $inArgs_href->{'indexOut_ref'};
    my $dataOut_aref                         = $inArgs_href->{'dataOut_aref'};
    my $timeOut_aref                         = $inArgs_href->{'timeOut_aref'};
    my $flagInactiveRegionBufferAppended_ref = $inArgs_href->{'flagInactiveRegionBufferAppended_ref'};
    my $anyModificationDone_ref              = $inArgs_href->{'anyModificationDone_ref'};

    my $status;

    # Resample @inactiveRegion
    my ( $inactiveRegionDownsampled_aref, $resample_ret_vals_href );
    $resample_ret_vals_href = NUM_ResampleData(
        {
            'dataIn_aref'      => $inactiveRegion_aref,
            'dtIn_sec'         => $dtFast_s,
            'dtOut_sec'        => $dtSlow_s,
            'dtResolution_sec' => $dtSlowResolution_s,
        }
    );
    $status                         = $resample_ret_vals_href->{'status'};
    $inactiveRegionDownsampled_aref = $resample_ret_vals_href->{'dataOutValues_aref'};
    if ( $status < 0 ) {
        S_set_error( "NUM_ResampleData failed, check input parameters and any previous error messages \n", 114 );
        return 0;
    }

    # if resampling was necessary and done
    if ( $status == 1 ) {

        # Append $inactiveRegionDownsampled_aref to @dataOut
        my $numPts                  = scalar(@$inactiveRegionDownsampled_aref);
        my $dtSlowInNewResolution_s = $resample_ret_vals_href->{'dataOutTimes_aref'}->[1];
        $$indexOut_ref++;

        # first point of inactive region still with fast cycle
        $$dataOut_aref[$$indexOut_ref] = $$inactiveRegionDownsampled_aref[0];
        $$timeOut_aref[$$indexOut_ref] = $$indexOut_ref > 0 ? $$timeOut_aref[ $$indexOut_ref - 1 ] + $dtFast_s : 0;

        # rest of points of inactive region in slow cycle
        foreach my $i ( 1 .. $numPts - 1 ) {
            $$indexOut_ref++;
            $$dataOut_aref[$$indexOut_ref] = $$inactiveRegionDownsampled_aref[$i];
            $$timeOut_aref[$$indexOut_ref] = $$timeOut_aref[ $$indexOut_ref - 1 ] + $dtSlowInNewResolution_s;
        }
        undef(@$inactiveRegionDownsampled_aref);    # free array
        $$flagInactiveRegionBufferAppended_ref = 1;
        $$anyModificationDone_ref              = 1;
    }
    return 1;
}

=head2 NUM_ListOfBytes2Integer

    $integer = NUM_ListOfBytes2Integer( $listOfBytes_aref, $type );
    
B<Arguments:>

=over

=item $listOfBytes_aref

- Array of integer bytes which needs to converted to an integer

- Each element of $listOfBytes_aref must be an integer (0-255)

=item $type

- Type of integer that needs to be converted

- $type can be =~ [USB]\d+, U(unsigned), S(signed) or B(boolean)followed by number of bits. ex: U8,S8,B8.. etc

- Default is 'U8'

=back

B<Return Values:>

=over

=item $integer

- On success, Returns Integer obtained from array of bytes. undef otherwise

- $integer is either a scalar for types up to 32 bit(S32|U32|B32), or a Math::BigFloat object for types > 32 bit

=back

B<Examples:>
    
    $integer = NUM_ListOfBytes2Integer([3,227,143], 'U32'); #Returns 254863
    
    $integer = NUM_ListOfBytes2Integer([3,227,143], 'B32'); #Returns 254863
    
    $integer = NUM_ListOfBytes2Integer([3,227,143], 'U16'); #Returns undef, Throws an error as number of bytes exceeds actual number of bytes
    
    $integer = NUM_ListOfBytes2Integer(  [ 247, 255, 255, 255, 255, 197, 43, 9 ], 'S64' ); #returns Math::BigFloat object with value -576460752307279095
    
=cut

sub NUM_ListOfBytes2Integer {
    my @args = @_;
    S_checkFunctionArguments( 'NUM_ListOfBytes2Integer(  $listOfBytes_aref, $type  )', @args ) or return;

    my $listOfBytes_aref = shift();
    my $type             = shift();

    $type = 'U8' unless ( defined $type );

    my ( $dataType, $nbrOfBits, $nbrOfBytes );
    if ( $type =~ /^([usb])(\d+)$/i ) {
        ( $dataType, $nbrOfBits, $nbrOfBytes ) = ( $1, $2, ceil( $2 / 8 ) );
    }
    else {
        S_set_error( "NUM_ListOfBytes2Integer : Invalid type = '$type'. Please specify in the format of [S|U|B][0-9]+ \n", 114 );
        return;
    }

    if ( grep { !/^\d+$/ } @$listOfBytes_aref ) {
        S_set_error( "NUM_ListOfBytes2Integer : One or more Invalid elements! Please provide only Integer bytes(\\d+) as the elements of \$listOfBytes_aref", 114 );
        return;
    }

    if ( scalar(@$listOfBytes_aref) > $nbrOfBytes ) {
        S_set_error( "NUM_ListOfBytes2Integer : Number of bytes provided in \$listOfBytes_aref (" . scalar(@$listOfBytes_aref) . ") > $nbrOfBytes (actual number of bytes. Type:$type) ", 114 );
        return;
    }

    foreach my $byte (@$listOfBytes_aref) {
        if ( $byte < 0 or $byte > 255 ) {
            S_set_error( "NUM_ListOfBytes2Integer : Invalid Byte value '$byte'. Please specify value within the range 0-255", 114 );
            return;
        }
    }

    my $hexstr_arr = STR_ListOfUnsignedIntegers2ListOfHexStrings( $listOfBytes_aref, { prefix0x => 0 } );

    my $hexstring = join( '', @$hexstr_arr );

    my $integer;

    # If the numberof bits > 32, Use Math::BigFloat
    if ( $nbrOfBits > 32 ) {

        #Note: Math::BigFloat->from_hex() creates Math::BigInt object. So create BigFloat object out of it
        $integer = Math::BigFloat->from_hex($hexstring);
        $integer = Math::BigFloat->new($integer);
    }
    else {
        $integer = hex($hexstring);
    }

    #calculate signed integer from the unsigned integer
    $integer = NUM_UnsignedInt2SignedInt( $integer, $nbrOfBits ) if ( lc($dataType) eq 's' );

    ValidateSignedOrUnsignedIntegerRange( $integer, $type ) or return;

    return $integer;
}

=head2 NUM_UnsignedInt2SignedInt

    $signedInt = NUM_UnsignedInt2SignedInt( $unsignedInt, $numRelevantBits );
    
Converts unsigned integer to signed integer
    
B<Arguments:>

=over

=item $unsignedInt

- Unsigned Integer which needs to be converted to Signed integer

- If the integer is more than 32 bit long, it MUST be quoted. ex: '1152921504716710707'.

- $unsignedInt can be specified in the form of Unsigned Int|Hex(must be prefixed with 0x)|an object of Math::BigInt or Math::BigFloat

=item $numRelevantBits

- Number of relevent bits based on which signed number is calculated

=back

B<Return Values:>

=over

=item $signedInt

- Signed equivalent of given Unsigned integer

- If the given integer is more than 32 bit long, SignedInteger will be an object of 'Math::BigFloat'

=back

B<Examples:>
    
    $signedInt = NUM_UnsignedInt2SignedInt( '655535' , 16 ) #Returns -1
    
    $signedInt = NUM_UnsignedInt2SignedInt( 251 , 8 ) #Returns -5
    
    $signedInt = NUM_UnsignedInt2SignedInt( '245122235104702' , 48 ) #Returns Math::BigFloat object with value  -36352741605954
    
    $signedInt = NUM_UnsignedInt2SignedInt( '18446744073709551615' , 64 ) #Returns -1
    
    $signedInt = NUM_UnsignedInt2SignedInt( '6255499882484729856', 63 ); #Returns Math::BigFloat object with value  -2967872154370045952
    
    $signedInt = NUM_UnsignedInt2SignedInt( '0xFFFFFFFF', 32 ); #Returns -1
    
    $signedInt = NUM_UnsignedInt2SignedInt( Math::BigFloat->new(0xFFFFFFFB), 32 ); #returns -5
    
    $signedInt = NUM_UnsignedInt2SignedInt( Math::BigInt->new(0xFFFFFFFA), 32 ); #returns -6

=cut

sub NUM_UnsignedInt2SignedInt {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NUM_UnsignedInt2SignedInt( $unsignedInt, $numRelevantBits )', @args );
    my $unsignedInt     = shift;
    my $numRelevantBits = shift;

    #Validate the input. Can be integer or hex(prefixed with 0x)
    unless ( $unsignedInt =~ /^(\d+|(0x)[0-9A-F]+)$/i ) {
        S_set_error( "NUM_UnsignedInt2SignedInt : Invalid input \$unsignedInt. It can be an Unsigned integer(\\d+),Hex((0x)[0-9A-F]+) ", 114 );
        return;
    }
    ValidateSignedOrUnsignedIntegerRange( $unsignedInt, 'U' . $numRelevantBits ) or return;

    # convert unsigned int to BigInt to be able to handle 32 bit and higher properly
    my $bunsignedInt = Math::BigInt->new($unsignedInt);

    # calculate the number that has only the MSB set (e.g. 0b10000000)
    my $msbMask = Math::BigInt->bone() << ( $numRelevantBits - 1 );
    my $signedInt;
    if ( $bunsignedInt & $msbMask ) {

        # if MSB is set then calculate the corresponding negative value by
        # reversing all bits
        $bunsignedInt->bnot();

        # adding 1
        $signedInt = $bunsignedInt + 1;

        # calculate maximum unsigned integer possible with the given number of bits (e.g. 0b11111111)
        my $maxUnsignedInt = ( Math::BigInt->bone() << $numRelevantBits ) - 1;

        # masking with the maximum unsigned integer
        $signedInt &= $maxUnsignedInt;

        # and multiplying with -1
        $signedInt *= -1;
    }
    else {
        # if MSB is not set then leave the number unchanged
        $signedInt = $bunsignedInt;
    }

    # convert the BigInt to a normal scalar
    my $signedReturn = $signedInt->bstr();

    # if more than 32 bits: convert into a BigFloat to be able to continue calculations with the value afterwards
    if ( $numRelevantBits > 32 ) {
        $signedReturn = Math::BigFloat->new($signedReturn);
    }

    return $signedReturn;
}

=head2 NUM_Integer2ListOfBytes

    $listOfBytes_aref = NUM_Integer2ListOfBytes( $integer, $type );
    
Converts integer to list of bytes
    
B<Arguments:>

=over

=item $integer

- Integer which needs to be converted to list of bytes

- If the integer is having > 32 bits, It MUST be specified as quoted. ex:'9007199254741247'. Else it may result in wrong value!

=item $type

- Type of $integer based on which the array of bytes needs to be calculated.

- $type can be =~ [US]\d+, U(unsigned), S(signed) or B(boolean) followed by number of bits. ex: U8,S8,B8... etc

- Default is 'U8'

=back

B<Return Values:>

=over

=item $listOfBytes_aref

- List of integer bytes calculated from the given integer

=back

B<Examples:>

    [ 0, 3, 227, 143 ] = NUM_Integer2ListOfBytes( 254863, 'U32' );
    
    [ 0, 3, 227, 143 ] = NUM_Integer2ListOfBytes( 254863, 'B32' );
    
    [ 255, 255, 241, 174 ] = NUM_Integer2ListOfBytes( -3666, 'S32' );
    
    [ 247, 255, 255, 255, 255, 197, 43, 9 ] = NUM_Integer2ListOfBytes( '-576460752307279095', 'S64' );
    
    [ 211, 65 ] = NUM_Integer2ListOfBytes( -11455, 'S16' );
    
    [ 251 ] = NUM_Integer2ListOfBytes( -5, 'S8' );

B<Notes:>

    Converting Integer to array ref of integer databytes
    
     Ex: Int = 555
         Convert it to hex
         555 => 02 2B
         Convert each byte of hex to integer
         02 => 02 , 2B => 43
         Build an array of bytes
         [ 02, 43]
   
=cut

sub NUM_Integer2ListOfBytes {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NUM_Integer2ListOfBytes( $integer, $type )', @args );
    my $integer = shift;
    my $type    = shift;

    $type = 'U8' unless ( defined $type );

    unless ( $integer =~ /^[+|-]?\d+$/ ) {
        S_set_error( " NUM_Integer2ListOfBytes : Invalid integer '$integer'. Please provide only valid Integer", 109 );
        return;
    }

    my ( $dataType, $nbrOfBits, $nbrOfBytes );
    if ( $type =~ /^([usb])(\d+)$/i ) {
        ( $dataType, $nbrOfBits, $nbrOfBytes ) = ( $1, $2, ceil( $2 / 8 ) );
    }
    else {
        S_set_error( "NUM_Integer2ListOfBytes : Invalid type = '$type'. Please specify in the format of [S|U|B][0-9]+ \n", 114 );
        return;
    }

    if ( $integer =~ /^-/ && $dataType =~ /U|B/i ) {
        S_set_error( " NUM_Integer2ListOfBytes : Invalid integer '$integer'. Negative integer not supported for type '$type'\n", 109 );
        return;
    }

    ValidateSignedOrUnsignedIntegerRange( $integer, $type ) or return;

    #convert signed to unsigned integer. as negative integer -> hex may result in getting negative hex value
    if ( $integer =~ /^-/ ) {
        $integer = NUM_SignedInt2UnsignedInt( $integer, $nbrOfBits );
    }

    #create a bigInt object using integer given
    #using BigInt as BigFloat didnt give the expected hex value. ex: 17870283321402272521(dec) -> 0xF7FFFFFFFFC52B09(expected), 0xf7ffffffffc52b09(obtained using BigFloat)
    my $binteger = Math::BigInt->new($integer);

    #get the hex value
    my $hexStr = $binteger->as_hex();

    #Remove the leading '0x'
    $hexStr =~ s/^0x//;

    #If the address is not in equal chunks of 2 characters, add prefix with 0 at the start. ( i.e. 22B => 022B )
    $hexStr = '0' . $hexStr unless ( length($hexStr) % 2 == 0 );

    #create an array out of hex value
    my @hexStr_arr = unpack( "(a2)*", $hexStr );

    # If the bytes calculated != number of bytes needed, Fill it with 0's
    unshift @hexStr_arr, 0 until ( scalar @hexStr_arr == $nbrOfBytes );

    #create integer array using hex array
    my $listOfBytes_aref = STR_ListOfHexStrings2ListOfUnsignedIntegers( \@hexStr_arr );

    return $listOfBytes_aref;
}

=head2 NUM_SignedInt2UnsignedInt

    $unsignedInt = NUM_SignedInt2UnsignedInt( $signedInt, $numRelevantBits );
    
Converts signed integer to unsigned integer
    
B<Arguments:>

=over

=item $signedInt

- Signed Integer which needs to be converted to unsigned integer

- If the integer is more than 32 bit long, it MUST be quoted. ex: '1152921504716710707'.

- $signedInt can be []Integer [-\d+], Hex(must be prefixed with 0x) or an object of Math::BigInt or Math::BigFloat

=item $numRelevantBits

- Number of relevent bits based on which unsigned number is calculated

=back

B<Return Values:>

=over

=item $unsignedInt

- Unsigned equivalent of given signed integer

- If the input signed integer is more than 32 bit long, resultant UnsignedInteger will be an object of 'Math::BigFloat'

=back

B<Examples:>

    $unsignedInt = NUM_SignedInt2UnsignedInt( -1 , 16 ) #Returns 655535
    
    $unsignedInt = NUM_SignedInt2UnsignedInt( -5 , 8 ) #Returns 251
    
    $unsignedInt = NUM_SignedInt2UnsignedInt( -1 , 64 ) #Returns Math::BigFloat object with value 18446744073709551615
    
    $unsignedInt = NUM_SignedInt2UnsignedInt( -1, 32 ); #Returns 4294967295 
    
    $unsignedInt = NUM_SignedInt2UnsignedInt( Math::BigFloat->new(-5), 32 ); #returns 4294967291
    
    $unsignedInt = NUM_SignedInt2UnsignedInt( Math::BigInt->new(-6), 32 ); #returns 4294967290

=cut

sub NUM_SignedInt2UnsignedInt {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NUM_SignedInt2UnsignedInt( $signedInt, $numRelevantBits )', @args );
    my $signedInt       = shift;
    my $numRelevantBits = shift;

    #Validate the input. Can be only signed number
    unless ( $signedInt =~ /^([+|-]?\d+|(0x)[0-9A-F]+)$/i ) {
        S_set_error( "NUM_SignedInt2UnsignedInt : Invalid input '$signedInt'. Please provide only signed integer ", 114 );
        return;
    }

    ValidateSignedOrUnsignedIntegerRange( $signedInt, 'S' . $numRelevantBits ) or return;

    # convert signed int to BigInt to be able to handle 32 bit and higher properly
    my $bsignedInt = Math::BigInt->new($signedInt);

    # calculate if the number that has only the MSB set (e.g. 0b10000000)
    my $msbMask = Math::BigInt->bone() << ( $numRelevantBits - 1 );
    my $unsignedInt;

    if ( $bsignedInt & $msbMask ) {

        #prepare mask of 1's based on relevent bits
        my $bitMask = ( Math::BigInt->bone() << $numRelevantBits ) - 1;
        $unsignedInt = $bsignedInt & $bitMask;
    }
    else {
        # if MSB is not set then leave the number unchanged
        $unsignedInt = $bsignedInt;
    }

    # convert the BigInt to a normal scalar
    my $unsignedReturn = $unsignedInt->bstr();

    # if more than 32 bits: convert into a BigFloat to be able to continue calculations with the value afterwards
    if ( $numRelevantBits > 32 ) {
        $unsignedReturn = Math::BigFloat->new($unsignedReturn);
    }

    return $unsignedReturn;
}

=head2 NUM_RandomNumber

    $random_value = NUM_RandomNumber( $value_max, $options_href );
    
Creates a float random number between 0 and $value_max (0 <= $random_value < $value_max).
If $options_href->{value_min} is given then creates a random number $options_href->{value_min} <= $random_value < $value_max.
If $options_href->{type} = 'int' then output is an integer number instead of float. Also here $random_value < $value_max.

B<Arguments:>

=over

=item $value_max

upper limit for the random value

=item $options_href (optional)

    $options_href = {
        value_min => ...,           # lower limit for the random value, = 0 if not given
        type      => 'float'|'int', # value type, either float or int, = 'float' if not given 
    }

=back

B<Return Values:>

=over

=item $random_value

Random value according to inputs. undef on error.

=back

B<Examples:>

    $random_value = NUM_RandomNumber( 10 );                   # float value: 0 <= value < 10
    $random_value = NUM_RandomNumber( 10, {value_min => 5} ); # float value: 5 <= value < 10
    $random_value = NUM_RandomNumber( 10, {type => 'int'} );  # int value: 0 <= value < 10

=cut

sub NUM_RandomNumber {
    my @args = @_;
    S_checkFunctionArguments( 'NUM_RandomNumber( $value_max [, $options_href] )', @args ) or return;
    my $value_max    = shift @args;
    my $options_href = shift @args;

    #STEP error if keys of options_href are not as expected
    if ( defined $options_href ) {
        S_checkFunctionArgumentHashKeys( '$options_href', $options_href, { value_min => 1, type => 1 }, {} ) or return;
    }

    #STEP error if values of $options_href->{type} are not as expected
    if ( defined $options_href->{type} ) {
        S_checkSingleValue( '$options_href->{type}', $options_href->{type}, { list_i => [ 'float', 'int' ] }, 'error' ) or return;
    }

    my $value_min = $options_href->{value_min} // 0;
    my $type      = $options_href->{type}      // 'float';

    #STEP error if max value <= min value
    if ( $value_max <= $value_min ) {
        S_set_error( "Given upper limit (\$value_max = $value_max) is <= lower limit (default or \$options_href->{value_min} = $value_min)", 109 );
        return;
    }

    #STEP calculate random value
    my $delta        = $value_max - $value_min;
    my $random_value = rand($delta) + $value_min;

    #STEP convert random value to int if $options_href->{type} = 'int'
    if ( lc($type) eq 'int' ) {
        $random_value = int($random_value);
    }

    #END return random value
    return $random_value;
}

=head1 not exported functions

=head2 ValidateSignedOrUnsignedIntegerRange

    $status = ValidateSignedOrUnsignedIntegerRange( $integer, $type );
    
Checks if the integer is in valid range based on signed/Unsigned type and number of bits
    
B<Arguments:>

=over

=item $integer

- Integer which needs to be checked if it exists in the range

- It can be signed/unsigned integer, hex(prefixed with 0x) or object of Math::BigInt or Math::BigFloat

=item $type

- Type which needs to checked against integer

- $type can be =~ [US]\d+, U(unsigned) or S(signed) followed by number of bits. ex: U8,S8... etc

=back

B<Return Values:>

=over

=item $status

- Returns 1 if the integer lies in the allowed range. Undef otherwise

=back

B<Examples:>

    ValidateSignedOrUnsignedIntegerRange( -4294967295, 'S32' ) # returns undef

    ValidateSignedOrUnsignedIntegerRange( -2079326208, 'S32' ) # returns 1
    
    ValidateSignedOrUnsignedIntegerRange( 129, 'S8' ) # returns undef
    
    ValidateSignedOrUnsignedIntegerRange( 129, 'U8' ) # returns 1
    
    ValidateSignedOrUnsignedIntegerRange( -2, 'U8' ) # returns undef

=cut

sub ValidateSignedOrUnsignedIntegerRange {
    my @args = @_;
    return unless S_checkFunctionArguments( 'ValidateSignedOrUnsignedIntegerRange( $integer, $type )', @args );
    my $integer = shift;
    my $type    = shift;

    $type =~ /^([usb])(\d+)$/i;
    my ( $dataType, $nbrOfBits ) = ( $1, $2 );

    #create a bigInt object using integer given
    #using BigInt as BigFloat didnt give the expected hex value. ex: 17870283321402272521(dec) -> 0xF7FFFFFFFFC52B09(expected), 0xf7ffffffffc52b09(obtained using BigFloat)
    my $binteger = Math::BigInt->new($integer);

    #check if the integer in the allowed range
    # For Unsigned: (2^$nbrOfBits)-1(max) ,0 (min)
    my $unsignedIntMax = ( Math::BigInt->bone() << $nbrOfBits ) - 1;
    my $unsignedIntMin = Math::BigInt->bzero();

    # For Signed: 2^($nbrOfBits-1)-1(max) ,-2^($nbrOfBits-1) (min)
    my $signedIntMax = ( Math::BigInt->bone() << ( $nbrOfBits - 1 ) ) - 1;
    my $signedIntMin = -Math::BigInt->bone() << ( $nbrOfBits - 1 );

    if ( lc($dataType) =~ /u|b/i && ( $binteger > $unsignedIntMax or $binteger < $unsignedIntMin ) ) {
        S_set_error( "ValidateSignedOrUnsignedIntegerRange : Cannot represent Unsigned integer '$integer' with '$nbrOfBits' bits (type:$type). Please specify in the range: $unsignedIntMax(max) and $unsignedIntMin(min)", 114 );
        return;
    }
    if ( lc($dataType) eq 's' && ( $binteger > $signedIntMax or $binteger < $signedIntMin ) ) {
        S_set_error( "ValidateSignedOrUnsignedIntegerRange : Cannot represent Signed integer '$integer' with '$nbrOfBits' bits (type:$type). Please specify in the range: $signedIntMax(max) and $signedIntMin(min)", 114 );
        return;
    }
    return 1;
}
1;
