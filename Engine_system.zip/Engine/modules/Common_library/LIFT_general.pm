package LIFT_general;

=head1 NAME

LIFT_general

Provide general useful functions of LIFT

=head1 SYNOPSIS

    use LIFT_general;

    $status = S_check_exec_option ( [ $option_name ] );
    $exec_option_value = S_get_exec_option ( [ $option_name ] );

    $parameter_value_or_ref = S_read_mandatory_testcase_parameter ( $parameter_name [, $mode ] );
    $parameter_value_or_ref = S_read_optional_testcase_parameter( $parameter_name [, $mode, $default_value ] );
    $parameter_value_or_ref = S_read_testcase_parameter ( $parameter_name [, 'byref'] );

    $parameter_value = S_read_project_parameter ( $PARAMETER_NAME );
    @timestamp = S_formated_timestamp ( [$TIME] );
    S_get_date_extension(time());
    S_kill_process ( $process_name , [ $HOST ] );
    $PID = S_remote_exec ( $MACHINE , $COMMAND , $ARGUMENTS );
    S_send_mail ($given_sender, $subject, $message, $receipient1 [, $receipient2, ...]);
    S_set_error ( [ $ERR_TEXT ] [, $ERR_CODE ] );
    S_set_warning ( [ $ERR_TEXT ] );
    S_repeat_testcase( );
    S_set_verdict ( $NEW_VERDICT );
    S_determine_overall_verdict( $oldOverallVerdict, $newVerdict );
    S_w2log ( $LEVEL , $TEXT , [color] );
    S_w2rep ( $TEXT , [color]);
    S_w2res ( $TEXT  );
    S_w2res_html ( $TEXT  );
    S_w2tc_html ( $FILENAME  );
    S_wait_ms ( $WAIT_TIME[,$comment] );
    $zip_handle = S_open_zip ( $zip_filename );
    S_add_to_zip ( $zip_handle , @list_of_files_folders );
    S_get_from_zip ( $zip_handle, $storage_folder, @list_of_files_folders );
    S_close_zip ( $zip_handle );
    S_speak( $text );
    S_user_action( $text [, 'Ok'|'YesNo' ]);
    S_set_project_info ( $project_info_href );
    S_get_project_info ( );
    S_set_public_variable ( $name_of_variable , $value );
    ( $valid_flag , $return_value )= S_read_public_variable ( $name_of_variable );
    ( $valid_flag , $old_value )= S_delete_public_variable ( $name_of_variable );
    S_hex2dec
    S_call_command ( $COMMAND_WITH_ARGUMENTS );
    S_append_lines_to_file ( <FILE_NAME> , <LIST OF LINES> );
    S_checkTextInHtml ( $searchRegexp );
    S_checkFunctionArguments ( $functionPrototype, @arguments );
    S_checkFunctionArgumentHashKeys( $functionName, $given_args_href, $valid_args_href, $mandatory_args_href );
    $type_of_content = S_check_contents_of_hash ($param_aref[,$input_href]);    
    $content = S_get_contents_of_hash ($param_aref[,$input_href]);
    S_calculate_value_by_mask ( 0b000111 , "0b10--00" );
    S_teststep
    S_teststep_2nd_level
    S_teststep_expected
    S_teststep_detected
    S_teststep_mismatch
	S_teststep_reset_all
    S_set_timer_zero ( [ $TIMER_NAME ] );
    S_wait_until_timer_ms ( $TIME_VALUE , [ $TIMER_NAME ] );
    $time = S_read_timer_ms ( [ $TIMER_NAME ] );
    $success = S_setSystemSleepMode( [ $command ] );    
    $success = S_check_LIFT_component_integrity( {component => "CREIS", action_on_mismatch => 'error'} );
    
=head1 CONFIGURATION

=head2 S_w2log, Sw2rep

Writing to the html report (HTML filtering) can be controlled by the following section in Project Const:

    'REPORTING' => {

        # 'HTML_FILTER_USE' is the main switch for HTML filtering
        'HTML_FILTER_USE' => 1, # 1- HTML filtering format, 0 - Old format without HTML filtering

        # 'LOGLEVELS' defines which loglevels will apprear in which output
        # 'TEXT'     :    _main__result_log.txt
        # 'HTML'     :    HTML report
        # 'CONSOLE'  :    Windows cmd console
        'LOGLEVELS' => {
            'w2rep'    => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
			'teststep' => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
            '1'        => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
            '2'        => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
            '3'        => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
            '4'        => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
            '5'        => { 'TEXT' => 1, 'HTML' => 0, 'CONSOLE' => 0 },
        },

        # 'LOGLEVEL_SELECTION' defines which loglevels will be displayed by default in the HTML report.
        # In the HTML report more or less loglevels can be selected for diplay.
        'LOGLEVEL_SELECTION' => {
            'w2rep'    => { 'display' => 1 },
			'teststep' => { 'display' => 1 },
            '1'        => { 'display' => 1 },
            '2'        => { 'display' => 1 },
            '3'        => { 'display' => 0 },
            '4'        => { 'display' => 0 },
            '5'        => { 'display' => 0 },
			'warningmessage'  => { 'display' => 1 },
        },

        # 'ELEMENT_SELECTION' defines which elements will be displayed in the HTML report.
        'ELEMENT_SELECTION' => {
            'TABLE'    => { 'display' => 1 },
            'GRAPHICS' => { 'display' => 1 },
            'TEXT'     => { 'display' => 1 },
            'TIME'     => { 'display' => 1 },
        },
    },

=head2 S_wait_ms

For S_wait_ms the waiting time can be a symbolic name which must be configured in project Const like shown in the examples below:

    'TIMER' => {
        'TIMER_ECU_READY' => 10000,
        'TIMER_DIAGNOSIS' => 1500,
        'TIMER_ECU_OFF'   => 9000,
    },

With the definitions above you can call then e.g. S_wait_ms( 'TIMER_ECU_READY' ), which will wait for 10 seconds.

=cut

use strict;
use warnings;
use Win32::OLE qw( in );    ## for S_remote_exec
use Win32::OLE::Variant;    ## for S_remote_exec
use Win32::PerfLib;         ## for S_get_Win32_processes
use Win32::Pipe;
use File::Basename;
use File::Copy;
use File::Find;
use File::Spec;
use Archive::Tar;
use Net::Ping;
use Data::Dumper;
use Sys::Hostname;
use GD::Graph::linespoints;
use GD::Graph::lines;
use GD::Graph::bars;
use Win32;
use Time::HiRes qw( gettimeofday tv_interval );
use Win32::Console::ANSI;
use Term::ANSIColor;
use Readonly;
use Clone qw(clone);
use Data::Table;
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
use Win32::TieRegistry( Delimiter => '/' );
use Win32::Exe qw( );

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

@ISA    = qw(Exporter);
@EXPORT = qw(
  S_0x2dec
  S_add_file_to_snapshot
  S_add_paths2INC
  S_add_pic2html
  S_add_to_zip
  S_add2eval_collection
  S_aref2dec
  S_aref2hex
  S_bin2dec
  S_bitmask_set
  S_call_command
  S_calculate_value_by_mask
  S_check_array
  S_check_contents_of_hash
  S_check_exec_option
  S_check_label
  S_check_LIFT_component_integrity
  S_check_tolerance_absolute
  S_check_tolerance_relative
  S_checkFunctionArguments
  S_checkFunctionArgumentHashKeys
  S_checkSingleValue
  S_checkTextInHtml
  S_close_all
  S_close_zip
  S_compare_num_arrays
  S_compare_str_arrays
  S_convert_dataref_to_file
  S_create_dummy_file
  S_create_dummy_pic
  S_create_graph
  S_create_histogram
  S_create_OLE
  S_dec2aref
  S_dec2bin
  S_dec2hex
  S_decaref2hexaref
  S_delete_public_variable
  S_determine_overall_verdict
  S_dump2pmFile
  S_formated_ECUtime
  S_formated_timestamp
  S_get_contents_of_hash
  S_get_current_verdict
  S_get_date_extension
  S_get_eval_collection
  S_get_eval_text
  S_get_exec_option
  S_get_from_zip
  S_get_label
  S_get_filelist_from_zip
  S_get_LastError_OLE
  S_get_LiftProcessMemory
  S_get_project_info
  S_get_system_strategies
  S_get_TC_number
  S_get_TC_parameter_name
  S_get_TC_time
  S_get_version_and_path_of_dll_on_file_system
  S_get_version_and_path_of_registered_COM_dll
  S_get_Win32_processes
  S_hex2dec
  S_init_LIFT_error_list
  S_init_pipe
  S_log_module_versions
  S_log_testbenchconfig
  S_open_log
  S_open_result
  S_open_zip
  S_ping
  S_PROGRAM_ECU_SW
  S_read_project_parameter
  S_read_public_variable
  S_read_testcase_parameter
  S_read_mandatory_testcase_parameter
  S_read_optional_testcase_parameter
  S_read_timer_ms
  S_register_COM_dlls
  S_kill_process
  S_remote_exec
  S_repeat_testcase
  S_reset_TC_time
  S_SCCM_SetSoftwareDistribution
  S_send_mail
  S_set_error
  S_set_project_info
  S_set_public_variable
  S_set_sys_state
  S_set_timer_zero
  S_set_verdict
  S_set_warning
  S_setSystemSleepMode
  S_speak
  S_Table2csv
  S_TableAddRow
  S_TableCreate
  S_Table2html
  S_TablePrint
  S_teststep
  S_teststep_2nd_level
  S_teststep_detected
  S_teststep_expected
  S_teststep_mismatch
  S_teststep_reset_all
  S_user_action
  S_w2eval
  S_w2log
  S_w2rep
  S_w2res
  S_w2res_html
  S_w2tc_html
  S_wait_ms
  S_wait_until_timer_ms
  AUTOLOAD
  U8
  S8
  U16
  S16
  U32
  S32
  U10
  S10
  SYS_INIT
  SYS_READY
  SYS_CLEAR
  SYS_FAIL
  TC_INIT
  TC_STIMU
  TC_EVAL
  TC_FINAL
  TC_FAIL
  VERDICT_NONE
  VERDICT_BLOCKED
  VERDICT_INCONC
  VERDICT_PASS
  VERDICT_FAIL
  INCONC
  OK
  ERROR
  $SYS_STATE
  $VERDICT
  @ACTUAL_ERROR_CODES
  @TC_HTML_TEXT
  @htmlBookmarks
  %TC_PARAMETER
  %TC_PRJ_PARAMETER
  $REPEAT_TC_FLAG
  ENABLE
  DISABLE
  TEXT
  HTML
  CONSOLE
  $report_log_level
  @report_level_library
  @TC_errors
  );    # export subs and constants

###----------------------------------------------------------------------------

use constant ENABLE  => 1;
use constant DISABLE => 0;

use constant U8  => 'U8';
use constant S8  => 'S8';
use constant U16 => 'U16';
use constant S16 => 'S16';
use constant U32 => 'U32';
use constant S32 => 'S32';
use constant U10 => 'U10';
use constant S10 => 'S10';
use constant F32 => 'F32';

use constant minUx  => 0;
use constant minS8  => -128;
use constant minS10 => -512;
use constant minS16 => -32768;
use constant minS32 => -2147483648;

use constant maxS8  => 127;
use constant maxU8  => 255;
use constant maxU10 => 1023;
use constant maxS10 => 511;
use constant maxS16 => 32767;
use constant maxU16 => 65535;
use constant maxS32 => 2147483647;
use constant maxU32 => 4294967295;

###----------------------------------------------------------------------------
### DECLARATION OF SYSTEM STATES
###----------------------------------------------------------------------------
### these are the constants for $SYS_STATE
use constant SYS_START => 'SYS_START';
use constant SYS_INIT  => 'SYS_INIT';
use constant SYS_READY => 'SYS_READY';
use constant SYS_CLEAR => 'SYS_CLEAR';
use constant SYS_FAIL  => 'SYS_FAIL';
use constant TC_INIT   => 'TC_INIT';
use constant TC_STIMU  => 'TC_STIMU';
use constant TC_EVAL   => 'TC_EVAL';
use constant TC_FINAL  => 'TC_FINAL';
use constant TC_FAIL   => 'TC_FAIL';

my @valid_sys_states = qw( SYS_INIT SYS_READY SYS_CLEAR SYS_FAIL TC_INIT TC_STIMU TC_EVAL TC_FINAL TC_FAIL );

our $SYS_STATE = SYS_START;

###----------------------------------------------------------------------------
### DECLARATION OF VERDICTS
###----------------------------------------------------------------------------
### variable VERDICT will be set only by function S_set_verdict
### initial value is VERDICT_INCONC

use constant VERDICT_NONE    => 'VERDICT_NONE';
use constant VERDICT_INCONC  => 'VERDICT_INCONC';
use constant VERDICT_PASS    => 'VERDICT_PASS';
use constant VERDICT_FAIL    => 'VERDICT_FAIL';
use constant VERDICT_BLOCKED => 'VERDICT_BLOCKED';
use constant INCONC          => '-----';
use constant OK              => '-OK--';
use constant ERROR           => 'ERROR';
my @valid_verdicts = qw( VERDICT_NONE VERDICT_PASS VERDICT_INCONC VERDICT_FAIL VERDICT_BLOCKED );

our $VERDICT = VERDICT_NONE;

###------------------------------------------------------------------
### Declaration of Log File Types
###------------------------------------------------------------------

use constant TEXT    => 0x0010;
use constant HTML    => 0x0020;
use constant CONSOLE => 0x0040;

our @ACTUAL_ERROR_CODES = ();

our %TC_PARAMETER     = ();
our %TC_PRJ_PARAMETER = ();
our @TC_HTML_TEXT     = ();
our @htmlBookmarks    = ();
our @TC_errors        = ();
our @EVAL_TEXT;

our $REPEAT_TC_FLAG = 0;
our $LIFT_TEMP_PATH = "C:\\temp\\LIFT\\";

#Report variables
our @report_level_library = ();
our $report_log_level     = {};

# hash structure
# with error codes and error texts from error file
# will be set up by S_init_LIFT_error_list(<file>)
my $ALL_ERR_CODES = {};

#       -> <CODE> = <error text>
# e.g.  -> 123 = "stupid system error"

# list with all errors leading to SYS_FAIL
my @SYS_FAIL_ERRORS = qw( 111 112 113 100 160 120);

#                           111         # OLE init
#                           112         # bad model state
#                           113         # LC operator not ready
#                           100         # diagnosis tool timeout
#                           160         # TSI config error
#                           120         # tool initialisation error

#
# used for all S_teststep functions
#
my $STEP_COUNTER_HASH;

# $STEP_COUNTER_HASH -> {Nbr_Teststep}  = <remember current major teststep nbr>
# $STEP_COUNTER_HASH -> {Nbr_2ndLevel_Teststep} = <remember current sub teststep nbr>
# $STEP_COUNTER_HASH -> {TC_REPORT_NAME} = <remember current TC name used for report (unique)>  # required for detected reset of numbering
# $STEP_COUNTER_HASH -> {EVAL_KEYWORDS} = { <eval_keyword_1> => <step_nbr_x> ,
#                                           <eval_keyword_2> => <step_nbr_y> , ...  }

###----------------------------------------------------------------------------
my $current_TC_ID;

my $zip_command;              # will be set in S_open_zip()
my %All_ZipFile_to_Handle;    # hash for zip-files: key is the zip-file, value is the corresponding zip-handle
my %All_ZipHandle_to_File;    # hash for zip-files: key is the zip-handle, value is the corresponding zip-file

my %Alive_Hosts;

my %PUBLIC_VARS;              ### this hash controls PUBLIC VARIABLES which can be set, read, deleted from the TCs
### acces only over functions
# S_set_public_variable()
# S_read_public_variable()
# S_delete_public_variable()

my %EVAL_COLLECTION;

#
# main keys are:  'NBR' , 'DATE_TIME' , 'TC_ID' , 'VERDICT' , 'MISMATCH' , 'LAMPS' , 'RB_FAULTS' , 'CU_FAULTS' , 'VR' ,'OTHER_VALUES'
#
# hash content controlled from:
# - S_add2eval_collection()  # fill it with eval informations (from DIAG_evaluate... LC_evaluate_lamps, ...)
# - S_w2eval()         # writes the content into eval file and deletes the entries

my $voice;    # OLE handle to computer voice
my $intra_cell_line_change;

my ( $TC_time, $TC_starttime );
my $noerrorCounter   = 0;
my $nologCounter     = 0;
my $noverdictCounter = 0;
my $timer_href;
my $sccmLastState;

#####################################
#####################################
## Functions in alphabetical order ##
#####################################
#####################################

=head1 FUNCTIONS



=head2 S_0x2dec

    $dec_value = S_0x2dec ( $hex_or_bin_number );

converts $hex_or_bin_number to decimal. leaves decimal values unchanged.
Sets ERROR if $hex_or_bin_number is not a valid number (match 0x[0-9a-fA-F] or 0b[0-1] or [0-9eE\+\-\.]) and returns -1 on error


B<Arguments:>

=over

=item $hex_or_bin_number 

Input can be a hex or a binary number

=back

B<Return Value:>

=over

=item $dec_value 

Returns the decimal value in positive case and -1 on error conditions.

=back

B<Examples:>

    42   = S_0x2dec ( 42 );
    12.5 = S_0x2dec ( 12.5 );
    -2   = S_0x2dec ( -2 );
    255   = S_0x2dec ( "0xFF" );
    9   = S_0x2dec ( "0b1001" );
    1230   = S_0x2dec ( 1.23e+03 );

B<Notes:> 

Input values such as 0X3F or 0B1000 is invalid. Use 0x3F or 0b1000.

=cut

sub S_0x2dec {
    my @args = @_;
    return -1 unless S_checkFunctionArguments( 'S_0x2dec ( $hex_or_bin_number )', @args );
    my $number = shift @args;

    #STEP validate the input values for converting to decimal
    if ( $number !~ /^0x[0-9a-fA-F]+$/ and $number !~ /^0b[0-1]+$/ and $number !~ /^[0-9eE\+\-\.]+$/i ) {
        S_set_error( "S_0x2dec: " . $number . " is not a valid dec hex or bin number\n", 114 );
        return -1;
    }

    # return without conversion if hex number is > 0xFFFFFFFF to avoid warning
    return $number if $number =~ /^0x[0-9a-fA-F]{9,}$/;

    #STEP convert using Oct functionality
    $number = oct($number) if $number =~ /^0(x|b)/;

    #STEP return the converted value
    return $number;
}

=head2 S_add_pic2html

    S_add_pic2html ( $filename [, $attributes, $linktarget, $linkattributes, $loglevel] );

add a picture to html report file with optional html attributes and link.

    e.g. S_add_pic2html ( "./test.png", 'width=600', './dummy.txt.unv','TYPE="text/unv"', 3 );

B<Arguments:>

=over

=item $filename 

Provide the filename in the format './test.png' which will be stored in the reports folder automatically.

Explicit report path is not necesary to be given.

=item $attributes 

(optional) html attributes can be set with this parameter example 'width=600'.

=item $linktarget 

Target unv file from which the image to be created './dummy.txt.unv'.

=item $linkattributes 

(optional) if the link should open unv file also in Firefox, you have to add TYPE="text/unv" as link attribute !

=item $loglevel 

(optional) set log level to display the image. (Ranges from 1 .. 5)

=back

B<Return Value:>

=over

=item $returnValue 

 1 on success
-1 on failure

=back

B<Examples:>

    1 = S_add_pic2html ( "./test.png", 'width=600', './dummy.txt.unv','TYPE="text/unv"', 3 );

=cut

sub S_add_pic2html {

    my @args = @_;
    return -1 unless S_checkFunctionArguments( 'S_add_pic2html ( $filename [, $attributes, $linktarget, $linkattributes, $loglevel] )', @args );

    my $filename       = shift;
    my $attributes     = shift;
    my $linktarget     = shift;
    my $linkattributes = shift;
    my $picLogLevel    = shift;
    my ( $htmltext, $text, $picLogLevelstr );

    my $package = (caller)[0];

    unless ( $package eq 'main' ) {
        unless ( grep { /^$package$/ } @report_level_library ) {
            push( @report_level_library, $package );
        }
    }

    if ( defined $picLogLevel and ( $picLogLevel < 0 or $picLogLevel > 5 ) ) {
        S_set_error("Given loglevel $picLogLevel is out of range. Loglevel must be 0 - 5");
        return -1;
    }

    if ( not defined $picLogLevel ) {
        $picLogLevelstr = "w2rep";
    }
    else {
        $picLogLevelstr = $picLogLevel;
    }

    $text = "adding $filename with attributes <$attributes> link <$linktarget> and linkattributes <$linkattributes> to html report\n";
    print $text unless $main::opt_silent;
    print LOG $text;

    if ( defined $linktarget ) {
        $htmltext = "<div class=\"$picLogLevelstr $package\"><div class=\"TCgraph\"><A HREF=\"$linktarget\" $linkattributes><IMG SRC=\"$filename\" alt=\"$filename\" $attributes></A></div></div><div class=\"space-line\"></div>";
    }
    else {
        $htmltext = "<div class=\"$picLogLevelstr $package\"><div class=\"TCgraph\"><IMG SRC=\"$filename\" alt=\"$filename\" $attributes></div></div><div class=\"space-line\"></div>";
    }
    push( @TC_HTML_TEXT, $htmltext . "\n" );

    return 1;
}

=head2 S_add2eval_collection

    S_add2eval_collection ( 'keyword' , $content );

This function fills internal %EVAL_COLLECTION with the following allowed keywords:

     'MISMATCH' , 'LAMPS' , 'RB_FAULTS' , 'CU_FAULTS' , 'OTHER_VALUES'

     (Enigne uses internally 'NBR' , 'DATE_TIME' , 'TC_ID' , 'VERDICT')

'$content' contains the string which have to be written in the related column of Evaluation table

each new call of S_add2eval_collection() with the same 'keyword' leads to an intra-cell line change in Excel - csv (chr(10))

this will also fill @EVAL_TEXT which will be used for importing expected and detected behaviour to DOORS.
all evaluation functions do this automatically, if you want to add something on your own here one example:

   this is a short example taken from EVAL_evaluate_interval

   my $signal_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};
   my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
   my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};

   S_add2eval_collection( 'OTHER_VALUES' , "$signal_marker $signal_to_check");
   S_add2eval_collection( 'OTHER_VALUES' , "$expect_marker interval $lower_limit <= X <= $upper_limit");
   S_add2eval_collection( 'OTHER_VALUES' , "$detect_marker X = $detected_value");

   if( compare_two_values( $detected_value , '<' , $lower_limit ) ) {
        S_w2rep( " Signal '$signal_to_check' : (detected) '$detected_value' is smaller than $lower_limit (lower_limit) \n");
        S_add2eval_collection( 'MISMATCH' , "$signal_to_check (lower limit violation)" );
        S_set_verdict( VERDICT_FAIL );
   }

=cut

sub S_add2eval_collection {
    my $keyword     = shift;
    my $new_content = shift;

    unless ( defined $new_content ) {
        S_set_error( "! too less parameters ! SYNTAX: S_add2eval_collection ( 'keyword' , 'content' );", 110 );
        return -1;
    }

    my $old_content;

    $intra_cell_line_change = chr(10);

    #   $intra_cell_line_change = chr(28);
    #   $intra_cell_line_change = chr(10).chr(13);

    unless ( exists $EVAL_COLLECTION{$keyword} ) {
        $EVAL_COLLECTION{$keyword} = "\"" . $new_content . "\"";
    }
    else {
        $old_content = $EVAL_COLLECTION{$keyword};
        chop $old_content;
        $EVAL_COLLECTION{$keyword} = $old_content . $intra_cell_line_change . $new_content . "\"";
    }

    push( @EVAL_TEXT, $keyword . ";" . $new_content );

    return 1;
}

=head2 S_aref2dec

    $dec_value = S_aref2dec ( $byte_aref , $datatype );

converts array reference to dec (with conversion to datatype).

    $datatype may be one of U8,S8,U10,S10,U16,S16,U32,S32, F32

				Description					|		  EXAMPLES	
											|	input	 		output
		--------------------------------------------------------------------				
    	U8	|	Unsigned integer 8 bit		| 	[0xA]		| 	10
    	S8	|	Signed integer 8 bit		| 	[0x83]		| 	-3
    	U10	|	Unsigned integer 10 bit		|	[0x35D]		|	861	
    	S10	|	Signed integer 10 bit		|	[0x3FE]		| 	-510	
    	U16	|	Unsigned integer 16 bit		|	[0xE3C7]	|	58311	
    	S16	|	Signed integer 16 bit		|	[0xE3C7]	| 	-25543
    	U32	|	Unsigned integer 32 bit		|	[0x4512DC00]|	1158863872
    	S32	|	Signed integer 32 bit		|	[0x4512DC00]| 	1158863872
    	F32	|	Float 32 bit				|	[0x40200000]|	2,5
    	
    array values may be hex of bin or dec and between 0 to 255

    e.g. 511 = S_aref2dec ( [1,255] , U16 );
         255 = S_aref2dec ( [0xff] , U8 );
        -255 = S_aref2dec ( [255,'0b1'] , S16 );


=cut

sub S_aref2dec {
    my $aref = shift;
    my $type = shift;
    my ( @array, $count, $dec_value );

    unless ( defined $type ) {
        S_set_error( "! too less parameters ! SYNTAX: S_aref2dec ( \$aref, \$datatype )", 110 );
        return;
    }

    unless ( ref($aref) eq "ARRAY" ) {
        S_set_error( " aref is not an array reference", 114 );
        return;
    }

    @array = @$aref;
    my $arr_size = scalar(@array);
    $type = uc($type);    # ignore lower case for AB12

    # check if bytes <= maxbytes(type)
    if ( ( $type eq U8 or $type eq S8 ) and $arr_size > 1 ) {
        S_set_error( "! array size $arr_size exceeds number of maximum bytes for type $type", 110 );
        return;
    }

    if ( ( $type eq U16 or $type eq S16 or $type eq S10 or $type eq U10 ) and $arr_size > 2 ) {
        S_set_error( "! array size $arr_size exceeds number of maximum bytes for type $type", 110 );
        return;
    }

    if ( ( $type eq U32 or $type eq S32 or $type eq F32 ) and $arr_size > 4 ) {
        S_set_error( "! array size $arr_size exceeds number of maximum bytes for type $type", 110 );
        return;
    }

    # convert data to dec if required
    for ( $count = 0 ; $count < $arr_size ; $count++ ) {
        my $val = S_0x2dec( $array[$count] );

        if ( $val > 255 ) {
            S_set_error( "! byte value $array[$count] on array[$count] out of range ( 0<=x<=255 )", 110 );
            return;
        }

        if ( $val < 0 ) {
            S_set_error( "! byte value $array[$count] not a valid value (S_0x2dec error) or < 0", 110 );
            return;
        }

        $array[$count] = sprintf( "%02X", $val );
    }

    my $val = hex( join( '', @array ) );

    if ( $type eq S10 ) {
        my $sign = $val & 512;
        $val = $val & 511;

        # if 1. bit=1 -> invert hex val, add 1, transform to dec, change sign
        if   ($sign) { $dec_value = ( 512 - $val ) * -1 }
        else         { $dec_value = $val }
    }
    elsif ( $type eq S8 )  { $dec_value = unpack( "c*", pack( "i*", $val ) ) }
    elsif ( $type eq S16 ) { $dec_value = unpack( "s*", pack( "i*", $val ) ) }
    elsif ( $type eq S32 ) { $dec_value = unpack( "l*", pack( "i*", $val ) ) }
    elsif ( $type eq U8 )  { $dec_value = $val }
    elsif ( $type eq U10 ) { $dec_value = $val & maxU10 }
    elsif ( $type eq U16 ) { $dec_value = $val }
    elsif ( $type eq U32 ) { $dec_value = $val }
    elsif ( $type eq F32 ) { $dec_value = unpack( "f*", pack( "I*", $val ) ) }
    else {
        S_set_error( " unknown datatype <$type>", 114 );
        return;
    }

    return $dec_value;

}

=head2 S_aref2hex

    $hex_value = S_aref2hex ( $aref );

converts array reference to hex bytestring (with leading 0x).

    array values may be hex of bin or dec and between 0 to 255

    e.g. 0x01FF = S_aref2hex ( [1,255] );
         0xFF = S_aref2hex ( ['0xff'] );
         0xFF = S_aref2hex ( ['0b11111111'] );

returns '0x0' on error

=cut

sub S_aref2hex {
    my $aref = shift;
    my ( @array, $count, $hex_value );

    unless ( defined($aref) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_aref2hex ( \$aref )", 110 );
        return "0x0";
    }

    if ( ref($aref) ne "ARRAY" ) {
        S_set_error( " aref is not an array reference", 114 );
        return "0x0";
    }

    # return 1 if $main::opt_offline;

    @array = @$aref;

    # convert data to dec if required
    for ( $count = 0 ; $count < scalar(@array) ; $count++ ) {
        my $val = S_0x2dec( $array[$count] );

        # check if 255 <= byte => 0
        if ( $val =~ /\./ ) {
            S_set_error( "S_aref2dec: " . $val . " is a float\n", 114 );
            return "0x0";
        }
        elsif ( $val > 255 ) {
            S_set_error( "! byte value $array[$count] on array[$count] out of range ( 0<=x<=255 )", 110 );
            return "0x0";
        }
        elsif ( $val < 0 ) {
            S_set_error( "! byte value $array[$count] not a valid value (S_0x2dec error) or < 0", 110 );
            return "0x0";
        }
        $array[$count] = sprintf( "%02X", $val );
    }

    $hex_value = "0x";
    $hex_value .= join( '', @array );

    return $hex_value;

}

=head2 S_bitmask_set

    $value_hex = S_bitmask_set ( $value, $bitmask , (0|1) );

sets the given bits in $value to 1 or 0. $value and $bitmask may be hex, dec or bin

    e.g. 0x17 = S_bitmask_set ( 22, '0b001' , 1);

returns '0x0' on error

=cut

sub S_bitmask_set {
    my $value   = shift;
    my $bitmask = shift;
    my $setflag = shift;

    my ( @array, $count, $hex_value, $report );

    S_w2log( 1, "S_bitmask_set\n" );
    unless ( defined($setflag) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_bitmask_set ( \$value, \$bitmask , (0|1) )", 110 );
        return "0x0";
    }

    if ( $setflag != 0 and $setflag != 1 ) {
        S_set_error( "! last parameter has to be 0 or 1", 114 );
        return "0x0";
    }

    $report = "-> val $value ";

    # convert data to dec if required
    my $new_value   = S_0x2dec($value);
    my $new_bitmask = S_0x2dec($bitmask);
    if ( ( $new_value eq "-1" and $value ne "-1" ) or ( $new_bitmask eq "-1" and $bitmask ne "-1" ) ) {
        S_set_error( "! S_0x2dec reported an error", 110 );
        return "0x0";
    }
    $bitmask = $new_bitmask;
    $value   = $new_value;

    if ( $setflag == 1 ) {
        $value |= $bitmask;
    }
    else {
        $value &= ~$bitmask;
    }

    $value = "0x" . sprintf( "%02X", $value );

    $report .= sprintf( "bitmask 0b%b $setflag result %s\n", $bitmask, $value );

    S_w2log( 3, $report );

    return $value;

}

=head2 S_call_command

    ( $RETURN_VALUE , @SCREEN_OUTPUT_LINES ) = S_call_command ( "$COMMAND_WITH_ARGUMENTS" );

Executes COMMAND_WITH_ARGUMENTS on the shell
returns the $RETURN_VALUE and all @SCREEN_OUTPUT_LINES

    e.g. (1, ("hello") ) = S_call_command ( "echo hello" )

The command with arguments will proceed in the following steps :

    open(HANDLE, "$COMMAND_WITH_ARGUMENTS |" )
    @SCREEN_OUTPUT_LINES = <HANDLE>
    $RETURN_VALUE = close HANDLE
    return ( $RETURN_VALUE , @SCREEN_OUTPUT_LINES) ;

$RETURN_VALUE = 1 if $COMMAND_WITH_ARGUMENTS was successful (returns with 0

$RETURN_VALUE = 0 if $COMMAND_WITH_ARGUMENTS was NOT successful (returns with 1)

Please take care that you use the "" in the parameter call
  - even when $COMMAND_WITH_ARGUMENTS is defined as a normal scalar value.

    OFFLINE MODE supported -> System Command will not be executed 

=cut

sub S_call_command {
    my $COMMAND_WITH_ARGUMENTS = shift;

    unless ($COMMAND_WITH_ARGUMENTS) {
        S_set_error( "! too less parameters ! SYNTAX: S_call_command ( \$COMMAND_WITH_ARGUMENTS )", 110 );
        return;
    }

    my ( $pid, $RETURN_VALUE, @SCREEN_OUTPUT_LINES, );

    return ( 1, "HURRA - SUCCESSFUL in OFFLINE MODE" ) if $main::opt_offline;

    unless ( defined( $pid = open( SAVE_CHILD_COMMAND, "$COMMAND_WITH_ARGUMENTS |" ) ) ) {
        S_set_error( "executing fork : $!", 5 );
        return;
    }

    @SCREEN_OUTPUT_LINES = <SAVE_CHILD_COMMAND>;

    unless ( ( $RETURN_VALUE = close SAVE_CHILD_COMMAND ) ) {
        S_set_error( "executing program: '$COMMAND_WITH_ARGUMENTS' : $! ($?) \n @SCREEN_OUTPUT_LINES", 5 );
        return;
    }

    return ( $RETURN_VALUE, @SCREEN_OUTPUT_LINES );

}

=head2 S_check_array

    $RESULT = S_check_array($array_ref [, $array_name ])

To check the given parameter is an Array reference and does not contain any Undefined array elements.

Returns 1 , if Given parameter is an Array reference and does not contain undefined array element (s)

0 , if Given parameter is not an Array reference or contains undefined array element (s)


=cut

sub S_check_array {
    my $array_ref  = shift;
    my $array_name = shift;

    unless ( defined($array_ref) ) {
        S_set_error( "! too less parameters ! SYNTAX: \$RESULT = S_check_array ( \$array_ref [, \$array_name])", 110 );
        return 0;
    }

    $array_name = "Given parameter" unless ( defined($array_name) );

    #check if $array_ref is an array
    if ( ref($array_ref) ne "ARRAY" ) {
        S_set_error( "$array_name is not an array reference", 114 );
        return 0;
    }

    #check if array contains undefined values
    for ( my $index = 0 ; $index < scalar(@$array_ref) ; $index++ ) {
        unless ( defined( $$array_ref[$index] ) ) {
            S_set_error( "$array_name contains undefined array element(s)", 109 );
            return 0;
        }
    }

    return 1;
}

=head2 S_check_tolerance_absolute

    $RESULT = S_check_tolerance_absolute ( $EXPECTED_VALUE , $TEST_VALUE , $tolerance_absolute );

    $EXPECTED_VALUE , $TEST_VALUE and $tolerance_absolute may be hex, dec, bin or float

    e.g. 1 = S_check_tolerance_absolute ( '0xa' , 9.2, '0b1' );
         0 = S_check_tolerance_absolute ( 11 , 9.2, 1.2 );

Returns 1 if the difference between $TEST_VALUE and $EXPECTED_VALUE fits
to the tolerance $tolerance_absolute Returns 0 otherwise and on error.

=cut

sub S_check_tolerance_absolute {

    my $expected_value     = shift;
    my $test_value         = shift;
    my $tolerance_absolute = shift;

    my ( $value_min, $value_max, $value_temp );

    unless ( defined($tolerance_absolute) ) {
        S_set_error( "! too less parameters ! SYNTAX: \$RESULT = S_check_tolerance_absolute ( \$EXPECTED_VALUE , \$TEST_VALUE , \$tolerance_absolute )", 110 );
        return 0;
    }

    S_w2log( 3, " S_check_tolerance_absolute: ExpectedValue: $expected_value TestValue: $test_value Tolerance: $tolerance_absolute (absolute) \n" );

    my $new_expected_value     = S_0x2dec($expected_value);
    my $new_test_value         = S_0x2dec($test_value);
    my $new_tolerance_absolute = S_0x2dec($tolerance_absolute);
    if ( ( $new_expected_value eq "-1" and $expected_value ne "-1" ) or ( $new_test_value eq "-1" and $test_value ne "-1" ) or ( $new_tolerance_absolute eq "-1" and $tolerance_absolute ne "-1" ) ) {
        S_set_error( "! S_0x2dec reported an error", 110 );
        return 0;
    }
    $test_value         = $new_test_value;
    $expected_value     = $new_expected_value;
    $tolerance_absolute = $new_tolerance_absolute;

    $value_max = $expected_value + $tolerance_absolute;
    $value_min = $expected_value - $tolerance_absolute;

    S_w2log( 5, " S_check_tolerance_absolute: MinValue: $value_min MaxValue: $value_max \n" );

    unless ( $test_value <= $value_max ) {
        S_w2log( 2, " S_check_tolerance_absolute: Tolerance NOT OK (MAX value violation)\n" );
        return 0;
    }

    unless ( $test_value >= $value_min ) {
        S_w2log( 2, " S_check_tolerance_absolute: Tolerance NOT OK (MIN value violation)\n" );
        return 0;
    }

    S_w2log( 4, " S_check_tolerance_absolute: Tolerance OK \n" );
    return 1;

}

=head2 S_check_tolerance_relative

    $RESULT = S_check_tolerance_relative ( $EXPECTED_VALUE , $TEST_VALUE , $tolerance_percentage );

Returns 1 if the difference between $TEST_VALUE and $EXPECTED_VALUE fits
to the tolerance $tolerance_percentage (in percent). Returns 0 otherwise and on error.

=cut

sub S_check_tolerance_relative {

    my $expected_value       = shift;
    my $test_value           = shift;
    my $tolerance_percentage = shift;

    my ( $value_min, $value_max, $value_temp );

    unless ( defined($tolerance_percentage) ) {
        S_set_error( "! too less parameters ! SYNTAX: \$RESULT = S_check_tolerance_relative ( \$EXPECTED_VALUE , \$TEST_VALUE , \$tolerance_percentage )", 110 );
        return 0;
    }

    S_w2log( 3, " S_check_tolerance_relative: ExpectedValue: $expected_value TestValue: " . $test_value . " Tolerance: $tolerance_percentage (percent) \n" );

    my $new_expected_value = S_0x2dec($expected_value);

    my $new_test_value = S_0x2dec($test_value);

    my $new_tolerance_percentage = S_0x2dec($tolerance_percentage);
    if ( ( $new_expected_value eq "-1" and $expected_value ne '-1' ) or ( $new_test_value eq "-1" and $test_value ne '-1' ) or ( $new_tolerance_percentage eq "-1" and $tolerance_percentage ne '-1' ) ) {
        S_set_error( "! S_0x2dec reported an error", 110 );
        return 0;
    }

    $test_value           = $new_test_value;
    $expected_value       = $new_expected_value;
    $tolerance_percentage = $new_tolerance_percentage;

    $value_max = $expected_value * ( 1 + ( $tolerance_percentage / 100 ) );
    $value_min = $expected_value * ( 1 - ( $tolerance_percentage / 100 ) );

    # Round numbers to 10 digits after decimal point
    $value_max  = sprintf( "%.10f", $value_max );
    $test_value = sprintf( "%.10f", $test_value );
    $value_min  = sprintf( "%.10f", $value_min );

    if ( $expected_value < 0 ) {

        $value_temp = $value_max;
        $value_max  = $value_min;
        $value_min  = $value_temp;
    }

    S_w2log( 3, " S_check_tolerance_relative: MeasureValue: $test_value ExpMinValue: $value_min ExpMaxValue: $value_max ( ExpValue: $expected_value +/- $tolerance_percentage % )\n" );

    if ( abs( $test_value > $value_max ) ) {
        S_w2log( 2, " S_check_tolerance_relative: Tolerance NOT OK (MAX value violation: $test_value > $value_max)\n" );
        return 0;
    }

    if ( $test_value < $value_min ) {
        S_w2log( 2, " S_check_tolerance_relative: Tolerance NOT OK (MIN value violation: $test_value < $value_min )\n" );
        return 0;
    }

    S_w2log( 4, " S_check_tolerance_relative: Tolerance OK \n" );
    return 1;
}

=head2 S_compare_num_arrays

    S_compare_num_arrays ( $aref1, $aref2 );

    returns true (1) if arrays match by number, uses S_0x2dec for conversion of elements
    returns false (0) on mismatch
    does not do any logging

=cut

sub S_compare_num_arrays {
    my $aref1 = shift;
    my $aref2 = shift;
    unless ( defined($aref2) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_compare_num_arrays ( \$aref1, \$aref2 )", 110 );
        return 0;
    }
    if ( ref($aref1) ne "ARRAY" ) {
        S_set_error( " aref1 is not an array reference", 114 );
        return 0;
    }
    if ( ref($aref2) ne "ARRAY" ) {
        S_set_error( " aref2 is not an array reference", 114 );
        return 0;
    }

    return 0 if ( scalar(@$aref1) != scalar(@$aref2) );
    for ( my $x = 0 ; $x < scalar(@$aref1) ; $x++ ) {
        return 0 if ( S_0x2dec( $$aref1[$x] ) != S_0x2dec( $$aref2[$x] ) );
    }
    return 1;
}

=head2 S_compare_str_arrays

    S_compare_str_arrays ( $aref1, $aref2 );

    returns true (1) if arrays match by string
    returns false (0) on mismatch
    does not do any logging

=cut

sub S_compare_str_arrays {
    my $aref1 = shift;
    my $aref2 = shift;
    unless ( defined($aref2) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_compare_str_arrays ( \$aref1, \$aref2 )", 110 );
        return 0;
    }

    if ( ref($aref1) ne "ARRAY" ) {
        S_set_error( " aref1 is not an array reference", 114 );
        return 0;
    }

    if ( ref($aref2) ne "ARRAY" ) {
        S_set_error( " aref2 is not an array reference", 114 );
        return 0;
    }

    return 0 if ( scalar(@$aref1) != scalar(@$aref2) );
    for ( my $x = 0 ; $x < scalar(@$aref1) ; $x++ ) {
        return 0 if ( $$aref1[$x] ne $$aref2[$x] );
    }
    return 1;

}

=head2 S_create_dummy_file

    S_create_dummy_file ( $filename );

creates a file with dummy text, useful in offline mode, does nothing if file already exists.

=cut

sub S_create_dummy_file {
    my $filename = shift;

    # just return in offline mode if file already exists
    return 1 if ( -f $filename and $main::opt_offline );

    if ( open( FILE, ">$filename" ) ) {
        print FILE "dummyfile created usually in offline mode";
        close(FILE);
    }
    else { S_set_error( " S_create_dummy_file : could not create $filename", 1 ); }

    return 1;
}

=head2 S_create_dummy_pic

    $picfile = S_create_dummy_pic ( $filename );

creates a picture file with dummy text, useful in offline mode. Filextension will be replaced with '.png', does nothing if file already exists.

=cut

sub S_create_dummy_pic {
    my $filename = shift;

    use GD;
    $filename =~ s/\.\w+$//;    # cut off file extension
    $filename =~ s/\//\\/g;     # replace all slashes with backslashes
    $filename .= '.png';

    # just return in offline mode if file already exists
    return $filename if ( -f $filename and $main::opt_offline );

    my $image = new GD::Image( 800, 600 );

    # background color white
    $image->colorAllocate( 255, 255, 255 );

    # define brush colors
    my $red   = $image->colorAllocate( 255, 0, 0 );
    my $black = $image->colorAllocate( 0,   0, 0 );

    # paint text on the canvas
    $image->string( gdGiantFont, 250, 300, "dummy file created usually in offline mode", $red );

    # Put a black frame around the picture
    $image->rectangle( 0, 0, 799, 599, $black );

    # create png
    if ( open( PNG, ">$filename" ) ) {
        binmode(PNG);
        print PNG $image->png;
        close(PNG);
    }
    else { S_set_error( " S_create_dummy_pic : could not create $filename", 1 ); }
    return ($filename);

}

=head2 S_create_graph

    S_create_graph ( $data_href, $plotfilename [, $title, $bg_colour, $mode, $yAxisLabel, $lineColors_aref] );

create plot from data structure and save as pic (*.png) and UNIVIEW file (*.txt.unv). $plotfilename extension will be cut off and replaced.

data structure has to be an Hash of Arrays, where the key is the signal name.

singal 'time' (in ms) will be taken as x axis or if signal 'time' is omitted it will be created as (1,2,3 ...).

$bg_colour may be 'black' or 'white', default is 'white'

$mode may be 'no_interpolation', 'interpolate' or 'interpolate_points', default is 'no_interpolation'

$title will be taken as heading for picture, default is 'graph'

$yAxisLabel will be taken as label for the y-axis, default is undef (no y-axis label).

   $data_href ={
    'signal' => \@values,
   };

    e.g.
    my @time =(10,20,30);        # in millisec
    my  $data1={
       'time' => \@time,
       'val1'=> [100,200,300],
       'val2'=> [@time],
    };
    S_create_graph($data1,"test1.txt");

Alternatively to 'time' => \@time, you can use 'x' => \@x_values, 'x-label' => 'mylabel'

    NOTE: graph will start from first time, not from time = 0. if you want to start from 0 you have to provide according signal.

The colors of graph lines will by default be in the order B<blue yellow purple gray orange red green gold dpink marine brown> for white background and 
B<lblue lyellow lpurple lgray lorange lred lgreen cyan lbrown> for black background.
By specifying $lineColors_aref the default can be changed to any other order.

=cut

sub S_create_graph {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_create_graph ( $data_href, $plotfilename [, $title, $bg_colour, $mode, $yAxisLabel, $lineColors_aref] )', @args );

    my $data_in         = shift @args;
    my $filename        = shift @args;
    my $title           = shift @args;
    my $bg_colour       = shift @args;
    my $mode            = shift @args;
    my $yLabel          = shift @args;
    my $lineColors_aref = shift @args;

    my $nbr_of_data_elements;
    my $mismatch_flag = 0;
    my @time          = ();

    # clone input data to avoid problems with multiple calls
    my $data_href = clone($data_in);

    $title     = 'graph'            unless defined($title);
    $bg_colour = 'white'            unless defined($bg_colour);
    $mode      = 'no_interpolation' unless defined($mode);

    if ( $bg_colour ne 'black' and $bg_colour ne 'white' ) {
        S_set_error( " bg_colour $bg_colour is not 'black' or 'white'", 114 );
        return 0;
    }
    if ( $mode ne 'no_interpolation' and $mode ne 'interpolate' and $mode ne 'interpolate_points' ) {
        S_set_error( " mode $mode is not 'no_interpolation', 'interpolate' or 'interpolate_points'", 114 );
        return 0;
    }

    $filename =~ s/\.(\w+)$//;    # cut off file extension
    $filename =~ s/::/_/g;        # Replace if the name contains '::' to '_'. as '::' is not supported by filename.
    my $picname = $filename . ".png";
    my $unvName = $filename . ".txt.unv";

    S_w2log( 5, "S_create_graph( $filename )\n" );

    return 1 if $main::opt_offline;

    # check if hash contains data
    my @legend = sort keys %{$data_href};
    if ( scalar(@legend) == 0 ) {
        S_set_error( "data_href is empty !", 109 );
        return 0;
    }

    my ( $timeFactor, $xLabel );
    if ( exists $data_href->{'time'} ) {
        $nbr_of_data_elements = scalar @{ $data_href->{'time'} };
        @time                 = @{ $data_href->{'time'} };
        delete $data_href->{'time'};
        $timeFactor = 1000;
        $xLabel     = 'time in ms';
    }
    elsif ( exists $data_href->{'x'} ) {
        $nbr_of_data_elements = scalar @{ $data_href->{'x'} };
        @time                 = @{ $data_href->{'x'} };
        delete $data_href->{'x'};
        $timeFactor = 1;
        $xLabel     = $data_href->{'x-label'};
        delete $data_href->{'x-label'};
    }
    else {
        $timeFactor = 1000;
        $xLabel     = 'time in ms';
    }

    # get number of data elements if no 'time' or 'x' key exists
    $nbr_of_data_elements = GetNumberOfElements( $data_href, $nbr_of_data_elements );
    if ( $nbr_of_data_elements == 0 ) {
        return 0;
    }

    # create @time if no 'time' or 'x' key exists
    unless (@time) {
        S_w2log( 5, " S_create_graph: no time signal given : take 1 .. $nbr_of_data_elements as x-axis\n" );
        @time = ( 1 .. $nbr_of_data_elements );
    }

    # create UNV file and GD::Graph data array
    S_w2log( 5, " S_create_graph: Start CrasteUNV_GD \n" );
    my ( $gdData_aref, $signals_aref ) = CreateUNV_GD( $data_href, $unvName, \@time, $nbr_of_data_elements, $mode, $timeFactor );
    if ( not defined $gdData_aref ) {
        return 0;
    }

    # create GD::Graph object
    my $graph;
    S_w2log( 5, " S_create_graph: fill graph variable with points \n" );
    if ( $mode eq 'interpolate_points' ) {
        $graph = GD::Graph::linespoints->new( 800, 600 );
    }
    else {
        $graph = GD::Graph::lines->new( 800, 600 );
    }

    # set GD::Graph attributes
    S_w2log( 5, " S_create_graph: set GD::Graph attributes \n" );
    if ( $bg_colour eq 'black' ) {
        $lineColors_aref = [qw(lblue lyellow lpurple lgray lorange lred lgreen cyan lbrown)] if not defined $lineColors_aref;
        $graph->set(
            x_label       => $xLabel,
            y_label       => $yLabel,
            title         => $title,
            x_tick_number => 'auto',
            r_margin      => 10,
            l_margin      => 10,
            b_margin      => 10,
            transparent   => 0,
            bgclr         => "black",
            fgclr         => "white",
            textclr       => "white",
            labelclr      => "white",
            axislabelclr  => "white",
            legendclr     => "white",
            valuesclr     => "white",
            dclrs         => $lineColors_aref,
        );
    }
    else {
        $lineColors_aref = [qw(blue yellow purple gray orange red green gold dpink marine brown)] if not defined $lineColors_aref;
        $graph->set(
            x_label       => $xLabel,
            y_label       => $yLabel,
            title         => $title,
            x_tick_number => 'auto',
            r_margin      => 10,
            l_margin      => 10,
            b_margin      => 10,
            dclrs         => $lineColors_aref,
        );
    }

    $graph->set_legend_font( GD::Font->Large );

    $graph->set_legend( @{$signals_aref} );

    # plot graph and save it as png
    S_w2log( 5, " S_create_graph: plot and save graph \n" );
    if ( open( my $pic_fh, ">$picname" ) ) {
        binmode $pic_fh;
        print $pic_fh $graph->plot($gdData_aref)->png;
        close($pic_fh);
    }
    else {
        S_set_error( "could not create file picname", 1 );
    }

    return 1;

}

=head2 GetNumberOfElements

    $nbr_of_data_elements = GetNumberOfElements ( $data_href, $nbr_of_data_elements );  (not exported)

get number of data elements if no 'time' or 'x' key exists

local function, called by S_create_graph

=cut

sub GetNumberOfElements {
    my $data_href            = shift;
    my $nbr_of_data_elements = shift;

    my ( $nbr_of_elements_temp, $mismatch_flag );

    foreach my $signal ( keys %$data_href ) {

        unless ( ref $data_href->{$signal} eq "ARRAY" ) {
            S_set_error( "signal '$signal' data is not an array ref !", 109 );
            return 0;
        }

        $nbr_of_elements_temp = scalar @{ $data_href->{$signal} };
        S_w2log( 5, " S_create_graph: '$signal' has $nbr_of_elements_temp elements \n" );

        unless ($nbr_of_elements_temp) {
            S_set_error( "parameter array size of signal '$signal' is 0 !", 109 );
            return 0;
        }

        # 1st loop : storing length and signal name when no time signal given (see above)
        $nbr_of_data_elements = $nbr_of_elements_temp unless defined $nbr_of_data_elements;

        # compare correct length and go in next loop
        next if ( $nbr_of_data_elements == $nbr_of_elements_temp );

        S_w2log( 5, " S_create_graph: '$signal' has size mismatch( $nbr_of_elements_temp <--> $nbr_of_data_elements (reference value) \n" );
        $mismatch_flag = 1;

    }

    if ($mismatch_flag) {
        S_set_error( "given signal data not consistant (different nbr of elements)!", 109 );
        return 0;
    }

    return $nbr_of_data_elements;

}

=head2 CreateUNV_GD

    ($gdData_aref, $signals_aref) = CreateUNV_GD ( $data_href, $unvName, $time_aref, $nbr_of_data_elements, $mode, $timeFactor );  (not exported)

create UNV file and GD::Graph data array

local function, called by S_create_graph

=cut

sub CreateUNV_GD {
    my $data_href            = shift;
    my $unvName              = shift;
    my $time_aref            = shift;
    my $nbr_of_data_elements = shift;
    my $mode                 = shift;
    my $timeFactor           = shift;

    my @time = @{$time_aref};

    my ( %oldvalue, $value, @gdData );

    my $unvLine1 = "TIME;";
    my $unvLine2 = "s;";
    foreach ( sort keys %{$data_href} ) {
        $unvLine1 .= "$_;";
        $unvLine2 .= "-;";
        $oldvalue{$_} = 0;
    }

    my $unvString = "$unvLine1\n";
    $unvString .= "$unvLine2\n";

    # signals is @legend without 'time'
    my @signals = sort keys %$data_href;

    # check if number of points to be plotted is within the memory limits
    my $numberOfPoints      = $nbr_of_data_elements * @signals;
    my $numberOfPointsLimit = 500000;
    if ( $numberOfPoints > $numberOfPointsLimit ) {
        S_set_error( "Number of data points ($numberOfPoints) higher than the memory limit ($numberOfPointsLimit). Please reduce the number of points to be plotted.", 104 );
        return ( undef, undef );
    }

    #create curve
    S_w2log( 5, " CreateUNV_GD: Start creating curve \n" );
    my ( $dt, $last_time, $current_time );

    # set plot stepwidth to 1/100 of the average time distance between 2 points if there are only few points (<10)
    # set plot stepwidth dynamically from 1/100 to 1 of the average time distance between 2 points if 10 < number of points < 1000
    # set plot stepwidth to the average time distance between 2 points if number of points >= 1000 in order to avoid memory problems with high number of points
    my $samplingFactor;
    if ( $nbr_of_data_elements < 10 ) {
        $samplingFactor = 100;
    }
    elsif ( $nbr_of_data_elements < 1000 ) {
        $samplingFactor = 1000 / $nbr_of_data_elements;
    }
    else {
        $samplingFactor = 1;
    }

    my $step = ( $time[-1] - $time[0] ) / ( $nbr_of_data_elements * $samplingFactor );

    if ( $step == 0 ) {
        S_set_error("Stepwidth was calculated as zero. Problem with time stamps! Function will be aborted.");
        return;
    }

    S_w2log( 5, "CreateUNV_GD: Step is $step \n" );

    my $gdData_signal_index;

    $last_time    = 0;
    $current_time = $time[0];
    my $last_time_index = 0;

    S_w2log( 5, " CreateUNV_GD: Start foreach time index \n" );
    foreach my $time_index ( 0 .. $#time ) {
        $dt = $time[$time_index];

        # calculate interpolation values between real given data
        while ( $current_time < ( $last_time + $dt ) ) {
            push( @{ $gdData[0] }, $current_time );

            $gdData_signal_index = 0;
            foreach my $signal (@signals) {
                $gdData_signal_index++;
                $value = $data_href->{$signal}[$last_time_index];
                if ( $mode eq 'no_interpolation' ) {
                    push( @{ $gdData[$gdData_signal_index] }, $value );    # put same value to avoid internal interpolation
                }
                else {
                    push( @{ $gdData[$gdData_signal_index] }, undef );     # put undef to use internal interpolation
                }
            }

            $current_time += $step;
        }

        $last_time_index = $time_index;
        push( @{ $gdData[0] }, $current_time );
        $unvLine1 = ( $time[$time_index] / $timeFactor ) . ";";

        $gdData_signal_index = 0;
        foreach my $signal (@signals) {
            $gdData_signal_index++;
            $value = $data_href->{$signal}[$time_index];
            push( @{ $gdData[$gdData_signal_index] }, $value );
            $unvLine1 .= "$value;";
        }
        $unvString .= "$unvLine1\n";
    }

    S_w2log( 5, " CreateUNV_GD: Open and write unv file \n" );
    if ( open( my $unv_fh, ">$unvName" ) ) {
        print $unv_fh $unvString;
        close($unv_fh);
    }
    else {
        S_set_error( " Couldnt open UNIVIEW file '$unvName' ", 1 );
        return ( undef, undef );
    }

    S_w2log( 5, " CreateUNV_GD: Return data \n" );
    return ( \@gdData, \@signals );

}

=head2 S_create_histogram

    S_create_histogram( $data_aref, $plotfilename [, $options_href] );

Creates a histogram from the numbers given in $data_aref and stores it as png file in given $plotfilename.

B<Arguments:>

=over

=item $data_aref 

Reference to an array of numbers that will be filled into a histogram.

=item $plotfilename 

File name for the png file that will be created. '.png' will be added if necessary. 
If no path is given then the file will be created in the report folder.

=item $options_href 

(optional) Hash with additional options for the histogram. Keys other than those listed below will be ignored.

    'numberOfChannels' => <n>    : number of histogram channels (default = 60)
    'title'            => <text> : title of the histogram (default = 'Histogram')
    'xAxisLabel'       => <text> : text of the x-axis label (default = '')
    'loglevel'         => <n>    : if given then the histogram will be added to the html report with given loglevel
    'ylogarithmic'     => 'yes'  : if given and == 'yes' then the y-values will be plotted in logarithmic scale;
                                   note however that in the uniview file log10(y)+1 will be stored

=back

B<Return Value:>

=over

=item $success 

1 on success, undef otherwise.

=back

B<Examples:>

    $success = S_create_histogram( $data_aref, 'myHistogram' );
    $success = S_create_histogram( $data_aref, 'C:\temp\myTempHistogram.png', {'title' => 'My Title'} );
    $success = S_create_histogram( $data_aref, 'myHistogram', {'title' => 'My Title', 'xAxisLabel' => 'x', 'numberOfChannels' => 50, 'loglevel' => 1} );

=cut

sub S_create_histogram {
    my @args = @_;
    S_checkFunctionArguments( 'S_create_histogram ( $data_aref, $plotfilename [, $options_href] )', @args ) or return;

    my $data_aref    = shift @args;
    my $plotfilename = shift @args;
    my $options_href = shift @args;

    #COMMENT-START
    # Arguments:
    # $data_aref:    Reference to an array of numbers that will be filled into a histogram
    # $plotfilename: File name for the png file that will be created
    # $options_href: (optional)
    #     'numberOfChannels' => <n>    : number of histogram channels (default = 60)
    #     'title' => <text> : title of the histogram (default = 'Histogram')
    #     'xAxisLabel' => <text> : text of the x-axis label (default = '')
    #     'loglevel' => <n> : if given then the histogram will be added to the html report with given loglevel
    #     'ylogarithmic' => 'yes' : if given and == 'yes' then the y-values will be plotted in logarithmic scale
    #COMMENT-END

    #STEP handle arguments, especially $options_href
    if ( basename($plotfilename) eq $plotfilename ) {
        $plotfilename = $main::REPORT_PATH . '/' . $plotfilename;
    }
    if ( $plotfilename !~ /\.png$/i ) {
        $plotfilename .= '.png';
    }

    my $numberOfChannels = $options_href->{'numberOfChannels'};
    $numberOfChannels = 60 if not defined $numberOfChannels;

    my $title = $options_href->{'title'};
    $title = 'Histogram' if not defined $title;
    my $xAxisLabel = $options_href->{'xAxisLabel'};
    $xAxisLabel = '' if not defined $xAxisLabel;
    my $loglevel = $options_href->{'loglevel'};
    S_w2log( 4, "S_create_histogram: Creating a histogram in file '$plotfilename' with numberOfChannels = $numberOfChannels, title = '$title', xAxisLabel = '$xAxisLabel', loglevel = $loglevel\n" );

    #STEP Get min and max value from $data_aref
    my ( $minValue, $maxValue ) = ( 1e99, -1e99 );    # Initialize to values outside anything in your list
    map { $maxValue = $_ if ( $_ > $maxValue ); $minValue = $_ if ( $_ < $minValue ); } @$data_aref;

    #STEP Calculate x-array of the histogram
    my $channelWidth = ( $maxValue - $minValue ) / ( $numberOfChannels - 1 );
    $channelWidth = $minValue / 10 if $channelWidth == 0;
    my @xValues;
    foreach my $index ( 0 .. $numberOfChannels ) {    # add 1 more dummy x-channel so that the graph looks good
        my $xValue = $minValue + ( $index + 0.5 ) * $channelWidth;
        push( @xValues, $xValue );
    }

    #STEP Sort each element of $data_aref into a histogram channel
    my @yValues = (0) x ( $numberOfChannels + 1 );    # add 1 more dummy x-channel so that the graph looks good
    foreach my $dataValue (@$data_aref) {
        my $index = int( ( $dataValue - $minValue ) / $channelWidth );
        $yValues[$index]++;
    }

    #STEP create the histogram
    my $graph = GD::Graph::bars->new( 800, 600 );

    $graph->set(
        x_label       => $xAxisLabel,
        y_label       => 'Number of values',
        title         => $title,
        x_tick_number => 'auto',
        r_margin      => 10,
        l_margin      => 10,
        b_margin      => 10,
    );

    $graph->set_legend_font( GD::Font->Large );
    my @histogramData = ( \@xValues, \@yValues );
    $xAxisLabel =~ s/\s/_/g;
    my $unvSignalLabel = "Number_of_values_of_$xAxisLabel";

    #STEP re-calculate y-values if option 'ylogarithmic' => 'yes' is given
    if ( $options_href->{'ylogarithmic'} =~ /yes/i ) {
        foreach my $index ( 0 .. $#yValues ) {
            if ( $yValues[$index] > 0 ) {
                $yValues[$index] = log( $yValues[$index] ) / log(10) + 1;
            }
            else {
                $yValues[$index] = 0;
            }
        }
        $graph->set( y_number_format => \&YaxisLog );
        $unvSignalLabel = 'log10(' . $unvSignalLabel . ')+1';
    }

    #STEP plot the histogram as png
    open( my $pic_fh, '>', $plotfilename ) or S_set_error( "Could not create the png file '$plotfilename': $!", 1 ), return;
    binmode $pic_fh;
    print $pic_fh $graph->plot( \@histogramData )->png;
    close($pic_fh);

    #CALL S_add_pic2html if loglevel is defined
    if ( defined $loglevel ) {
        my $basename = basename($plotfilename);
        my $unvname  = $basename;
        $unvname =~ s/\.png/.unv/i;
        S_add_pic2html( $basename, "", $unvname, 'TYPE="text/unv"', $loglevel );
    }

    #STEP write histogram data as uniview file
    $plotfilename =~ s/\.png/.unv/i;
    my $unvString = "$xAxisLabel;$unvSignalLabel;\n";
    $unvString .= "-;-;\n";
    foreach my $index ( 0 .. @xValues - 1 ) {
        $unvString .= "$xValues[$index];$yValues[$index];\n";
    }

    open( my $unv_fh, '>', $plotfilename ) or S_set_error( "Could not create the unv file '$plotfilename': $!", 1 ), return;
    print $unv_fh $unvString;
    close($unv_fh);

    return 1;
}

# helper function that converts log10($value) to $value for y axis number format
sub YaxisLog {
    my $value = shift;
    my $ret;

    if ( $value <= 0 ) {
        $ret = 0;
    }
    else {
        $ret = 10**( $value - 1 );
    }
    return $ret;
}

=head2 S_dec2aref

     $aref = S_dec2aref ( $dec_value, $datatype );

converts dec to array reference (with conversion of datatype).

    $datatype may be one of U8,S8,U10,S10,U16,S16,U32,S32
    $dec_value may be hex or bin if positive

    e.g.  [1,255] = S_dec2aref ( 511, U16 );
          [255,1] = S_dec2aref ( -255, 'S16'  );
          [255] = S_dec2aref ( '0b11111111', 'U8'  );
          [255] = S_dec2aref ( '0xff', 'U8'  );

=cut

sub S_dec2aref {
    my $dec_value = shift;
    my $type      = shift;
    my ( @array, $hex_value );
    my $error_ret = [];

    unless ( defined($type) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_dec2aref ( \$dec_value, \$datatype )", 110 );
        return $error_ret;
    }

    $type = uc($type);    # ignore lower case for AB12
    my $new_dec_value = S_0x2dec($dec_value);
    if ( $new_dec_value eq "-1" and $dec_value ne "-1" ) {
        S_set_error( "! S_0x2dec reported an error", 110 );
        return $error_ret;
    }

    $dec_value = $new_dec_value;
    if ( $dec_value =~ /\./ ) {
        S_set_error( "S_dec2aref: " . $dec_value . " is a float\n", 114 );
        return $error_ret;
    }

    # check if value inisde min/max(type)
    if ( $type eq U8 and ( $dec_value < minUx or $dec_value > maxU8 ) ) {
        S_set_error( "! U8 value $dec_value out of range (" . minUx . "<=val<=" . maxU8 . ")", 110 );
        return $error_ret;
    }
    elsif ( $type eq U10 and ( $dec_value < minUx or $dec_value > maxU10 ) ) {
        S_set_error( "! value $dec_value out of range (" . minUx . "<=val<=" . maxU8 . ")", 110 );
        return $error_ret;
    }
    elsif ( $type eq U16 and ( $dec_value < minUx or $dec_value > maxU16 ) ) {
        S_set_error( "! value $dec_value out of range (" . minUx . "<=val<=" . maxU16 . ")", 110 );
        return $error_ret;
    }
    elsif ( $type eq U32 and ( $dec_value < minUx or $dec_value > maxU32 ) ) {
        S_set_error( "! value $dec_value out of range (" . minUx . "<=val<=" . maxU32 . ")", 110 );
        return $error_ret;
    }
    elsif ( $type eq S8 and ( $dec_value < minS8 or $dec_value > maxS8 ) ) {
        S_set_error( "! S8 value $dec_value out of range (" . minS8 . "<=val<=" . maxS8 . ")", 110 );
        return $error_ret;
    }
    elsif ( $type eq S10 and ( $dec_value < minS10 or $dec_value > maxS10 ) ) {
        S_set_error( "! value $dec_value out of range (" . minS10 . "<=val<=" . maxS10 . ")", 110 );
        return $error_ret;
    }
    elsif ( $type eq S16 and ( $dec_value < minS16 or $dec_value > maxS16 ) ) {
        S_set_error( "! value $dec_value out of range (" . minS16 . "<=val<=" . maxS16 . ")", 110 );
        return $error_ret;
    }
    elsif ( $type eq S32 and ( $dec_value < minS32 or $dec_value > maxS32 ) ) {
        S_set_error( "! value $dec_value out of range (" . minS32 . "<=val<=" . maxS32 . ")", 110 );
        return $error_ret;
    }

    if ( $type eq S8 ) {
        $hex_value = unpack( "H*", pack( "c*", $dec_value ) );
    }
    elsif ( $type eq S16 ) {
        $hex_value = unpack( "H*", pack( "s*", $dec_value ) );
    }
    elsif ( $type eq S32 ) {
        $hex_value = unpack( "H*", pack( "l*", $dec_value ) );
    }
    elsif ( $type eq U8 ) {
        $hex_value = unpack( "H*", pack( "C*", $dec_value ) );
    }
    elsif ( $type eq U16 or $type eq U10 ) {
        $hex_value = unpack( "H*", pack( "S*", $dec_value ) );
    }
    elsif ( $type eq U32 ) {
        $hex_value = unpack( "H*", pack( "L*", $dec_value ) );
    }
    elsif ( $type eq S10 ) {
        $hex_value = 0;

        if ( $dec_value < 0 ) {
            $hex_value = 512;
            $dec_value = ( 512 + $dec_value );
        }
        $dec_value += $hex_value;
        $hex_value = unpack( "H*", pack( "S*", $dec_value ) );
    }
    else {
        S_set_error( " unknown datatype <$type>", 114 );
        return $error_ret;
    }

    $hex_value = sprintf( "%s", $hex_value );

    ## example taken form perlmonks.org:
    ## How can I split a string into chunks of size n bytes?
    ## my $string = "1234567890abcdefghijABCDEFGHIJK";
    ## my $n = 2;    # $n is group size.
    ## my @groups = unpack "a$n" x (length( $string ) /$n ), $string;
    @array = reverse( unpack( "a2" x ( length($hex_value) / 2 ), $hex_value ) );

    #convert all elements to decimal
    foreach my $item (@array) {
        $item = hex($item);
    }

    return \@array;
}

=head2 S_dec2bin

    $BIN = S_dec2bin ( $DEC );

returns 32 bit binary value of $DEC without leading '0b'.

  e.g. 00000000000000000000000011111111 = S_dec2bin ( 255 );
       00000000000000000000001011011101 = S_dec2bin ( 733 );

to drop leading zeroes you can use  $BIN =~ s/^0+//;

=cut

sub S_dec2bin {
    my $dec = shift;
    unless ( defined($dec) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_dec2bin ( \$DEC )", 110 );
        return 0;
    }
    unless ( $dec =~ /^\d+$/ ) {
        S_set_error( "DEC $dec is not a positive decimal value", 114 );
        return 0;
    }

    my $str = unpack( "B32", pack( "N", $dec ) );

    # S_w2log( 5, " S_dec2bin : $dec -> $str\n" );
    return $str;
}

=head2 S_delete_public_variable

    ( $valid_flag , $old_value )= S_delete_public_variable ( "MY_VARIABLE" );

    $valid_flag = 1 if delete successful
    $valid_flag = 0 if delete not successful because public variable was not defined before

    $old_value is last value of this variable

Deletes the public variable with key "MY_VARIABLE" from Memory, if exists.

=cut

sub S_delete_public_variable {

    my $var_name = shift;

    unless ( defined($var_name) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_delete_public_variable ( name_of_variable );", 110 );
        return 0;
    }

    my $value;

    if ( defined $PUBLIC_VARS{$var_name} ) {
        $value = $PUBLIC_VARS{$var_name};
        S_w2log( 2, " S_delete_public_variable: delete '$var_name' = '$value' (last value) \n" );
        delete $PUBLIC_VARS{$var_name};
        return ( 1, $value );
    }
    else {
        S_w2log( 2, " S_delete_public_variable: '$var_name' not defined \n" );
        delete $PUBLIC_VARS{$var_name} if exists $PUBLIC_VARS{$var_name};    ## just for the case that var was existing but without defined value
        return (0);
    }

}

=head2 S_formated_ECUtime

    $TIMESTAMP = S_formated_ECUtime ( $ECUtime );

returns "HH:MM:SS" of given time in seconds, 00:00:00 on error

$ECUtime will be converted by S_0x2dec if hex or bin and has to be > 0

mainly used in LIFT_PD to convert appearence and disappearence time.

=cut

sub S_formated_ECUtime {
    my $mytime = shift;
    unless ( defined($mytime) ) {
        S_set_error( "! too less parameters ! SYNTAX:  S_formated_ECUtime ( ECUtime )", 110 );
        return "00:00:00";
    }

    # convert data to dec if required
    my $new_time = S_0x2dec($mytime);
    if ( ( $new_time eq "-1" and $mytime ne "-1" ) ) {
        S_set_error( "! S_0x2dec reported an error", 110 );
        return "00:00:00";
    }
    $mytime = $new_time;

    if ( $mytime < 0 ) {
        S_set_error( "! ECUtime < 0", 110 );
        return "00:00:00";
    }
    my $hours = int( $mytime / 3600 );
    my $min   = int( $mytime / 60 ) - 60 * $hours;
    my $sec   = $mytime - 60 * $min - 3600 * $hours;

    return ( sprintf( "%02d:%02d:%02d", $hours, $min, $sec ) );

}

=head2 S_formated_timestamp

    @TIMESTAMP = S_formated_timestamp ( [$TIME] );

returns ( "DD.MM.YYYY", "HH:MM:SS" ) of given time (result of time() )
if nothing given the current time will be formated

=cut

sub S_formated_timestamp {
    my $mytime = shift;
    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst );
    if ( defined $mytime ) {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($mytime);
    }
    else {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime( time() );
    }
    return ( sprintf( "%02d.%02d.%04d", $mday, $mon + 1, $year + 1900 ), sprintf( "%02d:%02d:%02d", $hour, $min, $sec ) );
}

=head2 S_check_label

    $status = S_check_label ( $label [ , $source_aref ] );
    
    check status of $label in given $source_aref in main::ProjectDefaults
    $source_aref is the list of elements in tree above of the label in main::ProjectDefaults
    
    S_check_contents_of_hash is used 
    
    Return values: 
    $status :
        
        1 - specific $label is available and is not a reference

        SCALAR / ARRAY / HASH - type of content is a reference / type is returned
        
        0 - specific $label not defined

    No errors are thrown

    Example :
    
      my $TSG_scanner_dvm_ub_status = S_check_label( 'UB' , [ 'TSG4_SCANNER' , 'DVM' ] );
    
    
=cut

sub S_check_label {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_check_label ( $label [ , $source_aref ] )', @args );
    my $label       = shift @args;
    my $source_aref = shift @args;

    my $return = S_check_contents_of_hash( [ @$source_aref, $label ] );

    unless ($return) {
        S_w2log( 4, " S_check_label : '$label' is NOT DEFINED -> return 0\n" );
        return 0;
    }

    S_w2log( 4, " S_check_label : '$label' is defined -> return $return\n" );
    return $return;
}

=head2 S_get_label


    $content = S_get_label ( $label [ , $source_aref ] );
    
    check status of $label in given $source_aref in main::ProjectDefaults
    $source_aref is the list of elements in tree above of the label in main::ProjectDefaults
    
    Return values: 
    $status :
        
        $content - specific $label is available and is not a reference

        SCALAR / ARRAY / HASH - type of content is a reference / type is returned
        
        undef - specific $label not defined

    ERROR is THROWN by called S_get_contents_of_hash !!!
    
    use S_check_label before !!

    Example :
    
      my $TSG_scanner_dvm_ub_content = S_get_label( 'UB' , [ 'TSG4_SCANNER' , 'DVM' ] ) 
                                    if S_check_label( 'UB' , [ 'TSG4_SCANNER' , 'DVM' ] );
    
    
=cut

sub S_get_label {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_get_label ( $label [ , $source_aref ] )', @args );
    my $label       = shift @args;
    my $source_aref = shift @args;

    my $content_value = S_get_contents_of_hash( [ @$source_aref, $label ] );

    unless ( defined $content_value ) {
        S_w2log( 4, " S_get_label : '$label' is NOT DEFINED -> return\n" );
        return;
    }

    my $type_return_is_ref = ref $content_value;

    if ($type_return_is_ref) {
        S_w2log( 3, " S_get_label: Return '$label' =  < $type_return_is_ref >\n" );
    }
    else {
        S_w2log( 3, " S_get_label: Return '$label' = '$content_value' \n" );
    }

    return $content_value;
}

=head2 S_check_exec_option

    $status = S_check_exec_option ( [ $option_name ] );

    Is working only when LIFT_exec_engine is called with options
      -exec_options_file  <file>
      -use_exec_options  <name_of_profile>

    
    Return values: 
    $state :
        
        1 - LIFT_EXEC_OPTIONS are used 
        1 - specific $option_name is available
        
        0 - LIFT_EXEC_OPTIONS not active 
            => use LIFT_exec_engine with -exec_options_file and -use_exec_options
        0 - specific $option_name not defined

    No errors are thrown
    
=cut

sub S_check_exec_option {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_check_exec_option ( [ $option_name ] )', @args );
    my $option_name = shift @args;

    unless ( defined $main::LIFT_EXEC_OPTIONS_href ) {
        S_w2log( 4, " S_check_exec_option : LIFT_EXEC_OPTIONS not active => use LIFT_exec_engine with -exec_options_file and -use_exec_options\n" );
        S_w2log( 4, " S_check_exec_option : return 0\n" );
        return 0;
    }

    unless ($option_name) {
        S_w2log( 4, " S_check_exec_option : LIFT_EXEC_OPTIONS is active and no specific option have been asked for \n" );
        S_w2log( 4, " S_check_exec_option : return 1\n" );
        return 1;
    }

    unless ( defined $main::LIFT_EXEC_OPTIONS_href->{$option_name} ) {
        S_w2log( 4, " S_check_exec_option : LIFT_EXEC_OPTION '$option_name' is NOT DEFINED -> return 0\n" );
        return 0;
    }

    S_w2log( 4, " S_check_exec_option : LIFT_EXEC_OPTION '$option_name' is defined -> return 1\n" );
    return 1;
}

=head2 S_get_exec_option

    $exec_option_value = S_get_exec_option ( [ $option_name , $default_value_if_option_not_defined ] );

    returns the values of LIFT_EXEC_OPTIONS file (passed with -exec_options_file )
    
    Is working only when LIFT_exec_engine is called with options
      -exec_options_file  <file>
      -use_exec_options  <name_of_profile>

    Function arguments:
        no - return all exec_options in a hash ref
        $option_name - name of exec option
        $default_value_if_option_not_defined - value which shall be returned if $option_name is not defined 
    
    Return values: 
        $exec_option_value :
            
            <all_exec_options> - ( when no $option_name is given) 
            <value of $option_name>
    

        Error : return undef

    Error is thrown when LIFT_EXEC_OPTIONS is not activated 
    Error is thrown when given option_name is not defined and no default value is given

    
    EXAMPLES :

        my $exec_options_all = S_get_exec_option();
        
        my $exec_option_1 = S_get_exec_option( 'option_1' );
        
        my $exec_option_2 = S_get_exec_option( 'option_2' , '0' );     # return 0 when 'option_1' not defined
        
        my $exec_option_from_LIFT_engine = S_get_exec_option( 'offline' );     # is set with 1 when LIFT_exec_engine -OFFLINE is called
        
        my $exec_option_from_LIFT_engine = S_get_exec_option( 'evaluation_only' );     #  is set with 1 when LIFT_exec_engine -EVALUATION_ONLY is called
        


    Example LIFT_EXEC_OPTIONS file :

        package LIFT_EXEC_OPTIONS;
        
        $EXEC_OPTIONS  = {
            'DEFAULT' => {
                option_1 => 'value_D_1' ,
                option_2 => 'value_D_2' ,
                option_3 => 'value_D_3' ,
            },
            'DATA_SET_A' => {
                option_1 => 'value_A_1' ,
                option_2 => 'value_A_2' ,
                option_3 => 'value_A_3' ,
            },
        };



    NOTE :  all regular command line arguments from LIFT_exec_engine are taken as special exec options which can be read with this function as well:
    
    $LIFT_EXEC_OPTIONS_href->{'testlist'}             = $opt_testlist          if defined $opt_testlist          
    $LIFT_EXEC_OPTIONS_href->{'conf'}                 = $opt_conf              if defined $opt_conf              
    $LIFT_EXEC_OPTIONS_href->{'tc_para'}              = $opt_tc_para           if defined $opt_tc_para           
    $LIFT_EXEC_OPTIONS_href->{'IC'}                   = $opt_IC                if defined $opt_IC                
    $LIFT_EXEC_OPTIONS_href->{'EC'}                   = $opt_IC                if defined $opt_EC                
    $LIFT_EXEC_OPTIONS_href->{'tc_exec_options_file'} = $opt_exec_options_file if defined $opt_exec_options_file 
    $LIFT_EXEC_OPTIONS_href->{'beep'}                 = 1                      if defined $opt_beep              
    $LIFT_EXEC_OPTIONS_href->{'offline'}              = 1                      if defined $opt_offline           
    $LIFT_EXEC_OPTIONS_href->{'simulation'}           = 1                      if defined $opt_simulation        
    $LIFT_EXEC_OPTIONS_href->{'evaluation_only'}      = 1                      if defined $opt_evaluation_only   
    $LIFT_EXEC_OPTIONS_href->{'silent'}               = 1                      if defined $opt_silent            
    $LIFT_EXEC_OPTIONS_href->{'polite'}               = 1                      if defined $opt_polite            
    $LIFT_EXEC_OPTIONS_href->{'minimalsnapshot'}      = 1                      if defined $opt_minimalsnapshot   
    
    
=cut

sub S_get_exec_option {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_get_exec_option ( [ $option_name [ , $default_value_if_option_not_defined ]] )', @args );
    my $option_name                         = shift @args;
    my $default_value_if_option_not_defined = shift @args;

    my $exec_option_value;

    unless ( defined $main::LIFT_EXEC_OPTIONS_href ) {
        S_set_error(" LIFT_EXEC_OPTIONS not active => use LIFT_exec_engine with -exec_options_file and -use_exec_options\n");
        return;
    }

    unless ($option_name) {
        S_w2log( 4, " S_get_exec_option : return complete set of exec_options \n" );
        return $main::LIFT_EXEC_OPTIONS_href;
    }

    if ( defined $main::LIFT_EXEC_OPTIONS_href->{$option_name} ) {
        $exec_option_value = $main::LIFT_EXEC_OPTIONS_href->{$option_name};
    }
    else {
        if ( defined $default_value_if_option_not_defined ) {
            S_w2log( 3, " S_get_exec_option : '$option_name' is NOT DEFINED -> return given default value\n" );
            $exec_option_value = $default_value_if_option_not_defined;
        }
        else {
            S_set_error(" LIFT_EXEC_OPTION '$option_name' is NOT DEFINED\n");
            return;
        }
    }

    if ( ref $exec_option_value ) {
        S_w2log( 3, " S_get_exec_option : '$option_name' is a REF\n" );
    }
    else {
        S_w2log( 3, " S_get_exec_option : '$option_name' => $exec_option_value \n" );
    }

    return $exec_option_value;
}

=head2 S_get_current_verdict

    VERDICT = S_get_current_verdict ( );

returns current VERDICT for the current testcase (uses global variable $VERDICT).
Note that during a testcase the verdict can only get worse (e.g. a verdict can be set from
'VERDICT_PASS' to 'VERDICT_FAIL' but not vice versa.

=cut

sub S_get_current_verdict {

    S_w2log( 3, " S_get_current_verdict: $VERDICT\n" );
    return ($VERDICT);

}

=head2 S_get_date_extension

    $formatted_string = S_get_date_extension ( [$TIME] );

return the string created using the given time (result of time() ). This string can be appended to any file name.

If $TIME is not passed, current time (time()) will be taken.

    ex.,  S_get_date_extension ( time() );

If current time is "5th march, 2014 14:06:53", this API returns "20140305_140653"

=cut

sub S_get_date_extension {
    my $given_time = shift;

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst );

    if ( defined $given_time ) {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($given_time);
    }
    else {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime( time() );
    }

    return sprintf( "%04d%02d%02d_%02d%02d%02d", $year + 1900, $mon + 1, $mday, $hour, $min, $sec );
}

=head2 S_get_TC_time

    $time = S_get_TC_time ( );

returns current time in floating seconds since TC start.

=cut

sub S_get_TC_time {

    $TC_time = sprintf( "%.6f", tv_interval( $TC_starttime, [gettimeofday] ) );
    S_w2log( 5, "current TC time is $TC_time\n" );
    return ($TC_time);

}

=head2 S_hex2dec

    $dec_value = S_hex2dec ( $hex_number [, $number_of_bits ]);

converts $hex_number to decimal. returns -1 on error.

If $number_of_bits is not given then $hex_number is converted as unsigned integer.

If $number_of_bits is given then $hex_number is converted as signed integer
with a range [-(2**($number_of_bits*8-1)-1) .. 2**($number_of_bits*8-1)].

Example:

     255 = S_hex2dec ( "FF" );
      -1 = S_hex2dec ( "FF" , 8 );
    -128 = S_hex2dec ( "80" , 8 );
     255 = S_hex2dec ( "0xFF" );
    -128 = S_hex2dec ( "0x80" , 8 );

NOTE: it is recommended to use S_0x2dec instead !

=cut

sub S_hex2dec {
    my $hex_number     = shift;
    my $number_of_bits = shift;

    my ( $dec_value, $max_value );

    unless ( defined($hex_number) ) {
        S_set_error( "! too less parameters ! SYNTAX:  S_hex2dec ( \$hex_number [, \$number_of_bits ])", 110 );
        return -1;
    }
    $hex_number =~ s/^0x//;    # drop leading 0x

    if ( $hex_number !~ /^[0-9a-f]+$/i ) {
        S_set_error( "S_hex2dec: " . $hex_number . " is not a valid hex number\n", 114 );
        return -1;
    }

    $dec_value = hex($hex_number);

    ## return result in case of unsigned value given
    ## (indicated by no given number_of_bits)
    return $dec_value if not defined $number_of_bits;

    $max_value = 2**$number_of_bits;

    ## error when dec_value to big
    if ( $dec_value >= $max_value ) { S_set_error( "(dec_value is bigger than max_value) hex number $hex_number >= 2**number_bits = $max_value\n", 109 ); return -1; }

    ## return result in case of positve signed value
    ## (indicated by value less then 50% of max_value)
    if ( $dec_value < $max_value / 2 ) { return $dec_value; }
    ## return result in case of negative signed value
    else { return $dec_value - $max_value; }
}

=head2 S_dec2hex

    $hex_number = S_dec2hex ( $dec_value);

Converts decimal to hexadecimal.

B<Arguments:>

=over

=item $dec_value 

A decimal value is passed as input.

=back

B<Return Value:>

=over

=item $returnValue 

Returns -1 on error.
Return hex value on success.

=back

B<Examples:>

    0xFF = S_dec2hex ( "255" );

=cut

sub S_dec2hex {
    my @args = @_;
    return -1 unless S_checkFunctionArguments( 'S_dec2hex ( $dec_value )', @args );
    my $dec_number = shift @args;

    my $hex_value;

    #STEP Check if the number is valid decimal value
    if ( $dec_number !~ /^\d+$/i ) {
        S_set_error( "S_dec2hex: " . $dec_number . " is not a valid decimal number\n", 114 );
        return -1;
    }

    #STEP convert value to hex using sprintf
    # format specifier modified
    $hex_value = sprintf( "0x%0X", $dec_number );    #Convert decimal to hex

    #STEP Return
    return $hex_value;
}

=head2 S_decaref2hexaref

    $hex_aref = S_decaref2hexaref ( $dec_aref);

Converts $decaref to $hex_aref. 

Return -1 on error.
Return array values in hex  on succes

Example:    

    my $dec_aref = [224,173,223,254];
     $hex_aref = S_decaref2hexaref ( $dec_aref);

=cut

sub S_decaref2hexaref {
    my $dec_aref = shift;
    my @hex_aref = ();

    unless ( defined($dec_aref) ) {
        S_set_error( "! too less parameters ! SYNTAX:  S_decaref2hexaref ( $dec_aref )", 110 );
        return -1;
    }

    unless ( ref($dec_aref) eq 'ARRAY' ) {
        S_set_error( "Given input $dec_aref is not an array reference )", 114 );
        return -1;
    }

    foreach my $dec_value (@$dec_aref) {
        if ( $dec_value !~ /^\d+$/i ) {
            S_set_error( "S_decaref2hexaref " . $dec_value . " is not a valid decimal number in input array\n", 114 );
            return -1;
        }
    }

    foreach my $dec_value (@$dec_aref) {
        my $hex_value = sprintf( "%#0x", $dec_value );    #Convert decimal to hex
        push( @hex_aref, uc $hex_value );
    }
    return \@hex_aref;                                    #return converted hex values as array
}

=head2 S_read_project_parameter

    $PARAMETER_VALUE = S_read_project_parameter ( $PARAMETER_NAME );

Returns the value of $PARAMETER_NAME if found in project parameter file.

If $PARAMETER_NAME doesn't exist, no error is set to allow optional parameters.

If a parameter is mandatory it has to be checked inside the testcase.

Special case:

  %All_Project_Parameter = S_read_project_parameter ( 'ALL' );

=cut

sub S_read_project_parameter {
    my $para_name = shift;

    my ( $scalar, @list, %hash, $text, $key, $value, %return_all_hash );

    ## special case when all project parameters in one hash requested
    if ( $para_name =~ /^ALL$/i ) {
        S_w2log( 3, "  S_read_project_parameter: found project parameters: \n" );

        ## create one hash '%return_all_hash' with all project parameters
        foreach $para_name ( keys %TC_PRJ_PARAMETER ) {
            if ( exists $TC_PRJ_PARAMETER{$para_name}{'SCALAR'} ) {
                $scalar = $TC_PRJ_PARAMETER{$para_name}{'SCALAR'};
                S_w2log( 3, "    $para_name = $scalar \n" );
                $return_all_hash{$para_name} = $scalar;
            }
            elsif ( exists $TC_PRJ_PARAMETER{$para_name}{'LIST'} ) {
                @list = @{ $TC_PRJ_PARAMETER{$para_name}{'LIST'} };
                foreach (@list) { $text .= " $_ ,"; }
                S_w2log( 3, "    $para_name = LIST: ($text) \n" );
                @{ $return_all_hash{$para_name} } = @list;
            }
            elsif ( exists $TC_PRJ_PARAMETER{$para_name}{'HASH'} ) {
                %hash = %{ $TC_PRJ_PARAMETER{$para_name}{'HASH'} };
                while ( ( $key, $value ) = each %hash ) { $text .= " $key => $value ,"; }
                S_w2log( 3, "    $para_name = HASH: ($text) \n" );
                %{ $return_all_hash{$para_name} } = %hash;
            }
            else {
                S_set_error( " unexpected structure when reading project parameters", 21 );
                return;
            }
        }

        S_w2log( 3, "  return all project parameters in a hash \n" );
        return %return_all_hash;
    }

    unless ( defined($para_name) ) {
        S_set_error( "! too less parameters ! SYNTAX: read_project_parameters( \'parameter_name\' )", 110 );
        return;
    }
    unless ( exists $TC_PRJ_PARAMETER{$para_name} ) {
        S_set_error( " \n --> Project Parameter: $para_name doesnt exists ! \n --> TC has to decide if there's a problem...\n", 0 );
        return;
    }

    if ( exists $TC_PRJ_PARAMETER{$para_name}{'SCALAR'} ) {
        $scalar = $TC_PRJ_PARAMETER{$para_name}{'SCALAR'};
        S_w2log( 3, "   $para_name = $scalar \n" );
        return $scalar;
    }
    elsif ( exists $TC_PRJ_PARAMETER{$para_name}{'LIST'} ) {
        @list = @{ $TC_PRJ_PARAMETER{$para_name}{'LIST'} };
        foreach (@list) { $text .= " $_ ,"; }
        S_w2log( 3, "   $para_name = LIST: ($text) \n" );
        return @list;
    }
    elsif ( exists $TC_PRJ_PARAMETER{$para_name}{'HASH'} ) {
        %hash = %{ $TC_PRJ_PARAMETER{$para_name}{'HASH'} };
        while ( ( $key, $value ) = each %hash ) { $text .= " $key => $value ,"; }
        S_w2log( 3, "   $para_name = HASH: ($text) \n" );
        return %hash;
    }
    else {
        S_set_error( " unexpected structure when reading project parameters", 21 );
        return;
    }
}

=head2 S_read_public_variable

    ( $valid_flag , $return_value )= S_read_public_variable ( "MY_VARIABLE" );

    $valid_flag = 1 if $return_value valid
    $valid_flag = 0 if $return_value not valid

Reads the public variable value with key "MY_VARIABLE", that is already set using the API L</S_set_public_variable>

=cut

sub S_read_public_variable {

    my $var_name = shift;

    unless ( defined($var_name) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_read_public_variable ( name_of_variable );", 110 );
        return 0;
    }

    my $value;

    if ( defined $PUBLIC_VARS{$var_name} ) {
        $value = $PUBLIC_VARS{$var_name};
        S_w2log( 2, " S_read_public_variable: '$var_name' = '$value' \n" ) unless ref $value;
        S_w2log( 2, " S_read_public_variable: '$var_name' is a reference \n" ) if ref $value;
        return ( 1, $value );
    }
    else {
        S_w2log( 2, " S_read_public_variable: '$var_name' not defined \n" );
        return (0);
    }

}

=head2 S_read_testcase_parameter

    parameter_value_or_ref = S_read_testcase_parameter ( $parameter_name [, 'byref'] );

Returns the value of $parameter_name (scalar, list or hash) if found in testcase parameter file.

If $parameter_name doesn't exist, no error is set to allow optional parameters.

If a parameter is mandatory it has to be checked inside the testcase.

If 'byref' is given function returns the list reference for Lists and the hash reference for Hashes

=cut

sub S_read_testcase_parameter {
    my $para_name = shift;
    my $mode      = shift;

    my ( $scalar, @list, %hash, $text, $key, $value );
    $text = "";    # to remove "undefined" warnings

    unless ( defined($para_name) ) {
        S_set_error( "! too less parameters ! SYNTAX: read_tc_parameters( \'parameter_name\' )", 110 );
        return;
    }
    unless ( exists $TC_PARAMETER{$para_name} ) {
        S_w2log( 4, " S_read_testcase_parameter: $para_name doesnt exists (maybe optional) \n" );
        return;
    }

    if ( exists $TC_PARAMETER{$para_name}{'SCALAR'} ) {
        $scalar = $TC_PARAMETER{$para_name}{'SCALAR'};
        S_w2log( 2, "  S_read_testcase_parameter: $para_name = $scalar \n" );
        return $scalar;
    }
    elsif ( exists $TC_PARAMETER{$para_name}{'LIST'} ) {
        @list = @{ $TC_PARAMETER{$para_name}{'LIST'} };
        foreach (@list) { $text .= " $_ ,"; }
        S_w2log( 2, "  S_read_testcase_parameter: $para_name = LIST: ($text) \n" );
        return \@list if ( defined $mode && $mode =~ /byref/i );
        return @list;

    }
    elsif ( exists $TC_PARAMETER{$para_name}{'HASH'} ) {
        %hash = %{ $TC_PARAMETER{$para_name}{'HASH'} };
        while ( ( $key, $value ) = each %hash ) { $text .= " $key => $value ,"; }
        S_w2log( 2, "  S_read_testcase_parameter: $para_name = HASH: ($text) \n" );
        return \%hash if ( defined $mode && $mode =~ /byref/i );
        return %hash;
    }
    else {
        S_set_error( " unexpected structure when reading TC parameters", 21 );
        return;
    }
}

=head2 S_read_mandatory_testcase_parameter

    parameter_value_or_ref = S_read_mandatory_testcase_parameter ( $parameter_name [, $mode ] );

Works like L</S_read_testcase_parameter>, but throws an error if $parameter_name does not exist in the current parameter set.

Contrary to S_read_testcase_parameter, if $mode is not defined then by default it is 'byref'.

If $mode is 'byvalue' (in fact any string other than 'byref') then the direct value instead of a reference will be returned.

=cut

sub S_read_mandatory_testcase_parameter {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_read_mandatory_testcase_parameter ( $parameter_name [, $mode] )', @args );

    my $para_name = shift @args;
    my $mode      = shift @args;

    $mode = 'byref' if not defined $mode;

    my $tcpar_val = S_read_testcase_parameter_NOHTML( $para_name, 'byref' );    # read the ref just to test if the parameter is defined
    unless ( defined $tcpar_val ) {
        S_set_error( "Missing mandatory parameter $para_name \n", 110 );
        return;
    }

    return S_read_testcase_parameter( $para_name, $mode );
}

=head2 S_read_optional_testcase_parameter

	parameter_value_or_ref = S_read_optional_testcase_parameter( $parameter_name [, $mode, $default_value ] );

Works like L</S_read_testcase_parameter> and throws no error if $parameter_name does not exist in the current parameter set.

Contrary to S_read_testcase_parameter, if $mode is not defined then by default it is 'byref'.

If $mode is 'byvalue' (in fact any string other than 'byref') then the direct value instead of a reference will be returned.

Additionally to S_read_testcase_parameter you can define a default value that will be returned if $parameter_name does not exist in the current parameter set.
Note: $default_value will work for scalar parameters (always) or if 'byref' is set for list and hash parameters. 

=cut 

sub S_read_optional_testcase_parameter {

    my @args = @_;
    return unless S_checkFunctionArguments( 'S_read_optional_testcase_parameter ( $parameter_name [, $mode, $default_value_mix ] )', @args );

    my $para_name     = shift @args;
    my $mode          = shift @args;
    my $default_value = shift @args;

    $mode = 'byref' if not defined $mode;

    my $tcpar_val = S_read_testcase_parameter_NOHTML( $para_name, 'byref' );    # read the ref just to test if the parameter is defined
    if ( not defined $tcpar_val and defined $default_value ) {
        if ( $mode !~ /byref/i and ( ref $default_value eq 'ARRAY' or ref $default_value eq 'HASH' ) ) {
            S_set_error( "Default value given but not supported for ARRAY or HASH without using 'byref'. Consider using 'byref' as second argument.\n", 110 );
            return;
        }
        S_w2log( 2, " S_read_optional_testcase_parameter: '$para_name' not set. Use default '$default_value'\n", 'blue' );
        return $default_value;
    }

    return S_read_testcase_parameter( $para_name, $mode );

}

=head2 S_send_mail

  $return = S_send_mail ($given_sender, $subject, $given_message_text, $receipient1 [, $receipient2, ...]);

this function delivers a mail via SMTP to a list of receipients. You can use links and summary as shown below.

  example:
  $given_sender      = 'Frank.Boehm@de.bosch.com';
  $subject     = 'report link from LIFT';
  my $link = '\\\\'.$LIFT_config::LIFT_host."/$main::REPORT_PATH"."_result.html";
  $link =~ s/\:/\$/g;
  $message = "Test finshed with $main::CAMPAIGN_STATUS\n\nTest result link : $link\n\nthis is a generated message, please do not reply.";
  $receipient1 = 'Frank.Boehm@de.bosch.com';

  S_send_mail ($given_sender, $subject, $message, $receipient1);

sender has to be a valid mail address, if sender is empty (e.g. ''), AirbagsTurboLiFT.Support@in.bosch.com will be taken as sender

  Return : 
  	1 - successful 
  	0 - error 

=cut

sub S_send_mail {
    use Net::SMTP;

    # this function delivers a mail via SMTP to a list of receipients
    my $given_sender       = shift;
    my $subject            = shift;
    my $given_message_text = shift;
    my @receipients        = @_;

    unless (@receipients) {
        S_set_error( "! too less parameters ! SYNTAX: S_send_mail (sender, subject, given_message_text, receipient1, receipient2, ...)", 110 );
        return 0;
    }

    return 1 if $main::opt_offline;

    my $receipients_text = join( ';', @receipients );

    #    my $SMTP_Host  = 'rb-smtp-int.bosch.com'; # originally from STEPS
    my $SMTP_Host = 'mail.si.de.bosch.com';    # long name 'mail.si.de.bosch.com'
    my $account   = '';

    my $smtp = Net::SMTP->new(
        $SMTP_Host,
        Hello   => $account,
        offline => 0,
    );
    unless ($smtp) {
        S_set_error("Error while Net::SMTP->new( $SMTP_Host, Hello => $account, offline => 0");
        return;
    }

    my $used_sender;
    my $default_sender = 'AirbagsTurboLiFT.Support@in.bosch.com';

    if ( $given_sender eq '' ) {
        S_set_warning("given sender is empty, taking default sender '$default_sender'\n");
        $used_sender = $default_sender;
    }
    elsif ( $given_sender != /@.*bosch\.com$/ ) {
        S_w2log(" S_send_mail: use given sender : $given_sender \n");
        $used_sender = $given_sender;
    }
    elsif ( $given_sender !~ /@/ ) {
        S_set_warning("given sender '$given_sender' is not a mail address, adding \@bosch.com\n");
        $used_sender = $given_sender . '@bosch.com';
    }
    elsif ( $given_sender !~ /@.*bosch\.com$/ ) {
        S_set_warning("sender $given_sender is not a bosch address, taking default sender '$default_sender'\n");
        $used_sender = $default_sender;
    }
    else {
        S_set_error("Unexpected sender '$given_sender' ");
        return;
    }

    my $message_aref = [ "From: " . $used_sender . "\n", "To: " . $receipients_text . "\n", "Subject: " . $subject . "\n", "\n", $given_message_text ];

    S_w2log( 3, " S_send_mail : From = '$used_sender' \n" );
    S_w2log( 3, " S_send_mail : To = '@receipients' \n" );
    S_w2log( 4, " S_send_mail : Message = '$given_message_text' \n" );

    unless ( $smtp->mail($used_sender) )      { S_set_error("Error while smtp->mail($used_sender)"); return }
    unless ( $smtp->recipient(@receipients) ) { S_set_error("Error while smtp->recipient");          return }
    unless ( $smtp->data($message_aref) )     { S_set_error("Error while smtp->data");               return }
    unless ( $smtp->quit() )                  { S_set_error("Error while smtp->quit");               return }

    return 1;
}

=head2 S_set_error

    S_set_error ( [ $ERR_TEXT ] [, $ERR_CODE ] );

Writes an error text containing $ERR_TEXT, $ERR_CODE and the call stack to STDOUT,
standard logfile and HTML test case report.

If $ERR_CODE is not given, then $ERR_CODE = 999 (= unclassified error code).

If $ERR_TEXT is not given, then $ERR_TEXT = 'no error text was given'.

Sets system state for the execution engine depending on $ERR_CODE:

    System state is unchanged (no effect on verdict and execution) for $ERR_CODE = 0 (only a warning).
    System state = SYS_FAIL (current test case will become INCONC and test execution will be aborted) for those $ERR_CODE, that are defined in @SYS_FAIL_ERRORS.
    System state = TC_FAIL (current test case will become INCONC but test execution will be continued) for all other $ERR_CODE.

=cut

sub S_set_error {
    my $err_text = shift;    #optional
    my $err_code = shift;    #optional

    my $package = ( caller(1) )[0];
    my $file    = ( caller(1) )[1];
    my $line    = ( caller(1) )[2];
    my $sub     = ( caller(1) )[3];

    $package  = 'unknown'                 unless ( defined $package );
    $file     = 'unknown'                 unless ( defined $file );
    $line     = 'unknown'                 unless ( defined $line );
    $sub      = 'unknown'                 unless ( defined $sub );
    $err_text = 'no error text was given' unless ( defined $err_text );
    $err_code = 999                       unless ( defined $err_code );    # changed to error in rev. 2.63, before it was just a warning: $err_code = 0 unless (defined $err_code);
    $err_code = 0 if $noerrorCounter > 0;                                  # support of function calls with _NOERROR

    my $callStack = "";
    my $count     = 2;
    while ( defined( ( caller($count) )[3] ) and $count < 99 ) {
        $callStack .= " called by: " . ( caller($count) )[3] . "\n";
        $count++;
    }

    my $err_code_text;
    my $text;

    $err_text =~ s/[\s\n]+$//g;

    if ( $err_code == 0 ) {
        $text = "\n!--WARNING--! => $err_text {CODE: $err_code} <= !--WARNING--!\n packg\t: $package \n file \t: $file \n line \t: $line \n sub \t: $sub \n\n";
        print color 'cyan'  unless $main::opt_silent;
        print $text         unless $main::opt_silent;
        print color 'reset' unless $main::opt_silent;

        print LOG $text;
        $text =~ s/!--WARNING--! =>/<div class="messageheader">/g;
        $text =~ s/<= !--WARNING--!\s*\n/<\/div>/g;
        $text =~ s/[\s\n]+$//g;
        $text =~ s/^[\s\n]+//g;
        $text =~ s/\n/<BR>/g;
        push( @TC_HTML_TEXT, "<div class=\"warningmessage $package\">$text</div>\n" );
    }
    else {
        if ( defined $ALL_ERR_CODES ) {
            if ( defined $ALL_ERR_CODES->{$err_code} ) {
                $err_code_text = $ALL_ERR_CODES->{$err_code};
            }
            else {
                $err_code_text = "unclassified error code: $err_code";
                S_w2rep("!--UNCLASSIFIED ERROR--! => $err_text <= !--UNCLASSIFIED ERROR--!\n");
            }
        }

        $text = <<EOET;

!--ERROR--! => $err_text <= !--ERROR--!
 type     : $err_code_text {CODE: $err_code}
 package  : $package
 file     : $file
 line     : $line
 function : $sub
$callStack
EOET
        print color 'red on_white' unless $main::opt_silent;
        print $text                unless $main::opt_silent;
        print color 'reset'        unless $main::opt_silent;
        print LOG $text;
        $text =~ s/!--ERROR--! =>/<div class="messageheader">/g;
        $text =~ s/<= !--ERROR--!\s*\n/<\/div>/g;
        $text =~ s/[\s\n]+$//g;
        $text =~ s/^[\s\n]+//g;
        $text =~ s/\n/<BR>/g;
        push( @TC_HTML_TEXT, "<div class=\"errormessage $package\">$text</div>\n" );

        #set errorflag depending on caller and errorcode
        # tbd
        push( @ACTUAL_ERROR_CODES, $err_code );
        push( @TC_errors,          $err_code_text . '#' . $err_text );

        S_set_verdict(VERDICT_INCONC);

        S_set_sys_state(TC_FAIL);

        if ( not S_check_actual_error($err_code) ) {
            S_set_sys_state(SYS_FAIL);
        }
    }

    return 1;
}

=head2 S_set_project_info

    $return = S_set_project_info ( $project_info_href );

    Examples :
      
      S_set_project_info ( { 'ECU_SW_VERSION' => $ECU_SW_Version } );
      S_set_project_info ( { 'ECU_fingerprint' => $ECU_fingerprint } );

    The given keys are stored as project info labels.
    The given values are stored as project info values.
    
    With each call the elements will be collected. 
    Even multiple elements can be written in one call as key-value-pairs) 
    Nothing will be deleted, but values of the same label can be overwritten.
    internal storage is done via public variable 'PROJECT_INFO'    
    

   Note : Stored project info can be read back completely in one hash_ref with
   
    S_get_project_info();
    

=cut

sub S_set_project_info {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_set_project_info ( $project_info_href )', @args );

    my $project_info_href = shift @args;

    my ( $new_project_info, $valid_flag, $existing_project_info, );

    S_w2log( 4, " S_set_project_info: Reading already stored project data\n" );
    ( $valid_flag, $existing_project_info ) = S_read_public_variable("PROJECT_INFO");

    if ($valid_flag) {
        $new_project_info = $existing_project_info;
    }
    else {
        $new_project_info = {};
    }

    foreach my $project_info_label ( keys %$project_info_href ) {
        my $project_info_value = $project_info_href->{$project_info_label};
        S_w2log( 2, " S_set_project_info: Adding '$project_info_label' => '$project_info_value'\n" );
        $new_project_info->{$project_info_label} = $project_info_value;
    }

    #
    # set or overwrite stored "PROJECT_INFO"
    #
    S_set_public_variable( "PROJECT_INFO", $new_project_info );

    return 1;
}

=head2 S_get_project_info

    $project_info_href = S_get_project_info ( );
    
    Examples :
      
        $project_info_href = S_get_project_info ( );
      
        Note: all info are set by LIFT_exec_engine and PD_initCommunication() normally
              more individual project info can be added with S_set_project_info() 
      
        $project_info_href :
            {
                'ECU_fingerprint'       => ...,       # from  PD_initCommunication
                'ECU_SW_VERSION'        => ...,       # from  PD_initCommunication
                'ECU_AlgoParameter_ID'  => ...,       # from  PD_initCommunication
                'ProjectDescription'    => ...,       # from exec_engine / must be set as: LIFT_config::LIFT_ProjectDescription 
                'testlist'              => ...,       # from exec_engine
                'configuration'         => ...,       # from exec_engine
                'start_date'            => ...,       # from exec_engine
                'start_time'            => ...,       # from exec_engine
                'username'              => ...,       # from exec_engine
                'hostname'              => ...,       # from exec_engine
                'LIFT_version'          => ...,       # from exec_engine
                'LIFT_exec_engine'      => ...,       # from exec_engine
                'TT Number'             => ...,       # from exec_engine
                'HW Version'            => ...,       # from exec_engine
                'HW Serial Number'      => ...,       # from exec_engine
            }

        
=cut

sub S_get_project_info {

    my ( $valid_flag, $existing_project_info, $info_label, $info_value, );

    S_w2log( 4, " S_get_project_info: Reading stored project info\n" );
    ( $valid_flag, $existing_project_info ) = S_read_public_variable("PROJECT_INFO");

    unless ($valid_flag) {
        S_set_warning(" No PROJECT_INFO stored - nothing to be return");
        return;
    }

    S_w2log( 2, " S_get_project_info: Returning stored project info\n" );
    while ( ( $info_label, $info_value ) = each %$existing_project_info ) {
        S_w2log( 2, " S_get_project_info: $info_label => $info_value\n" );
    }

    return $existing_project_info;
}

=head2 S_set_warning

    S_set_warning ( [ $ERR_TEXT ] );

Calls S_set_error ( $ERR_TEXT , 0 ), which is only a warning and will not change the verdict.

=cut

sub S_set_warning {

    my $errorText = shift;

    my $status = S_set_error( $errorText, 0 );
    return $status;
}

=head2 S_set_public_variable

    $return = S_set_public_variable ( "MY_VARIABLE" , $value );

    $return = 1 if it's a new variable
    $return = 2 if it's an existing variable

Sets the value of public variable with key "MY_VARIABLE" to "$value", . The $value can be a scalar, hash reference, array reference.

=cut

sub S_set_public_variable {

    my $var_name  = shift;
    my $var_value = shift;

    unless ( defined($var_value) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_set_public_variable ( name_of_variable , value );", 110 );
        return 0;
    }

    my $old_value;

    if ( defined $PUBLIC_VARS{$var_name} ) {
        $old_value = $PUBLIC_VARS{$var_name};
        S_w2log( 3, " S_set_public_variable: '$var_name' = '$old_value' (old) -> '$var_value' (new) \n" ) unless ref $var_value;
        S_w2log( 3, " S_set_public_variable: '$var_name' to new value (reference) \n" ) if ref $var_value;
        $PUBLIC_VARS{$var_name} = $var_value;
        return 2;
    }
    else {
        S_w2log( 3, " S_set_public_variable: '$var_name' = '$var_value' (new) \n" ) unless ref $var_value;
        S_w2log( 3, " S_set_public_variable: '$var_name' to new value (reference) \n" ) if ref $var_value;
        $PUBLIC_VARS{$var_name} = $var_value;
        return 1;
    }

}

=head2 S_set_verdict

    $success = S_set_verdict ( $given_verdict );

Sets new verdict $given_verdict for the current testcase (uses global variable $VERDICT).

Values for verdict can be: 'VERDICT_NONE', 'VERDICT_PASS', 'VERDICT_INCONC', 'VERDICT_FAIL', 'VERDICT_BLOCKED' 
with increasing verdict weight.

Note that during a testcase the verdict can only get worse = higher verdict weight (e.g. a verdict can be set from
'VERDICT_PASS' to 'VERDICT_FAIL' but not vice versa.

=cut

sub S_set_verdict {
    my $given_verdict = shift;

    #STEP set verdict color
    my $verdict_color = "black";
    $verdict_color = "green"  if $given_verdict eq VERDICT_PASS;
    $verdict_color = "red"    if $given_verdict eq VERDICT_FAIL;
    $verdict_color = "purple" if $given_verdict eq VERDICT_INCONC;
    $verdict_color = "blue"   if $given_verdict eq VERDICT_NONE;
    $verdict_color = "blue"   if $given_verdict eq VERDICT_BLOCKED;

    my $tc_id = '';
    $tc_id = $main::CURRENT_TC if $main::CURRENT_TC;

    #STEP error and return if $given_verdict is not defined
    unless ( defined($given_verdict) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_set_verdict(new_verdict)", 110 );
        return 0;
    }

    #STEP error and return if $given_verdict is not one of the valid verdicts
    unless ( grep( {/$given_verdict/} @valid_verdicts ) ) {
        S_set_error( "given verdict $tc_id : $given_verdict not valid", 109 );    # 109 -> wrong parameters
        return 0;
    }

    #STEP return if $given_verdict is same as current verdict
    my $old_verdict = $VERDICT;
    if ( $old_verdict eq $given_verdict ) {
        S_w2log( 1, "VERDICT change $tc_id : $given_verdict (was already set)\n", $verdict_color );
        return 1;
    }

    #STEP determine weight for old and new verdict
    my $verdictWeights_href;
    foreach my $index ( 0 .. @valid_verdicts - 1 ) {
        my $verdict = $valid_verdicts[$index];
        $verdictWeights_href->{$verdict} = $index;
    }
    my $given_verdict_weight = $verdictWeights_href->{$given_verdict};
    my $old_verdict_weight   = $verdictWeights_href->{$old_verdict};

    #STEP message and return if weight of new verdict is <= weight of old verdict and system state ne SYS_READY
    if ( $given_verdict_weight <= $old_verdict_weight and $SYS_STATE ne SYS_READY ) {
        S_w2log( 1, "VERDICT change $tc_id : $given_verdict (NOT ACCEPTED)\n", $verdict_color );
        return 1;
    }

    #IF offline mode?
    if ($main::opt_offline) {

        #IF-YES-START

        #STEP set new verdict only if it is VERDICT_INCONC or if system state eq SYS_READY (needed to initialize new test with NONE)
        if ( $given_verdict eq VERDICT_INCONC or $SYS_STATE eq SYS_READY ) {
            S_w2log( 1, "VERDICT change $tc_id : $given_verdict (verdict change)\n", $verdict_color, $given_verdict );
            $VERDICT = $given_verdict;
        }
        else {
            S_w2log( 1, "no VERDICT change due to offline MODE\n", "blue" );
        }

        #IF-YES-END
    }

    #IF-NO-START
    #IF noverdict option set?
    elsif ( $noverdictCounter > 0 ) {

        #IF-YES-START
        #STEP set new verdict only if it is VERDICT_INCONC
        if ( $given_verdict eq VERDICT_INCONC ) {
            S_w2log( 1, "VERDICT change $tc_id : $given_verdict (verdict change)\n", $verdict_color, $given_verdict );
            $VERDICT = $given_verdict;
        }
        else {
            S_w2log( 1, "no VERDICT change due to noverdictFlag\n", "blue" );
        }

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #STEP SUCCESSFUL VERDICT CHANGE
        S_w2log( 1, "VERDICT change $tc_id : $given_verdict (verdict change)\n", $verdict_color, $given_verdict );
        $VERDICT = $given_verdict;

        #IF-NO-END
    }

    #IF-NO-END

    #STEP return 1
    return 1;
}

=head2 S_determine_overall_verdict

    $newOverallVerdict = S_determine_overall_verdict( $oldOverallVerdict, $newVerdict );

Determines the new overall verdict ($newOverallVerdict) from an old overall verdict ($oldOverallVerdict) and a new verdict ($newVerdict).

$newOverallVerdict is set to $newVerdict only if the weight of $newVerdict > weight of $oldOverallVerdict.
Otherwise $newOverallVerdict = $oldOverallVerdict.

Values for verdict can be: 'VERDICT_NONE', 'VERDICT_PASS', 'VERDICT_INCONC', 'VERDICT_FAIL', 'VERDICT_BLOCKED' with increasing weight.

If any other value is input in this function then a real verdict has always higher weight.

B<Arguments:>

=over

=item $oldOverallVerdict 

Old overall verdict.

=item $newVerdict 

New verdict.

=back

B<Return Value:>

=over

=item $newOverallVerdict 

New overall verdict of the.

=back

B<Examples:>

    $newOverallVerdict = S_determine_overall_verdict( VERDICT_PASS, VERDICT_FAIL );   # $newOverallVerdict = VERDICT_FAIL
    $newOverallVerdict = S_determine_overall_verdict( VERDICT_FAIL, VERDICT_INCONC ); # $newOverallVerdict = VERDICT_FAIL

B<Notes:> 

This function does B<not> set the test case verdict.

=cut

sub S_determine_overall_verdict {
    my $oldOverallVerdict = shift;
    my $newVerdict        = shift;

    my $verdictWeights_href;
    foreach my $index ( 0 .. @valid_verdicts - 1 ) {
        my $verdict = $valid_verdicts[$index];
        $verdictWeights_href->{$verdict} = $index;
    }

    my $oldVerdictWeight = $verdictWeights_href->{$oldOverallVerdict} // -1;
    my $newVerdictWeight = $verdictWeights_href->{$newVerdict}        // -1;

    my $newOverallVerdict = $oldOverallVerdict;
    if ( $newVerdictWeight > $oldVerdictWeight ) {
        $newOverallVerdict = $newVerdict;
    }

    return $newOverallVerdict;
}

=head2 S_speak

    my $stream_number = S_speak ( $text [, $waiting_enabled ] );

Speaks the text in English.
If $waiting_enabled is > 0 then the function waits until the text is spoken.
Otherwise the function does not wait until the text is spoken.


    Return : stream number -> see docu of MS below 

Microsoft Speech API 5.3

Object: SpVoice 
Speak Method

The Speak method initiates the speaking of a text string, a text file, an XML file, or a wave file by the voice.
The Speak method can be called synchronously or asynchronously. 
When called synchronously, the method does not return until the text has been spoken; when called asynchronously, it returns immediately, and the voice speaks as a background process.
When synchronous speech is used in an application, the applications execution is blocked while the voice speaks, and the user is effectively locked out. This may be acceptable for simple applications, or those with no graphical user interface (GUI), but when sophisticated user interaction is intended, asynchronous speaking will generally be more appropriate.

SpVoice.Speak(
     Text As String,
     [Flags As SpeechVoiceSpeakFlags = SVSFDefault]
) As Long

Parameters

Text
    The text to be spoken, or if the SVSFIsFilename flag is included in the Flags parameter, the path of the file to be spoken.
Flags
    [Optional] Flags. Default value is SVSFDefault. 


Return Value

A Long variable containing the stream number. When a voice enqueues more than one stream by speaking asynchronously, the stream number is necessary to associate events with the appropriate stream.

Remarks

The Speak method inserts a stream into the text-to-speech (TTS) engines queue, and returns a stream number, assigned by the engine. This distinguishes the stream from other streams in the queue. This number is a temporary identifier which functions like an index into the TTS queue. The first stream spoken into an empty queue will always have a stream number of 1.

A voice object can enqueue numerous streams, and each of these streams can generate events. SpVoice events always return the stream number as a parameter. If an application saves the stream numbers of the streams it enqueues, events can be associated with the proper stream. 

=cut

sub S_speak {

    my $text            = shift;
    my $waiting_enabled = shift;

    unless ( defined($text) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_speak ( \$text [, \$waiting_enabled ] )", 110 );
        return 0;
    }
    return 1 if $main::opt_offline;

    unless ( defined($voice) ) {
        $voice = Win32::OLE->new('SAPI.SpVoice');
    }

    S_w2log( 4, " S_speak say: $text\n" );
    my $flag;
    if ($waiting_enabled) {

        # waiting until text is spoken if $waiting_enabled
        $flag = 2;
    }
    else {
        $flag = 3;
    }

    S_w2log( 4, " S_speak: calling SAPI.SpVoice -> Speak( $text, $flag ) \n" );
    my $stream_number = $voice->Speak( $text, $flag );
    unless ($stream_number) {
        S_set_error("didnt get stream number from Speak - method of SAPI.SpVoice object");
        return;
    }

    return $stream_number;
}

=head2 S_user_action (blocking)

    $response = S_user_action ( $text [, 'Ok'|'YesNo' ] );

Opens a Window and asks user to do something. Test is halted until user presses a button.

returns button text in lowercase or 'error' in case of error or 'offline' in offline mode

=cut

sub S_user_action {

    my $text = shift;
    my $type = shift;

    my ($response);
    my %resp_map = (
        0 => 'error',
        1 => 'ok',
        2 => 'cancel',
        3 => 'abort',
        4 => 'retry',
        5 => 'ignore',
        6 => 'yes',
        7 => 'no'
    );

    unless ( defined($text) ) {
        S_set_error( "! too less parameters ! SYNTAX:  \$response = S_user_action ( \$text [, 'Ok'|'YesNo' ] );", 110 );
        return 'error';
    }

    chomp($text);

    return 'offline' if $main::opt_offline;

    if ( not defined $type or $type =~ /Ok/i ) {
        S_w2log( 1, " S_user_action (Ok) : $text .. \n" );
        $response = Win32::MsgBox( "$text", ( 0 + 32 ), 'user inter-action required' );
        $response = $resp_map{$response};

        S_w2log( 1, " $response pressed \n " );
        return $response;
    }
    elsif ( $type =~ /YesNo/i ) {
        S_w2log( 1, " S_user_action (YesNo) : $text .. \n" );
        $response = Win32::MsgBox( "$text", ( 4 + 32 ), 'user inter-action required' );
        $response = $resp_map{$response};
        S_w2log( 1, " $response pressed \n " );
        return $response;
    }
    else { S_set_error( "Wrong Parameter: only 'Ok' or 'YesNo' are allowed", 109 ); return 'error' }
}

=head2 S_w2log

    S_w2log ( $staticLevel , $text , [$color, $referenceName] );

Writes B<$text> to STDOUT, to the plain text log file (_main__result_log.txt) and to the html log file for the current test case (*.html).

If B<$color> is given then the text in STDOUT and in the html log file is written in the corresponding color.
For STDOUT only green, red, yellow and cyan are supported colors.
For the plain text log file, the current time and date is added to $text.
For the html log file, the time since start of the test case is added to $text.
For the html log file, a log-level and module is added as class attribute, e.g. <div class="loglevel2 LIFT_PD">.
The html report can later be filtered for loglevels, element type, library module
e.g. show only entries with loglevel 3 + LIFT_PD + TEXT

B<'$staticLevel'> can be user defined log type. Such as teststep, w2rep, 0-5 or combination of TEXT, HTML and CONSOLE constants.

If B<$referenceName> is given then a HTML reference (like anchor/bookmark) will be added <A NAME = "$referenceName" >.
The link to this anchor/bookmark will be placed directly below the header of the html testcase report ("Quick Links"),
To move directly to link, click on it and jump to the bookmark.

B<Note ::> To traverse through respective bookmark link, then that level should select in loglevel section.

B<$report_log_level> is the I<default structure>.

    $report_log_level =  {
             'w2rep' => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
             '1'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
             '2'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
             '3'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
             '4'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
             '5'     => { 'TEXT' => 1, 'HTML' => 0, 'CONSOLE' => 0 },
        };

For each log-level, based on the 1 and 0 mentioned for 'TEXT', 'HTML' and 'CONSOLE'. Given Text will display.

B<'TEXT'>    :: represents Text log file (_main__result_log.txt)

B<'HTML'>    :: represents HTML report

B<'CONSOLE'> :: represents STDOUT

In above hash for log-level 1, 1 is given for 'TEXT', 'HTML' and 'CONSOLE'. So Text will appear on all three.

In above hash for log-level 5, 1 is given for 'TEXT'. So log info will appear in only Text log file (_main__result_log.txt).

For w2rep, log info appears in 'TEXT', 'HTML' and 'CONSOLE'

B<HTML report structure in project defaults>

    $Defaults = {

        # This section in optional.
        # If any/all of subsections are not defined then default action will applicable

        # LOGLEVELS            =>   As defined in default structure is shown
        # LIB_SELECTION        :    All testcase related modules text information are shown
        # LOGLEVEL_SELECTION   :    1, 2, 3, w2rep, teststep, warningmessage levels are shown
        # ELEMENT_SELECTION    :    Table, Graphics, TCtext, TCtime are shown

        'REPORTING' => {

            # Loglevels where the testcase text to be appeared, 1 or 0 defines print or not in respective locations
            # 'TEXT'     :    _main__result_log.txt
            # 'HTML'     :    HTML report
            # 'CONSOLE'  :    STDOUT

            'HTML_FILTER_USE' => 0, # 1- To use new HTML filtering format, 0 - Old format
            
            'LOGLEVELS' => {
                             'w2rep' => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 }, # testcase text prints in  'TEXT', 'HTML', 'CONSOLE'
                             '1'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 }, # testcase text prints in  'TEXT', 'HTML', 'CONSOLE'
                             '2'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 }, # testcase text prints in  'TEXT', 'HTML'
                             '3'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 }, # testcase text prints in  'TEXT', 'HTML'
                             '4'     => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 }, # testcase text prints in  'TEXT', 'HTML'
                             '5'     => { 'TEXT' => 1, 'HTML' => 0, 'CONSOLE' => 0 }, # testcase text prints in  'TEXT'
            },

            # While generation of HTML report, default test information appears as per given selection for library modules.
            # 'display' : 1 says show while generation of testreport
            # 'display' : 0 says hide while generation of testreport
            # 'hide_from_filter' : 1 says hides module from filtering option

            'LIB_SELECTION' => {
                                 'LIFT_POWER'   => { 'display' => 1 }, # show
                                 'LIFT_sVTT'    => { 'display' => 1 }, # show
                                 'LIFT_PD'      => { 'display' => 1 }, # show
                                 'LIFT_NIDAQ'   => { 'display' => 0 }, # hide
                                 'LIFT_general' => { 'display' => 1, 'hide_from_filter' => 0 },   # hide, hide this module from filtering options
            },

            # While generation of HTML report, default test information appears as per given selection for loglevels.
            # 'display' : 1 says show while generation of testreport
            # 'display' : 0 says hide while generation of testreport

            'LOGLEVEL_SELECTION' => {
                                      'w2rep'    => { 'display' => 1 }, #show
                                      '1'        => { 'display' => 1 }, #show
                                      '2'        => { 'display' => 1 }, #show
                                      '3'        => { 'display' => 0 }, #hide
                                      '4'        => { 'display' => 0 }, #hide
                                      '5'        => { 'display' => 0 }, #hide
            },

            # While generation of HTML report, default test information appears as per given selection for element type.
            # 'display' : 1 says show while generation of testreport
            # 'display' : 0 says hide while generation of testreport

            'ELEMENT_SELECTION' => {
                                     'TABLE'    => { 'display' => 0 }, #hide
                                     'GRAPHICS' => { 'display' => 0 }, #hide
                                     'TEXT'   => { 'display' => 1 }, #show
                                     'TIME'   => { 'display' => 1 }, #show
            }
        },

B<Note ::> If any of log levels which is in default structure is not re-defined in project defaults, then default information will be considered.

B<Examples of Calling S_W2log function>

    S_w2log(1, "Level 1\n" ,'red');
    S_w2log(2, "Level 2\n" ,'green',"Ref name log level 2");
    S_w2log(3, "Level 3\n" ,'yellow',"Ref name log level 3");
    S_w2log(4, "Level 4\n" ,'cyan',"Ref name log level 4");
    S_w2log(5, "Level 5\n" ,'green',"Ref name log level 5");
    S_w2log('teststep', "Level teststep\n" ,'cyan',"Ref name log level teststep");
    S_w2log(TEXT, "print to TEXT \n");
    S_w2log(HTML, "print to HTML \n", 'red');
    S_w2log(CONSOLE, "print to CONSOLE \n",'Cyan');
    S_w2log(TEXT | HTML, "print to TEXT, HTML \n",'Green');
    S_w2log(HTML | CONSOLE, "print to HTML, CONSOLE \n",'yellow');
    S_w2log(TEXT | CONSOLE, "print to TEXT, CONSOLE \n",'red');
    S_w2log(TEXT | HTML | CONSOLE, "print to TEXT, HTML, CONSOLE \n",'cyan',"Ref name log level THC");

=cut

sub S_w2log {
    my @args = @_;

    # Do not use S_checkFunctionArguments in S_w2log because S_w2log is used so many times in the engine and
    # S_checkFunctionArguments adds way too much overhead. Furthermore using S_checkFunctionArguments in S_w2log
    # can lead to an endless loop: S_checkFunctionArguments -> S_set_error -> S_w2rep -> S_w2log -> S_checkFunctionArguments

    my $staticLevel   = shift @args;
    my $text          = shift @args;
    my $color         = shift @args;
    my $referenceName = shift @args;

    if ( not defined $staticLevel or not defined $text ) {
        S_set_error( "Arguments \$staticLevel and \$text are mandatory, but at least one of them is not given (undefined) is the actual call.", 110 );
        return 0;
    }

    my $package = (caller)[0];

    unless ( $package eq 'main' ) {
        unless ( grep { /^$package$/ } @report_level_library ) {
            push( @report_level_library, $package );
        }
    }

    my $logLevel       = undef;
    my $log_level_href = ();

    # Activate memory logging if the associated exec option 'Log_LiftProcessMemory_in_S_w2log_Level' is defined
    # and $staticLevel is less or equal than given $logMemoryLogLevel.
    # This feature is not documented in the API documentation and only for debugging of memory problems.
    my $logMemoryLogLevel = $main::LIFT_EXEC_OPTIONS_href->{'Log_LiftProcessMemory_in_S_w2log_Level'};
    if ( defined $logMemoryLogLevel ) {
        LogLiftProcessMemory( $logMemoryLogLevel, $staticLevel );
    }

    #Default Report Log Level
    $report_log_level = {

        # teststep is HTML stuff..
        #    will be always printed to TEXT and CONSOLE by teststep functions themself
        #      and in special form to HTML report by current function call
        'teststep'       => { 'TEXT' => 0, 'HTML' => 1, 'CONSOLE' => 0 },    # NEVER CHANGE IT
        'warningmessage' => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
        'w2rep'          => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
        '1'              => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1 },
        '2'              => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
        '3'              => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
        '4'              => { 'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 0 },
        '5'              => { 'TEXT' => 1, 'HTML' => 0, 'CONSOLE' => 0 },
    };

    #This will execute when the log level are in combination of TEXT, HTML and CONSOLE constants
    if ( ( $staticLevel =~ /^\d+$/ ) && ( $staticLevel >= 16 ) ) {

        # Check for Constant TEXT is given in static level and prints in _main__result_log.txt
        S_print2text($text) if ( TEXT & $staticLevel );

        # Check for Constant HTML is given in static level and prints in HTML report
        S_print2report( "3 $package", $text, $color, $referenceName ) if ( HTML & $staticLevel );

        # Check for Constant CONSOLE is given in static level and prints in STDOUT
        S_print2console( $text, $color ) if ( CONSOLE & $staticLevel and not $main::opt_silent );
    }
    else {
        #Checks for user defined log level hash in project defaults
        if ( defined $main::ProjectDefaults->{'REPORTING'}{'LOGLEVELS'} && ref( $main::ProjectDefaults->{'REPORTING'}{'LOGLEVELS'} ) eq 'HASH' ) {
            my $pjc_report_level = $main::ProjectDefaults->{'REPORTING'}{'LOGLEVELS'};

            # Updates the Default Report Log Level with project defaults log level
            foreach my $level ( keys %$pjc_report_level ) {
                $report_log_level->{$level} = $pjc_report_level->{$level};
            }
        }

        #Check static level is available in default report log level
        my @log_keys = keys(%$report_log_level);
        unless ( grep { /$staticLevel/i } @log_keys ) {
            S_print2report( "1 $package", "Given $staticLevel log level is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}!! \n", 'red' );
            S_print2text("Given $staticLevel log level is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}!! \n");
            return 0;
        }

        #Checking for TEXT HTML and CONSOLE are defined or not
        foreach my $level_name ( keys %$report_log_level ) {
            if ( !defined $report_log_level->{$level_name}{'TEXT'} ) {
                S_print2report( "1 $package", " For loglevel $level_name, TEXT is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}. TEXT should be either 0 or 1 \n", 'red' );
                S_print2text(" For loglevel $level_name, TEXT is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}. TEXT should be either 0 or 1 \n");
                return 0;
            }
            if ( !defined $report_log_level->{$level_name}{'HTML'} ) {
                S_print2report( "1 $package", " For loglevel $level_name, HTML is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}. HTML should be either 0 or 1 \n", 'red' );
                S_print2text(" For loglevel $level_name, HTML is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}. HTML should be either 0 or 1 \n");
                return 0;
            }
            if ( !defined $report_log_level->{$level_name}{'CONSOLE'} ) {
                S_print2report( "1 $package", " For loglevel $level_name, CONSOLE is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}. CONSOLE should be either 0 or 1 \n", 'red' );
                S_print2text(" For loglevel $level_name, CONSOLE is not defined  in ProjectDefaults->{'REPORTING'}{'LOGLEVELS'}. CONSOLE should be either 0 or 1 \n");
                return 0;
            }
        }

        $log_level_href = $report_log_level->{$staticLevel};

        #Printing Given text for given log level and log type
        if ( $log_level_href->{'TEXT'} == 1 ) {
            S_print2text($text);
        }
        if ( $log_level_href->{'HTML'} == 1 ) {
            S_print2report( "$staticLevel $package", $text, $color, $referenceName );
        }
        if ( $log_level_href->{'CONSOLE'} == 1 ) {
            if ( not $main::opt_silent ) {
                S_print2console( $text, $color );
            }
        }
    }

    return 1;
}

sub LogLiftProcessMemory {
    my $logMemoryLogLevel = shift;
    my $staticLevel       = shift;

    my $level2number_href = {
        'teststep' => -2,
        'w2rep'    => -1,
    };

    $logMemoryLogLevel = $level2number_href->{$logMemoryLogLevel} if defined $level2number_href->{$logMemoryLogLevel};
    $staticLevel       = $level2number_href->{$staticLevel}       if defined $level2number_href->{$staticLevel};

    return 0 if $staticLevel > $logMemoryLogLevel;

    S_get_LiftProcessMemory();
    return 1;
}

=head2 S_w2rep

    S_w2rep ( $text , [color, $referenceName] );

Writes $text to STDOUT, standard logfile and standard report file in the same way as S_w2log.

Only for the html log file a special log-level is added as class attribute: <div class="w2rep">.
In the html report entries with loglevel "w2rep" will always be displayed.

    S_w2rep("Testing write to report \n", 'cyan');
    S_w2rep("Testing write to report \n", 'blue', "test of reference name w2rep");

=cut

sub S_w2rep {

    my @args = @_;

    # Do not use S_checkFunctionArguments in S_w2rep because S_w2rep is used so many times in the engine via S_set_error and
    # S_checkFunctionArguments adds way too much overhead.

    my $text          = shift @args;
    my $color         = shift @args;
    my $referenceName = shift @args;

    return S_w2log( 'w2rep', $text, $color, $referenceName );
}

=head2 S_wait_ms

    S_wait_ms ( $WAIT_TIME [,$comment] );

Pauses the system for $WAIT_TIME milliseconds.

$WAIT_TIME can be either a number or a symbolic name that is defined in $main::ProjectDefaults->{'TIMER'}.

$WAIT_TIME must be >= 0 ! $WAIT_TIME 0 leads to a warning.

$comment is written to the test report. This field is optional.

Note that LIFT is not a realtime system, but running on Windows, so the accuracy and the smallest possible value of wait time will depend on the
system on which LIFT is running and its current load.

Typically a given wait time of < 2ms will be probably longer in reality.

=cut

sub S_wait_ms {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_wait_ms ( $WAIT_TIME [,$comment] )', @args );

    my $given_time = shift @args;
    my $comment    = shift @args;

    my $time;
    my $mapped_time_flag = 1;

    if ( not $time = $main::ProjectDefaults->{'TIMER'}{$given_time} ) {
        $mapped_time_flag = 0;
        $time             = $given_time;
    }

    # e.g. 0.2e3 = 200 ms
    unless ( $time =~ /^[0-9eE\+\.]+$/ ) {
        S_set_error( "wrong parameter at S_wait_ms($given_time) ! time must be a number >= 0 !", 109 );
        return 0;
    }

    $time = $time / 1000;

    # enclose the comment with square brackets, if comment is provided
    $comment = "[" . $comment . "]" if ( defined $comment );

    # if comment is not given, say it as empty ("")
    $comment = "" unless ( defined $comment );

    if ($mapped_time_flag) {
        S_w2log( 3, " S_wait_ms : $given_time (" . ( $time * 1000 ) . ") ms $comment\n" );
    }
    else {
        S_w2log( 3, " S_wait_ms : " . ( $time * 1000 ) . " ms $comment\n" );
    }

    return 1 if ( $main::opt_offline or $main::opt_simulation );
    if ( $time <= 0 ) {
        S_w2rep( "WARNING: waittime is 0 !\n", "red" );
        return 1;
    }

    if ( $time < 5 ) {
        select( undef, undef, undef, $time );    #sleep for X ms
    }
    else {
        local $| = 1;                            # to enable autoflush to make print lines with \r visible

        my $printLine;
        my $initialTime_sec = $time - int($time);
        select( undef, undef, undef, $initialTime_sec );
        foreach my $remaining_time_sec ( reverse 1 .. int($time) ) {
            $printLine = sprintf( " S_wait_ms: time remaining  -- %.0f seconds --  \r", $remaining_time_sec );
            S_print2console($printLine);
            select( undef, undef, undef, 1 );    #sleep for 1 sec
        }
        $printLine = sprintf( " S_wait_ms: finished waiting %.1f seconds --           \n", $time );
        S_print2console($printLine);
        S_w2log( 3, " S_wait_ms : " . ( $time * 1000 ) . " ms finished                    \n" );
        local $| = 0;                            # to disable autoflush again (default)
    }

    return 1;
}

=head2 S_set_timer_zero

    S_set_timer_zero ( [ $TIMER_NAME ] );
    
Sets the scheduler timer with the name $TIMER_NAME to zero.
This is a precondition for using the function S_wait_ms_until and S_read_timer.
If no $TIMER_NAME is given then the default timer ('timer_default') is set to zero.

=cut

sub S_set_timer_zero {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_set_timer_zero ( [ $TIMER_NAME ] )', @args );

    my $timer_name = shift @args;

    unless ( defined($timer_name) ) {
        $timer_name = 'timer_default';
    }

    S_w2log( 3, "S_set_timer_zero: setting scheduler timer '$timer_name' to zero...\n" );
    my $time_zero = Win32::GetTickCount();

    $timer_href->{$timer_name} = $time_zero;

    return 1;
}

=head2 S_wait_until_timer_ms

    S_wait_until_timer_ms ( $TIME_VALUE , [ $TIMER_NAME ] );
    
Waits until $TIME_VALUE ms have passed after having set the timer $TIMER_NAME
to zero (by using the function S_set_timer_zero).
If no $TIMER_NAME is given then the default timer ('timer_default') is used.
If $TIME_VALUE ms have already passed when calling this function then a warning
is given and no wait is performed.

This function shall be used to synchronize actions with other manipulations
or measurements (e.g. line manipulations, reading of lamps).

=cut

sub S_wait_until_timer_ms {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_wait_until_timer_ms ( $TIME_VALUE , [ $TIMER_NAME ] )', @args );

    my $time_value = shift @args;
    my $timer_name = shift @args;

    unless ( defined($timer_name) ) {
        $timer_name = 'timer_default';
    }
    S_w2log( 3, "S_wait_until_timer_ms: waiting until scheduled time $time_value is reached for timer '$timer_name'...\n" );
    if ( not defined $timer_href->{$timer_name} ) {
        S_set_error( " Timer '$timer_name' has not been set to zero before. Please use S_set_timer_zero before.", 114 );
        return 0;
    }
    my $T_now = Win32::GetTickCount();
    my $wait_time = $time_value - ( $T_now - $timer_href->{$timer_name} );
    if ( $wait_time > 0 ) {
        S_wait_ms($wait_time);
    }
    else {
        $wait_time *= -1;
        S_set_warning("No wait because we are $wait_time ms after scheduled time of timer $timer_name");
    }
    return $wait_time;
}

=head2 S_read_timer_ms

    $time = S_read_timer_ms ( [ $TIMER_NAME ] );

Returns runtime of $TIMER_NAME after having set the timer $TIMER_NAME
to zero (by using the function S_set_timer_zero).
If no $TIMER_NAME is given then the default timer ('timer_default') is used.

=cut

sub S_read_timer_ms {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_read_timer_ms ( [ $TIMER_NAME ] )', @args );

    my $timer_name = shift @args;

    unless ( defined($timer_name) ) {
        $timer_name = 'timer_default';
    }

    if ( not defined $timer_href->{$timer_name} ) {
        S_set_error( " Timer '$timer_name' has not been set to zero before. Please use S_set_timer_zero before.", 114 );
        return 0;
    }

    my $T_now = Win32::GetTickCount();
    my $time  = ( $T_now - $timer_href->{$timer_name} );

    return $time;
}

=head2 S_TableCreate

    $tableObject = S_TableCreate($header_aref [, $data_aref, $tableType]);

Creates a Data::Table object with table headers defined in $header_aref and optional data defined in $data_aref.
The table data in $data_aref is either given row-wise (default, $tableType = 'row-wise') or column-wise ($tableType = 'column-wise').
$header_aref is a simple array ref of scalars that defines the header cells of the table.
$data_aref is an array ref of array refs. 
For row-wise data all inner array refs must have the same length as $header_aref.
For column-wise data the outer array ref must have the same length as $header_aref.

The Data::Table package can be used if the same table shall be output to the text log file and to the html log file.
However there are limitations for the html output: highlighting of single cells or lines is not possible.
If highlighting in html is required then the package HTML::Table is better, however output as csv is not supported by HTML::Table.

Examples:

    $tableObject = S_TableCreate(['a', 'b', 'c']);                                         # only header given
    $tableObject = S_TableCreate(['a', 'b', 'c'], [ [1,2,3], [4,5,6] ]);                   # data row-wise
    $tableObject = S_TableCreate(['a', 'b', 'c'], [ [1,4], [2,5], [3,6] ], 'column-wise'); # same data, column-wise

Note : 

Using "\n" in data records don't create line breaks. 
Hence, use <br> tag to have line breaks inside the data cell. It will be reflected only in HTML report while it prints the tag as it is on the console and text log file.

Example :
 
$success = S_TableCreate(["Turbo<br>Lift"]); #prints "Turbo" in the first line and "Lift" in the next line inside the cell.

=cut

sub S_TableCreate {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_TableCreate($header_aref [, $data_aref, $tableType])', @args );

    my $header_aref = shift @args;
    my $data_aref   = shift @args;
    my $tableType   = shift @args;

    S_w2log( 4, "S_TableCreate: Creating a new table object.\n" );

    $data_aref = [] if not defined $data_aref;

    $tableType = 'row-wise' if not defined $tableType;

    my $typeValue;
    if ( $tableType =~ /^row/i ) {
        $typeValue = 0;
    }
    elsif ( $tableType =~ /^column/i ) {
        $typeValue = 1;
    }
    else {
        S_set_error( "Given value for argument '\$tableType' is '$tableType', but it must be either 'row-wise' or 'column-wise'", 114 );
        return;
    }

    S_w2log( 5, "S_TableCreate: Table type is $tableType.\n" );

    my $tableObject = eval { new Data::Table( $data_aref, $header_aref, $typeValue ); };
    if ($@) {
        S_set_error( "Could not create Data::Table object: $@", 114 );
        return;
    }

    return $tableObject;
}

=head2 S_Table2csv

    $csvString = S_Table2csv($tableObject [, $delimiter]);

Converts the Data::Table object $tableObject (created by S_TableCreate) to a csv string with delimiter character $delimiter (default: ,).

Example:
    
    $csvString = S_Table2csv($tableObject, ';');

=cut

sub S_Table2csv {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_Table2csv($tableObject_mix [, $delimiter])', @args );

    my $tableObject = shift @args;
    my $delimiter   = shift @args;

    S_w2log( 4, "S_Table2csv: Creating a csv string from the table object.\n" );

    my $csvString = eval { $tableObject->csv( 1, { delimiter => $delimiter } ); };
    if ($@) {
        S_set_error( "Could not create csv string from Data::Table object: $@", 114 );
        return;
    }

    return $csvString;
}

=head2 S_TableAddRow

    $success = S_TableAddRow($tableObject, $row_aref [, $rowIndex]);

Adds 1 row of data ($row_aref) to the table $tableObject. If $rowIndex is not defined the data are appended at the end of the table.
If $rowIndex is given then the data are inserted at line $rowIndex (e.g. 0 = directly after the header).

Returns 1 on success, undef otherwise.

Example:
    
    $success = S_TableAddRow($tableObject, [4, 5, 6]);    # appends [4, 5, 6] at the end of the table
    $success = S_TableAddRow($tableObject, [1, 2, 3], 0); # inserts [1, 2, 3] at the top of the table (after the header)

=cut

sub S_TableAddRow {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_TableAddRow($tableObject_mix, $row_aref [, $rowIndex])', @args );

    my $tableObject = shift @args;
    my $row_aref    = shift @args;
    my $rowIndex    = shift @args;

    my $success = eval { $tableObject->addRow( $row_aref, $rowIndex ); };
    if ($@) {
        S_set_error( "Could not add data to Data::Table object: $@", 114 );
        return;
    }

    return $success;
}

=head2 S_Table2html

    $htmlString = S_Table2html($tableObject [, $colors_aref, $table_attr_href , $tag_tr_href , $tag_th_href , $tag_td_href ]);

Converts the Data::Table object $tableObject (created by S_TableCreate) to a html string.

With $colors_aref the background colors of odd data rows, even data rows and for the header row can be defined.
If $colors_aref is not given then a default color array ref ["#D4D4BF","#ECECE4","#CCCC99"] will be used.

With $table_attr_href additional table formatting settings can be passed to the HTML table

With $tag_tr_href additional table row formatting settings can be passed to the HTML table

With $tag_th_href additional table header formatting settings can be passed to the HTML table

With $tag_td_href additional table colummn formatting settings can be passed to the HTML table

Check CPAN : L<Help Data::Table|http://search.cpan.org/~ezdb/Data-Table/Table.pm> -> Table_Formatting

Examples:
    
    $htmlString = S_Table2html( $tableObject  );
    $htmlString = S_Table2html( $tableObject , ["#D8D8BF","#EAEAE4","#CCCC99"] );
    $htmlString = S_Table2html( $tableObject , [ ] ,  { 'align'=>'center' , 'border' => 1 } );  # set table to center and addd border
    $htmlString = S_Table2html( $tableObject , [ ] ,  { } , { 'align'=>'left'} );   # align left in the row

=cut

sub S_Table2html {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'S_Table2html($tableObject_mix [, $colors_aref]);', @args );

    my $tableObject     = shift @args;
    my $colors_aref     = shift @args;
    my $table_attr_href = shift @args;
    my $tag_tr_href     = shift @args;    # row formatting attributes
    my $tag_th_href     = shift @args;    # header formatting attributes
    my $tag_td_href     = shift @args;    # column formatting attributes

    $colors_aref = [ "#D4D4BF", "#ECECE4", "#CCCC99" ] unless defined $colors_aref;

    S_w2log( 4, "S_Table2html: Creating a html string from the table object.\n" );

    my $htmlString = eval { $tableObject->html( $colors_aref, $table_attr_href, $tag_tr_href, $tag_th_href, $tag_td_href ) };
    if ($@) {
        S_set_error( "Could not create html string from Data::Table object: $@", 114 );
        return;
    }

    return $htmlString;

}

=head2 S_TablePrint

    $success = S_TablePrint($location, $tableObject [, $referenceName, $colors_aref]);

Prints the Data::Table object ($tableObject) to location $location. 
$location can be CONSOLE (console), TEXT (text log file), HTML (html report) or a combination, 
e.g. CONSOLE|TEXT|HTML.
Note that CONSOLE, TEXT and HTML are constants and must be used without quotes.
The table is printed to HTML as html code and to TEXT and CONSOLE as csv text.
In $location you can give a loglevel for HTML additionally by adding the loglevel with | (e.g. HTML|2).
If no additional loglevel is given then 'w2rep' is used.
If $referenceName is given then a HTML reference (like anchor/bookmark) will be added <A NAME = "$referenceName" >,
see S_print2report for more details.
For $colors_aref see S_Table2html.

Returns 1 on success, undef otherwise.

Example:
    
    # print the table to console, text log file and html report (loglevel 2) with bookmark 'mytable'
    $success = S_TablePrint( CONSOLE|TEXT|HTML|2 , $tableObject, 'mytable');

=cut

sub S_TablePrint {

    my @args = @_;
    return unless S_checkFunctionArguments( 'S_TablePrint($location, $tableObject_mix [, $referenceName, $colors_aref])', @args );

    my $location      = shift @args;
    my $tableObject   = shift @args;
    my $referenceName = shift @args;
    my $colors_aref   = shift @args;

    S_w2log( 4, "S_TablePrint: Printing the table object.\n" );

    if ( $location < TEXT ) {
        S_set_error( "For argument \$location (= $location) at least one of the constants CONSOLE, TEXT or HTML must be given", 114 );
        return;
    }

    # create and print csv data
    my $csvString = S_Table2csv( $tableObject, ';' );
    return if not defined $csvString;

    # print first a \n to have the whole table without any leading text (time stamp or other S_w2log text)
    S_print2console( "\n" . $csvString ) if ( CONSOLE & $location and not $main::opt_silent );
    S_print2text( "\n" . $csvString ) if ( TEXT & $location );

    # return if html is not needed
    return 1 unless HTML & $location;

    # extract the loglevel from $location
    my $logLevel = $location & 0xF;
    $logLevel = 'w2rep' if $logLevel == 0;

    # get caller information
    my $package = (caller)[0];
    unless ( $package eq 'main' ) {
        unless ( grep { /^$package$/ } @report_level_library ) {
            push( @report_level_library, $package );
        }
    }

    # create and print html data
    # note: S_print2report cannot be used here because it creates class 'TCtext' html
    my $htmlString = S_Table2html( $tableObject, $colors_aref );
    return if not defined $htmlString;
    $htmlString =~ s/data_table/tablesorter/;    # Data::Table framework creates tables of class 'data_table', but we need class 'tablesorter' for html filtering
    if ( defined $referenceName ) {

        # add reference to html text and to list of htmlBookmarks
        $htmlString = "<A NAME=\"$referenceName\">$htmlString</A>";
        push( @htmlBookmarks, $referenceName );
    }
    my $htmltext = "<div class=\"$logLevel $package\">$htmlString</div><div class=\"space-line\"></div>";
    push( @TC_HTML_TEXT, $htmltext . "\n" );

    return 1;

}

=head1 For Engine modules & Function Libraries use only

The below APIs are also Exported from LIFT_general module, but these APIs are recommended to be used only in Engine modules & Function Libraries, under careful reviews & tests.

i.e., These APIs shall not be used in Testcases directly.


=head2 S_add_to_zip

    S_add_to_zip ( $zip_handle , @list_of_files_folders );

B<Description:>

Adds all files/folders of @list_of_files_folders to archive with handle $zip_handle.

B<Input Arguments:>

$zip_handle : Get the handle of zip file with S_open_zip function

@list_of_files_folders : List of files\folders to add into existing zip folder. 

B<Example:>

		@list_of_files_folders = qw/Test_new_3.txt Test_new_4.txt Test_Folder/;
		$zip_handle = S_open_zip ( ".\\ZIP_Test.zip" );
		S_add_to_zip ( $zip_handle , @list_of_files_folders );
		S_close_zip ( $zip_handle );

=cut

sub S_add_to_zip {

    my $zip_handle            = shift;
    my @list_of_files_folders = @_;

    my ( $full_name, $local_zip_command, $zip_file );

    unless ( defined( $list_of_files_folders[0] ) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_add_to_zip ( zip , list_of_files_folders )", 110 );
        return 0;
    }

    unless ( exists $All_ZipHandle_to_File{$zip_handle} ) {
        S_set_error( " S_add_to_zip : Zip-Handle not valid , open Zip-File first", 110 );
        return 0;
    }

    $zip_file = $All_ZipHandle_to_File{$zip_handle}{'FullName'};

    # new part start

    unless ( exists $All_ZipHandle_to_File{$zip_handle} ) {
        S_set_error( " S_add_to_zip : Zip-Handle not valid , open Zip-File first", 110 );
        return;
    }

    unless ( $zip_file = $All_ZipHandle_to_File{$zip_handle}{'FullName'} ) {
        S_set_error( " S_add_to_zip : Abnormal error ; No Zip-File for Zip-Handle available ", 110 );
        return;
    }

    foreach my $file_to_zip (@list_of_files_folders) {
        if ( -f $file_to_zip ) {
            unless ( $zip_handle->addFile( $file_to_zip, basename($file_to_zip) ) ) { S_set_error( " adding file or directory '$file_to_zip' to exisiting zip not successful", 170 ); return }
        }
        elsif ( -d $file_to_zip ) {
            my $foldername = fileparse($file_to_zip);
            unless ( $zip_handle->addTree( $file_to_zip, $foldername ) == AZ_OK ) { S_set_error( " adding file or directory '$file_to_zip' to exisiting zip not successful", 170 ); return }
        }
        else {
            S_set_error( " S_add_to_zip : File '$file_to_zip', which has to be zipped doesnt exists: $!", 1 );
            return;
        }
    }

    # new part end

    return 1;
}

=head2 S_close_all

    S_close_all ();

Closes standard logfile and result files (csv + html)

=cut

sub S_close_all {
    unless ( close(LOG) )         { S_set_error( "Error closing LOG file : $!",         1 ); return 0; }
    unless ( close(RESULT) )      { S_set_error( "Error closing RESULT file : $!",      1 ); return 0; }
    unless ( close(RESULT_HTML) ) { S_set_error( "Error closing RESULT_HTML file : $!", 1 ); return 0; }

    if ( $main::ProjectDefaults->{'LC_SIGNAL_FILE'}{'USED'} ) {
        unless ( close(SIG) ) { S_set_error( "Error closing SIG file : $!", 1 ); return 0; }
    }

    if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} ) {
        unless ( close(EVAL) ) { S_set_error( "Error closing EVAL file : $!", 1 ); return 0; }
    }
}

=head2 S_close_zip

    S_close_zip ( $zip_handle );

B<Description:>
    
Takes the ZIP handler and checks for given zip handler availability.
Closes the zip file with help of handler.

B<Input Arguments:>

$zip_handle : Get the handle of zip file with S_open_zip function

B<Example:>

	$zip_handle = S_open_zip ( ".\\ZIP_Test.zip" );
	S_close_zip ( $zip_handle );
 
=cut

sub S_close_zip {

    my $zip_handle = shift;
    my $zip_file;

    unless ( defined($zip_handle) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_close_zip ( zip )", 110 );
        return;
    }

    unless ( $zip_file = $All_ZipHandle_to_File{$zip_handle}{'FullName'} ) {
        S_set_error( " S_close_zip : Abnormal error ; No Zip-File for Zip-Handle available ", 110 );
        return;
    }

    S_w2log( 3, "Write Zip - File : '$zip_file'" );

    if ( -f $zip_file ) {
        unless ( $zip_handle->overwrite() == AZ_OK ) {
            S_set_error( " S_close_zip : Storing of Zip-File not possible.", 110 );
            return;
        }
    }
    else {
        unless ( $zip_handle->writeToFileNamed($zip_file) == AZ_OK ) {
            S_set_error( " S_close_zip : Storing of Zip-File not possible.", 110 );
            return;
        }
    }

    delete $All_ZipHandle_to_File{$zip_handle};
    delete $All_ZipFile_to_Handle{$zip_file};

    undef $zip_handle;

    S_w2log( 3, " S_close_zip : $zip_file done \n" );

    return 1;
}

=head2 S_convert_dataref_to_file

   S_convert_dataref_to_file( $MEASURE_DATA , $output_file );

   function convert data reference of measurements into D97 or MDF or other output formats

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   measure data will be written into CSV file and
   converted to D97 or MDF output file

   Tool usage : c:\\tools\\sdtm3c NOWARN IFN=$csv_file_name OFN=$output_file


=cut

sub S_convert_dataref_to_file {

    my $dataref     = shift;
    my $output_file = shift;

    my ( $all_time_stamps, $all_signals, $all_signals_sorted, $first_signal_values, $last_signal_values, $value, $line, $convert_tool_command, $return_code, );

    foreach my $timestamp ( sort { $a <=> $b } keys %$dataref ) {

        # collecting all timestamps
        push( @$all_time_stamps, $timestamp );
        foreach my $signal ( keys %{ $dataref->{$timestamp} } ) {

            # storing first value of signal which is needed as initial value in csv file
            unless ( defined $first_signal_values->{$signal} ) {
                $first_signal_values->{$signal} = $dataref->{$timestamp}{$signal};
            }

            # collecting all signal names
            $all_signals->{$signal} = 1 unless defined $all_signals->{$signal};
        }
    }

    # created sorted list of all signals
    @$all_signals_sorted = sort keys %$all_signals;

    my $csv_file_name = "C:\\temp\\temp_dataref.csv";
    S_w2log( 4, " S_convert_dataref_to_file : Creating $csv_file_name ..\n" );

    unless ( open( CSVFILE, ">$csv_file_name" ) ) { S_set_error( "Opening $csv_file_name", 1 ) }

    # write header line is CSV file
    $line = "\"TIME\"";
    foreach my $signal (@$all_signals_sorted) { $line .= ";\"$signal\""; }
    print CSVFILE "$line\n";

    # write all values in CSV file
    foreach my $timestamp (@$all_time_stamps) {
        $line = $timestamp;
        foreach my $signal (@$all_signals_sorted) {
            if ( defined $dataref->{$timestamp}{$signal} ) {
                $value = $dataref->{$timestamp}{$signal};
                $last_signal_values->{$signal} = $value;
            }
            elsif ( defined $last_signal_values->{$signal} ) {
                $value = $last_signal_values->{$signal};
            }
            elsif ( defined $first_signal_values->{$signal} ) {
                $value = $first_signal_values->{$signal};
            }
            else {
                S_w2log( 3, " S_convert_dataref_to_file : unexpected state when looking for value of signal $signal \n" );
                next;
            }
            $line .= ";$value";
        }
        print CSVFILE "$line\n";
    }
    close CSVFILE;

    my $tool = "C:\\TurboLIFT\\SupportTools\\bin\\sdtm3c.exe";
    unless ( -f $tool ) { S_set_error( "Could not find tool : $tool", 1 ); return }
    $convert_tool_command = "$tool NOWARN IFN=$csv_file_name OFN=$output_file";

    ($return_code) = S_call_command($convert_tool_command);

    return $return_code;
}

=head2 S_create_OLE

    $OLE_object_handle = S_create_OLE ( $application , $host [ , \&shutdownfunction ] );

generic function to open an OLE interface to an application on a given host
function return the handle to the OLE object

the optional parameter \&shutdownfunction is a function reference to a local function
   which shall be called when the perl program dies

Example:

    $my_canalyzer_handle = S_create_OLE( 'CANalyzer.Application' ); # application started on local host

 or

    $my_canalyzer_handle = S_create_OLE( 'CANalyzer.Application' , 'appl_host.de.bosch.com' );

 or

    $my_canalyzer_handle = S_create_OLE( 'CANalyzer.Application' , 'appl_host.de.bosch.com' , \&my_OLE_quit );

    sub my_OLE_quit {
      my $self = shift;
      $self->Quit;
    }

=cut

sub S_create_OLE {
    my ( $application, $host, $quit_func_ref ) = @_;

    unless ( defined($application) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_create_OLE ( application [, host ])", 110 );
        return;
    }

    unless ( defined($host) ) {
        $host = hostname();    # application started on local host
    }

    S_w2log( 4, " S_create_OLE : creating '$application' object on host: '$host' \n" );

    return 1 if $main::opt_offline;

    my $OLE_handle = Win32::OLE->new( [ $host, $application ], $quit_func_ref );

    if ( defined $OLE_handle ) {
        S_w2log( 5, " S_create_OLE : Win32::OLE -> new ([ $host , $application ]) successful done \n" );
        return $OLE_handle;
    }
    else {
        S_set_error( " Error creating: Win32::OLE -> new ([ $host , $application ])", 111 );
        return;
    }
}

=head2 S_get_eval_collection

    $evalCollection_href = S_get_eval_collection ( );



=cut

sub S_get_eval_collection {
    return \%EVAL_COLLECTION;
}

=head2 S_get_eval_text

    ($expected,$detected,$stimulation) = S_get_eval_text ( );

    get text from eval data to write to result file for stimulation, expected and detected behaviour.
    Will get texts from  'S_teststep...' if it was used.
    replace internally all ; with , and all TAB with blank
    @EVAL_TEXT will be empty afterwards.

=cut

sub S_get_eval_text {
    my $expected;
    my $detected;
    my $stimulation;

    ## get content of 'S_teststep..' if it was used for the corresponding column
    $stimulation = prepare_content( $EVAL_COLLECTION{'Stimulation'} ) if exists $EVAL_COLLECTION{'Stimulation'};
    $detected    = prepare_content( $EVAL_COLLECTION{'DET'} )         if exists $EVAL_COLLECTION{'DET'};
    $expected    = prepare_content( $EVAL_COLLECTION{'EXP'} )         if exists $EVAL_COLLECTION{'EXP'};

    ## return content of eval collection if all corresponding contents are defined
    return ( $expected, $detected, $stimulation ) if defined $expected and defined $detected and defined $stimulation;

    ## clear expected and detected and try to get it from @EVAL_TEXT
    $expected = '';
    $detected = '';

    my $signal_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};
    my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};

    $signal_marker = 'SIG:' unless defined $signal_marker;
    $expect_marker = 'EXP:' unless defined $expect_marker;
    $detect_marker = 'DET:' unless defined $detect_marker;

    my $counter = 1;

    my ( $content, $key, $expected_collector, $detected_collector, $mismatch_collector, $name );

    while (@EVAL_TEXT) {
        my $line = shift(@EVAL_TEXT);
        if ( $line =~ /([^;]+);$signal_marker\s*(.+)/ ) {
            $name = $2;
        }
        elsif ( $line =~ /([^;]+);$expect_marker\s*(.+)/ ) {
            $expected_collector .= $2 . ",";
        }
        elsif ( $line =~ /MISMATCH;\s*(.+)/ ) {
            $mismatch_collector = $1;

            #replace all tabs with blanks
            $mismatch_collector =~ s/\t/ /g;
            $detected .= "MISMATCH: $mismatch_collector\t";
            $expected .= "\t";
        }
        elsif ( $line =~ /([^;]+);$detect_marker\s*(.+)/ ) {
            $detected_collector .= $2 . ",";

            #take signal name, else take key
            $name = $1 if ( $name eq '' );

            #replace all tabs with blanks
            $expected_collector =~ s/\t/ /g;
            $detected_collector =~ s/\t/ /g;
            $name =~ s/\t/ /g;

            $detected .= $counter . " " . $name . ": " . $detected_collector . "\t";
            chop($expected_collector);    # cut off last comma
            $expected .= $counter . " " . $name . ": " . $expected_collector . "\t";
            $counter++;
            $expected_collector = '';
            $detected_collector = '';
            $mismatch_collector = '';
            $name               = '';
        }
    }

    #    S_w2log( 5 , " S_get_eval_text :  \n"); # will not be written to html
    #    S_w2log( 5 , "EXP $expected\n"); # will not be written to html
    #    S_w2log( 5 , "FND $detected\n"); # will not be written to html

    chop($expected);    # cut off last tab
    chop($detected);    # cut off last tab

    #replace all ; with ,
    $expected =~ s/;/,/g;
    $detected =~ s/;/,/g;

    return ( $expected, $detected, $stimulation );
}
######## local function ##############################
sub prepare_content {
######################################################
    my $content = shift;

    # replace all tabs with blanks
    $content =~ s/\t/ /g;

    # replace all new lines with tabs
    $content =~ s/\n/\t /g;

    #    replace all "
    $content =~ s/\"/ /g;

    #replace all ; with ,
    $content =~ s/;/,/g;
    return $content;
}

=head2 S_get_from_zip

    S_get_from_zip ( $zip_handle, $storage_folder, @list_of_files_folders );


B<Description:>

Unzip all files/folders of @list_of_files_folders in Folder $storage_folder including files in case of folder.

B<Input Arguments:>

$zip_handle : Get the handle of zip file with S_open_zip function

$storage_folder : Folder name where extracted files to be stored

@list_of_files_folders : List of files\folders to extract from zip folder. 

B<Example:>

		@list_of_files_folders = qw/Test_new_3.txt Test_new_4.txt/;
		$zip_handle = S_open_zip ( ".\\ZIP_Test.zip" );
		S_get_from_zip ($zip_handle, ".\\zip_storage", @list_of_files_folders);

B<Note> If files given in @list_of_files_folders is available at $storage_folder, then those files are overwritten.

=cut

sub S_get_from_zip {

    my $zip_handle            = shift;
    my $storage_folder        = shift;
    my @list_of_files_folders = @_;

    my ( $full_name, $local_zip_command, $zip_file );

    unless ( defined($zip_handle) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_get_from_zip ( zip_handle, storage_folder, list_of_files_folders )", 110 );
        return;
    }
    unless ( defined($storage_folder) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_get_from_zip ( zip_handle, storage_folder, list_of_files_folders )", 110 );
        return;
    }
    unless ( defined( $list_of_files_folders[0] ) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_get_from_zip ( zip_handle, storage_folder, list_of_files_folders )", 110 );
        return 0;
    }

    $zip_file = $All_ZipHandle_to_File{$zip_handle}{'FullName'};

    # new part start

    unless ( $zip_file = $All_ZipHandle_to_File{$zip_handle}{'FullName'} ) {
        S_set_error( " S_get_from_zip : Abnormal error ; No Zip-File for Zip-Handle available ", 110 ) && return;
    }

    if ( -f $zip_file || -d $zip_file ) {

        foreach my $file_to_zip (@list_of_files_folders) {
            $zip_handle->extractMember( $file_to_zip, $storage_folder . '\\' . $file_to_zip );
        }
    }

    return 1;
}

=head2 S_get_filelist_from_zip

    @list_of_files_in_zip = S_get_filelist_from_zip ( $zip_handle );


B<Description:>

Returns list of all files/folders in zip file.

B<Input Arguments:>

$zip_handle : Get the handle of zip file with S_open_zip function

B<Example:>
my $zip_handle = S_open_zip("$zipFilePath");
my @list_of_files_in_zip = S_get_filelist_from_zip($zip_handle);

B<Note>

=cut

sub S_get_filelist_from_zip {

    my $zip_handle = shift;

    my ( $local_zip_command, $zip_file );

    unless ( defined($zip_handle) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_get_from_zip ( zip_handle, storage_folder, list_of_files_folders )", 110 );
        return;
    }

    $zip_file = $All_ZipHandle_to_File{$zip_handle}{'FullName'};

    # new part start

    unless ( $zip_file = $All_ZipHandle_to_File{$zip_handle}{'FullName'} ) {
        S_set_error( " S_get_filelist_from_zip : Abnormal error ; No Zip-File for Zip-Handle available ", 110 ) && return;
    }

    my (@list_of_files_folders);
    if ( -f $zip_file || -d $zip_file ) {
        @list_of_files_folders = $zip_handle->memberNames();
    }

    return @list_of_files_folders;
}

=head2 S_get_LastError_OLE

    $Error_Text = S_get_LastError_OLE ( $additional_info_to_be_printed );

=cut

sub S_get_LastError_OLE {
    my $additional_info_to_be_printed = shift;

    my $err = "";
    return 0 unless $err = Win32::OLE->LastError();

    S_w2log( 1, "\n" . $additional_info_to_be_printed . "\n", 'deeppink' ) if defined $additional_info_to_be_printed;
    S_w2log( 1, "\n" . $err . "\n", 'red' );

    return $err;
}

=head2 S_get_system_strategies

    $system_strategies = S_get_system_strategies ( \@fault_strategies [ , \@basic_operating_states ]  );

    @fault_strategies and
    @basic_operating_states  (optional)

    have to be defined in the system strategies with their items to be checked
    the sort of the list is the order of precedence which signals have the overweight
    in case that same signal behaviours are defined in different strategies

    (if there is no fault expected then the strategy 'NoFault' have to be given )

    examples :
    @basic_operating_states = ( "constant_drive" , "brake_not_pressed" , "full_system" );
    @fault_strategies       = ( "DsLine" , "WssFlLine" );



    items to be checked are given back in a structure like :

    $system_strategies =    {
                            'LAMPS_STATE' => { 'LAMPS_STRATEGY' => 'ABS_off' } ,
                            'VR_STATE' => 'ON' ,
                            'CAN_PATTERN' => { "SIG_X" => "PATTERN:X:Y" , "SIG_Y" => "PATTERN:A:B" } ,
                            'CAN_PATTERN_NOT' => { "SIG_WQ" => [ 0 , 255 ] , "SIG_UI" => [ 0 ] } ,
                            }

    the method of 'system strategies' is described in the document : XXXXX

=cut

sub S_get_system_strategies {
    my $fault_strategies = shift;    #array reference
    my $operating_states = shift;    #array reference
    my %system_strategies;

    my ( $fpath_strategy, $shutdown_strategy, $verification_item, $verification_value, );

    #
    # loop foreach fault_strategy
    #
    foreach my $fault_strategy (@$fault_strategies) {

        S_w2log( 3, " S_get_system_strategies : Fault-S. -> $fault_strategy \n" );

        #
        # loop foreach verif class ('CAN_PATTERN' , 'VR_STATE' , ... )
        #
        foreach my $verification_class ( keys %{ $LIFT_config::LIFT_ProjectDefaults->{'FAULT_STRATEGY'}{$fault_strategy} } ) {
            next if $verification_class eq 'FPATH_STRATEGY';
            ### get CAN Signal pattern checks from fault_strategies (all)
            while ( ( $verification_item, $verification_value ) = each %{ $LIFT_config::LIFT_ProjectDefaults->{'FAULT_STRATEGY'}{$fault_strategy}{$verification_class} } ) {
                if ( defined $system_strategies{$verification_class}{$verification_item} ) {
                    S_w2log( 3, " S_get_system_strategies : -X-> $verification_class : $verification_item is already part of $verification_class\n" );
                    next;
                }
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = $verification_value \n" ) unless ref($verification_value);
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = ( HASH ref ) \n" ) if ref($verification_value) eq "HASH";
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = [ " . join( " ", @$verification_value ) . " ] ( out of LIST ref) \n" ) if ref($verification_value) eq "LIST";
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = " . $$verification_value . " ( out of SCALAR ref ) \n" ) if ref($verification_value) eq "SCALAR";
                $system_strategies{$verification_class}{$verification_item} = $verification_value;
            }
        }    # end of :  foreach $verification_class

        #
        # take the fpath_strategy
        #
        if ( $fpath_strategy = $LIFT_config::LIFT_ProjectDefaults->{'FAULT_STRATEGY'}{$fault_strategy}{'FPATH_STRATEGY'} ) {

            S_w2log( 3, " S_get_system_strategies : FPath-S. -> $fpath_strategy ( Fault-S. $fault_strategy )\n" );

            #
            # loop foreach verif class ('CAN_PATTERN' , 'VR_STATE' , ... )
            #
            foreach my $verification_class ( keys %{ $LIFT_config::LIFT_ProjectDefaults->{'FPATH_STRATEGY'}{$fpath_strategy} } ) {
                next if $verification_class eq 'SHUTDOWN_STRATEGY';
                ### get CAN Signal pattern checks from fault_strategies (all)
                while ( ( $verification_item, $verification_value ) = each %{ $LIFT_config::LIFT_ProjectDefaults->{'FPATH_STRATEGY'}{$fpath_strategy}{$verification_class} } ) {
                    if ( defined $system_strategies{$verification_class}{$verification_item} ) {
                        S_w2log( 3, " S_get_system_strategies : -X-> $verification_class : $verification_item is already part of $verification_class\n" );
                        next;
                    }
                    S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = $verification_value \n" ) unless ref($verification_value);
                    S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = ( HASH ref ) \n" ) if ref($verification_value) eq "HASH";
                    S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = [ " . join( " ", @$verification_value ) . " ] ( out of LIST ref) \n" ) if ref($verification_value) eq "LIST";
                    S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = " . $$verification_value . " ( out of SCALAR ref ) \n" ) if ref($verification_value) eq "SCALAR";
                    $system_strategies{$verification_class}{$verification_item} = $verification_value;
                }
            }    # end of :  foreach $verification_class

            #
            # take the shutdown_strategy
            #
            if ( $shutdown_strategy = $LIFT_config::LIFT_ProjectDefaults->{'FPATH_STRATEGY'}{$fpath_strategy}{'SHUTDOWN_STRATEGY'} ) {

                S_w2log( 3, " S_get_system_strategies :  Shutdown-S. -> $shutdown_strategy ( FPath-S. $fpath_strategy , Fault-S. $fault_strategy )\n" );

                #
                # loop foreach verif class ('CAN_PATTERN' , 'VR_STATE' , ... )
                #
                foreach my $verification_class ( keys %{ $LIFT_config::LIFT_ProjectDefaults->{'SHUTDOWN_STRATEGY'}{$shutdown_strategy} } ) {
                    ### get CAN Signal pattern checks from fault_strategies (all)
                    while ( ( $verification_item, $verification_value ) = each %{ $LIFT_config::LIFT_ProjectDefaults->{'SHUTDOWN_STRATEGY'}{$shutdown_strategy}{$verification_class} } ) {
                        if ( defined $system_strategies{$verification_class}{$verification_item} ) {
                            S_w2log( 3, " S_get_system_strategies : -X-> $verification_class : $verification_item is already part of $verification_class\n" );
                            next;
                        }
                        S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = $verification_value \n" ) unless ref($verification_value);
                        S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = ( HASH ref ) \n" ) if ref($verification_value) eq "HASH";
                        S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = [ " . join( " ", @$verification_value ) . " ] ( out of LIST ref) \n" ) if ref($verification_value) eq "LIST";
                        S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = " . $$verification_value . " ( out of SCALAR ref ) \n" ) if ref($verification_value) eq "SCALAR";
                        $system_strategies{$verification_class}{$verification_item} = $verification_value;
                    }
                }    # end of :  foreach $verification_class
            }    # end of :  if( $shutdown_strategy =
        }    # end of : if( $fpath_strategy =
    }    # end of : foreach $fault_strategy ( @$fault_strategies )

    #### to get values which CAN Signal should not have in trace

    foreach my $basic_state ( @{$operating_states} ) {

        S_w2log( 3, " S_get_system_strategies :  Basic Op State -> $basic_state \n" );

        #
        # loop foreach verif class ('CAN_PATTERN' , 'VR_STATE' , ... )
        #
        foreach my $verification_class ( keys %{ $LIFT_config::LIFT_ProjectDefaults->{'BASIC_OPERATING_STATES'}{$basic_state} } ) {
            ### get CAN Signal pattern checks from fault_strategies (all)
            while ( ( $verification_item, $verification_value ) = each %{ $LIFT_config::LIFT_ProjectDefaults->{'BASIC_OPERATING_STATES'}{$basic_state}{$verification_class} } ) {
                if ( defined $system_strategies{$verification_class}{$verification_item} ) {
                    S_w2log( 3, " S_get_system_strategies : -X-> $verification_class : $verification_item is already part of $verification_class\n" );
                    next;
                }
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = $verification_value \n" ) unless ref($verification_value);
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = ( HASH ref ) \n" ) if ref($verification_value) eq "HASH";
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = [ " . join( " ", @$verification_value ) . " ] ( out of LIST ref) \n" ) if ref($verification_value) eq "LIST";
                S_w2log( 3, " S_get_system_strategies : ---> $verification_class : $verification_item = " . $$verification_value . " ( out of SCALAR ref ) \n" ) if ref($verification_value) eq "SCALAR";
                $system_strategies{$verification_class}{$verification_item} = $verification_value;
            }
        }    # end of : foreach $verification_class
    }    # end of : foreach $basic_state

    return \%system_strategies;

}

=head2 S_get_Win32_processes

    %PROCESSES = S_get_Win32_processes ( [ $HOST ] );

Retrieves all process IDs on host $HOST, sorted by name.

 %PROCESSES = (
                 proc_nameX => [proc_id1 , proc_id2] ,
                 proc_nameY => [proc_id1 , proc_id2] ,
                 ...
              );

If $HOST is not defined then the process IDs are taken from LIFT host.

Only slightly modified code from the Win32::PerfLib manpage, actually.

=cut

sub S_get_Win32_processes {
    my $hostname = shift;

    my ( %counter, %r_counter, %process_by_name );

    if ( !defined($hostname) or $hostname =~ /localhost/i ) {
        $hostname = '';
    }

    return if ( $main::opt_offline or $main::opt_simulation );

    Win32::PerfLib::GetCounterNames( '', \%counter );

    %r_counter = reverse %counter;

    # Get id for the process object
    my $process_obj = $r_counter{'Process'};

    # Get id for the process ID counter
    my $process_id = $r_counter{'ID Process'};

    # create connection to local computer
    my $perflib  = new Win32::PerfLib($hostname);
    my $proc_ref = {};

    # get the performance data for the process object
    $perflib->GetObjectList( $process_obj, $proc_ref );
    $perflib->Close();

    my $instance_ref = $proc_ref->{'Objects'}->{$process_obj}->{'Instances'};

    foreach my $instance ( values %{$instance_ref} ) {
        my $counter_ref = $instance->{'Counters'};
        foreach my $counter ( values %{$counter_ref} ) {
            if ( $counter->{'CounterNameTitleIndex'} == $process_id ) {

                # Process ID:s stored by name, in anonymous array:
                push @{ $process_by_name{ $instance->{'Name'} } }, $counter->{'Counter'};
            }
        }
    }
    return %process_by_name;
}

=head2 S_init_LIFT_error_list

    S_init_LIFT_error_list ( $FILE_NAME );

Reads from file $FILE_NAME error codes+texts and builds up the hash ALL_ERR_CODES
that is used by S_set_error.

=cut

sub S_init_LIFT_error_list {
    my $file = shift;

    my ( $err_code, $err_text );

    open( ERRORLIST, $file ) || die "Opening $file \n";
    my @all_errorlist_lines = (<ERRORLIST>);
    close ERRORLIST;

    for (@all_errorlist_lines) {
        next unless /^\s*(\d+)\s*=\s*"(.*)"/;
        $err_code            = $1;
        $err_text            = $2;
        $ALL_ERR_CODES->{$1} = $2;
    }
    return 1;
}

=head2 S_init_pipe

    $pipe = S_init_pipe ( $remote_pc , $pipe_name , @files_to_copy );

Copies @files_to_copy to $remote_pc into folder C:\temp\LIFT.
Starts the first file in @files_to_copy (either *.bat or *.pl) on the remote PC.
This file must contain the pipe-server that opens a pipe with the
name $pipe_name on the remote PC.
The function then opens the same pipe on the local (LIFT) PC.

=cut

sub S_init_pipe {

    my $remote_pc     = shift;
    my $pipe_name     = shift;
    my @files_to_copy = @_;

    my ( $pipe, $result, $file, $pid, $full_pipename );

    unless ( defined( $files_to_copy[0] ) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_init_pipe ( remote_pc , pipe_name , files_to_copy )", 110 );
        return 0;
    }

    return 1 if $main::opt_offline;

    my $remote_path = "\\\\$remote_pc\\c\$\\temp\\LIFT\\";

    #my $remote_path = "c:\\temp\\LIFT\\";
    S_w2log( 5, " S_init_pipe: remote path on LIFT PC: $remote_path\n\n" );

    # copy files in @files_to_copy to remote PC
    foreach $file (@files_to_copy) {
        $result = system("xcopy $file $remote_path");    # copy single file with DOS command xcopy
                                                         #$result = copy( $file, $remote_path );
        if ($result) {
            S_set_error( "could not copy file $file to $remote_path", 1 );
        }
        else {
            S_w2log( 4, " S_init_pipe: copied file $file to $remote_path\n\n" );
        }
    }

    # start 1st file of @files_to_copy on remote PC
    $files_to_copy[0] =~ /(\w+\.?\w*)$/;                 # extract blank filename from path
    $file = $1;
    S_w2log( 5, " S_init_pipe: blank file name: $file\n" );
    $remote_path =~ s/\\\\\w+\\c\$/c:/g;                 # change path from \\si1234\c$\... to c:\...
    S_w2log( 5, " S_init_pipe: local path on remote PC: $remote_path\n" );
    if ( $file =~ /\.bat$/ ) {                           # check for filename *.bat
        $pid = S_remote_exec( $remote_pc, 'C:\\WINNT\\system32\\CMD.EXE /C', $remote_path . $file );
    }
    elsif ( $file =~ /\.pl$/ ) {                         # check for filename *.pl
        $pid = S_remote_exec( $remote_pc, 'C:\\perl\\bin\\Perl.exe', $remote_path . $file );
    }
    else {
        S_set_error( "don't know how to start $file", 114 );
    }

    # wait for server to start pipe
    S_wait_ms(1000);

    # open pipe
    $full_pipename = "\\\\$remote_pc\\pipe\\$pipe_name";
    S_w2log( 5, " S_init_pipe: full pipe name: $full_pipename\n" );
    $pipe = new Win32::Pipe($full_pipename);    # open existing pipe (was created by program that was started previously)
    if ($pipe) {
        S_w2log( 2, " S_init_pipe: opened pipe: $full_pipename\n" );
        return $pipe;
    }
    else {
        S_set_error( "could not open pipe $full_pipename : $!", 1 );
        return;
    }

}

=head2 S_log_module_versions

    S_log_module_versions ();

Does not do anything anymore because version numbers in files are not supported anymore by SCM.

The function itself is kept to avoid errors if the function is called.

=cut

sub S_log_module_versions {
    return 1;
}

=head2 S_log_testbenchconfig

    S_log_testbenchconfig ();

Writes the testbench configuration to the log file. The configuration will be taken from the PC running LIFT (hostname).

=cut

sub S_log_testbenchconfig {

    my $LIFT_host;
    my $testbench_config;

    unless ( defined $LIFT_Testbenches::Testbench ) {
        S_set_warning("No LIFT_Testbenches are defined\n");
        return 1;
    }

    my $machine_name = hostname();

    #
    # check of LIFT_config::LIFT_host
    #
    if ( defined $LIFT_config::LIFT_host ) {
        $LIFT_host = $LIFT_config::LIFT_host;
        S_w2log( 3, " S_log_testbenchconfig: LIFT_config::LIFT_host is defined => '$LIFT_host' \n" );

        unless ( $machine_name eq $LIFT_host ) {
            S_set_warning("Mismatch of Local machine name '$machine_name' <=> $LIFT_host (LIFT_config::LIFT_host)\n");
        }
    }
    else {
        $LIFT_host = $machine_name;
        S_w2log( 3, " S_log_testbenchconfig: LIFT_config::LIFT_host is not defined => use local hostname '$LIFT_host' \n" );
    }

    #
    # assign Testbench config
    #
    if ( $testbench_config = $LIFT_Testbenches::Testbench->{$LIFT_host} ) {
        S_w2rep(" S_log_testbenchconfig: Explicit entry found in LIFT_Testbenches for host '$LIFT_host' \n");
        S_w2log( 3, " S_log_testbenchconfig: START DUMP TESTBENCH CONFIG ($LIFT_host) ...\n" );
    }
    else {
        S_w2log( 3, " S_log_testbenchconfig: No entry found in LIFT_Testbenches for host '$LIFT_host' \n" );
        S_w2log( 3, " S_log_testbenchconfig: Looking for entry for 'localhost' as machine name ... \n" );
        unless ( $testbench_config = $LIFT_Testbenches::Testbench->{'localhost'} ) {
            S_set_error( "No entry found in testbench config (LIFT_Testbenches.pm) for LIFT host : $LIFT_host ( note : hostnames are case sensitive / 'localhost' is possible too ) \n", 21 );
            return;
        }
        S_w2rep(" S_log_testbenchconfig: Use testbench config of 'localhost' as testbench definition \n");
        S_w2log( 3, " S_log_testbenchconfig: START DUMP TESTBENCH CONFIG ('localhost')\n" );
    }

    $Data::Dumper::Indent = 1;
    my $dump = Dumper $testbench_config;
    $dump =~ s/ /\./g;
    S_w2log( 3, $dump );

    S_w2log( 3, " S_log_testbenchconfig: END DUMP TESTBENCH CONFIG\n" );

    return 1;
}

=head2 S_open_log

    S_open_log ( $LOG_NAME );

The file names are defined using $LOG_NAME and current date and time.

=cut

sub S_open_log {

    my $log_name = shift;

    my $log_file = $log_name;
    $log_file =~ s/\.\w+$/_log.txt/g;    # replace file extension (e.g. .html) with _log.txt
    open( LOG, ">$log_file" ) || die "\n!!! couldn't open (Text) LOG file '$log_file': $! \n";
    LOG->autoflush(1);
    S_w2log( 5, " Opening (Text) LOG file '$log_file' (this file)\n" );

    my $result_html = $log_name;
    S_w2log( 5, " Opening RESULT_HTML file '$result_html'\n" );
    open( RESULT_HTML, ">$result_html" ) || die "\n!!! couldn't open RESULT_HTML file '$result_html': $! \n";
    RESULT_HTML->autoflush(1);

    if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} ) {
        my $eval_file = $log_name;
        $eval_file =~ s/\.\w+$/_eval.csv/g;    # replace file extension (e.g. .html) with _eval.csv
        S_w2log( 5, " Opening EVALUATION file '$eval_file'\n" );
        open( EVAL, ">$eval_file" ) || die "\n!!! couldn't open EVALUATION file '$eval_file': $! \n";

        binmode EVAL;                          ## change file mode to binary 'cause the line break (chr(10)) inside of EXCEL cells

        my $delim = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DELIMITER'};
        my $headline = join( $delim, @{ $main::ProjectDefaults->{'EVALUATION_FILE'}{'COLUMN_ORDER'} } );
        S_w2eval( $headline . "\n" );
    }

    return 1;
}

=head2 S_open_result

    S_open_result ( $RESUL_TFILE_NAME );

Opens the result file of LIFT Test Campaign (just for use of LIFT execution engine)
Result file is the csv-file which is the interface for following evaluation tool set
Remark: Path and file name of resultfile have to be prepared in Config Module of LIFT

=cut

sub S_open_result {
    my $file_name = shift;
    open( RESULT, ">$file_name" . "__result.txt" ) || die "\n!!! couldn't open result-File: $! \n";

    return 1;
}

=head2 S_open_zip

    $zip_handle = S_open_zip ( $zip_filename [, $keep_original_fileName ] );

B<Description:>

Opens a Zip archive (filename $zip_filename) and returns the handle.
If $zip_filename does not end with .zip then .zip will be added to $zip_filename.

Files can be added to the archive with S_add_to_zip.

The archive must be closed with S_close_zip

B<Input Arguments:>

$zip_filename : Zip file name on which user wants to perform required action (as said in description)
$keep_original_fileName : If set to 1 then the function will not add .zip to the file to be created

B<Return Value:>

$zip_handle : ZIP file handler
 
B<Example:>

		$zip_handle = S_open_zip ( ".\\ZIP_Test.zip" ); 

=cut

sub S_open_zip {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_open_zip ( $zip_filename [, $keep_original_fileName ] )', @args );

    my $zip_filename           = shift @args;
    my $keep_original_fileName = shift @args;

    my ( $zip_handle, $full_name );

    if ( not $zip_filename =~ /\.zip$/i and not $keep_original_fileName ) {
        $zip_filename = "$zip_filename.zip";
    }

    ### if filename given without valid path , zipfile will be stord in main log folder ($LOG_path_current_testrun)
    ## func: 'dirname' from File::Basename modul
    $main::save_name .= '';    # just to avoid warning
    unless ( -d dirname $zip_filename ) { $full_name = "$main::save_name/$zip_filename"; }
    else                                { $full_name = $zip_filename; }

    $zip_handle = Archive::Zip->new();

    # read the content of the zip_file if it already exists
    if ( -f $full_name ) {
        unless ( $zip_handle->read($full_name) == AZ_OK ) {
            S_set_error( " S_open_zip : Reading contents of existing Zip-File not possible.", 110 );
        }
    }

    unless ( exists $All_ZipFile_to_Handle{$full_name} ) {
        S_w2log( 5, " S_open_zip : Open new zip-archive $full_name\n" );
        $All_ZipFile_to_Handle{$full_name}{'ZipHandle'} = $zip_handle;
        $All_ZipHandle_to_File{$zip_handle}{'FullName'} = $full_name;

        return $zip_handle;
    }
    else {
        S_w2log( 5, " S_open_zip : Handle of Zip-file $full_name already exists and still valid\n" );
        return $All_ZipFile_to_Handle{$full_name}{'ZipHandle'};
    }
}

=head2 S_ping

    $alive = S_ping ( $requested_host );

    $alive = 1 if $host is alive
    $alive = 0 if $host not alive

=cut

sub S_ping {

    my $requested_host = shift;

    unless ( defined($requested_host) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_ping ( host );", 110 );
        return 0;
    }

    return 1 if ( $Alive_Hosts{$requested_host} );

    my $ping_handle = Net::Ping->new(0);

    my $local_host_name = Sys::Hostname::hostname();
    unless ( $ping_handle->ping($local_host_name) ) {
        S_set_error( " check to ping local host ($local_host_name) failed ; MS Windows has invalid network config ; probably there are some problems later ; S_ping return success anyway\n", 0 );
        return 1;
    }

    return 1 if $main::opt_offline;

    if ( $ping_handle->ping($requested_host) ) {
        S_w2log( 5, " S_ping : Host '$requested_host' is alive\n" );
        $Alive_Hosts{$requested_host} = $ping_handle;
        return 1;
    }
    else {
        S_w2log( 4, " S_ping : Host '$requested_host' is not alive\n" );
        return 0;
    }
}

#####################################################################

=head2 S_kill_process

    S_kill_process ( $process_name , [ $HOST ] );

    Retrieves all process IDs on host $HOST, sorted by name with S_get_Win32_processes
    
    Killing all process IDs which match with given process_name
    ( using DOS cmd : kill <pid>)

=cut

#####################################################################
sub S_kill_process {
    my $program_name = shift;
    my $hostname     = shift;

    my ( $procname, @procs, %process_by_name, );

    %process_by_name = S_get_Win32_processes($hostname);

    #     S_dump2log ( 2 , \%process_by_name , "Dump process_by_name" );

    @procs = grep( /$program_name/i, keys %process_by_name );
    foreach $procname (@procs) {
        S_w2log( 3, " S_kill_process : Killing all instances of process '$procname' on host '$hostname' \n" );
        S_remote_exec( $hostname, "taskkill", "/F /PID $_" ) foreach ( @{ $process_by_name{$procname} } );
    }

    return 1;
}

=head2 S_PROGRAM_ECU_SW

    S_PROGRAM_ECU_SW ( [ $hexfile ] );

    porgrams the ECU SW by flashing. $hexfile is optional (default is hexfile in SAD file folder).
    This function calls a project specific function that must be defined in ProjectDefaults.
    Typically a flashtool is called there, but project specific extras
    can be added there.

    #
    # TODO : function sounds like being part of the convinience layer
    #        should be moved to a TNT or Functional lib concerned to ECU access 
    #
    # See: Story 10831	
    #

=cut

sub S_PROGRAM_ECU_SW {

    my $hexfile = shift;

    # Call a (project specific) function to set battery voltage
    # The hash key 'FUNCTION_ECU_OFF' in ProjectDefaults points to a function reference.
    # The function itself is defined in ProjectDefaults.
    my $function_PROGRAM_ECU_SW = $main::ProjectDefaults->{'FUNCTION_PROGRAM_ECU_SW'};
    unless ($function_PROGRAM_ECU_SW) {
        S_set_error( "'FUNCTION_PROGRAM_ECU_SW' not defined in project defaults", 114 );
        return 0;
    }
    my $result = &$function_PROGRAM_ECU_SW($hexfile);
    return $result;
}

=head2 S_remote_exec

    $PID = S_remote_exec ( $MACHINE , $COMMAND , $ARGUMENTS );

Executes $COMMAND with $ARGUMENTS on remote computer $MACHINE and
returns the PID of the created process.

=cut

sub S_remote_exec {
    my $Machine = shift;
    my $CommandLine = join " ", @_;

    my ( $CLASS, $WMI, $Process, $vPid );

    $Machine =~ s|^[\\/]+||;
    $CLASS = "WinMgmts:{impersonationLevel=impersonate}!//$Machine";

    S_w2log( 3, "Trying to launch @_ on $Machine\n\n" );

    $WMI = Win32::OLE->GetObject($CLASS)
      or S_set_error( "Unable to connect to \\\\$Machine :" . Win32::OLE->LastError(), 5 );

    $Process = $WMI->Get("Win32_Process")
      or S_set_error( "Unable to get a Win32_Process :" . Win32::OLE->LastError(), 5 );

    $vPid = Variant( VT_I4 | VT_BYREF, 0 );    # $vPid (out) PID of the created Process

    if ( 0 == $Process->Create( $CommandLine, undef, undef, $vPid ) ) {
        return $vPid;
    }
    else {
        return;
    }
}

=head2 S_repeat_testcase

    S_repeat_testcase ( [$create_separate_HTML] );

B<Description>

This function indicates to the LIFT_execution_engine that
the testcase which is currently running has to be repeated.
There are two modes available which are selectable via 
the optional parameter $create_separate_HTML

=over

=item Mode 1: $create_separate_HTML = 0 or not given

The test case will be reexecuted. 
The HTML of the first execution will be enhanced with the data from the repetition.
The verdict of the previous test run will be overwritten.
The data in main_result (relevant for upload of test result to DOORS) 
will contain data only of the most recent execution.

=item Mode 2: $create_separate_HTML = 1 (or any true value)

The test case will be reexecuted.
The new test run will be documented in a separate HTML document with a separate verdict.
The test case number of the new test case will be combined out of 
the original test case number and the repetition number.

E.g. Test case 2 is repeated for the 3rd time:

    Test case number: 2_3

    Fileprefix: 0002_0003

=back

B<Examples>

=over

=item (Mode 1) Repeat without separate report and verdict

    S_repeat_testcase ();

=item (Mode 1) Repeat without separate report and verdict

    S_repeat_testcase ( 1 );

=back

B<Return value>

Function returns 1 on success.
Function returns undef if optional parameter is given in wrong format (e.g. as hash)

=cut

sub S_repeat_testcase {
    my @args = @_;
    return unless ( S_checkFunctionArguments( 'S_repeat_testcase ( [$create_separate_HTML] )', @args ) );

    my $create_separate_HTML = shift @args;
    $create_separate_HTML = 0 unless ( defined $create_separate_HTML );

    if ($create_separate_HTML) {
        S_w2log( 2, " S_repeat_testcase: TC will be repeated (with seperate HTML Report)\n" );
        $REPEAT_TC_FLAG = 2;    # Test case repeated in Mode 2
    }
    else {
        S_w2log( 2, " S_repeat_testcase: TC will be repeated (in same HTML Report)\n" );
        $REPEAT_TC_FLAG = 1;    # Test case repeated in Mode 1
    }

    return 1;
}

=head2 S_reset_TC_time

    $TC_starttime = 
        S_reset_TC_time ( );

B<Description>

Resets the Testcase time to zero. At testcase start, reads time into global variable $TC_starttime.

    Return :
        Current time value (gettimeofday) which is reference for TC time calculation

B<Example>

	$time = S_get_TC_time ();  # Testcase 1 execution started at 0.020176 
	$time = S_get_TC_time ();  # Testcase 2 execution started at 0.020335
	S_reset_TC_time ();        # Time resets to 0
	$time = S_get_TC_time ()   # Testcase 3 execution started at 0.000153

=cut

sub S_reset_TC_time {
    $TC_starttime = [gettimeofday];
    S_w2log( 4, " S_reset_TC_time: TC time is reset to 0\n" );

    return $TC_starttime;
}

=head2 S_set_sys_state

	S_set_sys_state ( $STATE );

B<Description>

Sets system state for execution engine state machine to new state $STATE.
Uses global variable $SYS_STATE, which indicates the state of execution engine.

Supported states are: SYS_INIT, SYS_READY, SYS_CLEAR, SYS_FAIL, TC_INIT, TC_STIMU, TC_EVAL, TC_FINAL and TC_FAIL 

SYS_FAIL is a final state and cannot be changed anymore.

B<Return Values>

1 - for supported SYS_STATE

0 - for unknown SYS_STATE

B<Example>

	S_set_sys_state ( SYS_INIT ); # set the system state to SYS_INIT
	S_set_sys_state ( SYS_READY ); # set the system state from SYS_INIT to SYS_READY


=cut

sub S_set_sys_state {
    my $given_state = shift;

    unless ( defined($given_state) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_set_sys_state(new_state)", 110 );
        return 0;
    }

    my $old_state = $SYS_STATE;

    unless ( grep { /$given_state/ } @valid_sys_states ) {
        $SYS_STATE = SYS_FAIL;
        S_w2log( 5, "set_system_state: invalid parameter: $given_state \n" );
        S_w2log( 5, "set_system_state: change SYS_STATE from $old_state -> $SYS_STATE \n" );
        return 0;
    }

    # SYS_FAIL is a final state and cannot be changed anymore
    if ( $old_state eq SYS_FAIL ) {
        S_w2log( 5, "set_system_state: change SYS_STATE from $old_state -> $given_state not allowed. SYS_STATE remains $old_state ! \n" );
        return 1;
    }

    S_w2log( 5, "SYS_STATE change: $old_state -> $given_state\n" );
    $SYS_STATE = $given_state;
    return 1;
}

=head2 S_w2eval

    S_w2eval ( [$content] );

    Write $content into Evaluation file.

    If no content given , write content from internal eval collection into Evaluation file.

    S_add2eval_collection() fills Internal eval collection

    after writing the content the internal eval collection will be deleted

=cut

sub S_w2eval {
    my $content = shift;

    if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} ) {
        if ( defined $content ) {
            ### unusal case (e.g. when headline will be written)
            print EVAL "$content";
            return 1;
        }

        my $delim      = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DELIMITER'};
        my $empty_char = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EMPTY_CHAR'};
        my @col_order  = @{ $main::ProjectDefaults->{'EVALUATION_FILE'}{'COLUMN_ORDER'} };

        my $eval_table_line = '';
        foreach my $column (@col_order) {
            if ( $content = $EVAL_COLLECTION{$column} ) {
                $eval_table_line = $eval_table_line . $content . $delim;
            }
            else {
                $eval_table_line = $eval_table_line . $empty_char . $delim;
            }
        }

        ## add new line char
        $eval_table_line = $eval_table_line . "\n";

        print EVAL $eval_table_line;
    }

    # delete the key from EVAL collection
    undef %EVAL_COLLECTION;
    @EVAL_TEXT = ();

    return 1;
}

=head2 S_w2res

    S_w2res ( $TEXT  );

Writes $TEXT to the resultfile and logfile.

=cut

sub S_w2res {
    my $text = shift;

    print RESULT "$text\n";

    return 1;
}

=head2 S_w2res_html

    S_w2res_html ( $TEXT  );

Writes $TEXT to the HTML resultfile.

=cut

sub S_w2res_html {
    my $text = shift;
    print RESULT_HTML "$text\n";

    return 1;
}

=head2 S_w2tc_html

    S_w2tc_html ( $FILENAME  );

Writes the report of the testcase to the HTML testcase file.

=cut

sub S_w2tc_html {
    my $file = shift;

    my ( $file_length, $add_text );

    unless ( open( TC_HTML, ">$file" ) ) {
        $file_length = length($file);
        $add_text = "(NOTE: file length = $file_length) " if $file_length >= 255;
        S_set_error( "Error opening $file $add_text: $!", 1 );
        return 0;
    }
    print TC_HTML @TC_HTML_TEXT;
    unless ( close(TC_HTML) ) { S_set_error( "Error closing $file : $!", 1 ); return 0; }

    return 1;
}

=head2 S_checkTextInHtml

    S_checkTextInHtml ( $searchRegexp );

Searches in each element of the global array @TC_HTML_TEXT for the regular expression $searchRegexp and returns the number of occurances.

This function can be used in TurboLIFT module tests to check if a certain output is written to the html log file.
STUB_reset will support this mechanism by emptying @TC_HTML_TEXT.

Example from LIFT_PD_simulation.t:

        cmp_ok( S_checkTextInHtml('PD already initialized') , '>', 0, 'PD_InitDiagnosis: expected report output' );

=cut

sub S_checkTextInHtml {
    my $searchRegexp = shift;

    unless ( defined($searchRegexp) ) {
        S_set_error( "! too less parameters ! SYNTAX: S_checkTextInHtml( searchRegexp )", 110 );
        return 0;
    }

    my $textFound = 0;
    foreach my $line (@TC_HTML_TEXT) {
        if ( $line =~ /$searchRegexp/ ) {
            $textFound++;
        }
    }
    return $textFound;
}

=head2 S_checkFunctionArguments

    $correct = S_checkFunctionArguments ( $functionPrototype, @arguments );

Checks if @arguments match the $functionPrototype in number and type.
The use case is to call this function at the beginning of each function and to let it check all arguments
instead of manuall checking the arguments.
Returns 1 if all arguments are correct. Otherwise it will set an error (and hence set the verdict to INCONC) and return 0.

$functionPrototype has the following form:

    '<functionName> ( <argument1> , <argument2>, ... [, <argumentn>, ...] )'

    The arguments between square brackets are optional.
    Square brackets my be nested, but this will not have any effect on functionality.
    Optional arguments have to come at the end of the argument list.
    If there are no optional arguments then the square brackets must be omitted.

    <argumentx> can be one of the following:
        $<name>      : scalar
        $<name>_aref : array reference
        $<name>_href : hash reference
        $<name>_mix  : mixed type, can be scalar, array reference or hash reference

    not allowed arguments are:
        @<name>      : use an arry reference instead
        %<name>      : use a hash reference instead
        \@<name>      : use $<name>_aref instead
        \%<name>      : use $<name>_href instead


Example: In EVAL_evaluate_signal_availability, the first commands could be

    my @args = @_;
    return 'VERDICT_INCONC' unless S_checkFunctionArguments( 'EVAL_evaluate_signal_availability ( $MEASURE_DATA_HREF , $SIGNAL_LABEL , $AVAILABILITY [, $TIME_LOG_START , $TIME_LOG_END ])', @args );

=cut

sub S_checkFunctionArguments {

    my @givenArguments    = @_;
    my $functionPrototype = shift @givenArguments;

    my @arguments = @givenArguments;

    my ( $function, $mandatoryArgString, $optionalArgString );

    # check format of $functionPrototype
    Readonly my $FUNCTION  => qr{ \w+                           }xms;                                 # function name
    Readonly my $MANARGS   => qr{ [ \s \w , \$ \@ \% \\ ]*      }xms;                                 # possible variable names, whitespace, comma, backslash
    Readonly my $OPTARGS   => qr{ [ \s \w , \$ \@ \% \[ \] \\]* }xms;                                 # possible variable names, whitespace, comma, backslash, square brackets
    Readonly my $PROTOTYPE => qr{ \s* ($FUNCTION) \s* \( ($MANARGS) \[? ($OPTARGS) \]? \s* \) }xms;
    if ( $functionPrototype =~ $PROTOTYPE ) {
        $function           = $1;
        $mandatoryArgString = $2;
        $optionalArgString  = $3;
    }
    else {
        S_set_error( "Function prototype $functionPrototype is not correct. It should have the following form: <functionName> ( <argument1> , <argument2>, ... [, <argumentn>, ...] ). Square brackets are optional.", 109 );
        return 0;
    }

    my $callingFunction = ( caller(1) )[3];
    $callingFunction = 'main' if not defined $callingFunction;
    $callingFunction =~ s/^\w+\:\://g;
    if ( $function ne $callingFunction ) {
        S_set_error( "Function name in prototype $functionPrototype is not the same as the callers name ($callingFunction).", 109 );
        return 0;
    }

    # remove whitespace and possible square brackets from argument list
    $mandatoryArgString =~ s/\s//g;
    $optionalArgString =~ s/[\s\[\]]//g;

    # split argument list into single arguments
    my @mandatoryArgs = split( /,/, $mandatoryArgString );

    # check each of the mandatory arguments
    foreach my $argumentName (@mandatoryArgs) {
        my $argumentValue = shift(@arguments);

        if ( $argumentName ne '' and not defined $argumentValue ) {
            S_set_error( "In function $functionPrototype: argument $argumentName is mandatory, but not given (undefined) is the actual call. Given argument values are: @givenArguments .", 110 );
            return 0;
        }
        else {
            my $correct = CheckArgumentType( $argumentName, $argumentValue, $functionPrototype, \@givenArguments );
            return 0 if not $correct;
        }
    }

    # split argument list into single arguments
    my @optionalArgs = split( /,/, $optionalArgString );

    # Check if first argument is empty. This is possible if a comma comes first in the optional arguments. If so remove the empty element
    my $firstArg = shift(@optionalArgs);
    if ( defined $firstArg and $firstArg ne '' ) {
        unshift( @optionalArgs, $firstArg );
    }

    # check each of the optional arguments (if they exist)
    foreach my $argumentName (@optionalArgs) {
        my $argumentValue = shift(@arguments);

        my $correct = CheckArgumentType( $argumentName, $argumentValue, $functionPrototype, \@givenArguments );
        return 0 if not $correct;

    }

    # check if there are still argument values left
    if ( @arguments > 0 ) {
        S_set_warning("In function $functionPrototype: There are more arguments given than defined in the function prototype. Given argument values are: @givenArguments .");
    }

    return 1;
}

=head2 CheckArgumentType (not exported)

    $correct = CheckArgumentType ( $argumentName, $argumentValue, $functionPrototype, $givenArguments_aref );

Checks whether $argumentName and $argumentValue match in type.
This is a sub-function of S_checkFunctionArguments.

=cut

sub CheckArgumentType {
    my $argumentName        = shift;
    my $argumentValue       = shift;
    my $functionPrototype   = shift;
    my $givenArguments_aref = shift;

    my @givenArguments = @{$givenArguments_aref};

    my %refType = ( '_aref' => 'ARRAY', '_href' => 'HASH' );

    my $firstChar = substr( $argumentName, 0, 1 );
    if ( $firstChar eq '$' ) {    # starts with $
        my $suffix4 = lc( substr( $argumentName, -4, 4 ) );
        my $suffix5 = lc( substr( $argumentName, -5, 5 ) );
        if ( $suffix5 eq '_aref' or $suffix5 eq '_href' ) {    # ends with _aref or _href
            if ( defined $argumentValue and ref($argumentValue) ne $refType{$suffix5} ) {
                S_set_error( "In function $functionPrototype: argument prototype ($argumentName) is a $refType{$suffix5} reference, but given argument ($argumentValue) is not a $refType{$suffix5} reference. All given argument values are: @givenArguments .", 109 );
                return 0;
            }
        }
        elsif ( $suffix4 eq '_mix' ) {                         # ends with _mix
                                                               # can be any type, no check to be done
            return 1;
        }
        else {                                                 # simple scalar (typically), actualy anything other than an array ref or a hash ref
            if ( defined $argumentValue and ( ref($argumentValue) eq 'ARRAY' or ref($argumentValue) eq 'HASH' ) ) {
                S_set_error( "In function $functionPrototype: argument prototype ($argumentName) is a scalar, but given argument ($argumentValue) is a reference. All given argument values are: @givenArguments .", 109 );
                return 0;
            }
        }
    }
    elsif ( $firstChar eq '@' ) {                              # starts with @
        S_set_error( "In function $functionPrototype: argument prototype ($argumentName) is an array. This is not allowed. Please use an array reference instead", 109 );
        return 0;
    }
    elsif ( $firstChar eq '%' ) {                              # starts with %
        S_set_error( "In function $functionPrototype: argument prototype ($argumentName) is a hash. This is not allowed. Please use a hash reference instead", 109 );
        return 0;
    }
    elsif ( $argumentName eq '' ) {                            # is empty
        S_set_error( "In function $functionPrototype: There is an empty argument. This is not allowed.", 109 );
        return 0;
    }
    else {
        S_set_error( "In function $functionPrototype: argument prototype ($argumentName) has unknown type. It should be either a scalar (\$<name>), an array reference (\$<name>_aref) or a hash reference (\$<name>_href).", 109 );
        return 0;
    }

    return 1;
}

=head2 S_checkFunctionArgumentHashKeys

    $returnValue = S_checkFunctionArgumentHashKeys( $functionName, $given_args_href, $valid_args_href, $mandatory_args_href );

Checks whether the given keys inside hash are valid (all mandatory keys and no extra unknown keys are given).

In case of errors, error code "wrong parameters" (109) is written to standard logfile and HTML test case report

B<Arguments:>

=over

=item $functionName 

The function name, which calls this function.

=item $given_args_href 

Hash defines the set of given keys.

=item $valid_args_href 

Hash defines the set of valid keys.

=item $mandatory_args_href 

Hash defines the set of mandatory keys.

=back

B<Return Value:>

=over

=item $returnValue 

$returnValue = 1: Success

$returnValue = 0: Fail (error message will be written, see example below)

=back

B<Examples:>

    1 = S_checkFunctionArgumentHashKeys( "functionCalling",
                                        { 'key1' => 1, 'key2' => 1 },
                                        { 'key1' => 1, 'key2' => 1 },
                                        { 'key1' => 1, 'key2' => 1 }
                                        );
                                        
    0 = S_checkFunctionArgumentHashKeys( "functionCalling",
                                        { 'key1' => 1 },
                                        { 'key1' => 1, 'key2' => 1 },
                                        { 'key1' => 1, 'key2' => 1 }
                                        );

        And writes following lines to log:
        
        !--ERROR--! => functionCalling :: The key(s) ' key2 ' is(are) mandatory. <= !--ERROR--!
         type     : wrong parameters {CODE: 109}

B<Notes:> 

Typical usage:

A 'function' expecting an href as input argument containing key-value-pairs

   $args_href = {
                            'key1' =>  $keyValue1,
                            'key2' =>  $keyValue2
   }

sub function
{

    my $inArgs_href = shift;

    my $validKeys_href = {
                            'key1' => 1,
                            'key2' => 1
    };
    my $mandatoryKeys_href = {
                            'key1' => 1,
                            'key2' => 1
    };

    my $status = S_checkFunctionArgumentHashKeys( "function", $inArgs_href, $validKeys_href, $mandatoryKeys_href )
    if ( $status == 0 ) { return 0; } # Abort function (error message was already written to log)

}

=cut

sub S_checkFunctionArgumentHashKeys {
    my $functionName        = shift;
    my $given_args_href     = shift;
    my $valid_args_href     = shift;
    my $mandatory_args_href = shift;

    #collect the keys which are invalid
    my @invalid_keys     = grep { !exists( $$valid_args_href{$_} ) } keys %$given_args_href;
    my @missingMand_keys = grep { !exists( $$given_args_href{$_} ) } keys %$mandatory_args_href;

    # error if the keys are wrongly configured
    if (@invalid_keys) {
        local $" = ', ';
        my @valid_keys = keys %$valid_args_href;
        S_set_error( "$functionName :: The key(s) < @invalid_keys > configured are invalid. Valid keys are < @valid_keys >\n", 109 );
        return 0;
    }

    # error if the mandatory keys are not configured
    if (@missingMand_keys) {
        local $" = ', ';
        S_set_error( "$functionName :: The key(s) ' @missingMand_keys ' is(are) mandatory.\n", 109 );
        return 0;
    }
    return 1;
}

=head2 S_checkSingleValue

    $success = S_checkSingleValue( $name, $singleValue, $expectedValues_href, $actionOnMismatch );

Checks that the value ($singleValue) of the variable $name matches the expected values as defined in $expectedValues_href.

B<Arguments:>

=over

=item $name 

Name of the variable to check.

=item $singleValue 

Value of the variable to check.
$singleValue can be undefined, a scalar value or a reference

=item $expectedValues_href 

    $expectedValues_href = {
        list => [<value1>, <value2, ...>],   # check is OK if $singleValue matches one of the given values in list (case dependent)
        list_i => [<value1>, <value2, ...>], # check is OK if $singleValue matches one of the given values in list (case independent)
        min => <min-value>,                  # check is OK if $singleValue is >= <min-value>
        max => <max-value>,                  # check is OK if $singleValue is <= <max-value>
        ref => <ref-value>,                  # check is OK if ref($singleValue) is <ref-value> (case independent)
        regex => <regular expression>,       # check is OK if $singleValue matches <regular expression> (case dependent)
        regex_i => <regular expression>,     # check is OK if $singleValue matches <regular expression> (case independent)
        eval => <perl expression>,           # check is OK if <perl expression> evaluates to true; the variable $singleValue
                                             # should be used in the Perl expression
        defined => <bool>                    # check is OK if defined($singleValue) is <bool>
        or => <bool>                         # if <bool> is true then all
    }

=item $actionOnMismatch 

Action that will be performed if a mismatch is found in the check. Can be one of 'none', 'warning', 'error', 'fail'.

=back

B<Return Value:>

=over

=item $success 

1 if $singleValue satisfies B<all> defined expected values in $expectedValues_href. 
However if or => 1 is set then $success = 1 if B<one> of the defined expected values in $expectedValues_href is satisfied.

undef otherwise.

=back

B<Examples:>

    # $success = 1 if 0 <= $singleValue <= 2
    $success = S_checkSingleValue( $name, $singleValue, {min => 0, max => 2}, 'none' );

    # $success = 1 if $singleValue is one of 'foo', 'bar' (exact match). If not a warning will be thrown.
    # If $singleValue = 'FOO' then $success = undef and warning.
    $success = S_checkSingleValue( $name, $singleValue, {list => ['foo', 'bar']}, 'warning' );

    # $success = 1 if $singleValue is one of 'foo', 'bar' (case independent). If not a warning will be thrown.
    # If $singleValue = 'FOO' then $success = 1 and no warning.
    $success = S_checkSingleValue( $name, $singleValue, {list_i => ['foo', 'bar']}, 'warning' );

    # $success = 1 if $singleValue is as array reference.
    $success = S_checkSingleValue( $name, $singleValue, {ref => 'array'}, 'none' );

    # $success = 1 if $singleValue matches /^fo/. If not an error will be thrown.
    # If $singleValue = 'FOO' then $success = undef and error.
    $success = S_checkSingleValue( $name, $singleValue, {regex => '^fo'}, 'error' );

    # $success = 1 if $singleValue matches /^fo/i. If not an error will be thrown.
    # If $singleValue = 'FOO' then $success = 1 and no error.
    $success = S_checkSingleValue( $name, $singleValue, {regex_i => '^fo'}, 'error' );

    # $success = 1 if the highest bit of the byte value $singleValue is set. If not VERDICT_FAIL will be set.
    # If $singleValue = 0xFF then $success = 1 and no verdict set. If $singleValue = 0x0F then $success = undef and VERDICT_FAIL.
    $success = S_checkSingleValue( $name, $singleValue, {eval => '($singleValue & 0x80) > 0'}, 'fail' );

=cut

sub S_checkSingleValue {
    my @args = @_;

    my $name                = shift @args;
    my $singleValue         = shift @args;
    my $expectedValues_href = shift @args;
    my $actionOnMismatch    = shift @args;

    S_checkFunctionArguments( 'S_checkSingleValue( $name, $expectedValues_href, $actionOnMismatch )', $name, $expectedValues_href, $actionOnMismatch ) or return;

    #STEP Define a mapping with check functions for each key in $expectedValues_href
    my $checkMapping_href = {
        list    => \&CheckSingleListValue,
        list_i  => \&CheckSingleListValue,
        min     => \&CheckSingleMinMaxValue,
        max     => \&CheckSingleMinMaxValue,
        ref     => \&CheckSingleRefValue,
        regex   => \&CheckSingleRegexValue,
        regex_i => \&CheckSingleRegexValue,
        eval    => \&CheckSingleEvalValue,
        defined => \&CheckSingleDefinedValue,
        or      => \&CheckSingleOrValue,
    };

    my $fulfillAll = 1;
    my $matchCount = 0;
    if ( $expectedValues_href->{or} ) {
        $fulfillAll = 0;
    }

    my $mismatch;
    my $expectedString = '{ ';    # this variable will hold a string representation of $expectedValues_href

    #LOOP-START Loop over keys of $expectedValues_href
    foreach my $expectedType ( sort keys %{$expectedValues_href} ) {
        my $expectedValue = $expectedValues_href->{$expectedType};

        #STEP Get check function from mapping
        my $checkFunction = $checkMapping_href->{$expectedType};
        if ( not defined $checkFunction ) {
            my @supportedKeys = sort keys %$checkMapping_href;
            S_set_error("Unknown key '$expectedType' in \$expectedValues_href. Supported keys are: @supportedKeys");
            return;
        }

        #STEP Call check function
        $mismatch = &$checkFunction( $name, $expectedType, $expectedValue, $singleValue, \$expectedString );
        next if $expectedType eq 'or';    # key 'or' shall not be used for counting matches
        if ( not defined $mismatch ) {
            $matchCount++;
        }
        elsif ($fulfillAll) {
            last;
        }
    }

    #LOOP-END Last key?

    #STEP Return 1 if no mismatch found
    $expectedString =~ s/,\s$/ }/;
    if ( ( $fulfillAll and not defined $mismatch ) or ( not $fulfillAll and $matchCount > 0 ) ) {
        S_w2log( 4, "Given value of '$name' (= $singleValue) fulfills expected values: $expectedString\n" );
        return 1;
    }

    if ( not $fulfillAll ) {
        $mismatch = "Given value of '$name' (= $singleValue) does not fulfill any of the expected values: $expectedString";
    }

    #STEP Do $actionOnMismatch
    if ( $actionOnMismatch eq 'none' ) {
        S_w2log( 4, "$mismatch\n" );
    }
    elsif ( $actionOnMismatch eq 'warning' ) {
        S_set_warning($mismatch);
    }
    elsif ( $actionOnMismatch eq 'error' ) {
        S_set_error($mismatch);
    }
    elsif ( $actionOnMismatch eq 'fail' ) {
        S_w2log( 4, "$mismatch\n" );
        S_set_verdict(VERDICT_FAIL);
    }
    else {
        S_set_error("\$actionOnMismatch = '$actionOnMismatch' is unknown. Supported values are: none, warning, error, fail");
        return;
    }

    #STEP Return undef
    return;
}

sub CheckSingleMinMaxValue {
    my ( $name, $expectedType, $expectedValue, $singleValue, $expectedString_ref ) = @_;

    my $mismatch;
    $$expectedString_ref .= "$expectedType => $expectedValue, ";
    if ( $expectedType eq 'min' ) {
        if ( $singleValue < $expectedValue ) {
            $mismatch = "Given value of '$name' (= $singleValue) is less than given minimum value $expectedValue";
        }
    }
    elsif ( $expectedType eq 'max' ) {
        if ( $singleValue > $expectedValue ) {
            $mismatch = "Given value of '$name' (= $singleValue) is greater than given maximum value $expectedValue";
        }
    }

    return $mismatch;
}

sub CheckSingleListValue {
    my ( $name, $expectedType, $expectedValue, $singleValue, $expectedString_ref ) = @_;

    my $mismatch;

    if ( ref($expectedValue) ne 'ARRAY' ) {
        S_set_error("For \$expectedValues_href key = 'list' or 'list_i' the value must be an array ref.");
        return;
    }

    my $listString = join( ',', @$expectedValue );
    $$expectedString_ref .= "$expectedType => [$listString], ";

    if ( $expectedType eq 'list' ) {
        unless ( grep { $singleValue eq $_ } @$expectedValue ) {
            $mismatch = "Given value of '$name' (= $singleValue) is not part of the expected list (case dependent): $listString";
        }
    }
    elsif ( $expectedType eq 'list_i' ) {
        unless ( grep { lc($singleValue) eq lc($_) } @$expectedValue ) {
            $mismatch = "Given value of '$name' (= $singleValue) is not part of the expected list (case independent): $listString";
        }
    }

    return $mismatch;
}

sub CheckSingleRegexValue {
    my ( $name, $expectedType, $expectedValue, $singleValue, $expectedString_ref ) = @_;

    my $mismatch;

    $$expectedString_ref .= "$expectedType => '$expectedValue', ";

    if ( $expectedType eq 'regex' ) {
        if ( $singleValue !~ /$expectedValue/ ) {
            $mismatch = "Given value of '$name' (= $singleValue) does not match given regular expression /$expectedValue/";
        }
    }
    elsif ( $expectedType eq 'regex_i' ) {
        if ( $singleValue !~ /$expectedValue/i ) {
            $mismatch = "Given value of '$name' (= $singleValue) does not match given regular expression /$expectedValue/i";
        }
    }

    return $mismatch;
}

sub CheckSingleEvalValue {
    my ( $name, $expectedType, $expectedValue, $singleValue, $expectedString_ref ) = @_;

    my $mismatch;

    $$expectedString_ref .= "$expectedType => '$expectedValue', ";
    if ( not eval $expectedValue ) {
        $mismatch = "Given value of '$name' (= $singleValue) does not fulfill the given Perl expression '$expectedValue'";
    }

    return $mismatch;
}

sub CheckSingleRefValue {
    my ( $name, $expectedType, $expectedValue, $singleValue, $expectedString_ref ) = @_;

    my $mismatch;

    $$expectedString_ref .= "$expectedType => '$expectedValue', ";
    if ( lc( ref($singleValue) ) ne lc($expectedValue) ) {
        $mismatch = "Given value of '$name' (= $singleValue) is not a reference of the given type: '$expectedValue'";
    }

    return $mismatch;
}

sub CheckSingleDefinedValue {
    my ( $name, $expectedType, $expectedValue, $singleValue, $expectedString_ref ) = @_;

    my $mismatch;

    $$expectedString_ref .= "$expectedType => '$expectedValue', ";
    if ( $expectedValue and not defined $singleValue ) {
        $mismatch = "Given value of '$name' (= $singleValue) is not defined as expected";
    }
    elsif ( not $expectedValue and defined $singleValue ) {
        $mismatch = "Given value of '$name' (= $singleValue) is defined which is not expected";
    }

    return $mismatch;
}

sub CheckSingleOrValue {
    my ( $name, $expectedType, $expectedValue, $singleValue, $expectedString_ref ) = @_;

    $$expectedString_ref .= "$expectedType => '$expectedValue', ";
    return;
}

sub Select_action_on_mismatch {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Select_action_on_mismatch ( [,$options_href] )', @args );
    my $options_href       = shift @args;
    my $action_on_mismatch = $options_href->{action_on_mismatch};
    if ( not defined $action_on_mismatch ) {
        $action_on_mismatch = 'error';
    }
    else {
        my @supported_action_mismatches = qw(none warning error w2log);
        unless ( grep { $_ =~ /$action_on_mismatch/i } @supported_action_mismatches ) {
            $action_on_mismatch = 'error';
        }
    }
    return $action_on_mismatch;
}

=head2 AUTOLOAD

    <any TurboLIFT function>_NOERROR ( <any arguments> );
    <any TurboLIFT function>_NOHTML ( <any arguments> );
    <any TurboLIFT function>_NOVERDICT ( <any arguments> );
    <any TurboLIFT function>_LOGMEMORY ( <any arguments> );
    
The AUTOLOAD function catches all function calls in a perl package that are not defined.
By exporting the AUTOLOAD function it will become effective in all TurboLIFT modules and test case modules.
With this mechanism it is possible to add suffixes for all TurboLIFT functions.
Two types of suffixes are defined.

1) _NOERROR: When calling a function with this suffix all errors that occur in the function and all its subfunctions will be treated as warnings,
so VERDICT_INCONC will not be set. This can be useful if you want to test that e.g. writing to a protected memory area using PD_WriteMemoryByName
is really not possible. This is expected behaviour, but without the suffix it would result in an error.

2) _NOHTML: When calling a function with this suffix there will be no logging to the html report in the function and all its subfunctions.
However logging to the text log file and to the console will happen normally. This can be useful if functions are called in a loop and would
without using the suffix produce the same html output over and over again.

3) _NOVERDICT: When calling a function with this suffix all verdicts "pass" or "fail" that occur in this function and all its subfunctions
 will be suppressed. This can be useful when you want to make an evaluation which should not effect the global TC verdict. 

4) _LOGMEMORY: When calling a function with this suffix then before and after the call the function S_get_LiftProcessMemory is called.
This can be useful when you want to find memory leaks in testcase or engine code

Example:

        PD_WriteMemoryByName_NOERROR( $protectedVariable, $value );
        FM_CD_measureQualiDequaliTime_NOHTML($faultname, $time);
		PD_check_fault_exists_NOVERDICT( $flt_mem_struct, $faultname );
=cut

sub AUTOLOAD {
    my @args = @_;

    our $AUTOLOAD;    # will be magically filled with the fully qualified name of the unknown function
    my $function = $AUTOLOAD;

    my @returnValues;

    if ( $function =~ /(.+)_NOERROR$/i ) {

        # Introduce $noerrorCounter. As long as $noerrorCounter > 0 no error will be set. This also works with nested usage of _NOERROR
        $noerrorCounter++;
        S_w2log( 5, "Calling the function $1 with option _NOERROR: all errors in this function and all its subfunctions will be treated as warnings and VERDICT_INCONC will not be set.\n" );
        {
            no strict "refs";    # applies only inside the curly brackets (page 433 PBP)
            @returnValues = &$1(@args);    # call the function without '_NOERROR'
        }
        $noerrorCounter--;
    }
    elsif ( $function =~ /(.+)_NOHTML$/i ) {

        # Introduce $nologCounter. As long as $nologCounter > 0 no logging will be done. This also works with nested usage of _NOHTML
        $nologCounter++;
        S_w2log( 5, "Calling the function $1 with option _NOLOG: no logging into the html report will be done in this function and all its subfunctions.\n" );
        {
            no strict "refs";              # applies only inside the curly brackets (page 433 PBP)
            @returnValues = &$1(@args);    # call the function without '_NOLOG'
        }
        $nologCounter--;
    }
    elsif ( $function =~ /(.+)_NOVERDICT$/i ) {

        # Introduce $noverdictCounter. As long as $noverdictCounter > 0 no verdict change be done. This also works with nested usage of _NOVERDICT
        $noverdictCounter++;
        S_w2log( 5, "Calling the function $1 with option _NOVERDICT: all verdicts in this function and all its subfunctions will not update the global VERDICT.\n" );
        {
            no strict "refs";              # applies only inside the curly brackets (page 433 PBP)
            @returnValues = &$1(@args);    # call the function without '_NOVERDICT'
        }
        $noverdictCounter--;
    }
    elsif ( $function =~ /(.+)_LOGMEMORY$/i ) {
        S_w2log( 5, "Calling the function $1 with option _LOGMEMORY: S_get_LiftProcessMemory will be called before and after this function.\n" );
        S_get_LiftProcessMemory();
        {
            no strict "refs";              # applies only inside the curly brackets (page 433 PBP)
            @returnValues = &$1(@args);    # call the function without '_NOVERDICT'
        }
        S_get_LiftProcessMemory();
    }
    else {
        S_set_error("Function $function is not known in TurboLIFT");
        return;
    }

    if ( defined $returnValues[1] ) {      # more than one value is returned from the function, so return all values
        return (@returnValues);
    }
    else {                                 # only one value (or none) is returned by the function, so return only this one value
        return ( $returnValues[0] );
    }

}

=head2 S_check_contents_of_hash

 $type_of_content = S_check_contents_of_hash ($param_aref[,$input_href]);

check the required contents from the given $input_href.
If $input_href is not specified, then by default, 'ProjectDefaults' hash is considered.

$param_aref =  This contains the key(s) whose value shall be returned from
               either $input_href or ProjectDefaults.
               This is mandatory parameter.

$input_href = Optional parameter

   return values :
      
      0 - required element not defined in given input_href or main::ProjectDefaults
      
      1 - required element is a scalar value ( not a reference )
      
      SCALAR / ARRAY / HASH - type of content is a reference / type is returned

Examples :
          $type_of_content = S_check_contents_of_hash(['Mapping_CAN']);
           -> result is 'HASH'
           
          $type_of_content = S_check_contents_of_hash(['Mapping_CAN','CAN_MESSAGES','Can_ABECU_2_Diag','ID']);
           -> result is 1 because it is defined and a scalar value (not a ref)

=cut

sub S_check_contents_of_hash {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_check_contents_of_hash ( $param_aref [, $input_href] )', @args );

    my $param_aref = shift;
    my $input_href = shift;

    my $input_text    = "";
    my $content_value = {};

    my @param_aref_temp    = @$param_aref;            #local array to store $param_aref
    my $size_of_param_aref = scalar(@$param_aref);    #size of $param_aref

    my $param_aref_text = join( " -> ", @$param_aref );

    if ( defined $input_href ) {
        $input_text    = 'input_href from user';
        $content_value = $input_href;
    }
    else {
        $input_text    = 'ProjectDefaults';
        $content_value = $main::ProjectDefaults;
    }

    foreach my $i ( 0 .. $size_of_param_aref - 1 ) {
        $content_value = $content_value->{ $param_aref_temp[$i] };    #update the return hash for keys in a loop.
        unless ( defined $content_value )                             #if the corresponding key is not defined in the hash, throw error
        {
            S_w2log( 3, " S_check_contents_of_hash : $input_text -> $param_aref_text is NOT DEFINED ==> return 0\n" );
            return 0;
        }
    }

    my $type_return_is_ref = ref $content_value;

    if ($type_return_is_ref) {
        S_w2log( 4, " S_check_contents_of_hash: $input_text -> $param_aref_text ==> return '$type_return_is_ref' \n" );
        return $type_return_is_ref;
    }
    else {
        S_w2log( 4, " S_check_contents_of_hash: $input_text -> $param_aref_text = $content_value  ==> return 1 \n" );
        return 1;
    }

}

=head2 S_get_contents_of_hash

    $returnValue = S_get_contents_of_hash( $param_aref, [, $input_href, $options_href ] );

Returns the required contents from the given $input_href.
If $input_href is not specified, then by default, 'ProjectDefaults' hash is considered.

B<Arguments:>

=over

=item $param_aref 

This contains the key(s) whose value shall be returned from  either $input_href or ProjectDefaults. This is mandatory parameter.

=item $input_href 

(optional) Input href from user. 

If $input_href is not specified, undef has to be passed and by default 'ProjectDefaults' hash is considered.

=item $options_href

(optional) Optional href which shall provide additional options to users. 

$options_href => {    
    action_on_mismatch => <action>,      
}

    - action_on_mismatch : action to be taken when the keys of hash ($input_href or ProjectDefaults) not found
    - <action> can be one of  ->  'none', 'w2log' , 'warning', 'error' (default),
                                  'none' ->  nothing will be done.
                                  'w2log' -> write to log level 4.
                                  'warning' -> write only warning, no error.
                                  'error' -> write an error. (this is the default case.)

If $options_href is not defined then error will be thrown if hash key(s) are not found. 

=back

B<Return Value:>

=over

=item $content_value 

return the content value of the input hash key(s).

=back

B<Examples:>

    S_get_contents_of_hash(['Mapping_CAN']);
    S_get_contents_of_hash(['Mapping_CAN','Diag_Byte_2','MESSAGE']);
    S_get_contents_of_hash(['Mapping_CAN','CAN_MESSAGES','Can_ABECU_2_Diag','ID']);
    S_get_contents_of_hash(['VTT','Sequence_Control','U_Diag'],$VTT);
    S_get_contents_of_hash(['VTT','Sequence_Control','U_Diag'],$VTT, {action_on_mismatch =>'none'});
    S_get_contents_of_hash(['VTT','Sequence_Control','U_Diag'],$VTT, {action_on_mismatch =>'w2log'});
    S_get_contents_of_hash(['VTT','Sequence_Control','U_Diag'],$VTT, {action_on_mismatch =>'warning'});
    S_get_contents_of_hash(['VTT','Sequence_Control','U_Diag'],$VTT, {action_on_mismatch =>'error'});
    S_get_contents_of_hash(['VTT','Sequence_Control','U_Diag'],undef, {action_on_mismatch =>'warning'}); # ProjectDefaults considered when $input_href is undef

=cut

sub S_get_contents_of_hash {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_get_contents_of_hash ( $param_aref [, $input_href, $options_href] )', @args );

    my $param_aref   = shift;
    my $input_href   = shift;
    my $options_href = shift;

    my $input_text         = "";
    my @error              = ();        #error array
    my $content_value      = {};
    my $action_on_mismatch = 'error';

    my @param_aref_temp    = @$param_aref;            #local array to store $param_aref
    my $size_of_param_aref = scalar(@$param_aref);    #size of $param_aref

    my $param_aref_text = join( " -> ", @$param_aref );

    if ( defined $input_href ) {
        $input_text         = 'input_href from user';
        $content_value      = $input_href;
        $action_on_mismatch = Select_action_on_mismatch($options_href);

    }
    else {
        $input_text         = 'ProjectDefaults';
        $content_value      = $main::ProjectDefaults;
        $action_on_mismatch = Select_action_on_mismatch($options_href);
    }

    foreach my $i ( 0 .. $size_of_param_aref - 1 ) {
        $content_value = $content_value->{ $param_aref_temp[$i] };    #update the return hash for keys in a loop.
        unless ( defined $content_value )                             #if the corresponding key is not defined in the hash, throw error
        {
            if ( lc $action_on_mismatch eq 'error' ) {
                S_set_error( "$input_text -> $param_aref_text is NOT DEFINED \n", 20 );
                return;
            }
            elsif ( lc $action_on_mismatch eq 'warning' ) {
                S_set_warning("$input_text -> $param_aref_text is NOT DEFINED \n");
                return;
            }
            elsif ( lc $action_on_mismatch eq 'w2log' ) {
                S_w2log( 4, "$input_text -> $param_aref_text is NOT DEFINED \n", );
                return;
            }
            else {
                # don't do anything..
                return;
            }

        }
    }

    my $type_return_is_ref = ref $content_value;

    if ($type_return_is_ref) {
        S_w2log( 4, " S_get_contents_of_hash: Return $input_text -> $param_aref_text =  < $type_return_is_ref > \n" );
    }
    else {
        S_w2log( 4, " S_get_contents_of_hash: Return $input_text -> $param_aref_text =  $content_value \n" );
    }

    return $content_value;
}

=head2 S_calculate_value_by_mask

    $ReturnValue = S_calculate_value_by_mask( $initial_value_given , $new_value_masked );

B<Description>

1. Reads the $initial_value_given and checks bit by bit with $new_value_masked

2. If '-' is available in $new_value_masked, then corresponding bit replace with bit value from $initial_value_given

3. Returns the decimal value of calculated binary value in step 2

B<Input Arguments>

$initial_value_given - Initial value to which mask operation to be performed. Formats can be Binary number ('0b...'), Hex number ('0x...') or Decimal number.

$new_value_masked  - New mask value. Always binary number and format should be 0bxxxxxxxx or xxxxxxxx	( 'x' can be 1/0/- )

B<Return Value> 

$ReturnValue -  After masking operation, calcluated value. Always in decimal format
   
	36 = S_calculate_value_by_mask( 0b000111 , "0b10--00" ); both input values are binary format
	36 = S_calculate_value_by_mask( 36 , "0b10--00" ); $initial_value_given is decimal format, $new_value_masked is binary
	36 = S_calculate_value_by_mask( 36 , "10--00" );
	32 = S_calculate_value_by_mask( 1 ,  "10--00" );

=cut

sub S_calculate_value_by_mask {
    my ( $initial_value_given, $new_value_masked ) = @_;

    S_w2log( 3, " S_calculate_value_by_mask : initial_value     : $initial_value_given \n " );
    S_w2log( 3, " S_calculate_value_by_mask : new_value_masked  : $new_value_masked \n " );

    # convert hex ('0x...') or bin ('0b...') number to to dec number
    $initial_value_given = S_0x2dec($initial_value_given);

    #Converting DEC to BIN format
    my $initial_value_bin = S_dec2bin($initial_value_given);

    S_w2log( 3, " S_calculate_value_by_mask : new_value_masked  : $new_value_masked \n " );

    my @array_mask    = split( //, reverse($new_value_masked) );
    my @array_initial = split( //, reverse($initial_value_bin) );

    #Comparing $initial_value_given with $new_value_masked in binary format
    #Replaces '-' bits with $initial_value_given bits
    foreach my $item_no ( 0 .. $#array_mask - 1 ) {
        while ( $array_mask[$item_no] =~ m/-/i ) {
            if   ( $array_initial[$item_no] ) { $array_mask[$item_no] = $array_initial[$item_no]; }
            else                              { $array_mask[$item_no] = 0; }
        }
    }

    my @calculated_value = reverse @array_mask;

    #Converts final binary value to decimal
    my $calc_value_bin = join( "", @calculated_value );
    my $returnValue = S_bin2dec($calc_value_bin);
    S_w2log( 2, " S_calculate_value_by_mask : calculated value to write : '$returnValue' \n" );

    return $returnValue;

}

=head2 S_bin2dec

    $DEC = S_bin2dec ( $BIN );
    
    returns decimal value of $BIN.

   $result = S_bin2dec ( 10101 );
     $result -> 21
     
   $result = S_bin2dec ( "10101" );
     $result -> 21

   $result = S_bin2dec ( "0b00111" );
     $result -> 7

=cut

sub S_bin2dec {
    my $given_bin_value = shift;
    my $value_to_check  = $given_bin_value;
    $value_to_check =~ s/0b//ig;
    if ( $value_to_check =~ /[^01]/ ) {
        S_set_error("given input value '$value_to_check' is not a binary string. Example binary string is '110010010' ");
        return;
    }
    my $ret_dec = unpack( "N", pack( "B32", substr( "0" x 32 . $value_to_check, -32 ) ) );
    S_w2log( 5, " S_bin2dec : (bin) $value_to_check -> $ret_dec (dec) \n" );
    return $ret_dec;
}

=head2 S_get_TC_number

    $tcNumber = S_get_TC_number ( );

Returns the running number of the current test case as four digit number with leading zeros.
This is the prefix of each test case html report file.
It represents the order of the test cases in the test list, so the first test case in the test list
(init campaign does not count) has '0001', the second test case in the test list has '0002' and so on.

=cut

sub S_get_TC_number {
    my $tcNumber = $main::file_prefix_number;
    return $tcNumber;
}

=head2 S_get_TC_parameter_name

    $tcParaName = S_get_TC_parameter_name ( );

Returns the parameter name of the current test case.

=cut

sub S_get_TC_parameter_name {
    my $tcParaName = $main::CURRENT_TC;
    my @parts = split( /\./, $tcParaName );
    $tcParaName = $parts[1];
    return $tcParaName;
}

################################################################

=head2 S_teststep

S_teststep ( <Comment_Text> , NO_AUTO_NBR|AUTO_NBR , <eval_keyword> );

Prints Comment_Text of S_teststep using Sw2rep() in color blue.

Comment_Text    : Text for the comment (you can use \n to have more than one line)

NO_AUTO_NBR        : No Automatic numbering of steps.

AUTO_NBR        : Automatic numbering of sub steps
                  Eg. (1)         if the Comment is a new Teststep
                      (2)        if the Comment is a new Teststep

(Default: AUTO_NBR)					  
					  
eval keyword    :stores an id to the teststep for later use in the S_teststep_expected or S_teststep_mismatch.

    S_teststep( "Pick up my bicycle from the Garage" , 'NO_AUTO_NBR' );                                                --> "Pick up my bicycle from the garage"

    S_teststep( "Read instruction from pressure pump" , 'NO_AUTO_NBR' )                                                --> "Read instruction from pressure pump"

     S_teststep( "Pump air into my bicycle tyres" , 'AUTO_NBR' );                                                    --> "(1) Pump air into my bicycle tyres"
                                                                                                                     --> increases internal Teststep Nbr.

    S_teststep( "Measure air pressure in my tyres" , 'AUTO_NBR' );                                                    --> "(2) Measure air pressure in my tyres"
                                                                                                                     --> increases internal Teststep Nbr.

    S_teststep( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' );                --> "(3) Measure air pressure in my rear tyre"
                                                                                                                     --> increases sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_rear as ID for S_teststep_expected or S_teststep_mismatch

######if RBT_Include_Stimuli_Comments is called befor it will also handle the comments out of the stimuli table.

=cut

######################################################
sub S_teststep
######################################################
{
    my @args = @_;
    return
      unless S_checkFunctionArguments( 'S_teststep ( $comment_Text , [ $is_Nbr [ , $_keyword ] ] )', @args );

    my $comment_Text = shift @args;
    my $is_Nbr       = shift @args // 'AUTO_NBR';
    my $eval_keyword = shift @args;

    my $step_counter_text;
    my $empty_counter_text = "     ";
    my $html_teststep_bookmark;
    my $html_teststep_link;

    manage_counter();

    if ( $is_Nbr eq 'AUTO_NBR' ) {
        $STEP_COUNTER_HASH->{Nbr_Teststep}++;    # increment STEP Counter for actual $Comment_Id
        $STEP_COUNTER_HASH->{Nbr_2ndLevel_Teststep} = 0;    # reset Subcomment Counter
        $step_counter_text = sprintf $STEP_COUNTER_HASH->{Nbr_Teststep}, '%02s';    # prepare Counter Text for comment
    }
    else {
        $step_counter_text = $empty_counter_text;
    }

    if ( defined $eval_keyword ) {
        set_keyword( $eval_keyword, $step_counter_text ) || return;
        $html_teststep_bookmark = "<a name=\"teststep__$eval_keyword\"></a>";
    }

    foreach my $step_comment ( split /\\n/, $comment_Text )                         #for comments with more than one line
    {
        my $text = $step_comment;
        $text = "($step_counter_text) " . $text if $step_counter_text =~ m/\w+/;
        if ($html_teststep_bookmark) {
            $html_teststep_link = "$html_teststep_bookmark <a href=\"#check__$eval_keyword\">$text</a>";
            S_w2log( 'teststep', "\n" . $html_teststep_link . "\n", 'blue' );       # only to HTML
        }
        else {
            S_w2log( 'teststep', "\n" . $text . "\n", 'blue' );                     # only to HTML
        }
        S_w2log( TEXT | CONSOLE, "\n" . $text . "\n" );                             # seperate print of text to TEXT log-file and CONSOLE

        S_add2eval_collection( 'Stimulation', $text );
        S_add2eval_collection( 'Eval_keyword', $eval_keyword ) if ( defined $eval_keyword );

        $step_counter_text = $empty_counter_text;
    }

    return 1;
}

################################################################

=head2 S_teststep_2nd_level

S_teststep_2nd_level ( <Comment_Text> , NO_AUTO_NBR|AUTO_NBR , <eval_keyword> );

Prints Comment_Text of S_teststep_2nd_level using Sw2rep() in color blue.

Comment_Text    : Text for the comment (you can use \n to have more than one line)

NO_AUTO_NBR        : No Automatic numbering of steps.

AUTO_NBR        : Automatic numbering of sub steps
                  Eg. (1-1)     if the Comment is a new sub Teststep
                      (1-2)     if the Comment is a new sub Teststep

eval keyword    :stores an id to the teststep for later use in the S_teststep_expected or S_teststep_mismatch.

    S_teststep_2nd_level( "Pump air into my front tyre until 1.5 bar"  , 'AUTO_NBR' );                                --> "(1-1) Pump air into my front tyre until 1.5 bar"
                                                                                                                    --> increases internal sub Teststep Nbr.

    S_teststep_2nd_level( "Pump air into my rear tyre until 1.8 bar" , 'AUTO_NBR');                                    --> "(1-2) Pump air into my rear tyre until 1.8 bar"
                                                                                                                    --> increases internal sub Teststep Nbr.

     S_teststep( "Measure air pressure in my tyres" , 'AUTO_NBR' );                                                    --> "(2) Measure air pressure in my tyres"
                                                                                                                     --> increases internal Teststep Nbr.

    S_teststep_2nd_level( "Measure air pressure in my front tyre" , 'AUTO_NBR' , 'my_pressure_measurement_front' );    --> "(2-1) Measure air pressure in my front tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_front as ID for S_teststep_expected or S_teststep_mismatch

    S_teststep_2nd_level( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' );    --> "(2-2) Measure air pressure in my rear tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_rear as ID for S_teststep_expected or S_teststep_mismatch

######if RBT_Include_Stimuli_Comments is called befor it will also handle the comments out of the stimuli table.

=cut

######################################################
sub S_teststep_2nd_level
######################################################
{
    my @args = @_;
    return
      unless S_checkFunctionArguments( 'S_teststep_2nd_level ( $comment_Text , $is_Nbr [ , $_keyword ] )', @args );

    my $comment_Text = shift @args;
    my $is_Nbr       = shift @args;
    my $eval_keyword = shift @args;

    my $step_counter_text;
    my $empty_counter_text = "     ";
    my $html_teststep_bookmark;
    my $html_teststep_link;

    unless ( $is_Nbr eq 'AUTO_NBR' || $is_Nbr eq 'NO_AUTO_NBR' ) {
        S_set_error("missing parameter : call S_teststep_2nd_level ('Comment_Text','NO_AUTO_NBR|AUTO_NBR','eval keyword' ) ");
        return;
    }

    manage_counter();

    $step_counter_text = $empty_counter_text;

    if ( $is_Nbr eq 'AUTO_NBR' ) {
        $STEP_COUNTER_HASH->{Nbr_2ndLevel_Teststep}++;    # increment Subcomment Counter
        $step_counter_text = sprintf '%01s', $STEP_COUNTER_HASH->{Nbr_Teststep};                        # prepare Counter Text for comment
        $step_counter_text = $step_counter_text . "-" . $STEP_COUNTER_HASH->{Nbr_2ndLevel_Teststep};    # Modify Counter Text if Subcomment required
    }
    else {
        $step_counter_text = $empty_counter_text;
    }

    if ( defined $eval_keyword ) {
        set_keyword( $eval_keyword, $step_counter_text ) || return;
        $html_teststep_bookmark = "<a name=\"teststep__$eval_keyword\"></a>";
    }
    else {
        $eval_keyword = "    ";
    }

    foreach my $step_comment ( split /\\n/, $comment_Text )    #for comments with more than one line
    {
        my $text = $step_comment;
        $text = "($step_counter_text) " . $text if $step_counter_text =~ m/\w+/;
        if ($html_teststep_bookmark) {
            $html_teststep_link = "$html_teststep_bookmark <a href=\"#check__$eval_keyword\">$text</a>";
            S_w2log( 'teststep', "\n" . $html_teststep_link . "\n", 'blue' );    # HTML report only
        }
        else {
            S_w2log( 'teststep', "\n" . $text . "\n", 'blue' );                  # HTML report only
        }
        S_w2log( TEXT | CONSOLE, "\n" . $text . "\n" );                          # seperate print of text to TEXT log-file and CONSOLE

        S_add2eval_collection( 'Stimulation', $text );
        S_add2eval_collection( 'Eval_keyword', $eval_keyword ) if ( defined $eval_keyword );
        $step_counter_text = $empty_counter_text;
    }

    return 1;

}

################################################################

=head2 S_teststep_expected

S_teststep_expected ( <Comment_Text> , <eval_keyword> );

Prints Comment_Text of S_teststep_expected using Sw2rep() in color blue.

Comment_Text    : Text for the comment (you can use \n to have more than one line)

eval keyword    : Retrieves ID from S_teststep or S_teststep_2nd_level.

    S_teststep_2nd_level( "Measure air pressure in my front tyre" , 'AUTO_NBR' , 'my_pressure_measurement_front' );    --> "(1-1) Measure air pressure in my front tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_front as ID for S_teststep_expected or S_teststep_mismatch

    S_teststep_2nd_level( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' );    --> "(1-2) Measure air pressure in my rear tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_rear as ID for S_teststep_expected or S_teststep_mismatch

    S_teststep_expected( "Air pressure front tyre 1.4 .. 1.6 bar" , 'my_pressure_measurement_front' );                --> "(1-1 EXPECTED) Air pressure front tyre 1.4 .. 1.6 bar"
                                                                                                                    -->    (1-1) is derived from [S_teststep_2nd_level( "Measure air pressure in my front tyre" , 'AUTO_NBR' , 'my_pressure_measurement_front' ) ]
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> retrieves <eval_keyword> my_pressure_measurement_front as  ID from S_teststep_2nd_level

    S_teststep_expected( "Air pressure rear tyre 1.7 .. 1.9 bar" , 'my_pressure_measurement_rear');                    --> "(1-2 EXPECTED) Air pressure front tyre 1.7 .. 1.9 bar"
                                                                                                                    -->    (1-2) is derived from [S_teststep_2nd_level( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' ) ]
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> retrieves <eval_keyword> my_pressure_measurement_rear as ID from S_teststep_2nd_level

######if RBT_Include_Stimuli_Comments is called befor it will also handle the comments out of the stimuli table.

=cut

######################################################
sub S_teststep_expected
######################################################
{
    my @args = @_;
    return
      unless S_checkFunctionArguments( 'S_teststep_expected ( $comment_Text [ , $_keyword ] )', @args );

    my $comment_Text = shift @args;
    my $eval_keyword = shift @args;

    my $step_counter_text  = "";
    my $empty_counter_text = "     ";
    my $html_teststep_bookmark;
    my $html_teststep_link;

    manage_counter();

    if ( defined $eval_keyword ) {
        $step_counter_text = get_keyword($eval_keyword) || return;
        $html_teststep_bookmark = "<a name=\"expect__$eval_keyword\"></a>";    # bookmark is not used currently
    }

    foreach my $step_comment ( split /\\n/, $comment_Text )    # for comments with more than one line
    {
        my $text = "(EXPECTED) $step_comment";
        $text =~ s/EXPECTED/$step_counter_text EXPECTED/ if $step_counter_text =~ m/\w+/;
        if ($html_teststep_bookmark) {
            $html_teststep_link = "$html_teststep_bookmark <a href=\"#teststep__$eval_keyword\">$text</a>";
            S_w2log( 'teststep', "\n" . $html_teststep_link . "\n", 'blue' );
        }
        else {
            S_w2log( 'teststep', "\n" . $text . "\n", 'blue' );    # HTML report only
        }
        S_w2log( TEXT | CONSOLE, "\n" . $text . "\n" );            # seperate print of text to TEXT log-file and CONSOLE

        S_add2eval_collection( "EXP", $text );                     # print comment to LIFT collection for later use
        $step_counter_text = $empty_counter_text;
    }

    return 1;
}

################################################################

=head2 S_teststep_detected

S_teststep_detected ( <Comment_Text> , <eval_keyword> );

Prints Comment_Text of S_teststep_expected using Sw2rep() in color blue.

Comment_Text    : Text for the comment (you can use \n to have more than one line)

eval keyword    : Retrieves ID from S_teststep or S_teststep_2nd_level.

    S_teststep_2nd_level( "Measure air pressure in my front tyre" , 'AUTO_NBR' , 'my_pressure_measurement_front' );    --> "(1-1) Measure air pressure in my front tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_front as ID for S_teststep_expected or S_teststep_mismatch

    S_teststep_2nd_level( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' );    --> "(1-2) Measure air pressure in my rear tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_rear as ID for S_teststep_expected or S_teststep_mismatch

   S_teststep_detected( "Air pressure front tyre measured : $det_front_pressure_bar bar " , 'my_pressure_measurement_front' );                --> "(2-1 DETECTED) Air pressure front tyre measured : 1.25 bar"
                                                                                                                                            -->    (2-1) is derived from [S_teststep_2nd_level( "Measure air pressure in my front tyre" , 'AUTO_NBR' , 'my_pressure_measurement_front' ) ]
                                                                                                                                             --> increases internal sub Teststep Nbr.
                                                                                                                                               --> retrieves <eval_keyword> my_pressure_measurement_front as ID from S_teststep_2nd_level

    S_teststep_detected("Air pressure rear tyre measured : $det_rear_pressure_bar bar " , 'my_pressure_measurement_rear');                    --> "(2-2 DETECTED) Air pressure front tyre measured : 1.85 bar"
                                                                                                                                            -->    (1-2) is derived from [S_teststep_2nd_level( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' ) ]
                                                                                                                                             --> increases internal sub Teststep Nbr.
                                                                                                                                               --> retrieves <eval_keyword> my_pressure_measurement_rear as ID from S_teststep_2nd_level

######if RBT_Include_Stimuli_Comments is called befor it will also handle the comments out of the stimuli table.

=cut

######################################################
sub S_teststep_detected
######################################################
{
    my @args = @_;
    return
      unless S_checkFunctionArguments( 'S_teststep_detected ( $comment_Text [ , $_keyword ] )', @args );

    my $comment_Text = shift @args;
    my $eval_keyword = shift @args;

    my $step_counter_text  = "";
    my $empty_counter_text = "     ";
    my $html_teststep_bookmark;
    my $html_teststep_link;

    manage_counter();

    if ( defined $eval_keyword ) {
        $step_counter_text = get_keyword($eval_keyword) || return;
        $html_teststep_bookmark = "<a name=\"check__$eval_keyword\"></a>";
    }

    foreach my $step_comment ( split /\\n/, $comment_Text )    #for comments with more than one line
    {
        my $text = "(DETECTED) $step_comment";
        $text =~ s/DETECTED/$step_counter_text DETECTED/ if $step_counter_text =~ m/\w+/;
        if ($html_teststep_bookmark) {
            $html_teststep_link = "$html_teststep_bookmark <a href=\"#teststep__$eval_keyword\">$text</a>";
            S_w2log( 'teststep', "\n" . $html_teststep_link . "\n", 'blue' );    # HTML report only
        }
        else {
            S_w2log( 'teststep', "\n" . $text . "\n", 'blue' );                  # HTML report only
        }
        S_w2log( TEXT | CONSOLE, "\n" . $text . "\n" );                          # seperate print of text to TEXT log-file and CONSOLE

        S_add2eval_collection( "DET", $text );                                   # print comment to LIFT collection for later use
        $step_counter_text = $empty_counter_text;
    }

    return 1;

}

################################################################

=head2 S_teststep_mismatch

S_teststep_mismatch ( <Comment_Text> , <eval_keyword> );

Prints Comment_Text of S_teststep_expected using Sw2rep() in color blue.
Comment_Text    : Text for the comment (you can use \n to have more than one line)
eval keyword    : Retrieves ID from S_teststep or S_teststep_2nd_level.

    S_teststep_2nd_level( "Measure air pressure in my front tyre" , 'AUTO_NBR' , 'my_pressure_measurement_front' );    --> "(1-1) Measure air pressure in my front tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_front as ID for S_teststep_expected or S_teststep_mismatch

    S_teststep_2nd_level( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' );    --> "(1-2) Measure air pressure in my rear tyre"
                                                                                                                     --> increases internal sub Teststep Nbr.
                                                                                                                       --> stores <eval_keyword> my_pressure_measurement_rear as ID for S_teststep_expected or S_teststep_mismatch

       S_teststep_mismatch( "Air pressure front : expected ( 1.4 .. 1.6 bar )  <==> $det_front_pressure_bar bar (out of range)"  , 'my_pressure_measurement_front' );                --> "(2-1 MISMATCH) Air pressure front : expected ( 1.4 .. 1.6 bar )  <==> 1.25 bar (out of range)"
                                                                                                                                                                                -->    (2-1) is derived from [S_teststep_2nd_level( "Measure air pressure in my front tyre" , 'AUTO_NBR' , 'my_pressure_measurement_front' ) ]
                                                                                                                                                                                 --> increases internal sub Teststep Nbr.
                                                                                                                                                                                   --> retrieves <eval_keyword> my_pressure_measurement_front as ID from S_teststep_2nd_level

    S_teststep_mismatch( "Air pressure front : expected ( 1.4 .. 1.6 bar )� <==> $det_rear_pressure_bar bar (out of range)", 'my_pressure_measurement_rear');                    --> "(2-2 MISMATCH) Air pressure rear : expected ( 1.4 .. 1.6 bar )  <==> 1.8 bar (out of range)"
                                                                                                                                                                                -->    (1-2) is derived from [S_teststep_2nd_level( "Measure air pressure in my rear tyre" , 'AUTO_NBR' , 'my_pressure_measurement_rear' ) ]
                                                                                                                                                                                 --> increases internal sub Teststep Nbr.
                                                                                                                                                                                   --> retrieves <eval_keyword> my_pressure_measurement_rear as ID from S_teststep_2nd_level

######if RBT_Include_Stimuli_Comments is called befor it will also handle the comments out of the stimuli table.

=cut

######################################################
sub S_teststep_mismatch
######################################################
{
    my @args = @_;
    return
      unless S_checkFunctionArguments( 'S_teststep_mismatch ( $comment_Text [ , $_keyword ] )', @args );

    my $comment_Text = shift @args;
    my $eval_keyword = shift @args;

    manage_counter();

    my $step_counter_text;
    my $empty_counter_text = "     ";
    my $html_teststep_bookmark;
    my $html_teststep_link;

    if ( defined $eval_keyword ) {
        $step_counter_text = get_keyword($eval_keyword) || return;
        $html_teststep_bookmark = "<a name=\"mismatch__$eval_keyword\"></a>";    # bookmark is not used currently
    }

    foreach my $step_comment ( split /\\n/, $comment_Text )    # for comments with more than one line
    {
        my $text = "(MISMATCH) $step_comment";
        $text =~ s/MISMATCH/$step_counter_text MISMATCH/ if $step_counter_text =~ m/\w+/;
        if ($html_teststep_bookmark) {
            $html_teststep_link = "$html_teststep_bookmark <a href=\"#teststep__$eval_keyword\">$text</a>";
            S_w2log( 'teststep', "\n" . $html_teststep_link . "\n", 'blue' );    # HTML report only
        }
        else {
            S_w2log( 'teststep', "\n" . $text . "\n", 'blue' );                  # HTML report only
        }
        S_w2log( TEXT | CONSOLE, "\n" . $text . "\n" );                          # seperate print of text to TEXT log-file and CONSOLE
        S_add2eval_collection( "MISMATCH", $text );                              # print comment to LIFT collection for later use
        $step_counter_text = $empty_counter_text;
    }

    return 1;

}

################################################################

=head2 S_dump2pmFile

    1) S_dump2pmFile (    "StoragePath" => 'C:/TurboLIFT/ProjectX',
                         "VariableToDump" => $allEDRrecords_href,
                         "VariableName" => "Records",
                        "PackageName" => "EDR_Records_Crash_C10345");

    2) S_dump2pmFile (    "VariableToDump" => $allEDRrecords_href,
                         "VariableName" => "Records",
                         "PackageName" => "EDR_Records_Crash_C10345");

    3) S_dump2pmFile (    "VariableToDump" => $allEDRrecords_href );

    4) S_dump2pmFile (    "VariableToDump" => $allEDRrecords_href,
                         "VariableName" => "Records" );

    5) S_dump2pmFile (    "VariableToDump" => $allEDRrecords_href,
                         "PackageName" => "EDR_Records_Crash_C10345");


I<B<Description:>> Dumps arrays or hashes to a .pm file

                   Use case: dumped array / hash can be used again in later test
                              scripts by calling the .pm file with "require"

                   Mandatory Parameters:

                           VariableToDump = array or hash reference to the array / hash
                                            to be dumped for later use

                   Optional Parameters:

                           StoragePath = Path where .pm file will be stored.
                                         Default is report path.

                           VariableName = Name of the hash or array to be dumped.
                                          Give name without prefix "$"!
                                          Default is "MyDumpVariable"

                           PackageName = Name of the perl package that is created with pm file.
                                         File name will be accordingly ("PackageName.pm").
                                         Default is "MyDumpPackage"

I<B<Return:>>     1: dumping successful, file already there, offline run
                nothing: no variable to dump given, file can not be opened

I<B<Verdict:>> none

I<B<Error:>> File can not be opened

=cut

#-------------------------------------------------------------------------------
sub S_dump2pmFile {

    #-------------------------------------------------------------------------------
    my @args   = @_;
    my $params = {@args};

    unless ( defined $params->{VariableToDump} ) {
        S_w2log( 4, "S_dump2pmFile: No data to dump given. Nothing will be done." );
        return;
    }

    my $path = $params->{StoragePath};
    unless ( defined $path ) {
        S_w2log( 4, "S_dump2pmFile: No storage path defined - set to default: Report Path" );
        $path = $main::REPORT_PATH;
    }
    unless ( -d $path ) {
        S_w2log( 4, " S_dump2pmFile: create path '$path'\n" );
        mkdir($path);
    }

    my $variableName = $params->{VariableName};
    unless ( defined $variableName ) {
        S_w2log( 4, "S_dump2pmFile: No variable name defined - set to default: MyDumpVariable" );
        $variableName = "MyDumpVariable";
    }

    my $packageName = $params->{PackageName};
    unless ( defined $packageName ) {
        S_w2log( 4, "S_dump2pmFile: No package name defined - set to default: MyDumpPackage" );
        $packageName = "MyDumpPackage";
    }

    my $recordFileName = $path . "/" . $packageName . ".pm";

    if ( -f $recordFileName ) {
        S_w2log( 4, "S_dump2pmFile: Dump file already exists. Nothing will be done.\n", 1 );
        return 1;
    }

    S_w2log( 4, "\nS_dump2pmFile: Dumping data to file...\n\n" );

    my $oDUMP_FILE;
    unless ( open( $oDUMP_FILE, '>', $recordFileName ) ) {
        S_set_error( "S_dump2pmFile: COULD NOT OPEN '$recordFileName'\n", 1 );
        return;
    }

    print $oDUMP_FILE "package $packageName;\n\n";

    print $oDUMP_FILE "\$$variableName = ";    # prepare parameter name for response

    # using the sub DumpRef instead of Data::Dumper because Data::Dumper has a severe memory problem with large data structures
    DumpRef( $params->{VariableToDump}, $oDUMP_FILE, 0 );

    print $oDUMP_FILE ";\n1;";

    close($oDUMP_FILE);
    return 1;
}

=head2 S_get_LiftProcessMemory

    $memory_MB = S_get_LiftProcessMemory ();
    
Gets the currently allocated memory (working set) in megabytes for the process perl.exe that runs LIFT_exec_engine.pl by running a power shell command.
The memory value is printed into the text log file only.

Returns the currently allocated working set memory of TurboLIFT in megabytes.
Returns 0 if there is more than one instance of TurboLIFT detected.
Returns 0 if no instance of TurboLIFT is detected (which seems not to be possible).

=cut

sub S_get_LiftProcessMemory {

    # power shell command: gwmi win32_process -filter "CommandLine like '%LIFT_exec_engine.pl%'" | select WS
    # has to be encoded because of too many nested quotes
    # encoding is done in the power shell:
    #   $filter = "`"CommandLine like '%LIFT_exec_engine.pl%'`""
    #   $command = "gwmi win32_process -filter $filter | select WS"
    #   $bytes = [System.Text.Encoding]::Unicode.GetBytes($command)
    #   $encodedCommand = [Convert]::ToBase64String($bytes)
    #   echo $encodedCommand
    # output is:
    # ZwB3AG0AaQAgAHcAaQBuADMAMgBfAHAAcgBvAGMAZQBzAHMAIAAtAGYAaQBsAHQAZQByACAAIgBDAG8AbQBtAGEAbgBkAEwAaQBuAGUAIABsAGkAawBlACAAJwAlAEwASQBGAFQAXwBlAHgAZQBjAF8AZQBuAGcAaQBuAGUALgBwAGwAJQAnACIAIAB8ACAAcwBlAGwAZQBjAHQAIABXAFMA
    #
    my $command = "PowerShell -encodedCommand ZwB3AG0AaQAgAHcAaQBuADMAMgBfAHAAcgBvAGMAZQBzAHMAIAAtAGYAaQBsAHQAZQByACAAIgBDAG8AbQBtAGEAbgBkAEwAaQBuAGUAIABsAGkAawBlACAAJwAlAEwASQBGAFQAXwBlAHgAZQBjAF8AZQBuAGcAaQBuAGUALgBwAGwAJQAnACIAIAB8ACAAcwBlAGwAZQBjAHQAIABXAFMA";
    my $psReturn = qx/ $command /;    # call command in windows system and get return value
    my $memory_MB;

    # the output of the command looks like this (the number is the working set memory in bytes):
    #                                                                             WS
    #                                                                             --
    #                                                                      140189696

    if ( $psReturn =~ /(\d+)\s+(\d+)/ ) {    # check if there is more than one number in the output
        S_print2text( "S_get_LiftProcessMemory ERROR: 2 or more instances of TurboLIFT detected\n", 21 );
        $memory_MB = 0;
    }
    elsif ( $psReturn =~ /(\d+)/ ) {         #  only one instance of TurboLIFT
        my $tcNumber = S_get_TC_number();
        my ( $date, $time ) = S_formated_timestamp();
        $memory_MB = $1 / 1024 / 1024;
        my $memory_MB_int = int( $memory_MB + 0.5 );
        S_print2text("S_get_LiftProcessMemory: TurboLIFT uses $memory_MB MB of memory (working set);$date;$time;$tcNumber;$memory_MB_int\n");
    }
    else {                                   # in all other cases there is no number
        S_print2text( "S_get_LiftProcessMemory ERROR: no instance of TurboLIFT detected, but this seems impossible\n", 21 );
        $memory_MB = 0;
    }

    return $memory_MB;
}

=head2 S_add_file_to_snapshot

    $status = S_add_file_to_snapshot( $filePath );

This function adds the file mentioned as argument to the snapshot folder of the report generated.

B<Arguments:>

=over

=item $filePath 

Full path of the file which has to be copied to the snapshot folder.

=back

B<Return Value:>

=over

=item $status 

1 - Success

undef - error

=back

B<Examples:>

    $status = S_add_file_to_snapshot( "D:/temp/example.mdb" );
    
=cut

sub S_add_file_to_snapshot {

    #COMMENT-START
    #   One argument - $filePath - mandatory
    #COMMENT-END
    my @args = @_;
    S_checkFunctionArguments( 'S_add_file_to_snapshot($FileName)', @args )
      or return;

    my $filename = shift @args;

    S_w2log( 3, "Call to S_add_file_to_snapshot to add \"$filename\" to snapshot folder" );

    #IF passed file path doesn't exist
    #IF-YES-START
    #STEP set error
    #IF-YES-END
    unless ( -e $filename ) {
        S_set_error( "S_add_file_to_snapshot : Input file does not exist", 114 );
        return;
    }

    #IF-NO-START
    #STEP configure snapshot folder
    my $snapshot_directory = "$main::REPORT_PATH/_snapshot_";

    #STEP if snapshot directory does not exist, create one
    unless ( -e $snapshot_directory or mkdir $snapshot_directory ) {
        S_set_error("Unable to create $snapshot_directory\n");
        return;
    }

    #STEP call perl "copy" to copy file to snapshot folder
    my $fileBaseName   = basename($filename);
    my $targetFilePath = $snapshot_directory . "\/$fileBaseName";
    unlink $targetFilePath if -e $targetFilePath;
    my $status = copy( $filename, $targetFilePath );
    unless ($status) {
        S_set_error( "S_add_file_to_snapshot : Could not copy file $filename to $snapshot_directory", 1 );
        return;
    }

    #IF-NO-END
    #STEP return
    return 1;
}

=head2 S_setSystemSleepMode

    $success = S_setSystemSleepMode( [ "enabled"|"disabled" ] );

Sends a command to System Power settings to enable or disable the system sleep mode depending on the input argument.
Input argument must be either "enabled" or "disabled". If no argument is given, by default it is considered to be 'enabled'

Enabled : 
It sets the Sleep mode settings for monitor and standby timeout to the active power scheme's default values. 

Disabled :
It sets the Sleep Mode settings for monitor and standby timeout to 'Never'.

Check image for details taken from Control Panel : 

=for html
<IMG SRC='..\..\pics\SleepSettings.png'  alt="System Sleep Settings" border="0">
<br/><I><B><caption align = "centre">Sleep Settings</caption></B></I>
<br/>

Returns 1 on success (and in offline or simulation mode - doesn't make any modifications to sleep settings in these two modes), undef otherwise.

Note : The sleep settings can be changed manually by going to Control Panel->System and Security->Power Options->Change when the computer sleeps.

=cut

sub S_setSystemSleepMode {

    my @args = @_;
    return unless S_checkFunctionArguments( 'S_setSystemSleepMode ( [ $subcommand ] )', @args );

    my $subcommand = shift @args;
    $subcommand = 'enabled' if not defined $subcommand;

    #COMMENT-START
    # Interface:
    # $success = S_setSystemSleepMode ( 'enabled'|'disabled'  );
    #COMMENT-END

    #STEP Check argument validity
    if ( $subcommand !~ /^(enabled|disabled)$/i ) {
        S_set_error( "Unknown argument '$subcommand'. It must be either 'enabled' or 'disabled'.", 114 );
        return;
    }

    my $command = 'c:\windows\system32\powercfg.exe';
    unless ( -f $command ) {
        S_set_warning("Privilege of powercfg.exe not found in this version of Windows ( $command ) to disable the System Sleep Mode.");
        return;
    }

    S_w2log( 1, "Sending command to make the System Sleep Mode $subcommand...\n" );
    return 1 if ( $main::opt_offline or $main::opt_simulation );

    #STEP Build and Send command for enabling or disabling the System Sleep Mode
    if ( $subcommand =~ /disabled/i ) {
        $command .= ' -change -standby-timeout-dc 0';    #command to set DC standby time out value to 0
        S_w2log( 5, "Sending command ( To set when the the computer goes to sleep with DC Power supply to 'Never' ) '$command'\n" );
        system($command);
        $command =~ s/-dc 0//;
        $command .= '-ac 0';                             #command to set AC standby time out value to 0
        S_w2log( 5, "Sending command ( To set when the the computer goes to sleep with AC Power supply to 'Never' ) '$command'\n" );
        system($command);

        S_w2log( 1, "Sending command to disable Montior display turnoff...\n" );
        $command =~ s/-change -standby-timeout-ac 0//;
        $command .= '-change -monitor-timeout-dc 0';     #command to set DC monitor time out value to 0
        S_w2log( 5, "Sending command ( To set when the the monitor turns off its display with DC Power supply to 'Never' ) '$command'\n" );
        system($command);
        $command =~ s/-dc 0//;
        $command .= '-ac 0';                             #command to set AC monitor time out value to 0
        S_w2log( 5, "Sending command ( To set when the the monitor turns off its display with AC Power supply to 'Never' ) '$command'\n" );
        system($command);
        S_w2log( 1, "System Sleep Mode was disabled. \n" );
    }
    else {
        $command .= ' -restoredefaultschemes';           #command to restore power scheme's default values
        S_w2log( 5, "Sending command '$command'\n" );
        system($command);
        S_w2log( 1, "System Sleep Mode was enabled back to its default settings.\n" );
    }
    return 1;
}

=head2 S_SCCM_SetSoftwareDistribution

    $success = S_SCCM_SetSoftwareDistribution ( "enabled"|"disabled"|"reset" );

Sends a command to Bosch SCCM to disable or enable the automatic software distribution, depending on input argument.
Input argument must be either "enabled" or "disabled" or "reset".
If the input argument is "reset" then the state to be set is determined by the state that was present before the last call of this function
with argument "enabled" or "disabled".
Returns 1 on success (and in offline or simulation mode), undef otherwise.

=cut

sub S_SCCM_SetSoftwareDistribution {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_SCCM_SetSoftwareDistribution ( [ $subcommand ] )', @args );

    my $subcommand = shift @args // 'enabled';

    #STEP Check argument validity
    if ( $subcommand !~ /^(enabled|disabled|reset)$/i ) {
        S_set_error( "Unknown argument '$subcommand'. It must be either 'enabled' or 'disabled' or 'reset'.", 114 );
        return;
    }
    $subcommand = lc($subcommand);

    S_w2log( 1, "Sending command to set SCCM $subcommand ...\n" );

    return 1 if ( $main::opt_offline or $main::opt_simulation );

    my $command = '"c:\Program Files\BOSCH\CMST\ITWTCmd.exe" /sd';

    #STEP handle reset subcommand
    if ( $subcommand eq 'reset' ) {
        if ( $sccmLastState =~ /enabled/ ) {
            $subcommand = 'enabled';
        }
        elsif ( $sccmLastState =~ /disabled/ ) {
            $subcommand = 'disabled';
        }
        elsif ( $sccmLastState =~ /not allowed/ ) {
            S_set_warning("Disabling SCCM software distribution is not allowed on this computer. Doing nothing...\n");
            return;
        }
        else {
            S_set_warning("Command to set SCCM $subcommand was not successful because last state of SCCM is unknown.\n");
            return;
        }
    }
    else {
        my $checkCommand = $command . ' /i';
        $sccmLastState = qx{ $checkCommand };
        S_w2log( 1, "Current SCCM state: $sccmLastState\n" );
    }

    #STEP Build SCCM command
    if ( $subcommand eq 'enabled' ) {
        $command .= ' /e';
    }
    else {
        $command .= ' /d';
    }

    #STEP Send SCCM command
    my $returnString = qx{ $command };
    S_w2log( 5, "Sent command '$command'. Return string = '$returnString'\n" );

    #STEP Handle SCCM command return string
    if ( $returnString =~ /successfully/i ) {
        S_w2log( 1, "SCCM $subcommand was triggered successfully.\n" );
    }
    elsif ( $returnString =~ /already/i ) {
        S_w2log( 1, "SCCM is already $subcommand.\n" );
    }
    else {
        S_set_warning("Command to set SCCM $subcommand was not successful: $returnString\n");
        return;
    }

    return 1;
}

######## called from LIFT_exec_engine and from LIFT_general::manage_counter ##############################
sub S_teststep_reset_all {
######## local function ##############################

    my $tc_report_name_from_Engine = $main::TC_REPORT_NAME;

    S_w2log( 4, " S_teststep_reset_all: New Testcase detected -> Reset Teststep Handling \n", 'grey' );
    undef $STEP_COUNTER_HASH;
    $STEP_COUNTER_HASH->{Nbr_Teststep}          = 0;
    $STEP_COUNTER_HASH->{Nbr_2ndLevel_Teststep} = 0;
    $STEP_COUNTER_HASH->{TC_REPORT_NAME}        = $tc_report_name_from_Engine;
    $STEP_COUNTER_HASH->{EVAL_KEYWORDS}         = {};

    return 1;
}

######## local function ##############################
sub manage_counter {
######## local function ##############################

    my $tc_report_name_stored = $STEP_COUNTER_HASH->{TC_REPORT_NAME};

    my $tc_report_name_from_Engine = $main::TC_REPORT_NAME
      || return;    # must be set ; is running number from Engine

    return 1
      if ( $tc_report_name_stored eq $tc_report_name_from_Engine );    # same testcase is running

    S_w2log( 5, " manage_counter : New Testcase detected -> Reset Teststep Handling \n", 'grey' );
    S_teststep_reset_all();

    return 1;
}

######## local function ##############################
sub set_keyword {
######################################################
    my $eval_keyword      = shift;
    my $step_counter_text = shift;

    if ( defined $STEP_COUNTER_HASH->{EVAL_KEYWORDS}{$eval_keyword} ) {
        S_set_error("Teststep handling : eval keyword '$eval_keyword' is already defined -> can just be used once");
        return;
    }

    $step_counter_text = "" unless defined $step_counter_text;
    $STEP_COUNTER_HASH->{EVAL_KEYWORDS}{$eval_keyword} = $step_counter_text;

    return 1;
}

######## local function ##############################
sub get_keyword {
######################################################
    my $eval_keyword = shift;

    unless ( exists $STEP_COUNTER_HASH->{EVAL_KEYWORDS}{$eval_keyword} ) {
        S_set_error("Teststep handling : eval keyword '$eval_keyword' is not defined");
        return;
    }

    my $step_counter_text = $STEP_COUNTER_HASH->{EVAL_KEYWORDS}{$eval_keyword};

    return $step_counter_text;
}

=head2 S_check_LIFT_component_integrity

    $componentOK = S_check_LIFT_component_integrity( [$componentCheckConfig_href] );

Checks if a TurboLIFT component's integrity is OK, i.e. the checksums of all files of the component are as expected.
Expected checksums are stored in a checksum file (see Notes below). 

B<Arguments:>

=over

=item $componentCheckConfig_href 

    $componentCheckConfig_href = {
        component          => <Component name>, 
        action_on_mismatch => 'log'|'warning'|'error'|'fail',
    }

If the key component is not defined then all components will be checked.

If the key action_on_mismatch = 'warning' then the check result will be given as warning.
If the key action_on_mismatch = 'log' then the check result will be printed as log entry.
If the key action_on_mismatch = 'error' then the check result will be given as error (VERDICT_INCONC).
If the key action_on_mismatch = 'fail' then the check result will be printed as log entry and the test verdict will be set to VERDICT_FAIL.

If the key action_on_mismatch is not defined then it is set to 'warning' by default.

=back

B<Return Value:>

=over

=item $componentOK

$componentOK = 1 if all checks are OK, 0 otherwise.

=back

B<Examples:>

my $success = S_check_LIFT_component_integrity( {component => 'CREIS', action_on_mismatch => 'error'} );

B<Notes:>

The checksum file for a component may be located in any folder below "Engine" or "TCs".
The name of the checksum file must be 'LIFT_checksums.md5'.
The format of the the checksum file is as follows:

    # any line starting with # is treated as comment
    Component: <Component name>
    Version: <Component version number>
    Requires: <other Component> >= <other Component version number>
    
    <checksum1> *<path to file1>
    <checksum2> *<path to file2>

    <checksum of checksum file>

A checksum of an engine file defined in a component checksum file overwrites the corresponding checksum in the Engine checksum file.
With this mechanism a component (e.g. CREIS) can require newer (or older) Engine files than those of the latest Engine checkpoint.  

The keyword "Requires: ..." is optional. It may be used to ensure that a minimum version of another component is required 
for the usage of the current component, e.g. "Requires: TurboLIFT_Engine >= 1.59" checks additionally that the component
TurboLIFT_Engine has at least version 1.59 and it's integrity is OK.
For the keyword "Requires: ..." instead of ">=" also "==" can be used to enforce an exact version instead of a minimal version.

=cut

sub S_check_LIFT_component_integrity {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_check_LIFT_component_integrity([$componentCheckConfig_href])', @args );

    #STEP check arguments
    my $componentCheckConfig_href = shift @args;

    S_checkFunctionArgumentHashKeys( '$componentCheckConfig_href', $componentCheckConfig_href, { component => 1, action_on_mismatch => 1 }, {} );
    my $componentToCheck = $componentCheckConfig_href->{'component'};
    my $actionOnMismatch = $componentCheckConfig_href->{'action_on_mismatch'} // 'warning';
    S_checkSingleValue( '$componentCheckConfig_href->{action_on_mismatch}', $actionOnMismatch, { list_i => [ 'log', 'warning', 'error', 'fail' ] }, 'error' ) or return;

    my $component4print = $componentToCheck // 'all components';
    S_w2log( 1, "S_check_LIFT_component_integrity: Checking integrity of component '$component4print'...\n" );

    #STEP get checksum results from LIFT engine
    my $checksumResultsAll_href = main::Get_checksumResultsAll();

    #STEP add top level warnings to warning list
    my @allWarnings;
    @allWarnings = @{ $checksumResultsAll_href->{Warnings} } if ( $checksumResultsAll_href->{Warnings} );

    #IF component defined in arguments?
    if ( defined $componentToCheck ) {

        #IF-YES-START
        #STEP add a warning if defined component is not found
        if ( not defined $checksumResultsAll_href->{Components}{$componentToCheck} ) {
            push( @allWarnings, "S_check_LIFT_component_integrity: Given component '$componentToCheck' not found in TurboLIFT. Please make sure to have all required checksum files (LIFT_checksums.md5) in your sandbox." );
        }
        else {
            #STEP add warnings of component to warning list
            push( @allWarnings, @{ $checksumResultsAll_href->{Components}{$componentToCheck}{Warnings} } );

            #STEP add warnings of all dependent components to warning list
            foreach my $dependentComponent ( keys %{ $checksumResultsAll_href->{Components}{$componentToCheck}{Requires} } ) {
                push( @allWarnings, @{ $checksumResultsAll_href->{Components}{$dependentComponent}{Warnings} } );
            }

            #IF-YES-END
        }
    }
    else {
        #IF-NO-START
        #STEP add warnings of all components to warning list
        foreach my $component ( keys %{ $checksumResultsAll_href->{Components} } ) {
            my $componentWarnings_aref = $checksumResultsAll_href->{Components}{$component}{Warnings};
            push( @allWarnings, @$componentWarnings_aref ) if defined $componentWarnings_aref;
        }

        #IF-NO-END
    }

    #STEP return 1 if warning list is empty
    if ( @allWarnings == 0 ) {
        S_w2log( 1, "S_check_LIFT_component_integrity: Component '$component4print' is OK.\n" );
        return 1;
    }

    #LOOP-START loop over all etries of warning list
    foreach my $warningText (@allWarnings) {

        #STEP output entry depending on action_on_mismatch
        if ( lc($actionOnMismatch) eq 'log' ) {
            S_w2log( 1, $warningText );
        }
        elsif ( lc($actionOnMismatch) eq 'error' ) {
            S_set_error( $warningText, 108 );
        }
        elsif ( lc($actionOnMismatch) eq 'fail' ) {
            S_w2log( 1, $warningText );
            S_w2log( 1, "Therefore verdict will be set to 'VERDICT_FAIL'\n" );
            S_set_verdict(VERDICT_FAIL);
        }
        else {
            S_set_warning($warningText);
        }
    }

    #LOOP-END last entry?

    #STEP return 0
    return 0;
}

=head1 not exported functions


=head2 S_append_lines_to_file

    S_append_lines_to_file ( <FILE_NAME> , <LIST OF LINES> );

    Appends the LIST OF LINES to FILE_NAME.

=cut

sub S_append_lines_to_file {
    my $given_file  = shift;
    my @given_lines = @_;

    unless ( scalar @given_lines ) { S_set_error( " SYNTAX: S_append_lines_to_file( <FILE_NAME> , <LIST OF LINES> )", 110 ); return }
    unless ( -f $given_file )      { S_set_error( " file '$given_file' doesnt exist",                                 1 );   return }
    unless ( -w $given_file )      { S_set_error( " file '$given_file' has no write access for user",                 1 );   return }

    unless ( open( GIVEN_FILE, ">>$given_file" ) ) { S_set_error( "could not open $given_file: $!", 1 ); return }
    S_w2log( 3, " S_append_lines_to_file: Adding lines to file : $given_file\n" );
    foreach (@given_lines) {
        print GIVEN_FILE "$_\n";
    }
    unless ( close(GIVEN_FILE) ) { S_set_error( "could not close $given_file: $!", 1 ); return }

    return 1;
}

=head2 S_check_actual_error

    S_check_actual_error ( $ERROR );

checks if error is a system error
returns 0 if given error is critical and leads to state SYS_FAIL

=cut

sub S_check_actual_error {
    my $actual_error = shift;

    foreach my $sys_fail_error (@SYS_FAIL_ERRORS) {
        if ( $actual_error == $sys_fail_error ) {
            my $err_text = $ALL_ERR_CODES->{$actual_error};
            S_w2rep("!!--SYS_FAIL--!! => $err_text (Code:$actual_error) <= !!--SYS_FAIL--!!\n");
            return 0;
        }
    }
    return 1;    # error dont lead to SYS_FAIL state
}

=head2 S_print2console

    S_print2console ( $text , [$color] );

Writes $text to STDOUT.

If $color is given then the text in STDOUT is written in the corresponding color.
For STDOUT only green, red, yellow and cyan are supported as colors.

    S_print2console ("Text to Console \n");

On STDOUT it appears as
Text to Console

=cut

sub S_print2console {
    my $text  = shift;
    my $color = shift;

    return 1 if $main::opt_silent;

    if ( defined $color ) {
        print color 'green'  if ( $color eq 'green' );
        print color 'red'    if ( $color eq 'red' );
        print color 'yellow' if ( $color eq 'yellow' );
        print color 'cyan'   if ( $color eq 'cyan' );
    }

    print $text;
    print color 'reset';

    return 1;
}

=head2 S_print2report

    S_print2report ( $logLevel , $text , [$color, $referenceName] );

Writes $text to the html log file for the current test case (*.html).
If $color is given then in the html log file is written in the corresponding color.
For the html log file the time since start of the test case is added to $text.
For the html log file a log-level is added as class attribute, e.g. <div class="loglevel2">.
The html report can later be filtered for loglevels, e.g. show only entries with loglevel 3 or lower

If $referenceName is given then a HTML reference (like anchor/bookmark) will be added <A NAME = "$referenceName" >.
The link to this anchor/bookmark will be placed directly below the header of the html testcase report ("Quick Links"),
so that the user can click on it and jump to the boomark.

=cut

sub S_print2report {
    my $logLevel      = shift;
    my $text          = shift;
    my $color         = shift;
    my $referenceName = shift;

    $text =~ s/^\n+//;
    $text =~ s/\n/<BR>/g;

    my $levelText = "$logLevel";

    # prepare the text for html output and push it into the html output list
    if ($referenceName) {

        # add reference to html text and to list of htmlBookmarks
        $text = "<A NAME=\"$referenceName\">$text</A>";
        push( @htmlBookmarks, $referenceName );
    }

    if ($color) {
        $text = "<span style=\"color:$color\">$text</span>\n";
    }

    $TC_time = sprintf( "%.6f", tv_interval( $TC_starttime, [ gettimeofday() ] ) );

    $text = "<div class=\"$levelText\"><div class=\"TCtime\">$TC_time</div><div class=\"TCtext\">$text</div></div><div class=\"space-line\"></div>";

    push( @TC_HTML_TEXT, "$text\n" ) if $nologCounter <= 0;

    return 1;
}

=head2 S_print2text

    S_print2text ( $text );

Writes $text to the plain text log file (_main__result_log.txt).
For the plain text log file the current time and date is added to $text.

    S_print2text ("Text to log file \n");

In Log file It appears as
[Wed Jan 28 09:20:30 2015] Text to log file

=cut

sub S_print2text {

    my $text = shift;

    my ( $time_sec,    $time_usec )   = gettimeofday();
    my ( $date_string, $time_string ) = S_formated_timestamp($time_sec);
    my $tcNumber = S_get_TC_number() // '__';
    my $log_text = "[$date_string $time_string." . sprintf( "%06d", $time_usec ) . " $tcNumber] $text";
    print LOG $log_text;

    return 1;
}

=head2 S_get_version_and_path_of_registered_COM_dll

    $versionPath_href = S_get_version_and_path_of_registered_COM_dll( $comPROGID );

Gets from the Windows registry the version number and the path of the given COM dll ($comPROGID).

B<Arguments:>

=over

=item $comPROGID 

Program ID of the registered COM dll.

=back

B<Return Value:>

=over

=item $versionPath_href 

    $versionPath_href = {
        version  => <string>,     # version string of COM dll
        fullPath => <string>,     # full path of COM dll
        relativePath => <string>, # path of COM dll relative to folder "Engine"
    }

=back

B<Examples:>

    $versionPath_href = S_get_version_and_path_of_registered_COM_dll( 'Pd4Com.Pd4Com.1.0' );

=cut

sub S_get_version_and_path_of_registered_COM_dll {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_get_version_and_path_of_registered_COM_dll($comPROGID)', @args );

    my $comPROGID = shift @args;

    #STEP get CLSID for $comPROGID in registry
    my $clsidKey = new Win32::TieRegistry 'HKEY_CLASSES_ROOT/' . $comPROGID . '/CLSID', { Access => Win32::TieRegistry::KEY_READ() | 0x0200, Delimiter => '/' };    # use Access option like this to be able to access the Win32 part of the registry
    if ( not defined $clsidKey ) {
        S_wait_ms(1000);

        # sometimes finding the CLSID fails for unknown reasons, trying again
        S_w2log( 5, "For given program ID ($comPROGID) no CLSID found in Windows registry. Trying again...\n" );
        $clsidKey = new Win32::TieRegistry 'HKEY_CLASSES_ROOT/' . $comPROGID . '/CLSID', { Access => Win32::TieRegistry::KEY_READ() | 0x0200, Delimiter => '/' };    # use Access option like this to be able to access the Win32 part of the registry

        if ( not defined $clsidKey ) {
            S_set_warning("For given program ID ($comPROGID) no CLSID found in Windows registry.");
            return;
        }
    }
    my $clsidValue = $clsidKey->GetValue('');

    #STEP get InprocServer32 for CLSID in registry
    my $inprocServer32Key = new Win32::TieRegistry 'HKEY_CLASSES_ROOT/CLSID/' . $clsidValue . '/InprocServer32', { Access => Win32::TieRegistry::KEY_READ() | 0x0200, Delimiter => '/' };

    #STEP get dll path from CodeBase key in registry (for .NET dll) or from (Default) key (for non-.NET dll)
    my $dllPath = $inprocServer32Key->GetValue('CodeBase');    # for .NET dll
    $dllPath = $inprocServer32Key->GetValue('') if not defined $dllPath;    # for non-.NET dll
    $dllPath =~ s/file:\/\/\///;                                            # remove leading "file:///"
                                                                            #STEP get relative path (starting from "Engine")
    my $relativePath;
    if ( $dllPath =~ /.*[\/\\](modules[\/\\].+)$/ ) {                       # uses .* to match as much as possible in order to find the last occurance of "modules"
        $relativePath = $1;
    }

    #STEP get dll version as sub-key of InprocServer32 (for .NET dll) or as (Default) value of Version key (for non-.NET dll)
    my @dllVersions = $inprocServer32Key->SubKeyNames();                    # for .NET dll
    my $dllVersion  = $dllVersions[0];
    if ( not defined $dllVersion ) {                                        # for non-.NET dll
        my $versionKey = new Win32::TieRegistry 'HKEY_CLASSES_ROOT/CLSID/' . $clsidValue . '/Version', { Access => Win32::TieRegistry::KEY_READ() | 0x0200, Delimiter => '/' };
        $dllVersion = $versionKey->GetValue('');
    }

    #STEP build return hash and return
    $dllPath = File::Spec->canonpath($dllPath);                             # clean up path
    my $versionPath_href = {
        version      => $dllVersion,
        fullPath     => $dllPath,
        relativePath => $relativePath,
    };

    return $versionPath_href;
}

=head2 S_get_version_and_path_of_dll_on_file_system

    $versionPath_href = S_get_version_and_path_of_dll_on_file_system( $dllPath );

Gets from the file system the version and full path of the given dll file 
($dllPath, either relative to currently used Engine folder or absolute).

B<Arguments:>

=over

=item $dllPath 

Path to a dll on the file system. If the path is relative then it is taken relative to the currently used Engine folder.
If the path is absolute then it is taken like that. 

=back

B<Return Value:>

=over

=item $versionPath_href 

    $versionPath_href = {
        version  => <string>,     # version string of dll as determined from the dll file properties
        fullPath => <string>,     # full path of dll
    }

=back

B<Examples:>

    $versionPath_href = S_get_version_and_path_of_dll_on_file_system( 'modules/DLLs/ProdDiag/Win32/PDLayer.dll' );

=cut

sub S_get_version_and_path_of_dll_on_file_system {
    my @args = @_;
    return unless S_checkFunctionArguments( 'S_get_version_and_path_of_dll_on_file_system($dllPath)', @args );

    my $dllPath = shift @args;

    #STEP If $dllPath is relative then determine the absolute path
    my $absoluteEngineDllPath;
    if ( not File::Spec->file_name_is_absolute($dllPath) ) {
        my $enginePath = dirname( File::Spec->rel2abs($0) );

        # check for new SCM unit test folder
        if ( $enginePath =~ /\\perl_unit_test$/ ) {

            # get engine path from Unit_test_engine_path.pm
            require('Unit_test_engine_path.pm');
            $enginePath = $Unit_test_engine_path::enginePath;
            $enginePath = File::Spec->rel2abs($enginePath);
        }
        $absoluteEngineDllPath = $enginePath . '/' . $dllPath;
    }
    else {
        $absoluteEngineDllPath = $dllPath;
    }
    $absoluteEngineDllPath = File::Spec->canonpath($absoluteEngineDllPath);    # clean up path

    #STEP Create Win32::Exe object for the dll with the absolute path
    my $exe = eval { Win32::Exe->new($absoluteEngineDllPath); };

    #STEP Throw error and return if object is not defined
    if ( not defined $exe ) {
        S_set_error( "Given dll path ($dllPath) does not point to a dll or executable.", 109 );
        return;
    }

    #STEP Get ProductVersion from Win32::Exe object
    my $version_href     = $exe->get_version_info();
    my $engineDllVersion = $version_href->{ProductVersion};

    #STEP build return hash and return
    my $versionPath_href = {
        version  => $engineDllVersion,
        fullPath => $absoluteEngineDllPath,
    };

    return $versionPath_href;
}

=head2 S_add_paths2INC

    S_add_paths2INC( $perlPaths_aref, $dllPaths_aref );

Adds the paths given in $perlPaths_aref to the perl include path (@INC)
and the paths given in $dllPaths_aref to environment variable PATH.
This function is usually used in the BEGIN block of a module, see example.

B<Arguments:>

=over

=item $perlPaths_aref 

Paths relative to the module in which the function is called to be added to the perl include path (@INC).

=item $dllPaths_aref 

Paths relative to the module in which the function is called to be added to environment variable PATH.

=back

B<Return Value:>

Returns always 1

B<Examples:>

    BEGIN {
        use LIFT_general;
        S_add_paths2INC(['./Win32'], ['./Win32']);
    }

=cut

sub S_add_paths2INC {
    my $perlPaths_aref = shift;
    my $dllPaths_aref  = shift;

    my $module = ( caller(1) )[1];

    my $basePath = File::Spec->rel2abs( dirname($module) );

    foreach my $path (@$perlPaths_aref) {
        my $addpath = $basePath . '/' . $path;
        $addpath =~ s/\//\\/g;    # replace all slashes with backslahes
        unshift( @INC, $addpath );
    }

    foreach my $path (@$dllPaths_aref) {
        my $addpath = $basePath . '/' . $path;
        $addpath =~ s/\//\\/g;    # replace all slashes with backslahes
        $ENV{PATH} = $addpath . ";$ENV{PATH}";
    }

    return 1;
}

=head2 S_register_COM_dlls

    $success = S_register_COM_dlls();

Runs the batch script run_once/register_com_dlls.bat in order to register the COM dlls.
The script needs administrator privileges to run properly.

B<Return Value:>

=item $success 

1 on success or in offline mode, undef otherwise, in particular if the function is called without administrator privileges.

=back

=cut

sub S_register_COM_dlls {
    S_w2log( 1, "Registering COM dlls of current engine...\n" );

    #STEP error and return if batch script does not exist
    my $registerBatchScript = dirname($0) . '/run_once/register_com_dlls.bat';
    if ( not -e $registerBatchScript ) {
        S_set_error( "Batch script for registering of COM dlls not found: $registerBatchScript. Please make sure your Engine is up-to-date.", 109 );
        return;
    }

    #CALL S_call_command with batch script
    my ( $returnValue, @screenOutputLines ) = S_call_command($registerBatchScript);

    #STEP error and return if screen output of batch script has "error"
    if ( grep { /error/i } @screenOutputLines or not defined $returnValue ) {
        S_set_error( "Could not register COM dlls of current engine. Please re-run the test once with administrator privileges or run $registerBatchScript as administrator and then re-run the test normally.\nOutput of batch file:\n@screenOutputLines", 109 );
        return;
    }

    #END return 1
    S_w2log( 1, "COM dlls of current engine successfully registered.\n" );
    return 1;
}

######## local function ##############################
# taken from http://www.perlmonks.org/bare/?node_id=49619
# and modified with additional argument $filehandle
sub DumpRef {
    my $testref    = shift;
    my $filehandle = shift;
    my $levels     = shift;

    my $curlevel = 0;
    if ( ref($testref) eq 'HASH' ) {
        print $filehandle "{\n";
        $levels++;
        my $maxlevel = scalar( keys %$testref );
        $curlevel = 0;
        foreach my $key ( keys %$testref ) {
            $curlevel++;
            print $filehandle " " x $levels;
            print $filehandle "'$key'";
            print $filehandle " => ";
            my $val = $testref->{$key};
            if ( ref($val) ) {
                &DumpRef( $val, $filehandle, $levels );
            }
            else {
                $val =~ s#\\#\\\\#g;
                $val =~ s#'#\\'#g;
                print $filehandle "'$val'";
            }
            print $filehandle "," if $curlevel < $maxlevel;
            print $filehandle "\n";
        }
        print $filehandle " " x ( $levels - 1 ) . "}";
    }
    elsif ( ref($testref) eq 'ARRAY' ) {
        print $filehandle "[\n";
        $levels++;
        my $maxlevel = scalar(@$testref);
        foreach my $val (@$testref) {
            $curlevel++;
            print $filehandle " " x $levels;
            if ( ref($val) ) {
                &DumpRef( $val, $filehandle, $levels );
                print $filehandle " " x ( $levels - 1 );
            }
            else {
                $val =~ s#\\#\\\\#g;
                $val =~ s#'#\\'#g;
                print $filehandle "'$val'";
            }
            print $filehandle "," if $curlevel < $maxlevel;
            print $filehandle "\n";
        }
        print $filehandle " " x ( $levels - 1 ) . "]";
    }
    else {
        print $filehandle ref($testref);
        print $filehandle "\n";
    }
}

=head2 APIDocumentationTemplateFunction

    $returnValue = APIDocumentationTemplateFunction( $mandArg1, $mandArg2 [, $optArg1, $optArg2 ] );

Describe here what the function is doing. Be precise! Try to think from a user perspective, 
i.e. as if you don't know how the function is implemented. Use here already the argument names for explanation.

Describe here also if special config settings are required for the function (if useful include links to L</"SYNOPSIS">, etc.)
or how this function works together with other functions if applicable.

Insert an empty line to make a new line in the html documentation.

To explain complex content a picture might be useful. 

B<Arguments:>

=over

=item $mandArg1 

Describe the purpose and/or typical values of $mandArg1.

=item $mandArg2 

Describe the purpose and/or typical values of $mandArg2.

=item $optArg1 

(optional) Describe the purpose and/or typical values of $optArg1. Write the default value for optional arguments.

=item $optArg2 

(optional) Describe the purpose and/or typical values of $optArg2. Write the default value for optional arguments.

=back

B<Return Value:>

=over

=item $returnValue 

Describe the values of $returnValue if the function works normally, if there is an error and in offline mode.

=back

B<Examples:>

    $returnValue = APIDocumentationTemplateFunction( 1, 2 );
    $returnValue = APIDocumentationTemplateFunction( 1, 2 , 'a');
    $returnValue = APIDocumentationTemplateFunction( 9, 9, 'b', 'x' );

B<Notes:> 

optional: Any additional things to mention, like dependencies on other functions, additional references etc.

=cut

1;
