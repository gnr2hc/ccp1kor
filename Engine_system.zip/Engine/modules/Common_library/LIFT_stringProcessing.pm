#*****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_stringProcessing;

=head1 NAME

LIFT_stringProcessing 

Provides string processing functions

=head1 SYNOPSIS

  use LIFT_stringProcessing;

    $hex_string = STR_Aref2HexString ( $input_aref );
    $hex_string = STR_Bin2HexString ( $binNbrStr, [,$nbrOfHexDigits]);
    $listOfUnsignedIntegers_aref = STR_ListOfHexStrings2ListOfUnsignedIntegers ( $listOfHexStrings_aref );
    $listOfHexStrings_aref = STR_ListOfUnsignedIntegers2ListOfHexStrings ( $listOfUnsignedIntegers_aref );
    $listOfUnsignedIntegers_aref = STR_HexString2ListOfUnsignedIntegers( $hex_string );

=head1 DESCRIPTION

This is a library of string processing functions

=cut

use strict;
use warnings;
use LIFT_general;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;


@ISA    = qw(Exporter);
@EXPORT = qw(
  STR_Aref2HexString
  STR_Bin2HexString
  STR_ListOfHexStrings2ListOfUnsignedIntegers
  STR_ListOfUnsignedIntegers2ListOfHexStrings
  STR_HexString2ListOfUnsignedIntegers
  );    # export subs and constants

###----------------------------------------------------------------------------

=head2 STR_Aref2HexString

    $hex_string = STR_Aref2HexString ( $input_aref, [$options_href] );

converts array reference of integers to hexstring based on $options_href.

B<Arguments:>

=over

=item $input_aref

It is the reference to the array of integers

=item $options_href

$options_href->{Seperator_character}: sepertor character for output hexstring.
see examples.

=back

B<Return Values:>

=over

=item $hex_string 

Success : $hex_string

=back

B<Examples:>
     
     '01 FF' = STR_Aref2HexString ( [1,255] );
     '01 FF' = STR_Aref2HexString ( [1,255], {Seperator_character=> ' '} );
     '01FF' = STR_Aref2HexString ( [1,255], {Seperator_character=> ''} );
     '01,FF' = STR_Aref2HexString ( [1,255], {Seperator_character=> ','} );
     
B<Notes>

=cut

sub STR_Aref2HexString {
    my @args = @_;
    S_checkFunctionArguments( 'STR_Aref2HexString( $input_aref, [$options_href] )', @args ) or return;
    my $input_aref = shift @args;
    my $options_href = shift @args;
    my $seperator = $options_href->{Seperator_character} // ' ';

    #STEP convert to the hex string
    my @hexList = map { sprintf( "%02X", $_ ) } @$input_aref;

    #STEP join the string using the seperator.
    my $hexString = join( $seperator, @hexList );

    # STEP return the hexstring
    return $hexString;
}

=head2 STR_Bin2HexString

    $hex_string = STR_Bin2HexString ( $binNbrStr, [,$nbrOfHexDigits]);

Converts bin number string to hex digit string.

Converts to required number of hex string if $nbrOfHexDigits is configured. ( optional )

B<Arguments:>

=over

=item $binNbrStr

binary number string starting with '0b'

=item $nbrOfHexDigits ( optional )

number of hex digits required string.

=back

B<Return Values:>

=over

=item $hex_string 

Success : $hex_string

Failure:  undef

=back

B<Examples:>
     
     1. # converts binary 2 ('0010') to one digit hex ('0x2')
        '0x2' = STR_Bin2HexString ( '0b0010' );
     
     2. # converts binary 2 ('0010') to two digit hex ('0x02')
        '0x02' = STR_Bin2HexString ( '0b0010', 2 );

B<Notes>

=cut

sub STR_Bin2HexString {
    my @args = @_;

    S_checkFunctionArguments( 'STR_Bin2HexString( $binNbrStr, [, $nbrOfHexDigits] )', @args ) || return;

    my $binNbrStr      = shift @args;
    my $nbrOfHexDigits = shift @args;

    unless ( $binNbrStr =~ /^0b/ ) {
        S_set_error( "Bin2HexString: Binary number does not start with '0b'", 109 );
        return;
    }

    my $format;
    if ( defined $nbrOfHexDigits ) {
        $format = '%0' . $nbrOfHexDigits . 'X';
    }
    else {
        $format = '%X';
    }

    my $hexString = '0x' . sprintf( $format, oct $binNbrStr );

    return $hexString;
}

=head2 STR_ListOfHexStrings2ListOfUnsignedIntegers

    $listOfUnsignedIntegers_aref = STR_ListOfHexStrings2ListOfUnsignedIntegers( $listOfHexStrings_aref );

Converts array of hex strings to array of unsigned integers

B<Arguments:>

=over

=item $listOfHexStrings_aref

- Array of hex strings. All elements provided as part of list are treated as Hex

=back

B<Return Values:>

=over

=item $listOfUnsignedIntegers_aref 

- On success returns array of unsigned integers. Undef otherwise

=back

B<Examples:>

    [ 80, 106, 8, 20 ] = STR_ListOfHexStrings2ListOfUnsignedIntegers([ '0x50', '0x6A', '0x08', '0x14' ]);
    
    [ 80, 106, 8, 20 ] = STR_ListOfHexStrings2ListOfUnsignedIntegers([ 50, '6A', 8, 14 ]);

B<Notes>

=cut

sub STR_ListOfHexStrings2ListOfUnsignedIntegers {
    my @args = @_;
    S_checkFunctionArguments( 'STR_ListOfHexStrings2ListOfUnsignedIntegers( $listOfHexStrings_aref )', @args ) || return;
    my $listOfHexStrings_aref = shift();

    if ( grep { !/^(0X)?[0-9A-F]+$/i } @$listOfHexStrings_aref ) {
        S_set_error( "STR_ListOfHexStrings2ListOfUnsignedIntegers : Please provide only the Hexstrings as the elements of \$listOfHexStrings_aref", 110 );
        return;
    }

    my $listOfUnsignedIntegers_aref;
    foreach my $hexstring (@$listOfHexStrings_aref) {
        push( @$listOfUnsignedIntegers_aref, hex( lc($hexstring) ) );
    }

    return $listOfUnsignedIntegers_aref;
}

=head2 STR_ListOfUnsignedIntegers2ListOfHexStrings

    $listOfHexStrings_aref = STR_ListOfUnsignedIntegers2ListOfHexStrings( $listOfUnsignedIntegers_aref [, $options_href]);

Converts array of unsigned integers to array of hex strings

B<Arguments:>

=over

=item $listOfUnsignedIntegers_aref

- Array of integers

=item $options_href

$options_href = {
    prefix0x => 0|1,  # default = 1
}

-> if prefix0x = 1 then all hex strings will be prefixed with '0x'.
-> if prefix0x = 0 then all hex strings will have no prefix'.

=back

B<Return Values:>

=over

=item $listOfHexStrings_aref 

- On success returns array of hex strings. Undef otherwise

=back

B<Examples:>

    [ '0x50', '0xAD2B076', '0x08', '0xA11' ] = STR_ListOfUnsignedIntegers2ListOfHexStrings( [ 80,   181579894, 8,    2577 ]);
    
    [ '50', 'AD2B076', '08', 'A11' ] = STR_ListOfUnsignedIntegers2ListOfHexStrings( [ 80,   181579894, 8,    2577 ],{prefix0x => 0});

B<Notes>

=cut

sub STR_ListOfUnsignedIntegers2ListOfHexStrings {
    my @args = @_;
    S_checkFunctionArguments( 'STR_ListOfUnsignedIntegers2ListOfHexStrings( $listOfUnsignedIntegers_aref [, $options_href])', @args ) || return;
    my $listOfUnsignedIntegers_aref = shift;
    my $options_href                = shift;

    my $prefix0x = 1;
    if ( defined $options_href->{prefix0x} && $options_href->{prefix0x} !~ /^(0|1)$/ ) {
        S_set_error( "STR_ListOfUnsignedIntegers2ListOfHexStrings : Please provide either 0|1 as \$options_href->{prefix0x} value ", 110 );
        return;
    }
    $prefix0x = $options_href->{prefix0x} if defined( $options_href->{prefix0x} );

    if ( grep { !/^\d+$/ } @$listOfUnsignedIntegers_aref ) {
        S_set_error( "STR_ListOfUnsignedIntegers2ListOfHexStrings : Please provide only Unsigned integers as part of \$listOfUnsignedIntegers_aref", 110 );
        return;
    }
    my $listOfHexStrings_aref;
    foreach my $intValue (@$listOfUnsignedIntegers_aref) {
        my $hexValue = sprintf( "%02X", $intValue );
        $hexValue = '0x' . $hexValue if $prefix0x;
        push( @$listOfHexStrings_aref, $hexValue );
    }
    return $listOfHexStrings_aref;
}

=head2 STR_HexString2ListOfUnsignedIntegers

    $listOfUnsignedIntegers_aref = STR_HexString2ListOfUnsignedIntegers( $hex_string );

Converts hex string to array of unsigned integers.

B<Arguments:>

=over

=item $hex_string

- Hex string. Either seperated by w/ or w/o whitespace 

=back

B<Return Values:>

=over

=item $listOfUnsignedIntegers_aref 

- On success returns array of unsigned integers. Undef otherwise

=back

B<Examples:>

    [ 80, 106, 8, 20 ] = STR_HexString2ListOfUnsignedIntegers('506A0814');
    
    [ 80, 106, 8, 20 ] = STR_HexString2ListOfUnsignedIntegers('50 6A 08 14');

B<Notes>

=cut

sub STR_HexString2ListOfUnsignedIntegers{
    my @args = @_; 
    my $hex_string = shift @args;
    
	# STEP remove all white spaces if $hex_string is seperated by white space
	$hex_string =~ s/\s+//g; # remove the white space 
	
	# STEP check if its a vlaid hex string
    if ($hex_string =~/[^0-9a-f]/i) {
        S_set_error ("STR_HexString2ListOfUnsignedIntegers : Not a valid Hex string = '$hex_string'.\n", 110);
        return;
    }
    # STEP convert hex string to list of unsigned intergers
    my @array_uIntergers = map hex, $hex_string =~ /../g;
    
    # STEP return list of unsigned integers
    return \@array_uIntergers;
    
}

1;
