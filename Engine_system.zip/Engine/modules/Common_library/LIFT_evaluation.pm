package LIFT_evaluation;

=head1 NAME

LIFT_evaluation 

Provide LIFT useful functions for evaluation of traces (SPI trace, CAN_trace)

=head1 DATA STRUCTURE

The datastructure for most of the evaluation functions will look like below:

   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

It is a hash with

=over 4

=item * 'TIME' as KEYS

=item * Hash of SignalValue pairs as VALUES

=back

=head1 SYNOPSIS

    use LIFT_evaluation;

    EVAL_get_time_when

    EVAL_get_values_at_time
    EVAL_get_value_around_time
    EVAL_evaluate_value_around_time

    EVAL_get_values_over_time
    EVAL_evaluate_value_over_time

    EVAL_get_signal_availability
    EVAL_evaluate_signal_availability

    EVAL_evaluate_string
    EVAL_evaluate_value
    EVAL_evaluate_interval
    EVAL_evaluate_alive_counter
    EVAL_evaluate_values_in_trace
    EVAL_evaluate_values_at_time
    EVAL_evaluate_values_at_event
    EVAL_evaluate_values_at_position
    EVAL_evaluate_values_existence

    EVAL_calc_signal_frequence
    EVAL_get_signal_pulses
    EVAL_evaluate_signal_frequence

    EVAL_evaluate_digital_pattern_over_time

    EVAL_GetSignalTransitions

    EVAL_get_time_multi_condition

    EVAL_RescaleDataHashValues

    EVAL_getFlashCodes

    EVAL_importCSV
    EVAL_dataCalculationOverTime
    EVAL_createGraphFromMeasurement
    EVAL_evaluateAndPlotDataWithLimits
    
    EVAL_get_trace_eval_params
    EVAL_evaluate_trace_sequence
    EVAL_evaluate_trace_times
    EVAL_evaluate_trace_signals

=cut

use LIFT_general;
use Statistics::LineFit;
use List::Util qw(min max);
use strict;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;


@ISA    = qw(Exporter);
@EXPORT = qw(
  EVAL_calc_signal_frequence
  EVAL_check_fault_status
  EVAL_dump2file
  EVAL_dump2UNV
  EVAL_evaluate_counter
  EVAL_evaluate_alive_counter
  EVAL_evaluate_digital_pattern_over_time
  EVAL_evaluate_interval
  EVAL_evaluate_signal_availability
  EVAL_evaluate_signal_frequence
  EVAL_evaluate_string
  EVAL_evaluate_value
  EVAL_evaluate_value_around_time
  EVAL_evaluate_values_at_event
  EVAL_evaluate_values_existence
  EVAL_evaluate_value_over_time
  EVAL_evaluate_values_at_position
  EVAL_filter_MAV
  EVAL_getFlashCodes
  EVAL_get_last_signallist_time
  EVAL_get_occurence
  EVAL_get_signal_availability
  EVAL_get_signal_pulses
  EVAL_get_signal_cycletime
  EVAL_get_time_multi_condition
  EVAL_get_time_when
  EVAL_get_value_around_time
  EVAL_get_values_at_time
  EVAL_get_values_over_time
  EVAL_get_values_and_times_over_time
  EVAL_importUNV
  EVAL_merge_sync
  EVAL_GetSignalTransitions
  EVAL_evaluate_values_in_trace
  EVAL_evaluate_values_at_time
  EVAL_RescaleDataHashValues
  EVAL_importCSV
  EVAL_dataCalculationOverTime
  EVAL_createGraphFromMeasurement
  EVAL_evaluateAndPlotDataWithLimits
  EVAL_get_trace_eval_params
  EVAL_evaluate_trace_sequence
  EVAL_evaluate_trace_times
  EVAL_evaluate_trace_signals
  );    # export subs

=head2 EVAL_calc_signal_frequence

   $found_freq = EVAL_calc_signal_frequence (\%MEASURE_DATA, $SIGNAL_LABEL, $TIME_MIN, $TIME_MAX [, $threshold ] );

              _______         _______         _______         _______         _____     high
             |       |       |       |       |       |       |       |       |
      _______|       |_______|       |_______|       |_______|       |_______|          low
             1               2               3               4               5
        |                                                                         |
    time_min                                                                   time_max

    Function calculates the frequency of a blinking signal between time_min and time_max.
    The algorithm counts the rising flanks of the signal and divides the time by the amount of found flanks -1.
    Signal low is <= threshold, Signal high is > threshold, default threshold is 0
    at least 2 falling edges are required in trace

    Function returns 0 in offline mode or if no frequency calculation possible, it does not set any error for that !

    example:
    $SIG_DATA = {
                  0.01 =>  { 'SIG_1' => 0} ,
                  0.02 =>  {                 'SIG_2' => 32  } ,
                  0.03 =>  { 'SIG_1' => 1} ,
                  0.04 =>  {                 'SIG_2' => 16  } ,
                  0.05 =>  { 'SIG_1' => 0} ,
                  0.06 =>  {                 'SIG_2' => 32  } ,
                  0.07 =>  { 'SIG_1' => 1} ,
                  0.08 =>  {                 'SIG_2' => 16  } ,
                  0.09 =>  { 'SIG_1' => 0} ,
                  0.10 =>  {                 'SIG_2' => 32  } ,
                };

    25 = EVAL_calc_signal_frequence ($SIG_DATA, 'SIG_1', 0.01, 0.08);
    25 = EVAL_calc_signal_frequence ($SIG_DATA, 'SIG_2', 0.04, 0.10, 18);
     0 = EVAL_calc_signal_frequence ($SIG_DATA, 'SIG_1', 0.03, 0.07); # no freq because too less edges

=cut

sub EVAL_calc_signal_frequence
{
    my $signals_ref           = shift;
    my $label                 = shift;
    my $timestamp_start_given = shift;
    my $timestamp_end_given   = shift;
    my $threshold             = shift;

    my $timestamp_initial_set = 0,

      my ( $found_freq, $time_current, $timestamp_previous, $edge_counter, $time_diff, $time_per_period, $timestamp_start_real, $timestamp_stop_real, $signal, @timestamps_temp_list, );

    $threshold = 0 unless ( defined $threshold );
    unless ( defined $timestamp_end_given )
    {
        S_set_error( "too less parameters ,SYNTAX: EVAL_calc_signal_frequence (MEASURE_DATA, SIGNAL_LABEL, TIME_MIN, TIME_MAX);", 110 );
        return 0;
    }

    if ( $signals_ref == 1 )
    {
        S_w2log( 5, " EVAL_calc_signal_frequence: No Measurement enabled in ProjectDefaults->{'MEASUREMENT'}->{'use_measurement'}\n" );
        return 0;
    }

    if ( ref($signals_ref) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return 0;
    }

    return 0 if $main::opt_offline;

    # apply label mapping if defined for current label in project defaults
    if ( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{$label} )
    {
        $label = $main::ProjectDefaults->{'LABEL_MAPPING'}{$label};
    }

    $signal = $label;

    @timestamps_temp_list = grep( /\d/, sort { $a <=> $b } keys %$signals_ref );
    if   ( defined $timestamp_start_given ) { $timestamp_previous    = $timestamp_start_given }
    else                                    { $timestamp_start_given = shift @timestamps_temp_list; $timestamp_previous = $timestamp_start_given; }
	
	my $timestamp_end_given_copy = $timestamp_end_given;
	#Set the timestamp end to max timestamp if given timestamp end > max timestamp
    if ( defined $timestamp_end_given and $timestamp_end_given > $timestamps_temp_list[-1] )
    {
        $timestamp_end_given = pop @timestamps_temp_list;
    }
    
    #If end timestamp is not given, assign max timestamp
    unless (  defined $timestamp_end_given ){
    	$timestamp_end_given = pop @timestamps_temp_list;
    	$timestamp_end_given_copy = $timestamp_end_given;
    }

    if ( $timestamp_start_given >= $timestamp_end_given )
    {
        S_set_error( "TIME_MIN ($timestamp_start_given) >= TIME_MAX ($timestamp_end_given)", 109 );
        return 0;
    }

    foreach $time_current ( sort { $a <=> $b } keys %$signals_ref )
    {
        next if $time_current < $timestamp_start_given;
        last if $time_current > $timestamp_end_given;
        next unless defined $signals_ref->{$time_current}{$signal};

        if ( ( $signals_ref->{$time_current}{$signal} > $threshold ) && ( $signals_ref->{$timestamp_previous}{$signal} <= $threshold ) )
        {
            $edge_counter++;
            $timestamp_stop_real = $time_current;
            if ( $timestamp_initial_set == 0 ) { $timestamp_start_real = $time_current; $timestamp_initial_set = 1 }
        }
        $timestamp_previous = $time_current;
    }    # end foreach

    if ( $edge_counter == 0 )
    {
        S_w2log( 2, " EVAL_calc_signal_frequence : no 'edges' detected \n" );
        return 0;
    }

    if ( $edge_counter < 2 )
    {
        S_w2log( 2, " EVAL_calc_signal_frequence : Too less periods selected to get proper frequency \n" );
        return 0;
    }

    unless ( defined $timestamp_start_real and defined $timestamp_stop_real )
    {
        S_w2log( 2, " EVAL_calc_signal_frequence : No valid calculation possible \n" );
        return 0;
    }

    $time_diff = $timestamp_stop_real - $timestamp_start_real;
    S_w2log( 5, " EVAL_calc_signal_frequence : $time_diff (time_diff) = $timestamp_stop_real - $timestamp_start_real \n" );

    $time_per_period = $time_diff / ($edge_counter - 1);
    S_w2log( 5, " EVAL_calc_signal_frequence : $time_per_period (time_per_period) = $time_diff / $edge_counter; \n" );

    $found_freq = 1.0 / $time_per_period;
    S_w2log( 5, " EVAL_calc_signal_frequence : $found_freq (found_freq) = 1.0 / $time_per_period \n" );

    S_w2log( 4, " EVAL_calc_signal_frequence : real measurement start: $timestamp_start_real (given : $timestamp_start_given ) end: $timestamp_stop_real (given : $timestamp_end_given_copy) \n" );
    S_w2log( 2, " EVAL_calc_signal_frequence : $signal = $found_freq Hz ( $edge_counter edges between $timestamp_start_real .. $timestamp_stop_real)\n" );
    return $found_freq;

}

=head2 EVAL_check_fault_status

    EVAL_check_fault_status( $flt_mem_struct, $fault_name, $expected_states, [$key_name] );

I<Mandatory Input Arguments>

flt_mem_struct - Fault memory structure

fault_name - Fault name to which state has to check

expected_state - The expected value of the state

I<Optional Input Arguments>

key_name - state/GeneralState/DisturbanceState/fltmun/QualificationTime/Dequalification_poweron_cycle
           DequalificationTime/OccuranceCounter/DisturbanceCounter/EventDebug/Qualification_poweron_cycle

$expected_states in dec, hex or as bitmask

sets PASS if the status byte for $fault_name matches $expected_states, else FAIL.

sets ERROR if $fault_name not found

calls internally

PD_check_fault_status($flt_mem_struct,$fault_name,$expected_state, $key_name);

    example:
    $flt_mem_struct = {
       info' => [],
          'EventDebug' => [
                            '0x00', 
                          ],
          'fault_text' => [
                            'rb_spi_SpiRcvMsgCrcWrong_flt',
                          ],
          'GeneralState_text' => [
                                   '',
                                 ],
          'Qualification_poweron_cycle' => [
                                             '9',
                                            ],
          'OccuranceCounter' => [
                                  '255',
                                ],
          'DisturbanceCounter' => [],
          'state' => [
                       '0x00',
                      ],
          'QualificationTime' => [
                                   '162111',
                                  ],
          'info_txt' => [],
          'GeneralState' => [
                              '0x0',
                             ],
          'DisturbanceState_text' => [],
          'Dequalification_poweron_cycle' => [
                                               '9',
                                               ],
          'DTC' => [
                     'F00049',
                     ],
          'DisturbanceState' => [],
          'fltnum' => [
                        '313',
                       ],
          'state_txt' => [
                           'Test_not_Failed',
                           'Test_not_Failed'
                         ],
          'DequalificationTime' => [
                                     '175313',
                                   ],
    };

    EVAL_check_fault_status( $flt_mem_struct, 'FltEOLNotProgrammed', '0x22' ); #passed
    EVAL_check_fault_status( $flt_mem_struct, 'FltEOLNotProgrammed', '0x11' ); #failed
    EVAL_check_fault_status( $flt_mem_struct, 'FltEOLNotProgrammed', '0x2c',' GeneralState'); #failed
    EVAL_check_fault_status( $flt_mem_struct, 'FltEOLNotProgrammed', '0x3', 'DisturbanceState'); #failed

Error return : 0

offline/success return :: 1

=cut

sub EVAL_check_fault_status
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'EVAL_check_fault_status( $flt_mem_struct_href , $fault_name , $expected_states [, $key_name ] )' , @args );
    LIFT_PD::PD_check_fault_status(@args);
    return 1;
}

=head2 EVAL_dump2file

    EVAL_dump2file( \%MEASURE_DATA [, $file_name] );

dumps MEASURE_DATA to file (time signal_1=value_1 ... signal_n=value_n \n).
if no filename is given save in report folder as file data_dump_{timestamp}.txt

    e.g. would create from data

    $MEASURE_DATA = {
                  0.1 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  0.2 => {                             'SIG_3' => 32  } ,
                  0.3 => { 'SIG_1' => 1  , 'SIG_2' => 0 } ,
                  0.4 => {                             'SIG_3' => 34  } ,
                  1.5 => { 'SIG_1' => 2  , 'SIG_2' => 1 } ,
                  1.6 => {                             'SIG_3' => 36  } ,
                  1.7 => { 'SIG_1' => 3  , 'SIG_2' => 0 } ,
                };

    the following file:

    0.1 SIG_1=0 SIG_2=0
    0.2 SIG_3=32
    0.3 SIG_1=1 SIG_2=0
    0.4 SIG_3=34
    1.5 SIG_1=2 SIG_2=1
    1.6 SIG_3=36
    1.7 SIG_1=3 SIG_2=0


=cut

sub EVAL_dump2file
{
    my $data     = shift;
    my $filename = shift;
    my ( $line, $time, $signal );

    $filename = $main::REPORT_PATH . "/data_dump_" . time() . ".txt" unless defined $filename;

    unless ( defined $data )
    {
        S_set_error( "too less parameters ,SYNTAX: EVAL_dump2file ( \%MEASURE_DATA [, \$file_name ] );", 110 );
        return 0;
    }

    if ( ref($data) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return 0;
    }

    S_w2rep("EVAL_dump2file: dump data to $filename\n");

    if ( open( FILE, ">$filename" ) )
    {
        foreach $time ( sort { $a <=> $b } keys %{$data} )
        {
            $line = "$time";
            foreach $signal ( sort keys %{ $data->{$time} } )
            {
                $line .= " $signal=" . $data->{$time}->{$signal};
            }
            print FILE"$line\n";
        }
        close(FILE);
    }
    else
    {
        S_set_error( "could not write $filename\n", 1 );
        return 0;
    }
}

=head2 EVAL_dump2UNV

    EVAL_dump2UNV( \%MEASURE_DATA [, $file_name] );

dumps MEASURE_DATA to UNIVIEW file (time signal_1=value_1 ... signal_n=value_n \n).
Missing signals at timestamp are added with last value, if no last value defined with 0.
If no filename is given save in report folder as file dump_{timestamp}.txt.unv
all values will be transformed to dec values.

    e.g. would create from data

    $MEASURE_DATA = {
                  0.1 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  0.2 => {                             'SIG_3' => 32  } ,
                  0.3 => { 'SIG_1' => 1  , 'SIG_2' => 0 } ,
                  0.4 => {                             'SIG_3' => 34  } ,
                  1.5 => { 'SIG_1' => 2  , 'SIG_2' => 1 } ,
                  1.6 => {                             'SIG_3' => 36  } ,
                  1.7 => { 'SIG_1' => 3  , 'SIG_2' => 0 } ,
                };

    the following file:

    TIME;SIG_1;SIG_2;SIG_3;
    s;-;-;-;
    0.1;0;0;0;
    0.2;0;0;32;
    0.3;1;0;32;
    0.4;1;0;34;
    1.5;2;1;34;
    1.6;2;1;36;
    1.7;3;0;36;

=cut

sub EVAL_dump2UNV
{
    my $data     = shift;
    my $filename = shift;
    my ( $line, $time, $signal, $val );
    my %lastval = ();

    $filename = $main::REPORT_PATH . "/dump_" . time() . ".txt.unv" unless defined $filename;

    unless ( defined $data )
    {
        S_set_error( "too less parameters ,SYNTAX: EVAL_dump2UNV ( \%MEASURE_DATA [, \$file_name ] );", 110 );
        return 0;
    }

    if ( ref($data) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return 0;
    }

    S_w2rep("EVAL_dump2UNV: dump UNIVIEW data to $filename\n");

    #extract all signal names
    foreach $time ( keys %{$data} )
    {
        foreach $signal ( keys %{ $data->{$time} } )
        {
            $lastval{$signal} = 0;
        }
    }
    my @sorted_sig = sort keys %lastval;

    if ( open( FILE, ">$filename" ) )
    {
        print FILE "TIME;" . join( ';', @sorted_sig ) . ";\n";
        print FILE "s;" . join( ';', ('-') x scalar(@sorted_sig) ) . ";\n";

        foreach $time ( sort { $a <=> $b } keys %{$data} )
        {
            $line = ( $time / 1000 ) . ";";
            foreach $signal (@sorted_sig)
            {

                #if signal exists at time, take current value
                if ( defined $data->{$time}->{$signal} )
                {
                    $val = S_0x2dec( $data->{$time}->{$signal} );
                    $lastval{$signal} = $val;
                }

                #else take previous value
                else
                {
                    $val = $lastval{$signal};
                }
                $line .= $val . ";";
            }
            print FILE"$line\n";
        }

        close(FILE);
    }
    else
    {
        S_set_error( "could not write $filename\n", 1 );
        return 0;
    }

}

=head2 EVAL_evaluate_counter

    $VERDICT = EVAL_evaluate_counter ( \%MEASURE_DATA , $SIGNAL_LABEL , $STEP_WIDTH , $START_VALUE , $END_VALUE , $DELTATIME_MIN , $DELTATIME_MAX [, $TIME_MIN [, $TIME_MAX ]]);

Evaluates if a given signal ($SIGNAL_LABEL) in a measurement (\%MEASURE_DATA) is a counter, 
i.e. the signal values are incremented by a given step width ($STEP_WIDTH, which can also be negative) 
and in total the signal values never exceed a given minimum ($START_VALUE) or a given maximum ($END_VALUE). 
The time in which the increment shall happen is given by a minimum and maximum delta time ($DELTATIME_MIN, $DELTATIME_MAX).

According to the evaluation the test case verdict is set!

   \%MEASURE_DATA : Signal reference , see example below
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA
   $STEP_WIDTH    : e.g. 1 for ascending , -1 for descending
   $START_VALUE   : e.g. 0 or 1 or 14 or 15 ?
   $END_VALUE     : e.g. 14 or 15 or 0 or 1 ?
   $DELTATIME_MIN : Minimum Time difference for Change of value (in milliseconds)
                    -1 , incase it is not to be considered
   $DELTATIME_MIN : Maximum Time difference for Change of value (in milliseconds)
                    -1 , incase it is not to be considered
   $TIME_MIN      : start time in MEASURE_DATA
   $TIME_MAX      : stop time in MEASURE_DATA

   for example,
   my  $RAMP_DATA = {                                                   25|
                     0.00 =>  { 'SIG_1' => 14} ,                          |                                            ___
                     0.50 =>  { 'SIG_1' => 14} ,                        24|                                           |
                     1.00 =>  { 'SIG_1' => 15} ,                          |                                        ___|
                     1.50 =>  { 'SIG_1' => 15} ,                        23|                                       |
                     2.00 =>  { 'SIG_1' => 16} ,                          |                                    ___|
                     2.50 =>  { 'SIG_1' => 16} ,                        22|                                   |
                     3.00 =>  { 'SIG_1' => 17} ,                          | V                              ___|
                     3.50 =>  { 'SIG_1' => 17} ,                        21| A                             |
                     4.00 =>  { 'SIG_1' => 18} ,                          | L                          ___|
                     4.50 =>  { 'SIG_1' => 18} ,                        20| U                         |
                     5.00 =>  { 'SIG_1' => 19} ,                          | E                      ___|
                     5.50 =>  { 'SIG_1' => 19} ,                        19|                       |
                     6.00 =>  { 'SIG_1' => 20} ,                          |                    ___|
                     6.50 =>  { 'SIG_1' => 20} ,                        18|                   |
                     7.00 =>  { 'SIG_1' => 21} ,                          |                ___|
                     7.50 =>  { 'SIG_1' => 21} ,                        17|               |
                     8.00 =>  { 'SIG_1' => 22} ,                          |            ___|
                     8.50 =>  { 'SIG_1' => 22} ,                        16|           |
                     9.00 =>  { 'SIG_1' => 23} ,                          |        ___|
                     9.50 =>  { 'SIG_1' => 23} ,                        15|       |
                    10.00 =>  { 'SIG_1' => 24} ,                          |    ___|
                };                                                      14|   |
                                                                          |___|___|___|___|___|___|___|___|___|___|___|___|___|
                                                                              0   1   2   3   4   5   6   7   8   9  10  11  12
                                                                                                TIME



    VERDICT_PASS = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 14 , 24, -1, -1 );
    VERDICT_PASS = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 15 , 24, -1, -1 , 1);
    VERDICT_PASS = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 14 , 24, -1, -1 , 0 , 10);
    VERDICT_PASS = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 14 , 24,  1, -1 , 0 , 10);
    VERDICT_PASS = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 14 , 24, -1,  1 , 0.5 , 10);
    VERDICT_PASS = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 14 , 24,  0,  1 , 0 , 10);

    VERDICT_FAIL = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 2 , 14 , 24, -1, -1 ); #STEP_VALUE violation
    VERDICT_FAIL = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 15 , 24,1.5, -1 , 0.5 , 10); #DELTATIME_MIN violation
    VERDICT_FAIL = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 15 , 24, -1, 0.5, 0.5 , 10); #DELTATIME_MAX violation
    VERDICT_FAIL = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 14 , 24, -1, -1 , 1 , 10); #START_VALUE violation
    VERDICT_FAIL = EVAL_evaluate_counter ( $RAMP_DATA , 'SIG_1' , 1 , 14 , 24, -1, -1 , 0 ,  9); #END_VALUE violation


=cut

sub EVAL_evaluate_counter
{

    my ( $MEASURE_DATA, $SIGNAL_LABEL, $STEP_WIDTH, $START_VALUE, $END_VALUE, $DELTATIME_MIN, $DELTATIME_MAX, $TIME_MIN, $TIME_MAX ) = @_;

    my ( $time_stamp, $expected_value, $current_value_dec, $previous_value_dec, $first_time, $last_time, $last_ramp_time, $count, $fail_count, $time_difference, $temp_time_stamp );

    $last_time = 'n.a.';

    #check for Parameter definitions
    unless ( defined $DELTATIME_MAX )
    {
        S_set_error( "too less parameters ,SYNTAX: VERDICT = EVAL_evaluate_counter ( \%MEASURE_DATA , \$SIGNAL_LABEL , \$STEP_WIDTH , \$START_VALUE , \$END_VALUE , \$DELTATIME_MIN , \$DELTATIME_MAX [, \$TIME_MIN [, \$TIME_MAX ]]);", 110 );
        return VERDICT_INCONC;
    }

    #check for MEASURE_DATA - It is a "Hash" or not
    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return VERDICT_INCONC;
    }

    #check for $DELTATIME_MIN, $DELTATIME_MAX values
    if ( ( $DELTATIME_MIN < 0 && $DELTATIME_MIN != -1 ) || ( $DELTATIME_MAX < 0 && $DELTATIME_MAX != -1 ) )
    {
        S_set_error( "Incorrect DELTATIME_MIN($DELTATIME_MIN) or DELTATIME_MAX($DELTATIME_MAX) is passed", 109 );
        return VERDICT_INCONC;
    }

    #check for $TIME_MAX definition
    if ( ( defined $TIME_MAX ) && ( $TIME_MIN >= $TIME_MAX ) )
    {
        S_set_error( "TIME_MIN ($TIME_MIN) >= TIME_MAX ($TIME_MAX)", 109 );
        return VERDICT_INCONC;
    }

    #Round the Floating values for comparing
    $TIME_MAX = sprintf( "%10.6f", $TIME_MAX ) if defined($TIME_MAX);
    $TIME_MIN = sprintf( "%10.6f", $TIME_MIN ) if defined($TIME_MIN);
    $DELTATIME_MIN = sprintf( "%10.6f", $DELTATIME_MIN );
    $DELTATIME_MAX = sprintf( "%10.6f", $DELTATIME_MAX );

    #if offline mode, return VERDICT_NONE
    return VERDICT_NONE if $main::opt_offline;

    $count = $fail_count = 0;
    foreach $time_stamp ( sort { $a <=> $b } keys %$MEASURE_DATA )
    {
        next unless defined $MEASURE_DATA->{$time_stamp}{$SIGNAL_LABEL};

        $temp_time_stamp = $time_stamp;
        $time_stamp = sprintf( "%10.6f", $time_stamp );

        #skip till $TIME_MIN , after $TIME_MAX
        next if ( ( defined $TIME_MIN ) && ( $time_stamp < $TIME_MIN ) );
        last if ( ( defined $TIME_MAX ) && ( $time_stamp > $TIME_MAX ) );

        $current_value_dec = $MEASURE_DATA->{$temp_time_stamp}{$SIGNAL_LABEL};
        $count++;

        unless ( defined $previous_value_dec )
        {
            #check the START_VALUE, write the error info to log
            if ( $current_value_dec != $START_VALUE )
            {
                $fail_count++;
                S_w2log( 1, " ----> ERROR - COUNTER MISSMATCH for $SIGNAL_LABEL (Reason : START_VALUE) <---\n" );
                S_w2log( 1, " TIME: $time_stamp COUNTER: $current_value_dec (EXPECTED START VALUE : $START_VALUE)\n" );
            }
            else
            {
                S_w2log( 5, " EVAL_evaluate_counter : Found 1st counter $SIGNAL_LABEL at time $time_stamp\n" );
            }

            #assign the values first time
            $first_time         = $time_stamp;
            $last_ramp_time     = $time_stamp;
            $last_time          = $time_stamp;
            $previous_value_dec = $current_value_dec;
            next;
        }

        #calculate the next "Expected" value
        $expected_value = $previous_value_dec + $STEP_WIDTH;

        #if the value does not equal to Expected value and Previous value
        unless ( $expected_value == $current_value_dec || $current_value_dec == $previous_value_dec )
        {
            $fail_count++;
            S_w2log( 1, " ----> ERROR - COUNTER MISSMATCH for $SIGNAL_LABEL (Reason : STEP_WIDTH) <---\n" );
            S_w2log( 1, " TIME: $time_stamp COUNTER: $current_value_dec (previous COUNTER : $previous_value_dec previous TIME : $last_ramp_time ) \n" );
            $last_ramp_time = $time_stamp;

            last if ( $previous_value_dec == $END_VALUE );
        }

        #Determine whether DELTATIME conditions are satisfied, skip if DELTA_TIMES are -1
        if ( $expected_value == $current_value_dec )
        {
            if ( $previous_value_dec == $END_VALUE )
            {
                $last_time = $time_stamp;
                last;
            }

            #if both $DELTATIME_MAX = -1 && $DELTATIME_MIN = -1, then skip checking
            unless ( $DELTATIME_MAX == -1 && $DELTATIME_MIN == -1 )
            {
                $time_difference = $time_stamp - $last_ramp_time;
                $time_difference = sprintf( "%10.6f", $time_difference );

                #check for the below conditions
                #DELTAMAX = -1 and $time_difference < DELTAMIN
                #DELTAMIN = -1 and $time_difference > DELTAMAX
                #DELTAMIN != -1 , DELTAMAX != -1 and ($time_difference < DELTAMIN or $time_difference > DELTAMAX )
                if ( ( $DELTATIME_MAX == -1 && $time_difference < $DELTATIME_MIN ) || ( $DELTATIME_MIN == -1 && $time_difference > $DELTATIME_MAX ) || ( $DELTATIME_MAX != -1 && $DELTATIME_MIN != -1 && ( ( $time_difference < $DELTATIME_MIN ) || ( $time_difference > $DELTATIME_MAX ) ) ) )
                {
                    $fail_count++;
                    S_w2log( 1, " ----> ERROR - COUNTER MISSMATCH for $SIGNAL_LABEL (Reason : DELTATIME) <---\n" );
                    S_w2log( 1, " TIME: $time_stamp COUNTER: $current_value_dec (previous COUNTER : $previous_value_dec previous TIME : $last_ramp_time ) \n" );
                }
            }
            $last_ramp_time = $time_stamp;
        }

        $previous_value_dec = $current_value_dec;
        $last_time          = $time_stamp;
    }

    #check whether the checking is finished with END_VALUE
    unless ( $current_value_dec == $END_VALUE )
    {
        $fail_count++;
        S_w2log( 1, " ----> ERROR - COUNTER MISSMATCH for $SIGNAL_LABEL (Reason : END_VALUE) <---\n" );
        S_w2log( 1, " TIME: $time_stamp COUNTER: $current_value_dec (EXPECTED END VALUE : $END_VALUE)\n" );
    }

    my $verdict = VERDICT_FAIL;
    #Is there any conditions failed?
    if ($fail_count)
    {
        S_w2log( 1, " EVAL_evaluate_counter : $SIGNAL_LABEL failed for $fail_count of $count signals  ( STEP_WIDTH = $STEP_WIDTH START_VALUE = $START_VALUE END_VALUE = $END_VALUE first time = $first_time , last time = $last_time ) \n" );
        S_set_verdict($verdict);
        return $verdict;
    }

    #Atleast one signal occurance found?
    unless ($count)
    {
        S_w2log( 1, " EVAL_evaluate_counter : $SIGNAL_LABEL failed because no message in trace found \n" );
        S_set_verdict($verdict);
        return $verdict;
    }

    S_w2log( 1, " EVAL_evaluate_counter : $SIGNAL_LABEL successfully checked for $count signals  ( STEP_WIDTH = $STEP_WIDTH START_VALUE = $START_VALUE END_VALUE = $END_VALUE first time = $first_time , last time = $last_time ) \n" );
    $verdict = VERDICT_PASS;
    S_set_verdict($verdict);
    return $verdict;
}

=head2 EVAL_evaluate_alive_counter

    $VERDICT = EVAL_evaluate_alive_counter ( $measure_data_href , $signal_label , $step_width , $start_value , $end_value[, $time_min , $time_max ] );

Evaluates if a given signal ($signal_label) in a measurement ($measure_data_href) is an alive counter, 
i.e. from one time stamp to the next one the signal values are always incremented by a given step width ($step_width) 
and in total the signal values never exceed a given minimum ($start_value) or a given maximum ($end_value).

According to the evaluation the test case verdict is set!

B<Arguments:>

=over

=item $measure_data_href

Complete hash structure of data to be evaluated. This could be a CAN data or a Fast diagnosis Trace. Refer to parameters with example below.

    $measure_data_href = {
                      0.01 =>  { 'SIG_1' => 0} ,
                      0.02 =>  { 'SIG_1' => 1} ,
                      0.03 =>  { 'SIG_1' => 2} ,
                      0.04 =>  { 'SIG_1' => 3} ,
                      0.05 =>  { 'SIG_1' => 4} ,
                      0.06 =>  { 'SIG_1' => 5} ,
                      0.07 =>  { 'SIG_1' => 6} ,
                      0.08 =>  { 'SIG_1' => 0} ,
                      0.09 =>  { 'SIG_1' => 1} ,
                      0.10 =>  { 'SIG_1' => 2} ,
                    };

=item $signal_label

Signal label whose values are to be evaluated.

=item $step_width

uniform step width of signal value data . e.g. 1 for ascending , -1 for descending

=item $start_value

start value of signal data value e.g. 0 or 6 

=item $end_value

End value of the signal in complete data set.  e.g.  6 or 0 

=item $time_min

(optional) minimum value of time from which counter needs to be evaluated. e.g. 0.03 

=item $time_max

(optional) Maximum value of time upto which counter needs to be evaluated. e.g. 0.08

=back

B<Return Value:>

=over

=item $VERDICT 

Returns verdict of Evaluation

=back

B<Examples AB12:>

    VERDICT_PASS = EVAL_evaluate_alive_counter ( $measure_data_href , 'SIG_1' , 1 , 0 , 6 );
    VERDICT_PASS = EVAL_evaluate_alive_counter ( $CAN_DATA , 'SIG_1' , 1 , 0 , 6 , 0.03, 0.09 ); # check for acending counter with specific timestamp
    VERDICT_INCONC = EVAL_evaluate_alive_counter ( $CAN_DATA , 'SIG_1' , 1 , 0 , 6 , 0.09, 0.07 ); # wrong values for Time min and time max
    VERDICT_INCONC = EVAL_evaluate_alive_counter ( $CAN_DATA , 'SIG_1' , 1 , 0 ); # Mandatory parameters not defined.
    VERDICT_PASS = EVAL_evaluate_alive_counter ( $CAN_DATA_decending , 'SIG_1' , -1 , 6 , 0 , 0.03,0.09 ); # check for decending counter with specific timestamp 
    VERDICT_FAIL = EVAL_evaluate_alive_counter ( $measure_data_href , 'SIG_1' , 2 , 0 , 6 ); #step violation
    VERDICT_FAIL = EVAL_evaluate_alive_counter ( $measure_data_href , 'SIG_1' , 2 , 1 , 6 ); #min violation
    VERDICT_FAIL = EVAL_evaluate_alive_counter ( $measure_data_href , 'SIG_1' , 2 , 0 , 5 ); #max violation

=cut

sub EVAL_evaluate_alive_counter
{
    #COMMENT-START
    #   Get the function arguments - measure_data_href , signal_label, step_width , start_value and max_value - mandatory paramaeters
    #COMMENT-END

    # STEP Check the function arguments for data type and correctness of mandatory variables
    # STEP check exit condition for TIME_MIN and TIME_MAX
    # STEP sort the hash with respect to time stamps for comparison.
    # STEP Compare and check the correctness of counter data
    # STEP Set verdict based on the failed counter flags and appropriate error message

    my @args = @_;
    return VERDICT_INCONC unless S_checkFunctionArguments( 'EVAL_evaluate_alive_counter( $measure_data_href , $signal_label , $step_width ,$start_value, $end_value[, $time_min , $time_max ])', @args );

    my ( $measure_data_href, $signal_label, $step_width, $start_value, $end_value, $time_min, $time_max ) = @args;

    my ( $expected_counter, $alive_counter_dec, $alive_counter_dec_prev, $first_time, $last_time, $count, $fail_cnt, );

    $last_time = 'n.a.';

    $count    = 0;
    $fail_cnt = 0;

    #check for $time_max definition
    if ( ( defined $time_min ) && ( defined $time_max ) && ( $time_min >= $time_max ) ) {
        S_set_error( "TIME_MIN ($time_min) >= TIME_MAX ($time_max)", 109 );
        return VERDICT_INCONC;
    }
    foreach my $time_stamp ( sort { $a <=> $b } keys %$measure_data_href ) {
        next unless defined $measure_data_href->{$time_stamp}{$signal_label};

        #skip till $time_min , after $time_max
        next if ( ( defined $time_min ) && ( $time_stamp < $time_min ) );
        last if ( ( defined $time_max ) && ( $time_stamp > $time_max ) );
        $count++;

        $alive_counter_dec = $measure_data_href->{$time_stamp}{$signal_label};

        unless ( defined $alive_counter_dec_prev ) {
            $first_time             = $time_stamp;
            $alive_counter_dec_prev = $alive_counter_dec;
            S_w2log( 5, " EVAL_evaluate_alive_counter : Found 1st counter $signal_label at time $time_stamp\n" );
            next;
        }

        ### normal case
        $expected_counter = $alive_counter_dec_prev + $step_width;

        ### special case
        $expected_counter = $start_value
          if $alive_counter_dec_prev == $end_value;

        ## check for error
        unless ( $alive_counter_dec == $expected_counter ) {
            $fail_cnt++;
            S_w2log( 1, " ----> ERROR - COUNTER MISSMATCH for $signal_label <---\n" );
            S_w2log( 1, " TIME: $time_stamp COUNTER: $alive_counter_dec (previous COUNTER : $alive_counter_dec_prev previous TIME : $last_time ) \n" );
        }

        ## save counter for next check
        $alive_counter_dec_prev = $alive_counter_dec;

        $last_time = $time_stamp;

    }

    my $verdict = VERDICT_FAIL;
    if ($fail_cnt) {
        S_w2log( 1, " EVAL_evaluate_alive_counter : $signal_label failed for $fail_cnt of $count signals  ( STEP_WIDTH = $step_width START_VALUE = $start_value END_VALUE = $end_value first time = $first_time , last time = $last_time ) \n" );
        S_set_verdict($verdict);
        return $verdict;
    }

    unless ($count) {
        S_w2log( 1, " EVAL_evaluate_alive_counter : $signal_label failed because no message in trace found \n" );
        S_set_verdict($verdict);
        return $verdict;
    }

    S_w2log( 1, " EVAL_evaluate_alive_counter : $signal_label successful checked for $count signals  ( STEP_WIDTH = $step_width START_VALUE = $start_value END_VALUE = $end_value first time = $first_time , last time = $last_time ) \n" );
    $verdict = VERDICT_PASS;
    S_set_verdict($verdict);
    return $verdict;
}

=head2 EVAL_evaluate_digital_pattern_over_time

    ($compressed_pattern_text, $measure_values_text, $verdict) = EVAL_evaluate_digital_pattern_over_time ( \%MEASURE_DATA , $SIGNAL_LABEL , $SIGNAL_PATTERN [, $TIME_MIN [, $TIME_MAX ]] );

Evaluates the $SIGNAL_LABEL in \%MEASURE_DATA based on the $SIGNAL_PATTERN

According to the evaluation the test case verdict is set!

B<Arguments:>

=over

=item \%MEASURE_DATA

-> Signal reference , see example:

   $MEASURE_DATA = {
                  1 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  2 => {                             'SIG_3' => 'VAL_2_3'  } ,
                  3 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  4 => {                             'SIG_3' => 'VAL_4_3'  } ,
                  5 => { 'SIG_1' => 0  , 'SIG_2' => 1 } ,
                  6 => {                             'SIG_3' => 'VAL_6_3'  } ,
                  7 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                };

=item $SIGNAL_LABEL

-> Signal to be checked in MEASURE_DATA

=item $SIGNAL_PATTERN: 

-> digital pattern to be checked, one string with delimiter ':'

   patterns can be written either in decimal or binary notation
       e.g. "0:1:0" or "1"
             or "0b00000000:0b00000010:0b00000011"

   in binary notation a bit mask can be defined using 'x' for every bit that shall be masked out
       e.g. "0bxxxxxx00:0bxxxxxx10:0bxxxxxx11"
       note "0:0:0:1:1:0:" will be tranformed to "0:1:0"
            "0:0:0" will be tranformed to "0"

=item $TIME_MIN (optional)

-> start time in MEASURE_DATA

=item $TIME_MAX (optional)

-> stop time in MEASURE_DATA

=back

B<Return Value:>

=over

=item $compressed_pattern_text

-> Compressed form of given pattern.

   ex: If the given pattern is : 0:0:1:0:0:1:0, compressed pattern is => 0 -> 1 -> 0 -> 1 -> 0

=item $measure_values_text

-> Measured signal pattern from \%MEASURE_DATA

=item $verdict

-> Final verdict of evaluation

=back

B<Examples:>

   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_1' , "0:1:0" )    -> '0 -> 1 -> 0' , 0, VERDICT_FAIL
   
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_1' , "0:0:1:0" )  -> (just "0:1:0" will be checked) Returns '0 -> 1 -> 0', 0, VERDICT_FAIL
   
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_1' , "0" )        -> 0, 0, VERDICT_PASS
   
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_1' , "0:0:0" )    -> (just "0" will be checked) Returns 0, 0, VERDICT_PASS

   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0:1:0" )    -> '0 -> 1 -> 0','0 -> 1 -> 0', VERDICT_PASS
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0:0:1:0" )  -> (just "0:1:0" will be checked) Returns  '0 -> 1 -> 0', '0 -> 1 -> 0', VERDICT_PASS
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0:1" )      ->  '0 -> 1', '0 -> 1 -> 0', VERDICT_FAIL
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0" )        ->  0, '0 -> 1 -> 0', VERDICT_FAIL

   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0b00000000:0b00000001:0b00000000" )    -> '0 -> 1 -> 0', '0 -> 1 -> 0', VERDICT_PASS
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0bxxxxxxx0:0bxxxxxxx1:0bxxxxxxx0" )    -> '0 -> 1 -> 0', '0 -> 1 -> 0', VERDICT_PASS

   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0:1" , 1 , 6 )  -> '0 -> 1', '0 -> 1', VERDICT_PASS
   EVAL_evaluate_digital_pattern_over_time( $MEASURE_DATA , 'SIG_2' , "0" , 1 , 3 )    -> 0, 0, VERDICT_PASS

B<Note :> 

calls EVAL_get_values_over_time internally

=cut

sub EVAL_evaluate_digital_pattern_over_time
{

    my ( $MEASURE_DATA, $SIGNAL_LABEL, $SIGNAL_PATTERN, $TIME_MIN, $TIME_MAX, ) = @_;

    my (
         @signal_pattern_splitted, @trace_values, @compressed_signal_pattern, $compressed_pattern_text, $current_pattern_value, $last_pattern_value,          @compressed_measure_values, $measure_values_text, $current_measure_value,
         $last_measure_value,      $state,        $first_pattern_value,       $regexpattern,            $mask,                  $ANY_begin_first_match_value, $ANY_end_last_match_value,  @temp_compressed_measure_values,
    );

    unless ( defined($SIGNAL_PATTERN) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_digital_pattern_over_time ( \%MEASURE_DATA , \$SIGNAL_LABEL , \$SIGNAL_PATTERN [, \$TIME_MIN [, \$TIME_MAX ]] ) )", 110 );
        return ( undef, undef, VERDICT_INCONC );
    }
    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return ( undef, undef, VERDICT_INCONC );
    }

    if ( $SIGNAL_PATTERN =~ /any:any/i ) { S_set_error( "pattern contains with 2 times 'ANY' ", 109 ); return ( undef, undef, VERDICT_INCONC ); }
    if ( $SIGNAL_PATTERN =~ /^any$/i ) { S_set_error( "pattern contains only 'ANY' -> no valid check possible ", 109 ); return ( undef, undef, VERDICT_INCONC ); }

    if ( ( defined $TIME_MAX ) && ( $TIME_MIN >= $TIME_MAX ) )
    {
        S_set_error( "TIME_MIN ($TIME_MIN) >= TIME_MAX ($TIME_MAX)", 109 );
        return ( undef, undef, VERDICT_INCONC );
    }

    return ( undef, undef, VERDICT_NONE ) if $main::opt_offline;

    @signal_pattern_splitted = split( /:/, $SIGNAL_PATTERN );

    # create mask and regular expression for later use for binary patterns (e.g 0bxxxxxx10)
    $first_pattern_value = $signal_pattern_splitted[0];
    if (
        $first_pattern_value =~ / ^           # match from beginning
                                  \s*         # any number of whitespace
                                  0b          # 0b
                                  ([01xX]+)   # at least one of 0,1,x or X
                                    /x
      )
    {
        $regexpattern = $1;
        $mask         = $1;

        # create a regular expression pattern to check if all pattern values have the same distribution of x's
        # e.g. for 0bxxxxxx10 the regular expression pattern will be xxxxxx[01][01]
        $regexpattern =~ s/[01]/[01]/g;    # replace all 0 or 1 with [01]
                                           # create a mask that is ANDed with each of the values
                                           # e.g. for 0bxxxxxx10 the mask will be 0b00000011 = 3
        $mask =~ s/[01]/1/g;               # replace all 0 or 1 with 1
        $mask =~ s/[xX]/0/g;               # replace all x or X with 0
        $mask = eval( '0b' . $mask );      # mark it as binary (0b) and get the integer value
    }

    S_w2log( 4, "EVAL_evaluate_digital_pattern_over_time: check '$SIGNAL_LABEL' for pattern '@signal_pattern_splitted' \n" );

    foreach $current_pattern_value (@signal_pattern_splitted)
    {
        if ( defined($mask) )
        {
            # for binary patterns check if all patterns have the same distribution of x's
            unless ( $current_pattern_value =~ /$regexpattern/ )
            {
                S_set_error( "Mask in bit pattern $current_pattern_value does not match the mask in the first bit pattern $first_pattern_value", 109 );
                return ( undef, undef, VERDICT_INCONC );
            }

            # for binary patterns replace the x's with 0's and get the integer value
            $current_pattern_value =~ s/[xX]/0/g;
            $current_pattern_value = eval($current_pattern_value);
        }

        # remove pattern values if they are the same as the previous one
        next
          if $current_pattern_value == $last_pattern_value
          and $current_pattern_value !~ /any/i
          and defined $last_pattern_value;
        push( @compressed_signal_pattern, $current_pattern_value );
        $last_pattern_value = $current_pattern_value;
    }

    $compressed_pattern_text = join( " -> ", @compressed_signal_pattern );

    @trace_values = EVAL_get_values_over_time( $MEASURE_DATA, $SIGNAL_LABEL, $TIME_MIN, $TIME_MAX );

    foreach $current_measure_value (@trace_values)
    {
        if ( defined($mask) )
        {
            # for binary patterns apply the mask to each value
            $current_measure_value &= $mask;
        }

        # remove measure values (after the mask was applied) if they are the same as the previous one
        next if defined $last_measure_value and $last_measure_value == $current_measure_value;
        push( @compressed_measure_values, $current_measure_value );
        $last_measure_value = $current_measure_value;
    }

    # in case that pattern starts with ANY
    if ( $compressed_signal_pattern[0] =~ /any/i )
    {
        #uc $compressed_signal_pattern[0]; # was a warning
        $ANY_begin_first_match_value = $compressed_signal_pattern[1];
        if ( $compressed_measure_values[0] == $ANY_begin_first_match_value )
        {
            S_w2log( 2, " EVAL_evaluate_digital_pattern_over_time: measured value starts directly with first expected value after 'ANY' \n" );
            unshift( @compressed_measure_values, "ANY" );
        }
        else
        {
            @temp_compressed_measure_values = @compressed_measure_values;
            for (@temp_compressed_measure_values)
            {
                if ( $_ == $ANY_begin_first_match_value )
                {
                    # if first matching value found put 'ANY' at begin of the list with measured values
                    unshift( @compressed_measure_values, "ANY" );
                    last;
                }
                else
                {
                    # delete value for value from beginning of orig list while not the first matched value
                    shift @compressed_measure_values;
                    next;
                }
            }
        }
    }

    # in case that pattern ends with ANY
    if ( $compressed_signal_pattern[$#compressed_signal_pattern] =~ /any/i )
    {
        #uc $compressed_signal_pattern[ $#compressed_signal_pattern ]; # was a warning
        $ANY_end_last_match_value = $compressed_signal_pattern[ $#compressed_signal_pattern - 1 ];

        if ( $compressed_measure_values[$#compressed_measure_values] == $ANY_end_last_match_value )
        {
            S_w2log( 2, " EVAL_evaluate_digital_pattern_over_time: measured value ends directly with expected value before 'ANY' \n" );
            push( @compressed_measure_values, "ANY" );
        }
        else
        {
            @temp_compressed_measure_values = reverse @compressed_measure_values;
            for (@temp_compressed_measure_values)
            {
                if ( $_ == $ANY_end_last_match_value )
                {
                    # if first matching value found put 'ANY' at end of the list with measured values
                    push( @compressed_measure_values, "ANY" );
                    last;
                }
                else
                {
                    # delete value for value from end of orig list while not the first matched value
                    pop @compressed_measure_values;
                    next;
                }
            }
        }
    }

    $measure_values_text = join( " -> ", @compressed_measure_values );
    
    my $verdict = 'VERDICT_PASS';

    for ( $state = 1 ; ; $state++ )
    {
        if ( compare_two_values( $compressed_signal_pattern[ $state - 1 ], "==", $compressed_measure_values[ $state - 1 ] ) )
        {
            S_w2log( 1, " $SIGNAL_LABEL in pattern '$compressed_pattern_text' : (expected) " . $compressed_signal_pattern[ $state - 1 ] . " == " . $compressed_measure_values[ $state - 1 ] . " (detected) ( state $state PASSED )\n" );
        }
        else
        {
            S_w2log( 1, " $SIGNAL_LABEL in pattern '$compressed_pattern_text' : (expected) " . $compressed_signal_pattern[ $state - 1 ] . " != " . $compressed_measure_values[ $state - 1 ] . " (detected) ( state $state FAILED )\n" );
            $verdict = 'VERDICT_FAIL';
        }

        next if defined $compressed_signal_pattern[$state] and defined $compressed_measure_values[$state];

        if ( not defined $compressed_signal_pattern[$state] and not defined $compressed_measure_values[$state] )
        {
            S_w2log( 4, "EVAL_evaluate_digital_pattern_over_time: all states verified \n" );
        }
        else
        {
            S_w2log( 2, "EVAL_evaluate_digital_pattern_over_time: mismatch in number of expected states \n" );
            $verdict = 'VERDICT_FAIL';
        }

        EVAL_evaluate_string( "$SIGNAL_LABEL digital pattern", $compressed_pattern_text, $measure_values_text, );
        S_w2log( 1, "\n" );
        S_w2log( 1, "\n" );
        last;
    }

    return ( $compressed_pattern_text, $measure_values_text, $verdict );
}

=head2 EVAL_evaluate_interval

    $VERDICT = EVAL_evaluate_interval ( $signal_to_check , $lower_limit , $upper_limit , $detected_value  );

Evaluates if $lower_limit <= $detected_value <= $upper_limit.
$signal_to_check is the label of the signal to check (only for documentation reasons).

According to the evaluation the test case verdict is set!

B<Return Value:>

=over

=item $VERDICT 

Returns verdict of Evaluation

=back

B<Example:>

    VERDICT_PASS = EVAL_evaluate_interval ( "MyNormalSig1" , 2.5 , 3.5 , 3.21 );

=cut

sub EVAL_evaluate_interval
{

    my ( $signal_to_check, $lower_limit, $upper_limit, $detected_value, ) = @_;

    unless ( defined $detected_value )
    {
        S_set_error( " SYNTAX : EVAL_evaluate_interval ( \$signal_to_check , \$lower_limit , \$upper_limit , \$detected_value  );", 110 );
        return VERDICT_INCONC;
    }

    #   return VERDICT_NONE if $main::opt_offline;

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $signal_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};
    my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};

    S_add2eval_collection( 'OTHER_VALUES', "$signal_marker $signal_to_check" );

    ### ----------------------------------------------------------------------------------------

    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker interval $lower_limit <= X <= $upper_limit" );
    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker X = $detected_value" );

    if ( compare_two_values( $detected_value, '<', $lower_limit ) )
    {
        S_w2rep(" Signal '$signal_to_check' : (detected) '$detected_value' is smaller than $lower_limit (lower_limit) \n");
        S_add2eval_collection( 'MISMATCH', "Signal '$signal_to_check' : (detected) '$detected_value' is smaller than $lower_limit (lower_limit)" );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    if ( compare_two_values( $detected_value, '>', $upper_limit ) )
    {
        S_w2rep(" Signal '$signal_to_check' : (detected) '$detected_value' is bigger than $upper_limit (upper_limit) \n");
        S_add2eval_collection( 'MISMATCH', "Signal '$signal_to_check' : (detected) '$detected_value' is bigger than $upper_limit (upper_limit)" );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }

    S_w2rep(" Signal '$signal_to_check' : interval $lower_limit <= $detected_value <= $upper_limit fullfilled \n");
    S_set_verdict(VERDICT_PASS);
    return VERDICT_PASS;

}

=head2 EVAL_evaluate_signal_availability

    $VERDICT = EVAL_evaluate_signal_availability ( $MEASURE_DATA_HREF , $SIGNAL_LABEL , $AVAILABILITY [, $TIME_LOG_START [, $TIME_LOG_END ]] );

Evaluates in the measurement hash tree $MEASURE_DATA_HREF if the given signal is available or not 
and compares the result with the expected availability.
$TIME_LOG_START and $TIME_LOG_END determine the time range for the data. 
If neither of them is given then the time range is the full time range of the data hash.

According to the evaluation the test case verdict is set!

   $MEASURE_DATA_HREF : Signal reference
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA_HREF
   $AVAILABILITY  : 'present' or 'absent'
   $TIME_LOG_START: start time in MEASURE_DATA_HREF
   $TIME_LOG_END  : stop time in MEASURE_DATA_HREF

   example for
   $MEASURE_DATA_HREF = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };


=cut

sub EVAL_evaluate_signal_availability
{

    my $MEASURE_DATA_HREF = shift;
    my $SIGNAL_LABEL      = shift;
    my $AVAILABILITY      = shift;
    my $TIME_LOG_START    = shift;
    my $TIME_LOG_END      = shift;

    my ($signal_availability);

    S_w2log( 1, "EVAL_evaluate_signal_availability \n" );

    unless ( defined($AVAILABILITY) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_signal_availability ( MEASURE_DATA_HREF , SIGNAL_LABEL, AVAILABILITY [, TIME_LOG_START [, TIME_LOG_END ]] )", 110 );
        return VERDICT_INCONC;
    }

    unless ( ( $AVAILABILITY =~ /^present$/i ) || ( $AVAILABILITY =~ /absent/i ) )
    {
        S_set_error( "wrong parameter : AVAILABILITY ( 'absent'|'present' )", 109 );
        return VERDICT_INCONC;
    }

    if ( defined $MEASURE_DATA_HREF && ref($MEASURE_DATA_HREF) ne "HASH" )
    {
        S_set_error( " MEASURE_DATA_HREF is not an Hash reference", 114 );
        return VERDICT_INCONC;
    }

    if ( ( defined $TIME_LOG_END ) && ( $TIME_LOG_START >= $TIME_LOG_END ) )
    {
        S_set_error( "TIME_MIN ($TIME_LOG_START) >= TIME_MAX ($TIME_LOG_END)", 109 );
        return VERDICT_INCONC;
    }

    return 'VERDICT_NONE' if $main::opt_offline;

    $signal_availability = EVAL_get_signal_availability( $MEASURE_DATA_HREF, $SIGNAL_LABEL, $TIME_LOG_START, $TIME_LOG_END );

    my $signal_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};
    my $expect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
    my $verdict_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'VERDICT_MARKER'};

    S_add2eval_collection( 'OTHER_VALUES', "$signal_marker $SIGNAL_LABEL AVAILABILITY" );

    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker Signal is $AVAILABILITY" );

    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker Signal is $signal_availability" );

    if ( $AVAILABILITY eq $signal_availability )
    {
        S_w2log( 1, " EVAL_evaluate_signal_availability: '$SIGNAL_LABEL' is $AVAILABILITY \n" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_PASS );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
    else
    {
        S_w2log( 1, " EVAL_evaluate_signal_availability: '$SIGNAL_LABEL' is NOT $AVAILABILITY \n" );
        S_add2eval_collection( 'MISMATCH',     "'$SIGNAL_LABEL' is NOT $AVAILABILITY" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_FAIL );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
}

=head2 EVAL_evaluate_signal_frequence

         $verdict = EVAL_evaluate_signal_frequence (\%measure_data, $signal_label, $expected_frequency_hz , $tolerance_percent, $time_min_s, $time_max_s [, $threshold] );

                 _______         _______         _______         _______         _____
                |       |       |       |       |       |       |       |       |
         _______|       |_______|       |_______|       |_______|       |_______|
                1               2               3               4               5
           |                                                                         |
       time_min in sec                                                            time_max in sec

Function calculates the frequency in Hz of a signal blinking between time_min and time_max in sec. 
Afterwards it evaluates if the calculated frequency is within the given tolerance in % around the expected frequency.
Signal low is <= threshold, Signal high is > threshold, default threshold is 0.

According to the evaluation the test case verdict is set!

=cut

sub EVAL_evaluate_signal_frequence
{

    my ( $MEASURE_DATA, $SIGNAL_LABEL, $EXPECTED_FREQUENCE, $TOLERANCE, $TIME_MIN, $TIME_MAX, $THRESHOLD ) = @_;

    unless ( defined $TIME_MAX )
    {
        S_set_error( "too less parameters ,SYNTAX: VERDICT = EVAL_evaluate_signal_frequence (\$MEASURE_DATA, \$SIGNAL_LABEL, \$EXPECTED_FREQUENCE , \$TOLERANCE, \$TIME_MIN, \$TIME_MAX );", 110 );
        return VERDICT_INCONC;
    }

    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return VERDICT_INCONC;
    }

    # return VERDICT_NONE if $main::opt_offline;
    my $detected_frequence = EVAL_calc_signal_frequence( $MEASURE_DATA, $SIGNAL_LABEL, $TIME_MIN, $TIME_MAX, $THRESHOLD );
    return EVAL_evaluate_value( "FREQUENCY_HZ OF $SIGNAL_LABEL", $detected_frequence, '==', $EXPECTED_FREQUENCE, $TOLERANCE );
}

=head2 EVAL_evaluate_string

 $verdict = EVAL_evaluate_string ( $signal_to_check , $expected_string , $detected_string [, $eval_operator] );

Compares 2 strings ($expected_string and $detected_string) with comparison operator '==' (by default).
Comparison operator can be changed by setting $eval_operator to '!='.

Sets and returns VERDICT_PASS if the comparison is true and VERDICT_FAIL if the comparison is false.

B<Arguments:>

=over

=item $signal_to_check 

The label of signal to check (only for documentation reasons).

=item $expected_string 

String 1 for comparison.

=item $detected_string 

String 2 for comparison.

=item $eval_operator 

(optional) Operator for comparison. Can be either '==' (default) or '!='.

=back

B<Return Value:>

=over

=item $verdict 

Verdict of the comparison.

=back

B<Examples:>

 $verdict = EVAL_evaluate_string ( 'my_signal' , 'foo' , 'foo');        # VERDICT_PASS
 $verdict = EVAL_evaluate_string ( 'my_signal' , 'foo' , 'bar');        # VERDICT_FAIL
 $verdict = EVAL_evaluate_string ( 'my_signal' , 'foo' , 'bar', '!=');  # VERDICT_PASS
    
=cut

sub EVAL_evaluate_string
{

    my $signal_to_check = shift;
    my $expected_string = shift;
    my $detected_string = shift;
    my $eval_operator   = shift;
    my $string_operator;

    if ( not defined($detected_string) )
    {
        S_set_error( "! too less parameters ! SYNTAX: EVAL_evaluate_string ( signal_to_check , expected_string , detected_string,[eval_operator]  );", 110 );
        return VERDICT_INCONC;
    }
    ### ----------------------------------------------------------------------------------------
    if ( defined($eval_operator) )
    {
        unless ( ( $eval_operator eq '==' ) or ( $eval_operator eq '!=' ) )
        {
            S_set_error( "! Invalid parameter  'eval_operator' it should be  '==' or '!=' but received is $eval_operator", 109 );
            return VERDICT_INCONC;
        }

    }
    else
    {
        $eval_operator = '==';
    }

    #   return VERDICT_NONE if $main::opt_offline;

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $signal_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};
    my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};

    S_add2eval_collection( 'OTHER_VALUES', "$signal_marker $signal_to_check" );
    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker $expected_string" );
    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detected_string" );

    if ( ( $eval_operator eq '==' ) )
    {
        if ( $expected_string eq $detected_string )
        {
            S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_string' == '$detected_string' (detected) \n");
            S_set_verdict(VERDICT_PASS);
            return VERDICT_PASS;
        }
        else
        {
            S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_string' != '$detected_string' (detected) \n");
            S_add2eval_collection( 'MISMATCH', "Signal '$signal_to_check' : (expected) '$expected_string' != '$detected_string' (detected)" );
            S_set_verdict(VERDICT_FAIL);
            return VERDICT_FAIL;
        }
    }
    else
    {
        if ( $expected_string ne $detected_string )
        {
            S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_string' != '$detected_string' (detected) \n");
            S_set_verdict(VERDICT_PASS);
            return VERDICT_PASS;
        }
        else
        {
            S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_string' == '$detected_string' (detected) \n");
            S_add2eval_collection( 'MISMATCH', "Signal '$signal_to_check' : (expected) '$expected_string' == '$detected_string' (detected)" );
            S_set_verdict(VERDICT_FAIL);
            return VERDICT_FAIL;
        }
    }

}

=head2 EVAL_evaluate_value

    $VERDICT = EVAL_evaluate_value ( $signal_to_check , $detected_value, $operator, $expected_value [, $tolerance , $toleranceType ] );

Evaluates if the expression "$detected_value $operator $expected_value" (e.g. 2 > 1) is true. 
If $operator is "==" then an optional tolerance ($tolerance) can be given. The tolerance is by default relative in %. 
If $toleranceType is "absolute" then the tolerance is absolute.

According to the evaluation the test case verdict is set!

B<Arguments:>

=over

=item $signal_to_check 

Label of signal to check (only for documentation reasons).

=item $detected_value 

Detected value for comparison (hex, bin or dec).

=item $operator 

Can be one of the following: == != >= <= > < MASK.

=item $expected_value 

Expected value for comparison (hex, bitmask or dec).

=item $tolerance 

(optional) Tolerance for operator "==". If not given the tolerance is 0. The tolerance is by default relative in %. 

=item $toleranceType 

(optional) Can be 'absolute' or 'relative' and determines if the tolerance is absolute or relative. Default is 'relative'.

=back

B<Return Value:>

=over

=item $VERDICT 

Verdict of the evaluation.

=back

B<Examples:>

    EVAL_evaluate_value ( "MyNormalSig1", '0b1', '==', 1  );
    EVAL_evaluate_value ( "MyFloatSig2", '0x64', '==', 100.01, 5  );                  # check with 5% tolerance
    EVAL_evaluate_value ( "MyFloatSig2", '0b1100100', '==', 100.3 , 5 , 'relative' ); # check with 5% tolerance
    EVAL_evaluate_value ( "MyFloatSig2", 99.45, '==', 100 , 0.5 , 'absolute' );       # check with 0.5 absolute tolerance
    EVAL_evaluate_value ( "MyHexSig3",   15, '==', '0xF' );                           # just HEX FORMAT for expected value
    EVAL_evaluate_value ( "MyMaskSig4",  10 , 'MASK', '0bxxxx0001xxxx' );             # check value with a bitmask (1..32 bits) (ignore x)

B<Notes:> 

If you want to check more than 32 bits you have to pass a binary value (0b...)

If you want to check without verdict setting, use B<S_check_tolerance_absolute, S_check_tolerance_relative>

=cut

sub EVAL_evaluate_value
{

    my ( $signal_to_check, $detected_value, $operator, $expected_value_given, $tolerance, $tolerance_type, ) = @_;

    my $expected_value       = $expected_value_given;
    my $detected_value_given = $detected_value;

    if ( not defined($expected_value) )
    {
        S_set_error( " SYNTAX : EVAL_evaluate_value ( signal_to_check ,detected_value, operator, expected_value [, tolerance , 'absolute|relative' ] );", 110 );
        return VERDICT_INCONC;
    }

    unless ( grep /^$operator$/i, '==', '!=', '>=', '<=', '<', '>', 'MASK' )
    {
        S_set_error( "unknown operator: $operator", 114 );
        return VERDICT_INCONC;
    }

    if ( $expected_value =~ /^0b[x01]+$/ and ( $expected_value =~ /x/ or $operator eq 'MASK' ) )
    {
        $operator = 'MASK';
        S_w2log( 4, "detected bitmask, taking default operator '$operator'\n" );
    }
    else
    {
        # convert data to dec if required (only if not a bitmask)
        $expected_value = S_0x2dec($expected_value_given);
    }

    if ( defined $tolerance_type and $tolerance_type !~ /^abs|rel/i )
    {
        S_set_error( " SYNTAX : EVAL_evaluate_value ( signal_to_check ,detected_value, operator, expected_value [, tolerance , 'absolute|relative'  ] ); \n ONLY 'absolute|relative' are allowed for type of tolerance", 110 );
        return VERDICT_INCONC;
    }

    # convert data to dec if required
    $detected_value = S_0x2dec($detected_value);

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $signal_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};
    my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};

    S_add2eval_collection( 'OTHER_VALUES', "$signal_marker $signal_to_check" );

    ### ----------------------------------------------------------------------------------------

    # define $toleranceTypeText for tolerance text output
    my $toleranceTypeText = '%';
    if ( defined $tolerance_type and $tolerance_type =~ /abs/i ){
        $toleranceTypeText = 'absolute';
    }

    # add expected value to eval collection; add tolerance if necessary
    if ( defined $tolerance ){
        S_add2eval_collection( 'OTHER_VALUES', "$expect_marker $expected_value (+/- $tolerance $toleranceTypeText)" );                
    }
    else{
        S_add2eval_collection( 'OTHER_VALUES', "$expect_marker $expected_value" );        
    }

    if ( $operator eq '==' )
    {

        if ( defined $tolerance )
        {
            if ( defined $tolerance_type and $tolerance_type =~ /abs/i )
            {
                if ( S_check_tolerance_absolute( $expected_value, $detected_value, $tolerance ) )
                {
                    S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_value' =~ '$detected_value' (detected) EQUAL with +/- $tolerance absolute tolerance\n");
                    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detected_value" );
                    S_set_verdict(VERDICT_PASS);
                    return VERDICT_PASS;
                }
                else
                {
                    S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_value' !~ '$detected_value' (detected) NOT EQUAL with +/- $tolerance absolute tolerance\n");
                    S_add2eval_collection( 'MISMATCH', "Signal '$signal_to_check' : (expected) '$expected_value' !~ '$detected_value' (detected) NOT EQUAL with +/- $tolerance absolute tolerance" );
                    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detected_value (FAIL)" ); # adding "(FAIL)" is needed by VDS tests for summary creation
                    S_set_verdict(VERDICT_FAIL);
                    return VERDICT_FAIL;
                }
            }

            if ( S_check_tolerance_relative( $expected_value, $detected_value, $tolerance ) )
            {
                S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_value' =~ '$detected_value' (detected) EQUAL with +/- $tolerance % \n");
                S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detected_value" );
                S_set_verdict(VERDICT_PASS);
                return VERDICT_PASS;
            }
            else
            {
                S_w2rep(" Signal '$signal_to_check' : (expected) '$expected_value' !~ '$detected_value' (detected) NOT EQUAL with +/- $tolerance % \n");
                S_add2eval_collection( 'MISMATCH', "Signal '$signal_to_check' : (expected) '$expected_value' !~ '$detected_value' (detected) NOT EQUAL with +/- $tolerance %" );
                S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detected_value (FAIL)" ); # adding "(FAIL)" is needed by VDS tests for summary creation
                S_set_verdict(VERDICT_FAIL);
                return VERDICT_FAIL;
            }
        }

    }

    if ( defined $tolerance )
    {
        S_set_error( "toleranace will be ignored for operator '$operator' !", 0 );    # only warning
    }

    unless ( compare_two_values( $detected_value, $operator, $expected_value ) )
    {
        S_w2log( 1, " EVAL_evaluate_value: '$signal_to_check' mismatch while : $detected_value (detected: $detected_value_given) $operator $expected_value (expected: $expected_value_given) \n" );
        S_add2eval_collection( 'MISMATCH', "'$signal_to_check' mismatch while : $detected_value (detected: $detected_value_given) $operator $expected_value (expected: $expected_value_given)" );
        S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detected_value (FAIL)" ); # adding "(FAIL)" is needed by VDS tests for summary creation
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    else
    {
        S_w2log( 1, " EVAL_evaluate_value: '$signal_to_check' ok : $detected_value (detected: $detected_value_given) $operator $expected_value (expected: $expected_value_given) \n" );
        S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detected_value" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
}

=head2 EVAL_evaluate_value_around_time

   VERDICT = EVAL_evaluate_value_around_time ( \%MEASURE_DATA , $MEASURE_TIME , $SIGNAL_LABEL , $OPERATOR , $COMPARE_VALUE );

Evaluates in a measurement hash tree (\%MEASURE_DATA) if the value of signal $SIGNAL_LABEL at/near a given time ($MEASURE_TIME) 
fulfills the expression "value $OPERATOR $COMPARE_VALUE".
If the signal has no value exactly at $MEASURE_TIME then the next higher time stamp where the signal has a value is used. 
If the signal has no value at all in the measurement data then verdict is NONE.

According to the evaluation the test case verdict is set!

   $MEASURE_TIME  : returned by function or directly the keys TIME_x out of MEASURE_DATA
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA
   $OPERATOR      : == != > <
   $COMPARE_VALUE : reference value for evaluation

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = VAL_1_1  , SIG_2 = VAL_1_2 } ,
                  TIME_2 => {                                        SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = VAL_3_1  , SIG_2 = VAL_3_2 } ,
                  TIME_4 => {                                        SIG_3 => VAL_4_3  } ,
                };


=cut

sub EVAL_evaluate_value_around_time
{

    my ( $MEASURE_DATA, $MEASURE_TIME, $SIGNAL_LABEL, $OPERATOR, $COMPARE_VALUE, ) = @_;

    my ( $measure_value, $alternate_timestamp, );

    unless ( defined($COMPARE_VALUE) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_value_around_time ( \%MEASURE_DATA , \$MEASURE_TIME , \$SIGNAL_LABEL , \$OPERATOR , \$COMPARE_VALUE )", 110 );
        return VERDICT_INCONC;
    }

    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return VERDICT_INCONC;
    }

    # check if $OPERATOR is known
    if ( compare_two_values( 0, $OPERATOR, 0 ) == -1 ) { S_set_error( "unknown OPERATOR $OPERATOR", 114 ); return VERDICT_INCONC; }

    ( $measure_value, $alternate_timestamp ) = EVAL_get_value_around_time( $MEASURE_DATA, $MEASURE_TIME, $SIGNAL_LABEL );

    unless ( defined $measure_value )
    {
        S_w2log( 1, " EVAL_evaluate_value_around_time: no value found for signal '$SIGNAL_LABEL'\n" );
        return VERDICT_NONE;
    }

    my $verdict;
    if ( compare_two_values( $measure_value, $OPERATOR, $COMPARE_VALUE ) )
    {
        #
        # good case
        #
        if ( defined $alternate_timestamp )
        {
            S_w2log( 1, " EVAL_evaluate_value_around_time: '$SIGNAL_LABEL' $measure_value $OPERATOR $COMPARE_VALUE fulfilled at time $alternate_timestamp (nearest to $MEASURE_TIME) \n" );
        }
        else
        {
            S_w2log( 1, " EVAL_evaluate_value_around_time: '$SIGNAL_LABEL' $measure_value $OPERATOR $COMPARE_VALUE fulfilled at time $MEASURE_TIME \n" );
        }
        $verdict = VERDICT_PASS;
        S_set_verdict($verdict);
        return $verdict;
    }
    else
    {
        #
        # bad case
        #
        if ( defined $alternate_timestamp )
        {
            S_w2log( 1, " EVAL_evaluate_value_around_time: '$SIGNAL_LABEL' $measure_value $OPERATOR $COMPARE_VALUE NOT fulfilled at time $alternate_timestamp (nearest to $MEASURE_TIME) \n" );
        }
        else
        {
            S_w2log( 1, " EVAL_evaluate_value_around_time: '$SIGNAL_LABEL' $measure_value $OPERATOR $COMPARE_VALUE NOT fulfilled at time $MEASURE_TIME \n" );
        }
        $verdict = VERDICT_FAIL;
        S_set_verdict($verdict);
        return $verdict;
    }
}

=head2 EVAL_evaluate_values_at_event

    $t_event_s = EVAL_evaluate_values_at_event ( $MEASURE_DATA_HREF , $event_listref , $offset_after_event , $signals_expected_hashref [, $time_min_s] );

   For each signal defined in $signals_expected_hashref: evaluates in the trace $MEASURE_DATA_HREF if the
   value at time t = t(event) + t(offset) matches the expected value (tolerance
   may be defined absolute or relative).

   t(event) is the first time in the trace (starting at $time_min_s) at which the conditions of the event
   defined by $event_listref are fulfilled.

   t(offset) in seconds is given by $offset_after_event.

   Returns t(event) in seconds.

   Sets the test case verdict.

    example for $event_listref :
        $event_listref = [  'sig1 > 1' ,
                            'sig2 == 0' ,
                            'sig3 != 5' ,
                         ];

        event is here defined as the time when all 3 sub-conditions are fulfilled
        simultaneously (i.e. (sig1 > 1) and (sig2 == 0) and (sig3 != 5) )

   This function works also properly if there is more than one signal in one event.

    example for $signals_expected_hashref :
        $signals_expected_hashref = {  'sig1' => '1' ,    # PASS if sig1 == 1 (no tolerance)
                                       'sig2' => '2?0.1'  # PASS if 1.9 <= sig2 <= 2.1 (absolute tolerance)
                                       'sig3' => '3%10'   # PASS if 2.7 <= sig2 <= 3.3 (relative tolerance)
                                    };

    example of function call:
        EVAL_evaluate_values_at_event ( ['VXFL > 15'] , 1 , { 'SP1' => '1600?100' } );

=cut

sub EVAL_evaluate_values_at_event
{

    my $MEASURE_DATA_HREF        = shift;
    my $event_listref            = shift;
    my $offset_after_event       = shift;
    my $signals_expected_hashref = shift;
    my $time_min_s               = shift;

    my ( $multi_condition, $condition_label, $cnt, $times, $det, $exp, @signals, $tolerance, $eval_time );

    S_w2log( 1, "EVAL_evaluate_values_at_event \n" );

    unless ( defined($signals_expected_hashref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: EVAL_evaluate_values_at_event ( dataref_hashref, event_listref , offset_after_event , can_signals_expected_hashref )", 110 );
        return 0;
    }

    unless ( ref($signals_expected_hashref) eq "HASH" )
    {
        S_set_error( "signals_expected_hashref is not a hash reference", 114 );
        return 0;
    }
    if ( defined $event_listref && ref($event_listref) ne "ARRAY" )
    {
        S_set_error( "event_listref is not an array reference", 114 );
        return 0;
    }

    if ( defined $MEASURE_DATA_HREF && ref($MEASURE_DATA_HREF) ne "HASH" )
    {
        S_set_error( " MEASURE_DATA_HREF is not an Hash reference", 114 );
        return 0;
    }

    return 0 if $main::opt_offline;

    # loop over all conditions of event
    $cnt = 1;
    foreach my $condition_string ( @{$event_listref} )
    {
        # define a label for current condition
        $condition_label = "condition $cnt";

        # extract signal name, operator (== or != or < or > ) and compare value from event hash
        # and build data structure for function EVAL_get_time_multi_condition
        if ( $condition_string =~ /\s*(.+)\s*(==|!=|<|>)\s*([+-]?\s*\d+\.?\d*)/i )
        {
            $multi_condition->{$condition_label}{'SIGNAL_LABEL'}  = $1;
            $multi_condition->{$condition_label}{'OPERATOR'}      = $2;
            $multi_condition->{$condition_label}{'COMPARE_VALUE'} = $3;
        }
        else
        {
            S_set_error( "EVAL_evaluate_values_at_event: could not extract operator and compare value from event_listref for signal $multi_condition->{$condition_label}{'SIGNAL_LABEL'}", 110 );
            next;
        }
        S_w2rep(" EVAL_evaluate_values_at_event: event $condition_label: $condition_string \n");
        push( @signals, $multi_condition->{$condition_label}{'SIGNAL_LABEL'} );
        $cnt++;
    }

    push( @signals, keys %{$signals_expected_hashref} );

    # get all times when conditions of event are fulfilled
    $times = EVAL_get_time_multi_condition( $MEASURE_DATA_HREF, $multi_condition, $time_min_s );
    if ( scalar(@$times) < 1 )
    {
        S_w2rep(" EVAL_evaluate_values_at_event: event never fulfilled in trace. \n");
        S_set_verdict(VERDICT_FAIL);
        return 0;
    }

    $eval_time = $$times[0] + $offset_after_event;

    # loop over signals to be read and checked
    $cnt = 0;
    foreach my $signal ( keys %{$signals_expected_hashref} )
    {

        $cnt++;
        S_w2rep(" EVAL_evaluate_values_at_event: evaluate SIGNAL $cnt : $signal at time $eval_time\n");

        # get expected value from hashref
        $exp = $signals_expected_hashref->{$signal};

        # read actual (phys) value of can signal
        ($det) = EVAL_get_value_around_time( $MEASURE_DATA_HREF, $eval_time, $signal );

        ### if value has to be checked with tolerance ( e.g '100.0%3.5' or '- 10 % 3' )
        if ( $exp =~ /([+-]?\s*\w+\.?\d*)\s*%\s*(\d+\.?\d*)/i )
        {
            $exp       = $1;
            $tolerance = $2;
            EVAL_evaluate_value( $signal, $det, '==', $exp, $tolerance, 'relative' );
        }
        elsif ( $exp =~ /([+-]?\s*\w+\.?\d*)\s*\?\s*(\d+\.?\d*)/i )
        {
            $exp       = $1;
            $tolerance = $2;
            EVAL_evaluate_value( $signal, $det, '==', $exp, $tolerance, 'relative' );
        }
        else    ### check values directly without tolerance
        {
            EVAL_evaluate_value( $signal, $det, '==', $exp );
        }
    }

    # return time of event
    return ( $$times[0] );

}

=head2 EVAL_evaluate_values_existence

    $verdict = EVAL_evaluate_values_existence ( $measure_data_href , $signal_label , $condition_href [, $time_min [, $time_max ]] );

Evaluates if a given signal ($signal_label) in a measurement ($measure_data_href) fulfills the conditions given in $condition_href. 
$condition_href contains a combination of the following possibilites:

=over

=item ONCE

The condition is fulfilled if the values of $signal_label have at least once the values given in the array reference.

=item NEVER

The condition is fulfilled if the values of $signal_label have never the values given in the array reference.

=item ABOVE

The condition is fulfilled if the values of $signal_label are at least once above the given value.

=item BELOW

The condition is fulfilled if the values of $signal_label are at least once below the given value.

=back

According to the evaluation the test case verdict is set!

B<Arguments:>

=over

=item $measure_data_href

Complete hash structure of data to be evaluated. This could be a CAN data or a Fast diagnosis Trace.

=item $signal_label

Signal label whose values are to be evaluated.

=item $condition_href

Hash reference with one or more of the below key-value pairs. See posibilities above for explanation.

    $condition_href = {
        'ONCE' => <array reference>,
        'NEVER' => <array reference>,
        'ABOVE' => <scalar>,
        'BELOW' => <scalar>,
   }

=item $time_min

(optional) minimum value of time from which the signal will be evaluated. e.g. 0.03 

=item $time_max

(optional) Maximum value of time upto which the signal will be evaluated. e.g. 0.08

=back

B<Return Value:>

=over

=item $verdict 

Returns verdict of Evaluation

=back

B<Examples:>

    my $condition_href = {
        'ONCE' => [5],
        'NEVER' => [0, 10],
        'ABOVE' => 8,
        'BELOW' => 2,
    }
    $verdict = EVAL_evaluate_values_existence ( $measure_data_href , 'mysignal' , $condition_href, 1, 9 );

In the above example the verdict will only be VERDICT_PASS if the values of 'mysignal' are at least once 5, never 0 or 10, 
at least once above 8 and at least once below 2.

=cut

sub EVAL_evaluate_values_existence {
    my $MEASURE_DATA_HREF = shift;
    my $SIGNAL_LABEL      = shift;
    my $condition_href    = shift;
    my $TIME_MIN          = shift;
    my $TIME_MAX          = shift;

    S_w2log( 1, "EVAL_evaluate_values_existence \n" );

    unless ( defined($condition_href) ) {
        S_set_error( "! too less parameters ! SYNTAX: EVAL_evaluate_values_existence ( MEASURE_DATA_HREF , SIGNAL_LABEL , condition_href,[, TIME_MIN [, TIME_MAX ]] )\n", 110 );
        return VERDICT_INCONC;
    }

    unless ( ref($condition_href) eq "HASH" ) {
        S_set_error( "condition_href is not an Hash reference", 114 );
        return VERDICT_INCONC;
    }

    if ( defined $MEASURE_DATA_HREF && ref($MEASURE_DATA_HREF) ne "HASH" ) {
        S_set_error( " MEASURE_DATA_HREF is not an Hash reference", 114 );
        return VERDICT_INCONC;
    }

    if ( ( defined $TIME_MAX ) && ( $TIME_MIN >= $TIME_MAX ) ) {
        S_set_error( "TIME_MIN ($TIME_MIN) >= TIME_MAX ($TIME_MAX)", 109 );
        return VERDICT_INCONC;
    }

    return VERDICT_NONE if $main::opt_offline;

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $signal_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};

    S_add2eval_collection( 'OTHER_VALUES', "$signal_marker $SIGNAL_LABEL" );

    my $functionMap_href = {
        ONCE  => \&EVAL_evaluate_values_once,
        NEVER => \&EVAL_evaluate_values_never,
        ABOVE => \&EVAL_evaluate_values_once_above,
        BELOW => \&EVAL_evaluate_values_once_below,
    };

    my $overallVerdict = VERDICT_NONE;

    foreach my $cond_key ( keys(%$condition_href) ) {
        S_w2log( 1, "cond_key value :: $cond_key \n" );

        if ( defined $functionMap_href->{$cond_key} ) {
            my $cond_value = $condition_href->{$cond_key};
            S_w2log( 1, "$cond_key value :: $cond_value\n" );

            # call sub-function based on $cond_key
            my $verdict = $functionMap_href->{$cond_key}->( $MEASURE_DATA_HREF, $SIGNAL_LABEL, $cond_value, $TIME_MIN, $TIME_MAX );
            $overallVerdict = S_determine_overall_verdict( $overallVerdict, $verdict );
        }
        else {
            S_set_error( "Given conditional key is not supported :: $cond_key \n", 114 );
            $overallVerdict = VERDICT_INCONC;
        }
    }

    return $overallVerdict;
}

=head2 EVAL_evaluate_value_over_time

    VERDICT = EVAL_evaluate_value_over_time ( $measureData_href , $signalLabel , $operator , $compareValueOrSignal [, $timeMin [, $timeMax ]] );

Evaluates if for all values of the signal $signalLabel the expression '$signalLabel $operator $compareValueOrSignal' is true.
Sets and returns the verdict according to the result of the evaluation.
If $compareValueOrSignal is a signal label then the function evaluates each value of $signalLabel with each value of $compareValueOrSignal which have the same time value.
Calls EVAL_get_values_and_times_over_time internally.

    $measureData_href     : Signal reference , see example below
    $signalLabel          : signal to be checked in $measureData_href
    $operator             : == != > <
    $compareValueOrSignal : reference value for evaluation, can be a number or another signal Label of $measureData_href
    $timeMin              : start time in $measureData_href
    $timeMax              : stop time in $measureData_href

Example for
    $measureData_href = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

Examples:
    EVAL_evaluate_value_over_time ( $measureData_href , 'SIG_1' , '<' , 1 );          # PASS
    EVAL_evaluate_value_over_time ( $measureData_href , 'SIG_1' , '==' , 'SIG_2' );   # FAIL

=cut

sub EVAL_evaluate_value_over_time
{

    my @args = @_;
    return VERDICT_INCONC unless S_checkFunctionArguments( 'EVAL_evaluate_value_over_time ( $measureData_href , $signalLabel , $operator , $compareValueOrSignal [, $timeMin , $timeMax ] )', @args );

    my $measureData          = shift @args;
    my $signalLabel          = shift @args;
    my $operator             = shift @args;
    my $compareValueOrSignal = shift @args;
    my $timeMin              = shift @args;
    my $timeMax              = shift @args;

    if ( ( defined $timeMax ) && ( $timeMin >= $timeMax ) )
    {
        S_set_error( "TIME_MIN ($timeMin) >= TIME_MAX ($timeMax)", 109 );
        return VERDICT_INCONC;
    }

    # check if $operator is known
    if ( compare_two_values( 0, $operator, 0 ) == -1 )
    {
        S_set_error( "unknown OPERATOR $operator", 114 );
        return VERDICT_INCONC;
    }

    return VERDICT_NONE if $main::opt_offline;

    # check if $compareValueOrSignal is a number or a signal name
    my $isNumber = 0;
    if ( $compareValueOrSignal =~ /^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$/ )
    {
        $isNumber = 1;
    }

    # get measured values of $signalLabel
    my ( $trace_values_aref, $time_values_aref ) = EVAL_get_values_and_times_over_time( $measureData, $signalLabel, $timeMin, $timeMax );
    if ( not defined $trace_values_aref )
    {
        S_set_error("There are no values for signal label $signalLabel in the data structure");
        return VERDICT_INCONC;
    }

    # calculate min and max values of $signalLabel for output of detected value in eval collection
    my $minValue = min( @$trace_values_aref );
    my $maxValue = max( @$trace_values_aref );

    # determine detected value for eval collection based on operator
    my ($detectedValue, $whichLimit);
    if( $operator =~ /^>/ ){
        $detectedValue = "min = $minValue";
        $whichLimit = "lower limit";
    }
    elsif( $operator =~ /^</ ){
        $detectedValue = "max = $maxValue";
        $whichLimit = "upper limit";
    }
    else{
        $detectedValue = "min = $minValue  max = $maxValue";        
        $whichLimit = "other";
    }
    
    # add data to eval collection csv file for this evaluation
    my $signal_marker = S_get_contents_of_hash (['EVALUATION_FILE', 'SIGNAL_MARKER']);
    my $expect_marker = S_get_contents_of_hash (['EVALUATION_FILE', 'EXPECT_MARKER']);
    my $detect_marker = S_get_contents_of_hash (['EVALUATION_FILE', 'DETECT_MARKER']);

    S_add2eval_collection( 'OTHER_VALUES', "$signal_marker $signalLabel" );
    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker $operator $compareValueOrSignal");
    # S_add2eval_collection for detected value is done after evaluation to be able to add "(FAIL)" if failed

    # get list of compare values if a signal name is given as compare value
    my ( $compare_values_aref, $time_values_comp_aref );
    if ( not $isNumber )
    {
        ( $compare_values_aref, $time_values_comp_aref ) = EVAL_get_values_and_times_over_time( $measureData, $compareValueOrSignal, $timeMin, $timeMax );
        if ( not defined $compare_values_aref )
        {
            S_set_error("There are no values for compare signal $compareValueOrSignal in the data structure");
            return VERDICT_INCONC;
        }
    }

    # do the comparison for every measured value of $signalLabel
    my $compareIndex = 0;
    foreach my $valueIndex ( 0 .. @{$trace_values_aref} - 1 )
    {
        my $measure_value = ${$trace_values_aref}[$valueIndex];
        my $time_value    = ${$time_values_aref}[$valueIndex];
        my $compareValue  = $compareValueOrSignal;
        if ( not $isNumber )
        {
            while ( ${$time_values_comp_aref}[$compareIndex] < $time_value )
            {
                $compareIndex++;
            }
            if ( ${$time_values_comp_aref}[$compareIndex] != $time_value )
            {
                S_set_error("For measure value $signalLabel at time $time_value there was no compare value found in signal $compareValueOrSignal with the same time");
                return VERDICT_INCONC;
            }
            $compareValue = ${$compare_values_aref}[$compareIndex];
        }
        unless ( compare_two_values( $measure_value, $operator, $compareValue ) )
        {
            my $failTime = ${$time_values_aref}[$valueIndex];
            S_w2log( 1, " EVAL_evaluate_value_over_time: '$signalLabel' mismatch while : $measure_value $operator $compareValueOrSignal at time $failTime\n" );
            S_add2eval_collection( 'MISMATCH' , "'$signalLabel' mismatch while : $measure_value $operator $compareValueOrSignal at time $failTime" );
            S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detectedValue (FAIL)"); # adding "(FAIL)" is needed by VDS tests for summary creation
            S_set_verdict(VERDICT_FAIL);
            return VERDICT_FAIL;
        }
    }

    S_w2log( 1, " EVAL_evaluate_value_over_time: '$signalLabel' $operator $compareValueOrSignal always fulfilled \n" );
    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker $detectedValue");
    S_set_verdict(VERDICT_PASS);
    return VERDICT_PASS;
}

=head2 EVAL_evaluate_values_at_position

    VERDICT = EVAL_evaluate_values_at_position ( $MEASURE_DATA_HREF , $SIGNAL_LABEL , $VALUE_EXPECTED , $POSITION [ , $TIME_MIN ] );

    Evaluates the value at a given position of measured signal.

    $MEASURE_DATA_HREF   : Signal reference
    $SIGNAL_LABEL        : signal to be checked in MEASURE_DATA_HREF
    $VALUE_EXPECTED      : value which must be at required position in $MEASURE_DATA_HREF
    $POSITION            : first/last
    $TIME_MIN            : minimum time in seconds

   example for
   $MEASURE_DATA_HREF = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

=cut

sub EVAL_evaluate_values_at_position
{

    my ( $MEASURE_DATA_HREF, $SIGNAL_LABEL, $VALUE_EXPECTED, $POSITION, $TIME_MIN ) = @_;

    my ( $check_value, $time_occurence, $value_last_text, @all_values, $value_detected, $signal_operator, @VALUE, $expected_value );

    S_w2log( 1, "EVAL_evaluate_values_at_position \n" );

    unless ( defined $POSITION )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_value_last ( MEASURE_DATA_HREF , SIGNAL_LABEL , VALUE_EXPECTED, POSITION[ , TIME_MIN ] )", 110 );
        return VERDICT_INCONC;
    }

    unless ( ( $POSITION =~ /^first$/i ) || ( $POSITION =~ /^last$/i ) )
    {
        S_set_error( "wrong parameter : POSITION ('FIRST/LAST') \n", 114 );
        return VERDICT_INCONC;
    }

    if ( defined $MEASURE_DATA_HREF && ref($MEASURE_DATA_HREF) ne "HASH" )
    {
        S_set_error( " MEASURE_DATA_HREF is not an Hash reference", 114 );
        return VERDICT_INCONC;
    }

    if ( $VALUE_EXPECTED =~ />/ )
    {
        @VALUE           = split( />/, $VALUE_EXPECTED );
        $signal_operator = ">";
        $expected_value  = $VALUE[1];
    }
    elsif ( $VALUE_EXPECTED =~ /</ )
    {
        @VALUE           = split( /</, $VALUE_EXPECTED );
        $signal_operator = "<";
        $expected_value  = $VALUE[1];
    }
    else
    {
        $signal_operator = "==";
        $expected_value  = $VALUE_EXPECTED;
    }

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $signal_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'SIGNAL_MARKER'};
    my $expect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
    my $verdict_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'VERDICT_MARKER'};

    S_add2eval_collection( 'OTHER_VALUES', "$signal_marker $SIGNAL_LABEL" );

    $value_last_text = join( " ", $VALUE[1] );
    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker $POSITION [$value_last_text]" );

    @all_values = EVAL_get_values_over_time( $MEASURE_DATA_HREF, $SIGNAL_LABEL, $TIME_MIN );
    unless (@all_values)
    {
        S_w2log( 1, " EVAL_evaluate_values_at_position: $SIGNAL_LABEL no values found \n" );
        S_add2eval_collection( 'OTHER_VALUES', "$detect_marker : no values found" );
        S_add2eval_collection( 'MISMATCH',     "$SIGNAL_LABEL no values found" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_INCONC );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_INCONC);
        return VERDICT_INCONC;
    }

    if ( $POSITION =~ /^first$/i )
    {
        $value_detected = shift @all_values;
    }
    elsif ( $POSITION =~ /^last$/i )
    {
        $value_detected = pop @all_values;
    }

    my $VERDICT = EVAL_evaluate_value( $SIGNAL_LABEL, $value_detected, $signal_operator, $expected_value );

    return $VERDICT;
}

=head2 EVAL_filter_MAV

    EVAL_filter_MAV( \%MEASURE_DATA, $samples, $SIGNAL_LABEL [, $NEW_SIGNAL_LABEL ] );

filter given signal with moving average to smoothen curve, if no $NEW_SIGNAL_LABEL is given, original signal is overwritten

 NOTE: the more samples you take the less noise you get, filter will not work on first and last samples
       $samples/2 points on beginning and end of original data will be filled with first/last average value!
       be aware that you might filter out things you wanted to see and that this is not original data anymore
       B<so it's recommended to use new label>

=cut

sub EVAL_filter_MAV
{

    my $MEASURE_DATA     = shift;
    my $samples          = shift;
    my $SIGNAL_LABEL     = shift;
    my $NEW_SIGNAL_LABEL = shift;
    my @tempvals         = ();
    my @temptimes        = ();
    my ( $i, $t, $total, $time_stamp );

    $NEW_SIGNAL_LABEL = $SIGNAL_LABEL unless ( defined $NEW_SIGNAL_LABEL );
    S_w2log( 5, " EVAL_filter_MAV $samples samples $SIGNAL_LABEL -> $NEW_SIGNAL_LABEL \n" );

    unless ( defined $SIGNAL_LABEL )
    {
        S_set_error( "too less parameters ,SYNTAX: EVAL_filter_MAV ( \%MEASURE_DATA, \$samples, \$SIGNAL_LABEL [, \$NEW_SIGNAL_LABEL ] );", 110 );
        return 0;
    }

    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( " MEASURE_DATA is not a hash reference", 114 );
        return 0;
    }

    if ( $samples <= 0 )
    {
        S_set_error( " samples is not > 0", 114 );
        return 0;
    }

    return 1 if $main::opt_offline;

    foreach $time_stamp ( sort { $a <=> $b } keys %$MEASURE_DATA )
    {
        next unless defined $MEASURE_DATA->{$time_stamp}{$SIGNAL_LABEL};
        push( @tempvals,  $MEASURE_DATA->{$time_stamp}{$SIGNAL_LABEL} );
        push( @temptimes, $time_stamp );

    }

    # initalize total buffer
    for ( $i = 0 ; $i < $samples ; $i++ )
    {
        $total += $tempvals[$i];
    }

    for ( $i = $samples ; $i < $#tempvals ; $i++ )
    {
        #print $i," ",$total/$samples,"\n";
        $MEASURE_DATA->{ $temptimes[ $i - ( $samples / 2 ) ] }{$NEW_SIGNAL_LABEL} = $total / $samples;
        $total += $tempvals[$i] - $tempvals[ $i - $samples ];
    }

    my $first = $MEASURE_DATA->{ $temptimes[ $samples - ( $samples / 2 ) ] }{$NEW_SIGNAL_LABEL};
    my $last = $MEASURE_DATA->{ $temptimes[ $#tempvals - 1 - ( $samples / 2 ) ] }{$NEW_SIGNAL_LABEL};

    #write first/last values, where filter is not active with first/last filter value
    for ( $i = 0 ; $i < ( $samples / 2 ) ; $i++ )
    {
        $MEASURE_DATA->{ $temptimes[$i] }{$NEW_SIGNAL_LABEL} = $first;
        $MEASURE_DATA->{ $temptimes[ $i + $#tempvals - ( $samples / 2 ) ] }{$NEW_SIGNAL_LABEL} = $last;
    }

}

=head2 EVAL_get_last_signallist_time

  $MEASURE_TIME = EVAL_get_last_signallist_time ( \%MEASURE_DATA , \@SIGNAL_LIST );

  return last occurence time of given signals

offline_return : -1

=cut

sub EVAL_get_last_signallist_time
{
    my ( $MEASURE_DATA, $SIGNAL_LIST, ) = @_;

    my ( $sig, $time_used, $FOUND_TIME, $RETURN_VALUE );

    unless ( defined($SIGNAL_LIST) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MEASURE_TIME = EVAL_get_last_signallist_time (  \%MEASURE_DATA , \@SIGNAL_LIST  )", 110 );
        return -1;
    }
    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return -1;
    }
    if ( ref($SIGNAL_LIST) ne "ARRAY" )
    {
        S_set_error( "Second parameter (\@SIGNAL_LIST) is not aa array reference", 114 );
        return -1;
    }

    return -1 if $main::opt_offline;

    # loop through time in signals hash and look for given SIGNALS
    foreach $time_used ( sort { $a <=> $b } keys %$MEASURE_DATA )
    {
        foreach $sig (@$SIGNAL_LIST)
        {
            $RETURN_VALUE = $MEASURE_DATA->{$time_used}->{$sig};
            next unless defined $RETURN_VALUE;
            $FOUND_TIME = $time_used;
            S_w2log( 5, " found $sig at $time_used\n" );
        }

    }

    S_w2log( 5, " max found time = $FOUND_TIME\n" );
    return $FOUND_TIME;

}

=head2 EVAL_get_signal_availability

   SIGNAL_AVAILABILITY = EVAL_get_signal_availability ( $MEASURE_DATA_HREF , $SIGNAL_LABEL [, $TIME_LOG_START [, $TIME_LOG_END ]] );

   $MEASURE_DATA_HREF : Signal reference
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA_HREF
   $TIME_LOG_START: start time in MEASURE_DATA_HREF
   $TIME_LOG_END  : stop time in MEASURE_DATA_HREF

   for Example
   $MEASURE_DATA_HREF = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   Checks out of the measurement hash tree $MEASURE_DATA_HREF, if the given signal is available ("present") or not ("absent").

   $TIME_LOG_START and $TIME_LOG_END determine the time range for the data. If neither of them is given
   then the time range is the full time range of the data hash.

=cut

sub EVAL_get_signal_availability
{

    my $MEASURE_DATA_HREF = shift;
    my $SIGNAL_LABEL      = shift;
    my $TIME_LOG_START    = shift;
    my $TIME_LOG_END      = shift;

    my ( $first_time, $last_time, @values );

    S_w2log( 1, "EVAL_get_signal_availability \n" );

    unless ( defined($SIGNAL_LABEL) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_get_signal_availability ( MEASURE_DATA_HREF , SIGNAL_LABEL, [, TIME_LOG_START [, TIME_LOG_END ]] )", 110 );
        return 0;
    }

    if ( defined $MEASURE_DATA_HREF && ref($MEASURE_DATA_HREF) ne "HASH" )
    {
        S_set_error( " MEASURE_DATA_HREF is not an Hash reference", 114 );
        return 0;
    }

    if ( ( defined $TIME_LOG_END ) && ( $TIME_LOG_START >= $TIME_LOG_END ) )
    {
        S_set_error( "TIME_MIN ($TIME_LOG_START) >= TIME_MAX ($TIME_LOG_END)", 109 );
        return 0;
    }

    return 0 if $main::opt_offline;

    # loop through time in signals hash
    foreach my $time ( sort { $a <=> $b } keys %$MEASURE_DATA_HREF )
    {
        next if ( ( defined $TIME_LOG_START ) and ( $time < $TIME_LOG_START ) );
        last if ( ( defined $TIME_LOG_END )   and ( $time > $TIME_LOG_END ) );
        if ( defined $MEASURE_DATA_HREF->{$time}{$SIGNAL_LABEL} )
        {
            S_w2log( 3, " EVAL_get_signal_availability: found '$SIGNAL_LABEL' at $time \n" );
            S_w2log( 1, " EVAL_get_signal_availability: '$SIGNAL_LABEL' is present \n" );
            return 'present';
        }
    }

    S_w2log( 1, " EVAL_get_signal_availability: '$SIGNAL_LABEL' is absent \n" );
    return 'absent';
}

=head2 EVAL_get_signal_pulses


    ($NumOfPulses, %pulses) = EVAL_get_signal_pulses(     \%MEASURE_DATA ,
                                                        $SIGNAL_LABEL,
                                                         [$PULSE_THRESHOLD,
                                                        $THRESHOLD_HYSTERESIS,
                                                        $PULSE_SLOPE,
                                                        $SIGNAL_HOLD_COUNT,
                                                        $TIME_LOG_START,
                                                        $TIME_LOG_END,] );

Parses through the Measurement hash(see L</DATA STRUCTURE>) and collects the pulses with specified condition. 
For each collected pulse the start time (=time of first data point above the threshold), 
end time (=time of first data point below the threshold after start time)
and values of the data point above the threshold are stored, see format of "%pulses" below.


                               VALUES OVER TRESHOLD ('rising' pulse)
                                       __
                                    __/  \__               ___
                                   /        \             /   \
                    ______________/__________\___________/_____\_______ $PULSE_THRESHOLD level
               time=   1   2   3 /  4   5   6 \  7   8  /9   10 \
                   -------------/--------------\-------/---------\----- $THRESHOLD_HYSTERESIS level (for 'rising' pulse)
                               /                \_____/           \

   $MEASURE_DATA        : Signal reference
                               (refer "DATA STRUCTURE" for data in form of example 2.
                                For fire times measured with TRC, it is required to give data
                                only for one channel. Otherwise, there would be too much data.
                                Refer to example 1 for according data structure.)
   $SIGNAL_LABEL        : signal to be checked in MEASURE_DATA
   $PULSE_SLOPE         : Slope of the pulse to be checked ('rising' or 'falling')
   $PULSE_THRESHOLD     : Threshold value for the pulse (default is 0.5)
   $THRESHOLD_HYSTERESIS: Hysteresis for the pulse threshold value (unit is same as $PULSE_THRESHOLD, default is 0)
   $SIGNAL_HOLD_COUNT   : The minimum number of samples for considering as a pulse ( = 1 , by default)
   $TIME_LOG_START      : start time in MEASURE_DATA, can be value in ms or 'START' for beginning of measurement
   $TIME_LOG_END        : stop time in MEASURE_DATA, can be value in ms or 'END' for end of measurement

  Examples:
      1)

          my $measuredData_href = {
                                'AB1FD' => [1, 1.2, 1.4, 2, 2.2, 1.3, 2, 1, 0.8, 1.4, 1.5, 1.8],
                                'time'=>   [0, 1  , 2  , 3, 4  , 5  , 6, 7, 8  , 9  , 10 , 11 ],
                            };

        ($SucceededPulses_aref, $pulses_href) = EVAL_get_signal_pulses (     $measuredData_href ,
                                                                                'AB1FD',
                                                                                1.5,         # Voltage Level
                                                                                0,            # Voltage Tolerance
                                                                                'rising',
                                                                                2,             # Min Nbr of samples
                                                                                'START',
                                                                                'END',
                                                                            );

    2)

        my $measuredData_href = {
                                    0 => {'AB1FD' => 0, 'BT1FP' => 0},
                                    1 => {'AB1FD' => 1, 'BT1FP' => 0},
                                    2 => {'AB1FD' => 1, 'BT1FP' => 0},
                                    3 => {'AB1FD' => 1, 'BT1FP' => 0},
                                    4 => {'AB1FD' => 0, 'BT1FP' => 1},
                                    5 => {'AB1FD' => 0, 'BT1FP' => 1},
                                };

        ($SucceededPulses_aref, $pulses_href) = EVAL_get_signal_pulses(     $measuredData_href ,
                                                                            'AB1FD',
                                                                            0.5,            # Voltage Level
                                                                            0,                # Voltage Tolerance
                                                                            'rising',
                                                                            1,                # Min Nbr of samples
                                                                            'START',
                                                                            'END',
                                                                            );


If no pulses found or error: returns (0, {})

   offline return : (1, ( 'pulse0'=>
                        {
                            'start' => 0,
                            'end' => 1,
                            'values' =>[0,1]
                        }
                      )
                  )

   Positive return : ($NumOfPulses, %pulses)   # format of "%pulses"
                                               # (
                                               # 'pulse0'=>{  'start' => 1.08, 'end' => 2.05, 'values' =>[1,2...] },
                                               # 'pulse1'=>{  'start' => 3.12, 'end' => 4.87, 'values' =>[2,2...] },
                                               # .
                                               # .
                                               # )


=cut

sub EVAL_get_signal_pulses
{

    my @args = @_;

    return ( 0, () ) unless S_checkFunctionArguments( 'EVAL_get_signal_pulses ( $measuredData_href , $channelName, [$voltageLevel, $voltageHysteresis, $slopeType, $minSamplesPerPulse, $TimeMin, $TimeMax, ] )', @args );

    my $measuredData_href  = shift @args;
    my $channelName        = shift @args;
    my $voltageLevel       = shift @args;
    my $voltageHysteresis   = shift @args;
    my $slopeType          = shift @args;
    my $minSamplesPerPulse = shift @args;
    my $time_min           = shift @args;
    my $time_max           = shift @args;
    my ( $pulseStartTime, $pulseEndTime );
    my ( $numOfActualPulses, %pulses, @values );
    my $time_aref;
    my $channelData_aref;

    #validate slope type
    unless ( defined $slopeType ) {
        S_w2log( 3, "Default value 'rising' will be set for slope type!" );
        $slopeType = "rising";
    }
    unless ( $slopeType =~ /rising/i || $slopeType =~ /falling/i ) {
        S_w2log( 3, "Invalid 'SlopeType' specified for Channel $channelName. 'SlopeType' shall be 'rising' or 'falling'" );
        S_w2log( 3, "Default value 'rising' will be set for slope type!" );
        $slopeType = "rising";
    }

    #Time_min should be a number or 'START'
    unless ( defined $time_min ) {
        S_w2log( 3, "Default value 'START' will be set for time min!" );
        $time_min = 'START';
    }
    unless ( $time_min =~ /\d+\.?\d*/ || $time_min =~ /START/i ) {
        S_w2log( 3, "Time min shall be a number or 'START' (is $time_min)" );
        S_w2log( 3, "Default value 'START' will be set for time min!" );
        $time_min = 'START';
    }

    #Time_max should be a number or 'END'
    unless ( defined $time_max ) {
        S_w2log( 3, "Default value 'END' will be set for time max!" );
        $time_max = 'END';
    }
    unless ( $time_max =~ /\d+\.?\d*/ || $time_max =~ /END/i ) {
        S_w2log( 3, "Time max shall be a number or 'END' (is $time_max)" );
        S_w2log( 3, "Default value 'END' will be set for time max!" );
        $time_max = 'END';
    }

    # minimum samples per pulse should be greater than 0
    if ( defined($minSamplesPerPulse) && $minSamplesPerPulse <= 0 ) {
        $minSamplesPerPulse = 1;
        S_w2log( 3, "Minimum samples per pulse should be greater than 0 - set to default value 1" );
    }

    #assign voltage level 0.5, if not defined (will fit for LCT)
    $voltageLevel = 0.5 unless ( defined($voltageLevel) );

    #assign voltage tolerance as 0, if not defined
    $voltageHysteresis = 0 unless ( defined($voltageHysteresis) );

    #assign Min samples per pulse as 1, if not defined
    $minSamplesPerPulse = 1 unless ( defined($minSamplesPerPulse) );

    if ($main::opt_offline) {
        return (
            1,
            {
                'pulse0' => {
                    'start'  => 0,
                    'end'    => 1,
                    'values' => [ 0, 1 ]
                }
            }
        );
    }

    #set the number of pulses found as 0
    $numOfActualPulses = 0;

    #get the time array and signal array corresponding to the channel
    #
    # TRC: Only one channel, since all data would be too much
    #
    if ( defined $measuredData_href->{'time'} ) {
        $time_aref        = $measuredData_href->{'time'};
        $channelData_aref = $measuredData_href->{$channelName};
    }

    # LCT: all measured data can be given
    else {
        ( $channelData_aref, $time_aref ) = EVAL_get_values_and_times_over_time( $measuredData_href, $channelName );
    }

    if ( not defined $channelData_aref ) {
        S_w2log( 4, "Signal $channelName not found in data structure\n" );
        return ( $numOfActualPulses, \%pulses );
    }

    if ( not defined $time_aref or scalar @$time_aref < 2 ) {
        S_w2log( 4, "To less timestamps detected for channel '$channelName', no pulses detected." );
        return ( $numOfActualPulses, \%pulses );
    }

    $time_min = $$time_aref[0]  if ( $time_min =~ /START/i );
    $time_max = $$time_aref[-1] if ( $time_max =~ /END/i );

    #Time_min should be lesser than Time_max
    if ( $time_min >= $time_max ) {
        S_set_error( "\$time_max should be greater than \$time_min", 109 );
        return ( 0, {} );
    }

    my $pulseStarted = 0;

    #go through all the signals and evaluate for pulses between $time_min and $time_max
    for my $timeIndex ( 0 .. $#{$time_aref} ) {

        my $isStartConditionFullfilled = 0;
        my $isEndConditionFullfilled   = 0;
        my $time                       = $$time_aref[$timeIndex];

        next if $time < $time_min;
        last if $time > $time_max;

        #determine whether the signal satisfies the pulse condition & slope
        #rising
        $isStartConditionFullfilled = 1 if ( $slopeType =~ m/rising/ && ( $$channelData_aref[$timeIndex] >= ($voltageLevel) ) );
        $isEndConditionFullfilled = 1 if ( $slopeType =~ m/rising/ && ( $$channelData_aref[$timeIndex] < ( $voltageLevel - $voltageHysteresis ) ) );

        #falling
        $isStartConditionFullfilled = 1 if ( $slopeType =~ m/falling/ && ( $$channelData_aref[$timeIndex] <= ($voltageLevel) ) );
        $isEndConditionFullfilled = 1 if ( $slopeType =~ m/falling/ && ( $$channelData_aref[$timeIndex] > ( $voltageLevel + $voltageHysteresis ) ) );

        if ( $isStartConditionFullfilled and not $pulseStarted ) {

            #if this is the first element that satisfies the slope
            $pulseStartTime = $time;
            $pulseStarted   = 1;
        }
        elsif ( $isEndConditionFullfilled and $pulseStarted ) {

            # consider pulse only if number of collected samples greater than or equal to $minSamplesPerPulse
            if ( scalar(@values) >= $minSamplesPerPulse ) {
                $pulses{ 'pulse' . $numOfActualPulses }{'start'} = $pulseStartTime;
                $pulses{ 'pulse' . $numOfActualPulses }{'end'}   = $time;             # current time stamp

                #get all the values of the pulse and store
                push( @{ $pulses{ 'pulse' . $numOfActualPulses }{'values'} }, @values );
                $numOfActualPulses++;
            }

            $pulseStarted = 0;

            #empty the collected values
            @values = ();
        }

        if ($pulseStarted) {
            push( @values, $$channelData_aref[$timeIndex] );

            # remember time in case this is last sample of this pulse
            $pulseEndTime = $time;
        }

        # next value
        $timeIndex++;
    }

    #check if the pulse was still ongoing at the time of exit of forloop (@values has not been emptied, so condition was still passed)
    if ( $pulseStarted and scalar(@values) >= $minSamplesPerPulse ) {
        $pulses{ 'pulse' . $numOfActualPulses }{'start'} = $pulseStartTime;
        $pulses{ 'pulse' . $numOfActualPulses }{'end'}   = $pulseEndTime;

        #get all the values of the pulse and store
        push( @{ $pulses{ 'pulse' . $numOfActualPulses }{'values'} }, @values );
        $numOfActualPulses++;
    }

    S_w2log( 5, " -> found $numOfActualPulses pulses in the signal $channelName (Threshold = $voltageLevel, Hysteresis = $voltageHysteresis, Slope = '$slopeType', Minimum signal timeIndex = $minSamplesPerPulse)\n" );

    #check if any pulses are found and log into report, if no pulses found
    if ( $numOfActualPulses <= 0 ) {
        S_w2log( 4, "No pulses found between $time_min ms and $time_max ms" );
    }

    return ( $numOfActualPulses, \%pulses );
}

=head2 EVAL_get_occurence


    ($elements, %occurence) = EVAL_get_occurence( \%MEASURE_DATA , $SIGNAL_LABEL,[, $TIME_LOG_START [, $TIME_LOG_END ]] );

    e.g. ($elements, %occurence) = EVAL_get_occurence( $MEASURE_DATA , 'SIG_2' );

counts occurence of every signal value, returns error if $SIGNAL_LABEL not found

calls EVAL_get_values_over_time internally

=cut

sub EVAL_get_occurence
{
    my $MEASURE_DATA   = shift;
    my $SIGNAL_LABEL   = shift;
    my $TIME_LOG_START = shift;
    my $TIME_LOG_END   = shift;
    my %occurence      = ();
    my $element;

    unless ( defined($SIGNAL_LABEL) )
    {
        S_set_error( "! too less parameters ! SYNTAX: (\$elements, \%occurence) = EVAL_get_occurence ( \$MEASURE_DATA , \$SIGNAL_LABEL,[, \$TIME_LOG_START [, \$TIME_LOG_END ]]  )", 110 );
        return ( 0, %occurence );
    }

    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return ( 0, %occurence );
    }

    S_w2log( 5, "EVAL_get_occurence analyzing $SIGNAL_LABEL\n" );

    return ( 1, ( 1 => 1 ) ) if $main::opt_offline;

    my @all_values = EVAL_get_values_over_time( $MEASURE_DATA, $SIGNAL_LABEL, $TIME_LOG_START, $TIME_LOG_END );
    foreach $element (@all_values)
    {
        $occurence{$element}++;
    }

    foreach $element ( sort keys %occurence )
    {
        S_w2log( 5, " -> found $occurence{$element} times value $element \n" );
    }

    return ( scalar(@all_values), %occurence );
}

=head2 EVAL_get_signal_cycletime

   ( $p_min, $p_max, $p_avg ) = EVAL_get_signal_cycletime ( $measure_data_href, $signal_label [, $time_min, $time_max ]);

             t1       t2                       t3   t4               t5
        |                                                                         |
    time_min                                                                   time_max

    $p_min = t4-t3,  $p_max = t3-t2

    Function extracts the minimum, maximum and average period of a signal between time_min and time_max.
    The algorithm compares the differences between the time stamps of the signal.

    Function returns (0,0,0) if no period calculation possible or in offline mode

=cut

sub EVAL_get_signal_cycletime {
    my @args = @_;
    return unless S_checkFunctionArguments( 'EVAL_get_signal_cycletime ($measure_data_href, $signal_label [,$time_min, $time_max ])', @args );

    my $measure_data_href = shift @args;
    my $signal_label      = shift @args;
    my $time_min          = shift @args;
    my $time_max          = shift @args;

    my ( $p_min, $p_max, $p_min_txt, $p_max_txt, $timestamp_previous, $edge_counter, $time_diff, $signal, $sum_for_average, $avg_time, );

    $p_max = $timestamp_previous = 0;
    $p_min = 99999999;
    $sum_for_average = 0;
    $avg_time        = 0;
    $edge_counter    = 0;

    return ( 0, 0, 0 ) if $main::opt_offline;

    # apply label mapping if defined for current label in project defaults
    if ( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{$signal_label} ) {
        $signal_label = $main::ProjectDefaults->{'LABEL_MAPPING'}{$signal_label};
    }

    $signal = $signal_label;

    foreach my $time_current ( sort { $a <=> $b } keys %$measure_data_href ) {
        next if defined $time_min and $time_current < $time_min;
        last if defined $time_max and $time_current > $time_max;
        if ( defined $measure_data_href->{$time_current}{$signal} ) {

            if ( $timestamp_previous > 0 ) {
                $time_diff = $time_current - $timestamp_previous;
                if ( $time_diff < $p_min ) {
                    $p_min     = $time_diff;
                    $p_min_txt = "[$timestamp_previous | $time_current]";
                    S_w2log( 4, " EVAL_get_signal_cycletime : new min $p_min $p_min_txt\n" );
                }
                if ( $time_diff > $p_max ) {
                    $p_max     = $time_diff;
                    $p_max_txt = "[$timestamp_previous | $time_current]";
                    S_w2log( 4, " EVAL_get_signal_cycletime : new max $p_max $p_max_txt\n" );
                }
            }

            $sum_for_average += $time_diff;

            $edge_counter++;

            $timestamp_previous = $time_current;

        }

    }    # end foreach

    if ( $edge_counter == 0 ) {
        S_w2log( 2, " EVAL_get_signal_cycletime : no samples detected \n" );
        return ( 0, 0, 0 );
    }

    if ( $edge_counter < 2 ) {
        S_w2log( 2, " EVAL_get_signal_cycletime : Too less samples selected to get proper periods \n" );
        return ( 0, 0, 0 );
    }

    $avg_time = $sum_for_average / ( $edge_counter - 1 );

    S_w2log( 2, " EVAL_get_signal_cycletime : $signal period between $p_min $p_min_txt and $p_max $p_max_txt, average period is $avg_time\n" );
    return ( $p_min, $p_max, $avg_time );

}

=head2 EVAL_get_time_multi_condition

   $TIMES_AREF = EVAL_get_time_multi_condition ( $MEASURE_DATA_HREF , $MULTI_CONDITION_HREF [, $TIME_LOG_START [, $TIME_LOG_END ]] );

   $MEASURE_DATA_HREF : Signal reference

   $MULTI_CONDITION_HREF : HASH REF with CONDITION_LABELS (free for your use) and their attributes

       SIGNAL_LABEL  : signal to be checked in MEASURE_DATA_HREF
       OPERATOR      : == != > <
       COMPARE_VALUE : reference value for evaluation

        e.g.

   $MULTI_CONDITION_HREF = {
                  'COND_LABEL_1' => { 'SIGNAL_LABEL' => SIG_1 , 'OPERATOR' => operator_1 , 'COMPARE_VALUE' => compare_1 }
                  'COND_LABEL_2' => { 'SIGNAL_LABEL' => sig_2 , 'OPERATOR' => operator_2 , 'COMPARE_VALUE' => compare_2 }
              }

   $TIME_LOG_START: start time in MEASURE_DATA_HREF
   $TIME_LOG_END  : stop time in MEASURE_DATA_HREF

   example for
   $MEASURE_DATA_HREF = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   $TIMES_AREF  : returned by this function

   Checks if the conditions defined by $MULTI_CONDITION_HREF are fulfilled in the measurement hash tree $MEASURE_DATA_HREF and returns all times (as list) at which
   the conditions were fulfilled at the same time. This works also for CAN traces where "same" means: accurate within the message cycle time.
   Returns an empty list if the condition was never fulfilled.

   Example:

    $TIMES_AREF = EVAL_get_time_multi_condition( $MEASURE_DATA_HREF , {'COND_LABEL_1' => { 'SIGNAL_LABEL' => "Ubatt_record" , 'OPERATOR' => ">" , 'COMPARE_VALUE' => 7 }} );

=cut

sub EVAL_get_time_multi_condition
{
    my $MEASURE_DATA_HREF    = shift;
    my $MULTI_CONDITION_HREF = shift;
    my $TIME_LOG_START       = shift;
    my $TIME_LOG_END         = shift;

    my ( $FOUND_TIME, $SIGNAL_LABEL, $OPERATOR, $COMPARE_VALUE ) = undef;
    my ( $detected_value, $used_signal, $used_operator, $found_flag, $all_condition_checks, $all_condition_true );
    my ($TIMES_AREF);

    S_w2log( 1, "EVAL_get_time_multi_condition \n" );

    unless ( defined $MULTI_CONDITION_HREF )
    {
        S_set_error( "!too less parameters! SYNTAX: TIMES_AREF = EVAL_get_time_multi_condition(MEASURE_DATA_HREF, MULTI_CONDITION_HREF[, TIME_LOG_START [, TIME_LOG_END ]] )", 110 );
        return [];
    }

    unless ( ref $MULTI_CONDITION_HREF eq "HASH" )
    {
        S_set_error( " MULTI_CONDITION_HREF is not an Hash reference", 114 );
        return [];
    }

    if ( defined $MEASURE_DATA_HREF && ref($MEASURE_DATA_HREF) ne "HASH" )
    {
        S_set_error( " MEASURE_DATA_HREF is not an Hash reference", 114 );
        return [];
    }

    foreach my $condition_label ( keys %$MULTI_CONDITION_HREF )
    {

        $SIGNAL_LABEL  = $MULTI_CONDITION_HREF->{$condition_label}{'SIGNAL_LABEL'};
        $OPERATOR      = $MULTI_CONDITION_HREF->{$condition_label}{'OPERATOR'};
        $COMPARE_VALUE = $MULTI_CONDITION_HREF->{$condition_label}{'COMPARE_VALUE'};

        S_w2log( 4, " EVAL_get_time_multi_condition: $condition_label \n" );
        S_w2log( 4, "   --> SIGNAL_LABEL : $SIGNAL_LABEL \n" );
        S_w2log( 4, "   --> OPERATOR : $OPERATOR \n" );
        S_w2log( 4, "   --> COMPARE VALUE : $COMPARE_VALUE \n" );

      PARA_CHECK:
        {
            last PARA_CHECK if defined $OPERATOR && grep { /^$OPERATOR$/i } 'MIN', 'MAX';
            last PARA_CHECK if defined $COMPARE_VALUE;
            S_set_error( " SYNTAX: TIME = TIMES_AREF = EVAL_get_time_multi_condition(MEASURE_DATA_HREF, MULTI_CONDITION_HREF[, TIME_LOG_START [, TIME_LOG_END ]])", 114 );
            return [];
        }

        unless ( grep { /^$OPERATOR$/i } '==', '!=', '<', '>', 'MIN', 'MAX' )
        {
            S_set_error( "unknown operator: $OPERATOR", 114 );
            return [];
        }
    }

    if ( ( defined $TIME_LOG_END ) && ( $TIME_LOG_START >= $TIME_LOG_END ) )
    {
        S_set_error( "TIME_MIN ($TIME_LOG_START) >= TIME_MAX ($TIME_LOG_END)", 109 );
        return [];
    }

    return [] if $main::opt_offline;

    # check all conditions for all timestamps
    foreach my $time_stamp ( sort { $a <=> $b } keys %$MEASURE_DATA_HREF )
    {
        next if ( defined $TIME_LOG_START ) && ( $time_stamp < $TIME_LOG_START );
        last if ( defined $TIME_LOG_END )   && ( $time_stamp > $TIME_LOG_END );
        $all_condition_true = 1;
        foreach my $condition_label ( keys %$MULTI_CONDITION_HREF )
        {

            $SIGNAL_LABEL  = $MULTI_CONDITION_HREF->{$condition_label}{'SIGNAL_LABEL'};
            $OPERATOR      = $MULTI_CONDITION_HREF->{$condition_label}{'OPERATOR'};
            $COMPARE_VALUE = $MULTI_CONDITION_HREF->{$condition_label}{'COMPARE_VALUE'};

            if ( defined $MEASURE_DATA_HREF->{$time_stamp}{$SIGNAL_LABEL} )
            {

                $detected_value = $MEASURE_DATA_HREF->{$time_stamp}{$SIGNAL_LABEL};

                #S_w2log(1, "EVAL_get_time_multi_condition detected_value :: $SIGNAL_LABEL - $detected_value \n");

                if ( compare_two_values( $detected_value, $OPERATOR, $COMPARE_VALUE ) )
                {
                    $all_condition_checks->{$condition_label} = 1;
                }
                else
                {
                    $all_condition_checks->{$condition_label} = 0;
                    $all_condition_true = 0;
                }
            }
            elsif ( $all_condition_checks->{$condition_label} == 0 )
            {
                $all_condition_true = 0;
            }
        }

        if ($all_condition_true)
        {
            push( @$TIMES_AREF, $time_stamp );
        }
    }

    S_w2log( 3, " EVAL_get_time_multi_condition: First timestamp with conditions fulfilled: $$TIMES_AREF[0] \n\n" );

    return ($TIMES_AREF);
}

=head2 EVAL_get_time_when

    $MEASURE_TIME = EVAL_get_time_when ( \%MEASURE_DATA , $SIGNAL_LABEL , $OPERATOR [, $COMPARE_VALUE [, $TIME_LOG_START [, $TIME_LOG_END ]]] );

   \%MEASURE_DATA : Signal reference , see example below
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))
   $OPERATOR      : == != >= <= > < MIN MAX MASK
   $COMPARE_VALUE : reference value for evaluation (not needed for OPERATOR MIN and MAX)
   $TIME_LOG_START: start time in MEASURE_DATA
   $TIME_LOG_END  : stop time in MEASURE_DATA

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   $MEASURE_TIME  : returned by this function

Checks if a condition defined by $SIGNAL_LABEL, $OPERATOR and $COMPARE_VALUE is fulfilled in
the measurement hash tree \%MEASURE_DATA and returns the time when the condition was first fulfilled.
Returns -1 if the condition was never fulfilled.

Example:

    $time = EVAL_get_time_when( $sigref , "Ubatt_record" , ">" , 7 );
    $time = EVAL_get_time_when( $sigref , "signal" , "MASK" , '0b1111xx00' );

offline_return : -2

calls EVAL_get_values_over_time internally for MIN or MAX

=cut

sub EVAL_get_time_when
{
    my $MEASURE_DATA   = shift;
    my $SIGNAL_LABEL   = shift;
    my $OPERATOR       = shift;
    my $COMPARE_VALUE  = shift;
    my $TIME_LOG_START = shift;
    my $TIME_LOG_END   = shift;

    my ( $FOUND_TIME, $time_stamp, $MAXtime_stamp, $MINtime_stamp, $used_signal, $used_operator, $found_flag, @all_values_sorted, @time_stamps, );

    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return 0;
    }

  PARA_CHECK:
    {
        last PARA_CHECK if defined $OPERATOR and grep /^$OPERATOR$/i, 'MIN', 'MAX';
        last PARA_CHECK if defined $COMPARE_VALUE;
        S_set_error( " SYNTAX: TIME = EVAL_get_time_when ( MEASURE_DATA , SIGNAL_LABEL , OPERATOR [, COMPARE_VALUE [, TIME_LOG_START [, TIME_LOG_END ]]] ); )", 110 );
        return 0;
    }

    unless ( grep /^$OPERATOR$/i, '==', '!=', '>=', '<=', '<', '>', 'MIN', 'MAX', 'MASK' )
    {
        S_set_error( "unknown operator: $OPERATOR", 114 );
        return 0;
    }

    return -2 if $main::opt_offline;

    if ( $MEASURE_DATA == 1 )
    {
        S_w2log( 5, "EVAL_get_time_when: No Measurement enabled in ProjectDefaults->{'MEASUREMENT'}->{'use_measurement'}\n" );
        return;
    }

    # apply label mapping if defined for current label in project defaults
    if ( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL} )
    {
        $SIGNAL_LABEL = $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL};
    }

    $used_signal = $SIGNAL_LABEL;

    # check if $used_signal exists in data hash
    $found_flag    = 0;
    @time_stamps   = sort { $a <=> $b } keys %$MEASURE_DATA;
    $MINtime_stamp = $time_stamps[0];
    $MAXtime_stamp = $time_stamps[-1];
    if ( defined $TIME_LOG_START && $TIME_LOG_START > $MAXtime_stamp )
    {
        S_set_error( "TIME_LOG_START $TIME_LOG_START out of range: time( $MINtime_stamp , $MAXtime_stamp )", 114 );
        return -1;
    }
    if ( defined $TIME_LOG_END && $TIME_LOG_END < $MINtime_stamp )
    {
        S_set_error( "TIME_LOG_END $TIME_LOG_END out of range: time( $MINtime_stamp , $MAXtime_stamp )", 114 );
        return -1;
    }

    foreach $time_stamp (@time_stamps)
    {
        if ( defined $MEASURE_DATA->{$time_stamp}{$used_signal} ) { $found_flag = 1; last; }
        $MAXtime_stamp = $time_stamp;
    }
    unless ($found_flag) { S_set_error( "signal $used_signal not found in given data reference", 0 ); return -1; }

    if ( grep /^$OPERATOR$/i, 'MIN', 'MAX' )
    {
        @all_values_sorted = sort { $a <=> $b } EVAL_get_values_over_time( $MEASURE_DATA, $used_signal, $TIME_LOG_START, $TIME_LOG_END );
        $COMPARE_VALUE = shift @all_values_sorted if $OPERATOR =~ /MIN/i;
        $COMPARE_VALUE = pop @all_values_sorted   if $OPERATOR =~ /MAX/i;
    }

    # loop through time in signals hash and check if condition defined by
    # $used_signal, $OPERATOR and $COMPARE_VALUE is fulfilled
    $used_operator = $OPERATOR;
    $used_operator = '==' if grep /^$OPERATOR$/i, 'MIN', 'MAX';

    foreach $time_stamp (@time_stamps)
    {
        next unless defined $MEASURE_DATA->{$time_stamp}{$used_signal};
        next if ( defined $TIME_LOG_START ) && ( $time_stamp < $TIME_LOG_START );
        last if ( defined $TIME_LOG_END )   && ( $time_stamp > $TIME_LOG_END );

        #    S_w2rep( "compare_two_values( ".$MEASURE_DATA->{$time_stamp}->{$used_signal}." , $used_operator , $COMPARE_VALUE )  $time_stamp S $TIME_LOG_START E $TIME_LOG_END\n" );

        last if ( compare_two_values( $MEASURE_DATA->{$time_stamp}{$used_signal}, $used_operator, $COMPARE_VALUE )
                  and ( ( $FOUND_TIME = $time_stamp ) or 1 ) );    # 'or 1' is added for the exception ($FOUND_TIME = 0)
        undef $FOUND_TIME;
    }

    unless ( defined $FOUND_TIME )
    {
        S_w2log( 5, " EVAL_get_time_when : condition $SIGNAL_LABEL $OPERATOR $COMPARE_VALUE not fulfilled in measurement\n" );
        return -1;
    }

    S_w2log( 3, " EVAL_get_time_when : condition $SIGNAL_LABEL $OPERATOR $COMPARE_VALUE fulfilled at time[$FOUND_TIME] (between: $TIME_LOG_START .. $TIME_LOG_END )\n" );
    return $FOUND_TIME;
}

=head2 EVAL_get_value_around_time

    ( $MEASURE_VALUE , [$ALTERNATE_TIMESTAMP] ) = EVAL_get_value_around_time ( \%MEASURE_DATA , $CHECK_TIME , $SIGNAL_LABEL );

Returns out of the measurement hash tree \%MEASURE_DATA (created by EA_trace_get_dataref or CA_trace_get_dataref )
the $MEASURE_VALUE of the given $SIGNAL_LABEL at one time $CHECK_TIME.
In case that no signal value available exactly at this time, alternatively the nearest time will be returned additionally

   $CHECK_TIME    : returned by function or directly the keys TIME_x out of MEASURE_DATA, if given as "LAST" will check for last appearence
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = VAL_1_1  , SIG_2 = VAL_1_2 } ,
                  TIME_2 => {                                        SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = VAL_3_1  , SIG_2 = VAL_3_2 } ,
                  TIME_4 => {                                        SIG_3 => VAL_4_3  } ,
                };


   EXAMPLE:

   Trace and corresponding \%DATA hash looks like this :

   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = VAL_1_1  , SIG_2 = VAL_1_2 } ,
                  TIME_2 => {                                        SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = VAL_3_1  , SIG_2 = VAL_3_2 } ,
                  TIME_4 => {                                        SIG_3 => VAL_4_3  } ,
                };

   ( VAL_1_1 )          = EVAL_get_value_around_time( $MEASURE_DATA , TIME_1 , SIG_1 );  # return val_1_1 from sig_1 at TIME_1 , value at exact time found
   ( VAL_1_1 , TIME_1 ) = EVAL_get_value_around_time( $MEASURE_DATA , TIME_2 , SIG_1 );  # return val_1_1 from sig_1 at TIME_1 , because it's the previous value around TIME_1 (before TIME_2)
   ( VAL_2_3 , TIME_2 ) = EVAL_get_value_around_time( $MEASURE_DATA , TIME_1 , SIG_3 );  # return val_2_3 from sig_3 at TIME_1 , because it's the 1st available value after TIME_1
   ( VAL_2_3 )          = EVAL_get_value_around_time( $MEASURE_DATA , TIME_2 , SIG_3 );  # return val_2_3 from sig_3 at TIME_2 , value at exact time found
   ( VAL_3_2 )          = EVAL_get_value_around_time( $MEASURE_DATA , TIME_3 , SIG_2 );  # return val_3_2 from sig_2 at time_3 , value at exact time found
   ( VAL_2_3 , TIME_3 ) = EVAL_get_value_around_time( $MEASURE_DATA , TIME_4 , SIG_2 );  # return val_2_3 from sig_2 at time_3 , because it's the previous value around time_3 (before time_4)

offline_return : -1

=cut

sub EVAL_get_value_around_time
{
    my ( $MEASURE_DATA, $CHECK_TIME, $SIGNAL_LABEL, ) = @_;

    my ( $RETURN_VALUE, $used_signal, $time_used, $FOUND_TIME, );

    unless ( defined($SIGNAL_LABEL) )
    {
        S_set_error( "! too less parameters ! SYNTAX: ( VALUE , [ALTERNATE_TIMESTAMP] ) = EVAL_get_value_around_time ( SIGNALS , TIME , given_signal )", 110 );
        return -1;
    }
    if ( ref($MEASURE_DATA) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return -1;
    }

    return -1 if $main::opt_offline;

    if ( uc($CHECK_TIME) eq "LAST" )
    {
        $CHECK_TIME = ( sort { $a <=> $b } keys %$MEASURE_DATA )[-1];
        S_w2log( 5, " LAST time = $CHECK_TIME\n" );
    }

    ## ( just for EA_trace )
    if ( $MEASURE_DATA == 1 )
    {
        S_w2log( 5, " No Measurement enabled in ProjectDefaults->{'MEASUREMENT'}->{'use_measurement'}\n" );
        return;
    }

    # apply label mapping if defined for current label in project defaults
    if ( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL} )
    {
        $SIGNAL_LABEL = $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL};
    }

    $used_signal = $SIGNAL_LABEL;

    # get value of actual signal at given time
    if ( defined $MEASURE_DATA->{$CHECK_TIME} and defined $MEASURE_DATA->{$CHECK_TIME}->{$used_signal} )
    {
        $RETURN_VALUE = $MEASURE_DATA->{$CHECK_TIME}->{$used_signal};
    }

    ## return the value if available at given timestamp
    if ( defined $RETURN_VALUE )
    {
        S_w2log( 2, " EVAL_get_value_around_time: found $used_signal = $RETURN_VALUE exact at time[$CHECK_TIME]\n" );
        return ($RETURN_VALUE);
    }

    S_w2log( 5, " checking $used_signal\n" );

    # loop through time in signals hash and look for time_given
    foreach $time_used ( sort { $a <=> $b } keys %$MEASURE_DATA )
    {
        next unless defined $MEASURE_DATA->{$time_used}->{$used_signal};
        $RETURN_VALUE = $MEASURE_DATA->{$time_used}->{$used_signal};
        $FOUND_TIME   = $time_used;
        next if ( $time_used < $CHECK_TIME );
        last if ( $time_used >= $CHECK_TIME );
    }

    ## return the value if available at used timestamp
    if ( defined $RETURN_VALUE )
    {
        S_w2log( 2, " EVAL_get_value_around_time: found $used_signal = $RETURN_VALUE at time_used[$FOUND_TIME] (nearest to: given_time[$CHECK_TIME])\n" );

        # make the alternative time ($FOUND_TIME) as undef, if the $CHECK_TIME & $FOUND_TIME are ( precision 10^-8 ) equal
        # sometimes, the time format in hash might be different (e.g., $FOUND_TIME = 000224.000, $CHECK_TIME = 224)
        $FOUND_TIME = undef if ( compare_two_values( $FOUND_TIME, "==", $CHECK_TIME ) );

        return ( $RETURN_VALUE, $FOUND_TIME );
    }

    S_set_error( "signal $used_signal not found in given data reference", 0 );
    return;
}

=head2 EVAL_get_values_at_time

    @VALUES = EVAL_get_values_at_time ( \%DATA , $CHECK_TIME , @SIGNAL_LABELS );

Returns out of the measurement hash tree \%DATA (created by EA_trace_get_dataref or CA_trace_get_dataref )
the values of the signals given in the list @LABELS at exact one timestamp $TIME.

In case that no value was found the string 'NO_VALUE_FOUND' will be returned

In case that no value at the specific time was found but before or after this a value is available then the string 'NO_VALUE_FOUND_AT_TIME' will be returned


   $CHECK_TIME    : returned by function or directly the keys TIME_x out of MEASURE_DATA
   @SIGNAL_LABELS : signals to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))

   EXAMPLE:

   Trace and corresponding \%DATA hash looks like this :

   $DATA_HASH = {
                  TIME_1 => { SIG_1 = VAL_1_1  , SIG_2 = VAL_1_2 } ,
                  TIME_2 => {                                        SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = VAL_3_1  , SIG_2 = VAL_3_2 } ,
                  TIME_4 => {                                        SIG_3 => VAL_4_3  } ,
                };

   EXAMPLE FUNCTION CALLS:

   (  VAL_1_1 ,
      VAL_1_2 )                = EVAL_get_values_at_time( $DATA_HASH , TIME_1 , SIG_1 , SIG_2 );

   (  VAL_1_1 ,
      VAL_1_2 ,
      NO_VALUE_FOUND_AT_TIME ) = EVAL_get_values_at_time( $DATA_HASH , TIME_1 , SIG_1 , SIG_2 , SIG_3 );

   (  VAL_1_1 ,
      VAL_1_2 ,
      NO_VALUE_FOUND_AT_TIME,
      NO_VALUE_FOUND         ) = EVAL_get_values_at_time( $DATA_HASH , TIME_1 , SIG_1 , SIG_2 , SIG_3 , SIG_4 );

   (  NO_VALUE_FOUND_AT_TIME ,
      NO_VALUE_FOUND_AT_TIME ,
      VAL_4_3 ,
      NO_VALUE_FOUND         ) = EVAL_get_values_at_time( $DATA_HASH , TIME_2 , SIG_1 , SIG_2 , SIG_3 , SIG_4 );


   in case of returning NO_VALUE_FOUND_AT_TIME the function EVAL_get_value_around_time() should be called, e.g.

   ( VAL_1_1 , TIME_1 ) = EVAL_get_value_around_time( $DATA_HASH , TIME_2 , SIG_1 );  # return val_1_1 from sig_1 at TIME_1 , because it's the previous value around TIME_1 (before TIME_2)

offline_return : ( 0 )

=cut

sub EVAL_get_values_at_time
{
    my $signals_ref = shift;
    my $time_given  = shift;
    my @labels      = @_;
    my @offline_ret = (0);

    my ( @values, $label, $value, $alternate_timestamp, );

    unless ( defined( $labels[0] ) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VALUES = EVAL_get_values_at_time ( SIGNALS , TIME , LABELS )", 110 );
        return @offline_ret;
    }
    if ( ref($signals_ref) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return @offline_ret;
    }

    return @offline_ret if $main::opt_offline;

    # loop over all labels in given label list
    foreach $label (@labels)
    {
        ( $value, $alternate_timestamp ) = EVAL_get_value_around_time( $signals_ref, $time_given, $label );
        unless ( defined $value )
        {
            S_set_error( " $label : no value found (not before and not after time[$time_given])", 0 );
            $value = "NO_VALUE_FOUND";
        }
        if ( defined $alternate_timestamp )
        {
            S_set_error( " found $label = $value at time[$alternate_timestamp] , but not at exactly time[$time_given]", 0 );
            $value = "NO_VALUE_FOUND_AT_TIME";
        }
        push( @values, $value );
        undef $value;
        undef $alternate_timestamp;
    }

    return @values;
}

=head2 EVAL_get_values_and_times_over_time

    ($VALUES_AREF, $TIMES_AREF) = EVAL_get_values_and_times_over_time ( \%MEASURE_DATA , $SIGNAL_LABEL [, $TIME_LOG_START [, $TIME_LOG_END ]] );

   \%MEASURE_DATA : Signal reference , see example below
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))
   $TIME_LOG_START: start time in MEASURE_DATA
   $TIME_LOG_END  : stop time in MEASURE_DATA

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

Returns the values & times at which the values occur, out of the measurement hash tree \%MEASURE_DATA (created by EA_trace_get_dataref or CA_trace_get_dataref ).

$TIME_LOG_START and $TIME_LOG_END determine the time range for the data. If neither of them is given, then the time range is the full time range of the data hash.

Example:

    ($VALUES_AREF, $TIMES_AREF) = EVAL_get_values_and_times_over_time ( $MEASURE_DATA , 'SIG_1'); # $VALUES_AREF = [0, 0, 0, 0], $TIMES_AREF = [TIME_1, TIME_3, TIME_5, TIME_7]

offline_return : ([0], [0])

returns empty list if signal is not found

=cut

sub EVAL_get_values_and_times_over_time
{

    my $signals_ref    = shift;
    my $SIGNAL_LABEL   = shift;
    my $TIME_LOG_START = shift;
    my $TIME_LOG_END   = shift;
    my @offline_ret    = ( [0], [0] );

    my ( $time, $first_time, $last_time, $used_signal, @values, @timearray, $found_flag, );

    unless ( defined($SIGNAL_LABEL) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VALUES = EVAL_get_values_and_times_over_time ( DATA , LABEL [, TIME_MIN [, TIME_MAX ]] )", 110 );
        return @offline_ret;
    }
    if ( ref($signals_ref) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return @offline_ret;
    }

    if ( ( defined $TIME_LOG_END ) && ( $TIME_LOG_START >= $TIME_LOG_END ) )
    {
        S_set_error( "TIME_MIN ($TIME_LOG_START) >= TIME_MAX ($TIME_LOG_END)", 109 );
        return @offline_ret;
    }

    return @offline_ret if $main::opt_offline;

    # apply label mapping if defined for current label in project defaults
    if ( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL} )
    {
        $SIGNAL_LABEL = $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL};
    }

    $used_signal = $SIGNAL_LABEL;

    # check if $used_signal exists in data hash
    $found_flag = 0;
    foreach $time ( sort { $a <=> $b } keys %$signals_ref )
    {
        if ( defined $signals_ref->{$time}{$used_signal} ) { $found_flag = 1; last; }
    }
    unless ($found_flag) { S_w2log( 5, "signal $used_signal not found in given data reference"); return (); }

    # loop through time in signals hash
    foreach $time ( sort { $a <=> $b } keys %$signals_ref )
    {
        next unless defined $signals_ref->{$time}->{$used_signal};
        next if ( ( defined $TIME_LOG_START ) && ( $time < $TIME_LOG_START ) );
        last if ( ( defined $TIME_LOG_END )   && ( $time > $TIME_LOG_END ) );
        $first_time = $time unless defined $first_time;
        push( @values,    $signals_ref->{$time}->{$used_signal} );
        push( @timearray, $time );
        $last_time = $time;
    }

    my $nbr_of_values = @values;
    S_w2log( 5, "EVAL_get_values_and_times_over_time : return $nbr_of_values values of '$used_signal' (between: $first_time .. $last_time ) \n" );
    return ( \@values, \@timearray );

}

=head2 EVAL_get_values_over_time

    @VALUES = EVAL_get_values_over_time ( \%MEASURE_DATA , $SIGNAL_LABEL [, $TIME_LOG_START [, $TIME_LOG_END ]] );

   \%MEASURE_DATA : Signal reference , see example below
   $SIGNAL_LABEL  : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))
   $TIME_LOG_START: start time in MEASURE_DATA
   $TIME_LOG_END  : stop time in MEASURE_DATA

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

Returns the values out of the measurement hash tree \%MEASURE_DATA (created by EA_trace_get_dataref or CA_trace_get_dataref )

$TIME_LOG_START and $TIME_LOG_END determine the time range for the data. If neither of them is given, then the time range is the full time range of the data hash.

offline_return : ( 0 )

returns empty list and warns if signal is not found

=cut

sub EVAL_get_values_over_time
{

    my $signals_ref    = shift;
    my $SIGNAL_LABEL   = shift;
    my $TIME_LOG_START = shift;
    my $TIME_LOG_END   = shift;
    my @offline_ret    = (0);

    my ( $time, $first_time, $last_time, $used_signal, @values, $found_flag, );

    unless ( defined($SIGNAL_LABEL) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VALUES = EVAL_get_values_over_time ( DATA , LABEL [, TIME_MIN [, TIME_MAX ]] )", 110 );
        return @offline_ret;
    }
    if ( ref($signals_ref) ne "HASH" )
    {
        S_set_error( "First parameter (\%MEASURE_DATA) is not a hash reference", 114 );
        return @offline_ret;
    }

    if ( ( defined $TIME_LOG_END ) && ( $TIME_LOG_START >= $TIME_LOG_END ) )
    {
        S_set_error( "TIME_MIN ($TIME_LOG_START) >= TIME_MAX ($TIME_LOG_END)", 109 );
        return @offline_ret;
    }

    return @offline_ret if $main::opt_offline;

    # apply label mapping if defined for current label in project defaults
    if ( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL} )
    {
        $SIGNAL_LABEL = $main::ProjectDefaults->{'LABEL_MAPPING'}{$SIGNAL_LABEL};
    }

    $used_signal = $SIGNAL_LABEL;

    # check if $used_signal exists in data hash
    $found_flag = 0;
    foreach $time ( sort { $a <=> $b } keys %$signals_ref )
    {
        if ( defined $signals_ref->{$time}{$used_signal} ) { $found_flag = 1; last; }
    }
    unless ($found_flag) { S_set_error( "signal $used_signal not found in given data reference", 0 ); return (); }

    # loop through time in signals hash
    foreach $time ( sort { $a <=> $b } keys %$signals_ref )
    {
        next unless defined $signals_ref->{$time}->{$used_signal};
        next if ( ( defined $TIME_LOG_START ) && ( $time < $TIME_LOG_START ) );
        last if ( ( defined $TIME_LOG_END )   && ( $time > $TIME_LOG_END ) );
        $first_time = $time unless defined $first_time;
        push( @values, $signals_ref->{$time}->{$used_signal} );
        $last_time = $time;
    }

    my $nbr_of_values = @values;
    S_w2log( 5, "EVAL_get_values_over_time : return $nbr_of_values values of '$used_signal' (between: $first_time .. $last_time ) \n" );
    return @values;

}

=head2 EVAL_importUNV

   $data_HoH = EVAL_importUNV( $file_name [, $signalNames_aref, $timeinseconds]);

imports UNIVIEW file. returns structure created from uniview file to evaluate with EVAL functions.

    e.g. would create from file

    TIME;SIG_1;SIG_2;SIG_3;
    s;-;-;-;
    0.1;0;0;0;
    0.2;0;0;32;
    0.3;1;0;32;
    0.4;1;0;34;
    1.5;2;1;34;
    1.6;2;1;36;
    1.7;3;0;36;

    the following data:

    $MEASURE_DATA = {
                  100 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  200 => {                             'SIG_3' => 32  } ,
                  300 => { 'SIG_1' => 1  , 'SIG_2' => 0 } ,
                  400 => {                             'SIG_3' => 34  } ,
                  1500 => { 'SIG_1' => 2  , 'SIG_2' => 1 } ,
                  1600 => {                             'SIG_3' => 36  } ,
                  1700 => { 'SIG_1' => 3  , 'SIG_2' => 0 } ,
                };

Optionally a list of signal names \@signalNames_aref can be given. In that case only the signals that are in the given list of signal names
are written to the output hash.

If $timeinseconds is set, time in datahash will be in seconds. Ex:

   $MEASURE_DATA = {
                  0.1 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  0.2 => {                             'SIG_3' => 32  } ,
                  0.3 => { 'SIG_1' => 1  , 'SIG_2' => 0 } ,
                  0.4 => {                             'SIG_3' => 34  } ,
                  1.5 => { 'SIG_1' => 2  , 'SIG_2' => 1 } ,
                  1.6 => {                             'SIG_3' => 36  } ,
                  1.7 => { 'SIG_1' => 3  , 'SIG_2' => 0 } ,
                };
   

offline_return : { 0 => { 'dummy' => 0 } }

=cut

sub EVAL_importUNV
{
    my $filename         = shift;
    my $signalNames_aref = shift;
    my $timeinseconds    = shift;
    my $data_HoH         = {};
    my ( $line, @names, @values, $count, $time );
    my $data_HoH_dummy;
    $data_HoH_dummy->{0}->{'dummy'} = 0;

    unless ( defined($filename) )
    {
        S_set_error( "! too less parameters ! SYNTAX: data_HoH = EVAL_importUNV( tracefilename )", 110 );
        return $data_HoH_dummy;
    }

    S_w2log( 5, "EVAL_importUNV( $filename )\n" );

    return $data_HoH_dummy if $main::opt_offline;

    unless ( -f $filename )
    {
        S_set_error( "tracefilename $filename not found", 1 );
        return $data_HoH_dummy;
    }

    @names = ();

    unless ( open( IN, "<$filename" ) )
    {
        S_set_error( "could not read $filename", 1 );
        return $data_HoH_dummy;
    }
    my @lines = <IN>;
    close(IN);

    $line = shift @lines;
    @names = split( /;/, $line );
    shift(@names);
    $line = shift @lines;

    foreach my $currentLine (@lines)
    {
        @values = split( /;/, $currentLine );
        $time   = shift(@values);
        $time   = sprintf( "%010.3f", ( $time * 1000 ) ) unless ($timeinseconds); #multipy time from unv by 1000, and represent in millisecond
        for ( $count = 0 ; $count < scalar(@names) - 1 ; $count++ )
        {
            #  put values into the output hash if the second function argument is not given or if the current signal name is in the list of signals given as second function argument
            if ( not defined $signalNames_aref or grep( { $names[$count] eq $_ } @{$signalNames_aref} ) )
            {
                $data_HoH->{$time}->{ $names[$count] } = $values[$count];
            }
        }
    }

    S_w2log(3, "EVAL_importUNV: INFO: highest imported time = $time\n");

    return ($data_HoH);

}

=head2 EVAL_merge_sync

   $data_HoH = EVAL_merge_sync( \%MEASURE_DATA1, \%MEASURE_DATA2 [, $synctime1, $synctime2 ] );

merges two data stuctures and snychronizes timestamps. offset for data2 will be calculated from synctimes ($synctime1 - $synctime2).
existing value1 will be overwritten if same sginal in data2

    e.g. $data_HoH = EVAL_merge_sync( \%MEASURE_DATA1, \%MEASURE_DATA2 , 0.2, 0.1 );
       . would create from data

    $MEASURE_DATA1 = {
                  0.1 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  0.2 => {                             'SIG_3' => 32  } ,
                  0.3 => { 'SIG_1' => 1  , 'SIG_2' => 0 } ,
                  0.4 => {                             'SIG_3' => 34  } ,
                  1.5 => { 'SIG_1' => 2  , 'SIG_2' => 1 } ,
                  1.6 => {                             'SIG_3' => 36  } ,
                  1.7 => { 'SIG_1' => 3  , 'SIG_2' => 0 } ,
                };

    $MEASURE_DATA2 = {
                  0.1 =>  { 'SIG_2' => 100 } ,
                  0.25 => {                             'SIG_B' => 332  } ,
                  0.3 =>  { 'SIG_1' => 110  , 'SIG_2' => 100 } ,
                  1.4 =>  {                             'SIG_2' => 334  } ,
                };

    this data:
    $data_HoH = {
                  0.1 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                  0.2 => { 'SIG_2' => 100,                'SIG_3' => 32  } ,    #merge 1+2
                  0.3 => { 'SIG_1' => 1  , 'SIG_2' => 0 } ,
                  0.35 => {                             'SIG_B' => 332  } ,     #add 2
                  0.4 => {  'SIG_1' => 110  , 'SIG_2' => 100, SIG_3' => 34  } ,
                  1.5 => { 'SIG_1' => 2  , 'SIG_2' => 334 } ,                   #overwritte 1
                  1.6 => {                             'SIG_3' => 36  } ,
                  1.7 => { 'SIG_1' => 3  , 'SIG_2' => 0 } ,
                };

offline_return : { 0 => { 'dummy' => 0 } }

=cut

sub EVAL_merge_sync
{
    my $MEASURE_DATA1 = shift;
    my $MEASURE_DATA2 = shift;
    my $synctime1     = shift;
    my $synctime2     = shift;
    my $data_HoH      = {};
    my ( $time, $signal, $offset );
    my $data_HoH_dummy;
    $data_HoH_dummy->{0}->{'dummy'} = 0;

    $synctime1 = 0 unless ( defined $synctime1 );
    $synctime2 = 0 unless ( defined $synctime2 );
    $offset    = $synctime1 - $synctime2;

    S_w2log( 5, "EVAL_merge_sync( offset $offset )\n" );

    return $data_HoH_dummy if ($main::opt_offline);

    #copy signal 1
    foreach $time ( keys %{$MEASURE_DATA1} )
    {
        foreach $signal ( sort keys %{ $MEASURE_DATA1->{$time} } )
        {
            $data_HoH->{$time}->{$signal} = $MEASURE_DATA1->{$time}->{$signal};
        }
    }

    #merge and sync signal 2
    foreach $time ( keys %{$MEASURE_DATA2} )
    {
        foreach $signal ( sort keys %{ $MEASURE_DATA2->{$time} } )
        {
            # if signal already exists in measure 1, overwrite and warn
            if ( exists $data_HoH->{ $time + $offset }->{$signal} )
            {
                S_w2log( 5, "EVAL_merge_sync overwriting existing $signal at time " . ( $time + $offset ) . " with " . $MEASURE_DATA2->{$time}->{$signal} . "\n" );
            }
            $data_HoH->{ $time + $offset }->{$signal} = $MEASURE_DATA2->{$time}->{$signal};
        }
    }

    return ($data_HoH);

}

=head2     EVAL_GetSignalTransitions

    $data_HoH = EVAL_GetSignalTransitions(\%MEASURE_DATA, $SignalName,[$StartTime,[$EndTime]]);

This function reads the signal information and returns the required transition with the timestamps.

    eg:    $data_HoH = EVAL_GetSignalTransitions(\%MEASURE_DATA, 'SIG_1','0.3' , '1.5');
        $data_HoH = EVAL_GetSignalTransitions(\%MEASURE_DATA, 'SIG_1', '0.3');
        $data_HoH = EVAL_GetSignalTransitions(\%MEASURE_DATA, 'SIG_1');

%MEASURE_DATA = (
                    0.1 => { 'SIG_1' => 0  , 'SIG_2' => 0 } ,
                    0.2 => {                             'SIG_3' => 32  } ,
                    0.3 => { 'SIG_1' => 1  , 'SIG_2' => 0 } ,
                    0.4 => {                             'SIG_3' => 34  } ,
                    1.5 => { 'SIG_1' => 2  , 'SIG_2' => 1 } ,
                    1.6 => {                             'SIG_3' => 36  } ,
                    1.7 => { 'SIG_1' => 3  , 'SIG_2' => 0 } ,
            );

Output::
$data_HoH = {
                 '0.3' => {
                            'Current' => '1',
                            'Previous' => '0'
                    },
                 '1.5' => {
                             'Current' => '2',
                             'Previous' => '1'
                    },
                 '1.7' => {
                             'Current' => '3',
                             'Previous' => '2'
                    }
            };

=cut

sub EVAL_GetSignalTransitions
{

    my $MEASURE_DATA_href = shift;
    my $SignalName_local  = shift;
    my $StartTime_local   = shift;
    my $EndTime_local     = shift;
    my ( $previous, $current ) = undef;

    my ( $MINtime_stamp, $MAXtime_stamp ) = undef;
    my (@time_stamps) = undef;
    my %data_HoH;
    my %dummy = ( '0' => { 'Current' => '0', 'Previous' => '0' } );

    unless ( defined $SignalName_local )
    {
        S_set_error( 'too less parameters, SYNTAX:  EVAL_GetSignalTransitions( \%MEASURE_DATA, $SignalName, [$StartTime, [$EndTime]] )', 110 );
        return ( \%dummy );
    }

    unless ( defined $MEASURE_DATA_href && ref($MEASURE_DATA_href) eq "HASH" )
    {
        S_set_error( " MEASURE_DATA is not an Hash reference", 114 );
        return ( \%dummy );
    }

    if ( defined $StartTime_local && defined $EndTime_local && $StartTime_local >= $EndTime_local )
    {
        S_set_error( "StartTime ($StartTime_local) >= EndTime ($EndTime_local)", 109 );
        return ( \%dummy );
    }

    @time_stamps   = sort { $a <=> $b } keys %$MEASURE_DATA_href;
    $MINtime_stamp = $time_stamps[0];
    $MAXtime_stamp = $time_stamps[-1];

    if ( defined $StartTime_local && $StartTime_local < $MINtime_stamp )
    {
        S_set_error(
            "Start_Time $StartTime_local out of range: time
        ( $MINtime_stamp , $MAXtime_stamp )", 114 );
        return ( \%dummy );

    }

    if ( defined $EndTime_local && $EndTime_local > $MAXtime_stamp )
    {
        S_set_error(
            "EndTime $EndTime_local out of range: time
        ( $MINtime_stamp , $MAXtime_stamp )", 114 );
        return ( \%dummy );
    }

    return ( \%dummy ) if $main::opt_offline;

    # check if $SignalName_local exists in data hash
    my $found_flag = 0;
    foreach my $time ( sort { $a <=> $b } keys %$MEASURE_DATA_href )
    {
        if ( defined $MEASURE_DATA_href->{$time}{$SignalName_local} ) { $found_flag = 1; last; }
    }
    unless ($found_flag)
    {
        S_set_error( "signal $SignalName_local not found in given data reference", 114 );
        return ( \%dummy );
    }

    if ($found_flag)
    {
        # loop through time in signals hash
        for ( my $ndx = 0 ; $ndx < scalar(@time_stamps) ; $ndx++ )
        {
            next unless defined( $MEASURE_DATA_href->{ $time_stamps[$ndx] }->{$SignalName_local} );

            #If Start time is given and end time is not given
            if ( defined $StartTime_local && !defined $EndTime_local )
            {
                if ( ( $StartTime_local <= $time_stamps[$ndx] ) )
                {
                    $previous = $current;
                    $current  = $MEASURE_DATA_href->{ $time_stamps[$ndx] }->{$SignalName_local};
                    if ( defined $previous && defined $current && ( $previous != $current ) )
                    {
                        $data_HoH{ $time_stamps[$ndx] }{'Previous'} = qq/$previous/;
                        $data_HoH{ $time_stamps[$ndx] }{'Current'}  = qq/$current/;
                    }
                }
            }

            #If both Start time and end time are given
            elsif ( defined $StartTime_local && defined $EndTime_local )
            {
                if ( ( $StartTime_local <= $time_stamps[$ndx] ) && ( $time_stamps[$ndx] <= $EndTime_local ) )
                {
                    $previous = $current;
                    $current  = $MEASURE_DATA_href->{ $time_stamps[$ndx] }->{$SignalName_local};
                    if ( defined $previous && defined $current && ( $previous != $current ) )
                    {
                        $data_HoH{ $time_stamps[$ndx] }{'Previous'} = qq/$previous/;
                        $data_HoH{ $time_stamps[$ndx] }{'Current'}  = qq/$current/;
                    }
                }
            }

            #If both Start time and end time are not given
            else
            {
                $previous = $current;
                $current  = $MEASURE_DATA_href->{ $time_stamps[$ndx] }->{$SignalName_local};
                if ( defined $previous && defined $current && ( $previous != $current ) )
                {
                    $data_HoH{ $time_stamps[$ndx] }{'Previous'} = qq/$previous/;
                    $data_HoH{ $time_stamps[$ndx] }{'Current'}  = qq/$current/;
                }

            }
        }
    }
    return ( \%data_HoH );
}

=head2 EVAL_getFlashCodes

    ($flashCodes_aref, $status) = EVAL_getFlashCodes( $measureData_href [, $startTime, $endTime, $givenFlashCodeConfig_href ] );

Analyzes the data of signal $flashCodeConfig_href->{'signalName'} in $measureData_href and extracts all flash codes from the data.

    Input:
    $measureData_href:     reference to measurement data
    $startTime:            start time in measureData_href
    $endTime:              end time in measureData_href
    $flashCodeConfig_href: configuration data for flash codes (structure see example below)

    Output:
    $flashCodes_aref:      reference to list of all extracted flash codes
    $status:               1 on success, 0 on parameter error or if the data do not match the configuration in timing or values

If $startTime is not given then the data are used from the start of data.
If $endTime is not given then the data are used until the end of data.
If $flashCodeConfig_href is not given then it is taken from ProjectDefaults ($main::ProjectDefaults->{'FLASH_CODE_CONFIG'}).
If it is not defined there then the following default data (Ford AB12) are used.

    $flashCodeConfig_href = {
        'signalName' =>   'RILReq',
        'lowLevel' =>     { 'value' => 0,   'tolerance' => 0 },
        'highLevel' =>    { 'value' => 1,   'tolerance' => 0 },
        'lowTime_s' =>    { 'value' => 0.5, 'tolerance' => 0.05 },
        'highTime_s' =>   { 'value' => 0.5, 'tolerance' => 0.05 },
        'digitDelay_s' => { 'value' => 2,   'tolerance' => 0.05 },
        'codeDelay_s' =>  { 'value' => 5,   'tolerance' => 0.1 },
    };


The following signal shows an example of flashCode 35:

            highTime
             |----|
              ____      ____      ____           ____      ____      ____      ____      ____               highLevel
             |    |    |    |    |  3 |         |    |    |    |    |    |    |    |    |  5 |
      _______|    |____|    |____|    |_________|    |____|    |____|    |____|    |____|    |_____________ lowLevel

                  |----|              |---------|                                            |-------------
                 lowTime               digitDelay                                              codeDelay


Function low level design:

    foreach timeValue in measureData
        get dataValue of flashCodeConfig-signalName from measureData
        get dataLevel (low or high) out of dataValue; values which are neither low nor high will be ignored before the first digit, otherwise invalid will be returned
        if dataLevel is same as in last cycle then next loop cycle

        if dataLevel is high then
            transition from low to high: get lowTime
            if lowTime matches lowTime_s from flashCodeConfig then count up the current digit
            elsif lowTime matches digitDelay_s from flashCodeConfig then the digit is complete; add it to the current code
            elsif lowTime matches codeDelay_s from flashCodeConfig then the code is complete; add digit to current code and code to the list of codes
            else no proper lowTime: return current list of codes with status 0 (invalid)
            endif
        else
            transition from high to low: get highTime
            if highTime matches highTime_s from flashCodeConfig then all is OK, do nothing
            else no proper highTime: return current list of codes with status 0 (invalid)
            endif
        endif
    endfor
    add digit to current code and code to the list of codes
    return current list of codes with status 1 (valid)




=cut

sub EVAL_getFlashCodes
{
    my @args = @_;
    return ( [], 0 ) unless S_checkFunctionArguments( 'EVAL_getFlashCodes( $measureData_href [, $startTime, $endTime, $givenFlashCodeConfig_href ] )', @args );

    my $measureData_href          = shift @args;
    my $startTime                 = shift @args;
    my $endTime                   = shift @args;
    my $givenFlashCodeConfig_href = shift @args;

    my %flashCodeConfig;
    my $flashCodeConfig_href = \%flashCodeConfig;

    return ( [], 0 ) unless VerifyFlashCodeConfig( $flashCodeConfig_href, $givenFlashCodeConfig_href );

    my ( @codeList, $code, $digit );
    my $levelStartTime = 0;
    my $isFirstDigit   = 1;
    my $lastDataLevel  = 'low';

    foreach my $timeValue ( sort { $a <=> $b } keys %{$measureData_href} )
    {
        next if ( defined $startTime and $timeValue < $startTime );
        next if ( defined $endTime   and $timeValue > $endTime );

        # get dataValue of flashCodeConfig-signalName from measureData
        my $dataValue = $measureData_href->{$timeValue}{ $flashCodeConfig_href->{'signalName'} };
        next if ( not defined $dataValue );

        # get dataLevel (low or high) out of dataValue; values which are neither low nor high will be ignored before the first digit, otherwise invalid will be returned
        my $dataLevel = GetDataLevel( $dataValue, $flashCodeConfig_href );
        if ( not defined $dataLevel )
        {
            next if ($isFirstDigit);
            S_set_warning("improper data level (neither low nor high) found in flash code data of signal $flashCodeConfig_href->{'signalName'} at time = $timeValue");
            return ( \@codeList, 0 );
        }

        # if $dataLevel is same as in last cycle then next loop cycle
        next if ( $dataLevel eq $lastDataLevel );
        $lastDataLevel = $dataLevel;

        if ( $dataLevel eq 'high' )
        {
            # transition from low to high: get lowTime
            my $lowTime = $timeValue - $levelStartTime;

            # if lowTime matches lowTime_s from flashCodeConfig then count up the current digit
            if (    $lowTime >= $flashCodeConfig_href->{'lowTime_s'}{'value'} - $flashCodeConfig_href->{'lowTime_s'}{'tolerance'} and $lowTime <= $flashCodeConfig_href->{'lowTime_s'}{'value'} + $flashCodeConfig_href->{'lowTime_s'}{'tolerance'}
                 or $isFirstDigit )
            {
                $digit++;
                $isFirstDigit = 0;
            }

            # if lowTime matches digitDelay_s from flashCodeConfig then the digit is complete; add it to the current code
            elsif (     $lowTime >= $flashCodeConfig_href->{'digitDelay_s'}{'value'} - $flashCodeConfig_href->{'digitDelay_s'}{'tolerance'}
                    and $lowTime <= $flashCodeConfig_href->{'digitDelay_s'}{'value'} + $flashCodeConfig_href->{'digitDelay_s'}{'tolerance'} )
            {
                $code .= $digit;
                $digit = 1;
            }

            # if lowTime matches codeDelay_s from flashCodeConfig then the code is complete; add digit to current code and code to the list of codes
            elsif (     $lowTime >= $flashCodeConfig_href->{'codeDelay_s'}{'value'} - $flashCodeConfig_href->{'codeDelay_s'}{'tolerance'}
                    and $lowTime <= $flashCodeConfig_href->{'codeDelay_s'}{'value'} + $flashCodeConfig_href->{'codeDelay_s'}{'tolerance'} )
            {
                $code .= $digit;
                $digit = 1;
                push( @codeList, $code );
                $code = '';
            }
            else
            {
                # no proper lowTime: return current list of codes with status 0 (invalid)
                S_set_warning("improper lowTime found in flash code data of signal $flashCodeConfig_href->{'signalName'} before time = $timeValue");
                return ( \@codeList, 0 );
            }

        }

        else
        {
            # transition from high to low: get highTime
            my $highTime = $timeValue - $levelStartTime;

            # if highTime matches highTime_s from flashCodeConfig then all is OK, do nothing
            if (     $highTime >= $flashCodeConfig_href->{'highTime_s'}{'value'} - $flashCodeConfig_href->{'highTime_s'}{'tolerance'}
                 and $highTime <= $flashCodeConfig_href->{'highTime_s'}{'value'} + $flashCodeConfig_href->{'highTime_s'}{'tolerance'} )
            {
                # do nothing
            }
            else
            {
                # no proper highTime: return current list of codes with status 0 (invalid)
                S_set_warning("improper highTime found in flash code data of signal $flashCodeConfig_href->{'signalName'} before time = $timeValue");
                return ( \@codeList, 0 );
            }
        }

        $levelStartTime = $timeValue;

    }    # end of foreach loop

    # add digit to current code and code to the list of codes
    if ( $digit > 0 )
    {
        $code .= $digit;
    }
    if ( $code ne '' )
    {
        push( @codeList, $code );
    }

    S_w2log( 3, "EVAL_getFlashCodes: flash codes are @codeList\n" );
    return ( \@codeList, 1 );
}

=head2 EVAL_importCSV

    $measureData_href = EVAL_importCSV( $fileName, $separator, $timeIdentifier [, $signalNames_aref] );

Reads given csv file, extracts all data and returns a reference to the data structure.

    Input:
    $fileName:          csv file with data
    $separator:         separator character in csv file
    $timeIdentifier:    time identifier (see description below)
    $signalNames_aref:  names of the signals in the csv file

    Output:
    $measureData_href:  reference to measurement data

The file to be read must have a csv structure with a defined separator character (e.g. ; or tab).
If $signalNames_aref is given then it defines the signal names, otherwise the signal names are taken from the first line of the input file.
If $timeIdentifier is a signal name then this signal serves as time of the measurement data.
Otherwise it can be a number indicating the time delta (in seconds) between 2 data points of each signal.

=cut

sub EVAL_importCSV
{
    my @args = @_;
    return {} unless S_checkFunctionArguments( 'EVAL_importCSV( $fileName, $separator, $timeIdentifier [, $signalNames_aref] )', @args );

    my $fileName         = shift @args;
    my $separator        = shift @args;
    my $timeIdentifier   = shift @args;
    my $signalNames_aref = shift @args;

    # read contents of csv file
    unless ( open( CSV, "<$fileName" ) )
    {
        S_set_error( "Cannot open csv file: $!", 5 );
        return {};
    }
    my @lines = <CSV>;
    close(CSV);

    my ( %measureData, @signalNames, $timeDelta, $timeIndex );

    # check if $signalNames_aref is given as argument
    if ( defined $signalNames_aref )
    {
        # use signal names defined in $signalNames_aref
        @signalNames = @{$signalNames_aref};
    }
    else
    {
        # extract first line from csv file and get signal names from there
        my $firstLine = shift @lines;
        chomp($firstLine);
        @signalNames = split( /$separator/, $firstLine );

        # remove any leading or trailing whitespace from the signal names
        map { s/^\s+//g } @signalNames;
        map { s/\s+$//g } @signalNames;
    }

    # check if $timeIdentifier is a number
    if ( $timeIdentifier =~ /^[0-9]*\.?[0-9]+$/ )
    {
        # use $timeIdentifier as time delta (in seconds) between 2 data points of each signal
        $timeDelta = $timeIdentifier;
    }
    else
    {
        # $timeIdentifier is a signal name: find it in the signals
        my $timeIndexFound = 0;

        # loop through all signal names
        foreach my $dataIndex ( 0 .. @signalNames - 1 )
        {
            if ( $signalNames[$dataIndex] eq $timeIdentifier )
            {
                # if signal name is found store the index (= column number in the csv file) as $timeIndex
                $timeIndex      = $dataIndex;
                $timeIndexFound = 1;
                last;
            }
        }

        # error if $timeIndexFound was not found in the list of all signals
        if ( not $timeIndexFound )
        {
            S_set_error("Could not find time identifier ($timeIdentifier) in the list of signal names (@signalNames)");
            return {};
        }

    }

    # loop over all lines of the csv file
    my $timeValue = -$timeDelta;
    foreach my $line (@lines)
    {
        # skip lines with "next measurement" at the beginning: special treatment of test data
        next if $line =~ /^\s*next\s+measurement/;

        # chop off newline
        chomp($line);

        # get individual data values
        my @dataValues = split( /$separator/, $line );

        # plausibility check for number of signal names and number of data values
        if ( @dataValues != @signalNames )
        {
            S_set_error("Number of signal names (@signalNames) does not match number of data values (@dataValues)");
            return {};
        }

        # get current time for the data
        if ($timeDelta)
        {
            # either from $timeDelta
            $timeValue += $timeDelta;
        }
        else
        {
            # or from time signal
            $timeValue = $dataValues[$timeIndex];
        }

        # build data structure
        foreach my $dataIndex ( 0 .. @dataValues - 1 )
        {
            my $signalName  = $signalNames[$dataIndex];
            my $signalValue = $dataValues[$dataIndex];
            $measureData{$timeValue}{$signalName} = $signalValue;
        }
    }

    return \%measureData;
}

=head2 EVAL_dataCalculationOverTime

    $status = EVAL_dataCalculationOverTime( $measureData_href, $newSignalName, $calculationExpression , $signalNames_aref );

Creates a new signal (with name $newSignalName) in $measureData_href using a Perl-like expression ($calculationExpression) to calculate the values of the new signal.

    Input:
    $measureData_href      : reference to measurement data
    $newSignalName         : name of the new calculated signal
    $calculationExpression : expression that defines the values of the new signal
    $signalNames_aref      : names of the signals that are used in $calculationExpression

    Output:
    $status               : status of the function (1 on success, 0 otherwise)

The values of the new signal are calculated for each time value with the given $calculationExpression.
$calculationExpression can have all operators and mechanisms of a valid Perl expression, including usage of variables (see examples).
Additionally special variables are defined to use existing signals of $measureData_href: #0, #1, ..., #9.
Each #n stands for one existing signal of $measureData_href. The names of the used signals are given in $signalNames_aref.
E.g. if $calculationExpression contains #0 and #1 then $signalNames_aref must contain 2 existing signal names.
Each #n can have optionally one of the following time identifiers:

    #n[t]   : value of #n at the current time step
    #n[t-1] : value of #n at the last time step
    #n[0]   : value of #n at the time step 0 (first value)
    #n[<number>] : value of #n at the time step <number> (e.g. #n[3])

If $measureData_href has the following values

   $measureData_href = {
                  0 => { 'signal0' = 1.0  } ,
                  1 => { 'signal0' = 1.1  } ,
                  2 => { 'signal0' = 1.2  } ,
                  3 => { 'signal0' = 1.3  } ,
                };

and $calculationExpression contains #0 and $signalNames_aref = ['signal0'] then at time t = 3: #0[t] = 1.3, #0[t-1] = 1.2 and #0[0] = 1.0.

Examples:

    # all values of signal0 will be multiplied by 42 and stored as 'rescaled'
    my $factor = 42;
    EVAL_dataCalculationOverTime( $measureData_href, 'rescaled', "#0 * $factor", ['signal0'] );
    # for each time value of signal0 will be added to value of signal1 and stored as 'sum'
    EVAL_dataCalculationOverTime( $measureData_href, 'sum', "#0 + #1", ['signal0', 'signal1'] );
    # for each time the difference of current value and last value of signal0 will be stored as 'delta'
    EVAL_dataCalculationOverTime( $measureData_href, 'delta', '#0[t] - #0[t-1]', ['signal0'] );

=cut

sub EVAL_dataCalculationOverTime
{

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'EVAL_dataCalculationOverTime( $measureData_href, $newSignalName, $calculationExpression , $signalNames_aref )', @args );

    my $measureData_href      = shift @args;
    my $newSignalName         = shift @args;
    my $calculationExpression = shift @args;
    my $signalNames_aref      = shift @args;


    my ( %variables, $expressionVarConfig_href, $expressionVariables_aref );

    my @signalNames = @{$signalNames_aref};
    S_w2log( 3, "EVAL_dataCalculationOverTime: Calculate new signal '$newSignalName' with formula '$calculationExpression' from signals '@signalNames'.\n" );

    # parse $calculationExpression, write all #n into $expressionVariables_aref, create $expressionVarConfig_href
    # and replace all #n in $calculationExpression with $variables{n}{time identifier}, so that $calculationExpression can be calculated by Perl
    ( $calculationExpression, $expressionVariables_aref, $expressionVarConfig_href ) = ParseCalculationExpression($calculationExpression);

    # check if number of #n matches the number of given signal names in $signalNames_aref
    if ( scalar keys %{$expressionVarConfig_href} != scalar @signalNames )
    {
        S_set_error("Number of variables in given expression ($calculationExpression) does not match the number of given signal names (@signalNames)");
        return 0;
    }

    # first loop: get all values for each variable in a list ($expressionVarConfig_href->{$signalIndex}{'values'}), so that #n[<number>] can be calculated
    my $timeIndex = 0;

    # loop over all time values of $measureData_href
    foreach my $timeValue ( sort { $a <=> $b } keys %{$measureData_href} )
    {

        # loop over all signal names that are used in $calculationExpression
        foreach my $signalIndex ( 0 .. @signalNames - 1 )
        {
            # get name and value of current signal at current time
            my $signalName   = $signalNames[$signalIndex];
            my $measureValue = $measureData_href->{$timeValue}{$signalName};
            ${ $expressionVarConfig_href->{$signalIndex}{'values'} }[$timeIndex] = $measureValue;
        }
        $timeIndex++;
    }

    # second loop: actually calculate the given $calculationExpression
    # loop over all time values of $measureData_href
    foreach my $timeValue ( sort { $a <=> $b } keys %{$measureData_href} )
    {

        my $signalDefined = 1;

        # loop over all signal names that are used in $calculationExpression
        foreach my $signalIndex ( 0 .. @signalNames - 1 )
        {

            # get name and value of current signal at current time
            my $signalName   = $signalNames[$signalIndex];
            my $measureValue = $measureData_href->{$timeValue}{$signalName};

            if ( defined $measureValue )
            {
                # if the value is defined get the number of the current expression variables: 0 for #0, 1 for #1, etc. and calculate the value of the expression variable
                my @exprVarNumbers = ${$expressionVariables_aref}[$signalIndex] =~ /\#(\d)/;
                my $exprVarNum     = $exprVarNumbers[0];
                CalculateExpressionVariable( \%variables, $measureValue, $expressionVarConfig_href, $exprVarNum );
            }
            else
            {
                $signalDefined = 0;
                last;
            }
        }

        # only if all signals have a value at the current time calculate the value of the new signal
        if ($signalDefined)
        {
            my $result = eval($calculationExpression);
            $measureData_href->{$timeValue}{$newSignalName} = $result;
        }

    }

    return 1;

}

=head2 EVAL_createGraphFromMeasurement

    $status = EVAL_createGraphFromMeasurement( $measureData_href, $graphTitle, $signalNames_href [, $plotmode, $loglevel, $htmlAttributes, $yLabel ] );

Creates a plot of the signals given in $signalNames_href from the data structure $measureData_href and saves it as pic (*.png) and UNIVIEW file (*.txt.unv).
Optionally also includes the plot into the html report with log level $loglevel.

    Input:
    $measureData_href : reference to measurement data
    $graphTitle       : title of the plot
    $signalNames_href : names of the signals that are plotted, see description below
    $plotmode         : (optional) 'no_interpolation', 'interpolate' or 'interpolate_points', default is 'no_interpolation'
    $loglevel         : (optional) log level with which the plot will be included in the html report
    $htmlAttributes   : (optional) further html attributes for the plot
    $yLabel           : (optional) label for the y-axis of the plot, default is no y-axis label

    Output:
    $status               : status of the function (1 on success, 0 otherwise)

The signals that will be plotted are defined by $signalNames_href:

    $signalNames_href = {
        'y' => ['signal1', 'signal2', ...],
        'x' => 'signalx',
    }

All signals given in key 'y' are included in the plot.
Key 'x' is optional. If not given then all signals defined in 'y' are plotted against time, otherwise against 'signalx'.

B<Note: All y-signals must have the same x- or time-values, both in number and value!>

$plotmode is just passed through to S_create_graph to control the way the data points are connected in the plot.
If $loglevel is not given then the plot is only created as files (*.png and *.txt.unv).
If given then additionally the plot is included in the html report with additional $htmlAttributes if wanted.

B<Examples:>

    # plot signal1 vs time; plot is included in html report with log level 1
    $status = EVAL_createGraphFromMeasurement( $measureData_href, "Example1", {y=>['signal1']}, undef, 1 );
    #
    # plot signal2 and signal3 vs signal4; plot is not included in html report
    $status = EVAL_createGraphFromMeasurement( $measureData_href, "Example2", {x=>'signal4', y->['signal2', 'signal3']} );

=cut

sub EVAL_createGraphFromMeasurement
{

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'EVAL_createGraphFromMeasurement( $measureData_href, $graphTitle, $signalNames_href [, $plotmode, $loglevel, $htmlAttributes, $yLabel ] )', @args );

    my $measureData_href = shift @args;
    my $graphTitle       = shift @args;
    my $signalNames_href = shift @args;
    my $plotmode         = shift @args;
    my $loglevel         = shift @args;
    my $htmlAttributes   = shift @args;
    my $yLabel           = shift @args;

    my $values_aref = [];
    my $times_aref = [];
    my %graphData;
    
    $graphTitle =~ s/::/_/g;   # Replace if the name contains '::' to '_'. as '::' is not supported by filename.

    if ( not defined $signalNames_href->{'y'} or ref( $signalNames_href->{'y'} ) ne 'ARRAY' )
    {
        S_set_error( "Given signal names not defined or wrong format. Format must be: \$signalNames_href = { 'y' => ['signal1', 'signal2', ...], 'x' => 'signal_x' } , 'x' is optional, if not given then time is used as x-axis.", 109 );
        return 0;
    }

    my @ySignalNames = @{ $signalNames_href->{'y'} };
    if ( @ySignalNames == 0 )
    {
        S_set_error( "No signal names given for y axis. Format must be: \$signalNames_href = { 'y' => ['signal1', 'signal2', ...], 'x' => 'signal_x' } , 'x' is optional, if not given then time is used as x-axis.", 109 );
        return 0;
    }

    my $graphArraySizes_href;
    foreach my $signalName ( @ySignalNames )
    {
        ( $values_aref, $times_aref ) = EVAL_get_values_and_times_over_time( $measureData_href, $signalName );
        if( not defined $values_aref or not defined $times_aref ) {
            S_set_error( "No data values found for signal '$signalName' in data hash", 109 );
            return 0;
        }
        $graphData{$signalName} = $values_aref;
        $graphArraySizes_href->{$signalName} = scalar( @$values_aref );
    }

    if ( defined $signalNames_href->{'x'} )
    {
        ( $values_aref, $times_aref ) = EVAL_get_values_and_times_over_time( $measureData_href, $signalNames_href->{'x'} );
        if( not defined $values_aref ) {
            S_set_error( "No data values found for signal '".$signalNames_href->{'x'}."' in data hash", 109 );
            return 0;
        }
        $graphData{'x'}       = $values_aref;
        $graphData{'x-label'} = $signalNames_href->{'x'};
    }
    else
    {
        $graphData{'x'}       = $times_aref;
        $graphData{'x-label'} = 'time in s';
    }

    my $xSize = @{ $graphData{'x'} };
    foreach my $signalName ( keys %{ $graphArraySizes_href } )
    {
        my $ysize = $graphArraySizes_href->{$signalName};
        my $yValues_aref = $graphData{$signalName};
        my $sizeDifference = $ysize - $xSize;
        if( $sizeDifference > 0 ){ # y-values have more points than x-values
            # remove y-values from the end
            S_set_warning( "Size mismatch in data to be plotted: x-axis ($graphData{'x-label'}) has size $xSize but signal '$signalName' has size $ysize . Removing $sizeDifference elements from '$signalName'..." );
            splice( @$yValues_aref, -$sizeDifference, $sizeDifference);
        }
        elsif( $sizeDifference < 0 ){ # y-values have fewer points than x-values
            # add y-values (0) at the end
            $sizeDifference = -$sizeDifference;
            S_set_warning( "Size mismatch in data to be plotted: x-axis ($graphData{'x-label'}) has size $xSize but signal '$signalName' has size $ysize . Adding $sizeDifference zero values to '$signalName'..." );
            my @zeros = (0) x $sizeDifference;
            push( @$yValues_aref, @zeros );
        }
    }

    $plotmode = 'no_interpolation' if not defined $plotmode;
    S_create_graph( \%graphData, "$main::REPORT_PATH/$graphTitle.txt", $graphTitle, 'white', $plotmode, $yLabel );

    if ( defined $loglevel )
    {
        S_add_pic2html( "$graphTitle.png", $htmlAttributes, "$graphTitle.txt.unv", 'TYPE="text/unv"', $loglevel );
    }

    return 1;
}

=head2 EVAL_RescaleDataHashValues

 $MEASURE_DATA_RESCALED_href = EVAL_RescaleDataHashValues( $MEASURE_DATA_href, $signalName, $rescaleFactor [, $newSignalName] )

Rescales data values of $MEASURE_DATA_href for selected signal $signalName with defined factor $rescaleFactor.
Other signals in $MEASURE_DATA_href are not changed.
Optionally a new name ($newSignalName) can be given for the signal. In that case the original data of $signalName are unchanged,
but the rescaled data is added with the new name $newSignalName.
The data to which $MEASURE_DATA_href points are changed in this function!!!

Returns the reference to $MEASURE_DATA_href. Returns an empty hash reference on error.

Note: $MEASURE_DATA_href and $MEASURE_DATA_RESCALED_href point to the same structure. So it is possible to use the function without return value.


Example:
    $MEASURE_DATA_href = {
                  0.01 =>  { 'SIG_1' => 0} ,
                  0.02 =>  {                 'SIG_2' => 32  } ,
                  0.03 =>  { 'SIG_1' => 1} ,
                  0.04 =>  {                 'SIG_2' => 16  } ,
                  0.05 =>  { 'SIG_1' => 0} ,
                  0.06 =>  {                 'SIG_2' => 32  } ,
                  0.07 =>  { 'SIG_1' => 1} ,
                  0.08 =>  {                 'SIG_2' => 16  } ,
                  0.09 =>  { 'SIG_1' => 0} ,
                  0.10 =>  {                 'SIG_2' => 32  } ,
                };

    EVAL_RescaleDataHashValues( $MEASURE_DATA_href, 'SIG_2', 0.25, 'SIG_2_new' );

In this example all values of SIG_2 are multiplied with 0.25.
In $MEASURE_DATA_href the values of 'SIG_1' and 'SIG_2' are unchanged and new values 'SIG_2_new' are added,
being always 0.25 * the values of 'SIG_2'.

=cut

sub EVAL_RescaleDataHashValues
{
    my $measureData_href = shift;
    my $signalName       = shift;
    my $rescaleFactor    = shift;
    my $newSignalName    = shift;

    unless ( defined $rescaleFactor )
    {
        S_set_error( "too less parameters ,SYNTAX: EVAL_RescaleDataHashValues( \$MEASURE_DATA_href, \$signalName, \$rescaleFactor [, \$newSignalName] )", 110 );
        return {};
    }

    if ( ref($measureData_href) ne "HASH" )
    {
        S_set_error( "First parameter (\$MEASURE_DATA_href) is not a hash reference", 114 );
        return {};
    }

    S_w2log( 4, "EVAL_RescaleDataHashValues: Rescaling signal $signalName with factor $rescaleFactor. Optional new signal name: $newSignalName" );

    foreach my $time ( keys %{$measureData_href} )
    {
        next unless defined $measureData_href->{$time}{$signalName};
        if ( defined $newSignalName )
        {
            $measureData_href->{$time}{$newSignalName} = $measureData_href->{$time}{$signalName} * $rescaleFactor;
        }
        else
        {
            $measureData_href->{$time}{$signalName} *= $rescaleFactor;
        }
    }    # end foreach

    return $measureData_href;
}

=head2 EVAL_evaluateAndPlotDataWithLimits

    $status = EVAL_evaluateAndPlotDataWithLimits( $data_href, $title, $signals_mix [, $limitExpression, $yLabel ] );

Plots the data ($data_href) of signals given in $signals_mix. Title of the plot is $title. Y-axis label is $yLabel.
If $signals_mix is an array reference then all signals in there are plotted against time.
If $signals_mix is a hash reference then all signals of $signals_mix->{'y'} (array reference) are plotted against $signals_mix->{'x'}.
If $limitExpression is given then the signals given in $signals_mix are evaluated against $limitExpression.
The limits given in $limitExpression will also be plotted.
Details of $limitExpression see below.


    Inputs:
    $data_href       : Measure data hashref
    $title           : Title of the plot
    $signals_mix     : Array reference of signals to be plotted against time and evaluated
                    or Hash reference with keys
                        'x' -> label for x-axis,
                        'y' -> array reference of signals to be plotted and evaluated (y-axis)
    $limitExpression : (optional) expression of the form '<operation> <operator> <compare value>'
                       <operation> can be 'abs' or 'value',
                       in case of 'abs' evaluate the absolute value of the signal values
                       in case of 'value' evaluate the signal values directly
                       <operator> can be '<', '<=', '=', '>', '>='
                       <compare value> can be either a number or another signal from $data_href
                       if <operator> is '=' then <compare value> must be <number>+-<tolerance>
    $yLabel          : (optional) label for the y-axis of the plot, default is no y-axis label

    Output:
    $status : 1 on success, 0 on error

Examples:

    EVAL_evaluateAndPlotDataWithLimits( $data_href, 'example1', ['sig1', 'sig2'] , 'abs < 0.1' );
    EVAL_evaluateAndPlotDataWithLimits( $data_href, 'example1', ['sig1'] , 'value > sig3' );
    EVAL_evaluateAndPlotDataWithLimits( $data_href, 'example2', {'x' => 'sig4', 'y' => ['sig5']} , 'value = 1+-0.1', 'current in A' );

Note: This function has been designed for and adapted to the SMI7xy verification test.

=cut

sub EVAL_evaluateAndPlotDataWithLimits
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'EVAL_evaluateAndPlotDataWithLimits( $data_href, $title, $signals_mix [, $limitExpression, $yLabel ] )', @args );

    my $data_href       = shift @args;
    my $title           = shift @args;
    my $signals_mix     = shift @args;
    my $limitExpression = shift @args;
    my $yLabel          = shift @args;

    my $plotMode = 'interpolate';
    
    my ( @signals, %plotData );

    # fill @signals and $plotData{'y'} depending on whether $signals_mix is an array ref or a hash ref
    if ( ref($signals_mix) eq 'ARRAY' )
    {
        @signals = @{$signals_mix};
        $plotData{'y'} = $signals_mix;
    }
    elsif ( ref($signals_mix) eq 'HASH' )
    {
        @signals = @{ $signals_mix->{'y'} };
        $plotData{'y'} = $signals_mix->{'y'};
        if ( defined $signals_mix->{'x'} )
        {
            $plotData{'x'} = $signals_mix->{'x'};
        }
    }
    else
    {
        S_set_error("Third argument is neither array reference nor hash reference");
        return 0;
    }

    if( @signals == 0 ) {
        S_set_error("For plot '$title' no signal is given for y axis.");
        return 0;
    }

    # if $limitExpression is not given then only plot and return
    if ( not defined $limitExpression )
    {
        S_w2log( 2, "Plot $title:" );
        EVAL_createGraphFromMeasurement( $data_href, $title, \%plotData, $plotMode, 1, 'width=900', $yLabel );
        return 1;
    }

    my ( $precalc, $operator, $limit, $limit_low, $limit_high, $offset, $limitIsNumber, %limits );

    # parse $limitExpression
    if ( $limitExpression =~ /(\S+)\s+(\S+)\s+(\S+)/ )
    {
        $precalc  = $1;
        $operator = $2;
        $limit    = $3;
    }
    else
    {
        S_set_error("Limit expression ($limitExpression) has the wrong format. It must be '<operation> <operator> <compare value>'");
        return 0;
    }

    # check if $precalc has correct values
    if ( $precalc ne 'abs' and $precalc ne 'value' )
    {
        S_set_error("First part of limit expression ($precalc) is unknown. Should be 'value' or 'abs'.");
        return 0;
    }

    # by default $limit is a number
    $limitIsNumber = 1;

    # build the %limits structure: evaluations can have 1 or 2 limits that need to be plotted and evaluated
    if ( $operator eq '=' )
    {
        if ( $limit =~ /(.+)\+-(.+)/ )
        {
            # operator '=' and value with tolerance: 2 limits
            $limits{0}{'title'}    = $title . '_limit_low';
            $limits{0}{'operator'} = '>';
            $limits{0}{'limit'}    = $1 - $2;
            $limits{0}{'sign'}     = '-';
            $limits{1}{'title'}    = $title . '_limit_high';
            $limits{1}{'operator'} = '<';
            $limits{1}{'limit'}    = $1 + $2;
            $limits{0}{'sign'}     = '';
        }
        else
        {
            S_set_error("In limit expression for operator '=' the expected value ($limit) must be like 'offset+-tolerance'.");
            return 0;
        }
    }
    else
    {
        if ( $limit =~ /^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$/ )
        {
            # limit is a number: set $limit_low and $limit_high for abs case
            $limit_low  = -$limit;
            $limit_high = $limit;
        }
        else
        {
            # limit is not a number: reset number flag and set $limit_low and $limit_high for abs case
            $limitIsNumber = 0;
            $limit_low     = $limit;
            $limit_high    = $limit;
        }

        if ( $precalc eq 'abs' )
        {
            # operator not '=' and precalc is 'abs': 2 limits for plotting, evaluation will be handled seperately
            $limits{0}{'title'}    = $title . '_limit_low';
            $limits{0}{'operator'} = '>';
            $limits{0}{'limit'}    = $limit_low;
            $limits{0}{'sign'}     = '-';
            $limits{1}{'title'}    = $title . '_limit_high';
            $limits{1}{'operator'} = '<';
            $limits{1}{'limit'}    = $limit_high;
            $limits{1}{'sign'}     = '';
        }
        else
        {
            # operator not '=' and precalc is 'value': 1 limit
            $limits{0}{'title'}    = $title . '_limit';
            $limits{0}{'operator'} = $operator;
            $limits{0}{'limit'}    = $limit;
            $limits{0}{'sign'}     = '';
        }
    }

    S_w2log( 2, "Evaluate and plot $title:" );
    my $lastSignal;

    # loop over all signals in @signals for evaluation
    foreach my $signal (@signals)
    {
        if ( $precalc eq 'abs' )
        {
            # special case for 'abs': calculate abs-value and do only one evaluation, but later plot limit_low and limit_high
            EVAL_dataCalculationOverTime( $data_href, $signal.'_abs', "abs(#0)", [$signal] );
            EVAL_evaluate_value_over_time( $data_href, $signal.'_abs', $operator, $limit );
        }
        else
        {
            # for 'value' do 1 or 2 evaluations depending on %limits
            foreach my $limitCounter ( keys %limits )
            {
                EVAL_evaluate_value_over_time( $data_href, $signal, $limits{$limitCounter}{'operator'}, $limits{$limitCounter}{'limit'} );
            }
        }

        # remember the last signal, we need it later for correctly calculating the limit-signals
        $lastSignal = $signal;
    }

    # loop over %limits for calculation of the limit signals
    foreach my $limitCounter ( keys %limits )
    {
        if ($limitIsNumber)
        {
            # $limit is a number, so calculate the limit-signal from the limit value
            # the term '+ #0 * 0' is necessary to calculate the values of the limit-signal only for those time values that are used by $lastSignal
            # otherwise the limit-signal might have more values than the data-signals and that would result in an error in the plotting function
            EVAL_dataCalculationOverTime( $data_href, $limits{$limitCounter}{'title'}, $limits{$limitCounter}{'limit'} . " + #0 * 0", [$lastSignal] );
        }
        else
        {
            # $limit is a signal name, so calculate the limit-signal from the signal name using the 'sign' set in %limits
            # see above about he term '+ #0 * 0'
            EVAL_dataCalculationOverTime( $data_href, $limits{$limitCounter}{'title'}, $limits{$limitCounter}{'sign'} . "#0 + #1 * 0", [ $limit, $lastSignal ] );
        }

        # push all additionally calculated signals into @signals
        push( @signals, $limits{$limitCounter}{'title'} );
    }

    # plot all signals
    $plotData{'y'} = \@signals;
    EVAL_createGraphFromMeasurement( $data_href, $title, \%plotData, $plotMode, 1, 'width=900', $yLabel );

    return 1;
}



##########################################################################################################

=head1 not exported functions


=head2 compare_two_values

    $bool = compare_two_values( $value1, $operator, $value2 ); not exported

   $operator      : == != >= <= > < MASK

=cut

#####################################################################
## compare_two_values (local function)
#####################################################################
sub compare_two_values
{
#####################################################################
    my $value1   = shift;
    my $operator = shift;
    my $value2   = shift;
    my ( $decvalue1, $decvalue2 );

    if ( $operator ne 'MASK' )
    {
        $decvalue1 = S_0x2dec($value1);
        $decvalue2 = S_0x2dec($value2);
    }

    if ( $operator eq '>' )
    {
        return eval( $decvalue1 > $decvalue2 );
    }
    elsif ( $operator eq '<' )
    {
        return eval( $decvalue1 < $decvalue2 );
    }
    elsif ( $operator eq '==' )
    {
        # equality precision of 10 nano units (10^-8)
        return eval( abs( $decvalue1 - $decvalue2 ) < 0.00000001 );
    }
    elsif ( $operator eq '>=' )
    {
        return 1 if compare_two_values( $value1, '>', $value2 );
        return 1 if compare_two_values( $value1, '==', $value2 );
        return;
    }
    elsif ( $operator eq '<=' )
    {
        return 1 if compare_two_values( $value1, '<', $value2 );
        return 1 if compare_two_values( $value1, '==', $value2 );
        return;
    }
    elsif ( $operator eq '!=' )
    {
        # non equality precision of 10 nano units (10^-8)
        return eval( abs( $decvalue1 - $decvalue2 ) >= 0.00000001 );
    }
    elsif ( $operator eq 'MASK' )
    {
        if ( $value2 =~ /0b([x01]{1,64})/i )
        {
            ### binary evaluation with bitmask
            my $exp_bin_value = reverse $1;
            my $det_bin_value;

            if ( $value1 =~ /0b([x01]{1,64})/i )
            {
                ## convert detected binary value
                $det_bin_value = reverse $1;
            }
            elsif ( $value2 =~ /0b([x01]{1,32})/i )
            {
                ## convert detected value into 32bit binary value
                $det_bin_value = reverse S_dec2bin($value1);
            }
            else
            {
                S_set_error( "not a valid bitmask or value not in binary, can't convert", 109 );
                return -1;
            }
            ## cut the 64bit binary value to a binary value with length of given bitmask
            my $used_part_of_det_bin_val = substr( $det_bin_value, 0, length($exp_bin_value), );

            ## cut the 64bit binary value to a binary value with length of given bitmask
            my $unused_part_of_det_bin_val = substr( $det_bin_value, length($exp_bin_value), length($det_bin_value) - length($exp_bin_value) );

            #S_w2rep( " used $used_part_of_det_bin_val unused $unused_part_of_det_bin_val det $det_bin_value exp $exp_bin_value\n");

            if ( length($unused_part_of_det_bin_val) > 0 and $unused_part_of_det_bin_val != 0 )
            {
                S_set_error( "Signal value ($value1 ) is bigger then max possible signal of given mask ($value2)  ", 109 );
                return -1;
            }

            $det_bin_value = $used_part_of_det_bin_val;

            my $exp_bit;
            my $det_bit;
            my @mismatched_bits = ();
            my $mismatch_text;
            for ( 0 .. length($exp_bin_value) - 1 )
            {
                $exp_bit = substr( $exp_bin_value, $_, 1 );
                $det_bit = substr( $det_bin_value, $_, 1 );
                next if $exp_bit =~ /x/i;
                next if $exp_bit == $det_bit;

                #         S_w2rep( " Signal '$signal_to_check' : (expected) '$expected_value' =~ '$detected_value' (detected) equal with $tolerance % tolerance\n");
                push( @mismatched_bits, $_ );

                #         print "$_ $exp_bit $det_bit\n";
            }

            if ( not @mismatched_bits )
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            S_set_error( "compare value $value2 is not a valid bitmask", 109 );
            return -1;
        }

    }
    else
    {    # unknown operator
        S_set_error( "unknown operator $operator", 109 );
        return -1;
    }
}

#####################################################################

=head2 EVAL_evaluate_values_at_time

   EVAL_evaluate_values_at_time ( \%DATA , \%labels );

 OBSOLETE FUNCTION EVAL_evaluate_values_at_time. PLEASE USE EVAL_EVALUATE_VALUE_AROUND_TIME INSTEAD.

 Evaluates out of the measurement hash tree \%DATA (created by EA_trace_get_dataref or CA_trace_get_dataref )
 the value of given signal at corresponding time and with corresponding reference value.

=cut

#####################################################################
sub EVAL_evaluate_values_at_time
{

    my $signals_ref = shift;
    my $labels      = shift;

    my ( $label, $time, $operator, $reference, @result );

    S_set_error( "Obsolete function EVAL_evaluate_values_at_time. Please use EVAL_evaluate_value_around_time instead.", 0 );

    unless ( defined($signals_ref) and defined($labels) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VALUES = EVAL_evaluate_values_at_time ( DATA , labels )", 110 );
        return 0;
    }

    $label     = $labels->{'label'};
    $time      = $labels->{'time'};
    $operator  = $labels->{'operator'};
    $reference = $labels->{'reference'};

    S_w2rep(" --> Evaluation of signal $label $operator $reference at $time s\n");

    @result = EVAL_get_values_at_time( $signals_ref, $time, $label );

    return unless @result;

    S_w2rep(" --> Signal value of $label at $time s: $result[0]\n");

    if ( compare_two_values( $result[0], $operator, $reference ) == 1 )
    {
        S_w2rep(" --> Value of signal $label at $time s is correct \n");
        S_set_verdict(VERDICT_PASS);
    }
    else
    {
        S_w2rep(" --> Value of signal $label at $time s is not correct \n");
        S_set_verdict(VERDICT_FAIL);
    }
}

#####################################################################

=head2 EVAL_evaluate_values_in_trace

  $time_point = EVAL_evaluate_values_in_trace ( \%DATA , \%labels );

Evaluates out of the measurement hash tree \%DATA (created by e.g. CA_trace_get_dataref )
if the given signal fulfills the refenrence value within the measurement time.

    \%labels = {
        label => <signal name>,
        operator => <one of: == != >= <= > < MASK>,
        reference => <reference value>,
    }

=cut

#####################################################################
sub EVAL_evaluate_values_in_trace
{

    my $signals_ref = shift;
    my $labels      = shift;

    my ( $label, $operator, $reference, $result, $time_point );

    $label     = $labels->{'label'};
    $operator  = $labels->{'operator'};
    $reference = $labels->{'reference'};

    S_w2rep("Evaluation if signal $label $operator $reference in measurement\n");

    $result = EVAL_get_time_when( $signals_ref, $label, $operator, $reference );

    return unless defined $result;

    if ( $result == -1 )
    {
        S_w2rep("Reference Value of signal $label is not fulfilled \n");
        S_set_verdict(VERDICT_FAIL);
    }
    else
    {
        S_w2rep("Reference value of signal $label is firstly fulfilled at $result s\n");
        S_set_verdict(VERDICT_PASS);
    }

    return $time_point = $result;
}

#####################################################################

=head2 EVAL_evaluate_values_once

    VERDICT = EVAL_evaluate_values_once ( \%MEASURE_DATA , $SIGNAL_LABEL , \@LIST_VALUES_ONCE [, $TIME_MIN [, $TIME_MAX ]] );

   \%MEASURE_DATA     : Signal reference , see example below
   $SIGNAL_LABEL      : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))
   \@LIST_VALUES_ONCE : list with values which %MEASURE_DATA must contain all of them at least once
    $TIME_MIN         : start time in MEASURE_DATA
    $TIME_MAX         : stop time in MEASURE_DATA

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   example for
   $LIST_VALUES_ONCE = [ 0 , 1 ];

=cut

#####################################################################
sub EVAL_evaluate_values_once
{

    my ( $MEASURE_DATA, $SIGNAL_LABEL, $GIVEN_LIST_VALUES_ONCE, $TIME_MIN, $TIME_MAX, ) = @_;

    my ( $time_occurence, @good_values, @bad_values, $value_once_text, $return_verdict, );

    S_w2log( 1, "EVAL_evaluate_values_once \n" );

    unless ( defined($GIVEN_LIST_VALUES_ONCE) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_values_once ( MEASURE_DATA , SIGNAL_LABEL , GIVEN_LIST_VALUES_ONCE [, TIME_MIN [, TIME_MAX ]]  )", 110 );
        return VERDICT_INCONC;
    }

    unless ( ref($GIVEN_LIST_VALUES_ONCE) eq "ARRAY" )
    {
        S_set_error( "! wrong parameter ! GIVEN_LIST_VALUES_ONCE must be Array REFERENCE ( e.g. [ 1,2,3 ] ) SYNTAX: VERDICT = EVAL_evaluate_values_once ( MEASURE_DATA , SIGNAL_LABEL , GIVEN_LIST_VALUES_ONCE [, TIME_MIN [, TIME_MAX ]]  )", 110 );
        return VERDICT_INCONC;
    }

    return VERDICT_NONE if $main::opt_offline;

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $expect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
    my $verdict_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'VERDICT_MARKER'};

    $value_once_text = join( " ", @$GIVEN_LIST_VALUES_ONCE );
    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker once [$value_once_text]" );

    @good_values = ();
    @bad_values  = ();
    foreach my $check_value (@$GIVEN_LIST_VALUES_ONCE)
    {
        $time_occurence = EVAL_get_time_when( $MEASURE_DATA, $SIGNAL_LABEL, "==", $check_value, $TIME_MIN, $TIME_MAX );

        if ( $time_occurence == -1 )
        {
            S_w2log( 1, " EVAL_evaluate_values_once: $SIGNAL_LABEL == $check_value doesnt occur at least once \n" );
            push( @bad_values, $check_value );
        }
        else
        {
            S_w2log( 1, " EVAL_evaluate_values_once: $SIGNAL_LABEL == $check_value at least once\n" );
            push( @good_values, $check_value );
        }
    }

    if (@bad_values)
    {
        foreach (@bad_values)
        {
            S_add2eval_collection( 'OTHER_VALUES', "$detect_marker no expected occurence: $_ " );
        }
        S_add2eval_collection( 'MISMATCH',     "$SIGNAL_LABEL: no expected occurence" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_FAIL );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    else
    {
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_PASS );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
}

=head2 EVAL_evaluate_values_once_above

    VERDICT = EVAL_evaluate_values_once_above ( \%MEASURE_DATA , $SIGNAL_LABEL , $COMPARE_VALUE [, $TIME_MIN [, $TIME_MAX ]] );

   \%MEASURE_DATA     : Signal reference , see example below
   $SIGNAL_LABEL      : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))
   $COMPARE_VALUE     : limit value which MEASURE_DATA must at least once above
    $TIME_MIN         : [optional] start time in MEASURE_DATA
    $TIME_MAX         : [optional] stop time in MEASURE_DATA

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   example for

=cut

#####################################################################
sub EVAL_evaluate_values_once_above
{

    my ( $MEASURE_DATA, $SIGNAL_LABEL, $COMPARE_VALUE, $TIME_MIN, $TIME_MAX, ) = @_;

    my ( $time_1st_occurence, $time_max_occurence, $return_verdict, $highest_value, );

    S_w2log( 1, "EVAL_evaluate_values_once_above \n" );

    unless ( defined($COMPARE_VALUE) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_values_once_above ( MEASURE_DATA ,SIGNAL_LABEL , COMPARE_VALUE [, TIME_MIN [, TIME_MAX ]]  )", 110 );
        return VERDICT_INCONC;
    }

    unless ( ref($COMPARE_VALUE) eq "" )
    {
        S_set_error( "! wrong parameter ! COMPARE_VALUE must be scalar( e.g. 1 ) SYNTAX: VERDICT = EVAL_evaluate_values_once_above ( MEASURE_DATA , SIGNAL_LABEL , COMPARE_VALUE [, TIME_MIN [, TIME_MAX ]]  )", 114 );
        return VERDICT_INCONC;
    }

    return VERDICT_NONE if $main::opt_offline;

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $expect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
    my $verdict_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'VERDICT_MARKER'};

    ### ----------------------------------------------------------------------------------------

    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker once above $COMPARE_VALUE" );

    $time_1st_occurence = EVAL_get_time_when( $MEASURE_DATA, $SIGNAL_LABEL, ">", $COMPARE_VALUE, $TIME_MIN, $TIME_MAX );

    if ( $time_1st_occurence == -1 )
    {
        S_add2eval_collection( 'OTHER_VALUES', "$detect_marker couldn't get value" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_FAIL );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }

    $time_max_occurence = EVAL_get_time_when( $MEASURE_DATA, $SIGNAL_LABEL, "MAX", 9999, $TIME_MIN, $TIME_MAX );

    ($highest_value) = EVAL_get_value_around_time( $MEASURE_DATA, $time_max_occurence, $SIGNAL_LABEL );

    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker MAXIMUM " . sprintf( "%.3f", $highest_value ) );

    if ( compare_two_values( $highest_value, '>', $COMPARE_VALUE ) )
    {
        S_w2rep( " EVAL_evaluate_values_once_above: $SIGNAL_LABEL > $COMPARE_VALUE fulfilled (1st at $time_1st_occurence; MAX=" . sprintf( "%.3f", $highest_value ) . " at " . sprintf( "%.3f", $time_max_occurence ) . ")\n" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_PASS );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
}

=head2 EVAL_evaluate_values_once_below

    VERDICT = EVAL_evaluate_values_once_below ( \%MEASURE_DATA , $SIGNAL_LABEL , $COMPARE_VALUE [, $TIME_MIN [, $TIME_MAX ]] );

   \%MEASURE_DATA     : Signal reference , see example below
   $SIGNAL_LABEL      : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))
   $COMPARE_VALUE     : limit value which MEASURE_DATA must at least once below
    $TIME_MIN         : [optional] start time in MEASURE_DATA
    $TIME_MAX         : [optional] stop time in MEASURE_DATA

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   example for

=cut

#####################################################################
sub EVAL_evaluate_values_once_below
{

    my ( $MEASURE_DATA, $SIGNAL_LABEL, $COMPARE_VALUE, $TIME_MIN, $TIME_MAX, ) = @_;

    my ( $time_1st_occurence, $time_min_occurence, $return_verdict, $lowest_value, );

    S_w2log( 1, "EVAL_evaluate_values_once_below \n" );

    unless ( defined($COMPARE_VALUE) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_values_once_below ( MEASURE_DATA , SIGNAL_LABEL , COMPARE_VALUE [, TIME_MIN [, TIME_MAX ]]  )", 110 );
        return VERDICT_INCONC;
    }

    unless ( ref($COMPARE_VALUE) eq "" )
    {
        S_set_error( "! wrong parameter ! COMPARE_VALUE must be scalar( e.g. 1 ) SYNTAX: VERDICT = EVAL_evaluate_values_once_below ( MEASURE_DATA , SIGNAL_LABEL , COMPARE_VALUE [, TIME_MIN [, TIME_MAX ]]  )", 114 );
        return VERDICT_INCONC;
    }

    return VERDICT_NONE if $main::opt_offline;

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in separated lines per cell

    my $expect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
    my $verdict_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'VERDICT_MARKER'};

    ### ----------------------------------------------------------------------------------------

    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker once below $COMPARE_VALUE" );

    $time_1st_occurence = EVAL_get_time_when( $MEASURE_DATA, $SIGNAL_LABEL, "<", $COMPARE_VALUE, $TIME_MIN, $TIME_MAX );

    if ( $time_1st_occurence == -1 )
    {
        S_add2eval_collection( 'OTHER_VALUES', "$detect_marker couldn't get value" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_FAIL );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }

    $time_min_occurence = EVAL_get_time_when( $MEASURE_DATA, $SIGNAL_LABEL, "MIN", 9999, $TIME_MIN, $TIME_MAX );

    ($lowest_value) = EVAL_get_value_around_time( $MEASURE_DATA, $time_min_occurence, $SIGNAL_LABEL );

    S_add2eval_collection( 'OTHER_VALUES', "$detect_marker MINIMUM " . sprintf( "%.3f", $lowest_value ) );

    if ( compare_two_values( $lowest_value, '<', $COMPARE_VALUE ) )
    {
        S_w2rep( " EVAL_evaluate_values_once_below: $SIGNAL_LABEL < $COMPARE_VALUE fulfilled (1st at $time_1st_occurence; MIN = " . sprintf( "%.3f", $lowest_value ) . " at " . sprintf( "%.3f", $time_min_occurence ) . ")\n" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_PASS );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
}

=head2 EVAL_evaluate_values_never

    VERDICT = EVAL_evaluate_values_never ( \%MEASURE_DATA , $SIGNAL_LABEL , \@LIST_VALUES_NEVER [, $TIME_MIN [, $TIME_MAX ]] );

   \%MEASURE_DATA     : Signal reference , see example below
   $SIGNAL_LABEL      : signal to be checked in MEASURE_DATA (can be also out of LabCar-Mapping (model-labels & stimuli-labels))
   \@LIST_VALUES_NEVER : list with values which %MEASURE_DATA must never contain each of them
    $TIME_MIN         : start time in MEASURE_DATA
    $TIME_MAX         : stop time in MEASURE_DATA

   example for
   $MEASURE_DATA = {
                  TIME_1 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_2 => {                             SIG_3 => VAL_2_3  } ,
                  TIME_3 => { SIG_1 = 0  , SIG_2 = 0 } ,
                  TIME_4 => {                             SIG_3 => VAL_4_3  } ,
                  TIME_5 => { SIG_1 = 0  , SIG_2 = 1 } ,
                  TIME_6 => {                             SIG_3 => VAL_6_3  } ,
                  TIME_7 => { SIG_1 = 0  , SIG_2 = 0 } ,
                };

   example for
   $LIST_VALUES_NEVER = [ 0 , 1 ];

=cut

#####################################################################
sub EVAL_evaluate_values_never
{

    my ( $MEASURE_DATA, $SIGNAL_LABEL, $LIST_VALUES_NEVER, $TIME_MIN, $TIME_MAX, ) = @_;

    my ( $time_occurence, @good_values, @bad_values, $value_never_text, $return_verdict, );

    S_w2log( 1, "EVAL_evaluate_values_never \n" );

    unless ( defined($LIST_VALUES_NEVER) )
    {
        S_set_error( "! too less parameters ! SYNTAX: VERDICT = EVAL_evaluate_values_never ( MEASURE_DATA , SIGNAL_LABEL , LIST_VALUES_NEVER [, TIME_MIN [, TIME_MAX ]]  )", 110 );
        return VERDICT_INCONC;
    }

    unless ( ref($LIST_VALUES_NEVER) eq "ARRAY" )
    {
        S_set_error( "! wrong parameter ! LIST_VALUES_NEVER must be Array REFERENCE ( e.g. [ 1,2,3 ] ) SYNTAX: VERDICT = EVAL_evaluate_values_once ( MEASURE_DATA , SIGNAL_LABEL , LIST_VALUES_NEVER [, TIME_MIN [, TIME_MAX ]]  )", 110 );
        return VERDICT_INCONC;
    }

    return VERDICT_NONE if $main::opt_offline;

    #### for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell

    my $expect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    my $detect_marker  = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
    my $verdict_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'VERDICT_MARKER'};

    ### ----------------------------------------------------------------------------------------

    $value_never_text = join( " ", @$LIST_VALUES_NEVER );
    S_add2eval_collection( 'OTHER_VALUES', "$expect_marker never [$value_never_text]" );

    @good_values = ();
    @bad_values  = ();
    foreach my $check_value (@$LIST_VALUES_NEVER)
    {
        $time_occurence = EVAL_get_time_when( $MEASURE_DATA, $SIGNAL_LABEL, "==", $check_value, $TIME_MIN, $TIME_MAX );

        if ( $time_occurence != -1 )
        {
            S_w2log( 1, " EVAL_evaluate_values_never: $SIGNAL_LABEL != $check_value was not always fullfilled \n" );
            push( @bad_values, $check_value );
        }
        else
        {
            S_w2log( 1, " EVAL_evaluate_values_never: $SIGNAL_LABEL != $check_value was always fullfilled\n" );
            push( @good_values, $check_value );
        }
    }

    if (@bad_values)
    {
        foreach (@bad_values)
        {
            S_add2eval_collection( 'OTHER_VALUES', "$detect_marker NOK - forbidden occurence: $_ " );
        }
        S_add2eval_collection( 'MISMATCH',     "$SIGNAL_LABEL - forbidden occurence" );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_FAIL );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    else
    {
        S_add2eval_collection( 'OTHER_VALUES', "$detect_marker OK - never values not occured " );
        S_add2eval_collection( 'OTHER_VALUES', "$verdict_marker " . VERDICT_PASS );
        S_add2eval_collection( 'OTHER_VALUES', "" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
}

=head2 EVAL_get_trace_eval_params

    ($tcpar_Trace_GetTime_href, $tcpar_Trace_EvalTime_href, $tcpar_Trace_EvalSignal_href)
    														= EVAL_get_trace_eval_params($evalType [, $projectConstLabel]);

I<B<Description:>> Obtain parameters from test case for EVAL_evaluate_trace_sequence, EVAL_evaluate_trace_times, and EVAL_evaluate_trace_signals

	Example Parameters in DOORS:
	
	1) Define time stamps based on signal values
	   By giving always the previous time stamp as 'Tref', a sequence can be defined

		_SPI_GetTime_T1             = @('T0', 'SignalX', '==', '4') 
		            T1 --> is the first time in log from T0 (measurement start) to end of measurement where SignalX has the value 4
		_SPI_GetTime_T2             = @('T1', 'SignalY', '>=', '5')
		_SPI_GetTime_T3             = @('T2', 'SignalY', '<', '4')
		_SPI_GetTime_T1_Docu        = 'Short test documentation'
	
	2) Define trace time evaluations
		_SPI_EvalTime0_T2_Docu      = 'Short test documetation' # --> will be printed with S_teststep if GEN_EVAL_evaluate_trace_times is used for eval                         
		                               e.g. 'check if time (T2�T1) is between 10 ms and 162 ms (OP used: > 26 and < 162)'
		_SPI_EvalTime0_T1           = @('T2', 'OP1',20, 'OP2', 162,)
	                T1 --> is the start point in time for the evaluation
	                T2 --> is the end point in time for the evaluation
	                OP1 --> is the first compare operator for the length of the validation interval T2-T1
	                20 --> is the first expected value for the interval T2-T1
	                            T2-T1 == 20 (OP1: ==), T2-T1 < 20 (OP1: <)... 
	                OP2 --> is the second compare operator for the length of the validation interval T2-T1
	                162 --> is the second expected value for the interval T2-T1
	                            T2-T1 == 162 (OP2: ==), T2-T1 > 162 (OP2: >)...                
	            
	            Both conditions (OP1 and OP2) must be fulfilled for a 'VERDICT_PASS'!
	
	3) Define signal evaluations to be done at the time stamps defined above
	   It can be validated how often the signal value fulfills a specified condition within the specified time range
	   E.g.: How often does SignalX have the value 1 in the time from 20ms to 40ms?
					_SPI_EvalSignal0_T1_Docu    = 'Short test documetation' # --> will be printed with S_teststep if EVAL_evaluate_trace_signals is used for eval
		                               e.g. 'check from time T1 over 1750 ms if value frome SPI_GetTime_T2 occurs 20 times'
					_SPI_EvalSignal0_T1         = @(1750, 'SMA560:DE_FOR_TEST:MOSI', 'OP1', 'V_T2', 'OP2',20)
		            T1 --> is the start point in time for the signal evaluation
		            1750 --> is the offset in ms to the start point of the validation: Validate from T1 to T1 + 1750ms
		                        Alternatively 'I_T2T3' could be given, which would be the time from T2 to T3
		            'SMA560:DE_FOR_TEST:MOSI' --> is the signal label
		            'OP1' --> is a place holder for the compare operator of the signal value
		            'V_T2' --> is the expected value that will be applied to the detected value with the compare operator 'OP1'
		                         It means value of the signal at point in time T2
		                         It can also be an absolute value like '4'
		            'OP2' --> is the operator for comparing the number of detected occurrences of the specified signal value condition
		            20 --> is the number of expected occurrences of the specified signal value condition

I<B<Return value(s):>> $tcpar_Trace_GetTime_href, $tcpar_Trace_EvalTime_href, $tcpar_Trace_EvalSignal_href
                        --> the returned hash references can be used as inputs for: EVAL_evaluate_trace_sequence, EVAL_evaluate_trace_times, EVAL_evaluate_trace_signals

I<B<Verdict:>>  none

I<B<Error:>> If the mandatory parameter is missing.

I<B<Example:>> EVAL_get_trace_eval_params('SPI');
I<B<Example:>> EVAL_get_trace_eval_params('FD');

I<B<Example for the mapping File:>>

=cut

sub EVAL_get_trace_eval_params {

    my $evalType = shift;
    my $projectConstLabel = shift;

    return unless(S_checkFunctionArguments ( 'EVAL_get_trace_eval_params($evalType [, $projectConstLabel])', ($evalType, $projectConstLabel) ));

    my ($tcpar_Trace_GetTime_href, $tcpar_Trace_EvalTime_href, $tcpar_Trace_EvalSignal_href);

    for ( my $timeStampNumber = 1 ; $timeStampNumber < 99 ; $timeStampNumber++ ) {
        # Get array with LogStart, Signal, compare operator, and expected value for time stamp $timeStampNumber
        my @tcpar_Trace_GetTime = S_read_testcase_parameter( "_$evalType\_GetTime_T" . $timeStampNumber );
        last unless(@tcpar_Trace_GetTime); # break out of loop if not defined
		# Store evaluation type
        $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'EvalType'} = $evalType;

        # Get documentation for time stamp $timeStampNumber
        $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'Docu'} = S_read_testcase_parameter( "_$evalType\_GetTime_T" . $timeStampNumber . '_Docu' );
        # Get time stamp number for Log Start
        $tcpar_Trace_GetTime[0] =~ m/T(\d+)/;
        $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'LogStartTimeStamp'} = $1;
        # Get time stamp signal name
        $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'SignalLabel'} = $tcpar_Trace_GetTime[1];
        # Get time stamp operator
        $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'CompareOperator'} = $tcpar_Trace_GetTime[2];
        # Get time stamp signal name

        # Get expected value
            # if same value is mapped to data in project const take that signal by using of a label
            # else directly take the value from parameters
        if( S_check_label( $tcpar_Trace_GetTime[3] , [ $projectConstLabel ] ) ) {
            $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'ExpectedSignalValue'}
                = S_get_label( $tcpar_Trace_GetTime[3] , [ $projectConstLabel ] );
        }
        else {
            $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'ExpectedSignalValue'} = $tcpar_Trace_GetTime[3];
        }

		if ( scalar @tcpar_Trace_GetTime > 4){
			# Get time stamp signal name
			$tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'SignalLabel2'} = $tcpar_Trace_GetTime[4];
			# Get time stamp operator
			$tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'CompareOperator2'} = $tcpar_Trace_GetTime[5];

			# Get expected value
				# if same value is mapped to data in project const take that value
				# else directly take the value from parameters
            if( S_check_label( $tcpar_Trace_GetTime[6] , [ $projectConstLabel ] ) ) {
                $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'ExpectedSignalValue2'}
                    = S_get_label( $tcpar_Trace_GetTime[6] , [ $projectConstLabel ] );
            }
            else {
                $tcpar_Trace_GetTime_href -> {$timeStampNumber} -> {'ExpectedSignalValue2'} = $tcpar_Trace_GetTime[6];
            }
		}

        # get evaluation information for time stamp
        # EVAL TIME
        for ( my $evalNumber = 0 ; $evalNumber < 99 ; $evalNumber++ )
        {
            # get eval start time, eval operator 1, eval expected value 1, eval operator 2, expected value 2
            my @tcpar_Trace_EvalTime = S_read_testcase_parameter( "_$evalType\_EvalTime" . $evalNumber . '_T' . $timeStampNumber );
            last unless(@tcpar_Trace_EvalTime);  # break out of loop if not defined

			# Store evaluation type
			$tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'EvalType'} = $evalType;

            # get docu for time eval $evalNumber of time stamp $timeStampNumber
            $tcpar_Trace_EvalTime_href -> {$timeStampNumber}-> {$evalNumber} -> {'Docu'} = S_read_testcase_parameter( "_$evalType\_EvalTime" . $evalNumber . '_T' . $timeStampNumber . '_Docu' );
 
            $tcpar_Trace_EvalTime[0] =~ m/T(\d+)/;
            $tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'StartTimeStamp'}     = $1;

            $tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'CompareOperator1'}   = $tcpar_Trace_EvalTime[1];
	        if( S_check_label( $tcpar_Trace_EvalTime[2] , [ $projectConstLabel ] ) ) {
	            $tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedValue1_ms'}
	                = S_get_label( $tcpar_Trace_EvalTime[2] , [ $projectConstLabel ] );
	        }
	        else {
	            $tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedValue1_ms'}  = $tcpar_Trace_EvalTime[2];
	        }

            $tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'CompareOperator2'}   = $tcpar_Trace_EvalTime[3];
 	        if( S_check_label( $tcpar_Trace_EvalTime[4] , [ $projectConstLabel ] ) ) {
	            $tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedValue2_ms'}
	                = S_get_label( $tcpar_Trace_EvalTime[4] , [ $projectConstLabel ] );
	        }
	        else {
	            $tcpar_Trace_EvalTime_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedValue2_ms'}  = $tcpar_Trace_EvalTime[4];
	        }
        }

        # EVAL SIGNAL
        for ( my $evalNumber = 0 ; $evalNumber < 99 ; $evalNumber++ )
        {
            # get array with time interval, signal label, operator value , expected value, operator number of times, number of expected times from parameters
            my @tcpar_Trace_EvalSignal = S_read_testcase_parameter( "_$evalType\_EvalSignal" . $evalNumber . '_T' . $timeStampNumber );
            last unless(@tcpar_Trace_EvalSignal);  # break out of loop if not defined

			# Store evaluation type
			$tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'EvalType'} = $evalType;

            $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'Docu'} = S_read_testcase_parameter( "_$evalType\_EvalSignal" . $evalNumber . '_T' . $timeStampNumber . '_Docu' );
            $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ValidationTime_ms'}    = $tcpar_Trace_EvalSignal[0];
            $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'SignalLabel'}          = $tcpar_Trace_EvalSignal[1];
            $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'CompareOperatorValue'} = $tcpar_Trace_EvalSignal[2];

            if( S_check_label( $tcpar_Trace_EvalSignal[3] , [ $projectConstLabel ] ) ) {
                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedSignalValue'}
                    = S_get_label( $tcpar_Trace_EvalSignal[3] , [ $projectConstLabel ] );
            }
            else {
                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedSignalValue'} = $tcpar_Trace_EvalSignal[3];
            }

			if ( scalar @tcpar_Trace_EvalSignal > 6){
				$tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'SignalLabel2'}          = $tcpar_Trace_EvalSignal[4];
				$tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'CompareOperatorValue2'} = $tcpar_Trace_EvalSignal[5];

	            if( S_check_label( $tcpar_Trace_EvalSignal[6] , [ $projectConstLabel ] ) ) {
	                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedSignalValue2'}
	                    = S_get_label( $tcpar_Trace_EvalSignal[6] , [ $projectConstLabel ] );
	            }
	            else {
	                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedSignalValue2'} = $tcpar_Trace_EvalSignal[6];
	            }

				$tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'CompareOperatorCount'}  = $tcpar_Trace_EvalSignal[7];
	            if( S_check_label( $tcpar_Trace_EvalSignal[8] , [ $projectConstLabel ] ) ) {
	                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedCount'}
	                    = S_get_label( $tcpar_Trace_EvalSignal[8] , [ $projectConstLabel ] );
	            }
	            else {
	                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedCount'} = $tcpar_Trace_EvalSignal[8];
	            }
			}
			else {
				$tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'CompareOperatorCount'} = $tcpar_Trace_EvalSignal[4];
	            if( S_check_label( $tcpar_Trace_EvalSignal[5] , [ $projectConstLabel ] ) ) {
	                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedCount'}
	                    = S_get_label( $tcpar_Trace_EvalSignal[5] , [ $projectConstLabel ] );
	            }
	            else {
	                $tcpar_Trace_EvalSignal_href -> {$timeStampNumber} -> {$evalNumber} -> {'ExpectedCount'} = $tcpar_Trace_EvalSignal[5];
	            }

			}
        }
    }

    return ($tcpar_Trace_GetTime_href, $tcpar_Trace_EvalTime_href, $tcpar_Trace_EvalSignal_href);
}

=head2 EVAL_evaluate_trace_sequence

    my ($verdict, $sequence_Time_Value_href) = EVAL_evaluate_trace_sequence($traceData_href, $trace_GetTime_href);

I<B<Description:>> Validate given sequence in given mesurement href

    Validate a given command sequence and get the time stamp value as well as signal value for each command (Parameter: $trace_GetTime_href)
    
    Parameter description:
    
    $trace_GetTime_href = {
                                '1' =>  # Time stamp number -> time stamp T1
                                       {'Docu' => 'Short test docu',
                                        'LogStartTimeStamp' => '0',    # Time in SPI trace where to start searching for the specified time stamp									    
										'SignalLabe' => '',            # Signal label which shall have 'ExpectedSignalValue' at time stamp
                                        'ExpectedSignalValue' => '1',  # Expected value for signal label at time stamp
                                        'CompareOperator' => '==',     # compare operator for detected and expected signal value
                                        },
                                '2' =>  # Time stamp number -> time stamp T2
                                       {'Docu' => 'Short test docu', 
									    'LogStartTimeStamp' => '0',    # Time in SPI trace where to start searching for the specified time stamp
									    'SignalLabel' => '',           # Signal label which shall have 'ExpectedSignalValue' at time stamp
                                        'ExpectedSignalValue' => '1',  # Expected value for signal label at time stamp
                                        'CompareOperator' => '==',     # compare operator for detected and expected signal value
                                        'SignalLabel2' => '',           # Signal2 label which shall have 'ExpectedSignalValue' at time stamp
                                        'ExpectedSignalValue2' => '1', # Expected value2 for signal label at time stamp
                                        'CompareOperator2' => '==',    # compare operator2 for detected and expected signal value
                                        },
                                '3' => { # Next time stamp number -> time stamp T3
                                    #...
                                        },
                            }
             

I<B<Return value(s):>> $verdict ('PASS' or 'FAIL')
                       $sequence_Time_Value_href = {
                                                       '1' => # Time stamp number
                                                                {
                                                                    'Time' => xx,
                                                                    'SignalLabel' => 'Signal',
                                                                    'SignalValue' => 'Value',
                                                                },
                                                       '2' => # Time stamp number
                                                                {
                                                                    'Time' => xx,
                                                                    'SignalLabel' => 'Signal',
                                                                    'SignalValue' => 'Value',
                                                                    'SignalLabel2' => 'Signal2',
                                                                    'SignalValue2' => 'Value2',
                                                                },
                                                       '3' => # next time stamp...
                                                   }

I<B<Verdict:>>  none

I<B<Error:>> Any mandatory parameter is missing
			 'SignalLabel2' is defined without defining CompareOperator2|ExpectedSignalValue2 for it.

I<B<Example:>> EVAL_evaluate_trace_sequence('');

I<B<Example for the mapping File:>>

=cut

sub EVAL_evaluate_trace_sequence {

    my $traceData_href        = shift;
    my $trace_GetTime_href    = shift;

    return unless(S_checkFunctionArguments ( 'EVAL_evaluate_trace_sequence($traceData_href, $trace_GetTime_href)', ($traceData_href, $trace_GetTime_href)));

    my $numberOfTimeStamps = keys %{$trace_GetTime_href};
    my $sequence_Time_Value_href;
    my $verdict = 'PASS';

	S_teststep( "--- Evaluate trace sequence ---", 'AUTO_NBR' );

    foreach my $timeStampNumber ( 1 .. $numberOfTimeStamps ) {
		my $evalType = $trace_GetTime_href->{$timeStampNumber}->{'EvalType'};
		my $testStepName = ('GetTime_TS:'.$timeStampNumber.'_TYPE:'.$evalType);

        if ( $trace_GetTime_href->{$timeStampNumber}->{'ExpectedSignalValue'} =~ /V_T(\d+)/ ) {
        	if(defined $sequence_Time_Value_href -> {$1}){
        		$trace_GetTime_href->{$timeStampNumber}->{'ExpectedSignalValue'} = $sequence_Time_Value_href -> {$1} -> {'SignalValue'};
        	}
        	else{
        		S_set_error("For timestamp $timeStampNumber, expected signal value for ".
        					$trace_GetTime_href->{$timeStampNumber}->{'SignalLabel'}.
        					"is the value from timestamp $1.\n".
        					"This timestamp is not available - only give timestamps from before the current timestamp!");
        		next;
        	}
        }
        my $logStartTimeStampNumber = $trace_GetTime_href->{$timeStampNumber}->{'LogStartTimeStamp'};

		my $time_LogStart;
		if(defined $sequence_Time_Value_href -> {$logStartTimeStampNumber}){
			$time_LogStart = $sequence_Time_Value_href -> {$logStartTimeStampNumber} -> {'Time'} + 0.001;
		}
		else{
			S_w2log(2, "Set log start time stamp to first time stamp in trace\n");
			foreach my $timeStamp (sort {$a <=> $b} keys %{$traceData_href}){
				$time_LogStart = $timeStamp;
				last;
			}
		}

		my $signalLabel = $trace_GetTime_href->{$timeStampNumber}->{'SignalLabel'};
		my $operator = $trace_GetTime_href->{$timeStampNumber}->{'CompareOperator'};
		my $compare_value = $trace_GetTime_href->{$timeStampNumber}->{'ExpectedSignalValue'};

		my $signalLabel2 = $trace_GetTime_href->{$timeStampNumber}->{'SignalLabel2'};
		my $operator2 = $trace_GetTime_href->{$timeStampNumber}->{'CompareOperator2'};
		my $compare_value2 = $trace_GetTime_href->{$timeStampNumber}->{'ExpectedSignalValue2'};

		if ( exists $trace_GetTime_href->{$timeStampNumber}->{'SignalLabel2'} ) {
			unless (defined $signalLabel2 and defined $operator2 and defined $compare_value2 ){
				S_set_error("Not all necessary parameter defined (needed are: SignalLabel2|CompareOperator2|ExpectedSignalValue2)!");
				next;
			}

			S_teststep_2nd_level($trace_GetTime_href->{$timeStampNumber}->{'Docu'}."\n"."Get timestamp T$timeStampNumber when"." ".
				   "$signalLabel $operator $compare_value AND $signalLabel2 $operator2 $compare_value2", 'AUTO_NBR', $testStepName );
			my $times_aref = EVAL_get_time_multi_condition( $traceData_href,
												{'COND_LABEL_1' => {'SIGNAL_LABEL' => $signalLabel ,
																    'OPERATOR' => $operator,
																    'COMPARE_VALUE' => $compare_value},
												 'COND_LABEL_2' => {'SIGNAL_LABEL' => $signalLabel2 ,
																    'OPERATOR' => $operator2,
																    'COMPARE_VALUE' => $compare_value2}
												}, $time_LogStart );
			if(@$times_aref){ # at least one value found
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'} = $times_aref->[0];
				S_set_verdict(VERDICT_PASS);
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'SignalLabel'} = $signalLabel;
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'SignalValue'} = EVAL_get_value_around_time( $traceData_href, $sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'}, $signalLabel );
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'SignalLabel2'} = $signalLabel2;
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'SignalValue2'} = EVAL_get_value_around_time( $traceData_href, $sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'}, $signalLabel2 );
			}
			else{
	            S_set_verdict(VERDICT_FAIL);
	            $verdict = 'FAIL';
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'} = 'not found';
			}
		}
		else {
			S_teststep_2nd_level($trace_GetTime_href->{$timeStampNumber}->{'Docu'}."\n"."Get timestamp T$timeStampNumber when"." ".
				   "$signalLabel $operator $compare_value", 'AUTO_NBR', $testStepName );

			$sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'} = EVAL_get_time_when(
																			$traceData_href,
																			$signalLabel,
																			$operator,
																			$compare_value,
																			$time_LogStart
			);

			if ( $sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'} == -1 ) {    # SPI condition not matched?
				S_set_verdict(VERDICT_FAIL);
				$verdict = 'FAIL';
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'} = 'not found';
			}
			else {
				S_set_verdict(VERDICT_PASS);
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'SignalLabel'} = $signalLabel;
				$sequence_Time_Value_href -> {$timeStampNumber} -> {'SignalValue'} = EVAL_get_value_around_time( $traceData_href, $sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'}, $signalLabel );
			}
		}

		S_teststep_expected("T$timeStampNumber >= ".$time_LogStart." ms", $testStepName);
		S_teststep_detected("T$timeStampNumber = ".$sequence_Time_Value_href -> {$timeStampNumber} -> {'Time'}." ms", $testStepName);
    }

    return ($verdict, $sequence_Time_Value_href);
}    # end of EVAL_evaluate_trace_sequence

=head2 EVAL_evaluate_trace_times

    EVAL_evaluate_trace_times($traceData_href, $sequence_times_values_href, $trace_EvalTime_href);

I<B<Description:>> Validate times within sequence of given mesurement href

    Validate timings between the commands of the command sequence (Parameter: $trace_EvalTime_href)
    Call EVAL_evaluate_trace_sequence first to get the times and values of the commands in the sequence. 

    Parameter description:                            
    $trace_EvalTime_href =   {
                               '1' => # Time stamp for validation: T1
                                       {'0' => { # Eval number
                                                 'Docu' => 'this is for evaluating...', # Text will be printed as S_teststep
                                                 'StartTimeStamp' => '2',     # Delta time from T1 to T2 will be validated 
                                                 'CompareOperator1' => '>',   # Delta time shall be > 'ExpectedValue1_ms'
                                                 'ExpectedValue1_ms' => '12', # Expected value for comparing delta time with 'CompareOperator1'
                                                 'CompareOperator2' => '<',   # Delta time shall be > 'ExpectedValue2_ms'
                                                 'ExpectedValue2_ms' => '20', # Expected value for comparing delta time with 'CompareOperator2'
                                               },
                                        
                                        '1' => { # next eval number
                                    
                                               },
                                        },
                                '2' => # next time stamp number
                                        {
                                            
                                        },
                           }

I<B<Return value(s):>> $verdict ('PASS' or 'FAIL')

I<B<Verdict:>>  none

I<B<Error:>> If the mandatory parameter is missing.

I<B<Example:>> EVAL_evaluate_trace_times('');

I<B<Example for the mapping File:>>

=cut

sub EVAL_evaluate_trace_times {

    my $traceData_href             = shift;
    my $sequence_times_values_href = shift;
    my $trace_EvalTime_href        = shift;

    return unless(S_checkFunctionArguments ( 'EVAL_evaluate_trace_times($traceData_href, $sequence_times_values_href, $trace_EvalTime_href)',
    				($traceData_href, $sequence_times_values_href, $trace_EvalTime_href)));

    my $verdict = 'VERDICT_PASS';
    my $numberOfTimeStamps = keys %{$sequence_times_values_href};

	S_teststep( "--- Evaluate TIME differences ---", 'AUTO_NBR' );

    foreach my $timeStampNumber ( 1 .. $numberOfTimeStamps )
    {
        foreach my $evalNumber ( sort { $a <=> $b } keys %{$trace_EvalTime_href -> {$timeStampNumber}} )
        {
            # Evaluate delta time
            my $evalStartTime  = $trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'StartTimeStamp'};
            my $deltatime = $sequence_times_values_href->{$evalStartTime}->{'Time'} - $sequence_times_values_href->{$timeStampNumber}->{'Time'};

            my $thisVerdict = EVAL_evaluate_value( "Delta time", $deltatime, $trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperator1'}, $trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedValue1_ms'} );
            $verdict = $thisVerdict if($thisVerdict eq 'VERDICT_FAIL');

            $thisVerdict = EVAL_evaluate_value( "Delta time", $deltatime, $trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperator2'}, $trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedValue2_ms'} );
            $verdict = $thisVerdict if($thisVerdict eq 'VERDICT_FAIL');

			my $evalType = $trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber} -> {'EvalType'};
			my $testStepName = ('TimeEval_EVAL:'.$evalNumber.'_TS:'.$timeStampNumber.'_TYPE:'.$evalType);
            S_teststep_2nd_level( $trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'Docu'}." ", 'AUTO_NBR', $testStepName );
            S_teststep_expected("(T$evalStartTime-T$timeStampNumber)"." ".$trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperator1'}." ".$trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedValue1_ms'}.
								" "."AND"." ".
								"(T$evalStartTime-T$timeStampNumber)"." ".$trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperator2'}." ".$trace_EvalTime_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedValue2_ms'}, $testStepName);
            S_teststep_detected($deltatime, $testStepName);
        }
    }

    return $verdict;
}    # end of EVAL_evaluate_trace_times

=head2 EVAL_evaluate_trace_signals

    EVAL_evaluate_trace_signals($traceData_href, $sequence_time_value_href, $trace_EvalSignal_href]);

I<B<Description:>> Validate occurence of ceratain signal values in given mesurement href

    Validate signal values and signal occurrences within the command sequence (Parameter: $trace_EvalSignal_href)
    Call GEN_EVAL_trace_sequence first to get the times and values of the commands in the sequence.     
    Parameter description:
    

    $trace_EvalSignal_href = {
                               '1' => # Time stamp for validation: T1
                                       {'0' => { # Eval number
                                                 'Docu' => 'this is for evaluating...', # Text will be printed as S_teststep
                                                 'ValidationTime_ms' => '2',  # Signal values will be validated in interval from T1 to T1 + 2ms
                                                 #'ValidationTime_ms' => 'I_T1T8',  # validation period is equal to time interval from T1 to T8
                                                 'SignalLabel' => '>',   # Delta time shall be > 'ExpectedValue1_ms'
                                                 'CompareOperatorValue' => '12', # Expected value for comparing delta time with 'CompareOperator1'
                                                 'ExpectedSignalValue' => '<',   # Delta time shall be > 'ExpectedValue2_ms'
                                                 'CompareOperatorCount' => '20', # Expected value for comparing delta time with 'CompareOperator'
                                                 'ExpectedCount' => '20', # Expected value for comparing delta time with 'CompareOperator'
                                               },
                                       {'1' => { # Eval number
                                                 'Docu' => 'this is for evaluating...', # Text will be printed as S_teststep
                                                 'ValidationTime_ms' => '2',  # Signal values will be validated in interval from T1 to T1 + 2ms
                                                 #'ValidationTime_ms' => 'I_T1T8',  # validation period is equal to time interval from T1 to T8
                                                 'SignalLabel' => '>',   # Delta time shall be > 'ExpectedValue1_ms'
                                                 'CompareOperatorValue' => '12', # Expected value for comparing delta time with 'CompareOperator1'
                                                 'ExpectedSignalValue' => '<',   # Delta time shall be > 'ExpectedValue1_ms'
                                                 'SignalLabel2' => '>',   # Delta time shall be > 'ExpectedValue2_ms'
                                                 'CompareOperatorValue2' => '12', # Expected value for comparing delta time with 'CompareOperator2'
                                                 'ExpectedSignalValue2' => '<',   # Delta time shall be > 'ExpectedValue2_ms'
                                                 'CompareOperatorCount' => '20', # Expected value for comparing delta time with 'CompareOperator'
                                                 'ExpectedCount' => '20', # Expected value for comparing delta time with 'CompareOperator'
                                               },                                     
                                        '2' => { # next eval number
                                    
                                               },
                                        },
                                '2' => # next time stamp number
                                        {
                                            
                                        },
                            }
             

I<B<Return value(s):>> $verdict ('PASS' or 'FAIL')

I<B<Verdict:>>  none

I<B<Error:>> If the mandatory parameter is missing.

I<B<Example:>> EVAL_evaluate_trace_signals('');

I<B<Example for the mapping File:>>

=cut

sub EVAL_evaluate_trace_signals {

    my $traceData_href             = shift;
    my $sequence_time_value_href   = shift;
    my $trace_EvalSignal_href      = shift;

    return unless(S_checkFunctionArguments ( 'EVAL_evaluate_trace_signals($traceData_href, $sequence_time_value_href, $trace_EvalSignal_href)',
    				($traceData_href, $sequence_time_value_href, $trace_EvalSignal_href) ));

    my $verdict = 'VERDICT_PASS';
    my $numberOfTimeStamps = keys %{$sequence_time_value_href};

	S_teststep( "--- Evaluate SIGNAL->VALUE occurrances ---", 'AUTO_NBR' );

    foreach my $timeStampNumber ( 1 .. $numberOfTimeStamps )
    {

        # Check and count signal value occurrence
        foreach my $evalNumber ( sort { $a <=> $b } keys %{$trace_EvalSignal_href -> {$timeStampNumber}} ) {
            my $signalValueCount = 0;
            if ( $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedSignalValue'} =~ /V_T(\d+)/ ) {
                $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedSignalValue'} = $sequence_time_value_href->{$1}->{'SignalValue'};
            }
            my $timeLogStart = $sequence_time_value_href->{$timeStampNumber}->{'Time'};
			my $timeLogStart_teststep = $timeLogStart;
            if ( $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ValidationTime_ms'} =~ /I_T(\d+)T(\d+)/ ) {
                $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ValidationTime_ms'} = abs( $sequence_time_value_href->{$1}->{'Time'} - $sequence_time_value_href->{$2}->{'Time'} );
            }

            my $timeLogEnd = $timeLogStart + $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ValidationTime_ms'};
            my $validationInterval = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ValidationTime_ms'};

			my $signalLabel = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'SignalLabel'};
			my $compareOperatorValue = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperatorValue'};
			my $expectedSignalValue = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedSignalValue'};
			my $signalLabel2 = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'SignalLabel2'};
			my $compareOperatorValue2 = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperatorValue2'};
			my $expectedSignalValue2 = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedSignalValue2'};

			if ( exists $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'SignalLabel2'} ) {
				unless (defined $signalLabel2 and defined $compareOperatorValue2 and defined $expectedSignalValue2 ){
					S_set_error("Not all necessary parameter defined (needed are: SignalLabel2|CompareOperator2|ExpectedSignalValue2)!");
					next;
				}

				my $times_aref = EVAL_get_time_multi_condition( $traceData_href,
													{ 'COND_LABEL_1' => {'SIGNAL_LABEL'   => $signalLabel,
													                     'OPERATOR'       => $compareOperatorValue,
																		 'COMPARE_VALUE'  => $expectedSignalValue},
													  'COND_LABEL_2' => {'SIGNAL_LABEL'   => $signalLabel2,
													                     'OPERATOR'       => $compareOperatorValue2,
																		 'COMPARE_VALUE'  => $expectedSignalValue2}
													}, $timeLogStart, $timeLogEnd );
				$signalValueCount = scalar @$times_aref;
			}
			else {
				do {
					$timeLogStart = EVAL_get_time_when( $traceData_href, $signalLabel, $compareOperatorValue, $expectedSignalValue, $timeLogStart, $timeLogEnd );
					if ( $timeLogStart != -1 ) {
						$timeLogStart = $timeLogStart + 0.001;
						$signalValueCount++;
					}
				} until ( $timeLogStart == -1 );
			}

            # Evaluate signal value occurrances
            my $thisVerdict = EVAL_evaluate_value( "Number of signal value occurrence",
                                             $signalValueCount,
                                             $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperatorCount'},
                                             $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedCount'} );

            $verdict = $thisVerdict if($thisVerdict eq 'VERDICT_FAIL');

			my $evalType = $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber} -> {'EvalType'};
			my $testStepName = ('Signal_EVAL:'.$evalNumber.'_TS:'.$timeStampNumber.'_TYPE:'.$evalType);
            S_teststep_2nd_level( $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'Docu'}."\n".
						"Count signal occurrences from T$timeStampNumber = $timeLogStart_teststep ms over $validationInterval ms"." ".
						"where $signalLabel $compareOperatorValue $expectedSignalValue $signalLabel2 $compareOperatorValue2 $expectedSignalValue2", 'AUTO_NBR', $testStepName );
            S_teststep_expected( $trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'CompareOperatorCount'}." ".$trace_EvalSignal_href -> {$timeStampNumber}->{$evalNumber}->{'ExpectedCount'}, $testStepName );
            S_teststep_detected( $signalValueCount, $testStepName );
        }
    }

    return $verdict;
}    # end of EVAL_evaluate_trace_signals


=head2 GetDataLevel

 GetDataLevel( $dataValue, $flashCodeConfig_href ) not exported

Called from EVAL_getFlashCodes.

Determines the data level (low or high) for a given $dataValue.

=cut

sub GetDataLevel
{
    my ( $dataValue, $flashCodeConfig_href ) = @_;

    #get $dataLevel (low or high) out of $dataValue
    my $dataLevel;

    if (     $dataValue >= $flashCodeConfig_href->{'lowLevel'}{'value'} - $flashCodeConfig_href->{'lowLevel'}{'tolerance'}
         and $dataValue <= $flashCodeConfig_href->{'lowLevel'}{'value'} + $flashCodeConfig_href->{'lowLevel'}{'tolerance'} )
    {
        $dataLevel = 'low';
    }
    elsif (     $dataValue >= $flashCodeConfig_href->{'highLevel'}{'value'} - $flashCodeConfig_href->{'highLevel'}{'tolerance'}
            and $dataValue <= $flashCodeConfig_href->{'highLevel'}{'value'} + $flashCodeConfig_href->{'highLevel'}{'tolerance'} )
    {
        $dataLevel = 'high';
    }
    else
    {
        # $dataLevel remains undefined
    }

    return $dataLevel;
}

=head2 VerifyFlashCodeConfig

 VerifyFlashCodeConfig( $flashCodeConfig_href, $givenFlashCodeConfig_href ) not exported

Called from EVAL_getFlashCodes.

Gets $flashCodeConfig_href from $givenFlashCodeConfig_href, $main::ProjectDefaults->{'FLASH_CODE_CONFIG'} or from default values.
Verifies that all required data are present in $flashCodeConfig_href.

=cut

sub VerifyFlashCodeConfig
{

    my $flashCodeConfig_href      = shift;
    my $givenFlashCodeConfig_href = shift;

    my $defaultFlashCodeConfig_href = {
                                        'signalName'   => 'RILReq',
                                        'lowLevel'     => { 'value' => 0, 'tolerance' => 0 },
                                        'highLevel'    => { 'value' => 1, 'tolerance' => 0 },
                                        'lowTime_s'    => { 'value' => 0.5, 'tolerance' => 0.05 },
                                        'highTime_s'   => { 'value' => 0.5, 'tolerance' => 0.05 },
                                        'digitDelay_s' => { 'value' => 2, 'tolerance' => 0.05 },
                                        'codeDelay_s'  => { 'value' => 5, 'tolerance' => 0.1 },
    };
    my ( $configSource, $error );

    if ( defined $givenFlashCodeConfig_href )
    {
        CopyFlashCodeConfig( $flashCodeConfig_href, $givenFlashCodeConfig_href );
        $configSource = 'argument of function EVAL_getFlashCodes';
    }
    elsif ( defined $main::ProjectDefaults->{'FLASH_CODE_CONFIG'} )
    {
        CopyFlashCodeConfig( $flashCodeConfig_href, $main::ProjectDefaults->{'FLASH_CODE_CONFIG'} );
        $configSource = 'from $main::ProjectDefaults->{"FLASH_CODE_CONFIG"}';
    }
    else
    {
        CopyFlashCodeConfig( $flashCodeConfig_href, $defaultFlashCodeConfig_href );
        $configSource = 'default';
    }

    my $logText = "EVAL_getFlashCodes: flash code configuration: ";
    foreach my $key ( sort keys %{$defaultFlashCodeConfig_href} )
    {
        if ( $key eq 'signalName' )
        {
            if ( not defined $flashCodeConfig_href->{$key} )
            {
                S_set_error( "Missing data {'$key'} in flash code config ($configSource)", 114 );
                $error = 1;
            }
            else
            {
                $logText .= "{'$key'} = $flashCodeConfig_href->{$key}   ";
            }
        }
        else
        {
            if ( not defined $flashCodeConfig_href->{$key}{'value'} )
            {
                S_set_error( "Missing data {'$key'}{'value'} in flash code config ($configSource)", 114 );
                $error = 1;
            }
            else
            {
                $logText .= "{'$key'}{'value'} = $flashCodeConfig_href->{$key}{'value'}   ";
            }
            if ( not defined $flashCodeConfig_href->{$key}{'tolerance'} )
            {
                S_set_error( "Missing data {'$key'}{'tolerance'} in flash code config ($configSource)", 114 );
                $error = 1;
            }
            else
            {
                $logText .= "{'$key'}{'tolerance'} = $flashCodeConfig_href->{$key}{'tolerance'}   ";
            }
        }
    }

    S_w2log( 5, "$logText\n" );
    if ($error)
    {
        return 0;
    }
    else
    {
        return 1;
    }

}

=head2 CopyFlashCodeConfig

 CopyFlashCodeConfig( $toFlashCodeConfig_href, $fromFlashCodeConfig_href ) not exported

Called from VerifyFlashCodeConfig.

Copies the data structure from $fromFlashCodeConfig_href to $toFlashCodeConfig_href.

=cut

sub CopyFlashCodeConfig
{
    my $toFlashCodeConfig_href   = shift;
    my $fromFlashCodeConfig_href = shift;

    foreach my $key ( keys %{$fromFlashCodeConfig_href} )
    {
        if ( $key eq 'signalName' )
        {
            $toFlashCodeConfig_href->{'signalName'} = $fromFlashCodeConfig_href->{'signalName'};
        }
        else
        {
            $toFlashCodeConfig_href->{$key}{'value'}     = $fromFlashCodeConfig_href->{$key}{'value'};
            $toFlashCodeConfig_href->{$key}{'tolerance'} = $fromFlashCodeConfig_href->{$key}{'tolerance'};
        }
    }
    return 1;
}

=head2 ParseCalculationExpression

    ($calculationExpression, $expressionVariables_aref, $expressionVarConfig_href) = ParseCalculationExpression( $calculationExpression ); (not exported)

This function is used by EVAL_dataCalculationOverTime.
Parses $calculationExpression, writes all #n into $expressionVariables_aref, creates $expressionVarConfig_href and replaces all #n in $calculationExpression with $variables{n}{time identifier}.

    Input:
    $calculationExpression : expression that defines the values of the new signal

    Output:
    $calculationExpression    : same as input but with #n replaced by $variables{n}{time identifier}
    $expressionVariables_aref : arrayref with all #n in $calculationExpression
    $expressionVarConfig_href : hashref with config data for all #n, see below

$expressionVarConfig_href has the following structure:

    $expressionVarConfig_href = {
        0 => {
            't' = 1,    # if #0 is in $calculationExpression
            't-1' = 1,  # only if #0[t-1] is in $calculationExpression
            '0' = 1,    # only if #0[0] is in $calculationExpression
        }
        1 => ...
    };

=cut

sub ParseCalculationExpression
{
    my $calculationExpression = shift;

    my $expressionVarConfig_href;

    # extract all #n from $calculationExpression, including all variantions: #n, #n[t], #n[t-1], #n[0]
    my @expressionVariables = sort( $calculationExpression =~ /(\#\d\[?t?[+-]?\d*\]?)/g );

    # loop over all #n in $calculationExpression
    foreach my $expressionVariable (@expressionVariables)
    {
        if ( $expressionVariable =~ /\#(\d)\[?(t?[+-]?\d*)\]?/ )
        {
            # get variable number: 0 for #0, 1 for #1, etc.
            my $exprVarNum = $1;

            # get time identifier: t for #n[t], t-1 for #n[t-1], 0 for #n[0]
            my $exprVarTime = $2;

            if ( $exprVarTime eq '' )
            {
                # if time identifier is not given use 't' as time identifier
                $expressionVarConfig_href->{$exprVarNum}{'t'} = 1;
                $calculationExpression =~ s/\#$exprVarNum/\$variables{$exprVarNum}{'t'}/;
            }
            else
            {
                # otherwise use given time identifier
                $expressionVarConfig_href->{$exprVarNum}{$exprVarTime} = 1;
                $calculationExpression =~ s/\#$exprVarNum\[$exprVarTime\]/\$variables{$exprVarNum}{'$exprVarTime'}/;
            }
            $expressionVarConfig_href->{$exprVarNum}{'values'} = [];
        }
    }

    return ( $calculationExpression, \@expressionVariables, $expressionVarConfig_href );

}

=head2 CalculateExpressionVariable

    CalculateExpressionVariable( $variables_href, $measureValue, $expressionVarConfig_href, $exprVarNum, $timeIndex ); (not exported)

This function is used by EVAL_dataCalculationOverTime.
Calculates the necessary values for $variables_href for the current signal and the current time. $variables_href is used in $calculationExpression of function EVAL_dataCalculationOverTime.

    Input:
    $variables_href           : hashref with variable values for the calculation expression (filled in this function)
    $measureValue             : current value of current variable
    $expressionVarConfig_href : hashref with config data for all #n, see documentation of parseCalculationExpression
    $exprVarNum               : variable number: 0 for #0, 1 for #1, etc.
    $timeIndex                : time index of data: = 0 if it is the first time value, > 0 otherwise

$variables_href has the following structure:

    $variables_href = {
        0 => {
            't' = ...,    # if #0 is in $calculationExpression
            't-1' = ...,  # only if #0[t-1] is in $calculationExpression
            '0' = ...,    # only if #0[0] is in $calculationExpression
        }
        1 => ...
    };

=cut

sub CalculateExpressionVariable
{
    my $variables_href           = shift;
    my $measureValue             = shift;
    my $expressionVarConfig_href = shift;
    my $exprVarNum               = shift;

    # loop over all time index values of current variable
    foreach my $exprVarTime ( keys %{ $expressionVarConfig_href->{$exprVarNum} } )
    {

        # for time index 't' store current data value in $variables_href
        if ( $exprVarTime eq 't' )
        {
            $variables_href->{$exprVarNum}{$exprVarTime} = $measureValue;
        }

        # for time index '0', '1', etc. store data value of appropriate time in $variables_href
        elsif ( $exprVarTime =~ /^\d+$/ )
        {
            $variables_href->{$exprVarNum}{$exprVarTime} = ${ $expressionVarConfig_href->{$exprVarNum}{'values'} }[$exprVarTime];
        }

        # for time index 't-1' store data value of last time in $variables_href
        elsif ( $exprVarTime eq 't-1' )
        {
            if ( defined $variables_href->{$exprVarNum}{'last'} )
            {
                $variables_href->{$exprVarNum}{$exprVarTime} = $variables_href->{$exprVarNum}{'last'};
            }
            else
            {
                $variables_href->{$exprVarNum}{$exprVarTime} = $measureValue;
            }
            $variables_href->{$exprVarNum}{'last'} = $measureValue;
        }
        else
        {
            # no other cases currently supported
        }
    }

    return 1;
}

1;

