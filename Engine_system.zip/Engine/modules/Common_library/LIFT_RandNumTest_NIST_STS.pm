#*****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_RandNumTest_NIST_STS;

use strict;
use warnings;

use Win32::OLE;
use Win32::OLE::Variant;
Win32::OLE->Option( Warn => \&CatchOleException );

use LIFT_general;
require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  RNT_init
  RNT_appendByteArray2BinaryFile
  RNT_invoke_test_suite
  RNT_exit
);

# Keep this PROGID incl. version same as in DLL source: PROGID, assembly and file version
my $RNT_PROGID = "RandNumTest_NIST_STS.NIST_STS.5.0.0.0";
my $RNT_hOle;
my $RNT_initialized = 0;

=head1 NAME

LIFT_RandNumTest_NIST_STS

=head1 SYNOPSIS

    use LIFT_RandNumTest_NIST_STS;
    
    $success = RNT_init();
    
    # Optional helper function, which allows preparation of a (optionally piecewise filled) file as input,
    # instead of providing an array as input stream, in case memory issues observed during array filling.
    # See API-docs in RNT_invoke_test_suite and RNT_appendByteArray2BinaryFile for more details.
    $success = RNT_appendByteArray2BinaryFile($byteArray_aref, $fileName);

    # Standard usage: Random byte stream as array input, testing complete NIST suite
    # More examples shown in API-doc of RNT_invoke_test_suite    
    my $args_href = {
        'streams_aref'        => [0x5F, ..., 0xA3],                 # recommneded 12.500.000 random bytes
        'numOfBitStreams'     => 100,                               # recommended number of (statistical) samples
        'testSelection_aref'  => [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0], # runs complete NIST test suite
        };
    
    $success = RNT_invoke_test_suite( $args_href );
    
    $success = RNT_exit();



=head1 DESCRIPTION

    Random Number Testing (RNT), adapter to NIST Statistical Test Suite
        https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-22r1a.pdf
        https://inside-docupedia.bosch.com/confluence/display/aeos/Random+Number+Generator+Test

=head1 FUNCTIONS

    RNT_init
    RNT_appendByteArray2BinaryFile
    RNT_invoke_test_suite
    RNT_exit

=cut

=head2 RNT_init

    $success = RNT_init();

Starts the application
RandNumTest_NIST_STS.dll must be registered for OLE access, otherwise "Invalid class string" error, which is
typically done by _run_once.bat (or register_com_dlls.bat).

Logs the DLL versions.

Passes the "report\_snapshot_" folder path into the DLL for its logging there.

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub RNT_init {
    my $status;

    if ($RNT_initialized) {
        S_set_warning("RandNumTest_NIST_STS already initialized");
        return 1;
    }

    S_w2log( 3, " RNT_init: Application_create() ..  \n" );
    Application_create() || return;

    my $dllInfos = $RNT_hOle->NIST_STS_getDllInfos();
    return unless defined $dllInfos;
    S_w2log( 3, " RandNumTest_NIST_STS DLL infos: $dllInfos\n" );

    my $snapshot_directory = "$main::REPORT_PATH/_snapshot_";
    unless ( -e $snapshot_directory or mkdir $snapshot_directory ) {
        S_set_error("Snapshot Directory: $snapshot_directory does not exist and could not be created\n");
        return;
    }
    $snapshot_directory =~ s/\//\\/g;    # replace all slashes by backslashes
    $snapshot_directory = File::Spec->rel2abs($snapshot_directory);
    $RNT_hOle->NIST_STS_SetLogFilePath($snapshot_directory);

    $RNT_initialized = 1;

    return 1;
}

=head2 RNT_exit

    $success = RNT_exit();



B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub RNT_exit {
    my $success = 1;

    unless ($RNT_initialized) {
        S_set_error( "RandNumTest_NIST_STS not initialized", 120 );
        return 0;
    }

    Application_destroy();

    $RNT_initialized = 0;

    return $success;
}

=head2 RNT_invoke_test_suite

    $success = RNT_invoke_test_suite($args_href);

B<Description:>

    Invoke NIST statistical test suite
    
    About the input bit streams under test:
    ONE stream of bits = ONE sample in a statistical sense
    SEVERAL such samples is the recommended input for statistical testing
    The input array (or optional the input file) shall contain therefore several consecutive
    bit streams (samples) concatenated one after the other.
    
    Input size recommended by NIST:
        Number of bits within *one* stream = 1.000.000
        Number of such streams (samples)   = 100

B<Arguments:>

=over

=item $args_href

        'streams_aref'       => [byte, byte, ...],  # Bit stream*s* grouped as bytes to be tested.
                                                    # Contains several bit streams
                                                    # as consecutive samples.
        'numOfBitStreams'    => <int>,              # Number of bit streams (samples) within
                                                    # streams_aref or inputFile
        'testSelection_aref' => [<0|1>, <0|1>, ...] # Index: 0, 1...15 specify test #1 to #15
                                Index 0...15 in testSelection array:
                                Index = Value
                                -------------
                                 0    = 0: run selected test(s) below
                                      = 1: run all tests (index-value 1...15 ignored)
                                 1    = 0|1: Frequency
                                 2    = 0|1: Block Frequency
                                 3    = 0|1: Cumulative Sums
                                 4    = 0|1: Runs
                                 5    = 0|1: Longest Run of Ones
                                 6    = 0|1: Rank
                                 7    = 0|1: Discrete Fourier Transform
                                 8    = 0|1: Nonperiodic Template Matchings
                                 9    = 0|1: Overlapping Template Matchings
                                10    = 0|1: Universal Statistical
                                11    = 0|1: Approximate Entropy
                                12    = 0|1: Random Excursions
                                13    = 0|1: Random Excursions Variant
                                14    = 0|1: Serial
                                15    = 0|1: Linear Complexity
        # OPTIONAL INPUTS
        'inputFile'          => [OPT] '<File-Path>', # file containing (several) byte streams,
                                                     # instead of streams_aref, which is ignored.
                                                     # Format: Binary data where each byte contains
                                                     #         eight bits worth of 0's and 1's.
        'streamLength_bytes' => [OPT] <int>, # Required only, if inputFile given.
                                             # Length of *ONE* bit stream (sample) within stream.

=back


B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.


=back


B<Examples:>

    ###################################################################
    # EXAMPLE 1: Default to run complete test suite (runs all 15 tests)
    ###################################################################
    
    # Stream length recommended by NIST:
    # 100.000.000 bits, considered as 100 samples, each with 1.000.000 Bits
    # In case the array is too large for Perl memory, use optional inputFile instead (see EXAMPLE 3)
    
    my @randomByteArray;
    my $randomByte;
    for (1..12500000) # 12.500.000 bytes = 100.000.000 bits
    {
        $randomByte = int(rand(0x100)); # Generates a random number between 0...FF
        push @randomByteArray, $randomByte;
    }
    
    $success = RNT_invoke_test_suite( {     'streams_aref'       => \@randomByteArray,
                                            'numOfBitStreams'    => 100,
                                            'testSelection_aref' => [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0], 
                                      } );
                                      
    #######################################
    # EXAMPLE 2: Runs an internal self test
    #######################################
    
    $success = RNT_invoke_test_suite( {     'streams_aref'       => [0],
                                            'numOfBitStreams'    => 0,
                                            'testSelection_aref' => [0],
                                      } );
    
    #############################################
    # EXAMPLE 3: bit stream coming from inputFile
    #############################################
    NOTE:
    See also function 'RNT_appendByteArray2BinaryFile', which can be used for below file writing part.
    
    my $fileName = 'c:\tempMy\randomdata.bin';
    
    # Method 1: Complete array saved as a whole
    # -----------------------------------------
    my @randomByteArray;
    my $randomByte;
    for (1..12500000) # 12.500.000 bytes = 100.000.000 bits
    {
        $randomByte = int(rand(0x100));       # Generates a random number between 0...FF
        push @randomByteArray, $randomByte;
    }
    
    my $fh;
    open($fh, '>:raw', $fileName);            # write binary file as a whole
    print $fh pack 'C*', @randomByteArray;    # write as bytes
    close($fh);

    # Method 2: Append bit stream piece-wise to file, to save Perl memory
    #           (e.g.: 6250 x 2000 bytes = 12.500.000 bytes = 100.000.000 bits)
    # -------------------------------------------------------------------------
    if ( -e $fileName ) { unlink $fileName; } # delete file, to avoid appending to previous old data
    for (1..6250)
    {
        my @smallerArray;                     # will not grow above 2000 elements
        my $randomByte;
        for (1..2000)
        {
            $randomByte = int(rand(0x100));   # Generates a random number between 0...FF
            push @smallerArray, $randomByte;
        }
    
        my $fh;
        open($fh, '>>:raw', $fileName);       # append to binary file, using operator '>>'
        print $fh pack 'C*', @smallerArray;   # write as bytes 
        close($fh);
    
        undef(@smallerArray);                 # free array
    }
 
    $success = RNT_invoke_test_suite( {     'streams_aref'       => [0], # ignored, if inputFile given
                                            'numOfBitStreams'    => 100,
                                            'testSelection_aref' => $testSelection_aref,
                                            'inputFile'          => $fileName,
                                            'streamLength_bytes' => 125000,
                                      } );
                                      
    #####################################
    # EXAMPLE 4: Runs tests #3, #5 and #7
    #####################################
    
    # Note: This example is expected to fail, because of not enough input data for statistics
    
    $success = RNT_invoke_test_suite( {     'streams_aref'       => [0x55, 0xaa, 0x12],
                                            'numOfBitStreams'    => 1,
                                            'testSelection_aref' => [0,0,0,1,0,1,0,1,0,0,0,0,0,0,0,0],
                                      } );
    
    
B<Notes:> 

Details of all statistical tests can be found here:

    <report-path>\_snapshot_\NIST_STS_<date>_<time>\testEvalResult.txt

which were extracted from the individual NIST test suite results inside folder:

    <report-path>\_snapshot_\NIST_STS_<date>_<time>\experiments

The given input bit stream(s) is saved into this binary file:

    <report-path>\_snapshot_\NIST_STS_<date>_<time>\randomStream.bin

=cut

sub RNT_invoke_test_suite {

    my $inArgs_href = shift;
    my $errorText;

    unless ( keys %$inArgs_href ) {
        S_set_error( "RNT_invoke_test_suite: Missing input parameters!", 109 );
        return;
    }

    # hash defines the set of valid keys
    my $valid_in_arg_keys = {
        'streams_aref'       => 1,
        'inputFile'          => 1,
        'streamLength_bytes' => 1,
        'numOfBitStreams'    => 1,
        'testSelection_aref' => 1,
    };
    my $mandatory_keys = { 'streams_aref' => 1, 'numOfBitStreams' => 1, 'testSelection_aref' => 1 };

    S_checkFunctionArgumentHashKeys( "RNT_invoke_test_suite", $inArgs_href, $valid_in_arg_keys, $mandatory_keys ) or return;

    my $success            = 1;
    my $streams_aref       = $inArgs_href->{'streams_aref'};
    my $inputFile          = $inArgs_href->{'inputFile'};
    my $numOfBitStreams    = $inArgs_href->{'numOfBitStreams'};
    my $testSelection_aref = $inArgs_href->{'testSelection_aref'};

    my $numTestSelections = scalar(@$testSelection_aref);

    if ( $numOfBitStreams > 0 && $numTestSelections != 16 ) {
        S_set_error( "RandNumTest_NIST_STS: Invalid input: testSelection_aref (@$testSelection_aref) has invalid length ($numTestSelections, expected: 16)", 114 );
        return 0;
    }

    unless ($RNT_initialized) {
        S_set_error( "RandNumTest_NIST_STS not initialized", 120 );
        return 0;
    }

    S_w2log( 4, "RNT_invoke_test_suite\n" );

    my $streamBufferLength = scalar(@$streams_aref);
    my $stream_OLEvariant  = Variant( VT_ARRAY | VT_I4, $streamBufferLength );
    my $tstsel_OLEvariant  = Variant( VT_ARRAY | VT_I4, $numTestSelections );
    $stream_OLEvariant->Put($streams_aref);
    $tstsel_OLEvariant->Put($testSelection_aref);
    my $status             = 0;
    my $streamLength_bytes = 0;    # default: run the internal self test...
    if ( $numOfBitStreams > 0 ) {

        # ... or calculate it from given input parameter
        $streamLength_bytes = $streamBufferLength / $numOfBitStreams;
    }

    if ( defined $inputFile ) {
        $streamLength_bytes = $inArgs_href->{'streamLength_bytes'};
        if ( not defined $streamLength_bytes ) {
            $errorText = sprintf("RNT_invoke_test_suite: Missing input parameter: streamLength_bytes");
            S_set_error( $errorText, 109 );
            return;
        }
    }
    else {
        $inputFile = '';
    }

    $status = $RNT_hOle->NIST_STS_invokeTestSuite( $stream_OLEvariant, $inputFile, $streamLength_bytes, $numOfBitStreams, $tstsel_OLEvariant );
    CheckStatus($status);
    S_w2log( 4, "RNT->NIST_STS_invokeTestSuite status ($status) \n" );

    GetLogFilePath();       # Writes link to NIST-log into test report
    LogFileTables2rep();    # Creates and writes tables from NIST-log into test report

    if ( $status != 1 ) { $success = 0; }

    return $success;
}

=head2 RNT_appendByteArray2BinaryFile

    $success = RNT_appendByteArray2BinaryFile($byteArray_aref, $fileName);
    
B<Description:>

    Writes byte array into file.
    If file does not exist yet, it will be created and array written into it.
    If file already exists, the byte array will be appended.

B<Arguments:>

=over

=item $byteArray_aref

    Reference to array of bytes as decimal/integer values in the intervall [0, 255].

=item $fileName

    Full path and fileName, which may exist already (-> appends to it) or not (-> creates it).
        
=back

B<Return Values:>

=over

=item $success

    1 on success, otherwise undef or 0.

=back


B<Examples:>

    # Optional for all examples: Avoids appending to any older file content of a previous test
    if ( -e $fileName ) { unlink $fileName; } # delete file, to avoid appending to previous old data
    
    # EXAMPLE 1: Save array once as a whole
    $success = RNT_appendByteArray2BinaryFile(\@byteArray, $fileName);
    
    # EXAMPLE 2: Save array in a loop of smaller packages
    for (1..6250)
    {
        my @smallerArray;                     # will not grow above 2000 elements
        my $randomByte;
        for (1..2000)
        {
            $randomByte = int(rand(0x100));   # Generates a random number between 0...FF
            push @smallerArray, $randomByte;
        }

        $success = RNT_appendByteArray2BinaryFile(\@smallerArray, $fileName);

        undef(@smallerArray);                 # free array
    }

B<Notes:> 

=cut

sub RNT_appendByteArray2BinaryFile {
    my $array_aref = shift;
    my $fileName   = shift;

    my $success = 1;

    my $fh;
    $success = open( $fh, '>>:raw', $fileName );    # append to binary file, using operator '>>'
    if ( !$success ) {
        S_set_error( "Could not open file: $fileName", 1 );
        return 0;
    }
    print $fh pack 'C*', @$array_aref;              # write as bytes
    close($fh);

    return $success;
}

=head2 GetLogFilePath

    $logFilePath = GetLogFilePath();

To be called after 'RNT_invoke_test_suite' has completed.
Returns the log file path of NIST_STS.dll, containing detailed statistical results and writes this link also to the test report.

B<Return Values:>

=over

=item $logFilePath

=back


B<Examples:>

B<Notes:> 

=cut

sub GetLogFilePath {
    my $logFilePath = $RNT_hOle->NIST_STS_GetLogFilePath();
    S_w2rep("RNT_getLogFilePath: $logFilePath\n");
    my $logFilePath_rel = File::Spec->abs2rel( $logFilePath, $main::REPORT_PATH );
    my $write_to_html = '<A HREF=' . "file:$logFilePath_rel" . '>' . "$logFilePath_rel" . '</A>';
    S_w2rep( $write_to_html, 'blue' );
    return $logFilePath_rel;
}

=head2 LogFileTables2rep

    $success = LogFileTables2rep();
    
B<Description:>

    Reads NIST Test Suite's csv-log-file:
    <report>\_snapshot_\NIST_STS_<time_stamp>\testEvalResult.csv
    and writes content to test report as html tables.

B<Arguments:>

    none

B<Return Values:>

=over

=item $success

    1 on success, otherwise undef or 0.

=back

B<Examples:>

    n/a
    
B<Notes:> 

    n/a

=cut

sub LogFileTables2rep {
    my $success         = 1;
    my $logFilePath_csv = $RNT_hOle->NIST_STS_GetLogFilePath();
    if ( $logFilePath_csv =~ /selfTestEvalResult/ ) {
        S_w2rep("No table output for NIST selftest done");
        return $success;
    }
    $logFilePath_csv =~ s/txt/csv/i;
    my $fh;
    $success = open( $fh, "<", $logFilePath_csv );
    if ( !$success ) {
        S_set_error( "Could not open file: $logFilePath_csv", 1 );
        return 0;
    }

    my @lines = <$fh>;
    close $fh;

    my $pValues_headline;
    my @pValues_columnHeader;
    my @pValues;

    my $histograms_headline;
    my @histograms_columnHeader;
    my @histogramsValues;

    my $nistFinalResult;

    my $lineCounter = 0;
    foreach my $line (@lines) {
        $lineCounter++;
        if ( $lineCounter == 1 ) {
            $pValues_headline = $line;    # Proportion of tested samples that pass:
        }
        if ( $lineCounter == 2 ) {
            @pValues_columnHeader = split( /;/, $line );    # Example: #;Test Name;min-P-val;#Passed;#Samples;%Passed;Result >= 96%
        }
        if ( $lineCounter > 2 && $lineCounter < 18 ) {
            my @values_line = split( /;/, $line );          # Example: 1;Frequency;0.006608;99;100; 99.000;PASSED
            push( @pValues, \@values_line );
        }
        if ( $lineCounter == 18 ) {
            $histograms_headline = $line;                   # Histograms of P-values:
        }
        if ( $lineCounter == 19 ) {
            @histograms_columnHeader = split( /;/, $line );    # Example: #;Test Name; 0.1; 0.2; 0.3; 0.4; 0.5; 0.6; 0.7; 0.8; 0.9; 1.0;Uniformity;Uniformity >= 0.0001
        }
        if ( $lineCounter > 19 && $lineCounter < 35 ) {
            my @values_line = split( /;/, $line );             # Example: 1;Frequency;11;13;16;11;8;9;8;9;8;7;0.637119;PASSED
            push( @histogramsValues, \@values_line );
        }
        if ( $lineCounter == 35 ) {
            $nistFinalResult = $line;                          # NIST Test Suite: PASSED
        }
    }

    my $tableObject;

    S_w2rep($pValues_headline);
    $tableObject = S_TableCreate( \@pValues_columnHeader, \@pValues );
    $success = S_TablePrint( HTML, $tableObject, 'Proportion of samples passed' );

    S_w2rep($histograms_headline);
    $tableObject = S_TableCreate( \@histograms_columnHeader, \@histogramsValues );
    $success = S_TablePrint( HTML, $tableObject, 'Histograms of P-values' );

    S_w2rep($nistFinalResult);

    return $success;
}

=head2 Application_create

    $success = Application_create();

Loads and initializes the NIST STS DLLs

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub Application_create {

    #$RNT_hOle = S_create_OLE($RNT_PROGID); # does not allow offline mode!
    $RNT_hOle = Win32::OLE->new($RNT_PROGID);

    unless ( defined($RNT_hOle) ) {
        S_set_error( "Unable to start COM-DLL $RNT_PROGID (Try '_run_once.bat' to register it), " . Win32::OLE->LastError(), 5 );
        return 0;
    }

    return 1;
}

=head2 Application_destroy

    $success = Application_destroy();



B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub Application_destroy {

    #    $RNT_hOle->Quit();
    #    $RNT_hOle = undef;
}

=head2 CheckStatus

    $success = CheckStatus($status);


B<Arguments:>

=over

=item $status

return value of a RandNumTest_NIST_STS.dll API call

=back


B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub CheckStatus {
    my $status = shift;

    if ( $status == 0 ) {
        my $errortext = $RNT_hOle->NIST_STS_getLastErrorString();
        S_set_error( "RNT ($status): $errortext", 5 );
        return 0;
    }

    return $status;
}

sub CatchOleException {
    my $errorText = Win32::OLE->LastError();

    return 1 if $errorText !~ /RandNumTest_NIST_STS/;    # only react on OLE exceptions from RandNumTest_NIST_STS

    if ( $errorText =~ /Invalid pointer|Invalid index/ ) {
        S_w2log( 3, "$errorText" );
    }
    else {
        S_set_error( "$errorText", 23 );
    }
    return;
}

1;
