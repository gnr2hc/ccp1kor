# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_MKS;

use strict;
use warnings;
use version;
use LIFT_general;
use LIFT_evaluation;
use Data::Dumper;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  MKS_checkEngineIntegrity
  MKS_checkFileRevisions
  MKS_checkFilesWithLabel
  MKS_checkReleaseIntegrity
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_MKS 

=head1 SYNOPSIS

    use LIFT_MKS;

	MKS_checkFilesWithLabel('Checkpoint_Quedlinburg_Castle', 'ATLEAST');
	MKS_checkFilesWithLabel('EDR V3_0', 'ATLEAST');
	MKS_checkFilesWithLabel('FordAB12_SysTE', 'EXACT');
	MKS_checkFileRevisions ('CREIS');
	MKS_checkFileRevisions ('CRAFT_PSI');

=head1 DESCRIPTION

This library contains functions which interact with MKS. Some use cases are: functions to check if a test is using the right library and configuration files from MKS.

I<B<Project defaults required by MKS_checkFilesRevisions:>>

   'Defaults' = {

		'MKS_FILE_REVISIONS' => {    #used by MKS_checkFilesRevisions

			'label1' => {            #label/name of test
				'EXACT' => {         #working revisions should match exactly with below revisions
					'filename'    => 'expected version',
					...
				},

				'ATLEAST' => {       #working revision should be greater than or equal to below revisions
					'filename'    => 'expected version',
					...
				},
			},

			'CREIS_example' => {     #label/name of test
				'EXACT' => {         #working revisions should match exactly with below revisions
					'TC_CREIS_StandardTest.pm'    => '1.1.1.2',
					'CREIS_ProjectConst_D544N.pm' => '1.3',
					'Mapping_DEVICE_CD391NA.pm'   => '1.10',
				},

				'ATLEAST' => {       #working revision should be greater than or equal to below revisions
					'LIFT_QuaTe.pm'                   => '1.26',
					'LIFT_TSG4.pm'                    => '1.60',
					'Ford_AB12_CD4_1_ProjectConst.pm' => '1.10',
				},
			},

			#further labels can be added here (separate hash for each test)
		}
   };

=cut

# variables to hold crash data and config of last crash
my $lastCheckedEntries_href = {};
my $lastCheckSuccess        = 0;
my $lastSerializedParams    = '';

=head2 MKS_checkFileRevisions

	($success, $allEntries_href) = MKS_checkFileRevisions ( $labelOfTest );

I<B<Description:>> This function compares MKS working file revisions against expected file revisions listed in the Project Const. Prints a summary table to html report

$labelOfTest: a label for the test which corresponds to the hash name defined in the Project Const under 'MKS_FILE_REVISIONS'

Hash structure format in Project Const:

	'MKS_FILE_REVISIONS' => {    #used by MKS_checkFilesRevisions

		'label1' => {            #label/name of test
			'EXACT' => {         #working revisions should match exactly with below revisions
				'filename'    => 'expected version',
				...
			},

			'ATLEAST' => {       #working revision should be greater than or equal to below revisions
				'filename'    => 'expected version',
				...
			},
		},

		'label2' => {            
			'EXACT' => { 
				...        
			},

			'ATLEAST' => {  
				...     
			},
		}, 

		#further labels can be added here (separate hash for each test)
	}

I<B<Example:>> MKS_checkFileRevisions ( 'CREIS' );

Hash structure in Project Const:

	'MKS_FILE_REVISIONS' => {    #used by MKS_checkFilesRevisions

		'CREIS' => {             #label/name of test
			'EXACT' => {         #working revisions should match exactly with below revisions
				'TC_CREIS_StandardTest.pm'                   => '1.1.1.2',
				'AB12_RefType3_ProjectConst_CREIS.pm' => '1.10',
				'Mapping_DEVICE_CD391NA.pm'                  => '1.10',
			},

			'ATLEAST' => {       #working revision should be greater than or equal to below revisions
				'LIFT_QuaTe.pm'                   => '1.26',
				'LIFT_TSG4.pm'                    => '1.60',
				'Ford_AB12_CD4_1_ProjectConst.pm' => '1.10',
			},
		},

		#further labels can be added here (separate hash for each test)

	},

I<B<Return:>> 0 on error, 1 on success and 

$allEntries_href - a hash reference that contains all checked files and the content of the check as displayed in the table.
        
        $allEntries_href->{
            'config/AB12_RefType3_ProjectConst_CREIS.pm' => {
                workingRev       => 1.10,
                labelRev         => 1.10,
                comparisonStatus => 1,
                modified         => 0,
                revCompare       => 'EXACT',
                mksLabel         => undef,
                labelOfTest      => 'CREIS',
            },
        };


I<B<Verdict:>> PASS if working revision of file matches expected revision

I<B<Error:>> ERROR if the working revision does not match expected revision or if file is not found in the current MKS project sandbox

=cut

sub MKS_checkFileRevisions {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MKS_checkFileRevisions ( $labelOfTest )', @args );

    my $labelOfTest = shift @args;

    S_w2log( HTML, "MKS_checkFileRevisions: checking MKS working revisions for '$labelOfTest' \n" );

    my $files_exact   = S_get_contents_of_hash( [ 'MKS_FILE_REVISIONS', $labelOfTest, 'EXACT' ] );
    my $files_atleast = S_get_contents_of_hash( [ 'MKS_FILE_REVISIONS', $labelOfTest, 'ATLEAST' ] );

    my $sandbox = mks_getSandboxName();    #prints current MKS sandbox

    my ( @allEntries_exact, @allEntries_atleast, $allEntries_href );
    my $success = 1;

    #EXACT
    foreach my $file ( keys %$files_exact ) {

        my $color = 'none';
        my $expRev = S_get_contents_of_hash( [ 'MKS_FILE_REVISIONS', $labelOfTest, 'EXACT', $file ] );

        my ( $workingRev, $memberRev, $modified, $shortFilepath ) = mks_getWorkingAndMemberRevision( $file, $sandbox );
        my $comparisonStatus = mks_compareFileRevisions( $shortFilepath, $expRev, $workingRev, $modified, 'EXACT' );

        $success = 0 if $modified;
        $success = 0 unless $comparisonStatus;

        #to create a table
        $color = 'red' if ( !$comparisonStatus );
        my $modifiedText = 'no';
        $modifiedText = "<span style='background:red'>yes</span>" if $modified;
        push( @allEntries_exact, [ $shortFilepath, $expRev, "<span style='background:$color'>" . $workingRev . "</span>", $modifiedText ] );

        $allEntries_href->{$shortFilepath}{workingRev}       = $workingRev;
        $allEntries_href->{$shortFilepath}{labelRev}         = $memberRev;
        $allEntries_href->{$shortFilepath}{comparisonStatus} = $comparisonStatus;
        $allEntries_href->{$shortFilepath}{modified}         = $modified;
        $allEntries_href->{$shortFilepath}{revCompare}       = 'EXACT';
        $allEntries_href->{$shortFilepath}{labelOfTest}      = $labelOfTest;
        $allEntries_href->{$shortFilepath}{mksLabel}         = undef;
    }

    #ATLEAST
    foreach my $file ( keys %$files_atleast ) {

        my $color = 'none';
        my $expRev = S_get_contents_of_hash( [ 'MKS_FILE_REVISIONS', $labelOfTest, 'ATLEAST', $file ] );

        my ( $workingRev, $memberRev, $modified, $shortFilepath ) = mks_getWorkingAndMemberRevision( $file, $sandbox );
        my $comparisonStatus = mks_compareFileRevisions( $shortFilepath, $expRev, $workingRev, $modified, 'ATLEAST' );

        $success = 0 if $modified;
        $success = 0 unless $comparisonStatus;

        #to create a table
        $color = 'red' if ( !$comparisonStatus );
        my $modifiedText = 'no';
        $modifiedText = "<span style='background:red'>yes</span>" if $modified;
        push( @allEntries_atleast, [ $shortFilepath, $expRev, "<span style='background:$color'>" . $workingRev . "</span>", $modifiedText ] );

        $allEntries_href->{$shortFilepath}{workingRev}       = $workingRev;
        $allEntries_href->{$shortFilepath}{labelRev}         = $workingRev;
        $allEntries_href->{$shortFilepath}{comparisonStatus} = $comparisonStatus;
        $allEntries_href->{$shortFilepath}{modified}         = $modified;
        $allEntries_href->{$shortFilepath}{revCompare}       = 'ATLEAST';
        $allEntries_href->{$shortFilepath}{labelOfTest}      = $labelOfTest;
        $allEntries_href->{$shortFilepath}{mksLabel}         = undef;
    }

    S_w2log( 1, "Summary of MKS file revision check ($labelOfTest)\n", undef, "MKSRevisionCheck_$labelOfTest" );
    if ( scalar @allEntries_exact ) {
        my $tableObject_exact = S_TableCreate( [ 'Filename', 'Expected Revision (EXACT)', 'Working Revision', 'Modified' ], \@allEntries_exact );
        S_TablePrint( TEXT | HTML, $tableObject_exact );
    }

    if ( scalar @allEntries_atleast ) {
        my $tableObject_atleast = S_TableCreate( [ 'Filename', 'Expected Revision (ATLEAST)', 'Working Revision', 'Modified' ], \@allEntries_atleast );
        S_TablePrint( TEXT | HTML, $tableObject_atleast );
    }

    S_set_error( "MKS_checkFilesWithLabel: revision compare not successfull for section '$labelOfTest'. For details see tables above", 5 ) unless $success;

    return ( $success, $allEntries_href );
}

=head2 MKS_checkEngineIntegrity

    ($success, $allEntries_href) = MKS_checkEngineIntegrity ([,$revCompare, $ignoreList_aref, $minimumRequiredEngineBaseline]) ;

I<B<Description:>> This function compares MKS working file revisions against file revisions for the used Engine in MKS. Prints a summary table to html report

$revCompare: can be 'EXACT' or 'ATLEAST'

EXACT: working revisions should match exactly with the MKS revision of files which contains this label

ATLEAST: working revision should be greater than or equal to the MKS revision of files which contains this label

$ignoreList_aref: a list reference of files pathes (in the short format) to be excluded from the check.

$minimumRequiredEngineBaseline: Baseline Revision of the Engine that is minimum required for the release to be fully functional.

I<B<Examples:>> MKS_checkEngineIntegrity ( 'EXACT' );

MKS_checkEngineIntegrity ( 'ATLEAST', ['modules/TC_FunctionLib/TC_TNT/FuncLib_TNT_CREIS_Framework.pm', 'modules/TC_FunctionLib/FuncLib_CREIS_Framework.pm',...] )

I<B<Return:>> 0 on error 

$allEntries_href - a hash reference that contains all checked files and the content of the check as displayed in the table.
        
        $allEntries_href->{
            'modules/LIFT_can_access.pm' => {
                workingRev       = 1.64,
                labelRev         = 1.64,
                comparisonStatus = 1,
                modified         = 0,
                revCompare       = 'EXACT',
            },
        };

I<B<Verdict:>> PASS if working revision of file matches expected revision

I<B<Error:>> ERROR if the working revision does not match expected revision or if the label is not found on any file in the current MKS project

=cut

sub MKS_checkEngineIntegrity {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MKS_checkEngineIntegrity ( [$revCompare, $ignoreList_aref, $minimumRequiredEngineBaseline] )', @args );

    my $revCompare                    = shift @args;
    my $ignoreList_aref               = shift @args;
    my $minimumRequiredEngineBaseline = shift @args;

    my ( $engineBaseline, $allEntries_href );
    my $successEngineBaselineCheck = 1;

    my $project_info_href = S_get_project_info();

    my $label = $project_info_href->{LIFT_version};    # fetch from project_info

    if ( $label =~ m!^((0|[1-9]\d*)(.\d+){1,3})\s+baseline\s+\((\w+)\)$! ) {
        $engineBaseline = $1;
        $label          = "Checkpoint_" . $4;
    }
    else {
        S_set_error( "Given LIFT_version is not in expected format.", 114 );
        return 0;
    }

    if ( defined $minimumRequiredEngineBaseline ) {
        unless ( $minimumRequiredEngineBaseline =~ m!^(0|[1-9]\d*)(.\d+){1,3}$! ) {
            S_set_error( "MKS_checkEngineIntegrity: Given \$minimumRequiredEngineBaseline $minimumRequiredEngineBaseline not in the expected version format (f.e.: 1.32)", 114 );
            return 0;
        }

        my $engineBaselineText = $engineBaseline;
        $allEntries_href->{ENGINE}{workingRev}       = $engineBaseline;
        $allEntries_href->{ENGINE}{labelRev}         = $minimumRequiredEngineBaseline;
        $allEntries_href->{ENGINE}{comparisonStatus} = 1;
        $allEntries_href->{ENGINE}{modified}         = undef;
        $allEntries_href->{ENGINE}{revCompare}       = 'ATLEAST';
        $allEntries_href->{ENGINE}{labelOfTest}      = undef;
        $allEntries_href->{ENGINE}{mksLabel}         = $label;

        $successEngineBaselineCheck = mks_checkMinimumRequiredEngine( $engineBaseline, $minimumRequiredEngineBaseline );

        unless ( $successEngineBaselineCheck ) {
            $allEntries_href->{ENGINE}{comparisonStatus} = 0;
            $engineBaselineText                          = "<span style='background:red'>$engineBaselineText</span>";
        }

        S_w2log( 1, "Summary of minimum required Engine check\n", undef, "MksCheckMinimumRequiredEngine" );
        my $tableObject = S_TableCreate( [ 'Filename', "Minimum required Engine", 'Working Revision' ], [ [ 'ENGINE', $minimumRequiredEngineBaseline, $engineBaselineText ] ] );
        S_TablePrint( TEXT | HTML, $tableObject );

        S_set_error( "MKS_checkEngineIntegrity: minimum required Engine Baseline not fullfilled. For details see table above.", 5 ) unless $successEngineBaselineCheck;

    }

    my ( $success, $checkedEntries_href ) = MKS_checkFilesWithLabel( $label, $revCompare, $ignoreList_aref );
    @$allEntries_href{ keys %$checkedEntries_href } = values %$checkedEntries_href;

    $success = 0 unless ($successEngineBaselineCheck);

    return ( $success, $allEntries_href );
}

=head2 MKS_checkReleaseIntegrity

    ($success, $allEntries_href) = MKS_checkReleaseIntegrity ( $releaseLabel, [$minimumRequiredEngineBaseline] ) ;

I<B<Description:>>
This function is the easy to use method for checking the integrity of complete test automation releases. It contains 4 different checks:
A. It checks the integrity of the project specific files by calling 'MKS_checkFileRevisions' 
    with a label provided by ExecutionOption 'MKS_ProjectFilesSection'.
B. It checks the integrity of all files (Engine, Testcases, ...) assigned to a particular release by calling 'MKS_checkFilesWithLabel'
    with the label provided by $releaseLabel. 
C. Checks that the used Engine is at least $minimumRequiredEngine.
D. Checks the integrity of the used Engine. 

I<B<Parameters:>>
$releaseLabel - label assigned to a particular test automation release like "CREIS_V2_0" or "EDR_V7_0"
$minimumRequiredEngineBaseline - Baseline Revision of the Engine that is minimum required for the release to be fully functional.

I<B<Examples:>>
($success, $allEntries_href) = MKS_checkReleaseIntegrity ( "CREIS_V2_0", "2.32" ) ;

I<B<ExecutionOptions:>>
MKS_ProjectFilesSection             => Name of the section in Project Defaults to be checked with 'MKS_checkFileRevisions' during MKS_checkReleaseIntegrity. 
MKS_NoError4CheckReleaseIntegrity   => if set or defined all errors of MKS_checkReleaseIntegrity will be transformed into warnings.

I<B<Return:>> 0 on error

$allEntries_href - a hash reference that contains all checked files and the content of the check as displayed in the html tables.
        
        $allEntries_href->{
            'config/AB12_RefType3_ProjectConst_CREIS.pm' => {
                workingRev       => 1.10,
                labelRev         => 1.10,
                comparisonStatus => 1,
                modified         => 0,
                revCompare       => 'EXACT',
                mksLabel         => undef,
                labelOfTest      => 'CREIS',
            },
            'modules/LIFT_can_access.pm' => {
                workingRev       => 1.64,
                labelRev         => 1.64,
                comparisonStatus => 1,
                modified         => 0,
                revCompare       => 'EXACT',
                mksLabel         => 'Checkpoint_Main_Tower',
                labelOfTest      => undef,
            },
        };

I<B<Verdict:>> PASS if working revision of file matches expected revision

I<B<Error:>> ERROR if the working revision does not match expected revision or if the label is not found on any file in the current MKS project

=cut

sub MKS_checkReleaseIntegrity {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MKS_checkReleaseIntegrity ( [ $releaseLabel, $minimumRequiredEngineBaseline ] )', @args );

    my $releaseLabel                  = shift @args;
    my $minimumRequiredEngineBaseline = shift @args;
    my ( $allEntries_href, $checkedEntries_href, $success, @alreadyCheckedFiles );

    my $params_href = {};
    $params_href->{releaseLabel}                  = $releaseLabel;
    $params_href->{minimumRequiredEngineBaseline} = $minimumRequiredEngineBaseline;
    
    my $noErrorFlag               = S_check_exec_option('MKS_NoError4ReleaseIntegrityCheck') ? S_get_exec_option('MKS_NoError4ReleaseIntegrityCheck') : 0;
    my $skipReleaseIntegrityCheck = S_check_exec_option('MKS_SkipReleaseIntegrityCheck') ? S_get_exec_option('MKS_SkipReleaseIntegrityCheck') : 0;

    if ($skipReleaseIntegrityCheck){
        S_set_error( "MKS_checkReleaseIntegrity: Check is switched OFF by Execution Option 'MKS_SkipReleaseIntegrityCheck'.", 5 ) unless $noErrorFlag;
        S_set_warning( "MKS_checkReleaseIntegrity: Check is switched OFF by Execution Option 'MKS_SkipReleaseIntegrityCheck'.", 5 ) if $noErrorFlag;        
        return ( 0, undef );
    }

    my $serializedParams = Dumper($params_href);

    # if the function is called with the same parameters the previous result can be reused if available
    # if the function is called without parameter for $releaseLabel it will reuse the previous result and just check for minimumRequiredEngineBaseline
    if ( $serializedParams eq $lastSerializedParams or not defined $releaseLabel ) {
        S_w2log( 3, "MKS_checkReleaseIntegrity: parameters are the same as for last function call. Re-using result and data of last check.\n" ) if ( $serializedParams eq $lastSerializedParams );
        S_w2log( 3, "MKS_checkReleaseIntegrity: parameters are empty. Re-using result and data of last check.\n" ) unless defined $releaseLabel;
        $allEntries_href = $lastCheckedEntries_href;
        $success         = $lastCheckSuccess;

        if ( defined $minimumRequiredEngineBaseline and not defined $releaseLabel ) {
            my $successEngineBaselineCheck = mks_checkMinimumRequiredEngine( $allEntries_href->{ENGINE}{workingRev}, $minimumRequiredEngineBaseline );
            
            S_set_error( "MKS_checkReleaseIntegrity: minimum Engine of last check of ReleaseIntegrity is too low.", 5 ) if not $successEngineBaselineCheck and not $noErrorFlag;
            S_set_warning( "MKS_checkReleaseIntegrity: minimum Engine of last check of ReleaseIntegrity is too low.", 5 ) if not $successEngineBaselineCheck and $noErrorFlag;
            return ( $success, $allEntries_href );                       
        }

        S_set_error( "MKS_checkReleaseIntegrity: last check of ReleaseIntegrity was not successfull.", 5 ) if not $success and not $noErrorFlag;
        S_set_warning( "MKS_checkReleaseIntegrity: last check of ReleaseIntegrity was not successfull.", 5 ) if not $success and $noErrorFlag;
        return ( $success, $allEntries_href );
    }

    # check the project specific files (as given in Project Defaults)
    my $labelOfTest = S_check_exec_option('MKS_ProjectFilesSection') ? S_get_exec_option('MKS_ProjectFilesSection') : 0;
    ( $success, $checkedEntries_href ) = MKS_checkFileRevisions($labelOfTest)         if $labelOfTest and not $noErrorFlag;
    ( $success, $checkedEntries_href ) = MKS_checkFileRevisions_NOERROR($labelOfTest) if $labelOfTest and $noErrorFlag;
    @$allEntries_href{ keys %$checkedEntries_href } = values %$checkedEntries_href;

    # check all files with release label, but ignore all files that have already been checked
    @alreadyCheckedFiles = keys %{$allEntries_href};
    ( $success, $checkedEntries_href ) = MKS_checkFilesWithLabel( $releaseLabel, 'EXACT', \@alreadyCheckedFiles ) unless $noErrorFlag;
    ( $success, $checkedEntries_href ) = MKS_checkFilesWithLabel_NOERROR( $releaseLabel, 'EXACT', \@alreadyCheckedFiles ) if $noErrorFlag;
    @$allEntries_href{ keys %$checkedEntries_href } = values %$checkedEntries_href;

    my $instAddons_href = S_get_contents_of_hash( [ 'MKS_FILE_REVISIONS', $labelOfTest, 'AddOns' ] );

    # check all files with release label of AddOns (as given in ProjectDefaults), but ignore all files that have already been checked
    foreach my $instAddOn ( keys %{$instAddons_href} ){
        @alreadyCheckedFiles = keys %{$allEntries_href};
        ( $success, $checkedEntries_href ) = MKS_checkFilesWithLabel( $instAddons_href->{$instAddOn}, 'EXACT', \@alreadyCheckedFiles ) unless $noErrorFlag;
        ( $success, $checkedEntries_href ) = MKS_checkFilesWithLabel_NOERROR( $instAddons_href->{$instAddOn}, 'EXACT', \@alreadyCheckedFiles ) if $noErrorFlag;
        @$allEntries_href{ keys %$checkedEntries_href } = values %$checkedEntries_href;
    }

    # check the Engine integrity, but ignore all files that have already been checked
    @alreadyCheckedFiles = keys %{$allEntries_href};
    ( $success, $checkedEntries_href ) = MKS_checkEngineIntegrity( 'EXACT', \@alreadyCheckedFiles, $minimumRequiredEngineBaseline ) unless $noErrorFlag;
    ( $success, $checkedEntries_href ) = MKS_checkEngineIntegrity_NOERROR( 'EXACT', \@alreadyCheckedFiles, $minimumRequiredEngineBaseline ) if $noErrorFlag;
    @$allEntries_href{ keys %$checkedEntries_href } = values %$checkedEntries_href;

    # remember result, data and params for next function call
    $lastCheckedEntries_href = $allEntries_href;
    $lastCheckSuccess        = $success;
    $lastSerializedParams    = $serializedParams;

    return ( $success, $allEntries_href );
}

=head2 MKS_checkFilesWithLabel

	($success, $allEntries_href) = MKS_checkFilesWithLabel ($label [,$revCompare]) ;

I<B<Description:>> This function compares MKS working file revisions against file revisions with a particular label in MKS. Prints a summary table to html report

Files to be compared should be appropriately labeled in MKS

$label: a string which corresponds to the MKS label added to the files which are to be verified

$revCompare: can be 'EXACT' or 'ATLEAST'

EXACT: working revisions should match exactly with the MKS revision of files which contains this label

ATLEAST: working revision should be greater than or equal to the MKS revision of files which contains this label

$ignoreList_aref: a list reference of files pathes (in the short format) to be excluded from the check.

I<B<Examples:>> MKS_checkFilesWithLabel ( 'FordAB12_CREIS_SysTE', 'EXACT' )

MKS_checkFilesWithLabel ( 'Checkpoint_Main_Tower', 'ATLEAST' )

I<B<Return:>> 0 on error, 1 on success and 

$allEntries_href - a hash reference that contains all checked files and the content of the check as displayed in the table.
        
        $allEntries_href->{
            'modules/LIFT_can_access.pm' => {
                workingRev       => 1.64,
                labelRev         => 1.64,
                comparisonStatus => 1,
                modified         => 0,
                revCompare       => 'EXACT',
                mksLabel         => 'Checkpoint_Main_Tower',
                labelOfTest      => undef,
            },
        };

I<B<Verdict:>> PASS if working revision of file matches expected revision

I<B<Error:>> ERROR if the working revision does not match expected revision or if the label is not found on any file in the current MKS project

=cut

sub MKS_checkFilesWithLabel {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MKS_checkFilesWithLabel ( $label , [$revCompare, $ignoreList_aref] )', @args );

    my $label           = shift @args;
    my $revCompare      = shift @args;
    my $ignoreList_aref = shift @args;

    S_w2log( HTML, "MKS_checkFilesWithLabel: comparing MKS working revisions with revision of files with label '$label'\n" );

    unless ( defined $revCompare ) {
        $revCompare = 'EXACT';
        S_w2log( 3, "MKS_checkFilesWithLabel: operator not defined. Default: 'EXACT' (working revision should exactly match revision of file with label) " );
    }

    if ( $revCompare !~ /EXACT/i and $revCompare !~ /ATLEAST/i ) {
        S_set_error( "Unknown comparision parameter '$revCompare'. Allowed: 'EXACT', 'ATLEAST'", 114 );
        return 0;
    }

    my @allEntries;
    my $allEntries_href;
    my $sandbox = mks_getSandboxName();    #prints current MKS sandbox
    my $success = 1;

    my $files = mks_getFilesWithLabel($label);
    unless ( scalar @$files ) {            #no files found
        S_set_error( "No files with label '$label' is found in the current MKS project", 5 );
        return 0;
    }

    foreach my $file (@$files) {
        my $labelRev = @$file[1];
        my $color    = 'none';

        my ( $workingRev, $memberRev, $modified, $shortFilepath ) = mks_getWorkingAndMemberRevision( @$file[0], $sandbox );
        next if $shortFilepath ~~ @$ignoreList_aref;

        my $comparisonStatus = mks_compareFileRevisions( $shortFilepath, $labelRev, $workingRev, $modified, $revCompare );

        $success = 0 if $modified;
        $success = 0 unless $comparisonStatus;

        #to create a table
        $color = 'red' if ( !$comparisonStatus );
        my $modifiedText = 'no';
        $modifiedText = "<span style='background:red'>yes</span>" if $modified;
        push( @allEntries, [ $shortFilepath, $labelRev, "<span style='background:$color'>" . $workingRev . "</span>", $modifiedText ] );

        $allEntries_href->{$shortFilepath}{workingRev}       = $workingRev;
        $allEntries_href->{$shortFilepath}{labelRev}         = $labelRev;
        $allEntries_href->{$shortFilepath}{comparisonStatus} = $comparisonStatus;
        $allEntries_href->{$shortFilepath}{modified}         = $modified;
        $allEntries_href->{$shortFilepath}{revCompare}       = $revCompare;
        $allEntries_href->{$shortFilepath}{labelOfTest}      = undef;
        $allEntries_href->{$shortFilepath}{mksLabel}         = $label;
    }

    if ( scalar @allEntries ) {
        S_w2log( 1, "Summary of MKS label check ($label)\n", undef, "MKSRevisionCheck_$label" );
        my $tableObject = S_TableCreate( [ 'Filename', "Label Revision ($revCompare)", 'Working Revision', 'Modified' ], \@allEntries );
        S_TablePrint( TEXT | HTML, $tableObject );
    }

    S_set_error( "MKS_checkFilesWithLabel: revision compare not successfull for label '$label' and mode '$revCompare'. For details see table above", 5 ) unless $success;

    return ( $success, $allEntries_href );
}

=head1 not exported functions

=head2 mks_locateFile

I<B<Syntax : >>

    $fullSandboxPath = mks_locateFile( $filename, $sandbox );

I<B<Arguments    : >>

    $status   =   status code to be checked
    $sandbox  =   name of current sandbox

I<B<Description :>> check if file is found in MKS (any project) and return the full sandbox path

I<B<Return values :>> $fullSandboxPath

=cut

sub mks_locateFile {
    my $filename = shift;
    my $sandbox  = shift;
    my ( @allFiles, $shortpath );

    #my $sandbox = mks_getSandboxName();

    my $cmd = "si locate --memberbyname=$filename --sandbox=$sandbox";    # --projectscope=this

    open( SANDBOX, $cmd . "|" ) || die("ERROR: cannot execute $cmd\n$!\n");
    my @allLines = <SANDBOX>;
    close(SANDBOX);

    #sample output on console: g:/MKS/Projects/TurboLIFT/Projects/FoMoCo/Ford_AB12_CD4_1_MCA/Ford_AB12_CD4_1_MCA.pj    - Mainline -    config/Mapping_DEVICE_CD391NA.pm        1.10    Feb 2, 2016 10:03:39 AM - Now
    if ( $allLines[0] =~ m/.*\s+(.*)\/\Q$filename\E\s+/ ) {
        $shortpath = $1 . "/$filename" if ( defined $1 );
        return File::Spec->rel2abs($shortpath);                           #full/absolute path
    }

    #sample output on console: g:/MKS/Projects/TurboLIFT/Projects/CustLib/Chrysler_Fiat/TC_FunctionLib/TC_FunctionLib.pj - Mainline - FuncLib_CustLib_CREIS_Framework.pm 1.2 Jan 16, 2017 3:30:10 PM - Now
    elsif ( $allLines[0] =~ m/.*\s+\Q$filename\E\s+/ ) {

        #$shortpath = "$filename" if ( defined $1 );
        return File::Spec->rel2abs($filename);                            #full/absolute path
    }
    else {
        S_set_error( "File '$filename' not found in current MKS sandbox", 5 );
        return;
    }

}

=head2 mks_getFilesWithLabel

I<B<Syntax : >>

    $allFiles_Revs = mks_getFilesWithLabel( $label );

I<B<Arguments    : >>

    $label   =   label of file revision in MKS

I<B<Description :>> find all files with a particular label in current MKS sandbox, return the absolute filepaths and label revisions of all files with label

Note: ignores these folders: Documentation, test, htmldata

I<B<Return values :>> $allFiles_Revs which is an aref of arefs containing ($file, $fileRev) for each file with label

=cut

sub mks_getFilesWithLabel {
    my $label = shift;

    my @allFiles;
    my @allFileRevs;

    my $cmd = "si viewsandbox --filtersubs --filter=anylabel:'$label'";
    open( SANDBOX, $cmd . "|" ) || die("ERROR: cannot execute $cmd\n$!\n");
    my @allLines = <SANDBOX>;
    close(SANDBOX);

    #sample output on console:
    # c:\MKS\Projects\TurboLIFT\Projects\FoMoCo\Ford_AB12_CD4_1_MCA\TCs\TCs_TNT\TCs_TNT.pj shared-subsandbox
    #   c:\MKS\Projects\TurboLIFT\Projects\FoMoCo\Ford_AB12_CD4_1_MCA\TCs\TCs_TNT\CREIS\TC_CREIS_StandardTest.pm archived 1.3
    #
    #    Working file corresponds to revision 1.1.1.2
    # c:\MKS\Projects\TurboLIFT\Projects\FoMoCo\Ford_AB12_CD4_1_MCA\config\CREIS_ProjectConst_CD391NA.pm archived 1.8
    # c:\MKS\Projects\TurboLIFT\Projects\FoMoCo\Ford_AB12_CD4_1_MCA\config\Mapping_DEVICE_CD391NA.pm archived 1.10

    # for si viewlabels:
    # C:\MKS\Projects\TurboLIFT\Projects\FIAT_CHRY_Mainsteam\FCA_AB12>si viewlabels c:\MKS\Projects\TurboLIFT\Projects\FIAT_CH
    # RY_Mainsteam\FCA_AB12\config\Mapping_QUATE_vDVHigh.pm
    # c:\MKS\Projects\TurboLIFT\Projects\FIAT_CHRY_Mainsteam\FCA_AB12\config\Mapping_QUATE_vDVHigh.pm
    # rev2_Step63_v3  1.4

    foreach my $line (@allLines) {

        #chomp if defined $line;
        next if ( $line =~ m/(Documentation|test|htmldata|.pj)\\/i );    #dont include files in Engine/Documentation, Engine/test, Engine/htmldata folders and .pj files

        if ( $line =~ m/\s+(.*)\s+archived\s+([.\d]+)/ ) {
            push( @allFiles, $1 );
        }
    }

    foreach my $file (@allFiles) {
        my $pd_path = 'PD\Win32';
        if ( $file =~ m/\Q$pd_path\E/i ) {                               #bad workaround for files within DLLs/PD/Win32 due to the presence of shared subproject within this folder (si viewlabels is not able to find the files without providing the .pj file)
            open( FILES, "si viewlabels -S Engine/modules/DLLs/DLLs.pj $file" . "|" ) || die("ERROR: cannot execute cmd\n!\n");
        }
        else {
            open( FILES, "si viewlabels $file" . "|" ) || die("ERROR: cannot execute cmd\n!\n");
        }

        my $fileRev;
        while (<FILES>) {
            if ( $_ =~ m/\s*\Q$label\E\s+([.\d]+)/ ) {
                $fileRev = $1;
                S_w2log( CONSOLE | TEXT, "\n$file, label on: $fileRev" );
            }
        }
        close(FILES);
        $fileRev = 'NOT FOUND!' unless ( defined $fileRev );
        push( @allFileRevs, [ $file, $fileRev ] );
    }

    return \@allFileRevs;
}

=head2 mks_getWorkingAndMemberRevision

I<B<Syntax : >>

     ( $workingRev, $memberRev, $shortFilepath ) = mks_getWorkingAndMemberRevision ( $file, $sandbox );

I<B<Arguments    : >>

    $file     =   filename/fullpath
    $sandbox  =   name of current sandbox

I<B<Description :>> get working revision and member revision of file in current MKS project sandbox

I<B<Return values :>> ( $workingRev, $memberRev, $shortFilepath )
     'NOT FOUND!' for $workingRev, $memberRev if file is not found in MKS

=cut

sub mks_getWorkingAndMemberRevision {
    my $file    = shift;
    my $sandbox = shift;
    my ( $memberRev, $workingRev, $shortFilepath, $filepath );

    if ( $file =~ m/\\|\// ) {    #if already a file path
        $filepath = $file;
    }
    else {
        $filepath = mks_locateFile( $file, $sandbox );    #locate file in MKS (any project)
    }

    return ( 'NOT FOUND!', 'NOT FOUND!', $file ) unless defined $filepath;    #file not found in MKS!

    $shortFilepath = mks_getPathRelativeToSubProject($filepath);              #to use si viewsandbox which needs folder/filename format!

    my $cmd      = "si viewsandbox --fields=name,memberrev,workingrev,wfdelta --filter=file:$shortFilepath --filtersubs";
    my $modified = 0;
    open( SANDBOX, $cmd . "|" ) || die("ERROR: cannot execute $cmd\n$!\n");

    #sample output on console: c:\MKS\Projects\TurboLIFT\Projects\FoMoCo\Ford_AB12_CD4_1_MCA\config\Mapping_DEVICE_CD391NA.pm 1.10 1.10
    while (<SANDBOX>) {
        chomp;
        my $line2 = $_;
        if ( $line2 =~ m!\s+Working(.*)! ) {
            S_w2log( CONSOLE | TEXT, "Working File modified...\n" );
            $modified = 1;
        }
        elsif ( $line2 =~ m!(.*)\s+([.\d]+)\s+([.\d]+)! ) {
            $memberRev  = $2;
            $workingRev = $3;
            S_w2log( CONSOLE | TEXT, "$file, working: $workingRev, memberrev: $memberRev\n" );
        }
    }
    close(SANDBOX);

    unless ( defined $workingRev ) {
        S_set_error( "File '$file' not found in current MKS sandbox", 5 );
        return ( 'NOT FOUND!', 'NOT FOUND!', 0, $shortFilepath );
    }

    return ( $workingRev, $memberRev, $modified, $shortFilepath );
}

=head2 mks_getSandboxName

I<B<Syntax : >>

     $currentSandboxProj = mks_getSandboxName ( [$type] );

I<B<Arguments    : >>

    $type is optional: can be 'project' if MKS project path (server path) is required. Else sandbox path (path on local PC) will be returned

I<B<Description :>> get name of current MKS sandbox/project

I<B<Return values :>> project path or sandbox path based on $type

=cut

sub mks_getSandboxName {
    my $type = shift;    #can be 'project' or 'sandbox'
    $type = 'sandbox' unless defined $type;

    S_w2log( CONSOLE, "\nEnter your MKS password if prompted and press Enter (password will not be visible in console) \n", 'cyan' );
    my $connect = `si connect --hostname=si-airbag-mks.de.bosch.com --port=7001`;
    my $sandboxProject = `si sandboxinfo` || die $!;

    #sample output on console:
    #	Sandbox Name: c:\MKS\Projects\TurboLIFT\Projects\FoMoCo\Ford_AB12_CD4_1_MCA\Ford_AB12_CD4_1_MCA.pj
    #	Project Name: g:/MKS/Projects/TurboLIFT/Projects/FoMoCo/Ford_AB12_CD4_1_MCA/Ford_AB12_CD4_1_MCA.pj
    #	Configuration Path: #p=g:/MKS/Projects/TurboLIFT/TurboLIFT.pj#s=Projects/Projects.pj#s=FoMoCo/FoMoCo.pj#s=Ford_AB12_CD4_
    #	1_MCA/Ford_AB12_CD4_1_MCA.pj
    #	Server: si-airbag-mks.de.bosch.com:7001
    #	Revision: 1.1
    #	Last Checkpoint: Nov 22, 2013 5:00:38 AM
    #	Members: 2000
    #	Subsandboxes: 4
    #	Line Terminator: native
    #	Project Description:
    #	Project Attributes: none
    #	Sandbox Attributes: none

    my @sandboxProj = split /\n/, $sandboxProject;
    my ($currentSandboxProj);

    if ( $type eq 'project' ) {
        my @sandbox = split / /, $sandboxProj[1];
        $currentSandboxProj = $sandbox[2];
        S_w2log( 3, "Current MKS project: $currentSandboxProj\n" );
    }
    else {    #sandbox
        my @sandbox = split / /, $sandboxProj[0];
        $currentSandboxProj = $sandbox[2];
        S_w2log( 3, "Current MKS sandbox: $currentSandboxProj\n" );
    }

    return $currentSandboxProj;
}

=head2 mks_checkMinimumRequiredEngine

I<B<Syntax : >>

     $success = mks_checkMinimumRequiredEngine($engineBaseline, $minimumRequiredEngineBaseline);

I<B<Arguments    : >>

    $engineBaseline                 = actual engine baseline
    $minimumRequiredEngineBaseline  = minimum engine baseline

I<B<Description :>> check that Engine is minimum required

I<B<Return values :>> return 0 on error/mismatch, else return 1

=cut

sub mks_checkMinimumRequiredEngine {
    my $engineBaseline                = shift;
    my $minimumRequiredEngineBaseline = shift;

    my $engineBaseline_v                = version->new( "v" . $engineBaseline );                  #example format v1.2.1
    my $minimumRequiredEngineBaseline_v = version->new( "v" . $minimumRequiredEngineBaseline );

    return 0 if ( $engineBaseline_v < $minimumRequiredEngineBaseline_v );

    return 1;
}

=head2 mks_compareFileRevisions

I<B<Syntax : >>

     $return = mks_compareFileRevisions ( $shortFilepath, $expRev, $workingRev, $revCompare );

I<B<Arguments    : >>

    $shortFilepath = relative path of file
    $expRev = expected MKS revision
    $workingRev = working revision
    $revCompare can be 'EXACT' to check if $expRev and $workingRev are same
    $revCompare can be 'ATLEAST' to check if $workingRev is at least (greater than or equal to) $expRev

I<B<Description :>> compare MKS file revisions

I<B<Return values :>> return 0 on error/mismatch, else return 1

=cut

sub mks_compareFileRevisions {
    my $shortFilepath = shift;
    my $expRev        = shift;
    my $workingRev    = shift;
    my $modified      = shift;
    my $revCompare    = shift;

    return 0 if ( $workingRev eq 'NOT FOUND!' or $expRev eq 'NOT FOUND!' );

    if ( $revCompare eq 'EXACT' ) {    #eval - compare version strings
        if ( $expRev eq $workingRev ) {
            S_w2log( 4, "Working revision of $shortFilepath ($workingRev) matches the expected MKS revision ($expRev)\n" );
            return 1;
        }
        else {
            S_w2log( 4, "Working revision of $shortFilepath ($workingRev) does not match the expected MKS revision ($expRev)\n" );
            return 0;
        }
    }
    elsif ( $revCompare eq 'ATLEAST' ) {

        #eval - compare version numbers
        my $working_v = version->new( "v" . $workingRev );    #example format v1.2.1
        my $label_v   = version->new( "v" . $expRev );
        if ( $working_v >= $label_v ) {
            S_w2log( 4, "Working revision of $shortFilepath ($workingRev) is greater or equal to the expected MKS revision ($expRev)\n" );
            return 1;
        }
        else {
            S_w2log( 4, "Working revision of $shortFilepath ($workingRev) is NOT greater than or equal to the expected MKS revision ($expRev)\n" );
            return 0;
        }
    }

}

=head2 mks_getPathRelativeToSubProject

I<B<Syntax : >>

     $relPathToSubProj = mks_getPathRelativeToSubProject ( $absPath );

I<B<Arguments    : >>

    $absPath = absolute file path in sandbox

I<B<Description :>> get path of file relative to subproject path (required by si viewproject)

I<B<Return values :>> returns path of file relative to subproject path

=cut

sub mks_getPathRelativeToSubProject {
    my $path = shift;

    $path = File::Spec->abs2rel($path);
    $path =~ s!\\!/!g;    #replace backslash with forward slash

    return $path if ( $path =~ m/TC_FunctionLib\/TC_Project/ );    #for project FuncLibs

    my @subProjPaths = ( 'Engine/modules/DLLs/PSDiagSharedDLLs', 'Engine/modules/DLLs', 'Engine/modules/TC_FunctionLib/TC_CustLib', 'Engine', 'TCs/TCs_TNT', 'TCs/TCs_CustLib', );

    foreach my $projpath (@subProjPaths) {
        return $1 if ( $path =~ m/\Q$projpath\E\/(.*)/i );
    }

    return $path;                                                  #if none above matches

}

1;
__END__
