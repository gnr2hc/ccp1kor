# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::                                          ::: #
# ::: this file is only used for documentation ::: #
# :::                                          ::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #

=head1 NAME

TurboLIFT REST API description 

=head1 DESCRIPTION

With the command line argument B<-server_mode> TurboLIFT will be put into server mode after execution of the init campaign.
See the link below for an overview of all command line arguments:

=for html
<a href='../index.html#EXECUTE-TurboLIFT-WITH-A-BATCH-FILE'>EXECUTE TurboLIFT WITH A BATCH FILE</a>

In server mode TurboLIFT will listen on http port 3000 for REST API requests. 
Bosch IT infrastructure does not allow for sending such requests across different PCs.
Therefore REST API requests can only be sent on http://localhost:3000/.


A client must register himself first on the server before he is allowed to trigger any actions, 
because TurboLIFT can only handle one test configuration at a time. 
Registering is done with a B<POST /clients> request. 
If registering is successful then the client is allowed to send any other request to the server.
If registering is B<not> successful then the client is B<not> allowed to send any other request to the server.
The server will not check if a request comes from a registered or from a non-registered client.
So it is the B<clients responsibility> to stick to the rules mentioned above.
If a registered client has finished all actions on the server 
then he has to either unregister on the server with the B<DELETE /clients> request
or shutdown the server with the B<POST /shutdown> request.

Once a client is registered successfully he can trigger actions on the server:

=over

=item Use case ServerMode execute test cases and create report

    # Execute RQM test case: one RQM test case can contain one or more TurboLIFT testcases 

    # register client
    POST http://localhost:3000/clients?name=rqmclientxyz

    # add TurboLIFT test cases to be executed to execution list
    PUT http://localhost:3000/testcases/1?name=<name1>
    PUT http://localhost:3000/testcases/2?name=<name2>
    ...

    # execute all tests in the execution list
    PUT http://localhost:3000/executions/1

    # create a report for the execution
    PUT http://localhost:3000/reports/1

    # get report path and verdict
    GET http://localhost:3000/reports/1

    # finally unregister client
    DELETE http://localhost:3000/clients?name=rqmclientxyz

=item Use case ServerMode execute code snippets

    # Execute code snippets, e.g. from a GUI or a standalone tool

    # register client
    POST http://localhost:3000/clients?name=codeclientxyz

    PUT http://localhost:3000/codelines/1
        <codelines1>

    PUT http://localhost:3000/codelines/2
        <codelines2>

    ...

=back


=head1 Base URL

All URLs referenced below have the following base:

    http://localhost:3000

=head1 Functions




=head2 GET /

B<Request:>

    GET <Base URL>/

B<Description:>

Return the TurboLIFT server welcome message

B<Description:>

Return the TurboLIFT server welcome message

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    {'message' : 'TurboLIFT Rest Server'}




=head2 POST /clients

B<Request:>

    POST <Base URL>/clients?name=<name>

B<Description:>

Register the client with name = <name> on the server if no client is registered yet.
If a client with another name is already registered then an error message will be returned.

B<URL Parameter:>

=over

=item name

name of the client to be registered

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)
    403 (forbidden) if no name is given or a client with another name is already registered

B<Example Response Data:>

    {"message" : "Client successfully registered on the server with name = '<name>'"}





=head2 DELETE /clients

B<Request:>

    DELETE <Base URL>/clients?name=<name>

B<Description:>

Unregister the client with name = <name> on the server if it is registered.
If the client with name = <name> is not registered then nothing will be done.

B<URL Parameter:>

=over

=item name

name of the client to be unregistered

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)
    403 (forbidden) if no name is given

B<Example Response Data:>

    {"message" : "Client with name '<name>' is no more registered on the server"}




=head2 GET /clients

B<Request:>

    GET <Base URL>/clients

B<Description:>

Return the list of registered client ids.

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    ["1"]






=head2 GET /testcases

B<Request:>

    GET <Base URL>/testcases

B<Description:>

Return the list of testcase item ids.

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    ["1", "2"]




=head2 DELETE /testcases

B<Request:>

    DELETE <Base URL>/testcases

B<Description:>

Empty the list of testcase item ids.

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

    200: successful operation

B<Example Response Data:>

    {'message' : 'Deleted all testcase items'}




=head2 PUT /testcases/{id}

B<Request:>

    PUT <Base URL>/testcases/<id>?name=<name>

B<Description:>

Create/update a testcase item.

B<URL Parameter:>

=over

=item id

ID of testcase item to create/update

=item name

name of TurboLIFT testcase ("<testcase module>" or "<testcase module>.<parameter set>")

=back

B<Data Parameter:>

Optionally testcase parameter data can be given:

    {
        "TC_PARAMETER" : { 
            <parameter1 name> : { <type1> : <value1>},
            <parameter2 name> : { <type2> : <value2>},
            ...
        }
    }

<parameter name> is a string

<type> is one of: "SCALAR", "LIST", "HASH"

<value> is a scalar, list or hash, depending on <type>

If testcase parameter data are given then those data will be used for execution of the testcase with the given name, 
even if a parameter set exists in TurboLIFT for that testcase.

B<Response Status Code:>

    200 (successful operation)
    403 (forbidden) if name is not given or request body hash does not have a key 'TC_PARAMETER'

B<Example Response Data:>

    {"message" : "Created testcase item with index = <id>   name = <name>"}




=head2 GET /testcases/{id}

B<Request:>

    GET <Base URL>/testcases/<id>

B<Description:>

Return a single testcase item.

B<URL Parameter:>

=over

=item id

ID of testcase item to return

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)
    403 (forbidden) if testcase item does not exist

B<Example Response Data:>

    {
        "name" : "tc1.mypar",
        "TC_PARAMETER" : { ... },
    }

Key "TC_PARAMETER" is optional.




=head2 GET /executions

B<Request:>

    GET <Base URL>/executions

B<Description:>

Return the list of execution item ids.

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    ["1", "2"]




=head2 PUT /executions/{id}

B<Request:>

    PUT <Base URL>/executions/<id>

B<Description:>

Create an execution item. 
If the execution item does not yet exist then the execution of all testcase items that are currently in the list of testcase items will be triggered.
If the execution item exists already then nothing will be done.

B<URL Parameter:>

=over

=item id

ID of execution item to create

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    {"message" : "Created new execution with index = {id}. Verdict is ..."}




=head2 GET /executions/{id}

B<Request:>

    GET <Base URL>/executions/<id>

B<Description:>

Return a single execution item.

B<URL Parameter:>

=over

=item id

ID of execution item to return

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)
    403 (forbidden) if execution item does not exist

B<Example Response Data:>

    {
        "testcases" : {
            "0": {
                "report_index": 'IC',
                "verdict": <init campaign verdict>,
                "ALL_TC": { ... },
            },
            "1": {
                "report_index": <index in report>,
                "verdict": <testcase verdict>,
                "ALL_TC": { ... },
            },
            "2": { ... },
            ...
        },
        "execution_verdict" : <consolidated verdict>,
    }




=head2 GET /reports

B<Request:>

    GET <Base URL>/reports

B<Description:>

Return the list of report item ids.

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    ["1", "2"]



=head2 PUT /reports/{id}

B<Request:>

    PUT <Base URL>/reports/<id>

B<Description:>

Create a report item. 
If the report item does not yet exist then the currently opened TurboLIFT report will be finalized 
and a new report (in a new report folder) will be opened.
If the report item exists already then nothing will be done.

B<URL Parameter:>

=over

=item id

ID of report item to create

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    {"message" : "Created new report with index = <id>"}




=head2 GET /reports/{id}

B<Request:>

    GET <Base URL>/reports/<id>

B<Description:>

Return a single report item.

B<URL Parameter:>

=over

=item id

ID of report item to return

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)
    403 (forbidden) if report item does not exist

B<Example Response Data:>

    {
        "report_html" : "<path to report folder>\\_main__result.html",
        "report_verdict" : <consolidated report verdict>,
    }





=head2 GET /codelines

B<Request:>

    GET <Base URL>/codelines

B<Description:>

Return the list of codeline item ids.

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    ["1", "2"]




=head2 PUT /codelines/{id}

B<Request:>

    PUT <Base URL>/codelines/<id>

B<Description:>

Create a codelines item. 
Executes the code snippet that is given in Data Parameter.

B<URL Parameter:>

=over

=item id

ID of codelines item to create

=back

B<Data Parameter:>

Any TurboLIFT Perl code snippet as (multi-line) string: <ode snippet>

B<Response Status Code:>

    200 (successful operation)

B<Example Response Data:>

    {"message" : "Executed code with index = <id>   code = <ode snippet>   return value = <return value>"}




=head2 GET /codelines/{id}

B<Request:>

    GET <Base URL>/codelines/<id>

B<Description:>

Return a single codeline item.

B<URL Parameter:>

=over

=item id

ID of codeline item to return

=back

B<Data Parameter:>

none

B<Response Status Code:>

    200 (successful operation)
    403 (forbidden) if codeline item does not exist

B<Example Response Data:>

    {
        "code" : "<given code snippet>",
        "return_value" : <return value of code snippet>,
    }




=head2 POST /shutdown

B<Request:>

    POST <Base URL>/shutdown

B<Description:>

Triggers the shutdown of the server.

B<URL Parameter:>

none

B<Data Parameter:>

none

B<Response Status Code:>

none




=head1 Models

The following data models are used for the different resources.

=head2 clients

    $clients_href = {
        1 => {
            name => <name>,
        },
    }

=head2 testcases

    $testcases_href = {
        <index> => {
            name => <name>,
            TC_PARAMETER => {  optional
                <parameter1 name> => { <type1> => <value1>},
                <parameter2 name> => { <type2> => <value2>},
                ...
            },
        },
        ...
    }

=head2 executions

    $executions_href = {
        <index> => {
            "testcases" => {
                0 => {
                    report_index => 'IC',
                    verdict => <init campaign verdict>,
                    ALL_TC => { ... },
                },
                1 => {
                    report_index => <index in report>,
                    verdict => <testcase verdict>,
                    ALL_TC => { ... },
                },
                2 => { ... },
                ...
            },
            execution_verdict => <consolidated verdict>,
        },
        ...
    }

=head2 reports

    $reports_href = {
        <index> => {
            report_html => "<path to report folder>\\_main__result.html",
            report_verdict => <consolidated report verdict>,
        },
        ...
    }

=head2 codelines

    $codelines_href = {
        <index> => {
            code => <code lines>,
            return_value => <return value of executed code>,
        },
        ...
    }

=cut

1;