# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package LIFT_securityAlgorithms;

use strict;
use warnings;
use Encoding::BER::DER;
use Crypt::Mode::CTR;
use Data::Dumper;

use LIFT_general;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  SECA_DER_decode
  SECA_DER_encode
  SECA_AES_CTR_encrypt
  SECA_AES_CTR_decrypt
  SECA_control_security_printouts
);

my $objDER    = Encoding::BER::DER->new();
my $objAESCTR = Crypt::Mode::CTR->new('AES');

my %tag_defination_mapping = (
    '0'  => { name => 'version' },
    '1'  => { name => 'messageType' },
    '10' => { name => 'useCaseID' },
    '16' => { name => 'nonce' },
    '17' => { name => 'deviceID' },
    '32' => { name => 'trustAnchor' },
    '33' => { name => 'authzOID' },
    '34' => { name => 'authzBits' },
    '35' => { name => 'authzMask' },
    '41' => { name => 'signature' },
    '42' => { name => 'certChain' },
    '4'  => { name => 'certificate' },
);

my $enable_print_outs = 0;    # This will print security related information in the logs.
                              # so this flag is introducted to enable only for debugging

my $challenge_offline_aref = [
    0x30, 0x81, 0x9F, 0x80, 0x01, 0x01, 0x81, 0x01, 0x00, 0x8A, 0x01, 0x00, 0x90, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x91, 0x30, 0x4D, 0x50, 0x48, 0x35, 0x33, 0x39, 0x20, 0x20, 0x20, 0x20, 0x03, 0xFF, 0x71, 0x00, 0x49, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x9F, 0x20, 0x1F, 0x52, 0x42, 0x41, 0x31, 0x41, 0x42, 0x53, 0x45, 0x53,
    0x50, 0x31, 0x2F, 0x4F, 0x45, 0x4D, 0x41, 0x31, 0x3A, 0x43, 0x4E, 0x3A, 0x44, 0x55, 0x4D, 0x4D, 0x59, 0x30, 0x30, 0x30, 0x30, 0x31, 0x9F, 0x21, 0x0F, 0x2B, 0x06, 0x01, 0x04, 0x01, 0xA9, 0x46, 0x93, 0x48, 0x15, 0x02, 0x01, 0x67, 0x01, 0x01, 0x9F, 0x22,
    0x10, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x10, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9F, 0x23, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x10, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
];

=head1 NAME

LIFT_securityAlgorithms

=head1 SYNOPSIS

    use LIFT_securityAlgorithms;

    $decoded_data_href = SECA_DER_decode( $data_to_decode_aref ); 
    $der_encoded_int_aref  = SECA_DER_encode( $data_to_encode_href  );
    
    $plainHexStr  = SECA_AES_CTR_decrypt($ciphertext, $key,  $iv );
    $cipherHexStr = SECA_AES_CTR_encrypt($plaintext, $key,  $iv );


=head1 DESCRIPTION

Module for security algorithms for performing encoding or decoding.

=head1 FUNCTIONS

=head2 SECA_DER_decode

    $decoded_data_href = SECA_DER_decode($data_to_decode_aref );
    
This will decode '$data_to_decode_aref' (which shall be DER encoded)  And it will provide functionality to change this decoded data. 

Use case if you want to modify the challenge from ECU or response from KMS.

See return value how this can be done.   
    
B<Arguments:>

=over

=item $data_to_decode_aref

It is an array of integer values. Example of this can be a challenge received from the ECU. This is der encoded. 

=back

B<Return Values:>

=over

=item $decoded_data_href

This will return two sub hash with following keys :
   
B<decoded_for_modification>
   
- Here you can  get following : 'value_hexstring', 'value_charstring' , 'tagnum' , 'number_of_bytes'.

- You can modify 'value_hexstring' or check other values like number_of_bytes etc.


B<decoded_raw>

- B<PLEASE DO NOT MODIFY THIS>.

- this is required to encode back your modified values to the integer array which is a input for 'KMS' or 'ECU'. 

- Hash is of below format : 
  
    {
        'decoded_for_modification' => {
            'messageType' => {
                'number_of_bytes'  => <number of bytes>,
                'tagnum'           => <tag number>,
                'value_hexstring'  => <value as hex string>,
                'value_charstring' => <value as character string>,
            }
            ...
            so on
        },
        'decoded_raw' => {
            'identval' => 48,
            'tagnum'   => 16,
            'value'    => [
                {
                    'identval' => 129,
                    'tagnum'   => 1,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 1 ]
                },
                ...
                so on
            ],
            'type' => [ 'universal', 'constructed', 'sequence' ]
        }
    };


=back

B<Examples:>
    
B<Example 1 : For decoding Challenge and further how to modify it>
    
    my $challenge_aref = [0x30, 0x81, 0x9F, 0x80, 0x01, 0x01, 0x81, 0x01, 0x00, 0x8A, 0x01, 0x00, 0x90,
           0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x91, 0x30, 0x4D, 0x50, 0x48, 0x35, 0x33, 
           0x39, 0x20, 0x20, 0x20, 0x20, 0x03, 0xFF, 0x71, 0x00, 0x49, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x02, 0x02, 0x02, 0x02, 
           0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x9F, 0x20, 0x1F, 0x52, 0x42,
           0x41, 0x31, 0x41, 0x42, 0x53, 0x45, 0x53, 0x50, 0x31, 0x2F, 0x4F, 0x45, 0x4D, 0x41, 0x31, 0x3A,
           0x43, 0x4E, 0x3A, 0x44, 0x55, 0x4D, 0x4D, 0x59, 0x30, 0x30, 0x30, 0x30, 0x31, 0x9F, 0x21, 0x0F, 
           0x2B, 0x06, 0x01, 0x04, 0x01, 0xA9, 0x46, 0x93, 0x48, 0x15, 0x02, 0x01, 0x67, 0x01, 0x01, 0x9F,
           0x22, 0x10, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x10, 0x08, 0x00, 0x00, 0x00, 0x00,
           0x00, 0x00, 0x9F, 0x23, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x10, 0x08, 0x00, 
           0x00, 0x00, 0x00, 0x00, 0x00 ];  
						
    my $decoded_data_href = SECA_DER_decode( $challenge_aref ); 
    
    $decoded_data_href =
    {
        'decoded_for_modification' => {
            'authzBits' => {
                'number_of_bytes'  => 16,
                'tagnum'           => 34,
                'value_hexstring'  => '300000000000007f0000000000a7ffff',
                'value_charstring' => '  '
            },
            'trustAnchor' => {
                'number_of_bytes'  => 27,
                'tagnum'           => 32,
                'value_hexstring'  => '52424131414952424147312f434f4d4d4f4e313a434e3030303031',
                'value_charstring' => 'RBA1AIRBAG1/COMMON1:CN00001'
            },
            'authzMask' => {
                'number_of_bytes'  => 16,
                'tagnum'           => 35,
                'value_hexstring'  => '300000000000007f0000000000a7ffff',
                'value_charstring' => '  '
            },
            'version' => {
                'number_of_bytes'  => 1,
                'tagnum'           => 0,
                'value_hexstring'  => '01',
                'value_charstring' => ' '
            },
            'nonce' => {
                'number_of_bytes'  => 8,
                'tagnum'           => 16,
                'value_hexstring'  => '1b0f07d8c8e843dc',
                'value_charstring' => ' '
            },
            'authzOID' => {
                'number_of_bytes'  => 15,
                'tagnum'           => 33,
                'value_hexstring'  => '2b06010401a9469348150201090001',
                'value_charstring' => ' '
            },
            'deviceID' => {
                'number_of_bytes'  => 32,
                'tagnum'           => 17,
                'value_hexstring'  => '4e31585933372d3531200bff2d00420000000000000000000000000000000000',
                'value_charstring' => ' '
            },
            'useCaseID' => {
                'number_of_bytes'  => 1,
                'tagnum'           => 10,
                'value_hexstring'  => '00',
                'value_charstring' => ' '
            },
            'messageType' => {
                'number_of_bytes'  => 1,
                'tagnum'           => 1,
                'value_hexstring'  => '00',
                'value_charstring' => ' '
            }
        },
        'decoded_raw' => {
            'identval' => 48,
            'tagnum'   => 16,
            'value'    => [
                {
                    'identval' => 128,
                    'tagnum'   => 0,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 0 ]
                },
                {
                    'identval' => 129,
                    'tagnum'   => 1,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 1 ]
                },
                {
                    'identval' => 138,
                    'tagnum'   => 10,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 10 ]
                },
                {
                    'identval' => 144,
                    'tagnum'   => 16,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 16 ]
                },
                {
                    'identval' => 145,
                    'tagnum'   => 17,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 17 ]
                },
                {
                    'identval' => 128,
                    'tagnum'   => 32,
                    'value'    => 'RBA1AIRBAG1/COMMON1:CN00001',
                    'type'     => [ 'context', 'primitive', 32 ]
                },
                {
                    'identval' => 128,
                    'tagnum'   => 33,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 33 ]
                },
                {
                    'identval' => 128,
                    'tagnum'   => 34,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 34 ]
                },
                {
                    'identval' => 128,
                    'tagnum'   => 35,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 35 ]
                }
            ],
            'type' => [ 'universal', 'constructed', 'sequence' ]
        }
    };

    
If you want to modify B<authzBits> then: 

    my $decoded_data_href = SECA_DER_decode( $challenge_aref ); 
    my $value = $decoded_data_href->{decoded_for_modification}{authzBits}{value_hexstring} ;
    # here value is '300000000000007f0000000000a7ffff' and if you want to modify
    # to '300000000000007f0000000000a7ff00'
    $decoded_data_href->{decoded_for_modification}{authzBits}{value_hexstring} = 
                                                            '300000000000007f0000000000a7ff00';
    SECA_DER_encode($decoded_data_href);

B<Example 2 : For decoding signature from KMS and further how to modify it>
    
    my $responseKMS_aref = [
        0x30, 0x82, 0x03, 0xB8, 0x80, 0x01, 0x01, 0x81, 0x01, 0x01, 0x9F, 0x29, 0x82, 0x01, 0x00, 0x2A,
        0xF8, 0x7A, 0x69, 0x40, 0x76, 0xC5, 0x3F, 0x88, 0x13, 0x50, 0xC6, 0xA3, 0x04, 0x53, 0xDA, 0x76,
        0xE4, 0x49, 0x54, 0xB9, 0xC4, 0xCA, 0x29, 0x85, 0xD7, 0x44, 0xF7, 0x7C, 0x6B, 0xF4, 0xA3, 0x0C,
        0x2F, 0x20, 0x09, 0x5C, 0x5B, 0x27, 0x44, 0xF4, 0x59, 0xEB, 0x7F, 0xA3, 0xE3, 0xE1, 0x89, 0xEB,
        0x02, 0xC1, 0x96, 0x44, 0xD8, 0xB6, 0xA2, 0x64, 0x3A, 0x78, 0x1F, 0x74, 0xF4, 0x61, 0x63, 0x4B,
        0x56, 0xDA, 0xDD, 0x4A, 0x36, 0x47, 0x9E, 0x80, 0xEC, 0xD9, 0x07, 0x95, 0xE4, 0xA8, 0x9F, 0x74,
        0xA8, 0x32, 0x72, 0xA5, 0xDA, 0x95, 0xB2, 0x52, 0xEF, 0x76, 0xF4, 0x43, 0xE8, 0x2E, 0x3F, 0xC6,
        0x2B, 0x0F, 0x23, 0x12, 0x16, 0x8F, 0x0C, 0x57, 0x02, 0xD5, 0x11, 0xB6, 0x00, 0xAB, 0x9D, 0x27,
        0x5C, 0x98, 0x59, 0x7A, 0xB2, 0x13, 0xDF, 0x17, 0x00, 0x3A, 0xD1, 0x85, 0x28, 0xBD, 0xEC, 0x6E,
        0xDB, 0xDF, 0xCA, 0xAF, 0x10, 0x8F, 0x33, 0xBB, 0x6A, 0x66, 0xFF, 0x5D, 0x44, 0x5D, 0x8B, 0xCF,
        0x0E, 0x25, 0xD9, 0xDB, 0x8F, 0x76, 0x0E, 0xB9, 0x9A, 0xA4, 0x5F, 0x87, 0xC7, 0x28, 0x51, 0x89,
        0x1F, 0x82, 0xA5, 0x3F, 0xAE, 0x4B, 0x0F, 0xC3, 0xC2, 0xF3, 0xD4, 0xAC, 0xA7, 0x9C, 0x11, 0xC6,
        0x9D, 0x8B, 0xA4, 0x56, 0x61, 0xFC, 0x2F, 0xCC, 0xC3, 0xAA, 0xA0, 0xF7, 0x8F, 0x84, 0xC3, 0x5D,
        0xC5, 0xB5, 0x21, 0x16, 0xDD, 0x2E, 0x0A, 0xF2, 0x50, 0x51, 0xDB, 0x9C, 0xDC, 0x19, 0x66, 0x2B,
        0x78, 0x75, 0x74, 0x03, 0xD2, 0xCD, 0x20, 0x51, 0xF1, 0xC9, 0xD4, 0x07, 0x3A, 0xDE, 0x61, 0x95,
        0x46, 0x4B, 0xD4, 0xB9, 0xB7, 0xB0, 0x86, 0x81, 0xD4, 0x38, 0x07, 0xD0, 0x88, 0xC6, 0x1C, 0xD6,
        0x4F, 0x72, 0xBB, 0xFF, 0x83, 0xCC, 0x9F, 0x34, 0xF1, 0xB0, 0xFA, 0xF3, 0xCA, 0xBF, 0x6F, 0xBF,
        0x2A, 0x82, 0x02, 0xA8, 0x04, 0x82, 0x02, 0xA4, 0x7F, 0x21, 0x82, 0x02, 0x9F, 0x7F, 0x4E, 0x82,
        0x01, 0x95, 0x5F, 0x29, 0x01, 0x00, 0x42, 0x1B, 0x52, 0x42, 0x41, 0x31, 0x41, 0x49, 0x52, 0x42, 
        0x41, 0x47, 0x31, 0x2F, 0x43, 0x4F, 0x4D, 0x4D, 0x4F, 0x4E, 0x31, 0x3A, 0x43, 0x4E, 0x30, 0x30, 
        0x30, 0x30, 0x31, 0x7F, 0x49, 0x82, 0x01, 0x18, 0x06, 0x0D, 0x2B, 0x06, 0x01, 0x04, 0x01, 0xA9,
        0x46, 0x93, 0x48, 0x15, 0x01, 0x08, 0x01, 0x81, 0x82, 0x01, 0x00, 0xB4, 0x51, 0x04, 0x0B, 0x0C, 
        0x8D, 0x1F, 0x12, 0x3A, 0x24, 0x17, 0x9C, 0x15, 0x65, 0x69, 0x37, 0xD9, 0xE9, 0x85, 0x9F, 0x38, 
        0xC8, 0x31, 0xCF, 0x9C, 0xE1, 0xE1, 0xB0, 0x6B, 0x16, 0x75, 0xFC, 0xB7, 0xDF, 0xBF, 0x33, 0x86,
        0xA1, 0x25, 0x79, 0xC9, 0x5A, 0x84, 0x31, 0x67, 0xC2, 0x23, 0xB9, 0x7B, 0xB7, 0x23, 0x76, 0x2B, 
        0xDA, 0xF1, 0xCE, 0xCA, 0x89, 0x92, 0xB3, 0x74, 0x95, 0xCF, 0x4A, 0xB4, 0xF8, 0x7A, 0x4F, 0xA3, 
        0xF9, 0x96, 0xD5, 0xFF, 0xFE, 0x7A, 0xF6, 0x4A, 0xB1, 0x86, 0xE8, 0x17, 0x68, 0x81, 0xCE, 0x44,
        0x1C, 0x76, 0x5B, 0x7C, 0xB3, 0xA2, 0x59, 0xE6, 0x21, 0x76, 0x1A, 0xFE, 0xA4, 0xD4, 0x84, 0xA1, 
        0x4B, 0x62, 0x96, 0x7F, 0x57, 0x5F, 0xE5, 0xF9, 0x96, 0x36, 0x6D, 0xBF, 0x34, 0x1C, 0x4D, 0xF5, 
        0x91, 0xE3, 0xB6, 0x3B, 0x3D, 0x7F, 0xC9, 0x8D, 0xDC, 0x82, 0x21, 0x8C, 0x41, 0x82, 0x6B, 0x71,
        0x8D, 0x3B, 0xB4, 0x74, 0xC6, 0xBA, 0x63, 0x77, 0x78, 0x0A, 0x9F, 0xCE, 0x8A, 0x10, 0x98, 0x7C, 
        0x27, 0x4C, 0x31, 0xAF, 0x6E, 0x12, 0x3D, 0xBC, 0x48, 0x27, 0xB1, 0x8C, 0xAA, 0x2B, 0x23, 0x6D, 
        0x0F, 0x13, 0x97, 0x72, 0xF2, 0x6B, 0x8A, 0xE5, 0x66, 0xB6, 0x75, 0x58, 0x7F, 0x9D, 0x5A, 0x42,
        0x5A, 0x61, 0x4F, 0xB4, 0x07, 0xB4, 0x36, 0x79, 0x5E, 0x35, 0xA8, 0x50, 0xB4, 0x2A, 0x2C, 0x66, 
        0x56, 0xE7, 0x37, 0x5A, 0xA6, 0xF0, 0x2D, 0xCE, 0xA2, 0x38, 0xB9, 0xD9, 0xE7, 0xE3, 0xFE, 0x51, 
        0xF3, 0x04, 0xFC, 0x49, 0xD0, 0x3C, 0xA1, 0x61, 0xBD, 0x9D, 0x6F, 0x3F, 0xE8, 0xDE, 0xC0, 0xAC,
        0x65, 0xCE, 0x68, 0xCA, 0x38, 0x04, 0x98, 0x21, 0x52, 0x6F, 0xF1, 0x42, 0xB9, 0x8E, 0x27, 0x52, 
        0x7F, 0xC4, 0x63, 0x82, 0x28, 0x4E, 0x2B, 0xD7, 0x03, 0x49, 0x97, 0x82, 0x03, 0x01, 0x00, 0x01, 
        0x5F, 0x20, 0x1C, 0x52, 0x42, 0x41, 0x34, 0x43, 0x33, 0x39, 0x43, 0x36, 0x36, 0x32, 0x33, 0x34,
        0x38, 0x46, 0x39, 0x31, 0x31, 0x38, 0x37, 0x3A, 0x50, 0x4E, 0x30, 0x30, 0x30, 0x30, 0x31, 0x7F, 
        0x4C, 0x23, 0x06, 0x0F, 0x2B, 0x06, 0x01, 0x04, 0x01, 0xA9, 0x46, 0x93, 0x48, 0x15, 0x02, 0x01, 
        0x09, 0x00, 0x01, 0x53, 0x10, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x00, 0x00, 0x00,
        0x00, 0x00, 0xA7, 0xFF, 0xFF, 0x5F, 0x25, 0x06, 0x01, 0x08, 0x00, 0x07, 0x03, 0x01, 0x5F, 0x24, 
        0x06, 0x02, 0x00, 0x00, 0x07, 0x03, 0x00, 0x5F, 0x37, 0x82, 0x01, 0x00, 0xB0, 0x4B, 0x10, 0x62, 
        0xF7, 0xC1, 0x89, 0xC3, 0xFE, 0xE8, 0x76, 0x57, 0x99, 0xA8, 0x1B, 0x60, 0x61, 0xEB, 0x34, 0x40,
        0xA1, 0x2B, 0x93, 0xB1, 0x68, 0x2E, 0x43, 0x56, 0x63, 0xD8, 0x3C, 0x75, 0xA2, 0x89, 0xFD, 0x2B, 
        0x33, 0x86, 0x27, 0x7D, 0xF6, 0xF7, 0x07, 0xFD, 0xDF, 0x1E, 0x73, 0xAE, 0xC5, 0x3E, 0xDA, 0xEF, 
        0x7D, 0x64, 0x26, 0x73, 0x1C, 0xBB, 0x24, 0xFE, 0xFB, 0x88, 0x10, 0xF3, 0x27, 0xE7, 0xAF, 0x95,
        0x8E, 0xBE, 0xF3, 0x62, 0xBE, 0x3B, 0x37, 0x96, 0x94, 0xC2, 0xBA, 0x31, 0xA0, 0x5E, 0x73, 0x54, 
        0x23, 0xBE, 0x35, 0xF2, 0x1D, 0xE4, 0xDF, 0x30, 0xBF, 0x63, 0x97, 0x01, 0x43, 0x26, 0x56, 0x47, 
        0xAC, 0x4A, 0x11, 0x4A, 0xA2, 0x56, 0x1D, 0x19, 0x78, 0x1B, 0x14, 0x1F, 0xB6, 0xDE, 0x2C, 0xAC,
        0x02, 0x9C, 0x63, 0xE3, 0x56, 0xC0, 0x3F, 0x40, 0xCC, 0xFB, 0x78, 0x06, 0x0A, 0x24, 0x16, 0x7E, 
        0xF2, 0xB2, 0x75, 0x82, 0xBF, 0xA7, 0x37, 0x8B, 0x48, 0xD4, 0x01, 0x7F, 0xC4, 0x06, 0x89, 0x17, 
        0xEB, 0xE6, 0x52, 0x0E, 0xE2, 0x5C, 0x65, 0x59, 0x9F, 0xBA, 0xC7, 0xD4, 0xD0, 0x24, 0x6D, 0x5E,
        0x4C, 0xB2, 0xBD, 0xEE, 0xBA, 0x8D, 0x74, 0xD4, 0xC3, 0xDD, 0x28, 0xEC, 0x92, 0x87, 0x6E, 0xE9, 
        0x73, 0x0A, 0x2B, 0xD0, 0xF7, 0x4D, 0xC6, 0x09, 0xB0, 0xA1, 0x8B, 0xDB, 0xD0, 0xDC, 0x0F, 0xDF, 
        0xDD, 0x0D, 0x06, 0x26, 0xA1, 0x9F, 0x4A, 0x33, 0xD6, 0x12, 0x59, 0xBD, 0xF9, 0x3F, 0x4A, 0xD3,
        0x51, 0x62, 0x03, 0x2C, 0xB6, 0xD0, 0x1F, 0x18, 0xC5, 0x04, 0xC6, 0x78, 0xFA, 0x20, 0xDC, 0xF5, 
        0xEB, 0xE9, 0xEF, 0x59, 0xD8, 0x98, 0x60, 0x9E, 0xF1, 0x5E, 0x9E, 0x67, 0x4E, 0x67, 0xA0, 0x61, 
        0x3C, 0x18, 0xD4, 0x56, 0xF2, 0x10, 0x1D, 0x41, 0xA3, 0xB6, 0xE1, 0xF3
    ];
    
    my $decoded_data_href = SECA_DER_decode( $responseKMS_aref ); 
    
    $decoded_data_href =
    {
        'decoded_for_modification' => {
            'signature' => {
                'number_of_bytes' => 256,
                'tagnum'          => 41,
                'value_hexstring' =>
    '2af87a694076c53f881350c6a30453da76e44954b9c4ca2985d744f77c6bf4a30c2f20095c5b2744f459eb7fa3e3e189eb02c19644d8b6a2643a781f74f461634b56dadd4a36479e80ecd90795e4a89f74a83272a5da95b252ef76f443e82e3fc62b0f2312168f0c5702d511b600ab9d275c98597ab213df17003ad18528bdec6edbdfcaaf108f33bb6a66ff5d445d8bcf0e25d9db8f760eb99aa45f87c72851891f82a53fae4b0fc3c2f3d4aca79c11c69d8ba45661fc2fccc3aaa0f78f84c35dc5b52116dd2e0af25051db9cdc19662b78757403d2cd2051f1c9d4073ade6195464bd4b9b7b08681d43807d088c61cd64f72bbff83cc9f34f1b0faf3cabf6f',
                'value_charstring' =>' '
            },
            'version' => {
                'number_of_bytes'  => 1,
                'tagnum'           => 0,
                'value_hexstring'  => '01',
                'value_charstring' => ' '
            },
            'messageType' => {
                'number_of_bytes'  => 1,
                'tagnum'           => 1,
                'value_hexstring'  => '01',
                'value_charstring' => ' '
            },
            'certChain' => {
                'certificate' => {
                    'number_of_bytes' => 676,
                    'tagnum'          => 4,
                    'value_hexstring' =>
    '7f2182029f7f4e8201955f290100421b52424131414952424147312f434f4d4d4f4e313a434e30303030317f49820118060d2b06010401a94693481501080181820100b451040b0c8d1f123a24179c15656937d9e9859f38c831cf9ce1e1b06b1675fcb7dfbf3386a12579c95a843167c223b97bb723762bdaf1ceca8992b37495cf4ab4f87a4fa3f996d5fffe7af64ab186e8176881ce441c765b7cb3a259e621761afea4d484a14b62967f575fe5f996366dbf341c4df591e3b63b3d7fc98ddc82218c41826b718d3bb474c6ba6377780a9fce8a10987c274c31af6e123dbc4827b18caa2b236d0f139772f26b8ae566b675587f9d5a425a614fb407b436795e35a850b42a2c6656e7375aa6f02dcea238b9d9e7e3fe51f304fc49d03ca161bd9d6f3fe8dec0ac65ce68ca38049821526ff142b98e27527fc46382284e2bd703499782030100015f201c52424134433339433636323334384639313138373a504e30303030317f4c23060f2b06010401a94693481502010900015310300000000000007f0000000000a7ffff5f25060108000703015f24060200000703005f37820100b04b1062f7c189c3fee8765799a81b6061eb3440a12b93b1682e435663d83c75a289fd2b3386277df6f707fddf1e73aec53edaef7d6426731cbb24fefb8810f327e7af958ebef362be3b379694c2ba31a05e735423be35f21de4df30bf63970143265647ac4a114aa2561d19781b141fb6de2cac029c63e356c03f40ccfb78060a24167ef2b27582bfa7378b48d4017fc4068917ebe6520ee25c65599fbac7d4d0246d5e4cb2bdeeba8d74d4c3dd28ec92876ee9730a2bd0f74dc609b0a18bdbd0dc0fdfdd0d0626a19f4a33d61259bdf93f4ad35162032cb6d01f18c504c678fa20dcf5ebe9ef59d898609ef15e9e674e67a0613c18d456f2101d41a3b6e1f3',
                    'value_charstring' => ' '
                }
            }
        },
        'decoded_raw' => {
            'identval' => 48,
            'tagnum'   => 16,
            'value'    => [
                {
                    'identval' => 128,
                    'tagnum'   => 0,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 0 ]
                },
                {
                    'identval' => 129,
                    'tagnum'   => 1,
                    'value'    => ' ',
                    'type'     => [ 'context', 'primitive', 1 ]
                },
                {
                    'identval' => 128,
                    'tagnum'   => 41,
                    'value' => ' ',
                    'type' => [ 'context', 'primitive', 41 ]
                },
                {
                    'identval' => 160,
                    'tagnum'   => 42,
                    'value'    => [
                        {
                            'identval' => 4,
                            'tagnum'   => 4,
                            'value'    => ' ',
                            'type' => [ 'universal', 'primitive', 'octet_string' ]
                        }
                    ],
                    'type' => [
                        'context',
                        'constructed',
                        42
                    ]
                }
            ],
            'type' => [
                'universal',
                'constructed',
                'sequence'
            ]
        }
    };


If you want to modify B<signature> then: 
    
    my $decoded_data_href = SECA_DER_decode( $responseKMS_aref );
    my $value = $decoded_data_href->{decoded_for_modification}{signature}{value_hexstring} ;
    
    # here value is '2af87a694076c53f881350c6a30453da76e44954b9c4ca2985d744f77c6bf4a30c2f20095c5b2744f459eb7fa3e3e189eb02c19644d8b6a2643a781f74f461634b56dadd4a36479e80ecd90795e4a89f74a83272a5da95b252ef76f443e82e3fc62b0f2312168f0c5702d511b600ab9d275c98597ab213df17003ad18528bdec6edbdfcaaf108f33bb6a66ff5d445d8bcf0e25d9db8f760eb99aa45f87c72851891f82a53fae4b0fc3c2f3d4aca79c11c69d8ba45661fc2fccc3aaa0f78f84c35dc5b52116dd2e0af25051db9cdc19662b78757403d2cd2051f1c9d4073ade6195464bd4b9b7b08681d43807d088c61cd64f72bbff83cc9f34f1b0faf3cabf6f'
    # and if you want to modify '2af87a694076c53f881350c6a30453da76e44954b9c4ca2985d744f77c6bf4a30c2f20095c5b2744f459eb7fa3e3e189eb02c19644d8b6a2643a781f74f461634b56dadd4a36479e80ecd90795e4a89f74a83272a5da95b252ef76f443e82e3fc62b0f2312168f0c5702d511b600ab9d275c98597ab213df17003ad18528bdec6edbdfcaaf108f33bb6a66ff5d445d8bcf0e25d9db8f760eb99aa45f87c72851891f82a53fae4b0fc3c2f3d4aca79c11c69d8ba45661fc2fccc3aaa0f78f84c35dc5b52116dd2e0af25051db9cdc19662b78757403d2cd2051f1c9d4073ade6195464bd4b9b7b08681d43807d088c61cd64f72bbff83cc9f34f1b0faf3cccccf'
    
    $decoded_data_href->{decoded_for_modification}{signature}{value_hexstring} = '2af87a694076c53f881350c6a30453da76e44954b9c4ca2985d744f77c6bf4a30c2f20095c5b2744f459eb7fa3e3e189eb02c19644d8b6a2643a781f74f461634b56dadd4a36479e80ecd90795e4a89f74a83272a5da95b252ef76f443e82e3fc62b0f2312168f0c5702d511b600ab9d275c98597ab213df17003ad18528bdec6edbdfcaaf108f33bb6a66ff5d445d8bcf0e25d9db8f760eb99aa45f87c72851891f82a53fae4b0fc3c2f3d4aca79c11c69d8ba45661fc2fccc3aaa0f78f84c35dc5b52116dd2e0af25051db9cdc19662b78757403d2cd2051f1c9d4073ade6195464bd4b9b7b08681d43807d088c61cd64f72bbff83cc9f34f1b0faf3cccccf';

    SECA_DER_encode($decoded_data_href);

or If you want to modify B<certificate> then: 
    
    my $decoded_data_href = SECA_DER_decode( $responseKMS_aref );
    my $value = $decoded_data_href->{decoded_for_modification}{certChain}{certificate}{value_hexstring} ;
    
    # here value is '7f2182029f7f4e8201955f290100421b52424131414952424147312f434f4d4d4f4e313a434e30303030317f49820118060d2b06010401a94693481501080181820100b451040b0c8d1f123a24179c15656937d9e9859f38c831cf9ce1e1b06b1675fcb7dfbf3386a12579c95a843167c223b97bb723762bdaf1ceca8992b37495cf4ab4f87a4fa3f996d5fffe7af64ab186e8176881ce441c765b7cb3a259e621761afea4d484a14b62967f575fe5f996366dbf341c4df591e3b63b3d7fc98ddc82218c41826b718d3bb474c6ba6377780a9fce8a10987c274c31af6e123dbc4827b18caa2b236d0f139772f26b8ae566b675587f9d5a425a614fb407b436795e35a850b42a2c6656e7375aa6f02dcea238b9d9e7e3fe51f304fc49d03ca161bd9d6f3fe8dec0ac65ce68ca38049821526ff142b98e27527fc46382284e2bd703499782030100015f201c52424134433339433636323334384639313138373a504e30303030317f4c23060f2b06010401a94693481502010900015310300000000000007f0000000000a7ffff5f25060108000703015f24060200000703005f37820100b04b1062f7c189c3fee8765799a81b6061eb3440a12b93b1682e435663d83c75a289fd2b3386277df6f707fddf1e73aec53edaef7d6426731cbb24fefb8810f327e7af958ebef362be3b379694c2ba31a05e735423be35f21de4df30bf63970143265647ac4a114aa2561d19781b141fb6de2cac029c63e356c03f40ccfb78060a24167ef2b27582bfa7378b48d4017fc4068917ebe6520ee25c65599fbac7d4d0246d5e4cb2bdeeba8d74d4c3dd28ec92876ee9730a2bd0f74dc609b0a18bdbd0dc0fdfdd0d0626a19f4a33d61259bdf93f4ad35162032cb6d01f18c504c678fa20dcf5ebe9ef59d898609ef15e9e674e67a0613c18d456f2101d41a3b6e1f3'
    # and if you want to modify '7f2182029f7f4e8201955f290100421b52424131414952424147312f434f4d4d4f4e313a434e30303030317f49820118060d2b06010401a94693481501080181820100b451040b0c8d1f123a24179c15656937d9e9859f38c831cf9ce1e1b06b1675fcb7dfbf3386a12579c95a843167c223b97bb723762bdaf1ceca8992b37495cf4ab4f87a4fa3f996d5fffe7af64ab186e8176881ce441c765b7cb3a259e621761afea4d484a14b62967f575fe5f996366dbf341c4df591e3b63b3d7fc98ddc82218c41826b718d3bb474c6ba6377780a9fce8a10987c274c31af6e123dbc4827b18caa2b236d0f139772f26b8ae566b675587f9d5a425a614fb407b436795e35a850b42a2c6656e7375aa6f02dcea238b9d9e7e3fe51f304fc49d03ca161bd9d6f3fe8dec0ac65ce68ca38049821526ff142b98e27527fc46382284e2bd703499782030100015f201c52424134433339433636323334384639313138373a504e30303030317f4c23060f2b06010401a94693481502010900015310300000000000007f0000000000a7ffff5f25060108000703015f24060200000703005f37820100b04b1062f7c189c3fee8765799a81b6061eb3440a12b93b1682e435663d83c75a289fd2b3386277df6f707fddf1e73aec53edaef7d6426731cbb24fefb8810f327e7af958ebef362be3b379694c2ba31a05e735423be35f21de4df30bf63970143265647ac4a114aa2561d19781b141fb6de2cac029c63e356c03f40ccfb78060a24167ef2b27582bfa7378b48d4017fc4068917ebe6520ee25c65599fbac7d4d0246d5e4cb2bdeeba8d74d4c3dd28ec92876ee9730a2bd0f74dc609b0a18bdbd0dc0fdfdd0d0626a19f4a33d61259bdf93f4ad35162032cb6d01f18c504c678fa20dcf5ebe9ef59d898609ef15e9e674e67a0613c18d456f2101d41a3b6e2f3'
    
    $decoded_data_href->{decoded_for_modification}{certChain}{certificate}{value_hexstring} = '7f2182029f7f4e8201955f290100421b52424131414952424147312f434f4d4d4f4e313a434e30303030317f49820118060d2b06010401a94693481501080181820100b451040b0c8d1f123a24179c15656937d9e9859f38c831cf9ce1e1b06b1675fcb7dfbf3386a12579c95a843167c223b97bb723762bdaf1ceca8992b37495cf4ab4f87a4fa3f996d5fffe7af64ab186e8176881ce441c765b7cb3a259e621761afea4d484a14b62967f575fe5f996366dbf341c4df591e3b63b3d7fc98ddc82218c41826b718d3bb474c6ba6377780a9fce8a10987c274c31af6e123dbc4827b18caa2b236d0f139772f26b8ae566b675587f9d5a425a614fb407b436795e35a850b42a2c6656e7375aa6f02dcea238b9d9e7e3fe51f304fc49d03ca161bd9d6f3fe8dec0ac65ce68ca38049821526ff142b98e27527fc46382284e2bd703499782030100015f201c52424134433339433636323334384639313138373a504e30303030317f4c23060f2b06010401a94693481502010900015310300000000000007f0000000000a7ffff5f25060108000703015f24060200000703005f37820100b04b1062f7c189c3fee8765799a81b6061eb3440a12b93b1682e435663d83c75a289fd2b3386277df6f707fddf1e73aec53edaef7d6426731cbb24fefb8810f327e7af958ebef362be3b379694c2ba31a05e735423be35f21de4df30bf63970143265647ac4a114aa2561d19781b141fb6de2cac029c63e356c03f40ccfb78060a24167ef2b27582bfa7378b48d4017fc4068917ebe6520ee25c65599fbac7d4d0246d5e4cb2bdeeba8d74d4c3dd28ec92876ee9730a2bd0f74dc609b0a18bdbd0dc0fdfdd0d0626a19f4a33d61259bdf93f4ad35162032cb6d01f18c504c678fa20dcf5ebe9ef59d898609ef15e9e674e67a0613c18d456f2101d41a3b6e2f3';

    SECA_DER_encode($decoded_data_href);


B<Notes:> 

=for html
<a href='LIFT_securityAlgorithms.html#SECA_DER_encode'>To encode above hash to challenge or signature call SECA_DER_encode with hash as input.</a>
<br><br>

=cut

sub SECA_DER_decode {
    my @args = @_;
    S_checkFunctionArguments( 'SECA_DER_decode($data_to_decode_aref )', @args ) or return;
    my $data_to_decode_aref = shift @args;

    S_w2log( 4, "SECA_DER_decode start .." . "\n" );

    # STEP return offline:
    if ($main::opt_offline) {
        S_w2log( 4, "SECA_DER_decode handle offline condition  .." . "\n" );
        S_w2log( 4, "SECA_DER_decode offline, original passed input is = '@$data_to_decode_aref' .." . "\n" );
        S_w2log( 4, "SECA_DER_decode offline, changed input for offline handling is  = '@$challenge_offline_aref' .." . "\n\n" );
        $data_to_decode_aref = $challenge_offline_aref;
    }

    my @data_print = @$data_to_decode_aref;
    foreach (@data_print) { $_ = sprintf( "%02X", $_ ); }
    S_w2log( 3, "Input data for DER decoding is = '@data_print' of length = " . scalar(@$data_to_decode_aref) . "\n" ) if ($enable_print_outs);

    # STEP convert the array of int into the char String
    my $der_en_data_as_char_str = pack( "C*", @$data_to_decode_aref );    # pack to character string

    # STEP use encoding BER::DER with 'char string' as input and get DER tags and values
    S_w2log( 3, "Now going to decode the data .. " . "\n" );

    my $der_decoded_data_href;
    $der_decoded_data_href = eval { $objDER->decode($der_en_data_as_char_str) };
    unless ( defined $der_decoded_data_href ) {
        S_set_error( "SECA_DER_decode : could not decode the data bytes @$data_to_decode_aref ..", 114 );
        return;
    }

    S_w2log( 5, "SECA_DER_decode dump raw decoded data :\n" . Dumper($der_decoded_data_href) . "\n" ) if ($enable_print_outs);

    my $raw_der_decoded_data_href = $der_decoded_data_href;

    # STEP Construct the hash with field name as keys and (tag number, char_string , hex_string) as values.
    my $decoded_data_href;
    foreach my $field_value ( @{ $der_decoded_data_href->{value} } ) {
        my $tag_num = $field_value->{tagnum};
        if ( $tag_num == 42 ) {
            foreach my $certificate ( @{ $field_value->{value} } ) {
                my $tag_num_certificate  = $certificate->{tagnum};
                my $char_str_certificate = $certificate->{value};
                my $key_name             = $tag_defination_mapping{$tag_num_certificate}{name};
                $decoded_data_href = Get_tagData_certificate_value( $decoded_data_href, $key_name, $tag_num_certificate, $char_str_certificate );
            }
        }
        else {
            my $char_str = $field_value->{value};
            my $tag_name = $tag_defination_mapping{$tag_num}{name};
            $decoded_data_href = Get_tagData_values( $decoded_data_href, $tag_name, $tag_num, $char_str );
        }
    }

    my $return_decoded_data_href;
    $return_decoded_data_href->{decoded_raw}              = $raw_der_decoded_data_href;
    $return_decoded_data_href->{decoded_for_modification} = $decoded_data_href;

    S_w2log( 5, "following are the values read: (if values are not seen than the flag for printouts is disabled)" . "\n" );
    S_w2log( 5, "SECA_DER_decode retruned data :\n" . Dumper($return_decoded_data_href) . "\n" ) if ($enable_print_outs);

    S_w2log( 4, "SECA_DER_decode end .." . "\n" );

    # STEP return $decoded_data_href
    return $return_decoded_data_href;
}

=head2 SECA_DER_encode

    $der_encoded_int_aref = SECA_DER_encode($data_to_encode_href );
    
This will perform DER encoding to input '$data_to_encode_href' (which was DER decoded) and it will return array of intergers, so that it can be sent either to KMS or
ECU.

This has to be done so that : 

=for html
<a href='LIFT_securityAlgorithms.html#SECA_DER_decode'> Modified Challenge or response from KMS </a>
can to be encoded again.
<br><br>
    
B<Arguments:>

=over

=item $data_to_encode_href

this is an retrun value of SECA_DER_decode Please refer return value and example of it. 

=back

B<Return Values:>

=over

=item $der_encoded_int_aref

Array of integers. One use case is challenge of ECU sent to KMS after modification.
  
=back

B<Examples:>

    my $data_der_encoded = [0x30, 0x81, 0x8b, 0x80, 0x01, 0x01, 0x81, 0x01, 0x00, 0x8a, 0x01, 0x00, 
            0x90, 0x08, 0x1b, 0x0f, 0x07, 0xd8, 0xc8, 0xe8, 0x43, 0xdc, 0x91, 0x20, 0x4e, 0x31, 0x58,
            0x59, 0x33, 0x37, 0x2d, 0x35, 0x31, 0x20, 0x0b, 0xff, 0x2d, 0x00, 0x42, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9f, 
            0x20, 0x1b, 0x52, 0x42, 0x41, 0x31, 0x41, 0x49, 0x52, 0x42, 0x41, 0x47, 0x31, 0x2f, 0x43, 
            0x4f, 0x4d, 0x4d, 0x4f, 0x4e, 0x31, 0x3a, 0x43, 0x4e, 0x30, 0x30, 0x30, 0x30, 0x31, 0x9f, 
            0x21, 0x0f, 0x2b, 0x06, 0x01, 0x04, 0x01, 0xa9, 0x46, 0x93, 0x48, 0x15, 0x02, 0x01, 0x09, 
            0x00, 0x01, 0x9f, 0x22, 0x10, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7f, 0x00, 0x00,
            0x00, 0x00, 0x00, 0xa7, 0xff, 0xff, 0x9f, 0x23, 0x10, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x7f, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa7, 0xff, 0xff ];

    my $decoded_data_href = SECA_DER_decode( $data_to_decode_aref ); 
    $der_encoded_int_aref = SECA_DER_encode($decoded_data_href );
    
    $der_encoded_int_aref =  [48 129 139 128 1 1 129 1 0 138 1 0 144 8 27 15 7 216 200 232 
                67 220 145 32 78 49 88 89 51 55 45 53 49 32 11 255 45 0 66 0 0 0 0 0 0 0 0 0 0 0 
                0 0 0 0 0 0 159 32 27 82 66 65 49 65 73 82 66 65 71 49 47 67 79 77 77 79 78 49 58
                67 78 48 48 48 48 49 159 33 15 43 6 1 4 1 169 70 147 72 21 2 1 9 0 1 159 34 16 48
                0 0 0 0 0 0 127 0 0 0 0 0 167 255 255 159 35 16 48 0 0 0 0 0 0 127 0 0 0 0 0 167 
                255 255];
                    
B<Notes:> 

=cut

sub SECA_DER_encode {
    my @args = @_;
    S_checkFunctionArguments( 'SECA_DER_encode ( $data_to_encode_href )', @args ) or return;
    my $data_to_encode_href = shift @args;

    S_w2log( 4, "SECA_DER_encode start .." . "\n" );
    S_w2log( 5, "SECA_DER_encode intput data is ..\n" . Dumper($data_to_encode_href) . "\n" ) if ($enable_print_outs);

    # STEP handle offline return
    if ($main::opt_offline) {
        S_w2log( 4, "SECA_DER_encode offline return is = '@$challenge_offline_aref'." . "\n" );
        return $challenge_offline_aref;
    }

    # STEP get the modified and unmodified decoded data
    my $raw_decoded_data_href      = $data_to_encode_href->{decoded_raw};
    my $modified_decoded_data_href = $data_to_encode_href->{decoded_for_modification};

    # STEP Find the modified hex_string and overwrite it..
    S_w2log( 4, "SECA_DER_encode : find the modified hex_string and overwrite it.." . "\n" );
    foreach my $field_value ( @{ $raw_decoded_data_href->{value} } ) {

        my $tag_num = $field_value->{tagnum};
        my $ascii_value;
        my $updated_ascii_value;

        # STEP check if it is certificate value has been updated or else other tag values
        if ( $tag_num == 42 ) {    # certChain
            $ascii_value = $field_value->{value}[0]{value};
            my $found_hex_value = $modified_decoded_data_href->{certChain}{certificate}{value_hexstring};
            $updated_ascii_value = HexStr_to_charStr($found_hex_value);
        }
        else {
            $ascii_value = $field_value->{value};
            $updated_ascii_value = Get_updated_charStr_from_tag( $modified_decoded_data_href, $tag_num );
        }

        # STEP check if the ascii values are changed ?
        if ( $ascii_value ne $updated_ascii_value ) {
            if ( $tag_num == 42 ) {
                $field_value->{value}[0]{value} = $updated_ascii_value;
            }
            else {
                $field_value->{value} = $updated_ascii_value;
            }
            my $hexstr_before = CharStr_to_hexStr($ascii_value);
            my $hexstr_after  = CharStr_to_hexStr($updated_ascii_value);
            my $tag_name      = $tag_defination_mapping{$tag_num}{name};
            S_w2log( 4, "SECA_DER_encode modifed value of tag_num = '$tag_num' ($tag_name), value_hexstring before : '$hexstr_before' , value_hexstring after = '$hexstr_after'  \n" ) if ($enable_print_outs);
        }
    }

    # STEP encode the data and convert the char string into the array of integers
    my $der_encoded_chrStr = eval { $objDER->encode($raw_decoded_data_href) };
    my $der_encoded_int_aref = CharStr_to_intArr($der_encoded_chrStr);

    S_w2log( 4, "DER encoded value is : @$der_encoded_int_aref \n" ) if ($enable_print_outs);
    S_w2log( 4, "SECA_DER_encode ends .. \n" );
    return $der_encoded_int_aref;
}

=head2 SECA_control_security_printouts

    SECA_control_security_printouts($flag_to_enable_security_printouts );
    
As sometimes user do not want to log security information in the logs. But sometimes it is necessary   
for debugging purpose to have these logs.

This function is to control the logging of the security information from the various function of this module.
    
B<Arguments:>

=over

=item $flag_to_enable_security_printouts

It have have two values 0 or 1.

0: for not logging the security printouts from functions of this module 
1: for logging the security printouts from functions of this module 

default is 0 if this function is not called.

=back

B<Examples:>

    # disable logging of secure info from various functions of this module
    SECA_control_security_printouts(0); 
    
    # enable logging of secure info from various functions of this module
    SECA_control_security_printouts(1); 
                    
B<Notes:> 

=cut

sub SECA_control_security_printouts {
    my @args = @_;
    S_checkFunctionArguments( 'SECA_control_security_printouts ( $flag_to_enable_debug_printouts )', @args ) or return;
    my $flag_to_enable_debug_printouts = shift @args;
    $enable_print_outs = $flag_to_enable_debug_printouts;
    return 1;
}

=head2 SECA_AES_CTR_encrypt

    $cipherHexStr = SECA_AES_CTR_encrypt($plaintext, $key,  $iv );
    
Advanced Encryption Standard (AES) is a block cipher, and it can be used in many different modes.
This function encrypt a text using AES encryption in Counter mode (CTR) of operation.

B<Arguments:>

=over

=item $plaintext

Input to perfrom AES CTR mode encryption. 
It should be passed as Hex string (withoout prefix 0x) see examples. 

=item $key

The secret key to use in the symmetric cipher.
It should be passed as Hex string (withoout prefix 0x) see examples.

=item $iv

The initialization vector to use for encryption or decryption. 
It should be passed as Hex string (withoout prefix 0x) see examples. 

=back

B<Return Values:>

=over

=item $cipherHexStr

AES Encrpted hex String.
  
=back

B<Examples:>

    $key        = "38722e65542d756d5f6f30626c36654e";
    $iv         = "51f0bebf7e3b9d92fc49741779363cfe";
    $plaintext  = "b5dada380e2872df935bca55b882c8c9";
    
    my $cipherhex = SECA_AES_CTR_encrypt( $plaintext, $key, $iv );
    $cipherhex is 'bb83e0378d6d96131f73db95b7b18a7f'.
                    
B<Notes:> 

=cut

sub SECA_AES_CTR_encrypt {
    my @args = @_;
    S_checkFunctionArguments( 'SECA_AES_CTR_encrypt ( $plaintext, $key,  $iv)', @args ) or return;
    my $plaintext = shift @args;
    my $key       = shift @args;
    my $iv        = shift @args;

    # STEP validate the inputs if they vare hex numbers
    unless ( Is_hex_string($plaintext) and Is_hex_string($key) and Is_hex_string($iv) ) {
        S_set_error("One of the input is not a valid hex string -> data_to_encrypt = '$plaintext' or key ='$key' or iv = '$iv'. Please pass as valid hex string as inputs.");
        return;
    }

    my $ciphertext;

    #STEP encrypt AES CTR mode
    $ciphertext = eval { $objAESCTR->encrypt( pack( 'H*', $plaintext ), pack( 'H*', $key ), pack( 'H*', $iv ) ) };

    # STEP convert the result back from ASCII string to hex string
    my $cipherHexStr = unpack "H*", $ciphertext;

    return $cipherHexStr;
}

=head2 SECA_AES_CTR_decrypt

    $plainHexStr = SECA_AES_CTR_decrypt($ciphertext, $key,  $iv );
    
Advanced Encryption Standard (AES) is a block cipher, and it can be used in many different modes.
This function decrypts a cipher text using AES encryption in Counter mode (CTR) of operation.

B<Arguments:>

=over

=item $ciphertext

Input to perfrom AES CTR mode decryption. 
It should be passed as Hex string (withoout prefix 0x) see examples. 

=item $key

The secret key to use in the symmetric cipher.
It should be passed as Hex string (withoout prefix 0x) see examples.

=item $iv

The initialization vector to use for encryption or decryption. 
It should be passed as Hex string (withoout prefix 0x) see examples. 

=back

B<Return Values:>

=over

=item $plainHexStr

AES Decrypted hex String.
  
=back

B<Examples:>

    $key = "38722e65542d756d5f6f30626c36654e";
    $iv = "f69f2445df4f9b17ad2b417be66c3710";
    $ciphertext = "ee87bbac7a15b6bbbc9707343b32ed72";
    
    $plainHexStr = SECA_AES_CTR_decrypt( $ciphertext, $key, $iv );
    $plainHexStr is '8579743f8b8bccd039e002318d3eb1e2'.
                    
B<Notes:> 

=cut

sub SECA_AES_CTR_decrypt {
    my @args = @_;
    S_checkFunctionArguments( 'SECA_AES_CTR_decrypt ( $ciphertext, $key,  $iv)', @args ) or return;
    my $ciphertext = shift @args;
    my $key        = shift @args;
    my $iv         = shift @args;

    # STEP validate the inputs if they vare hex numbers
    unless ( Is_hex_string($ciphertext) and Is_hex_string($key) and Is_hex_string($iv) ) {
        S_set_error("One of the input is not a valid hex string -> cipher text  = '$ciphertext' or key ='$key' or iv = '$key'. Please pass as valid hex string as inputs.");
        return;
    }
    #STEP decrypt AES CTR mode
    my $plaintext;
    $plaintext = eval { $objAESCTR->decrypt( pack( 'H*', $ciphertext ), pack( 'H*', $key ), pack( 'H*', $iv ) ) };

    # STEP convert the result back from ASCII string to hex string
    my $plainHexStr = unpack "H*", $plaintext;

    return $plainHexStr;
}

=head1 Internal functions

=cut

=head2 Get_updated_charStr_from_tag

    $char_str_value = Get_updated_charStr_from_tag( $modified_decoded_data_href, $tag_to_find_modifed_value );
    
Internal function called by SECA_DER_encode.
this function is to fetch value_hexstring from modifed der decoded data for the passed tagnumber.

value_hexstring will be converted to value_char_string which will be compared later before doing DER encoding. 

=cut

sub Get_updated_charStr_from_tag {
    my @args                       = @_;
    my $modified_decoded_data_href = shift @args;
    my $tag_to_find_modifed_value  = shift @args;

    # STEP look for the value_hexString from the modified hex for tag-num
    my $found_hex_value;
    foreach my $eachfield ( keys( %{$modified_decoded_data_href} ) ) {
        if ( $modified_decoded_data_href->{$eachfield}{tagnum} == $tag_to_find_modifed_value ) {
            $found_hex_value = $modified_decoded_data_href->{$eachfield}{value_hexstring};
            last;
        }
    }
    return unless defined $found_hex_value;

    # STEP : convert hex to character string
    my $char_str_value = HexStr_to_charStr($found_hex_value);
    return $char_str_value;
}

=head2 HexStr_to_charStr

    $char_str = HexStr_to_charStr( $hex_str );
    
Convert the input hexstring "$hex_str" to character string '$char_str'

B<Arguments:>

=over

=item $hex_str

input hex string.  

=back

B<Return Values:>

=over

=item $char_str

Character string value or undef on error 

=back

B<Examples:>

    'RBA1ABSESP1/OEMA1:CN:DUMMY00001' = HexStr_to_charStr( 
                            '52424131414253455350312f4f454d41313a434e3a44554d4d593030303031' );           

=cut

sub HexStr_to_charStr {
    my @args    = @_;
    my $hex_str = shift @args;

    return undef if not defined $hex_str;

    my $char_str = $hex_str;
    $char_str =~ s/(..)/chr(hex($1))/eg;    #hex() -> convert hex string to decimal number, chr() -> convert decimal number to a character(string).
    return $char_str;
}

=head2 CharStr_to_hexStr

    $hex_str = CharStr_to_hexStr( $char_str );
    
Convert the input ASCII character string  "$char_str" to hex string '$hex_str'

B<Arguments:>

=over

=item $char_str

input ASCII character string.  

=back

B<Return Values:>

=over

=item $hex_str

converted value of hex string or undef on error 

=back

B<Examples:>

     '52424131414253455350312f4f454d41313a434e3a44554d4d593030303031' = 
                        CharStr_to_hexStr('RBA1ABSESP1/OEMA1:CN:DUMMY00001' );     

=cut

sub CharStr_to_hexStr {
    my @args     = @_;
    my $char_str = shift @args;

    return undef if not defined $char_str;

    my $hex_str = $char_str;
    $hex_str =~ s/(.)/sprintf '%02x', ord $1/seg;    # convert to a hex string.
    return $hex_str;
}

=head2 CharStr_to_intArr

    $converted_int_aref = CharStr_to_intArr( $char_str );
    
Convert the input ASCII character string  "$char_str" to integer array

B<Arguments:>

=over

=item $char_str

input ASCII character string.  

=back

B<Return Values:>

=over

=item $converted_int_aref

converted array of intergers 

=back

B<Examples:>

     [ '82', '66', '65', '49', '65', '66', '83', '69', '83', '80' ...] = 
                        CharStr_to_intArr('RBA1ABSESP1/OEMA1:CN:DUMMY00001' );     

=cut

sub CharStr_to_intArr {
    my @args     = @_;
    my $char_str = shift @args;

    my $hex_str = $char_str;
    $hex_str =~ s/(.)/sprintf '%02x', ord $1/seg;    # convert to a hex string.
    my @array_intergers = map hex, $hex_str =~ /../g;
    return \@array_intergers;
}

=head2 Get_tagData_values

    Get_tagData_values($tag_data_href, $tagName, $tag_number, $char_string );
    
Internal function to update decoded structure $decoded_data_href with tagnum, value_charstring, value_hexstring, number of bytes.
It is called by SECA_DER_decode.

This will fill data for rest of the tagnumber (0, 1, 10, 16, 17, 32, 33, 35, 41, etc) apart from 42 i.e. certificate.   
    
B<Arguments:>

=over

=item $tag_data_href

input structure to be filled with tagnum, value_charstring, value_hexstring, number of bytes.

=item $tagName 

tag name corresponding to the tag number.

=item $tag_number

(0, 1, 10, 16, 17, 32, 33, 35, 41, etc) tag number obtained after DER decoding.

=item $char_string

character string obtained after DER decoding

=back

B<Return Values:>

=over

=item $tag_data_href

Hash filled with tagnum, value_charstring, value_hexstring, number of bytes.
  
=back

=cut

sub Get_tagData_values {
    my @args          = @_;
    my $tag_data_href = shift @args;
    my $tagName       = shift @args;
    my $tag_number    = shift @args;
    my $char_string   = shift @args;

    my $hex_string           = CharStr_to_hexStr($char_string);
    my $calculated_nbr_bytes = int( length($hex_string) / 2 );

    $tag_data_href->{$tagName}{tagnum}           = $tag_number;
    $tag_data_href->{$tagName}{value_charstring} = $char_string;
    $tag_data_href->{$tagName}{value_hexstring}  = $hex_string;
    $tag_data_href->{$tagName}{number_of_bytes}  = $calculated_nbr_bytes;

    return $tag_data_href;
}

=head2 Get_tagData_certificate_value

    Get_tagData_certificate_value($tag_data_href, $tagName, $tag_number, $char_string );
    
Internal function to update decoded structure $decoded_data_href with tagnum, value_charstring, value_hexstring, number of bytes
for cerficate tagname. It is called by SECA_DER_decode  
    
B<Arguments:>

=over

=item $tag_data_href

input structure to be filled by tagnum, value_charstring, value_hexstring, number of bytes for certicate. 

=item $tagName 

certificate : tag name corresponding to the tag number 4.

=item $tag_number

4: tag number obtained after DER decoding.

=item $char_string

character string for tagnumber 4 obtained after DER decoding

=back

B<Return Values:>

=over

=item $tag_data_href

Hash filled with tagnum, value_charstring, value_hexstring, number of bytes.
  
=back

=cut

sub Get_tagData_certificate_value {
    my @args          = @_;
    my $tag_data_href = shift @args;
    my $tagName       = shift @args;
    my $tag_number    = shift @args;
    my $char_string   = shift @args;

    my $hex_string           = CharStr_to_hexStr($char_string);
    my $calculated_nbr_bytes = int( length($hex_string) / 2 );
    $tag_data_href->{certChain}{$tagName}{tagnum}           = $tag_number;
    $tag_data_href->{certChain}{$tagName}{value_charstring} = $char_string;
    $tag_data_href->{certChain}{$tagName}{value_hexstring}  = $hex_string;
    $tag_data_href->{certChain}{$tagName}{number_of_bytes}  = $calculated_nbr_bytes;

    return $tag_data_href;
}

sub Is_hex_string {
    my @args   = @_;
    my $input  = shift @args;
    my $status = 0;

    $status = 1 if ( $input =~ /^[0-9a-fA-F]+$/ );
    return $status;
}

1;

