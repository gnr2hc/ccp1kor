package LIFT_KMSs;

use strict;
use warnings;
use Readonly;

use Win32::OLE;
use Win32::OLE::Variant;
Win32::OLE->Option( Warn => \&CatchOleException );

use LIFT_general;
use LIFT_stringProcessing;
require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  KMSs_init
  KMSs_exit
  KMSs_generateRandomNumber
  KMSs_generatePassword
  KMSs_storePassword
  KMSs_loadPassword
  KMSs_generateAESKeys
  KMSs_loadPrivateKey
  KMSs_loadPublicKey
  KMSs_loadAESKey
  KMSs_answerChallenge
  KMSs_loadX509Certificate
  KMSs_deleteID
  KMSs_generateRSAKeys
  KMSs_setSHECounter
  KMSs_getSHECounter
  KMSs_generateSHEMessages
  KMSs_validateSHEMessages
  KMSs_savePrivateKey
  KMSs_savePublicKey
  KMSs_saveAESKey
  KMSs_savePairOfKeys
  KMSs_saveCertificate
  KMSs_setIDlength
  KMSs_resetAll
  KMSs_generateX509Certificate
  KMSs_generateCVC
  KMSs_loadCVC
  KMSs_calculateCMAC
  KMSs_sign
  KMSs_addAuthorization
  KMSs_registerCertificatesAndRSAKeys
);

# Keep this PROGID incl. version same as in DLL source: PROGID, assembly and file version (defined by PSDiag-Team)
# Which refers to this COM-wrapper-DLL:
# ..\tools_TurboLIFT\Engine\modules\Device_layer\ProdDiag\Win32\KMSs_NET_32.dll
# ( should be identical to                 C:\AB12_TOOLS\PSDiag\KMSs_NET_32.dll )
# The wrapper-DLL will use C:\AB12_TOOLS\KMSSimulationForProductionDiagnosis\KMSs_x32.dll, which will
# in turn use Python scripts in same folder, sub-folders and embedded Python itself in sub-folder \lib_32.
# Summary: TurboLIFT < via COM > KMSs_NET_32.dll <> KMSs_x32.dll <> Python scripts <> python.exe with core libraries
# Registry entry for the wrapper-DLL done in run_once: ...\tools_TurboLIFT\Engine\run_once\register_com_dlls.bat
my $KMSs_PROGID = "KMSs_NET_32.KMSs_NET_32.1.0.0.0";
my $KMSs_hOle;
my $KMSs_initialized = 0;
our ( $VERSION, $HEADER );

=head1 NAME

LIFT_KMSs

=head1 SYNOPSIS

    use LIFT_KMSs;
    
    $success = KMSs_init();
    
    # Call now any KMSs_functions in desired order
    
    $success = KMSs_exit();

=head1 DESCRIPTION

    Perl-COM-Interface to Key Management System Simulator (KMSs) developed by TWT company
        Test Purspose and Strategy:
            https://inside-docupedia.bosch.com/confluence/display/aeos/Security+Tests+using+KMSs
        Test Tool Setup and Usage:
            https://inside-docupedia.bosch.com/confluence/display/aeos/Key+Management+System+Simulation+-+KMSs
        API documentation:
            tools_TurboLIFT\Engine\modules\Common_library\KMSs_NET\Win32\AnforderungenTests.py
            tools_TurboLIFT\Engine\modules\Common_library\KMSs_NET\Win32\example_x32.cpp
        Perl usage examples taken from example_x32.cpp:
            tools_TurboLIFT\System\perl_unit_test\LIFT_KMSs.t

=head1 NOTES

        After running these functions
        -----------------------------
        Generated KMSs-log-files in working directory: KMS_LastError.txt, KMSs_log.txt
        
        In case of issues observed
        --------------------------
        Since this module is in principle a 1:1 wrapper to external PsDiag/KMSs library,
        it is important to find out, whether the issue needs to be analysed in TurboLIFT or PsDiag/KMSs.
        
        Repeat your session sequence using the interactive Console.py, in order to reproduce the issue:
        
        1. Open a cmd inside: C:\AB12_TOOLS\KMSSimulationForProductionDiagnosis
        2. lib_32\Python38\python Console.py
        3. Type help to show available commands (same names as here, whithout prefix: "KMSs_")
        4. Call one command after the other, as you did in TurboLIFT automation TC.
        5. Result: If observation is same here, raise the issue for PsDiag-Team, else TurboLIFT-Team.
        
=cut

=head1 FUNCTIONS

=head2 KMSs_init

    $success = KMSs_init();

Starts the application
KMSs_NET_32.dll must be registered for OLE access, otherwise "Invalid class string" error, which is
typically done by _run_once.bat (or register_com_dlls.bat).

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub KMSs_init {
    my $status;

    if ($KMSs_initialized) {
        S_set_warning("KMSs already initialized");
        return 1;
    }

    # Old KMS-Path: ..\tools_TurboLIFT\Engine\modules\Common_library\KMSs_NET\Win32
    #    my $liftExecPath = $main::LIFT_exec_path;
    #
    #    if ( not defined $liftExecPath )
    #    {
    #        # Assume .t testing
    #        require( "Unit_test_engine_path.pm" );
    #        $liftExecPath = $Unit_test_engine_path::enginePath;
    #    }
    #
    #    $liftExecPath =~ s/\//\\/g;             # replace all slashes by backslashes
    #    $liftExecPath = File::Spec->rel2abs($liftExecPath);
    #    my $kmsPath = $liftExecPath . "\\modules\\Common_library\\KMSs_NET\\Win32";

    my $kmsPath = "C:\\AB12_TOOLS\\KMSSimulationForProductionDiagnosis";    # New KMS-Path
    S_w2log( 3, " KMSs path: $kmsPath\n" );

    unless ( -e $kmsPath ) {
        S_set_error("KMSs-Library-Path: '$kmsPath' does not exist. Comes with PSDiag installation\n");
        return;
    }

    S_w2log( 3, " KMSs_init: Application_create() ..  \n" );
    Application_create() || return;

    $KMSs_hOle->KMSs_initPaths($kmsPath);

    #    my $dllInfos = $KMSs_hOle->KMSs_initPaths($kmsPath);
    #    return unless defined $dllInfos;
    #    S_w2log( 3, " KMSs DLL infos: $dllInfos\n" );

    # TODO: DLL-Log-File, if required later
    #    my $snapshot_directory = "$main::REPORT_PATH/_snapshot_";
    #    unless ( -e $snapshot_directory or mkdir $snapshot_directory ) {
    #        S_set_error("Snapshot Directory: $snapshot_directory does not exist and could not be created\n");
    #        return;
    #    }
    #    $snapshot_directory =~ s/\//\\/g;    # replace all slashes by backslashes
    #    $snapshot_directory = File::Spec->rel2abs($snapshot_directory);
    #    $KMSs_hOle->KMSs_SetLogFilePath($snapshot_directory);

    LastError2log();

    $KMSs_initialized = 1;

    return 1;
}

=head2 KMSs_exit

    $success = KMSs_exit();



B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub KMSs_exit {
    my $success = 1;

    unless ($KMSs_initialized) {
        S_set_error( "KMSs not initialized", 120 );
        return 0;
    }

    Application_destroy();

    $KMSs_initialized = 0;

    return $success;
}

=head2 KMSs_generateRandomNumber

I<B<Syntax : >>

    my $random_number  = KMSs_generateRandomNumber($length);

I<B<Description : >>

    Generates a random number

I<B<Arguments : >>

    $length: length of random number

I<B<Example : >>

    my $random_number  = KMSs_generateRandomNumber(50);

=cut

sub KMSs_generateRandomNumber {
    my $length               = shift;
    my $random_number_string = $KMSs_hOle->KMSs_generateRandomNumber($length);
    return $random_number_string;
}

=head2 KMSs_generatePassword

    my $password_id_string = KMSs_generatePassword( $length, $lc, $uc, $nums, $withSpecialChars );
    
    Generates a random password
    
    Returns the KMSs-ID of the generated Password
    
    To get password it has to be loaded with "KMSs_loadPassword"

B<Arguments:>

=over

=item $length
    
The length of the Password

=item $lc 

lowerCase

=item $uc

upperCase

=item $nums             

numbers

=item $withSpecialChars

1 - Use Special Chars

0 - No Special Chars  

=back

B<Return Value:>

=over

=item $password_id_string 

Returns password ID on success and undef on failure

=back

B<Examples:>

    my $password_id = KMSs_generatePassword( 50, 1, 0, 0, 1 ); #With Special Characters
    my $password_id = KMSs_generatePassword( 50, 1, 0, 0, 0 ); #Without Special Characters

=cut

sub KMSs_generatePassword {
	my @args = @_;
	return unless S_checkFunctionArguments( 'KMSs_generatePassword( $length, $lc, $uc, $nums, $withSpecialChars )', @args );
    my $length             = shift @args;
    my $lc                 = shift @args;
    my $uc                 = shift @args;
    my $nums               = shift @args;
    my $withSpecialChars   = shift @args;
    my $password_id_string = $KMSs_hOle->KMSs_generatePassword($length, $lc, $uc, $nums, $withSpecialChars);
    return $password_id_string;
}

=head2 KMSs_storePassword

I<B<Syntax : >>

    my $password_id = KMSs_storePassword( $password_string );

I<B<Description : >>

    Stores a password in the KMSs.
    
    Returns the KMS-ID for the stored Password. To get password it has to be loaded with "KMSs_loadPassword"

I<B<Arguments : >>

    $password_string: The Password to save as String.

I<B<Example : >>

    my $password_id = KMSs_storePassword( "Password_To_Store123!" );

=cut

sub KMSs_storePassword {
    my $password_string    = shift;
    my $password_id_string = $KMSs_hOle->KMSs_storePassword($password_string);
    return $password_id_string;
}

=head2 KMSs_loadPassword

I<B<Syntax : >>

    my $password_string = KMSs_loadPassword($password_id_string);

I<B<Description : >>

    Gets password by ID from KMSs

I<B<Arguments : >>

    $password_id_string: ID returned from KMSs_generatePassword or KMSs_storePassword

I<B<Example : >>

    my $password_string = KMSs_loadPassword("69jrI4eq"; # gets password by ID = 69jrI4eq from KMSs

=cut

sub KMSs_loadPassword {
    my $keyID           = shift;
    my $password_string = $KMSs_hOle->KMSs_loadPassword($keyID);
    return $password_string;
}

=head2 KMSs_generateAESKeys

I<B<Syntax : >>

    my $aesKey = KMSs_generateAESKeys($length);

I<B<Description : >>

    Generates an AES Key in KMSs and returns the ID of the AES Key

I<B<Arguments : >>

    $length: 128 or 256

I<B<Example : >>

    my $aesKey = KMSs_generateAESKeys(256);

=cut

sub KMSs_generateAESKeys {
    my $length         = shift;
    my $aes_key_string = $KMSs_hOle->KMSs_generateAESKeys($length);
    return $aes_key_string;
}

=head2 KMSs_loadPrivateKey

I<B<Syntax : >>

    my $privateKey = KMSs_loadPrivateKey( $keyID, $type );

I<B<Description : >>

    Loads the Private key by ID. Returns the Private Key as String in PEM/PKSC-8

I<B<Arguments : >>

    $keyID: RSA-KeyID
    $type:  "RSA"

I<B<Example : >>

    my $privateKey = loadPrivateKey("dbjjG2bK", "RSA"));

=cut

sub KMSs_loadPrivateKey {
    my $keyID              = shift;
    my $type               = shift;
    my $private_key_string = $KMSs_hOle->KMSs_loadPrivateKey( $keyID, $type );
    return $private_key_string;
}

=head2 KMSs_loadPublicKey

I<B<Syntax : >>

    my $publicKey = KMSs_loadPublicKey( $keyID, $type );

I<B<Description : >>

    Loads the Public key by ID. Returns the Public Key as String in PEM/PKCS-1

I<B<Arguments : >>

    $keyID: RSA-KeyID
    $type:  "RSA"

I<B<Example : >>

    my $publicKey = KMSs_loadPublicKey( "dbjjG2bK", "RSA" );

=cut

sub KMSs_loadPublicKey {
    my $keyID             = shift;
    my $type              = shift;
    my $public_key_string = $KMSs_hOle->KMSs_loadPublicKey( $keyID, $type );
    return $public_key_string;
}

=head2 KMSs_loadAESKey

I<B<Syntax : >>

    my $aesKey = KMSs_loadAESKey( $keyID, $type );

I<B<Description : >>

    Loads the AES key by ID

I<B<Arguments : >>

    $keyID: AES-KeyID
    $type:  "AES"

I<B<Example : >>

    my $aesKey = KMSs_loadAESKey( "dbjjG2bK", "AES" );

=cut

sub KMSs_loadAESKey {
    my $keyID          = shift;
    my $type           = shift;
    my $aes_key_string = $KMSs_hOle->KMSs_loadAESKey( $keyID, $type );
    return $aes_key_string;
}

=head2 KMSs_answerChallenge

    my $signature_aref = KMSs_answerChallenge( $challengeMessage_aref, $cert_ID, $type );

This function will return the signature from given $challengeMessage_aref based on input $cert_ID and $type.

B<Arguments:>

=over

=item $challengeMessage_aref

challenge obtained from the ECU.

=item $cert_ID

Certificate ID returned from KMSs_generateX509Certificate or KMSs_generateCVC

=item $type

"X509" or "CVC"

=back

B<Return Values:>

=over

=item $signature_aref

Signature obtained from the KMSs.

=back

B<Examples:>

    my $length            = 1024;
    my $rsa_key_id_string = KMSs_generateRSAKeys($length);
    my $cert_ID = KMSs_generateX509Certificate( $g_rsa_key_id_string, "RSA" );
    my $type = "X509";
    
    my $challenge_aref = [0x30, 0x81, 0x9F, 0x80, 0x01, 0x01, 0x81, 0x01, 0x00, 0x8A, 0x01, 0x00, 0x90,
       0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x91, 0x30, 0x4D, 0x50, 0x48, 0x35, 0x33, 
       0x39, 0x20, 0x20, 0x20, 0x20, 0x03, 0xFF, 0x71, 0x00, 0x49, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x02, 0x02, 0x02, 0x02, 
       0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x9F, 0x20, 0x1F, 0x52, 0x42,
       0x41, 0x31, 0x41, 0x42, 0x53, 0x45, 0x53, 0x50, 0x31, 0x2F, 0x4F, 0x45, 0x4D, 0x41, 0x31, 0x3A,
       0x43, 0x4E, 0x3A, 0x44, 0x55, 0x4D, 0x4D, 0x59, 0x30, 0x30, 0x30, 0x30, 0x31, 0x9F, 0x21, 0x0F, 
       0x2B, 0x06, 0x01, 0x04, 0x01, 0xA9, 0x46, 0x93, 0x48, 0x15, 0x02, 0x01, 0x67, 0x01, 0x01, 0x9F,
       0x22, 0x10, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x10, 0x08, 0x00, 0x00, 0x00, 0x00,
       0x00, 0x00, 0x9F, 0x23, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x10, 0x08, 0x00, 
       0x00, 0x00, 0x00, 0x00, 0x00 ];
    
    my $signature_aref = KMSs_answerChallenge( $challenge_aref, $cert_ID, $type );
    $signature_aref =
    [48, 130, 2, 33, 128, 1, 1, 129, 1, 0, 159, 41, 129, 128, 154, 232, 101, 162, 28, 84, 87, 60,
    209, 90, 95, 111, 253, 86, 57, 56, 113, 186, 230, 61, 236, 210, 69, 154, 150, 18, 197, 214, 
    234, 206, 218, 10, 1, 116, 168, 175, 78, 129, 177, 254, 2, 174, 255, 26, 81, 156, 113, 159,
    89, 66, 84, 38, 199, 61, 96, 176, 93, 154, 5, 42, 40, 156, 84, 121, 196, 82, 247, 177, 252,
    254, 42, 148, 241, 26, 62, 130, 43, 250, 190, 17, 168, 235, 116, 246, 132, 40, 13, 16, 53, 
    217, 255, 115, 183, 56, 142, 120, 156, 207, 18, 241, 109, 208, 72, 8, 46, 232, 161, 118, 57,
    71, 68, 89, 125, 74, 73, 181, 48, 50, 154, 113, 82, 93, 52, 25, 119, 251, 201, 211, 191, 42,
    130, 1, 146, 4, 130, 1, 142, 127, 33, 130, 1, 137, 127, 78, 130, 1, 0, 95, 41, 1, 0, 66, 23,
    82, 66, 65, 100, 83, 121, 122, 71, 111, 84, 98, 58, 67, 78, 58, 68, 85, 77, 77, 89, 0, 0, 1,
    127, 73, 129, 150, 6, 12, 134, 142, 85, 1, 1, 3, 6, 1, 4, 1, 12, 1, 129, 129, 128, 195, 214,
    154, 35, 110, 10, 18, 65, 228, 35, 8, 132, 50, 221, 115, 191, 116, 164, 51, 163, 252, 
    226, 207, 187, 18, 79, 245, 178, 66, 248, 103, 53, 143, 37, 155, 92, 51, 38, 7, 137, 
    194, 253, 36, 74, 187, 68, 249, 192, 117, 238, 249, 113, 120, 194, 87, 109, 206, 217, 
    126, 47, 15, 129, 239, 70, 52, 24, 207, 138, 165, 204, 235, 49, 236, 244, 220, 227, 
    17, 109, 178, 19, 12, 27, 237, 120, 104, 85, 60, 252, 35, 81, 138, 35, 44, 107, 83, 
    203, 77, 89, 59, 68, 17, 99, 18, 50, 149, 187, 103, 52, 212, 26, 248, 6, 49, 21, 139,
    50, 179, 229, 93, 133, 236, 28, 67, 149, 110, 22, 237, 3, 130, 3, 1, 0, 1, 95, 32, 23,
    82, 66, 65, 100, 83, 121, 122, 71, 111, 84, 98, 58, 67, 78, 58, 68, 85, 77, 77, 89, 0,
    0, 1, 127, 76, 26, 6, 6, 134, 142, 85, 2, 1, 0, 83, 16, 48, 0, 0, 0, 0, 0, 0, 127, 0,
    0, 0, 0, 0, 167, 255, 255, 95, 37, 6, 2, 0, 0, 6, 2, 5, 95, 36, 6, 2, 0, 0, 7, 2, 5, 
    95, 55, 129, 128, 27, 55, 102, 144, 64, 244, 248, 3, 72, 114, 25, 215, 225, 189, 182,
    196, 173, 123, 71, 194, 46, 157, 76, 254, 242, 170, 211, 50, 165, 43, 56, 133, 43, 52, 
    72, 199, 211, 6, 141, 181, 41, 209, 164, 179, 85, 119, 203, 230, 18, 82, 39, 55, 239, 
    57, 176, 237, 43, 78, 161, 29, 152, 14, 109, 230, 79, 175, 115, 142, 53, 166, 35, 2, 
    25, 197, 89, 153, 48, 97, 55, 11, 40, 110, 139, 246, 186, 137, 88, 222, 106, 234, 35,
    12, 237, 253, 68, 142, 29, 139, 137, 238, 107, 194, 159, 199, 177, 91, 115, 126, 125,
    212, 223, 130, 101, 59, 185, 201, 38, 198, 196, 243, 179, 208, 65, 244, 183, 102, 50, 250,];
     
     
B<Notes:> 

=cut

sub KMSs_answerChallenge {
    my @args = @_;
    S_checkFunctionArguments( 'KMSs_answerChallenge( $challengeMessage_aref, $cert_ID, $type )', @args ) or return;

    my $challengeMessage_aref = shift @args;
    my $cert_ID               = shift @args;
    my $type                  = shift @args;

    # STEP validate the arguments $type
    my @validTypes = ( 'X509', 'CVC' );
    unless ( grep { /^$type/i } @validTypes ) {
        S_set_error( "KMSs_answerChallenge passed type = '$type' is not supported. Supported types are : '@validTypes' \n", 109 );
        return;
    }

    # CALL LIFT_stringProcessing::STR_Aref2HexString to convert input aref to hex string
    my $challengeMessage_string = STR_Aref2HexString( $challengeMessage_aref, { Seperator_character => '' } );

    S_w2log( 3, "KMSs_answerChallenge [challenge hex string= '$challengeMessage_string' , certificate = '$cert_ID' and type = '$type'] \n " );

    # STEP call dll function to obtain signature.
    my $signature_string = $KMSs_hOle->KMSs_answerChallenge( $challengeMessage_string, $cert_ID, $type );

    S_w2log( 3, "KMSs_answerChallenge : signature hex string  = '$signature_string'  \n " );

    # CALL LIFT_stringProcessing::STR_HexString2ListOfUnsignedIntegers to convert
    my $signature_aref = STR_HexString2ListOfUnsignedIntegers($signature_string);
    S_w2log( 4, "KMSs_answerChallenge : signature as list of uint   = '@$signature_aref'  \n " );

    # STEP return $signature_aref
    return $signature_aref;
}

=head2 KMSs_loadX509Certificate

I<B<Syntax : >>

     my $x509Certificate_string = KMSs_loadX509Certificate($keyID);

I<B<Description : >>

    Loads the Certificate by Certification ID

I<B<Arguments : >>

    $keyID: E.g. returned from KMSs_generateX509Certificate

I<B<Example : >>

    my $x509Certificate_string = KMSs_loadX509Certificate("5WRpIkKK");

=cut

sub KMSs_loadX509Certificate {
    my $keyID                  = shift;
    my $x509Certificate_string = $KMSs_hOle->KMSs_loadX509Certificate($keyID);
    return $x509Certificate_string;
}

=head2 KMSs_deleteID

I<B<Syntax : >>

     KMSs_deleteID($keyID, $type);

I<B<Description : >>

     Deletes the stored Data. It needs the ID and Type to delete something.

I<B<Arguments : >>

    $keyID: E.g. AES_Key_ID returned from KMSs_generateAESKeys
    $type:  E.g. "AES256"

I<B<Example : >>

    KMSs_deleteID("2A3wJBt4", "AES256");

=cut

sub KMSs_deleteID {
    my $keyID = shift;
    my $type  = shift;
    $KMSs_hOle->KMSs_deleteID( $keyID, $type );
    return 1;
}

=head2 KMSs_generateRSAKeys

I<B<Syntax : >>

     my $rsa_key_id_string = KMSs_generateRSAKeys($length);

I<B<Description : >>

    Genereates an RSA Key Pair.

I<B<Arguments : >>

    $length: 1024 or 2048 (for RSA1024 or RSA2048)

I<B<Example : >>

    my $rsa_key_id_string = KMSs_generateRSAKeys(1024);

=cut

sub KMSs_generateRSAKeys {
    my $length            = shift;
    my $rsa_key_id_string = $KMSs_hOle->KMSs_generateRSAKeys($length);
    return $rsa_key_id_string;
}

=head2 KMSs_setSHECounter

    1 = KMSs_setSHECounter( $she_uid, $mem_id, $counter );

Sets the counter value for the given SHE_UID and MEM_ID 

B<Arguments:>

=over

=item $she_uid 

HEX_String of the SHE_UID, HEX_String should not include '0x' at the beginning.

=item $mem_id 

String of the MEM_ID has to be one of "MASTER_ECU_KEY" | "BOOT_MAC_KEY" | "BOOT_MAC" | "KEY_N"(N:1-12)

=item $counter 

counter in integer format

=back

B<Return Value:>

Returns 1 on success

B<Examples:>

    1 = KMSs_setSHECounter("000000000000000000000000000000", "MASTER_ECU_KEY", 2);

=cut

sub KMSs_setSHECounter {
    my $she_uid = shift;
    my $mem_id  = shift;
    my $counter = shift;
    $KMSs_hOle->KMSs_setSHECounter( $she_uid, $mem_id, $counter );
    return 1;
}

=head2 KMSs_getSHECounter

    $counter = KMSs_getSHECounter( $she_uid, $mem_id );

Returns the counter value for the given SHE_UID and MEM_ID

B<Arguments:>

=over

=item $she_uid 

HEX_String of the SHE_UID, HEX_String should not include '0x' at the beginning.

=item $mem_id 

String of the MEM_ID has to be one of "MASTER_ECU_KEY" | "BOOT_MAC_KEY" | "BOOT_MAC" | "KEY_N"(N:1-12)

=back

B<Return Value:>

=over

=item $counter

Returns the counter value for the given SHE_UID and MEM_ID

=back

B<Examples:>

    my $counter = KMSs_getSHECounter("000000000000000000000000000000", "MASTER_ECU_KEY");

=cut

sub KMSs_getSHECounter {
    my @args = @_;
    S_checkFunctionArguments( 'KMSs_getSHECounter(  $she_uid, $mem_id  )', @args ) or return;

    my $she_uid = shift @args;
    my $mem_id  = shift @args;

    #IF KMSs initialised?
    #IF-NO-START
    #STEP ERROR KMSs should be initialised
    unless ($KMSs_initialized) {
        S_set_error("KMSs_getSHECounter: KMSs not initialised , call KMSs_init() before calling any other function");
        return;
    }

    $she_uid =~ s/^0x//;    # remove 0x if present

    if ( $she_uid !~ /^[0-9a-fA-F]+$/ ) {
        S_set_error("KMSs_getSHECounter: argument $she_uid is not a hex string, check the value configured");
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #CALL Dll interface KMSs_getSHECounter to get counter value
    my $counter = $KMSs_hOle->KMSs_getSHECounter( $she_uid, $mem_id );
    unless ( defined $counter ) {
        S_set_error("KMSs_getSHECounter: Getting counter value unsuccessful !");
        return;
    }

    S_w2log( 3, "KMSs_getSHECounter: counter value obtained: $counter\n" );

    #IF-YES-END
    #STEP-END
    return $counter;
}

=head2 KMSs_generateSHEMessages

I<B<Syntax : >>

    KMSs_generateSHEMessages($args_href);

I<B<Description : >>

    Generates the SHE_Messages

I<B<Arguments : >>

    $args_href = {
      'she_uid'     => $she_uid,     # IN: HEX_String of the SHE_UID (KMSs will interpret the SHE_UID as 120 Bit)
      'mem_id'      => $mem_id,      # IN: String of the MEM_ID has to be one of
                                     # "MASTER_ECU_KEY" | "BOOT_MAC_KEY" | "BOOT_MAC" | "KEY_N"(N:1-12)
      'auth_id'     => $auth_id,     # IN: String of the AUTH_ID same as MEM_ID
      'auth_key_id' => $auth_key_id, # IN: KMS-ID of the Authentication key
      'new_key_id'  => $new_key_id,  # IN: KeyID of the new Key to use
      'flags'       => $flags,       # IN: flag as bit String (6 Bits)
      'm1_ref'      => $m1_ref,      # OUT: reference to string of hex values
      'm2_ref'      => $m2_ref,      # OUT: reference to string of hex values
      'm3_ref'      => $m3_ref,      # OUT: reference to string of hex values
      }

I<B<Example : >>

    my $authKey = KMSs_saveAESKey("000102030405060708090a0b0c0d0e0f", "AES");
    my $g_newAESKeY = KMSs_saveAESKey("0f0e0d0c0b0a09080706050403020100", "AES");
    KMSs_setSHECounter("000000000000000000000000000001", "4", 0);
    my ($m1, $m2, $m3);
    
    KMSs_generateSHEMessages(
        {
            'she_uid'     => "000000000000000000000000000001",
            'mem_id'      => "4",
            'auth_id'     => "1",
            'auth_key_id' => $authKey,       # e.g. returned from KMSs_saveAESKey
            'new_key_id'  => $newAESKeY,     # e.g. returned from KMSs_saveAESKey
            'flags'       => "00000",
            'm1_ref'      => \$m1,           # m1 and
            'm2_ref'      => \$m2,           # m2 and
            'm3_ref'      => \$m3            # m3 returned by reference
        }
    );


=cut

sub KMSs_generateSHEMessages {
    my @args = @_;

    return 0 unless S_checkFunctionArguments( 'KMSs_generateSHEMessages( $args_href )', @args );

    my $inArgs_href = shift;

    # hash defines the set of valid keys
    my $valid_in_arg_keys = {
        'she_uid'     => 1,
        'mem_id'      => 1,
        'auth_id'     => 1,
        'auth_key_id' => 1,
        'new_key_id'  => 1,
        'flags'       => 1,
        'm1_ref'      => 1,
        'm2_ref'      => 1,
        'm3_ref'      => 1
    };
    my $mandatory_keys = {
        'she_uid'     => 1,
        'mem_id'      => 1,
        'auth_id'     => 1,
        'auth_key_id' => 1,
        'new_key_id'  => 1,
        'flags'       => 1,
        'm1_ref'      => 1,
        'm2_ref'      => 1,
        'm3_ref'      => 1
    };

    return 0 unless S_checkFunctionArgumentHashKeys( "KMSs_generateSHEMessages", $inArgs_href, $valid_in_arg_keys, $mandatory_keys );

    my $she_uid     = $inArgs_href->{'she_uid'};
    my $mem_id      = $inArgs_href->{'mem_id'};
    my $auth_id     = $inArgs_href->{'auth_id'};
    my $auth_key_id = $inArgs_href->{'auth_key_id'};
    my $new_key_id  = $inArgs_href->{'new_key_id'};
    my $flags       = $inArgs_href->{'flags'};
    my $m1_ref      = $inArgs_href->{'m1_ref'};
    my $m2_ref      = $inArgs_href->{'m2_ref'};
    my $m3_ref      = $inArgs_href->{'m3_ref'};

    my $m1_var = Variant( VT_BSTR | VT_BYREF );
    my $m2_var = Variant( VT_BSTR | VT_BYREF );
    my $m3_var = Variant( VT_BSTR | VT_BYREF );

    $KMSs_hOle->KMSs_generateSHEMessages( $she_uid, $mem_id, $auth_id, $auth_key_id, $new_key_id, $flags, $m1_var, $m2_var, $m3_var );

    $$m1_ref = $m1_var->Value();
    $$m2_ref = $m2_var->Value();
    $$m3_ref = $m3_var->Value();

    return 1;
}

=head2 KMSs_validateSHEMessages

I<B<Syntax : >>

    my $isValid    = KMSs_validateSHEMessages( $m4, $m5, $uid, $mem_id, $auth_id, $new_key_id );

I<B<Description : >>

    Validates the SHE Messages M4 and M5. Returns 0: invalid or 1: valid

I<B<Arguments : >>

    $m4:         M4 as hex String
    $m5:         M5 as hex String
    $uid:        String of the SHE_UID
    $mem_id:     String of the MEM_ID
    $auth_id:    ID of the SHE Authentication
    $new_key_id: KeyID of the new Key to use

I<B<Example : >>



=cut

sub KMSs_validateSHEMessages {
    my $m4         = shift;
    my $m5         = shift;
    my $uid        = shift;
    my $mem_id     = shift;
    my $auth_id    = shift;
    my $new_key_id = shift;
    my $isValid    = $KMSs_hOle->KMSs_validateSHEMessages( $m4, $m5, $uid, $mem_id, $auth_id, $new_key_id );
    return $isValid;
}

=head2 KMSs_addAuthorization

I<B<Syntax : >>

    KMSs_addAuthorization (string auth_Value, string parsed_auth_oid )		

I<B<Description : >>

    Stores the Authorization value in the given identifier

B<Arguments:>

=over

=item $auth_Value 

Authorization value to be added

Example : $auth_Value = "0400FFFFFFFFFFFFFFFFFFFFFFFFFFFF";

=item $parsed_auth_oid 

Object identifier to store authorization value

Example: $parsed_auth_oid = "1.3.6.1.4.1.5318.2504.21.2.1.9.0";

=back

B<Return Value:>

=over

=item $returnValue 

This Function returns 1 on success and undef on failure.

=back

B<Examples:>

1 = KMSs_addAuthorization ('0400FFFFFFFFFFFFFFFFFFFFFFFFFFFF', '1.3.6.1.4.1.5318.2504.21.2.1.9.0')

=cut

sub KMSs_addAuthorization {

    #checking for mandate arguments for the function
    my @args = @_;

    #IF check if $auth_Value and $parsed_auth_oid is defined.
    #IF-NO-START
    #STEP Return undef.
    #IF-NO-END
    return unless S_checkFunctionArguments( 'KMSs_addAuthorization( $auth_Value, $parsed_auth_oid )', @args );

    #IF-YES-START
    my $auth_Value      = shift @args;
    my $parsed_auth_oid = shift @args;

    #IF check for invalid characters.
    #IF-YES-START
    #STEP Return undef with error message to report
    #IF-YES-END

    if ( $auth_Value !~ /^[0-9A-Fa-f]+$/gm ) {
        S_set_error( "KMSs_addAuthorization: Given $auth_Value is not valid, digit range should be 0-F are allowed.", 109 );
        return;
    }
    unless ( $parsed_auth_oid =~ /^[0-9][0-9.]+[0-9]$/gm ) {
        S_set_error( "KMSs_addAuthorization: Given $parsed_auth_oid is not valid format, please check input format.", 109 );
        return;
    }

    #IF-NO-START
    #STEP Using KMS ole Object, calls the KMSs_addAuthorization()
    #IF-NO-END
    #IF-YES-END

    #calls the KMS ole Object and calls the KMSs_addAuthorization().
    S_w2log( 3, "KMSs_addAuthorization: Calling KMSs_addAuthorization\n" );
    $KMSs_hOle->KMSs_addAuthorization( $auth_Value, $parsed_auth_oid );
    S_w2log( 3, "KMSs_addAuthorization: adding authorisation completed\n" );

    #STEP END
    return 1;
}

=head2 KMSs_savePrivateKey

I<B<Syntax : >>

    my $private_key_id_string = KMSs_savePrivateKey( $private_key, $type );

I<B<Description : >>

    Saves a private key. Returns the ID of the private key as string

I<B<Arguments : >>

    $private_key: As string in PEM/PKSC-8 format
    $type:        E.g. "RSA1024 / RSA 2048"    

I<B<Example : >>



=cut

sub KMSs_savePrivateKey {
    my $private_key           = shift;
    my $type                  = shift;
    my $private_key_id_string = $KMSs_hOle->KMSs_savePrivateKey( $private_key, $type );
    return $private_key_id_string;
}

=head2 KMSs_savePublicKey

I<B<Syntax : >>

    my $public_key_id_string = KMSs_savePublicKey( $public_key, $type );

I<B<Description : >>

    Saves a Public Key. Returns the ID of the Public key as string

I<B<Arguments : >>

    $public_key: As String in PEM/PKCS-1 Format
    $type:       E.g. "RSA1024"

I<B<Example : >>



=cut

sub KMSs_savePublicKey {
    my $public_key           = shift;
    my $type                 = shift;
    my $public_key_id_string = $KMSs_hOle->KMSs_savePublicKey( $public_key, $type );
    return $public_key_id_string;
}

=head2 KMSs_saveAESKey

I<B<Syntax : >>

    my $aes_key_id_string = KMSs_saveAESKey( $aes_key, $type );

I<B<Description : >>

    Saves an AES Key. Returns the ID of the saved Key

I<B<Arguments : >>

    $aes_key: hex String
    $type:    E.g "AES256"

I<B<Example : >>



=cut

sub KMSs_saveAESKey {
    my $aes_key           = shift;
    my $type              = shift;
    my $aes_key_id_string = $KMSs_hOle->KMSs_saveAESKey( $aes_key, $type );
    return $aes_key_id_string;
}

=head2 KMSs_savePairOfKeys

I<B<Syntax : >>

    my $pair_key_id_string = KMSs_savePairOfKeys( $private_key, $public_key, $type );

I<B<Description : >>

    Saves a Pair of Keys. Same as for KMSs_savePublicKey or KMSs_savePrivateKey, but saves both with same id.

I<B<Arguments : >>

    $private_key:
    $public_key:
    $type:

I<B<Example : >>



=cut

sub KMSs_savePairOfKeys {
    my $private_key        = shift;
    my $public_key         = shift;
    my $type               = shift;
    my $pair_key_id_string = $KMSs_hOle->KMSs_savePairOfKeys( $private_key, $public_key, $type );
    return $pair_key_id_string;
}

=head2 KMSs_saveCertificate

I<B<Syntax : >>

    my $certID = KMSs_saveCertificate($certificate, $type);

I<B<Description : >>

    Saves a certificate in the KMSs. This is possible for the X509 and CVC.

I<B<Arguments : >>

    $certificate: as hex string (X509: bytes in PEM-Format, CVC as Hex-String)
    $type:        "X509" or "CVC"

I<B<Example : >>



=cut

sub KMSs_saveCertificate {
    my $certificate        = shift;
    my $type               = shift;
    my $certificate_string = $KMSs_hOle->KMSs_saveCertificate( $certificate, $type );
    return $certificate_string;
}

=head2 KMSs_setIDlength

I<B<Syntax : >>

    KMSs_setIDlength($length);

I<B<Description : >>

    Sets the length of the used IDs. Standard length is 8. 

I<B<Arguments : >>

    $length: The given ID length will be saved in an extra txt file, "data/idlength.txt"

I<B<Example : >>



=cut

sub KMSs_setIDlength {
    my $length = shift;
    $KMSs_hOle->KMSs_setIDlength($length);
    return 1;
}

=head2 KMSs_resetAll

I<B<Syntax : >>

    KMSs_resetAll();

I<B<Description : >>

    Resets the whole KMSs
        Deletes all stored Certificates
        Deletes all stores Keys
        Deletes all stored Passwords
        Resets counters for the SHE protocols

I<B<Arguments : >>

    none

I<B<Example : >>



=cut

sub KMSs_resetAll {
    $KMSs_hOle->KMSs_resetAll();
    return 1;
}

=head2 KMSs_generateX509Certificate

I<B<Syntax : >>

    my $x509Certificate_id_string = KMSs_generateX509Certificate( $key_id, $type );

I<B<Description : >>

    Generates a X059 Certificate for a given RSA key and Type. 
    Type is the Type of the RSA Key as String. "RSA1024" "RSA2048". "RSA" works for both.
    The type is needed because one specification of the KMSs was, that it will throw an error,
    if a key of the wrong type is used.
    Returns the ID of the certificate.
    The certificate is stored in the KMS and can be returned with loadCertificate(certID)

I<B<Arguments : >>

    $key_id:
    $type:

I<B<Example : >>



=cut

sub KMSs_generateX509Certificate {
    my $key_id                    = shift;
    my $type                      = shift;
    my $x509Certificate_id_string = $KMSs_hOle->KMSs_generateX509Certificate( $key_id, $type );
    return $x509Certificate_id_string;
}

=head2 KMSs_generateCVC

   my $cvc_id_string = KMSs_generateCVC( $parsed_uc_oid, $parsed_auth_oid, $cert_authority_reference, $cert_holder_reference, $is_self_signed, $register_car, $contained_key_id );

Generates the CVC ID

B<Arguments:>

=over

=item $parsed_uc_oid 

Object Identifier(OID) for use case

A parsed OID is expected as a string with each of the integer values separated by a '.'

Example: $parsed_uc_oid = '1.3.6.1.4.1.5318.2504.21.1.0.1'

=item $parsed_auth_oid 

Object Identifier(OID) to store authorization value of the certificate

A parsed OID is expected as a string with each of the integer values separated by a '.'

Example: $parsed_auth_oid = '1.3.6.1.4.1.5318.2504.21.2.1.9.0'

=item $cert_authority_reference 

Reference Name for the signing certificate

=item $cert_holder_reference

Reference Name of the certificate

=item $is_self_signed

1 - if the certificate shall be self signed

0 - if the certificate shall be signed by a super ordinated certificate

i.e.$is_self_signed shall be set to 0 when using different certificate authority reference and certificate holder reference

=item $register_car

1 - if the authority reference shall be assigned to the ID of the given superordinated certificate

0 - if the authority reference shall not be assigned to the ID of the given superordinated certificate

=item $contained_key_id

ID of the RSA key pair whose public key is contained in the certificate

=back

B<Return Value:>

=over

=item $cvc_id_string

Returns the CVC ID as a Hex String on success and undef on failure

=back

B<Examples:>

    $cert_id = KMSs_generateCVC('1.3.6.1.4.1.5318.2504.21.1.0.1','1.3.6.1.4.1.5318.2504.21.2.1.9.0','KMSsRoot','KMSsRoot',1,1,'oCkzbe7g');
    $cert_id = KMSs_generateCVC('1.3.6.1.4.1.5318.2504.21.1.0.1','1.3.6.1.4.1.5318.2504.21.2.1.9.0','KMSsRoot','PDUser:000',0,1,'oCkzbe7g');  
    $cert_id = KMSs_generateCVC('1.3.6.1.4.1.5318.2504.21.1.8.1','1.3.6.1.4.1.5318.2504.21.2.1.9.0.1','PDUser:000','PDUser/end:001',0,1,'oCkzbe7g');
        
B<Notes:> 

This function has dependencies on functions KMSs_addAuthorization and KMSs_generateRSAKeys

KMSs_addAuthorization and KMSs_generateRSAKeys need to be called before calling KMSs_generateCVC in the following sequence

B<Sequence:>

1) KMSs_addAuthorization ( $auth_Value, $parsed_auth_oid);

2) $contained_key_id = KMSs_generateRSAKeys ($length);
	
3) $cvc_id_string = KMSs_generateCVC($parsed_uc_oid,$parsed_auth_oid,$cert_authority_reference,$cert_holder_reference,$is_self_signed,$register_car,$contained_key_id);

=cut

sub KMSs_generateCVC {
	#IF check if mandatory keys - $parsed_uc_oid, $parsed_auth_oid, $cert_authority_reference, $cert_holder_reference, $is_self_signed, $register_car and  $contained_key_id are defined in $cvcParams_href that is passed to KMSs_generateCVC
	#IF-NO-START
    #STEP Return undef
    #IF-NO-END
    my @args = @_;
	return unless S_checkFunctionArguments( 'KMSs_generateCVC ( $cvcParams_href )', @args );
	my $cvcParams_href = shift @args;
	my $valid_mandatory_keys = {
		'parsed_uc_oid'            => 1,
		'parsed_auth_oid'          => 1,
		'cert_authority_reference' => 1,
		'cert_holder_reference'    => 1,
		'is_self_signed'           => 1,
		'register_car'             => 1,
		'contained_key_id'         => 1
	};
	return unless S_checkFunctionArgumentHashKeys( "KMSs_generateCVC", $cvcParams_href, $valid_mandatory_keys, $valid_mandatory_keys );
    my $parsed_uc_oid            = $cvcParams_href->{'parsed_uc_oid'};
    my $parsed_auth_oid          = $cvcParams_href->{'parsed_auth_oid'};
    my $cert_authority_reference = $cvcParams_href->{'cert_authority_reference'};
    my $cert_holder_reference    = $cvcParams_href->{'cert_holder_reference'};
    my $is_self_signed           = $cvcParams_href->{'is_self_signed'};
    my $register_car             = $cvcParams_href->{'register_car'};
    my $contained_key_id         = $cvcParams_href->{'contained_key_id'};
    #IF-YES-START
    #STEP Call the OLE object to trigger the python function
    #STEP Return the received CVC ID
    #IF-YES-END
    my $cvc_id_string = $KMSs_hOle->KMSs_generateCVC($parsed_uc_oid,$parsed_auth_oid,$cert_authority_reference,$cert_holder_reference,$is_self_signed,$register_car,$contained_key_id);
    return $cvc_id_string;
    #STEP END
}

=head2 KMSs_loadCVC

I<B<Syntax : >>

     my $cvc_id_string = KMSs_loadCVC($key_id);

I<B<Description : >>

    Loads the CVC for the given certID. Returns the CVC as hex string

I<B<Arguments : >>

    $key_id: E.g. returned from KMSs_generateCVC

I<B<Example : >>



=cut

sub KMSs_loadCVC {
    my $keyID         = shift;
    my $cvc_id_string = $KMSs_hOle->KMSs_loadCVC($keyID);
    return $cvc_id_string;
}

=head2 KMSs_calculateCMAC

I<B<Syntax : >>

     my $cmac_string = KMSs_calculateCMAC( $data, $key_id, $type );

I<B<Description : >>

    Genereats a CMAC for given RSA key and DATA

I<B<Arguments : >>

    $data:   Abitary data as hex string
    $key_id: keyID of RSA
    $type:   Type of the AES key ("AES", "AES128" or "AES258")

I<B<Example : >>



=cut

sub KMSs_calculateCMAC {
    my $data        = shift;
    my $keyID       = shift;
    my $type        = shift;
    my $cmac_string = $KMSs_hOle->KMSs_calculateCMAC( $data, $keyID, $type );
    return $cmac_string;
}

=head2 KMSs_sign

I<B<Syntax : >>

     my $sign_data_string = KMSs_sign( $data, $key_id, $type, $algorithm, $hash );

I<B<Description : >>

    Signs given Data with specified RSA key.

I<B<Arguments : >>

    $data:      data as hex String
    $key_id:    KeyID of the RSA-Key to used
    $type:      type of the RSA-Key as string ("RSA1024", "RSA2048" or "RSA")
    $algorithm: algorithm to use "PSS" or "OAP"
    $hash:      Hashfunction
                "SHA224", "SHA256", "SHA384", "SHA3_224", "SHA3_256", "SHA3_384", "SHA3_512",
                "BLAKE2s" or "BLAKE2b"

I<B<Example : >>



=cut

sub KMSs_sign {
    my $data             = shift;
    my $keyID            = shift;
    my $type             = shift;
    my $algorithm        = shift;
    my $hash             = shift;
    my $sign_data_string = $KMSs_hOle->KMSs_sign( $data, $keyID, $type, $algorithm, $hash );
    return $sign_data_string;
}

=head2 Application_create

    $success = Application_create();

Loads and initializes the KMSs DLLs

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub Application_create {

    #$KMSs_hOle = S_create_OLE($KMSs_PROGID); # does not allow offline mode!
    $KMSs_hOle = Win32::OLE->new($KMSs_PROGID);    # allows offline mode

    unless ( defined($KMSs_hOle) ) {
        S_set_error( "Unable to start COM-DLL $KMSs_PROGID (Try '_run_once.bat' to register it), " . Win32::OLE->LastError(), 5 );
        return 0;
    }

    return 1;
}

=head2 Application_destroy

    $success = Application_destroy();



B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub Application_destroy {

    #    $KMSs_hOle->Quit();
    #    $KMSs_hOle = undef;
}

=head2 CheckStatus

    $success = CheckStatus($status);


B<Arguments:>

=over

=item $status

return value of a KMSs_NET.dll API call

=back


B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub CheckStatus {
    my $status = shift;

    if ( $status == 0 ) {
        my $errortext = $KMSs_hOle->KMSs_getLastErrorString();
        S_set_error( "KMSs ($status): $errortext", 5 );
        return 0;
    }

    return $status;
}

sub LastError2log {
    my $errortext    = $KMSs_hOle->KMSs_getLastErrorString();
    my $returnLength = length($errortext);
    S_w2log( 3, "$errortext" );
    return $errortext;
}

sub CatchOleException {
    my $errorText = Win32::OLE->LastError();
    S_set_error( "$errorText", 23 );
    return;
}

=head2 KMSs_registerCertificatesAndRSAKeys

I<B<Syntax : >>

    $returnValue = KMSs_registerCertificatesAndRSAKeys($register_type, $certKeys_href);
    
I<B<Description : >>    

    This function maps the certificateId and RSAKeyId and register it to kms simulator.
    
B<Arguments:>

=over

=item $register_type

$register_type is a mandatory parameter.

$register_type can be either 'SecureAccessForPD' or  'SecureAccessForBootloader'.

Ex: $register_type = 'SecureAccessForPD';

=item $certKeys_href 

$certKeys_href is a mandatory parameter.
    
$certKeys_href is hash reference of certificateId and RSAKeyId.
    
Ex:- 
my $certKeys_href = {
    'rootCertificateId'   => $rootCertificateId,
    'interCertificateId'  => $interCertificateId,
    'userCertificateId'   => $userCertificateId,
    'rootRSAKeyId'        => $rootRSAKeyId,
    'interRSAKeyId'       => $interRSAKeyId, 
    'userRSAKeyId'        => $userRSAKeyId, 
};


=item $optArg1 

None.

=item $optArg2 

None.

=back

B<Return Value:>

=over

=item $returnValue 

    $returnValue = 1: on success

    $returnValue = 0: on failure (like missing args, invalid args, etc.)

=back

B<Examples:>


B<Notes:> 


=cut

sub KMSs_registerCertificatesAndRSAKeys {
    my @args = @_;

    #IF checks require parameter

    #IF-NO-START
    #STEP Return 0.
    #IF-NO-END

    # checks require parameter
    return 0
      unless S_checkFunctionArguments(
        'KMSs_registerCertificatesAndRSAKeys($register_type, $certKeys_href)',
        @args );

# extract register_type either 'SecureAccessForPD' or 'SecureAccessForBootloader'
    my $register_type = shift @args;

    # extract parameter hash_ref
    my $certKeys_href = shift @args;

    # check for require elements of $certKeys_href
    my $mandatoryArgs_href = {
        'rootCertificateId'  => 1,
        'interCertificateId' => 1,
        'userCertificateId'  => 1,
        'rootRSAKeyId'       => 1,
        'interRSAKeyId'      => 1,
        'userRSAKeyId'       => 1
    };
    my $validArgs_href = {
        'rootCertificateId'  => 1,
        'interCertificateId' => 1,
        'userCertificateId'  => 1,
        'rootRSAKeyId'       => 1,
        'interRSAKeyId'      => 1,
        'userRSAKeyId'       => 1
    };
    if ($certKeys_href) {
        return 0
          unless S_checkFunctionArgumentHashKeys(
            'KMSs_registerCertificatesAndRSAKeys',
            $certKeys_href, $validArgs_href, $mandatoryArgs_href );
    }

#IF-YES-START
#IF checks valid $register_type either 'SecureAccessForPD' or 'SecureAccessForBootloader'.
#IF-NO-START
#STEP return 0
#IF-NO-END
    return 0
      unless ( $register_type eq
        ( 'SecureAccessForPD' or 'SecureAccessForBootloader' ) );

    #IF-YES-START
    #STEP call and return the response of KMSs_registerCertificatesAndRSAKeys()
    #IF-YES-END
    # calls  KMSs_registerCertificatesAndRSAKeysInKMS() using $KMSs_hOle object
    return $KMSs_hOle->KMSs_registerCertificatesAndRSAKeysInKMS(
        $register_type,
        $certKeys_href->{rootCertificateId},
        $certKeys_href->{interCertificateId},
        $certKeys_href->{userCertificateId},
        $certKeys_href->{rootRSAKeyId},
        $certKeys_href->{interRSAKeyId},
        $certKeys_href->{userRSAKeyId}
    );

    #IF-YES-END
    #STEP END
}
1;
