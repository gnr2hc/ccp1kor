# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_simulation;

use strict;
use warnings;
use LIFT_general;
use Data::Dumper;
use Storable qw(dclone);

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  SIM_addToValuesTable
  SIM_setReturnValues
  SIM_returnValues
);

our ( $VERSION, $HEADER );

my $returnValuesTemp_href  = {};
my $returnValuesTable_href = {};
our $helper;

=head1 NAME

LIFT_simulation 

Simulation mode functions

=head1 SYNOPSIS

    use LIFT_simulation;

    SIM_setReturnValues( ... );


=head1 DESCRIPTION

Local functions for simulation mode.


=head2 SIM_setReturnValues

    $success = SIM_setReturnValues( $functionName , $returnValues [, $functionArgs_aref, $repetitions] );
    
Define the return values of function $functionName for the next call(s) of SIM_returnValues for this function.
See arguments for more detail.

B<Arguments:>

=over

=item $functionName 

Name of the low level function for which return values shall be defined.

=item $returnValues 

If $returnValues is an array reference then the return values of SIM_returnValues is $returnValues.
If $returnValues is a scalar then the return values of SIM_returnValues is taken from the hash $returnValuesTable_href
(see SIM_addToValuesTable).

If $returnValues is a code reference (subroutine) then the return values of SIM_returnValues are calculated by the given subroutine. 
In this case $functionArgs_aref is used as a vector of input values (iterator) that are passed one by one to the subroutine as first argument. 
Further arguments that are passed to the subroutine are the arguments that are passed to $functionName when it is called.
If the subroutine returns undef then the normal default mechanisms of SIM_returnValues apply.
So, if returning values from the subroutine should be stopped then an empty vector of input values should be given.
If any values shall be stored between subsequent call to the subroutine then the variable $LIFT_simulation::helper may be used. 

=item $functionArgs_aref (optional)

If given and if $returnValues is a scalar or an array reference then the return values are defined only for a call to the function 
with exactly the arguments as given in $functionArgs_aref.

If $returnValues is a code reference (subroutine) then $functionArgs_aref holds the reference to a vector of input values (iterator),
see argument $returnValues above.

=item $repetitions (optional)

Defines the number of times that SIM_returnValues shall return $returnValues if $returnValues is an array reference.
If $returnValues is a code reference then $repetitions is ignored.

If $repetitions is not given then it is set to the default value of 1.

=back

B<Return Value:>

=over

=item $success 

1 on success, 0 otherwise.
=back

B<Examples:>

	SIM_setReturnValues('pd_TestStart', [-15]);
	SIM_setReturnValues('pd_GetCANHWList', [ 0, ['12345'], [1] ]);
	SIM_setReturnValues('pd_GetSWversion', 'AB12');
	SIM_setReturnValues('pd_ReadName', [ 0, [32] ], ['E_MaxSquibs_SXC']);  
	SIM_setReturnValues( 'VEC_trace_flxr_store_signals_file' , [undef] );

	SIM_setReturnValues('pd_ReadName', 
	                   sub{
	                       my $iteration = shift;
	                       my $label = shift;
	                       if($label eq 'rb_tim_EcuOnTimeDataEe_dfst.POnCounter_u32' ){
	                           if($iteration <= 2){
	                               return [ 0, [0, 0, 0, 2] ];
	                           }
	                           else{
	                               return[ 0, [0, 0, 0, 3] ];
	                           }
	                       }
	                       else{
	                           return;
	                       }
	                   }, 
	                   [1 .. 3]);

    In the previous example for repeated calls to pd_ReadName('rb_tim_EcuOnTimeDataEe_dfst.POnCounter_u32') 
    the return value will be 2 times (0, [0, 0, 0, 2]) and then once (0, [0, 0, 0, 3]) 
    and then the default value for pd_ReadName. But no other calls to pd_ReadName are allowed in between.

	SIM_setReturnValues('pd_ReadName', 
	                   sub{
	                       my $iteration = shift;
	                       my $label = shift;
	                       if($label eq 'rb_tim_EcuOnTimeDataEe_dfst.POnCounter_u32' ){
	                           $LIFT_simulation::helper++;
	                           if($LIFT_simulation::helper <= 2){
	                               return [ 0, [0, 0, 0, 2] ];
	                           }
	                           else{
	                               return[ 0, [0, 0, 0, 3] ];
	                           }
	                       }
	                       else{
	                           return;
	                       }
	                   }, 
	                   [1 .. 99]);
    In the previous example for repeated calls to pd_ReadName('rb_tim_EcuOnTimeDataEe_dfst.POnCounter_u32') 
    the return value will be 2 times (0, [0, 0, 0, 2]) and then (0, [0, 0, 0, 3]) 
    and also other calls to pd_ReadName are allowed in between.

=cut

sub SIM_setReturnValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SIM_setReturnValues( $functionName , $returnValues_mix [, $functionArgs_aref, $repetitions] )', @args );

    my $functionName      = shift @args;
    my $returnValues      = shift @args;
    my $functionArgs_aref = shift @args;
    my $repetitions       = shift @args // 1;

    #IF $returnValues is an array reference?
    if ( ref($returnValues) eq "ARRAY" ) {
    	#IF-YES-START

        # use argument $returnValues_aref to set value in $returnValuesTemp_href
        #IF $functionArgs_aref is defined?
        if ( defined $functionArgs_aref ) {
        	#IF-YES-START
            #STEP serialize $functionArgs_aref to a string
            my $dump = Data::Dumper->new($functionArgs_aref);
            Reset_Dumper($dump);
            my $functionArgsString = $dump->Dump;    # create a string out of the given arguments
            #STEP store $returnValues and $repetitions in 'args' section of $returnValuesTemp_href
            $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString}{value} = dclone($returnValues);
            $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString}{repetitions} = $repetitions;
        	#IF-YES-END
        }
        else {
        	#IF-NO-START
            #STEP store $returnValues and $repetitions in 'default' section of $returnValuesTemp_href
            $returnValuesTemp_href->{$functionName}{'default'}{value} = dclone($returnValues);
            $returnValuesTemp_href->{$functionName}{'default'}{repetitions} = $repetitions;
        	#IF-NO-END
        }
    	#IF-YES-END
    }
    	#IF-NO-START
    #IF $returnValues is a code reference?
    elsif ( ref($returnValues) eq "CODE" ) {
    	#IF-YES-START
        #STEP throw error and return if $functionArgs_aref is not defined
        if ( not defined $functionArgs_aref ) {
            S_set_error( "Second argument is a code reference, but no value is defined for \$functionArgs_aref", 114 );
            return 0;
        }
        #STEP store $returnValues and $functionArgs_aref in 'code_*' sections of $returnValuesTemp_href
        $returnValuesTemp_href->{$functionName}{'code_ref'}              = $returnValues;
        $returnValuesTemp_href->{$functionName}{'code_iteration_vector'} = $functionArgs_aref;
    	#IF-YES-END
    }
    	#IF-NO-START
    #IF $returnValues is a scalar?
    elsif ( not ref($returnValues) ) {
    	#IF-YES-START

        #STEP throw error and return if $returnValuesTable_href is not defined
        if ( not defined $returnValuesTable_href->{$functionName}{$returnValues} ) {
            S_set_error( "For first argument = $functionName no value is defined in \$returnValuesTable_href for the label $returnValues", 114 );
            return 0;
        }
        #STEP store $returnValuesTable_href as value and $repetitions in the 'default' section of $returnValuesTemp_href
        $returnValuesTemp_href->{$functionName}{'default'}{value} = $returnValuesTable_href->{$functionName}{$returnValues};
        $returnValuesTemp_href->{$functionName}{'default'}{repetitions} = $repetitions;
    	#IF-YES-END
    }
    else {
    	#IF-NO-START
        #STEP throw an error and return
        S_set_error( "For first argument = $functionName the second argument is neither scalar nor an array reference", 114 );
        return 0;
    	#IF-NO-END
    }
    	#IF-NO-END
    	#IF-NO-END

    #END return 1
    return 1;
}

=head2 SIM_returnValues

    return_values = SIM_returnValues( $functionName , $defaultValues , $functionArgs_aref );
    
This function is used to redefine the low level function $functionName for simulation mode.
If prior to this function the function SIM_setReturnValues is called for this $functionName then the return value is defined by SIM_setReturnValues.
Otherwise: If $defaultValues is 'default' then the return value is taken from $returnValuesTable_href->{$functionName}{'default'} (if defined) or it is 1.
If $defaultValues is not 'default' then the function will return $defaultValues (either as scalar or as array reference, whatever is given).
The arguments ($functionArgs_aref) that are passed to the function $functionName need to be passed as third argument (array reference) to enable defining 
different return values based on the given arguments (see SIM_setReturnValues).

B<Arguments:>

=over

=item $functionName 

Name of the low level function for which values shall be returned.

=item $defaultValues

If $defaultValues is 'default' then it is used as key in $returnValuesTable_href.
Otherwise $defaultValues (scalar or array reference) are the return values for function $functionName, except SIM_setReturnValues is in use.

=item $functionArgs_aref

Arguments that are passed to $functionName.

=back

B<Return Value:>

=over

=item return_values 

If $functionName returns only one value then return_values is a scalar.
If $functionName returns more than one value then return_values is a list.

=back

B<Examples:>

	@returnValues = SIM_returnValues($function, 'default', \@_);
	$errortext = SIM_returnValues('pd_GetErrorString', "Error $status", \@_);

=cut

sub SIM_returnValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SIM_returnValues( $functionName , $defaultValues_mix , $functionArgs_aref )', @args );

    my $functionName      = shift @args;
    my $defaultValues     = shift @args;
    my $functionArgs_aref = shift @args;

    #IF $defaultValues is 'default'?
    if ( $defaultValues eq 'default' ) {
    	#IF-YES-START
        #STEP $defaultValues is set to $returnValuesTable_href->{$functionName}{'default'} if that exists, otherwise to 1
        if ( defined $returnValuesTable_href->{$functionName}{'default'} ) {
            $defaultValues = $returnValuesTable_href->{$functionName}{'default'};
        }
        else {
            $defaultValues = [1];
        }
    	#IF-YES-END
    }
    	#IF-NO-START
    	#IF-NO-END

    #STEP make $defaultValues an array reference if not already
    if ( not ref($defaultValues) ) {
        $defaultValues = [$defaultValues];
    }

    #STEP serialize $functionArgs_aref to a string
    my $dump = Data::Dumper->new($functionArgs_aref);
    Reset_Dumper($dump);
    my $functionArgsString = $dump->Dump;    # create a string out of the given arguments

    my $returnValues_aref;
    #IF a value exists in 'args' section of $returnValuesTemp_href for function name and arguments?
    if ( defined $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString}{value} and defined $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString}{repetitions}) {
    	#IF-YES-START
        #STEP take return values from 'args' section of $returnValuesTemp_href for function name and arguments
        $returnValues_aref = $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString}{value};
        #STEP decrease repetition counter for function name and arguments
        $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString}{repetitions}--;
        #STEP delete stored return value if repetition counter is 0
        if( $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString}{repetitions} == 0 ) {
            $returnValuesTemp_href->{$functionName}{'args'}{$functionArgsString} = undef;
        }
    	#IF-YES-END
    }
    	#IF-NO-START
    #IF 'code_*' sections exist in $returnValuesTemp_href?
    elsif ( defined $returnValuesTemp_href->{$functionName}{'code_ref'} and defined $returnValuesTemp_href->{$functionName}{'code_iteration_vector'} ) {
    	#IF-YES-START
        my $code_ref              = $returnValuesTemp_href->{$functionName}{'code_ref'};
        my $iteration_vector_aref = $returnValuesTemp_href->{$functionName}{'code_iteration_vector'};
        #STEP get iteration value from code iteration vector
        my $iteration_value       = shift @$iteration_vector_aref;
        #STEP calculate return values from code reference using iteration value and arguments
        if ( defined $iteration_value ) {
            no strict 'refs';
            $returnValues_aref = &$code_ref( $iteration_value, @$functionArgs_aref );
        }

        #STEP remove code reference and iteration vector if iteration vector is empty
        if ( @$iteration_vector_aref == 0 ) {
            delete $returnValuesTemp_href->{$functionName}{'code_ref'};
            delete $returnValuesTemp_href->{$functionName}{'code_iteration_vector'};
        }
    	#IF-YES-END
    }
    else {
    	#IF-NO-START
        #STEP take return values from 'default' section of $returnValuesTemp_href for function name
        $returnValues_aref = $returnValuesTemp_href->{$functionName}{'default'}{value};
        #STEP decrease repetition counter for function name
        $returnValuesTemp_href->{$functionName}{'default'}{repetitions}--;
        #STEP delete stored return value if repetition counter is 0
        if( $returnValuesTemp_href->{$functionName}{'default'}{repetitions} == 0 ) {
            $returnValuesTemp_href->{$functionName}{'default'} = undef;
        }
    	#IF-NO-END
    }
    	#IF-NO-END

    # if there were values defined in $returnValuesTemp_href->{$functionName} take those as return values, otherwise take them from $defaultValues_aref
    my @values;
    #IF return values are defined?
    if ( defined $returnValues_aref ) {
    	#IF-YES-START
        #STEP use them to make a list of return values
        @values = @{$returnValues_aref};
        S_w2log( 5, "$functionName returns @values (set by SIM_setReturnValues) in simulation mode\n" );
    	#IF-YES-END
    }
    else {
    	#IF-NO-START
        #STEP use $defaultValues to make a list of return values
        @values = @{$defaultValues};
        S_w2log( 5, "$functionName returns @values (default value) in simulation mode\n" );
    	#IF-NO-END
    }

    # return actual values either as scalar (if only one value) or as list
    #IF list of return values has only 1 element?
    if ( @values <= 1 ) {
    	#IF-YES-START
    	#STEP return that element
        return $values[0];
    	#IF-YES-END
    }
    else {
    	#IF-NO-START
    	#STEP return the list
        return @values;
    	#IF-NO-END
    }
    #END END
}

=head2 SIM_addToValuesTable

    SIM_addToValuesTable( $localValuesTable_href );
    
Append hash $localValuesTable_href to $returnValuesTable_href.
This is used to collect all default return values from each low level module.

=cut

sub SIM_addToValuesTable {
    my $localValuesTable_href = shift;

    #STEP append hash $localValuesTable_href to $returnValuesTable_href
    %{$returnValuesTable_href} = ( %{$returnValuesTable_href}, %{$localValuesTable_href} ); # see perl cookbook chapter 5.10

    #END END
    return 1;
}

=head2 Reset_Dumper

    Reset_Dumper( $dumper_obj );
    
reset $dumper_obj to default values

=cut

sub Reset_Dumper {
    my $dumper_obj = shift;

    $dumper_obj->Indent(0);
    $dumper_obj->Purity(0);
    $dumper_obj->Pad("");
    $dumper_obj->Varname('VAR');
    $dumper_obj->Useqq(0);
    $dumper_obj->Terse(0);
    $dumper_obj->Freezer("");
    $dumper_obj->Toaster("");
    $dumper_obj->Deepcopy(0);
    $dumper_obj->Quotekeys(1);
    $dumper_obj->Bless("bless");
    $dumper_obj->Maxdepth(0);
    $dumper_obj->Pair(' => ');
    $dumper_obj->Useperl(0);
    $dumper_obj->Sortkeys(0);
    $dumper_obj->Deparse(0);

    #$dumper_obj->Sparseseen(0);

    return 1;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Christian Prosch, E<lt>Christian.Prosch@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut
 
