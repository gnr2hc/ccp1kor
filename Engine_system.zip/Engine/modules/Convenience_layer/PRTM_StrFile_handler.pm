package PRTM_StrFile_handler;

use strict;
use warnings;

use DBI;
use File::Spec;

sub new {

	# Useful literature for developers:
	# http://perldoc.perl.org/perlobj.html
	my $class   = shift;
	my $strfile = shift;

	# Check if str file argument was set
	unless ( defined $strfile ) {
		S_set_error("[StrFile.pm] Str file parameter missing");
		return 0;
	}

	# Check if str files extension is ".str" and if it is existing
	$strfile = File::Spec->rel2abs($strfile);
	unless ( $strfile =~ /\.str$/ ) {
		S_set_error("[StrFile.pm] $strfile does not end with .str");
		return 0;
	}
	unless ( -f $strfile ) {
		S_set_error("[StrFile.pm] $strfile does not exist");
		return 0;
	}

	# Load in-memory db
	my $dbh;
	unless ( $dbh = DBI->connect('dbi:SQLite:dbname=:memory:') ) {
		S_set_error("Couldn't connect to DB");
	}

	#my $dbh = DBI->connect( "dbi:SQLite:database.sqlite");
	$dbh->{AutoCommit} = 0;

	# Create tables
	$dbh->do("CREATE TABLE EnumDef (enumtypename TEXT NOT NULL, enumvaluename TEXT NOT NULL, value INTEGER NOT NULL, PRIMARY KEY (enumtypename, enumvaluename))");
	$dbh->do("CREATE TABLE Array (name TEXT NOT NULL, address INTEGER NOT NULL, location TEXT NOT NULL, modifier TEXT, type TEXT NOT NULL, typeName TEXT NOT NULL, size INTEGER NOT NULL)");
	$dbh->commit();

	# Open str file for reading
	my $str_fh;
	unless ( open $str_fh, $strfile ) {
		S_set_error("Couldn't open $strfile");
		return;
	}

	# Read in all lines
	my %data;
	my $currentFileIndex = 0;

	# Search for start of first file info
	my $line;
	my $found = 0;
	do {
		$line = <$str_fh>;

		if ( $line =~ /^0:\s*(\(\"(\w+)\",\"(\w+)\"\).*)/ ) {

			# First file info found
			$data{$currentFileIndex}{'data'}{0} = $0;
			$data{$currentFileIndex}{'name'}    = $1;
			$data{$currentFileIndex}{'path'}    = $2;
			$found                              = 1;
		}
		elsif ( $line =~ /^0:/ ) {
			$data{$currentFileIndex}{'data'}{0} = $0;
			$data{$currentFileIndex}{'name'}    = "";
			$data{$currentFileIndex}{'path'}    = "";
			$found                              = 1;
		}
	} until ( $found == 1 );

	# Process all following lines till EOF
	while ( $line = <$str_fh> ) {

		# Check if start of a file was found
		if ( $line =~ /^0:\s*(\(\"(\w+)\",\"(\w+)\"\).*)/ ) {
			$currentFileIndex++;    # Increment current file index
			$data{$currentFileIndex}{'data'}{0} = $0;
			$data{$currentFileIndex}{'name'}    = $1;
			$data{$currentFileIndex}{'path'}    = $2;
		}
		elsif ( $line =~ /^0:/ ) {
			$currentFileIndex++;    # Increment current file index
			$data{$currentFileIndex}{'data'}{0} = $0;
			$data{$currentFileIndex}{'name'}    = "";
			$data{$currentFileIndex}{'path'}    = "";
		}
		elsif ( $line =~ /^(\d+):\s*(.*)/ ) {
			$data{$currentFileIndex}{'data'}{$1} = $2;
		}
	}

	unless ( close $str_fh ) {
		S_set_error("Couldn't close $strfile");
		return;
	}

	# Go through file data and extract the information
	foreach my $fileInfo ( keys %data ) {
		foreach my $lineNo ( sort keys %{ $data{$fileInfo}{'data'} } ) {
			if ( $data{$fileInfo}{'data'}{$lineNo} =~ /\"(\w+)\" Typedef.*Enum1 ref = (\d+)/ ) {
				my $enumtypename   = $1;
				my $enumvalrefline = $2;

				# Get the last line of the enum value definition
				# It can be retrieved out of the line at $enumvalrefline
				# which contains a reference to the next information entry
				# Subtract 2 to get the last line which needs to be processed
				# This will exclude the closing "tag" of the enum value definition
				$data{$fileInfo}{'data'}{$enumvalrefline} =~ /ind:\((\d+)/;
				my $lastLineDefinition = $1 - 2;

				# Loop over the definition lines and extract the information
				for ( my $i = $enumvalrefline + 1 ; $i <= $lastLineDefinition ; $i++ ) {
					if ( $data{$fileInfo}{'data'}{$i} =~ /\"(\w+)\" enumval (\d+)/ ) {
						$dbh->do("INSERT OR IGNORE INTO EnumDef VALUES ('$enumtypename', '$1', $2)");
					}
				}
				$dbh->commit;
			}
			elsif ( $data{$fileInfo}{'data'}{$lineNo} =~ /\"(\w+)\" (0x[0-9a-fA-F]{8}),\s+(\w+)\s+(\w+) Array of (.*)C (.*) \[0..(\d+)\]/ ) {
				my $name     = $1;
				my $address  = hex($2);
				my $info     = $3;
				my $location = $4;
				my $modifier = $5;
				my $typeName = $6;
				my $size     = $7 + 1;

				$dbh->do("INSERT OR IGNORE INTO Array VALUES('$name', $address, '$location', '$modifier', 'simple', '$typeName', $size)");
				$dbh->commit;
			}
		}
	}

	# Setup the object
	my $self = bless {
		strfile => $strfile,
		dbh     => $dbh
	}, $class;

	return $self;
}

sub getEnumTypeNames {
	my $self = shift;
	my @enumTypeNames;

	my $sth = $self->{dbh}->prepare("SELECT DISTINCT enumtypename FROM EnumDef");
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;
	foreach my $rowref (@$resultref) {
		push @enumTypeNames, @$rowref[0];
	}

	return @enumTypeNames;
}

sub getEnumValueNames {
	my $self         = shift;
	my $enumTypeName = shift;
	my @enumValueNames;

	my $sth = $self->{dbh}->prepare("SELECT enumvaluename FROM EnumDef WHERE enumtypename = '$enumTypeName' ORDER BY value ASC");
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;
	foreach my $rowref (@$resultref) {
		push @enumValueNames, @$rowref[0];
	}

	return @enumValueNames;
}

sub getEnumValueNamesAndValue {
	my $self         = shift;
	my $enumTypeName = shift;
	my %result;

	my $sth = $self->{dbh}->prepare("SELECT enumvaluename, value FROM EnumDef WHERE enumtypename = '$enumTypeName'");
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;
	foreach my $rowref (@$resultref) {
		$result{ @$rowref[0] } = @$rowref[1];
	}

	return %result;
}

sub getValueAndEnumValueNames {
	my $self         = shift;
	my $enumTypeName = shift;
	my %result;

	my $sth = $self->{dbh}->prepare("SELECT value, enumvaluename FROM EnumDef WHERE enumtypename = '$enumTypeName'");
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;
	foreach my $rowref (@$resultref) {
		$result{ @$rowref[0] } = @$rowref[1];
	}

	return %result;
}

sub getEnumValue {
	my $self          = shift;
	my $enumValueName = shift;
	my $enumTypeName  = shift;

	my $sth;
	if ( defined $enumTypeName ) {
		$sth = $self->{dbh}->prepare("SELECT value FROM EnumDef WHERE enumvaluename = '$enumValueName' AND enumtypename = '$enumTypeName'");
	}
	else {
		$sth = $self->{dbh}->prepare("SELECT value FROM EnumDef WHERE enumvaluename = '$enumValueName'");
	}
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;
	if ( scalar @$resultref == 1 ) {
		return @$resultref[0]->[0];
	}
	else {
		return;
	}
}

sub getNumberEnumValues {
	my $self         = shift;
	my $enumTypeName = shift;

	my $sth = $self->{dbh}->prepare("SELECT * FROM EnumDef WHERE enumtypename = '$enumTypeName'");
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;

	return scalar @$resultref;
}

sub getEnumValueName {
	my $self         = shift;
	my $enumTypeName = shift;
	my $value        = shift;

	my $sth = $self->{dbh}->prepare("SELECT enumvaluename FROM EnumDef WHERE enumtypename = '$enumTypeName' AND value = $value");
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;
	if ( scalar @$resultref == 1 ) {
		return @$resultref[0]->[0];
	}
	else {
		return;
	}
}

sub getArraySize {
	my $self  = shift;
	my $array = shift;

	my $sth = $self->{dbh}->prepare("SELECT size FROM Array WHERE name = '$array'");
	$sth->execute();
	my $resultref = $sth->fetchall_arrayref;
	if ( scalar @$resultref == 1 ) {
		return @$resultref[0]->[0];
	}
	else {
		return;
	}
}

sub DESTROY {
	my $self = shift;

	$self->{dbh}->disconnect;
	return 1;
}
1;
__END__
