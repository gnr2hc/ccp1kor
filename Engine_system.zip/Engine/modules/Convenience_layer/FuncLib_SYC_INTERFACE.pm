# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package FuncLib_SYC_INTERFACE;

use strict;
use warnings;
use LIFT_general;
use Import::Into;

our ( $VERSION, $HEADER );

use Exporter;
our @ISA    = qw(Exporter);
our @EXPORT = qw(
  SYC_get_FiringModeDetails
  SYC_get_ConfigId_Content
  SYC_get_ConfigId_List
  SYC_getLogLevel
  SYC_getSycType
  SYC_get_ScipPM_Content
  SYC_get_ScipPM_List
  SYC_Init
);

=head2 import
    
There is no builtin import function. It is just an ordinary method (subroutine) defined (or inherited) by modules that wish to export names to another module.
The use function calls the import method for the package used. See also use, perlmod, and Exporter. When using this builtin import Exporter's import method is
no longer called, but Exporter has a special method, 'export_to_level' which is used in situations where you can't directly call Exporter's import method.

http://perldoc.perl.org/Exporter.html

=cut

sub import {
    my @args   = @_;
    my $caller = caller;

    # mandatory TNT modules (always needed!)
    eval { require FuncLib_TNT_SYC_INTERFACE; 1; };

    if ($@) {
        S_set_error( "Error occured while loading FuncLib 'FuncLib_TNT_SYC_INTERFACE' : $@", 112 );
    }
    else {
        'FuncLib_TNT_SYC_INTERFACE'->import::into($caller);
    }

    # optional CustLib module (will only be imported if *.pm file exists)
    eval { require FuncLib_CustLib_SYC_INTERFACE; 1; };

    if ( $@ =~ /Can't locate FuncLib_CustLib_SYC_INTERFACE.pm in \@INC.*/ ) {
        S_w2log( 3, "FuncLib_SYC_INTERFACE: no 'FuncLib_CustLib_SYC_INTERFACE' found. This is OK if there are no CustLib specific functions for SYC Interface.\n" );
    }
    elsif ($@) {
        S_set_error( "Error occured while loading FuncLib 'FuncLib_CustLib_SYC_INTERFACE' : $@", 112 );
    }
    else {
        'FuncLib_CustLib_SYC_INTERFACE'->import::into($caller);
    }

    # optional CustLib module (will only be imported if *.pm file exists)
    eval { require FuncLib_Project_SYC_INTERFACE; 1; };

    if ( $@ =~ /Can't locate FuncLib_Project_SYC_INTERFACE.pm in \@INC.*/ ) {
        S_w2log( 3, "FuncLib_SYC_INTERFACE: no 'FuncLib_Project_SYC_INTERFACE' found. This is OK if there are no project specific functions for SYC Interface.\n" );
    }
    elsif ($@) {
        S_set_error( "Error occured while loading FuncLib 'FuncLib_Project_SYC_INTERFACE' : $@", 112 );
    }
    else {
        'FuncLib_Project_SYC_INTERFACE'->import::into($caller);
    }

    FuncLib_SYC_INTERFACE->export_to_level( 1, @args );
}

=head1 NAME

FuncLib_SYC_INTERFACE 

=head1 SYNOPSIS

    use ;

    SYC_Init();
    
    ( $result , $content ) = SYC_get_ConfigId_Content( 'Monitored', ['Switch','BLFD']);
    ( $result , $content ) = SYC_get_ConfigId_Content( 'SwitchType', ['BLFD']);
    
	LIFT_config:

		our $SYC_export_xml_file 	= './config/SYC_Exp.xml';
		our $SYC_variant_name 		= 'V_AB12Base_2015A';

=head1 DESCRIPTION

Basic Interface for accessing SYC after this was exported from DOORS.

This basic interface can be used directly by testcases, but normaly it is used in "FuncLib_TNT_SYC_INTERFACE" etc.   

=cut

my $syc_type                              = 0;
my $syc_interface_initialised             = 0;
my $syc_interface_successfull_initialised = 0;
my $fire_modes                            = {
    "mode I" => {
        "current_A"   => 1.85,
        "duration_ms" => 0.7,
    },
    "mode II" => {
        "current_A"   => 1.75,
        "duration_ms" => 0.5,
    },
    "mode III" => {
        "current_A"   => 1.2,
        "duration_ms" => 2.0,
    },
    "mode V" => {
        "current_A"   => 1.75,
        "duration_ms" => 0.7,
    },
    "mode V backup" => {
        "current_A"   => 1.2,
        "duration_ms" => 2.0,
    },
    "mode VI" => {
        "current_A"   => 1.5,
        "duration_ms" => 1.5,
    },
};
my $configIds_href;
my $syc_export->{Content} = {};

=head1 Function 'base'

=head2 SYC_Init

    SYC_Init();
    
Initialize SYC interface. It will read the SYC export xml given in "$LIFT_config::SYC_export_xml_file"
and parse it for the given variant "$LIFT_config::SYC_variant_name".

returns 0 and sets error
	-if the given file does not exist   
	-if there is an error during import of the XML
			(basically this means that the XML export is not according XML spec
			and there is a problem with the DOORS Syc Export.)
	-if the given Variant is not in the SYC Export XML
	-if ConfigID is not defined at all

Calling this function is not required, but it can be done in the IC to move the warnings from testcase to IC.

=cut

sub SYC_Init {
    if ($syc_interface_initialised) {
        S_w2log( 3, "SYC interface already initialised.\n" );
        return $syc_interface_successfull_initialised;
    }

    $syc_interface_initialised = 1;

    if ( defined $LIFT_config::SYC_export_xml_file and defined $LIFT_config::SYC_variant_name ) {
        S_w2log( 2, "SYC interface will use DOORS XML export!\n" );
        $syc_type = "doorsXML";
    }
    elsif ( defined $LIFT_config::SYC_export_pm_file ) {
        S_w2log( 2, "SYC interface will use *.pm exported from SCIP!\n" );
        $syc_type = "scipPM";
    }
    else {
        S_set_error( "SYC_Init: SYC_export_pm_file or ('SYC_export_xml_file' and 'SYC_variant_name') are not defined in Project Config.", 1 );
        return 0;
    }

    $syc_interface_successfull_initialised = FuncLib_SYC_INTERFACE_doorsXML::SYC_Init() if $syc_type eq "doorsXML";
    $syc_interface_successfull_initialised = FuncLib_SYC_INTERFACE_scipPM::SYC_Init()   if $syc_type eq "scipPM";

    return $syc_interface_successfull_initialised;
}

=head2 SYC_get_ConfigId_Content

( $result , $content ) = SYC_get_ConfigId_Content($ConfigID [, $filter4ancestors_aref ] );

returns the content of a ConfigID. The given strings in 'filter4ancestors_aref' are used as a filter on the parent headlines,
so that only ConfigIDs are considered, which are in a subchapter which fulfils the parent filter.

 $ConfigID	   = Contains the exact name of the ConfigID (currently no placeholders / RegEx are allowed).
				 This is a mandatory parameter.
 $filter4ancestors_aref = 
 				 This contains key(s) (Headlines of SYC), whose content shall be returned for current Variant.
				 An ConfigID is considered if all key(s) are valid for his ancestors headlines.
                 It's also possible to use regular expressions in these key(s).

returns 0 and sets error
	-if more than one Element in SYC Export fulfils the filters from 'filter4ancestors_aref'  
	-if no ConfigID in SYC Export fulfils the filters from 'filter4ancestors_aref'
	-if the given ConfigID is not defined at all

 e.g.
    ( $result , $content ) = SYC_get_ConfigId_Content( 'Monitored', ['Switch','BLFD']);
    ( $result , $content ) = SYC_get_ConfigId_Content( 'SwitchType', ['BLFD']);
	( $result , $content ) = SYC_get_ConfigId_Content( 'SignalName1', ['.* System Warning Lamp .*'] );

=cut

sub SYC_get_ConfigId_Content {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_get_ConfigId_Content( $ConfigId [ , $parents_aref] )', @args );

    my $configId     = shift @args;
    my $parents_aref = shift @args;
    my $loglevel     = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_get_ConfigId_Content called for configId '$configId' ...\n" );

    if ( $syc_type eq "scipPM" ) {
        S_set_error("Function 'SYC_get_ConfigId_Content' not supported for SCIP based SYC.");
        return 0;
    }

    unless ($syc_interface_initialised) {
        S_w2log( $loglevel, "SYC interface not yet initialised.\n" );
        SYC_Init();
    }

    unless ($syc_interface_successfull_initialised) {
        return 0;
    }

    my @found_elements;
    my $key_in_syc_export;

    unless ( exists $configIds_href->{$configId} ) {
        S_set_error( "ConfigID '$configId' is not availeable in SYC Export XML '$LIFT_config::SYC_export_xml_file'", 20 );
        return 0;
    }

    foreach my $element ( 1 .. $configIds_href->{$configId}{Nbr} ) {
        my %temp_parents;
        my %tmp_hash;

        @$parents_aref = grep { defined } @$parents_aref;
        @temp_parents{@$parents_aref} = undef;

        @tmp_hash{ values %{ $configIds_href->{$configId}{$element}{ConfigId_Collection} } } = undef;
        @tmp_hash{ values %{ $configIds_href->{$configId}{$element}{headline_Collection} } } = undef;

        foreach my $d ( 0 .. $#{$parents_aref} ) {
            if ( grep { /^\s*$$parents_aref[$d]\s*$/ } keys %tmp_hash ) {
                delete $temp_parents{ $$parents_aref[$d] };
            }
        }

        push @found_elements, $element unless %temp_parents;
    }

    if ( @found_elements == 0 ) {
        S_set_error( "ConfigID '$configId' is not availeable in SYC Export XML with given list of ancestors", 20 );
        return 0;
    }
    elsif ( @found_elements > 1 ) {
        S_set_error( "ConfigID '$configId' is found more than once in SYC Export XML with given list of ancestors", 20 );
        return 0;
    }

    # set curent_position to the beginning of the syc_export
    my $curent_position = $syc_export->{Content};

    # update curent_position to give ($object_level - 1) headline
    foreach my $key_in_syc_export ( sort keys %{ $configIds_href->{$configId}{ $found_elements[0] }{headline_Collection} } ) {
        $key_in_syc_export = $configIds_href->{$configId}{ $found_elements[0] }{headline_Collection}{$key_in_syc_export};
        $curent_position = $curent_position->{$key_in_syc_export} if defined $key_in_syc_export;
    }

    S_w2log( $loglevel, "SYC_get_ConfigId_Content returns '$curent_position->{Content}'...\n" );

    return ( 1, $curent_position->{Content} );
}

sub SYC_get_ScipPM_Content {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_get_ScipPM_Content( $params_aref )', @args );

    if ( $syc_type eq "doorsXML" ) {
        S_set_error("Function 'SYC_get_ScipPM_Content' not supported for Doors based SYC.");
        return 0;
    }

    my $params_aref = shift @args;

    unshift( @$params_aref, 'Content' );

    my $content = S_get_contents_of_hash_NOERROR( $params_aref, $syc_export );
    return 0 unless defined $content;

    return ( 1, $content );
}

sub SYC_get_ScipPM_List {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_get_ScipPM_List( $params_aref )', @args );

    if ( $syc_type eq "doorsXML" ) {
        S_set_error("Function 'SYC_get_ScipPM_Content' not supported for Doors based SYC.");
        return 0;
    }

    my $params_aref = shift @args;

    unshift( @$params_aref, 'Content' );

    my $content = S_get_contents_of_hash_NOERROR( $params_aref, $syc_export );
    return 0 unless defined $content;

    my $elementsList_aref;
    @$elementsList_aref = keys %{$content};

    return ( 1, $elementsList_aref );
}

=head2 SYC_get_ConfigId_List

( $result , $elementsList_aref ) = SYC_get_ConfigId_List($ConfigID [ , $filter4ancestors_aref]);


=cut

sub SYC_get_ConfigId_List {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_get_ConfigId_List( $ConfigId [ , $parents_aref] )', @args );

    my $configId     = shift @args;
    my $parents_aref = shift @args;
    my $loglevel     = SYC_getLogLevel();
    my ( $result, $elementsList_aref );

    S_w2log( $loglevel, "SYC_get_ConfigId_List called for configId '$configId' ...\n" );

    if ( $syc_type eq "scipPM" ) {
        S_set_error("Function 'SYC_get_ConfigId_List' not supported for SCIP based SYC.");
        return 0;
    }

    unless ($syc_interface_initialised) {
        S_w2log( $loglevel, "SYC interface not yet initialised.\n" );
        SYC_Init();
    }

    unless ($syc_interface_successfull_initialised) {
        return 0;
    }

    my @found_elements;
    my $key_in_syc_export;

    unless ( exists $configIds_href->{$configId} ) {
        S_set_error( "ConfigID '$configId' is not availeable in SYC Export XML '$LIFT_config::SYC_export_xml_file'", 20 );
        return 0;
    }

    foreach my $element ( 1 .. $configIds_href->{$configId}{Nbr} ) {
        my %temp_parents;
        my %tmp_hash;

        @$parents_aref = grep { defined } @$parents_aref;
        @temp_parents{@$parents_aref} = undef;

        @tmp_hash{ values %{ $configIds_href->{$configId}{$element}{ConfigId_Collection} } } = undef;
        @tmp_hash{ values %{ $configIds_href->{$configId}{$element}{headline_Collection} } } = undef;

        foreach my $d ( 0 .. $#{$parents_aref} ) {
            if ( grep { /$$parents_aref[$d]/ } keys %tmp_hash ) {
                delete $temp_parents{ $$parents_aref[$d] };
            }
        }

        push @found_elements, $element unless %temp_parents;
    }

    if ( @found_elements == 0 ) {
        S_set_error( "ConfigID '$configId' is not availeable in SYC Export XML with given list of ancestors", 20 );
        return 0;
    }

    foreach my $element (@found_elements) {

        # get a list of all keys in headline_Collection
        my @keylist       = sort keys %{ $configIds_href->{$configId}{$element}{headline_Collection} };
        my $last_headline = $configIds_href->{$configId}{$element}{headline_Collection}{ $keylist[-1] };
        my $last_configId = $configIds_href->{$configId}{$element}{ConfigId_Collection}{ $keylist[-1] };
        $last_headline = $configIds_href->{$configId}{$element}{headline_Collection}{ $keylist[-2] } if ( $last_headline eq $last_configId );
        push @$elementsList_aref, $last_headline;
    }

    my $joined_content_text = join( ", ", @$elementsList_aref );
    S_w2log( $loglevel, "SYC_get_ConfigId_List returns $joined_content_text...\n" );

    return ( 1, $elementsList_aref );
}

=head2 SYC_get_FiringModeDetails

    ( $result , $detail_for_return ) = SYC_get_FiringModeDetails( $firing_mode , "current_A"|"duration_ms" , ['backup'] );

returns status 1 and "current_A" or "duration_ms" for given firing_mode if firing_mode is valid
returns status 0 if firing_mode is not valid

if optional parameter 'backup' is given 
    returns status 1 and "current_A" or "duration_ms" for given firing_mode if firing_mode is valid and backup mode is defined
    returns status 0 if firing_mode is not valid
    
=cut

sub SYC_get_FiringModeDetails {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_get_FiringModeDetails($firing_mode, $detail, [$backup])', @args );

    my $firing_mode = shift @args;
    my $detail      = shift @args;
    my $backup      = shift @args;
    my $detail_for_return;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_get_FiringModeDetails called...\n" );

    unless ( exists $fire_modes->{$firing_mode} ) {
        S_set_error( "Configured firing mode '$firing_mode' is not a supported mode ('mode I'|'mode II'|'mode III'|'mode V'|'mode VI')", 20 );
        return 0;
    }

    unless ( $detail eq "current_A" or $detail eq "duration_ms" ) {
        S_set_error( "requested detail '$detail' is not as expected ('current_A'|'duration_ms')", 20 );
        return 0;
    }

    if ( defined $backup ) {
        unless ( exists $fire_modes->{ $firing_mode . " backup" } ) {
            return 0;
        }

        $detail_for_return = $fire_modes->{ $firing_mode . " backup" }{$detail};

        S_w2log( $loglevel, "SYC_get_FiringModeDetails returns '$detail' == '$detail_for_return'...\n" );

        return ( 1, $detail_for_return );
    }

    $detail_for_return = $fire_modes->{$firing_mode}{$detail};

    S_w2log( $loglevel, "SYC_get_FiringModeDetails returns '$detail' == '$detail_for_return'...\n" );

    return ( 1, $detail_for_return );
}

=head2 SYC_getSycType

    $logLevel = SYC_getSycType( );

Returns the tpye of SYC which is used (scipPM | doorsXML).

=cut

sub SYC_getSycType {
    my $loglevel = SYC_getLogLevel();

    unless ($syc_interface_initialised) {
        S_w2log( $loglevel, "SYC interface not yet initialised.\n" );
        SYC_Init();
    }

    return $syc_type;
}

=head2 SYC_getLogLevel

    $logLevel = SYC_getLogLevel( );

Returns the log Level to be used.

returns 5 if the function was called from "FuncLib_***_SYC_INTERFACE"
else returns 3

=cut

sub SYC_getLogLevel {
    my @package_list = ( "FuncLib_TNT_SYC_INTERFACE", "FuncLib_CustLib_SYC_INTERFACE", "FuncLib_Project_SYC_INTERFACE" );

    my ( $package, $filename, $line ) = caller(1);

    if ( grep { /$package/ } @package_list ) {
        return 5;
    }
    return 3;
}

############################################################################################################
#
#
# package FuncLib_SYC_INTERFACE_doorsXML
#
#
############################################################################################################

package FuncLib_SYC_INTERFACE_doorsXML;

use strict;
use warnings;
use LIFT_general;
use XML::Simple;

=head2 SYC_Init

    SYC_Init( );

=cut

sub SYC_Init {

    unless ( -f $LIFT_config::SYC_export_xml_file ) {
        S_set_error( "SYC_Init: SYC_export_xml_file '$LIFT_config::SYC_export_xml_file' does not exist.", 1 );
        return 0;
    }

    my $xml = XML::Simple->new();
    my $data = eval { $xml->XMLin($LIFT_config::SYC_export_xml_file) };

    if ($@) {
        S_set_error( "SYC_Init: Error while importing SYC_export_xml_file '$LIFT_config::SYC_export_xml_file'", 20 );
        return 0;
    }

    my $syc_Variant_Name = Convert_SYC_variant_name($LIFT_config::SYC_variant_name);

    my ( $syc_hash, @headline_collection, @configId_collection, $found_variant_column, $previous_item_text, $previous_object_level, $previous_item_heading, $previous_object_identifier );

    # put all objects in new hash with hierarchy as key
    foreach my $object ( @{ $data->{module}{object} } ) {
        $syc_hash->{ $object->{object_hierarchy} } = $object;

        #check that SYC_Variant_Name is defined in one of the elements
        $found_variant_column++ if exists $object->{$syc_Variant_Name};
    }

    # error if variant was not defined in one of the objects
    unless ($found_variant_column) {
        S_set_error( "Variant '$LIFT_config::SYC_variant_name' or converted '$syc_Variant_Name' are not availeable in SYC Export XML '$LIFT_config::SYC_export_xml_file'", 20 );
        return 0;
    }

    # go through SYC in order of doors hierarchy
    foreach my $syc_column ( sort keys %$syc_hash ) {

        my $object_level      = $syc_hash->{$syc_column}{object_level};
        my $object_identifier = $syc_hash->{$syc_column}{object_identifier};
        my $object_type       = $syc_hash->{$syc_column}{Type};
        my $object_hierarchy  = $syc_hash->{$syc_column}{object_hierarchy};

        my $config_id = $syc_hash->{$syc_column}{ConfigID};
        $config_id = undef if ref($config_id);
        $config_id =~ s/\s//g if defined $config_id;

        my $item_heading = $syc_hash->{$syc_column}{Object_Heading};
        $item_heading = undef if ref($item_heading);

        my $item_text = $syc_hash->{$syc_column}{Object_Text};
        $item_text = undef if ref($item_text);

        my $object_content = $syc_hash->{$syc_column}{$syc_Variant_Name};
        $object_content = undef if ref($object_content);

        my $nbr = 1;

        # set curent_position to the beginning of the syc_export
        my $curent_position = $syc_export->{Content};

        next unless defined $object_type;
        next unless ( $object_type eq "Heading" or $object_type eq "Configuration" );

        splice( @headline_collection, $object_level ) if @headline_collection >= $object_level;
        splice( @configId_collection, $object_level ) if @configId_collection >= $object_level;

        # update curent_position to give ($object_level - 1) headline
        foreach my $hierarchy_level ( 1 .. $object_level - 1 ) {
            if ( defined $headline_collection[$hierarchy_level] ) {
                $curent_position = $curent_position->{ $headline_collection[$hierarchy_level] };
            }
            elsif ( $object_level > $previous_object_level and $previous_object_level == $hierarchy_level and not defined $previous_item_heading ) {
                $headline_collection[$hierarchy_level]                     = $previous_item_text;
                $curent_position->{$previous_item_text}{object_identifier} = $previous_object_identifier;
                $curent_position                                           = $curent_position->{$previous_item_text};
            }
        }

        if ( $object_type eq "Heading" ) {
            $headline_collection[$object_level] = $item_heading;
            $configId_collection[$object_level] = $config_id;
            S_set_error( "Headline '$item_heading' defined more than once in the current scope / chapter.", 0 ) if exists $curent_position->{$item_heading};
            $curent_position->{$item_heading}{object_identifier} = $object_identifier;
            $curent_position = $curent_position->{$item_heading};
            next if not defined $config_id;
        }
        elsif ( $object_type eq "Configuration" ) {
            next if not defined $config_id;
            $object_content =~ s/\n/ /g if defined $object_content;    # maybe not necessary
            S_set_error( "ConfigID '$config_id' [SYC_Id '$object_identifier'] defined more than once in the current scope / subchapter.", 0 ) if exists $curent_position->{$config_id};
            $curent_position->{$config_id}{Content}           = $object_content;
            $curent_position->{$config_id}{object_identifier} = $object_identifier;
        }

        $nbr = $configIds_href->{$config_id}{Nbr} + 1 if ( exists $configIds_href->{$config_id} );
        foreach my $curent_obj_lvl ( 1 .. $object_level ) {
            $configIds_href->{$config_id}{$nbr}{headline_Collection}{$curent_obj_lvl} = $headline_collection[$curent_obj_lvl];
            $configIds_href->{$config_id}{$nbr}{ConfigId_Collection}{$curent_obj_lvl} = $configId_collection[$curent_obj_lvl] if defined $configId_collection[$curent_obj_lvl];
        }
        if ( $object_type eq "Configuration" ) {
            $configIds_href->{$config_id}{$nbr}{headline_Collection}{$object_level} = $config_id;
            $configIds_href->{$config_id}{$nbr}{ConfigId_Collection}{$object_level} = $config_id;
        }
        $configIds_href->{$config_id}{Nbr} = $nbr;

        $previous_item_text         = $item_text;
        $previous_item_heading      = $item_heading;
        $previous_object_level      = $object_level;
        $previous_object_identifier = $object_identifier;
    }

    # get general information of SYC export xml
    #	<syc_module_name>AB12_SYC_Core_Asset_Project</syc_module_name>
    #	<syc_module_path>_Core Assets AB12_System_SYC</syc_module_path>
    #	<syc_module_type>SYC</syc_module_type>
    #	<syc_baseline>No baselined data</syc_baseline>
    #	<syc_last_modified>24 April 2015</syc_last_modified>
    #	<syc_description>AB12 System Core Asset Project only !!!</syc_description>

    $syc_export->{information}{syc_module_name}  = $data->{syc_module_name};
    $syc_export->{information}{syc_module_path}  = $data->{syc_module_path};
    $syc_export->{information}{syc_module_type}  = $data->{syc_module_type};
    $syc_export->{information}{syc_baseline}     = $data->{syc_baseline};
    $syc_export->{information}{syc_description}  = $data->{syc_description};
    $syc_export->{information}{xml_export_path}  = $LIFT_config::SYC_export_xml_file;
    $syc_export->{information}{used_syc_variant} = $LIFT_config::SYC_variant_name;

    my $syc_export4dump = $syc_export;
    $syc_export4dump->{configId_Index} = $configIds_href;

    S_w2log( 1, "SYC interface succesfully initialized!\n" );
    foreach my $info_key ( keys %{ $syc_export4dump->{information} } ) {
        S_w2log( 3, "$info_key: '$syc_export4dump->{information}{$info_key}'\n" );
    }

    S_dump2pmFile(
        "VariableToDump" => $syc_export4dump,
        "VariableName"   => "SYC_Export",
        "PackageName"    => "SYC_Export__" . $syc_Variant_Name,
    );

    return 1;

}

=head2 Convert_SYC_variant_name

    Convert_SYC_variant_name( $variant_name );

Convert the configured variant name as it is done by DOORS SYC export,
so that the user is able to use the same text as it is used in DOORS
(which may not be compatible with XML format).

Called by SYC_Init.

=cut

sub Convert_SYC_variant_name {
    my $variant_name = shift;

    # replace all german umlauts
    $variant_name =~ s/�/ae/g;
    $variant_name =~ s/�/oe/g;
    $variant_name =~ s/�/�e;/g;
    $variant_name =~ s/�/Ae;/g;
    $variant_name =~ s/�/Oe/g;
    $variant_name =~ s/�/Ue/g;
    $variant_name =~ s/�/ss/g;
    $variant_name =~ s/&/and/g;
    $variant_name =~ s/ /_/g;

    $variant_name =~ tr/A-Za-z_0-9\-\./_/c;
    $variant_name =~ s/_+/_/g;

    return $variant_name;
}

############################################################################################################
#
#
# package FuncLib_SYC_INTERFACE_scipPM
#
#
############################################################################################################

package FuncLib_SYC_INTERFACE_scipPM;

use strict;
use warnings;
use LIFT_general;

=head2 SYC_Init

    SYC_Init( );

=cut

sub SYC_Init {
    unless ( -f $LIFT_config::SYC_export_pm_file ) {
        S_set_error( "SYC_Init: SYC_export_pm_file '$LIFT_config::SYC_export_pm_file' does not exist.", 1 );
        return 0;
    }

    require $LIFT_config::SYC_export_pm_file;
    $syc_export->{Content} = $SystemTest_SYC_Export::SYC_Export;

    if ( defined $LIFT_config::CUST_SYC_export_pm_file ) {
        unless ( -f $LIFT_config::CUST_SYC_export_pm_file ) {
            S_set_error( "SYC_Init: CUST_SYC_export_pm_file '$LIFT_config::CUST_SYC_export_pm_file' does not exist.", 1 );
            return 0;
        }

        require $LIFT_config::CUST_SYC_export_pm_file;

        #    $syc_export->{Content} = $SystemTest_SYC_Export::SYC_Export;
        foreach my $section ( keys %{$CUST_SystemTest_SYC_Export::SYC_Export} ) {
            $syc_export->{Content}{$section} = $CUST_SystemTest_SYC_Export::SYC_Export->{$section};
        }
    }

    return 1;
}

1;
__END__

