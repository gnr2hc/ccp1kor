# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM::StorageManager;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################


use strict;
use warnings;

use LIFT_CSM::Container;
use LIFT_CSM::LocalWorkingArea;
use LIFT_CSM::StorageArea;

use LIFT_general;
use File::Path qw(make_path);
use File::Spec;

#######################################################################################################

my $oneTrueSelf;                        # -> getInstance

#
# initial settings
#
my $csm_disable = 0;                    # -> _readProjectDefaults_CSM

my $SM_local_working_area_obj;          # -> new(); is the object
my $SM_storage_area_obj;                # -> new(); is the object

#######################################################################################################

#-------------------------------------------------------------------------------
sub getInstance {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $options_href = shift;
    
    S_w2log( 5, " StorageManager -> getInstance()\n" , 'grey' );
    
    unless( defined $oneTrueSelf ) {
        # calling Constructor just first time
        $oneTrueSelf = $self->new( $options_href );    
    } else {
        # all following calls the existing object will be returned        
        S_w2log( 5, " StorageManager is running\n" , 'grey' );
    }
    
    return $oneTrueSelf;
}


#-------------------------------------------------------------------------------
sub isDisabled {
#-------------------------------------------------------------------------------
    my $self = shift;
    return 0 unless( $csm_disable );
    
    S_w2log( 5, " CSM is disabled in ProjectDefaults_CSM" , 'grey' );
    return 1; 
}

###############################################################################

=head2 new

	$SM_obj = LIFT_CSM::StorageManager -> new();

I<B<Description:>> 	instances a new object of StorageManager -> object

I<B<Arguments:>> 
					mandatory: n/a
					optional:  n/a

I<B<Return:>> return the blessed (instanced) StorageManager object
              nothing if 
                    reading ProjectDefaults_CSM is failing
                    instancing LocalWorkingArea is failing 
                    instancing StorageArea is failing 

I<B<Verdict:>> none

I<B<Error:>> no own error

=cut

#-------------------------------------------------------------------------------
sub new {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $class = ref($type) || $type;
    my $self = {};
    my $options_href = shift;
    
    my ( $DEFAULT_LWA_path , $DEFAULT_SA_path , $USED_LWA_path , $USED_SA_path );

    my $options_text = join ( " : " , keys ( %{$options_href} ) );
    
    if ( $options_text =~ /\w+/ ) {
        S_w2log( 1, " StorageManager -> new() with option(s) : $options_text\n" , 'grey' );
    } else {
        S_w2log( 1, " StorageManager -> new() \n" , 'grey' );
    }

    #
    #   pre-settting for DEFAULT paths for LocalWorkingArea and StorageArea
    # 
    unless( defined $main::REPORT_PATH ) 
        { S_set_error( "Crazy .. No REPORT_PATH in main defined ... ?? " ); return }

    $DEFAULT_SA_path = $main::REPORT_PATH;
    
    if( $main::REPORT_PATH =~ /^D:/i ) {      # report-path is on D:-drive             
        $DEFAULT_LWA_path = "D:\\temp\\csm_default_lwa\\";
    }
    else {                                    # report-path is on C:-drive o somewhere else            
        $DEFAULT_LWA_path = "C:\\temp\\csm_default_lwa\\";        
    }
        
    #
    #   reading ProjectDefaults of CSM
    # 
    my $project_defaults_csm;
    unless( $project_defaults_csm = _readProjectDefaults_CSM() ) {
        S_w2rep( " Could not read ProjectDefaults_CSM\n" , 'red' );
    }
    
    #
    #   determine the USED_LWA_path depending from 
    #      - optional function arguments $options_href
    #      - REPORT_PATH
    #      - ProjectDefaultsCSM 
    # 
    if( defined $options_href->{ 'LocalWorkingArea_Path' }  ) {
        if( $options_href->{ 'LocalWorkingArea_Path' } =~ /DEFAULT/i  ) {
            $USED_LWA_path = $DEFAULT_LWA_path;
        } else {
            $USED_LWA_path = $options_href->{ 'LocalWorkingArea_Path' };
        }    
    }
    elsif( defined $project_defaults_csm->{ 'LocalWorkingArea_Path' } ) {     
        $USED_LWA_path = File::Spec->rel2abs( $project_defaults_csm->{ 'LocalWorkingArea_Path' } );   
    }
    else {
        $USED_LWA_path = $DEFAULT_LWA_path;
    }

    #
    #   creating the LocalWorkingArea in the Path determined before
    # 
    my $SM_LocalWorkingArea_obj;
    unless( $SM_LocalWorkingArea_obj = LIFT_CSM::LocalWorkingArea->new( $USED_LWA_path ) ) {
        S_w2log( 2, " Could not initialize LocalWorkingArea in folder '$USED_LWA_path'\n" , 'red' );
        return;          # return w/o creating the SM object
    }
    $SM_local_working_area_obj = $SM_LocalWorkingArea_obj;
    
    #
    #   determine the $USED_SA_path depending from 
    #      - optional function arguments $options_href
    #      - REPORT_PATH
    #      - ProjectDefaultsCSM 
    # 
    if( defined $options_href->{ 'StorageArea_Path' }  ) {
        if( $options_href->{ 'StorageArea_Path' } =~ /DEFAULT/i  ) {
            $USED_SA_path = $DEFAULT_SA_path;
        } else {
            $USED_SA_path = $options_href->{ 'StorageArea_Path' };
        }    
    }
    elsif( defined $project_defaults_csm->{ 'StorageArea_Path' } ) {     
        $USED_SA_path = $project_defaults_csm->{ 'StorageArea_Path' };
    }
    else {
        $USED_SA_path = $DEFAULT_SA_path;
    }
              
    #
    #   creating/setting the StorageArea in the Path determined before
    # 
    my $SM_StorageArea_obj;
    unless( $SM_StorageArea_obj = LIFT_CSM::StorageArea->new( $USED_SA_path ) ) {
        S_w2log( 2, " Could not initialize StorageArea\n" , 'red' );
        return;          # return w/o creating the SM object
    }
    $SM_storage_area_obj = $SM_StorageArea_obj;
              
    #
    # BLESS HERE 
    #
    bless $self, $class;     # create the object from the class
    
    return $self;            # return the object reference
}

#-------------------------------------------------------------------------------
sub createContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $container_identifier = shift;
    
    S_w2log( 5, " StorageManager -> createContainer( )\n" , 'grey' );

    my $local_working_area_obj = _get_lwa_obj() || return;
    my $lwa_path = $local_working_area_obj->getPath( ) || return;
    
    my $cont_obj = LIFT_CSM::Container -> new( $container_identifier ) || return;
    my $cont_id = $cont_obj -> getIdentifier( ) || return;
    $cont_obj -> setRootPath( "$lwa_path/$cont_id/" ) || return;
        
    $local_working_area_obj -> addContainer( $cont_id , $cont_obj , 'Created' );
    
    return $cont_id;

}

#-------------------------------------------------------------------------------
sub addContainerHeader {
#-------------------------------------------------------------------------------

    my $self = shift;
    my $cont_id = shift;
    my $ProjectData_href = shift;

    unless( defined $ProjectData_href ) {
        S_set_error( "Missing parameter ProjectData" ); return;
    }

    unless( ref $ProjectData_href eq 'HASH' ) {
        S_set_error( "Given parameter ProjectData must be HASH reference" ); return;
    }
        
    S_w2log( 5, " StorageManager -> addContainerHeader()\n" , 'grey' );

    my $local_working_area_obj = _get_lwa_obj() || return;
    
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;
    
    $cont_obj->addHeader( $ProjectData_href ) || return;
            
    return 1;
}



#-------------------------------------------------------------------------------
sub addKeywords {
#-------------------------------------------------------------------------------

    my $self = shift;
    my $cont_id = shift;
    my $keywords_aref = shift;

    unless( defined $keywords_aref ) {
        S_set_error( "Missing parameter keywords" ); return;
    }

    unless( ref $keywords_aref eq 'ARRAY' ) {
        S_set_error( "Given parameter keywords must be array reference" ); return;
    }
        
    S_w2log( 5, " StorageManager -> addKeywords()\n" , 'grey' );

    my $local_working_area_obj = _get_lwa_obj() || return;
    
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;
    
    foreach my $kw ( @$keywords_aref ) {
        $cont_obj -> addKeyword( $kw ) || return;
    }
        
    return 1;
}

###############################################################################

=head2 addUserfile

	LIFT_CSM::StorageManager -> addUserfile( $cont_id ,  $filename_long [ , $userfile_description ]  );

    See docu of CSM_add_userfile()

=cut

#-------------------------------------------------------------------------------
sub addUserfile {
#-------------------------------------------------------------------------------

    my $self = shift;
    my $cont_id = shift;
    my $filename_long = shift;
    my $userfile_description = shift;

    unless( defined $filename_long ) {
        S_set_error( "Missing parameter 'filename_long'" ); return;
    }
            
    S_w2log( 5, " StorageManager -> addUserfile()\n" , 'grey' );

    my $local_working_area_obj = _get_lwa_obj() || return;
    
    my $cont_status = $local_working_area_obj -> getContainerStatus( $cont_id ) || return;
    
    unless( $cont_status =~ /Created|Filled/i ) {
        S_set_error( "Container must have state Created|Filled .... (ID '$cont_id')" ); 
        return;
    }
    
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;
    
	if ($main::opt_offline) { S_w2log( 5 , " StorageManager -> addUserfile: OFFLINE MODE - no execution of addUserFile \n" ) }
    else {
        $cont_obj -> addUserFile( $filename_long , $userfile_description ) || return;
    }

    $local_working_area_obj -> updateContainerStatus( $cont_id , 'Filled' ) || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub addDump_EDR {
#-------------------------------------------------------------------------------

    my $self = shift;

#         RecordNumber => 1 ,
#         CrashLabel => "MySelfDefinedCrash",
#         StructureInfo => undef ,
#         RawDataGeneric => [ @EDR_record_Gen ] ,
#         RawDataOEM => [ @EDR_record_OEM ] ,    

#
#  to be changed / moved 
#
#     S_checkFunctionArguments ( 'addDump_EDR ( $cont_id , $RecordNumber , $CrashLabel , $StructureInfo_aref ,  $RawDataGeneric_aref , $RawDataOEM_aref   )', @_ ) || return;

    my $cont_id = shift;
    my $EDR_DATA_href = shift;
    my $EDR_storage_identifier = shift;
    
    S_w2log( 5, " StorageManager -> addDump_EDR()\n" , 'grey' );

    my $local_working_area_obj = _get_lwa_obj() || return;
    
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;
#     my $lwa_path = $local_working_area_obj->getPath( ) || return;
    
	if ($main::opt_offline) { S_w2log( 5 , " StorageManager -> addDump_EDR: OFFLINE MODE - no execution of addDump_EDR \n" ) }
    else {
        $cont_obj -> addDump_EDR( $EDR_DATA_href , $EDR_storage_identifier ) || return;
    }
    
    $local_working_area_obj -> updateContainerStatus( $cont_id , 'Filled' ) || return;
        
    return 1;
}



#-------------------------------------------------------------------------------
sub packContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $cont_id = shift;
    
    S_w2log( 5, " StorageManager -> packContainer()\n" , 'grey' );

    unless( defined $cont_id ) {        
        S_set_error( "missing parameter 'container_Id'" ); return
    }

    my $local_working_area_obj = _get_lwa_obj() || return;
    
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;
    my $lwa_path = $local_working_area_obj -> getPath( ) || return;
    
    my $storage_fname = $cont_obj -> pack_to_zip( $lwa_path ) || return;

    $local_working_area_obj -> updateContainerStatus( $cont_id , 'Packed'  ) || return;
    $local_working_area_obj -> updateContainerStorageFilename( $cont_id , $storage_fname ) || return;

#     $local_working_area_obj -> existingContainer( $cont_id ) || return;   # just for debugging
#     $local_working_area_obj -> getContainerStatus( $cont_id ) || return;  # just for debugging
        
    return 1;

}


#-------------------------------------------------------------------------------
sub archiveContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $cont_id = shift;
    my $archive_mode = shift;
    
    $archive_mode = 'KeepLocalContainer' unless defined $archive_mode;
    
    unless( $archive_mode eq 'KeepLocalData' or $archive_mode eq 'NoLocalData' ) {
        S_set_error( "option mode must be 'KeepLocalData' or 'NoLocalData'" ); return;
    }
    
    S_w2log( 5, " StorageManager -> archiveContainer()\n" , 'grey' );

    unless( defined $cont_id ) {        
        S_set_error( "missing parameter 'container_Id'" ); return
    }

    my $local_working_area_obj  = _get_lwa_obj() || return;

    # check container status 'Packed'
    my $cont_status = $local_working_area_obj -> getContainerStatus( $cont_id ) || return;    
    unless( $cont_status eq 'Packed' ) {
        S_set_error( "Container '$cont_id' must be in status 'Packed' before archieving (is '$cont_status')" ); return;
    }

    my $storage_area_obj = _get_storage_area_obj() || return;
    my $storage_area_path = $storage_area_obj -> getPath( ) || return;

    # get Container for move operation
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;
        
    my $storage_fname;
    
    if( $archive_mode eq 'NoLocalData') {
        #
        # MOVE OPERATION HERE
        #
        $storage_fname = $cont_obj -> moveContainer_To_StorageAreaFileSystem( $storage_area_path ) || return;        
        
        #
        # un-register in Local Working Area
        #
        $local_working_area_obj -> unregisterContainer( $cont_id ) || return;
        
    }    
    else {    # 'KeepLocalContainer'
        #
        # COPY OPERATION HERE
        #
        $storage_fname = $cont_obj -> copyContainer_To_StorageAreaFileSystem( $storage_area_path ) || return;        
        #
        # un-register in Local Working Area
        #
        $local_working_area_obj -> updateContainerStatus( $cont_id ,  'Archived' ) || return;
        
    }    

    #
    # register in Storage Area
    #
    $storage_area_obj -> registerContainer( $cont_id , $cont_obj , 'Archived' , $storage_fname ) || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub clearContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $cont_id = shift;
    
    S_w2log( 5, " StorageManager -> clearContainer\n" , 'grey' );

    unless( defined $cont_id ) {        
        S_set_error( "missing parameter 'container_Id'" ); return
    }

    my $local_working_area_obj = _get_lwa_obj() || return;    
    my $cont_status = $local_working_area_obj -> getContainerStatus( $cont_id ) || return;
    
    if( $cont_status =~ /Opened/ ) {
        $local_working_area_obj -> clearContainer( $cont_id ) || return;
        $local_working_area_obj -> updateContainerStatus( $cont_id , 'Initialized' ) || return;
    }

    if( $cont_status =~ /Created|Filled/ ) {
        $local_working_area_obj -> clearContainer( $cont_id ) || return;
        $local_working_area_obj -> unregisterContainer( $cont_id ) || return;
    }

    if( $cont_status =~ /Packed|Archived|Initialized/ ) {
        S_w2log( 4, " StorageManager -> clearContainer : Nothing to do\n" , 'grey' );
    }
        
    return 1;
}

#-------------------------------------------------------------------------------
sub searchLocalContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $query_href = shift;
    
    my ( 
        @returned_ContIds_LWA ,
        $nbr_Cont_LWA ,
        );

    S_w2log( 5, " StorageManager -> searchLocalContainer\n" , 'grey' );

    unless( defined $query_href ) {        
        S_set_error( "missing parameter 'query_href'" , 110 ); return;
    }

    my $local_working_area_obj = _get_lwa_obj() || return;

    ( $nbr_Cont_LWA , @returned_ContIds_LWA ) = $local_working_area_obj -> query( $query_href );
    return unless defined $nbr_Cont_LWA;   # ERROR occured

    S_w2log( 4, " StorageManager -> searchLocalContainer : $nbr_Cont_LWA Container found\n" , 'grey' );
    
    return ( $nbr_Cont_LWA , @returned_ContIds_LWA );
}


#
#  this get operation ensure Container to become ready for work
#
#  if existing in local working area 
#    -> can be used again
#  if not existing 
#    -> request of transport from StorageArea is handled 
#
#-------------------------------------------------------------------------------
sub getContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $cont_id = shift;
    
    S_w2log( 5, " StorageManager -> getContainer( $cont_id )\n" , 'grey' );

    unless( defined $cont_id ) {        
        S_set_error( "missing parameter" , 110 ); return;
    }

    my $local_working_area_obj = _get_lwa_obj() || return;
    my $lwa_path = $local_working_area_obj -> getPath( ) || return;
    
    my( $cont_obj );
    
    unless( $local_working_area_obj -> existingContainer( $cont_id )  ) {
        S_w2log( 4, " StorageManager -> getContainer : Requested Container is not Local Working Area -> transport from StorageArea\n" , 'grey' );
        #
        # search in StorageArea and copy to LWA
        #
        
        my $storage_area_obj = _get_storage_area_obj() || return;
        my $storage_area_path = $storage_area_obj -> getPath( ) || return;
        
        # get Container for move operation
        $cont_obj = $storage_area_obj -> getContainer( $cont_id ) || return;
            
        #
        # COPY OPERATION HERE
        #
        my $storage_fname_local = $cont_obj -> copyContainer_To_LocalWorkingArea( $lwa_path ) || return;        
    
        #
        # register to Local Working Area
        #
        $local_working_area_obj -> addContainer( $cont_id , $cont_obj , 'Archived' ) || return;

    }
    else {
        #
        #  Container is (now) existing in LWA
        #
        $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) ;
        S_w2log( 4, " StorageManager -> getContainer : Requested Container is already Local Working Area \n" , 'grey' );
    }
        
    my $cont_status = $local_working_area_obj -> getContainerStatus( $cont_id ) || return;
    
    unless( $cont_status =~ /Packed|Archived|Initialized|Opened/  ) {
        S_set_error( "Container must be in status 'Packed' or 'Archived' or 'Initialized' or 'Opened' when getContainer() is requested" ); return;
    }

    if( $cont_status =~ /Initialized/  ) {
        S_w2log( 4, " StorageManager -> getContainer : Container is just initialized - objects must be re-opened \n" , 'grey' );
        $cont_obj -> reinitializeObjectsFromHeader() || return;
        
        #
        # creating container root path for further operations
        #
        my $LWA_path = $local_working_area_obj -> getPath() || return;
        my $container_rootpath = $LWA_path."/".$cont_id; 
        
        if( -d $container_rootpath ) {
            S_w2log( 3 , " Container RootPath '$container_rootpath' exist already \n" , 'grey' );
        }
     
        $cont_obj -> setRootPath( $container_rootpath ) || return; 
        
        $cont_status = $local_working_area_obj -> updateContainerStatus( $cont_id , 'Opened' ) || return;
    }

        
    my $header = $cont_obj -> getHeader( ) || return;
    
    S_w2log( 4, " StorageManager -> getContainer : Returning requested container header (Status '$cont_status') \n" , 'grey' );

    return $header;
}

#
# looking only in LWA
#
#-------------------------------------------------------------------------------
sub getContainerWorkingPath {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $cont_id = shift;
    
    S_w2log( 5, " StorageManager -> getContainerWorkingPath\n" , 'grey' );

    unless( defined $cont_id ) {        
        S_set_error( "missing parameter 'container_Id'" ); return
    }

    my $local_working_area_obj = _get_lwa_obj() || return;

    unless( $local_working_area_obj -> existingContainer( $cont_id )  ) {
        S_w2log( 3 , " StorageManager -> getContainerWorkingPath : Container doesnt exist in local working area \n" , 'grey' );
        return
    }   
    
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;

    my $cont_root_path = $cont_obj -> getRootPath(); 
    
    unless( $cont_root_path ) {
        S_w2log( 3 , " StorageManager -> getContainerWorkingPath : RootPath of Container in local working area is not set \n" , 'grey' );
        return
    }   
        
    return $cont_root_path;
}


###############################################################################

=head2 getUserfile

	$userfile_obj = LIFT_CSM::StorageManager -> getUserfile( $cont_id ,  $userfile_id , $options_href );

        $cont_id      : Container ID (e.g. given from CSM_create_container)
        $userfile_id  : filename with complete path of file to be geted to container
        $options_href :
            { extract => 0 }   # => no extraction of userfile from container
            { extract => 1 }   # => [DEFAULT] extraction of userfile from container
            
        NOTE: Container must be in local working area and in state 
            - Opened    : use getContainer   <-- typical use case
            - Packed    : use packContainer 
            - Archived  : use archiveContainer 

=cut

#-------------------------------------------------------------------------------
sub getUserfile {
#-------------------------------------------------------------------------------

    my $self = shift;
    my $cont_id = shift;
    my $userfile_id = shift;
    my $options_href = shift;

    #
    # prepare default setting : Userfile will be extracted physically
    #
    $options_href -> { extract } = 1 unless defined $options_href -> { extract };

    unless( defined $userfile_id ) {
        S_set_error( "Missing parameter 'userfile_id'" ); return;
    }
            
    S_w2log( 4, " StorageManager -> getUserfile( $cont_id , $userfile_id, $options_href )\n" , 'grey' );

    my $local_working_area_obj = _get_lwa_obj() || return;
    
    my $cont_status = $local_working_area_obj -> getContainerStatus( $cont_id ) || return;
    
    unless( $cont_status =~ /Packed|Archived|Opened/i ) {
        S_set_error( "Container must have state Packed|Archived|Opened (ID '$cont_id') (current state : $cont_status)" ); 
        return;
    }
    
    my $cont_obj = $local_working_area_obj -> getContainer( $cont_id ) || return;
    
    my $userfile_obj = $cont_obj -> getUserFile( $userfile_id ) || return;

    #
    # return directly when userfile is physically existing
    #
    if( $userfile_obj -> getFileStatus_physical( ) ) {
        S_w2log( 3, " StorageManager -> getUserfile : returning object of userfile_id '$userfile_id' => userfile is available\n" , 'grey' );    
        return $userfile_obj;
    }

    S_w2log( 5, " StorageManager -> getUserfile : userfile not available\n" , 'grey' );    

    #
    # in case user has set option { extract => 0 }
    # Userfile object will be returned without extraction of physical userfile 
    #
    unless( $options_href -> { extract } ) 
    {
        S_w2log( 4, " StorageManager -> getUserfile : returning object of userfile_id '$userfile_id' => userfile is not extracted !\n" , 'grey' );    
        return $userfile_obj;
    }
    
    my $userfile_name = $userfile_obj -> getFilename( ) || return;
    my $LWA_path = $local_working_area_obj -> getPath() || return;
    my $target_path = $LWA_path . "/" . $cont_id;
    unless( -d $target_path ) {
        unless ( make_path($target_path) ) {
            S_set_error("Could not create path '$target_path' : $!"); return;
        }    
    } 
    
    my $extracted_fname_long = $cont_obj -> extractFile( $userfile_name , $target_path ) || return;
    
    $userfile_obj -> setFilename_long( $extracted_fname_long ) || return;
    
    S_w2log( 4, " StorageManager -> getUserfile : returning object of userfile_id '$userfile_id' \n" , 'grey' );
    S_w2log( 4, " StorageManager -> getUserfile : Userfile is extracted to :  '$extracted_fname_long' \n" , 'grey' );

    return $userfile_obj;
}



#-------------------------------------------------------------------------------
sub _get_lwa_obj {
#-------------------------------------------------------------------------------
    unless( $SM_local_working_area_obj ) {
        S_set_error( "Local Working Area not established" ); return;        
    }   
    return $SM_local_working_area_obj;
}

#-------------------------------------------------------------------------------
sub _get_storage_area_obj {
#-------------------------------------------------------------------------------
    unless( $SM_storage_area_obj ) {
        S_set_error( "Storage Area not established" ); return;        
    }   
    return $SM_storage_area_obj;
}


#-------------------------------------------------------------------------------
sub _readProjectDefaults_CSM {
#-------------------------------------------------------------------------------
    
    my (
        $project_defaults_csm,
    );

    S_w2log( 5, " _readProjectDefaults_CSM()\n" , 'grey' );
    
    #
    # Reading ProjectDefaults 'CSM'
    #   
    unless(  S_check_contents_of_hash( [ 'CSM' ] ) eq 'HASH' ) {
#         S_set_error( "Could not read ProjectDefaults_CSM" ); return;        
        S_set_warning( " StorageManager -> _readProjectDefaults_CSM : Could not read ProjectDefaults_CSM - LIFT_PROJECT::Defaults -> {'CSM'} is not configured" ); 
        return;
    }   
    
     $project_defaults_csm = S_get_contents_of_hash( [ 'CSM' ] );
     
    #
    # read 'disable_CSM'
    #
    if( $project_defaults_csm->{ 'disable_CSM' } ) {
        S_set_warning( "CSM is disabled in ProjectDefaults_CSM" ); 
        $csm_disable = 1;
        return 1;        
    }

    #
    #  read 'LocalWorkingArea_Path'
    #
    unless( $project_defaults_csm->{ 'LocalWorkingArea_Path' } ) {
#         S_set_error( "Could not read 'LocalWorkingArea_Path' in ProjectDefaults_CSM" ); return;        
        S_w2rep( " StorageManager -> _readProjectDefaults_CSM : LIFT_PROJECT::Defaults -> {'CSM'}{ 'LocalWorkingArea_Path' } is not configured" ); 
    }

    #
    #  read 'StorageArea_Path'
    #
    unless( $project_defaults_csm->{ 'StorageArea_Path' } ) {
#         S_set_error( "Could not read 'StorageArea_Path' in ProjectDefaults_CSM" ); return;        
        S_w2rep( " StorageManager -> _readProjectDefaults_CSM : LIFT_PROJECT::Defaults -> {'CSM'}{ 'LocalWorkingArea_Path' } is not configured" ); 
    }
    
    return $project_defaults_csm; 
}


#-------------------------------------------------------------------------------
sub DESTROY {
#-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;
    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    # now do your own thing before or after
    #print "Destroying $self \n";
}

1;

__END__
