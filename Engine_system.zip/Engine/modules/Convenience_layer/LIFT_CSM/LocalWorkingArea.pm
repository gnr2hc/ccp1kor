# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM::LocalWorkingArea;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################


use strict;
use warnings;

use LIFT_general;

use File::Path qw(make_path remove_tree);
use File::Basename;


#######################################################################################################


#-------------------------------------------------------------------------------
sub new {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $local_working_area_path = shift;
    
    my $class = ref($type) || $type;
    my $self = {};

    S_w2log( 5, " LocalWorkingArea::new()\n" , 'grey' );
    
    $self->{ 'Path' } = undef;
    
    #
    #  $self->{ 'ContainerListing' } = {
    #      <ContainerIdentifier_1> => {
    #         'State' => Created|Filled|Stored
    #         'Object' => <Container>
    #      <ContainerIdentifier_2> => {
    #         'State' => Created|Filled|Stored
    #         'Object' => <Container>
    #
    $self->{ 'ContainerListing' } = undef;
    
    # 
    # States in Container Listing
    #   - NotListed : this state is not stored / just returned from getContainerStatus
    #   - Created
    #   - Filled
    #   - Packed
    #   - Initialized
    #   - Opened
    #   - Unpacked
    
    
    unless( defined $local_working_area_path ) {
        S_set_error( " <LocalWorkingArea_Path> expected as parameter for Constructor" ); return;
    }

    #
    # BLESS HERE 
    #
    bless $self, $class;


    $self -> setupLocalWorkingArea( $local_working_area_path ) || return;   
    
               
    return $self;
}


#-------------------------------------------------------------------------------
sub setupLocalWorkingArea {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $local_working_area_path = shift;

    S_w2log( 3, " Setup LocalWorkingArea \n" , 'grey' );

    unless( -d $local_working_area_path ) {
        unless( make_path( $local_working_area_path ) ) {
            S_set_error( "Could not create path '$local_working_area_path'" ); return;                                                                   
        }       
        S_w2log( 3 , " '$local_working_area_path' created \n" , 'grey' );
    }

    S_w2log( 3 , " Set LocalWorkingArea Path = '$local_working_area_path' \n" , 'grey' );
    $self->{ 'Path' } = $local_working_area_path;

    return 1; 
}
 
#-------------------------------------------------------------------------------
sub getPath {
#-------------------------------------------------------------------------------
    my $self = shift;

    my $path;

    unless( $path = $self -> { 'Path' } )  {
        S_set_error( " LocalWorkingArea -> 'Path' is not set " ); return;
    }

    S_w2log( 4, " Get LocalWorkingArea -> 'Path' = '$path' \n" , 'grey' );    

    return $path; 
}

#-------------------------------------------------------------------------------
sub existingContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    
    unless( defined $Id ) { 
        S_set_error( "missing parameter 'Id'", 110 ); return 
    }
    
    if( $self->{ 'ContainerListing' }->{ $Id } ) {
        S_w2log( 5, " LocalWorkingArea -> existingContainer : TRUE ('$Id') \n" , 'grey' );    
        return 1 ;
    }
    else {
        S_w2log( 5, " LocalWorkingArea -> existingContainer : FALSE ('$Id')\n" , 'grey' );    
        return 0 ;
    }

}

#-------------------------------------------------------------------------------
sub initializeContainerFromFile {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    my $storage_fname_local = shift;

#     S_w2log( 5, " LocalWorkingArea -> initializeContainerFromFile : $Id \n" , 'grey' );
    
    my $cont_obj = LIFT_CSM::Container -> new( $Id ) || return;
    
    $cont_obj -> setStorageFileName( $storage_fname_local ) || return;    
        
    $cont_obj -> initializeHeaderFromFile( $storage_fname_local ) || return;    
        
    return $cont_obj;
}



#-------------------------------------------------------------------------------
sub addContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    my $obj = shift;
    my $state = shift;
    my $storage_fname_local = shift;      # OPTIONAL
    
    unless( defined $state ) { 
        S_set_error("missing parameter"); return }
    
    unless( grep( /^$state$/ , qw( Created Filled Packed Archived Initialized ) ) ) {
         S_set_error("wrong parameter : given State : $state -> must be Created | Filled | Packed | Archived | Initialized "); return }
        
    $self->{ 'ContainerListing' }->{ $Id }{ 'Object' } = $obj;
    $self->{ 'ContainerListing' }->{ $Id }{ 'State' } = $state;
    $self->{ 'ContainerListing' }->{ $Id }{ 'StorageFileName' } = $storage_fname_local if defined $storage_fname_local;

#     S_w2log( 5, " LocalWorkingArea -> addContainer : $Id => $state \n" , 'grey' );
    
    return 1;
}

#-------------------------------------------------------------------------------
sub unregisterContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    
    unless( defined $Id ) { 
        S_set_error("missing parameter 'Id'"); return }
    
    unless( $self -> existingContainer( $Id ) ) {
        S_set_error( " Container doesnt exist Id '$Id'" ); return;
    }
    
    delete $self->{ 'ContainerListing' }->{ $Id };

    S_w2log( 5, " LocalWorkingArea -> unregisterContainer : unregistered '$Id'\n" , 'grey' );
    
    return 1;
}


#-------------------------------------------------------------------------------
sub getContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    
    unless( defined $Id ) { 
        S_set_error("missing parameter 'Id'"); return 
    }
    
    unless( $self->{ 'ContainerListing' }->{ $Id } ) {
        S_set_error( " given Id '$Id' doesnt exist in listing" ); 
        return;
    }
        
    my $cont_obj;    
    unless( $cont_obj = $self->{ 'ContainerListing' }->{ $Id }{ 'Object' } ) {
        S_set_error( "Could not get Container object for given Id '$Id'" ); 
        return;
    }

    my $state;    
    unless( $state = $self->{ 'ContainerListing' }->{ $Id }{ 'State' } ) {
        S_set_error( "Could not get Container State for given Id '$Id'" ); 
        return;
    }

    S_w2log( 5, " LocalWorkingArea -> getContainer : return object of 'Id' $Id ( state : $state )\n" , 'grey' );
    
    return $cont_obj;
}


#-------------------------------------------------------------------------------
sub clearContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    
    unless( defined $Id ) { 
        S_set_error("missing parameter 'Id'"); return 
    }
    
    unless( $self->{ 'ContainerListing' }->{ $Id } ) {
        S_set_error( " given Id '$Id' doesnt exist in listing" ); 
        return;
    }
        
    my $cont_obj;    
    unless( $cont_obj = $self->{ 'ContainerListing' }->{ $Id }{ 'Object' } ) {
        S_set_error( "Could not get Container object for given Id '$Id' from internal listing" ); 
        return;
    }

    $cont_obj -> getRootPath() || return;
    $cont_obj -> clearRootPath() || return;
    $cont_obj -> unloadContentObjects() || return;

    S_w2log( 5, " LocalWorkingArea -> clearContainer : RootPath cleared from Container $Id \n" , 'grey' );
    
    return 1;
}

#-------------------------------------------------------------------------------
sub reinitializeContainerListing {
#-------------------------------------------------------------------------------
    my $self = shift;

    S_w2log( 5, " LocalWorkingArea -> reinitializeContainerListing \n" );

    my $lwa_dir = $self -> getPath( ) || return;

    use IO::Dir;
    my $lwa_dir_obj = IO::Dir -> new("$lwa_dir");
    unless( defined $lwa_dir_obj ) {
        S_set_error( "Error while creating object for reading LWA path" ); return;
    }
    
    while( defined( my $entry = $lwa_dir_obj -> read ) ) { 
        next unless basename( $entry ) =~ /(.+).zip$/;
        my $cont_id_from_fname = $1;
        if( $self -> existingContainer( $cont_id_from_fname ) ) {
            S_w2log( 5, " Already known : $cont_id_from_fname\n" , 'grey' );
            next;    
        }
#         $d->rewind;
#         while (defined($_ = $d->read)) { something_else($_); }
        
        #
        # trigger initializing Obj from Storage File
        #
        my $storage_fname_local = $lwa_dir."/".$entry;
        my $cont_obj = $self -> initializeContainerFromFile( $cont_id_from_fname , $storage_fname_local ) || next ;
               
        #
        # Adding to ContainerListing
        #   status 'Initialized' because unclear whether is already Archived or just Packed
        #
        $self -> addContainer( $cont_id_from_fname , $cont_obj , 'Initialized' , $storage_fname_local ) || return;        
    }
    undef $lwa_dir_obj;
    
    return 1;
}
 
#-------------------------------------------------------------------------------
sub query {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $query_href = shift;

    my @returned_ContIds_LWA = ();
    my @not_matched_ContIds = (); 
    
    unless( defined $query_href ) { 
        S_set_error( "missing parameter 'query_href'" , 110 ); return 
    }
    
    $self -> reinitializeContainerListing( ) || return;
    
    foreach my $Id ( keys %{ $self->{ 'ContainerListing' } } ) {
        my $state = $self -> getContainerStatus( $Id ) || return;
        unless( $state =~ /Packed|Archived|Initialized|Opened/  ) {
#             S_w2log( 5, " LocalWorkingArea -> query: Container '$Id' will not be considered in query search (state: $state)" ); 
            next;
        }
    
        my $cont_obj = $self -> getContainer( $Id ) || return;
        my $cont_header = $cont_obj -> getHeader() || return;    
#         S_w2log( 5, " LocalWorkingArea -> query : $Id .. \n" , 'grey' );
        my $match_result = $cont_header -> queryMatch( $query_href );

        return unless defined $match_result;  # undef is ERROR
        if( $match_result ) {
            push( @returned_ContIds_LWA , $Id );
            S_w2log( 3, " LocalWorkingArea -> query : $Id is MATCHING \n" , 'green' );
        } else {
            push( @not_matched_ContIds , $Id );
            S_w2log( 4, " LocalWorkingArea -> query : $Id is NOT MATCHING \n" , 'orange' );
        }
    }
    
#     @returned_ContIds_LWA = qw ( ABC DEF );
    my $nbr_Cont_LWA = scalar @returned_ContIds_LWA;

    S_w2log( 3, " LocalWorkingArea -> query : return $nbr_Cont_LWA matching Container IDs\n" , 'grey' );

    return ( $nbr_Cont_LWA , @returned_ContIds_LWA );
}

#-------------------------------------------------------------------------------
sub updateContainerStorageFilename {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    my $storage_fname = shift;
        
    unless( defined $self->{ 'ContainerListing' }->{ $Id } ) {
        S_set_error( " given Id '$Id' doesnt exist in ContainerListing" ); 
        return;
    }

    $self->{ 'ContainerListing' }{ $Id } { 'StorageFileName' } = $storage_fname;
     
#     S_w2log( 5, " LocalWorkingArea -> updateContainerStorageFilename : $storage_fname \n" , 'grey' );

    return 1;
}

#-------------------------------------------------------------------------------
sub updateContainerStatus {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    my $new_state = shift;
    
    unless( defined $new_state ) { 
        S_set_error("missing parameter 'new_state'"); return }

    unless( grep( /^$new_state$/ , qw( Created Filled Packed Archived Initialized Opened ) ) ) {
         S_set_error("wrong parameter : given State : $new_state -> must be Created | Filled | Packed | Archived | Initialized | Opened "); return 
    }
        
    unless( defined $self->{ 'ContainerListing' }->{ $Id } ) {
        S_set_warning( " given Id '$Id' doesnt exist in internal listing" ); 
        return;
    }
        
    my $current_state;    
    unless( $current_state = $self->{ 'ContainerListing' }->{ $Id }{ 'State' } ) {
        S_set_warning( "Could not get Container State for given Id '$Id'" ); 
        return;
    }

    $self->{ 'ContainerListing' }->{ $Id }{ 'State' } = $new_state ;     # set new state here
    
#     S_w2log( 5, " LocalWorkingArea -> updateContainerStatus : $current_state -> $new_state \n" , 'grey' );
     
    return $new_state;
}

#-------------------------------------------------------------------------------
sub getContainerStatus {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;

    unless( defined $Id ) { 
        S_set_error("missing parameter 'Id'" , 110 ); return; 
    }
    
    unless( $self->{ 'ContainerListing' }->{ $Id } ) {
        S_set_warning( " given Id '$Id' doesnt exist in listing" ); 
        return "NotListed";
    }
        
    my $current_state;    
    unless( $current_state = $self->{ 'ContainerListing' }->{ $Id }{ 'State' } ) {
        S_set_error( "Could not get Container State for given Id '$Id'" ); return;
    }

#     S_w2log( 4, " LocalWorkingArea -> getContainerStatus : $current_state \n" , 'grey' );
     
    return $current_state; 
}


#-------------------------------------------------------------------------------
sub DESTROY {
#-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;
    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    # now do your own thing before or after
    #print "Destroying $self \n";
}

1;  

__END__
