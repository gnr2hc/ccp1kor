# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM::StorageArea;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################


use strict;
use warnings;

use LIFT_general;

use File::Path qw(make_path remove_tree);

#######################################################################################################


#-------------------------------------------------------------------------------
sub new {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $local_working_area_path = shift;
    
    my $class = ref($type) || $type;
    my $self = {};

    S_w2log( 5, " StorageArea::new()\n" , 'grey' );
    
    $self->{ 'Path' } = undef;
    
    #
    #  $self->{ 'ContainerListing' } = {
    #      <ContainerIdentifier_1> => {
    #         'State' => Created|Filled|Stored
    #         'Object' => <Container>
    #      <ContainerIdentifier_2> => {
    #         'State' => Created|Filled|Stored
    #         'Object' => <Container>
    #
    $self->{ 'ContainerListing' } = undef;
    
    unless( defined $local_working_area_path ) {
        S_set_error( " <StorageArea_Path> expected as parameter for Constructor" ); return;
    }

    #
    # BLESS HERE 
    #
    bless $self, $class;


    $self -> setupStorageArea( $local_working_area_path ) || return;   
    
               
    return $self;
}


#-------------------------------------------------------------------------------
sub setupStorageArea {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $local_working_area_path = shift;

    S_w2log( 2, " Setup StorageArea \n" , 'grey' );

    unless( -d $local_working_area_path ) {
        unless( make_path( $local_working_area_path ) ) {
            S_set_error( "Could not create path '$local_working_area_path'" ); return;                                                                   
        }       
        S_w2log( 2 , " '$local_working_area_path' created \n" , 'grey' );
    }

    S_w2log( 2 , " Set StorageArea Path = '$local_working_area_path' \n" , 'grey' );
    $self->{ 'Path' } = $local_working_area_path;

    return 1; 
}
 
#-------------------------------------------------------------------------------
sub getPath {
#-------------------------------------------------------------------------------
    my $self = shift;

    my $path;

    unless( $path = $self -> { 'Path' } )  {
        S_set_error( " StorageArea -> 'Path' is not set " ); return;
    }

    S_w2log( 2, " Get StorageArea -> 'Path' = '$path' \n" , 'grey' );    

    return $path; 
}

#-------------------------------------------------------------------------------
sub existingContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    
    unless( defined $Id ) { 
        S_set_error( "missing parameter 'Id'", 110 ); return 
    }
    
    if( $self->{ 'ContainerListing' }->{ $Id } ) {
        S_w2log( 4, " LIFT_CSM::StorageArea -> existingContainer : TRUE ('$Id') \n" , 'grey' );    
        return 1 ;
    }
    else {
        S_w2log( 4, " LIFT_CSM::StorageArea -> existingContainer : FALSE ('$Id')\n" , 'grey' );    
        return 0 ;
    }

}


#-------------------------------------------------------------------------------
sub registerContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    my $obj = shift;
    my $state = shift;
    my $storage_fname = shift;
    
    unless( defined $state ) { 
        S_set_error("missing parameter"); return }
    
    unless( grep( /^$state$/ , qw( Archived ) ) ) {
         S_set_error("wrong parameter : given State : $state -> must be Archived "); return }
    
    $self->{ 'ContainerListing' }->{ $Id }{ 'Object' } = $obj;
    $self->{ 'ContainerListing' }->{ $Id }{ 'State' } = $state;

    S_w2log( 5, " StorageArea -> registerContainer : $Id => $state \n" , 'grey' );
    
    return 1;
}

#-------------------------------------------------------------------------------
sub unregisterContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    
    unless( defined $Id ) { 
        S_set_error("missing parameter 'Id'"); return }
    
    unless( $self -> existingContainer( $Id ) ) {
        S_set_error( " Container doesnt exist Id '$Id'" ); return;
    }
    
    delete $self->{ 'ContainerListing' }->{ $Id };

    S_w2log( 4, " StorageArea -> unregisterContainer : unregistered '$Id'\n" , 'grey' );
    
    return 1;
}


#-------------------------------------------------------------------------------
sub getContainer {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;
    
    unless( defined $Id ) { 
        S_set_error("missing parameter 'Id'"); return 
    }
    
    unless( $self->{ 'ContainerListing' }->{ $Id } ) {
        S_set_error( " given Id '$Id' doesnt exist in listing" ); 
        return;
    }
        
    my $obj;    
    unless( $obj = $self->{ 'ContainerListing' }->{ $Id }{ 'Object' } ) {
        S_set_error( "Could not get Container object for given Id '$Id'" ); 
        return;
    }

    my $state;    
    unless( $state = $self->{ 'ContainerListing' }->{ $Id }{ 'State' } ) {
        S_set_error( "Could not get Container State for given Id '$Id'" ); 
        return;
    }

    S_w2log( 5, " getContainer : return object of 'Id' $Id ( state : $state )\n" , 'grey' );
    
    return $obj;
}
# 
# #-------------------------------------------------------------------------------
# sub updateContainerStatus {
# #-------------------------------------------------------------------------------
#     my $self = shift;
#     my $Id = shift;
#     my $new_state = shift;
#     
#     unless( defined $new_state ) { 
#         S_set_error("missing parameter 'new_state'"); return }
# 
#     unless( grep( /^$new_state$/ , qw( Created Filled Packed ) ) ) {
#          S_set_error("wrong parameter : given State : $new_state -> must be Created | Filled | Packed "); return 
#     }
#     
#     
#     unless( defined $self->{ 'ContainerListing' }->{ $Id } ) {
#         S_set_warning( " given Id '$Id' doesnt exist in internal listing" ); 
#         return;
#     }
#         
#     my $current_state;    
#     unless( $current_state = $self->{ 'ContainerListing' }->{ $Id }{ 'State' } ) {
#         S_set_warning( "Could not get Container State for given Id '$Id'" ); 
#         return;
#     }
# 
#     $self->{ 'ContainerListing' }->{ $Id }{ 'State' } = $new_state ;     # set new state here
#     
#     S_w2log( 4, " LIFT_CSM::StorageArea -> updateContainerStatus : $current_state -> $new_state \n" , 'grey' );
#      
#     return 1;
# }

#-------------------------------------------------------------------------------
sub getContainerStatus {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $Id = shift;

    unless( defined $Id ) { 
        S_set_error("missing parameter 'Id'" , 110 ); return; 
    }
    
    unless( $self->{ 'ContainerListing' }->{ $Id } ) {
        S_set_error( " given Id '$Id' doesnt exist in listing" , 109 ); return;
    }
        
    my $current_state;    
    unless( $current_state = $self->{ 'ContainerListing' }->{ $Id }{ 'State' } ) {
        S_set_error( "Could not get Container State for given Id '$Id'" ); return;
    }

    S_w2log( 4, " LIFT_CSM::StorageArea -> getContainerStatus : $current_state \n" , 'grey' );
     
    return $current_state; 
}


#-------------------------------------------------------------------------------
sub DESTROY {
#-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;
    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    # now do your own thing before or after
    #print "Destroying $self \n";
}

1;  

__END__
