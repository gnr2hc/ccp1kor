# *****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM::Container;

####    ##
#    #    #
#          #
#          #     ####    #####   #####
#          #         #  #     # #     #
#          #     #####   ###     ###
#          #    #    #      ##      ##
#    #    #    #    #  #     # #     #
####   #####   #### #  #####   #####

#######################################################################################################


use strict;
use warnings;

use LIFT_CSM::Container::Header;
use LIFT_CSM::Container::UserFile;
use LIFT_CSM::Container::Dump::EDR;

use LIFT_general;

use File::Path qw(make_path remove_tree);
use File::Basename;
use File::Copy;
use Path::Class;  # Exports dir() by default

use XML::Simple;

# use Tie::RefHash;

#######################################################################################################

#-------------------------------------------------------------------------------
sub new {

    #-------------------------------------------------------------------------------
    my $type       = shift;
    my $identifier = shift;

    my $class = ref($type) || $type;
    my $self = {};

    S_w2log( 5, " Container::new()\n", 'grey' );

    $self->{'Identifier'}      = "";
    $self->{'RootPath'}        = "";
    $self->{'StorageFileName'} = "";
    $self->{'Header'}          = undef;
    $self->{'Dumps__EDR'}      = [];
    $self->{'UserFiles'}       = [];

    #     $self -> { 'UserFilesInHash' } = { };
    #     tie my %{$self -> { 'UserFilesInHash' }}, 'Tie::RefHash';

    unless ( defined $identifier ) {
        S_set_error("Container 'Identifier' expected as parameter for Constructor");
        return;
    }

    #
    # BLESS HERE
    #
    bless $self, $class;

    $self->setIdentifier($identifier);

    return $self;
}

################################################################################

=head2 LIFT_CSM::Container -> setRootPath

   LIFT_CSM::Container -> setRootPath( $root_path );

   Arguments : 
    - $root_path : absolute folder name of Container (working place) 

   Return :

=cut

#-------------------------------------------------------------------------------
sub setRootPath {

    #-------------------------------------------------------------------------------
    my $self      = shift;
    my $root_path = shift;

    S_w2log( 4, " Set Container -> 'RootPath' = '$root_path' \n", 'grey' );

    unless ( -d $root_path ) {
        unless ( make_path($root_path) ) {
            S_set_error("Could not create path '$root_path' : $!");
            return;
        }
        S_w2log( 3, " Container RootPath '$root_path' created \n", 'grey' );
    }

    $self->{'RootPath'} = $root_path;

    return 1;
}

################################################################################

=head2 LIFT_CSM::Container -> clearRootPath

   LIFT_CSM::Container -> clearRootPath( );

   Clear Container root path setting
   Delete Container path physically 

   Arguments : 
   Return :

=cut

#-------------------------------------------------------------------------------
sub clearRootPath {

    #-------------------------------------------------------------------------------
    my $self = shift;

    S_w2log( 4, " Clear Container -> 'RootPath' \n", 'grey' );

    my $root_path = $self->{'RootPath'};

    if ( -d $root_path ) {
        unless ( remove_tree($root_path) ) {
            S_set_error("Could not remove path '$root_path' : $!");
            return;
        }
        S_w2log( 3, " Container RootPath '$root_path' deleted physically \n", 'grey' );
    }
    else {
        S_w2log( 3, " Container RootPath '$root_path' not existing -> can not delete \n", 'grey' );
    }

    $self->{'RootPath'} = undef;

    return 1;
}

################################################################################

=head2 LIFT_CSM::Container -> getRootPath

   $root_path = LIFT_CSM::Container -> getRootPath( );

   Arguments :     
   Return :
    - $root_path : absolute folder name of Container (working place)
    - unded : when RootPath not set  (deploy warning)

=cut

#-------------------------------------------------------------------------------
sub getRootPath {

    #-------------------------------------------------------------------------------
    my $self = shift;

    my $root_path = $self->{'RootPath'};

    unless ($root_path) {
        S_set_warning(" Container -> 'RootPath' is not set ");
        return;
    }

    S_w2log( 4, " Get Container -> 'RootPath' = '$root_path'\n", 'grey' );

    return $root_path;
}

################################################################################

=head2 LIFT_CSM::Container -> setStorageFileName

   LIFT_CSM::Container -> setStorageFileName( $storage_file_name );

   Arguments : 
    - $storage_file_name : absolute storage file nameof Container (working place) 

   Return :

=cut

#-------------------------------------------------------------------------------
sub setStorageFileName {

    #-------------------------------------------------------------------------------
    my $self              = shift;
    my $storage_file_name = shift;

    S_w2log( 4, " Set Container -> 'StorageFileName' = '$storage_file_name' \n", 'grey' );

    $self->{'StorageFileName'} = $storage_file_name;

    return 1;
}

################################################################################

=head2 LIFT_CSM::Container -> getStorageFileName

   $storage_file_name = LIFT_CSM::Container -> getStorageFileName( );

   Arguments :     
   Return :
    - $storage_file_name : absolute storage file nameof Container (working place)

=cut

#-------------------------------------------------------------------------------
sub getStorageFileName {

    #-------------------------------------------------------------------------------
    my $self = shift;

    my $storage_file_name = $self->{'StorageFileName'};

    unless ($storage_file_name) {
        S_set_error(" Container -> 'StorageFileName' is not set ");
        return;
    }

    S_w2log( 4, " Get Container -> 'StorageFileName' = '$storage_file_name'\n", 'grey' );

    return $storage_file_name;
}

################################################################################

=head2 LIFT_CSM::Container -> setIdentifier

   LIFT_CSM::Container -> setIdentifier( $identifier );

   Arguments : 
    - $identifier : identifier name of container 

   Return :

=cut

#-------------------------------------------------------------------------------
sub setIdentifier {

    #-------------------------------------------------------------------------------
    my $self       = shift;
    my $identifier = shift;

    S_w2log( 4, " Set Container -> 'Identifier' = '$identifier' \n", 'grey' );
    $self->{'Identifier'} = $identifier;

    return 1;
}

################################################################################

=head2 LIFT_CSM::Container -> getIdentifier

   $root_path = LIFT_CSM::Container -> getIdentifier( );

   Arguments :     
   Return :
    - $identifier : identifier name of container

=cut

#-------------------------------------------------------------------------------
sub getIdentifier {

    #-------------------------------------------------------------------------------
    my $self = shift;

    my $identifier = $self->{'Identifier'};

    unless ($identifier) {
        S_set_error(" Container -> 'Identifier' is not set ");
        return;
    }

    S_w2log( 4, " Get Container -> 'Identifier' = '$identifier' \n", 'grey' );

    return $identifier;
}

################################################################################

=head2 LIFT_CSM::Container -> addKeyword

   LIFT_CSM::Container -> addKeyword( $keyword );

   Arguments : 
    - $keyword : keyword to be added in container header keyword list 

   Return :

=cut

#-------------------------------------------------------------------------------
sub addKeyword {

    #-------------------------------------------------------------------------------
    my $self    = shift;
    my $keyword = shift;

#     S_w2log( 4, " Add Container -> Keyword \n", 'grey' );

    my $header_obj = $self->getHeader() || return;

    $header_obj->addKeyword($keyword) || return;

    return 1;
}

################################################################################

=head2 LIFT_CSM::Container -> addHeader

   LIFT_CSM::Container -> addHeader( $params );

   Header object will be created and attached this Container
   Header object contain Meta data of this Container
   Header object will be stored as XML when closing this Container    

   Arguments : 
    - $params : hash reference with elements to be set in the header (see docu of header constructor) 

   Return :

=cut

#-------------------------------------------------------------------------------
sub addHeader {

    #-------------------------------------------------------------------------------
    my $self   = shift;
    my $params = shift;

    S_w2log( 4, " Add Container -> Header (".$self->{'Identifier'}.") \n", 'grey' );

    if ( $self->{'Header'} ) {
        S_set_warning("Header Object already existing for this class");
        $self->{'Header'}->getProjectData();
        return 1;
    }

    my $header_obj = LIFT_CSM::Container::Header->new( $self->{'Identifier'} ) || return;

    foreach ( keys %$params ) {
        next if /ContentListing/;

        if (/KeywordListing/) {
            foreach my $keyword ( @{ $params->{'KeywordListing'} } ) {
                $header_obj->addKeyword($keyword) || return;
            }
            next;
        }

        if (/ProjectData/) {

            my $projectData = {};
            if ( ref $params->{'ProjectData'} eq 'ARRAY' ) {
#                 S_w2log( 5, "LIFT_CSM::Container -> addHeader: element 'ProjectData' contain ARRAY element \n" );
                unless ( scalar @{ $params->{'ProjectData'} } ) {
                    S_set_error("Missing project data in empty ARRAY element of 'ProjectData'");
                    return;
                }
                $projectData = shift @{ $params->{'ProjectData'} };
            }
            elsif ( ref $params->{'ProjectData'} eq 'HASH' ) {
                $projectData = $params->{'ProjectData'};
            }
            else {
                S_set_error("Missing project data in 'ProjectData' ( neither ARRAY nor HASH ref )");
                return;
            }

            foreach ( keys %$projectData ) {
#                 S_w2log( 5, " LIFT_CSM::Container -> addHeader: ProjectData : $_ => ".$projectData -> {$_}."\n" );
                $header_obj->setTestcaseOfCreation( $projectData->{$_} ) && next if (/TestcaseOfCreation/);
                $header_obj->setTimeOfCreation( $projectData->{$_} )     && next if (/TimeOfCreation/);

                $header_obj->setTestername( $projectData->{$_} ) && next if (/Testername/);
                $header_obj->setHostname( $params->{$_} )        && next if (/Hostname/);

                $header_obj->setProjectName( $projectData->{$_} )            && next if (/ProjectName/);
                $header_obj->setProjectCustomerName( $projectData->{$_} )    && next if (/ProjectCustomerName/);
                $header_obj->setProjectSoftwareVersion( $projectData->{$_} ) && next if (/ProjectSoftwareVersion/);
                $header_obj->setProjectVariant( $projectData->{$_} )         && next if (/ProjectVariant/);

                #
                # remaining attributes will be filled in generic routine
                #
                $header_obj->setProjectAttributeOther( $_, $projectData->{$_} );
            }
        }
    }

    #
    # specific handling of re-initializing ContentListing
    #
    if ( $params->{'ContentListing'} ) {

        if ( ref( $params->{'ContentListing'} ) eq "ARRAY" ) {
            S_set_error(" {'ContentListing'} is 'ARRAY' - this can happen when Container with empty ContentListing was read - please contact LIFT support\n");
            return;
        }

        foreach my $cont_entry_nbr ( sort { $a <=> $b } keys %{ $params->{'ContentListing'} } ) {
            my $cont_entry   = $params->{'ContentListing'}{$cont_entry_nbr};
            my $content_type = $cont_entry->{'Content_ClassName'};
            unless ( defined $content_type ) {
                S_set_error("Missing 'Type' in content entry");
                return;
            }
            my $content_identifier = $cont_entry->{'Content_Identifier'};
            unless ( defined $content_identifier ) {
                S_set_error("Missing 'Identifier' in content entry");
                return;
            }
            my $content_obj = $cont_entry->{'Content_Object'};
            unless ( defined $content_obj ) {
                S_set_error("Missing 'Object' in content entry");
                return;
            }

            $header_obj->addContentEntry(
                $content_identifier,    # Content_Identifier
                $content_type,          # Content_ClassName
                $content_obj,           # Content_Object
                $cont_entry_nbr,
            ) || return;

        }
    }

    $self->{'Header'} = $header_obj;

#     S_w2log( 5, " Assigned Container -> Header \n", 'grey' );

    return 1;
}

#-------------------------------------------------------------------------------
sub getHeader {

    #-------------------------------------------------------------------------------
    my $self = shift;

    my $header = $self->{'Header'};
    unless ( defined $header ) {
        S_set_error("Container -> 'Header' is not set ");
        return;
    }

    return $header;
}

################################################################################

=head2 LIFT_CSM::Container -> initializeHeaderFromFile

   LIFT_CSM::Container -> initializeHeaderFromFile( $container_storage_fname );

   Arguments : 
    - $container_storage_fname : absolute filename of Container 
    
    File will be opened and Header-File will be read to initialize the header - object

   Return :

=cut

#-------------------------------------------------------------------------------
sub initializeHeaderFromFile {

    #-------------------------------------------------------------------------------
    my $self                    = shift;
    my $container_storage_fname = shift;

    my $identifier = $self->getIdentifier() || return;

    unless ( defined $container_storage_fname ) {
        S_set_error( "Missing Argument 'storage_fname'", 110 );
        return;
    }

    unless ( -f $container_storage_fname ) {
        S_set_error( "Storage File doesnt exists ($container_storage_fname )", 110 );
        return;
    }

    S_w2log( 5, " Container -> initializeHeaderFromFile : $identifier \n", 'grey' );

    #     my $temp_folder = "C:\\TEMP\\$identifier\\";
    my $temp_folder = "C:\\TEMP";

    unless ( -d $temp_folder ) {
        unless ( make_path($temp_folder) ) {
            S_set_error("Could not create path '$temp_folder' : $!");
            return;
        }
        S_w2log( 4, " Container -> initializeHeaderFromFile: '$temp_folder' created \n", 'grey' );
    }

    my $header_file_in_zip = "$identifier.xml";

    my $zip_handle = S_open_zip($container_storage_fname) || return;
    S_get_from_zip( $zip_handle, $temp_folder, ($header_file_in_zip) );

    my $container_folder = $temp_folder . "\\" . $identifier;
    my $header_file      = $container_folder . "\\" . "$identifier.xml";

    my $container_style = "";
    if( -f $header_file ) {
        $container_style = "CONTAINER WITH SUBFOLDER";
        S_w2log( 4, " Container -> initializeHeaderFromFile: $container_style \n", 'grey' );
    }
    else {
        $header_file = $temp_folder  . "\\" . "$identifier.xml";
        if ( -f $header_file ) {
            $container_style = "CONTAINER WITHOUT SUBFOLDER";
            S_w2log( 4, " Container -> initializeHeaderFromFile: $container_style \n", 'grey' );
        }
        else {
#             S_set_error("Headerfile '$header_file' not existing after zip-extraction");
            S_set_warning( "Could not extract $header_file_in_zip from ZIP-file -> might be not a CSM Container zip-file" );
            return;
        }
    }

    $self->reinitializeHeader($header_file) || return;
    if( $container_style eq "CONTAINER WITH SUBFOLDER" ) {
        unless ( remove_tree $container_folder ) {
            S_set_error("Could not remove folder '$container_folder' ");
            return;
        }
    }
    else {
        unless ( unlink $header_file ) {
            S_set_error("Could not delete '$header_file' ");
            return;
        }
    }

    return 1;
}

#-------------------------------------------------------------------------------
sub reinitializeHeader {

    #-------------------------------------------------------------------------------
    my $self        = shift;
    my $header_file = shift;

#     S_w2log( 5, " Container -> reinitializeHeader \n", 'grey' );

    if ( defined $self->{'Header'} ) {
        S_set_error("Container -> 'Header' is already set ");
        return;
    }

    unless ( -f $header_file ) {
        S_set_error("Headerfile '$header_file' not existing");
        return;
    }

    my $header_obj = LIFT_CSM::Container::Header->new() || return;

    my $header_config;

    #     unless( $header_config = XMLin( $header_file, keyattr => [ ] , ) ) {
    unless (
        $header_config = XMLin(
            $header_file,
            ForceArray => 1,    # required to get array of hashes from ContentListing !!

            #                                     keyattr => [ ] ,
        )
      )
    {
        S_set_error("Error while reading XML-file '$header_file' : $!");
        return;
    }

    #     use Data::Dumper;
    #     S_w2rep( Dumper $header_config ) ;

    $self->addHeader($header_config) || return;

    return 1;
}

################################################################################

=head2 LIFT_CSM::Container -> reinitializeObjectsFromHeader

   LIFT_CSM::Container -> reinitializeObjectsFromHeader( );


=cut

#-------------------------------------------------------------------------------
sub reinitializeObjectsFromHeader {

    #-------------------------------------------------------------------------------
    my $self = shift;

    my $identifier = $self->getIdentifier() || return;

    S_w2log( 4, " Container -> reinitializeObjectsFromHeader : $identifier \n", 'grey' );

    my $header_obj = $self->getHeader() || return;

    foreach my $content_element_nbr ( sort { $a <=> $b } keys %{ $header_obj->{'ContentListing'} } ) {
        my $content_element = $header_obj->{'ContentListing'}{$content_element_nbr};

        #         S_w2rep( " reinitializeObjectsFromHeader: Content is a ". ref ($content_element) ." \n" , 'grey' );

        my $class      = $content_element->{'Content_ClassName'};
        my $identifier = $content_element->{'Content_Identifier'};
        my $object     = $content_element->{'Content_Object'};

        #         my $ref_type = ref ($object);
        #         S_w2rep( " reinitializeObjectsFromHeader: Object is a '$ref_type' \n" , 'grey' );
        #
        #         use Data::Dumper;
        #         S_w2rep( "STORED OBJECT\n" . Dumper $object . "\n" );

        #
        # after XMLin with ForceArray the Object is packed in an array with one hashref element
        #
        # looks like : [ { <<all object data>> } ]
        #
        S_w2log( 5, " Container -> reinitializeObjectsFromHeader : Load Content object '$identifier' (class: $class) )\n", 'grey' );
        my $blessed_obj = $class->load( $object->[0] ) || return;

        #         my $ref_type_obj = ref ( $blessed_obj );
        #         S_w2rep( " reinitializeObjectsFromHeader: Blessed Object is a '$ref_type_obj' \n" , 'grey' );
        #
        #         use Data::Dumper;
        #         S_w2rep( "BLESSED OBJECT\n" . Dumper $blessed_obj . "\n" );

        if ( $class =~ /UserFile/ ) {
            push( @{ $self->{'UserFiles'} }, $blessed_obj );
        }

        if ( $class =~ /EDR/ ) {
            push( @{ $self->{'Dumps__EDR'} }, $blessed_obj );
        }

    }

    return 1;
}

################################################################################

=head2 LIFT_CSM::Container -> unloadContentObjects

   LIFT_CSM::Container -> unloadContentObjects( );


=cut

#-------------------------------------------------------------------------------
sub unloadContentObjects {

    #-------------------------------------------------------------------------------
    my $self = shift;

    S_w2log( 4, " Container -> unloadContentObjects \n", 'grey' );

    while ( my $userfile_obj = pop @{ $self->{'UserFiles'} } ) {
        $userfile_obj->DESTROY();
    }

    while ( my $EDR_obj = pop @{ $self->{'Dumps__EDR'} } ) {
        $EDR_obj->DESTROY();
    }
    return 1;
}

#-------------------------------------------------------------------------------
sub addDump_EDR {

    #-------------------------------------------------------------------------------
    my $self                   = shift;
    my $EDR_DATA_href          = shift;
    my $EDR_storage_identifier = shift;

    S_w2log( 4, " Container -> addDump_EDR \n", 'grey' );

    my $UserFile_class = "LIFT_CSM::Container::Dump::EDR";

    my $dump_EDR_obj = $UserFile_class->new( $EDR_storage_identifier, $EDR_DATA_href ) || return;

    my $nbr_of_elements = scalar @{ $self->{'Dumps__EDR'} };
    $nbr_of_elements++;
    my $temp_file = "C:/TEMP/EDR_" . $nbr_of_elements . ".xml";

    $dump_EDR_obj->saveAsXml($temp_file) || return;

    $self->addFile($temp_file) || return;

    unless ( unlink $temp_file ) {
        S_set_error("Cannot remove $temp_file");
        return;
    }

    push( @{ $self->{'Dumps__EDR'} }, $dump_EDR_obj );

    my $header_obj = $self->getHeader() || return;

    my $content_number = $header_obj->addContentEntry(
        $EDR_storage_identifier,    # Content_Identifier
        $UserFile_class,            # Content_ClassName
        $dump_EDR_obj,              # Content_Object
    ) || return;

    return $content_number;
}

#-------------------------------------------------------------------------------
sub getDump_EDR {

    #-------------------------------------------------------------------------------
    my $self = shift;

    #     my $dump_EDR = $self -> { 'dump_EDR' };
    #     unless( defined $dump_EDR ) {
    #         S_set_error( "Container -> 'dump_EDR' is not set " ); return;
    #     }
    #
    #     return $dump_EDR;
}

################################################################################

=head2 LIFT_CSM::Container -> addUserFile

   LIFT_CSM::Container -> addUserFile( $fname_long [ , $userfile_description ] );

   Arguments : 
    - $keyword : keyword to be added in container header keyword list 

   Return : Content_Number of Content Listing in Header

=cut

#-------------------------------------------------------------------------------
sub addUserFile {

    #-------------------------------------------------------------------------------
    my $self                 = shift;
    my $fname_long           = shift;
    my $userfile_description = shift;

    S_w2log( 4, " Add Container -> UserFile \n", 'grey' );

    my $UserFile_class = "LIFT_CSM::Container::UserFile";

    my $header_obj = $self->getHeader() || return;

    my $stored_fname = $self->addFile($fname_long) || return;    # adding external userfile to container

    my $fname_only = basename $stored_fname ;

    #     my $userfile_obj = $UserFile_class -> new( $fname_only  ) || return;
    my $userfile_obj = LIFT_CSM::Container::UserFile->new($fname_only) || return;

    $userfile_obj->setFilename($fname_only)      || return;
    $userfile_obj->setFilename_long($fname_long) || return;
    $userfile_obj->getFileStatus_physical()      || return;      # must be 1 -> file exists

    if ( defined $userfile_description ) {
        $userfile_obj->setDescription($userfile_description) || return;
    }

    push( @{ $self->{'UserFiles'} }, $userfile_obj );

    #     $self -> { 'UserFilesInHash' }} , $userfile_obj );
    #     $hash{MyClass->new(1)} = 0;  # never use the indirect object syntax

    #     use Data::Dumper;
    #     S_w2rep( "\n NEW USERFILE\n" . Dumper $userfile_obj . "\n" );

    my $content_number = $header_obj->addContentEntry(
        $fname_only,                        # Content_Identifier
        "LIFT_CSM::Container::UserFile",    # Content_ClassName
        $userfile_obj,                      # Content_Object
    ) || return;

    return $content_number;
}

################################################################################

=head2 LIFT_CSM::Container -> getUserFile

    $userfile_obj = LIFT_CSM::Container -> getUserFile( $userfile_id );

   Arguments : 
    - $userfile_id : keyword to be added in container header keyword list 

   Return : $userfile_obj

=cut

#-------------------------------------------------------------------------------
sub getUserFile {

    #-------------------------------------------------------------------------------
    my $self        = shift;
    my $userfile_id = shift;

    my $requested_userfile_obj;

    S_w2log( 4, " Container -> getUserFile ( $userfile_id )\n", 'grey' );

    foreach my $userfile_obj ( @{ $self->{'UserFiles'} } ) {

        #         use Data::Dumper;
        #         S_w2rep( "\n OLD USERFILE\n" . Dumper $userfile_obj . "\n" );

        my $temp_userfile_id = $userfile_obj->getId();
        S_w2log( 5, "Container -> getUserFile : check Id : $temp_userfile_id\n" );
        next unless $userfile_id eq $temp_userfile_id;    # continue loop when userfile found

        S_w2log( 4, " Container -> getUserFile : Found requested Id : $userfile_id \n", 'grey' );
        $requested_userfile_obj = $userfile_obj;
        last;
    }

    unless ( defined $requested_userfile_obj ) {
        S_set_error("Couldnt find userfile object by give Id '$userfile_id'\n");
        return;
    }

    my $StorageFileName = $self->getStorageFileName() || return;
    S_w2log( 1, " Container -> getStorageFileName : $StorageFileName \n", 'blue' );

    my $userfile_name_long = $requested_userfile_obj->getFilename() || return;
    S_w2log( 3, " Container -> getUserFile : return the object of : $userfile_name_long \n", 'grey' );
    return $requested_userfile_obj;
}

################################################################################

=head2 LIFT_CSM::Container -> addFile

   $target_fname_abs = LIFT_CSM::Container -> addFile( $file_source [ , $target_path_relative , $target_file_name ] );

   copy external file into open container

   Arguments : 
    - $file_source : absolute file name external file to be added 
    - $target_path_relative : relative path to be created inside of container (default : '.' (root))
    - $target_file_name : different file name to be set (default : $file_source )

   return value :
    - complete absolute path and file name of stored file  

=cut

#-------------------------------------------------------------------------------
sub addFile {

    #-------------------------------------------------------------------------------
    my $self                 = shift;
    my $file_source          = shift;
    my $target_path_relative = shift;    # optional
    my $target_file_name     = shift;    # optional

    my $file_name_source = basename $file_source;

    if ( defined $target_file_name ) {
        $target_file_name = basename $target_file_name;
    }
    else {
        $target_file_name = basename $file_source;
    }

    my $identifier = $self->{'Identifier'};

    S_w2log( 4, " Container -> addFile '$target_file_name' \n", 'grey' );

    unless ( -f $file_source ) {
        S_set_error("Sourcefile '$file_source' doesnt exists");
        return;
    }

    my $target_path_abs = $self->getRootPath() || return;

    if ( defined $target_path_relative ) {
        $target_path_abs .= "/" . dirname $target_path_relative;
    }

    unless ( -d $target_path_abs ) {
        unless ( make_path($target_path_abs) ) {
            S_set_error("Could not create path '$target_path_abs' : $!");
            return;
        }
        S_w2log( 3, " '$target_path_abs' created \n", 'grey' );
    }

    my $target_fname_abs = $target_path_abs . "/" . $file_name_source;

    if ( -f $target_fname_abs ) {
        S_set_error("Target-Filename --->>> '$target_fname_abs' <<<----- already existing - please use another filename for the new file");
        return;
    }

    S_w2log( 4, " Copying $file_source -> $target_fname_abs \n", 'grey' );
    unless ( copy $file_source , $target_fname_abs ) {
        S_set_error("Could not copy '$file_source' , '$target_fname_abs' ");
        return;
    }

    return $target_fname_abs;
}

################################################################################

=head2 LIFT_CSM::Container -> extractFile

   $extracted_fname_long = LIFT_CSM::Container -> extractFile( $filename_in_zip_requested , $target_path );

   extracting/unzipping file from zipped container

   Arguments : 
    - $filename_in_zip_requested : file name in zip to be extracted 
    - $target_path : path where unzip command shall unzip the zipped content 
       NOTE : internal folders will be created again during unzip

   return value :
    - $extracted_fname_long : absolute filename of extracted file  

=cut

#-------------------------------------------------------------------------------
sub extractFile {

    #-------------------------------------------------------------------------------
    my $self                      = shift;
    my $filename_in_zip_requested = shift;
    my $target_path               = shift;

    my $identifier = $self->getIdentifier() || return;

    S_w2log( 4, " Container -> extractFile '$filename_in_zip_requested' \n", 'grey' );

    my $target_fname = basename $filename_in_zip_requested ;

    my $extracted_fname_long = $target_path . "/" . $target_fname;

    my $container_storage_fname = $self->getStorageFileName() || return;

    unless ( -f $container_storage_fname ) {
        S_set_error("Storage File '$container_storage_fname' doesnt exists");
        return;
    }

    my $zip_handle = S_open_zip($container_storage_fname) || return;
    S_get_from_zip( $zip_handle, $target_path, ($filename_in_zip_requested) ) || return;

    unless ( -f $extracted_fname_long ) {
        S_w2log( 4, " Container -> extractFile '$extracted_fname_long ' not existing after un-Zip command - might be old container with root sub-folder\n", 'grey' );
        $extracted_fname_long = dirname($extracted_fname_long) . "/" . $identifier . "/" . $target_fname;
        unless ( -f $extracted_fname_long ) {
            S_set_error("File '$extracted_fname_long' not existing after un-Zip command");
            return;
        }
    }

    S_w2log( 4, " Container -> extractFile : $extracted_fname_long done \n", 'grey' );

    return $extracted_fname_long;
}

#-------------------------------------------------------------------------------
sub pack_to_zip {

    #-------------------------------------------------------------------------------
    my $self        = shift;
    my $target_path = shift;

    unless ( defined $target_path ) {
        S_set_error("Missing target path");
        return;
    }

    S_w2log( 5, " Container -> pack_to_zip \n", 'grey' );

    my $identifier       = $self->getIdentifier() || return;
    my $container_folder = $self->getRootPath()   || return;
    my $header           = $self->getHeader()     || return;

    #---------------------------------------------------------------------------
    # header create <container_ID>.xml
    #  (XML of header object)
    #  adding this file from temp place to Container folder
    #  removing it on temp place
    #

    my $temp_header_file = "C:/TEMP/$identifier.xml";

    my $file_name_path = dirname $temp_header_file;

    unless ( -d dirname $file_name_path ) {
        unless ( make_path $file_name_path ) {
            S_set_error("Could not create path '$file_name_path'");
            return;
        }
        S_w2log( 5, " Path created : '$file_name_path' \n", 'grey' );
    }

    unless (
        XMLout(
            $header,
            rootname   => 'CSM_ContainerHeader',
            outputfile => $temp_header_file,

            #                     keyattr => [ ] ,
            AttrIndent => 1,
            XMLDecl    => 1,
        )
      )

    {
        S_set_error("Error while creating XML-file '$temp_header_file' : $!");
        return;
    }

    S_w2log( 3, " Container -> pack_to_zip : XML created '$temp_header_file' created \n", 'grey' );

    $self->addFile($temp_header_file) || return;    # add header XML to container

    unless ( unlink $temp_header_file ) {
        S_set_error("Cannot remove $temp_header_file");
        return;
    }

    #---------------------------------------------------------------------------
    # Container folder will be zipped into <container_ID>.zip
    # and deleted after zipping
    #
    unless ( -d $target_path ) {
        S_set_error("Target path for Container doesnt exist '$target_path' : $!");
        return;
    }

    my $container_fname_zip = "$target_path/$identifier.zip";

    unless ($container_folder) {
        S_set_error(" Container -> 'Identifier' is not set ");
        return;
    }

    my $zip_handle = S_open_zip($container_fname_zip) || return;
    my $folder_obj = dir( $container_folder );      # dir from use Path::Class
    foreach my $folder_entry ( $folder_obj->children() ) {  
        S_add_to_zip( $zip_handle, $folder_entry->stringify ) || return;
    }
    S_close_zip($zip_handle) || return;

    unless ( remove_tree $container_folder ) {
        S_set_error("Could not remove folder '$container_folder' ");
        return;
    }

    $self->setStorageFileName($container_fname_zip) || return;

    S_w2log( 4, " Packed Container '$identifier' to zip-file \n", 'grey' );

    return $identifier;
}

#-------------------------------------------------------------------------------
sub moveContainer_To_StorageAreaFileSystem {

    #-------------------------------------------------------------------------------
    my $self                = shift;
    my $target_archive_path = shift;

    unless ( defined $target_archive_path ) {
        S_set_error("Missing target_archive_path");
        return;
    }

    unless ( -d $target_archive_path ) {
        S_set_error(" Target path for archiving '$target_archive_path' doesnt exist");
        return;
    }

    my $identifier                    = $self->getIdentifier()      || return;
    my $container_storage_fname_local = $self->getStorageFileName() || return;

    my $target_fname_archive = $target_archive_path . '/' . basename($container_storage_fname_local);

    S_w2log( 3, " Moving Container '$identifier' \n",            'grey' );
    S_w2log( 3, " Source : '$container_storage_fname_local' \n", 'grey' );
    S_w2log( 3, " Target : '$target_fname_archive' \n",          'grey' );
    unless ( move $container_storage_fname_local , $target_fname_archive ) {
        S_set_error("Error while file move operation : $! ");
        return;
    }

    $self->setStorageFileName($target_fname_archive) || return;

    S_w2log( 4, " Moving Container '$identifier' to StorageArea (FileSystem) done \n", 'grey' );

    return $target_fname_archive;
}

#-------------------------------------------------------------------------------
sub copyContainer_To_StorageAreaFileSystem {

    #-------------------------------------------------------------------------------
    my $self                = shift;
    my $target_archive_path = shift;

    unless ( defined $target_archive_path ) {
        S_set_error("Missing target_archive_path");
        return;
    }

    unless ( -d $target_archive_path ) {
        S_set_error(" Target path for archiving '$target_archive_path' doesnt exist");
        return;
    }

    my $identifier                    = $self->getIdentifier()      || return;
    my $container_storage_fname_local = $self->getStorageFileName() || return;

    my $target_fname_archive = $target_archive_path . '/' . basename($container_storage_fname_local);

    S_w2log( 3, " Moving Container '$identifier' \n",            'grey' );
    S_w2log( 3, " Source : '$container_storage_fname_local' \n", 'grey' );
    S_w2log( 3, " Target : '$target_fname_archive' \n",          'grey' );
    unless ( copy $container_storage_fname_local , $target_fname_archive ) {
        S_set_error("Error while file copy operation : $! ");
        return;
    }

    $self->setStorageFileName($target_fname_archive) || return;

    S_w2log( 4, " Copying Container '$identifier' to StorageArea (FileSystem) done \n", 'grey' );

    return 1;
}

#-------------------------------------------------------------------------------
sub copyContainer_To_LocalWorkingArea {

    #-------------------------------------------------------------------------------
    my $self              = shift;
    my $local_target_path = shift;

    unless ( defined $local_target_path ) {
        S_set_error("Missing local_target_path");
        return;
    }

    unless ( -d $local_target_path ) {
        S_set_error(" Target path for copying '$local_target_path' doesnt exist");
        return;
    }

    my $identifier           = $self->getIdentifier()      || return;
    my $target_fname_archive = $self->getStorageFileName() || return;

    my $container_storage_fname_local = $local_target_path . '/' . basename($target_fname_archive);

    S_w2log( 3, " Copying Container '$identifier' \n",           'grey' );
    S_w2log( 3, " Source : '$target_fname_archive' \n",          'grey' );
    S_w2log( 3, " Target : '$container_storage_fname_local' \n", 'grey' );
    unless ( copy $target_fname_archive , $container_storage_fname_local ) {
        S_set_error("Error while file copy operation : $! ");
        return;
    }

    $self->setStorageFileName($container_storage_fname_local) || return;

    S_w2log( 4, " Copying Container '$identifier' to Local Working Area done \n", 'grey' );

    return $container_storage_fname_local;
}

#-------------------------------------------------------------------------------
sub DESTROY {

    #-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");

    # now do your own thing before or after
    #print "Destroying $self \n";
}

1;

__END__
