# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM::Container::Header;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################


use strict;
use warnings;

use LIFT_general;

use File::Path qw(make_path);
use File::Basename;

#######################################################################################################


#-------------------------------------------------------------------------------
sub new {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $identifier = shift;
    
    my $class = ref($type) || $type;
    my $self = {};

#     S_w2log( 5, " Container::Header::new( )\n" , 'grey' );
    
    $self -> { 'Identifier' } = $identifier if defined $identifier;
    
    $self -> { 'ProjectData' }{ 'ProjectName' } = undef;
    $self -> { 'ProjectData' }{ 'ProjectCustomerName' } = undef;
    $self -> { 'ProjectData' }{ 'ProjectSoftwareVersion' } = undef;
    $self -> { 'ProjectData' }{ 'ProjectVariant' } = undef;
    
    $self -> { 'ProjectData' }{ 'TestcaseOfCreation' } = undef;
    $self -> { 'ProjectData' }{ 'TimeOfCreation' } = undef;
    
    $self -> { 'ProjectData' }{ 'Testername' } = undef;
    $self -> { 'ProjectData' }{ 'Hostname' } = undef;
    
    
# will be created with 1st entry / otherwise problems with XMLin ForceArray
#     $self -> { 'ContentListing' } = { };       
    $self -> { 'ContentListingCounter' } = 0;
    
    $self -> { 'KeywordListing' } = undef;
    
    
    #
    # BLESS HERE 
    #
    bless $self, $class;
    
    return $self;
}


###############################################################################

=head2 addContentEntry

	LIFT_CSM::Container::Header -> addContentEntry(  
                                                    $content_identifier , 
                                                    $content_class_name ,  
                                                    $content_object ,
                                                    $content_cnt_given , # optional
                                                    );

    adding a new element the content listing    
    required is type of content - class type must be used 
    - 'LIFT_CSM::Container::UserFile'
    - 'LIFT_CSM::Container::Dump::EDR'
    - ...

    content will be sortend by incresing entry numbering 

    Layout of ContentListing (numbered hash of hashes)
    
    $self -> { 'ContentListing' } = {
                                        
                                        1   =>         # 1st element               
                                            { 
                                                Content_Identifier  => 'File_A.txt' , 
                                                Content_ClassName   => "LIFT_CSM::Container::UserFile"  , 
                                                Content_Object => <<< all data of object >>  ,
                                            } ,
                                        
                                        2  =>          # 2nd element
                                            { 
                                                Content_Identifier  => ... , 
                                                Content_ClassName   => ...  , 
                                                Content_Object => ... ,
                                            } ,
                                    }

    Return : NUmber of Element in ContentListing

=cut

#-------------------------------------------------------------------------------
sub addContentEntry {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $content_identifier = shift;
    my $content_class_name = shift;
    my $content_object = shift;
    my $content_cnt_given = shift;

    my $content_cnt ; 
    
    unless( defined $content_identifier ) {
        S_set_error( "missing function argument 'content_identifier' " ); return
    }

    unless( defined $content_class_name ) {
        S_set_error( "missing function argument 'content_class_name' " ); return
    }

    unless( defined $content_object ) {
        S_set_error( "missing function argument 'content_object' " ); return
    }

    unless( $content_cnt = $content_cnt_given ) 
    {
        $content_cnt = $self -> { 'ContentListingCounter' };
        $content_cnt++;
    }

    S_w2log( 5, " Container::Header -> addContentEntry ($content_cnt) Type: '$content_class_name' Identifier: '$content_identifier' \n" , 'grey' );
    
#     push( 
#             @{$self -> { 'ContentListing' }} , 
#             { 
#                 'Content_Identifier' => $content_identifier ,
#                 'Content_ClassName'  => $content_class_name , 
#                 'Content_Object'     => $content_object , 
#             } 
#         );

    $self -> { 'ContentListing' }{ $content_cnt } { 'Content_Identifier' }  = $content_identifier ;
    $self -> { 'ContentListing' }{ $content_cnt } { 'Content_ClassName' }   = $content_class_name ;
    $self -> { 'ContentListing' }{ $content_cnt } { 'Content_Object' }      = $content_object ;   # will be written in a array because after read of header with XMLin it will be an array ref as well
        
    $self -> { 'ContentListingCounter' } = $content_cnt;

    return $content_cnt; 
}
 

#-------------------------------------------------------------------------------
sub addKeyword {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $keyword = shift;

#     S_w2log( 4, " Container::Header -> addKeyword ( $keyword ) \n" , 'grey' );
    
    push( @{ $self -> { 'KeywordListing' }} , $keyword );    

    return 1; 
}


################################################################################
 
=head2 LIFT_CSM::Container::Header -> queryMatch

   LIFT_CSM::Container::Header -> queryMatch( $storage_fname );

    $query_href_match = {
            'keywords_fully'        =>  [ 
                                            'my-keyword-test-value-ABC' , 
                                            'my-keyword-test-value-XYZ' , 
                                        ] ,
            'keywords_partially'    => [ 'Front_' ] ,
            'keywords_regex'        => [ 'test.*ABC' ] ,
            'content_type'          => [ 'EDR' ] ,
        };

   Return :
        0     - no matching
        1     - matching
        undef - error (e.g. wrong query) 

   Note: Search is case insensitive 

=cut

#-------------------------------------------------------------------------------
sub queryMatch {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $query_href = shift;

    my $no_match_cntr_fully_search       = 0;
    my $no_match_cntr_partially_search   = 0;
    my $no_match_cntr_regex_search       = 0;
    my $no_match_cntr_conttype_search    = 0;
    my $no_match_cntr_contID_search      = 0;

    
    if( defined $query_href -> { 'keywords_fully' } ) {
        unless ( ref $query_href -> { 'keywords_fully' } eq 'ARRAY' ) {
            S_set_error( " Search query 'keywords_fully' must be ARRAY ref" ); return;
        } 
        
        foreach my $keyword_fully_match ( @{ $query_href -> { 'keywords_fully' } } ) {            
            # S_w2log( 4 , "  Checking keyword fully match : $keyword_fully_match \n" , 'grey' );
            
            #
            #  good case
            #
            next if grep { /^$keyword_fully_match$/i } @{ $self -> { 'KeywordListing' }} ;

            #
            # bad case
            #
            $no_match_cntr_fully_search++;
#             S_w2log( 4 , "  NOT fully matching keyword : $keyword_fully_match \n" , 'orange' );
        }
    }

    if( defined $query_href -> { 'keywords_partially' } ) {
        unless ( ref $query_href -> { 'keywords_partially' } eq 'ARRAY' ) {
            S_set_error( " Search query 'keywords_partially' must be ARRAY ref" ); return;
        } 
        
        foreach my $keyword_partially_match ( @{ $query_href -> { 'keywords_partially' } } ) {            
            # S_w2log( 4 , "  Checking keyword partially match : $keyword_partially_match \n" , 'grey' );
            
            #
            #  good case
            #
            next if grep { /$keyword_partially_match/i } @{ $self -> { 'KeywordListing' }} ;

            #
            # bad case
            #
            $no_match_cntr_partially_search++;
            S_w2log( 4 , "  NOT partially matching keyword : $keyword_partially_match \n" , 'orange' );
        }
    }

    if( defined $query_href -> { 'keywords_regex' } ) {
        unless ( ref $query_href -> { 'keywords_regex' } eq 'ARRAY' ) {
            S_set_error( " Search query 'keywords_regex' must be ARRAY ref" ); return;
        } 
        
        foreach my $keyword_regex_match ( @{ $query_href -> { 'keywords_regex' } } ) {            
            # S_w2log( 4 , "  Checking keyword regex match : $keyword_regex_match \n" , 'grey' );
            
            #
            #  good case
            #
            next if grep { /$keyword_regex_match/i } @{ $self -> { 'KeywordListing' }} ;

            #
            # bad case
            #
            $no_match_cntr_regex_search++;
#             S_w2log( 4 , "  NOT regex matching keyword : $keyword_regex_match \n" , 'orange' );
        }
    }

    if( defined $query_href -> { 'content_type' } ) {
        unless ( ref $query_href -> { 'content_type' } eq 'ARRAY' ) {
            S_set_error( " Search query 'content_type' must be ARRAY ref" ); return;
        } 
        
        foreach my $content_class_name_match ( @{ $query_href -> { 'content_type' } } ) {            
            # S_w2log( 4 , "  Checking keyword regex match : $content_class_name_match \n" , 'grey' );
            
            my @ContentType_Collection = ();
            foreach my $cont_entry_nbr ( keys %{ $self -> { 'ContentListing' }} ) {
                push(   @ContentType_Collection , 
                        $self -> { 'ContentListing' }{$cont_entry_nbr}{ 'Content_ClassName' } 
                        );
            }

            #
            #  good case
            #
            next if grep { /$content_class_name_match/i } @ContentType_Collection ;

            #
            # bad case
            #
            $no_match_cntr_conttype_search++;
#             S_w2log( 4 , "  NOT regex matching keyword : $content_class_name_match \n" , 'orange' );
        }
    }

    if( $no_match_cntr_fully_search || 
        $no_match_cntr_partially_search || 
        $no_match_cntr_regex_search ||
        $no_match_cntr_conttype_search ||
        $no_match_cntr_contID_search       
        ) 
    {
#         S_w2log( 4 , " Container::Header -> queryMatch : NOT SUCCESSFUL \n" , 'orange' );
        return 0;
    }

#     S_w2log( 4, " Container::Header -> queryMatch SUCCESSFUL\n" , 'green' );
    
    return 1; 
}

################################################################################
 
=head2 LIFT_CSM::Container::Header -> getContentIdentifiers

   $content_identifier_aref = LIFT_CSM::Container::Header -> getContentIdentifiers( $requested_content );

   $requested_content : 'UserFile' | 'EDR' | ... somehow matching with content classname

   Return :
        $content_identifier_aref : 
            array ref of content Ids in order of content listing (order of storing)

=cut

#-------------------------------------------------------------------------------
sub getContentIdentifiers {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $requested_content = shift;

#     S_w2log( 4, " Container::Header -> getContentIdentifiers( $requested_content ) \n" , 'grey' );
    
    my $content_identifier_aref = [];
        
    foreach my $content_entry_nbr ( sort {$a <=> $b} keys %{ $self -> { 'ContentListing' }} ) {
        my $content_entry = $self -> { 'ContentListing' }{$content_entry_nbr};
        my $content_class = $content_entry -> { 'Content_ClassName' };
        next unless $content_class =~ /$requested_content/i;
        
        my $content_id = $content_entry -> { 'Content_Identifier' };
#         S_w2log( 3, " [ $content_entry_nbr ] $content_id \n" , 'grey' );
        
        push( @$content_identifier_aref , $content_id );
    }
    
    return $content_identifier_aref; 
}

 

#-------------------------------------------------------------------------------
sub getProjectData {
#-------------------------------------------------------------------------------
    my $self = shift;

#     S_w2log( 4, " Container::Header -> getProjectData \n" , 'grey' );
    
    foreach my $prj_data_item ( keys %{$self -> { 'ProjectData' }} ) {
        my $prj_data_value = $self -> { 'ProjectData' }{$prj_data_item}; 
        S_w2log( 3, " Project Data of Header: $prj_data_item => $prj_data_value\n" );
    }
   
    return $self -> { 'ProjectData' }; 
}
 
#-------------------------------------------------------------------------------
sub getKeywordListing {
#-------------------------------------------------------------------------------
    my $self = shift;

#     S_w2log( 4, " Container::Header -> getKeywordListing \n" , 'grey' );
    
    foreach my $key_word_item ( @{$self -> { 'KeywordListing' }} ) {
        S_w2log( 4, " getKeywordListing: Keyword $key_word_item \n" );
    }
   
    return $self -> { 'KeywordListing' }; 
}
 

#-------------------------------------------------------------------------------
sub setProjectName {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $project_name = shift;

#     S_w2log( 4, " Set Container::Header -> 'ProjectName' = '$project_name' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'ProjectName' } = $project_name;    

    return 1; 
}
 

#-------------------------------------------------------------------------------
sub setProjectCustomerName {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $project_customer_name = shift;

#     S_w2log( 4, " Set Container::Header -> 'ProjectCustomerName' = '$project_customer_name' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'ProjectCustomerName' } = $project_customer_name;    

    return 1; 
}
 

#-------------------------------------------------------------------------------
sub setProjectSoftwareVersion {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $project_software_version = shift;

#     S_w2log( 4, " Set Container::Header -> 'ProjectSoftwareVersion' = '$project_software_version' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'ProjectSoftwareVersion' } = $project_software_version;    

    return 1; 
}
 
#-------------------------------------------------------------------------------
sub setProjectVariant {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $project_variant = shift;

#     S_w2log( 4, " Set Container::Header -> 'ProjectVariant' = '$project_variant' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'ProjectVariant' } = $project_variant;    

    return 1; 
}
 
#-------------------------------------------------------------------------------
sub setProjectAttributeOther {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $project_attribute_name = shift;
    my $project_attribute_value = shift;

#     S_w2log( 4, " Set Container::Header -> '$project_attribute_name' = '$project_attribute_value' \n" , 'grey' );
    $self -> { 'ProjectData' }{ $project_attribute_name } = $project_attribute_value;    

    return 1; 
}
 
#-------------------------------------------------------------------------------
sub setTestcaseOfCreation {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $testcase_of_creation = shift;

#     S_w2log( 4, " Set Container::Header -> 'TestcaseOfCreation' = '$testcase_of_creation' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'TestcaseOfCreation' } = $testcase_of_creation;    

    return 1; 
}

#-------------------------------------------------------------------------------
sub setTimeOfCreation {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $testcase_of_creation = shift;

#     S_w2log( 4, " Set Container::Header -> 'TimeOfCreation' = '$testcase_of_creation' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'TimeOfCreation' } = $testcase_of_creation;    

    return 1; 
}

#-------------------------------------------------------------------------------
sub setTestername {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $testername = shift;

#     S_w2log( 4, " Set Container::Header -> 'Testername' = '$testername' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'Testername' } = $testername;    

    return 1; 
}

#-------------------------------------------------------------------------------
sub setHostname {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $hostname = shift;

#     S_w2log( 4, " Set Container::Header -> 'Hostname' = '$hostname' \n" , 'grey' );
    $self -> { 'ProjectData' }{ 'Hostname' } = $hostname;    

    return 1; 
}



#-------------------------------------------------------------------------------
sub DESTROY {
#-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;
    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    # now do your own thing before or after
    #print "Destroying $self \n";
}

1;

__END__
