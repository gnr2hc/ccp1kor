# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

# package EDR_Framework::EDR;
package LIFT_CSM::Container::Dump::EDR;
use parent qw( LIFT_CSM::Container::Dump );

 
   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

use strict;
use warnings;
use LIFT_general;

use File::Path qw(make_path);
use File::Basename;
use XML::Simple;


#
#  for AKLV all Services shall be run and status and results to be dumped
#   spec: \\siz1130\aerse$\Projekte\AB12\60.Software\J.SystemConcept\15.EDR\B_Requirements\10_AK_LV_37\01_AK_LV_37
#   chapter 6.4
#     6.4	Diagnosekommunikation	18
#     6.4.1	ReadDataByIdentifier 0xFA10 � NumberOfEDRDevices	19
#     6.4.2	ReadDataByIdentifier 0xFA11 � EDRIdentification	20
#     6.4.3	ReadDataByIdentifier 0xFA12 � AddressInformation	21
#     6.4.4	ReadDataByIdentifier 0xFA13...0xFA18 � EDREntry	23
#     6.4.4.1	Header	24
#     6.4.5	RoutineControl 0xE210 � CalculateSignatureOrCRC	25
#     6.4.5.1	Start Routine 0xE210	25
#     6.4.5.2	Stop Routine 0xE210	26
#     6.4.5.3	Request Routine Results 0xE210	27
#     6.4.5.4	Request- und Responseparameter 0xE210	28
#     6.4.6	SecurityAccess	29
# 

# 
#     my $EDR_DATA_href = {
#                             
#                             #
#                             # can even just simple EDR data as given as response from higl leel functions to testcase
#                             #
#                             Records => {                                                                
#                                 1 => {   # Record_Nbr
#                                          Description    => "EDR - Record (1) - newest (Generic + OEM) - read by 22 FA 13 and 22 10 13" ,
#                                          Status         => "Complete" ,  #   'Complete' | 'NotComplete' | 'Empty'
#                                          Data_Generic   => $EDR_record_Gen_22_FA_13 ,
#                                          Data_OEM       => $EDR_record_OEM_22_10_13 ,
#                                          Data_Mixed     => undef ,
#                                          Structure_Info => undef ,   # response from reading EDR structure data (Ford)
#                                         },
# #                                 2 => {
# #                                         },
# #                                 3 => {
# #                                         },
# #                                 4 => {
# #                                         },
# #                                         
#                                 # ....
#                             },
#                             
#                             #
#                             # can even be complete AKLV Cust Diag communication (additionally)
#                             #
#                             DiagCommunication => {
#                                 #
#                                 #  even all preceding requests shall be dumped there e.g. 
#                                 #   22 FA 10   NumberOfEDRDevices
#                                 #   22 FA 11   EDRIdentification
#                                 #   22 FA 12   AddressInformation
#                                 #
#                                                                 
#                                 3 => {   # numbering just for sequence , not for record number
#                                          Description    => "EDR Generic - Record (1) - newest"
#                                          Record_Nbr     => 1 ,
#                                          Record_Type    => "AKLV_Generic" ,
#                                          Request        => "22 FA 13" ,
#                                          Response       => $EDR_record_Gen_22_FA_13 ,     # simple string with all bytes  / must not be complete when Records are given explicitely
#                                         },
#                                 4 => {   # numbering just for sequence , not for record number
#                                          Description    => "EDR OEM - Record (1) - newest"
#                                          Record_Nbr     => 1 ,
#                                          Record_Type    => "AKLV_OEM" ,
#                                          Request => "22 10 13" ,
#                                          Response => $EDR_record_OEM_22_10_13 ,           # simple string with all bytes / must not be complete when Records are given explicitely
#                                         },
#                             },
#                         };    
# 


###############################################################################

=head2 new

	$record_object = Container::Dump::EDR -> new( );

I<B<Description:>> 	instances a new object of EDR data class 
					mandatory: n/a
                    
                    optional :
						$EDR_DATA_href 	= big complex hash ref with structure to be defined
                                           (see comments in class) 
						

I<B<Return:>> return the blessed (instanced) record object

I<B<Verdict:>> none

I<B<Error:>> inconsistent data of EDR_DATA_href (if given)

=cut

#------------------------ Constructor ------------------------------------------
sub new {
#-------------------------------------------------------------------------------

    my $type = shift;
    my $Id = shift;
    my $EDR_DATA_href = shift; 
    
    my $class = ref($type) || $type;
    my $self = {};

    $self -> { 'Id' } = $Id;
    $self -> { 'Records' } = [];
    $self -> { 'DiagCommunication' } = [];

    S_w2log( 5, " Container::Dump::EDR()\n" , 'grey' );

	bless $self, $class;
        
    if( defined $EDR_DATA_href->{ 'Records' } ) {
        foreach my $RecordNbr ( sort {$a <=> $b} keys %{$EDR_DATA_href->{ 'Records' }} )  {
            S_w2log( 5, " Container::Dump::EDR -> Constructor : add Record $RecordNbr \n" , 'grey' );
            $self -> addRecord( 
                                $RecordNbr ,
                                $EDR_DATA_href->{ 'Records' }{$RecordNbr} , 
                                ) || return;
        }
    }
    
    if( defined $EDR_DATA_href->{ 'DiagCommunication' } ) {
        foreach my $DiagSequenceNbr ( sort {$a <=> $b} keys %{$EDR_DATA_href->{ 'DiagCommunication' }} )  {
            S_w2log( 5, " Container::Dump::EDR -> Constructor : add DiagCommunication $DiagSequenceNbr \n" , 'grey' );
            $self -> addDiagCommunication( 
                                $DiagSequenceNbr , 
                                $EDR_DATA_href->{ 'DiagCommunication' }{$DiagSequenceNbr} ,
                                ) || return;
        }
    }
    
    return $self;
}

################################################################################
 
=head2 LIFT_CSM::Container::Dump::EDR -> load

   LIFT_CSM::Container::Dump::EDR -> load( );

=cut

#-------------------------------------------------------------------------------
sub load {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $old_object = shift;
    
    my $class = ref($type) || $type;

    S_w2log( 4, " $class -> load() an old object\n" , 'grey' );
   
    #
    # BLESS HERE 
    #
    bless $old_object, $class;
    
    return $old_object;
}


#-------------------------------------------------------------------------------
sub addDiagCommunication {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $seq_nbr = shift;
    my $diag_comm = shift;

    S_w2log( 4, " Container::Dump::EDR -> addDiagCommunication () \n" , 'grey' );

    unless( defined $diag_comm ) {
        S_set_error( "missing parameter" ); return;
    }

#     $self -> { DiagCommunication }{$seq_nbr} = $diag_comm;
    push ( @{$self -> { DiagCommunication }} , $diag_comm );
    
    return 1; 
}
 

#-------------------------------------------------------------------------------
sub addRecord {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $RecordNbr = shift;
    my $RecordData = shift;
    
    S_w2log( 4, " Container::Dump::EDR -> addRecord ( $RecordNbr , <data> ) \n" , 'grey' );

    unless( defined $RecordData ) {
        S_set_error( "missing parameter" ); return;
    }

#     $self -> { Records }{$RecordNbr} = $RecordData;
    push ( @{$self -> { Records }} , $RecordData );
    
    return 1; 
}
 

################################################################################
 
=head2 LIFT_CSM::Container::Dump -> saveAsXml

   LIFT_CSM::Container::Dump::EDR -> saveAsXml( );


=cut

#-------------------------------------------------------------------------------
sub saveAsXml {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $file_name = shift;

    my $file_name_path = dirname $file_name;

    unless( -d dirname $file_name_path ) {
        unless( make_path $file_name_path ) {
            S_set_error( "Could not create path '$file_name_path'" ); return;                                                                   
        }       
        S_w2log( 5 , " Path created : '$file_name_path' \n" , 'grey' );
    }

    
    unless( XMLout( $self, 
                    rootname => 'DUMP__EDR', 
                    outputfile => $file_name,
#                     KeyAttr => [ qw ( Records DiagCommunication ) ] , 
                    KeyAttr => [ ] , 
                    AttrIndent => 1 , 
                    XMLDecl => 1 ,
                    ) ) 
             
    {
        S_set_error( "Error while creating XML-file '$file_name' : $!" ); return;
    }

    S_w2log( 3, " Container::Dump::EDR -> saveAsXml : XML created '$file_name' created \n" , 'grey' );

    return 1; 
}
 


#-------------------------------------------------------------------------------
sub DESTROY {
#-------------------------------------------------------------------------------
	#
	# Destructor - just to have one
	#

	my $self = shift;
	# check for an overridden destructor...
	$self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
	print "Destroying 'EDR'\n";
	
	return 1;
}



1;