# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM::Container::UserFile;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################


use strict;
use warnings;

use LIFT_general;

#######################################################################################################


################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> new

   LIFT_CSM::Container::UserFile -> new( );


=cut

#-------------------------------------------------------------------------------
sub new {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $Id = shift;
    
    my $class = ref($type) || $type;
    my $self = {};

    S_w2log( 4, " Container::UserFile -> new()\n" , 'grey' );
   
    $self -> { 'Id' } = $Id;
    
    $self -> { 'Filename' } = undef;
    $self -> { 'Filename_long' } = undef;       # only set when file is physically available (un-packed)
    $self -> { 'Description' } = undef;
#     $self -> { 'TimeOfStorage' } = undef;
#     $self -> { 'TimeOfFileCreation' } = undef;
        
    #
    # BLESS HERE 
    #
    bless $self, $class;
    return $self;    
}

################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> load

   LIFT_CSM::Container::UserFile -> load( $old_object );


=cut

#-------------------------------------------------------------------------------
sub load {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $old_object = shift;
    
    my $class = ref($type) || $type;

    S_w2log( 4, " $class -> load() an old object\n" , 'grey' );
   
    #
    # BLESS HERE 
    #
    bless $old_object, $class;
    
    #
    # reset 'Filename_long'  because not valid
    #
    $old_object -> getFileStatus_physical();
    
    return $old_object;
}

################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> getId

   $Id = LIFT_CSM::Container::UserFile -> getId(  );

=cut

#-------------------------------------------------------------------------------
sub getId {
#-------------------------------------------------------------------------------
    my $self = shift;
    
    my $Id = $self -> { 'Id' };
   
    unless( $Id ) {
        S_set_error( "Id is not set" ); 
        return;
    }
    
    S_w2log( 5, " Container::UserFile -> getId() : $Id \n" , 'grey' );
    
    return $Id;
}


################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> setFilename

   LIFT_CSM::Container::UserFile -> setFilename( $filename );

   Note: when Filename of Userfile object is set it can not be set again 

=cut

#-------------------------------------------------------------------------------
sub setFilename {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $filename = shift;

    unless( defined $filename ) {
        S_set_error( "Missing argument 'filename'" ); return;
    }
    
    S_w2log( 5, " Container::UserFile -> setFilename()\n" , 'grey' );
   
    if( my $existing_fname = $self -> { 'Filename' } ) {
        S_set_error( "Filename is already set to '$existing_fname'" ); 
        return;
    }
    
    $self -> { 'Filename' } = $filename;
    
    return 1;
}

################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> getFilename

   $filename = LIFT_CSM::Container::UserFile -> getFilename(  );

=cut

#-------------------------------------------------------------------------------
sub getFilename {
#-------------------------------------------------------------------------------
    my $self = shift;
    
    my $filename = $self -> { 'Filename' };
   
    unless( $filename ) {
        S_set_error( "Filename is not set" ); 
        return;
    }
    
    S_w2log( 5, " Container::UserFile -> getFilename() : $filename \n" , 'grey' );
    
    return $filename;
}


################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> setFilename_long

   LIFT_CSM::Container::UserFile -> setFilename_long( $filename );

   Note: when Filename_long is set the userfile is physically available

=cut

#-------------------------------------------------------------------------------
sub setFilename_long {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $filename = shift;

    unless( defined $filename ) {
        S_set_error( "Missing argument 'filename'" ); return;
    }
    
    S_w2log( 5, " Container::UserFile -> setFilename_long()\n" , 'grey' );
   
    if( my $existing_fname = $self -> { 'Filename_long' } ) {
        S_set_error( "Filename_long is already set to '$existing_fname'" ); 
        return;
    }
    
    $self -> { 'Filename_long' } = $filename;
    
    return 1;
}

################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> getFilename_long

   $filename = LIFT_CSM::Container::UserFile -> getFilename_long(  );

   when 'Filename_long' not set
    - set warning
    - return undefined  

=cut

#-------------------------------------------------------------------------------
sub getFilename_long {
#-------------------------------------------------------------------------------
    my $self = shift;
    
    my $filename = $self -> { 'Filename_long' };
   
    unless( $filename ) {
        S_set_warning( "Filename_long is not set" ); 
        return;
    }
    
    S_w2log( 5, " Container::UserFile -> getFilename_long() : $filename \n" , 'grey' );
    
    return $filename;
}

################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> getFileStatus_physical

   $filestatus_physical = LIFT_CSM::Container::UserFile -> getFileStatus_physical(  );
   
   return values :
    $filestatus_physical = 1      : 'Filename_long' set     & userfile physically     available 
    $filestatus_physical = 0      : 'Filename_long' re-set  & userfile physically not available 
    $filestatus_physical = undef  : 'Filename_long' not defined

=cut

#-------------------------------------------------------------------------------
sub getFileStatus_physical {
#-------------------------------------------------------------------------------
    my $self = shift;
    
    my $fname_long = $self -> { 'Filename_long' };
    
    unless( defined $fname_long ) {
        S_w2log( 4, " Container::UserFile -> getFileStatus_physical() : 'Filename_long' is not defined \n" , 'grey' );
        return;
    }
   
    unless( -f $fname_long ) {
        S_w2log( 3, " Container::UserFile -> getFileStatus_physical() : UserFile $fname_long physically not available\n" , 'grey' );
        $self -> { 'Filename_long' } = undef;
        return 0;
    }
    
    S_w2log( 3, " Container::UserFile -> getFileStatus_physical() : UserFile $fname_long physically availabl\n" , 'grey' );
    return 1;
}



################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> setDescription

   LIFT_CSM::Container::UserFile -> setDescription( $description );

   Note: when Description of Userfile object is set it can not be set again 

=cut

#-------------------------------------------------------------------------------
sub setDescription {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $description = shift;
    
    unless( defined $description ) {
        S_set_error( "Missing argument 'description'" ); return;
    }
    
    S_w2log( 5, " Container::UserFile -> setDescription()\n" , 'grey' );
   
    if( my $existing_description = $self -> { 'Description' } ) {
        S_set_error( "Description is already set to '$existing_description'" ); 
        return;
    }
    
    $self -> { 'Description' } = $description;
    
    return 1;
}

################################################################################
 
=head2 LIFT_CSM::Container::UserFile -> getDescription

   $description = LIFT_CSM::Container::UserFile -> getDescription( );

   when 'Description' not set
    - set warning
    - return undefined  

=cut

#-------------------------------------------------------------------------------
sub getDescription {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $params = shift;

    S_w2log( 5, " Container::UserFile -> getDescription()\n" , 'grey' );
   
    my $description = $self -> { 'Description' };
    unless( $description ) {
        S_set_warning( "Description is not set" ); 
        return;
    }
        
    return $description;
}


#-------------------------------------------------------------------------------
sub DESTROY {
#-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;
    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    # now do your own thing before or after
    #print "Destroying $self \n";
}

1;

__END__
