# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM::Container::Dump;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################


use strict;
use warnings;

use LIFT_general;

use File::Path qw(make_path);
use File::Basename;
use XML::Simple;

#######################################################################################################


#-------------------------------------------------------------------------------
sub new {
#-------------------------------------------------------------------------------
    my $type = shift;
    my $identifier = shift;
    
    my $class = ref($type) || $type;
    my $self = {};

    S_w2log( 5, " Container::Dump::new()\n" , 'grey' );
        
    #
    # BLESS HERE 
    #
    bless $self, $class;
    
    return $self;
}

################################################################################
 
=head2 LIFT_CSM::Container::Dump -> saveAsXml

   LIFT_CSM::Container::Dump -> saveAsXml( );


=cut

#-------------------------------------------------------------------------------
sub saveAsXml {
#-------------------------------------------------------------------------------
    my $self = shift;
    my $file_name = shift;

    my $file_name_path = dirname $file_name;

    unless( -d dirname $file_name_path ) {
        unless( make_path $file_name_path ) {
            S_set_error( "Could not create path '$file_name_path'" ); return;                                                                   
        }       
        S_w2log( 5 , " Path created : '$file_name_path' \n" , 'grey' );
    }

    
    unless( XMLout( $self, 
                    rootname => 'CSM_DUMP', 
                    outputfile => $file_name,
                    KeyAttr => [] , 
                    AttrIndent => 1 , 
                    XMLDecl => 1 ,
                    ) ) 
             
    {
        S_set_error( "Error while creating XML-file '$file_name' : $!" ); return;
    }

    S_w2log( 3, " Container::Dump -> saveAsXml : XML created '$file_name' created \n" , 'grey' );

    return 1; 
}
 

#-------------------------------------------------------------------------------
sub DESTROY {
#-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;
    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    # now do your own thing before or after
    #print "Destroying $self \n";
}

1;

__END__
