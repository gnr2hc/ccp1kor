# *****************************************************************************************************
#                                                                                                      
#  Copyright (c) 2014  Robert Bosch GmBH                                                               
#                      Germany                                                                         
#                      All rights reserved                                                             
#                                                                                                      
#******************************************************************************************************
#******************************************************************************************************

package FuncLib_sVTT;

use strict;
use warnings;
use LIFT_general;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_DSO1;
use Readonly;
use File::Basename;
use Math::BigInt qw(bgcd);
use List::Util qw/max/;
use POSIX;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use FuncLib_sVTT ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
					SVTT_ClearFaultMemory
                    SVTT_Evaluation
                    SVTT_ExecuteCurve
                    SVTT_exit
                    SVTT_init
                    SVTT_PerformDiagnosis
					SVTT_PrepareCurve
					SVTT_Reset
					SVTT_StartMeasurement
					SVTT_StopAndStoreMeasurement
					$SVTT_FAILED
);

our ($VERSION, $HEADER);

#Global variables used in whole module
my($sVTT_Initialize); #Global variables for module 
my $module_name = __PACKAGE__;
my @devices; # Array containing the devices used for this setup

my $power_device; # Holds the name of power device, ex:: NIDAQ and TOE1
my $measurement_device; # Holds the name of measurement device, ex:: NIDAQ 
our %Diagnosis; #Holds information generated from pre and post diagnosis action 
my $error_flag = 0; #Flag will set to 1 if the result is fail

#Constant variables used in whole module
Readonly my $SVTT_FAILED => -1000; #failed checking condition
Readonly my $SVTT_SUCCESS => 1; #success condition
Readonly my $SCALAR_FACTOR => 10**6; # allow time samples until 0.000001s / 1us

my $DSO_settings; 

=head1 NAME

 FuncLib_sVTT 

=head1 DESCRIPTION

 This module is used for performing stochastic Voltage Temperature Test(sVTT) from TurboLiFT.

=head1 SYNOPSIS

    SVTT_init();
    SVTT_ClearFaultMemory( outputChannel);
    SVTT_PerformDiagnosis(curve_name, 'AO0','pre', ecu_labels_aref, check_label_aref);
    SVTT_Reset();
    SVTT_ExecuteCurve($duration);
    SVTT_Reset();
    SVTT_PerformDiagnosis(curve_name, 'AO0','pre', ecu_labels_aref, check_label_aref);
    SVTT_PrepareCurve($curve_name);
    SVTT_Reset();
    SVTT_exit();

=head2 Project Configuration

$Defaults = {
			'VTT' => {
				#Hardware Devices Required to perform an action 
				'Devices' => ['power', 'temperature','diagnosis'],
					#This section is used for controlling the diagnosis action before and after execution of each curve
					'Sequence_Control' => {
							'U_Diag' => 10,  # in volt; negative numbers mean: voltage of last Point of previous curve used for Diag
							't_Diag'  => 10,  # in seconds (new parameter which indicates time after curve start when can the diagnosis be performed during curve)
							'Diag_wait' => 2,  # in seconds, time to wait after curve output (U=U_diag) before trying diagnosis
							'Reset_time' => 2,  # in seconds
						},
				'Curve_Controls' => {
                                    'U_min' => 0,  # in volt , lower voltage limit
                                    'U_max' => 30,  # in volt , upper voltage limit 
                                },
			},	
			'NIDAQ' => {
				'ChannelNames'    => ['AO0'],  # Channel Names for acquisition
			},
    }; 
	
=head2 Testbench Configuration

    ### ----------- Device Configuration Section -----------
    'Devices' => {
       'PD' => {
            'Hostname' => 'BMH1019669',
            'CANchannel' => 1,
            'CANHWSerialNo' => 28766,
        },
       'NIDAQ' =>{
                    'Device_ID' =>"M6251",      # Devices can be :: NI-DAQmx (and M6251 for old setups, new setups should only use the generic name)
                    'Channel_Name' =>['AO0'], # channel number(s) used for communication, Channel names can be: AO0  and AO1
                    'Amplifier' => "Servowatt",  # Amplifiers can be: Servowatt and TOE7621_32
                    'channel_input_divider' => "no_divider", # can be divider and no_divider
        },
    'TOE1' => {
            'connect' => 'GPIB:8',
        },
    'VOETSCH' => {
            'connect' => 'COM6',
        },
    'DTM5080' => {
            'connect' => 'COM6',
        },    
    }, ## end of ~~~ Device Configuration Section ~~~
    ### ----------- Function Configuration Section -----------
    'Functions' => {
        ### --- Function Area : Power, select device the power functions will be mapped to TSG4, MLC, TOE1, NIDAQ, IDX, IXS, GOS1, NONE
         'Labcar' => {
                    'power_Ubat' => 'NONE', # possible devices: TSG4, MLC, TOE1, NIDAQ, IDX, IXS, GOS1, NONE
					'measure_trace_analog' =>  'NIDAQ', #possible device : NIDAQ
                      },
        ### --- Function Area : Temperature, select device where ECU is connected to (VOETSCH, DTM5080)
         'Temperature' => {
                        'get'     =>   'VOETSCH', # possible devices: VOETSCH , DTM5080
                    },
       ### --- Function Area : Peripherie, select device where ECU is connected to (PeriBox or LabCar or TSG4)
        'PERIPHERIE' => {
            'device' => 'LabCar',
        }
    }, ## end of ~~~ Function Configuration Section ~~~

=head2 Configuration file

   our $sVTTCurve_file_path = 'D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\Tools\sVTT_Curves'; #All VTT Curves are maintained here - Absolute path of sVTT_Curves folder

   our $SAD_file = 'D:\Projects\PD_AB12_Testing\PD_DLL\PD_Control\AB1200_BB00000_B12_Cat2_20130830.sad'; #Absolute path of SAD file related to ECU used for Project

=head2 Hardware Pictures

=for html
<IMG SRC='..\..\pics\sVTT\Voetsch.png'  alt="Voetsch Oven picture" border="0">
<br/><I><B><caption align = "centre">Voetsch Oven</caption></B></I>
<br/>
<IMG SRC='..\..\pics\sVTT\NIDAQ_M.png'  alt="NIDAQ M-Series picture" border="0">
<br/><I><B><caption align = "centre">NIDAQ M-Series</caption></B></I>

=cut

=head1 Exported Subroutines

=head2 SVTT_ClearFaultMemory

    $status = SVTT_ClearFaultMemory( $outputChannel );

- Reads the Diag_wait and U_Diag from project defaults. 

- It sets the NIDAQ voltage to U_Diag on given channel $outputChannel.

- Waits for Diag_wait time. 

- Clears Fault memory.

B<Arguments:>

=over

=item $outputChannel 

volt source output channel where the voltage curve will be injected

=back

B<Return Value:>

=over

=item $status 

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

    SVTT_ClearFaultMemory('AO0');
    
=cut

sub SVTT_ClearFaultMemory
{
	my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_ClearFaultMemory( $outputChannel )', @args );    
    my $outputChannel = shift @args; # volt source output channel where the voltage curve will be injected
    
    my $diag_waitTime = $main::ProjectDefaults->{'VTT'}{'Sequence_Control'}{'Diag_wait'};
	my $diag_voltage = $main::ProjectDefaults->{'VTT'}{'Sequence_Control'}{'U_Diag'};
    
    unless(defined $diag_waitTime)
    {
        S_set_error("No Diag_waitTime is configured in project defaults in {'VTT'}{'Sequence_Control'}{'Diag_wait'} \n",20);
        return $SVTT_FAILED;
    }

    unless(defined $diag_voltage)
    {
        S_set_error("No Diag_voltage is configured in project defaults in {'VTT'}{'Sequence_Control'}{'U_Diag'} \n",20);
        return $SVTT_FAILED;
    }
	
    S_w2log(1, "SVTT_ClearFaultMemory Output_Channel ::$outputChannel \n");
    S_w2log(1, "SVTT_ClearFaultMemory Diag_voltage ::$diag_voltage \n");
    
    unless( SVTT_SetVoltage($diag_voltage, $outputChannel) ) 
    { 
    S_set_error("Failed to set the voltage to U_Diag on given channel outputChannel \n"); 
    return; 
    }
    # wait for diagnosis 
    S_wait_ms( $diag_waitTime * 1000 ); # diag wait time is provided in seconds

    # Erase Fault memory
    unless( PD_ECUlogin() ) 
    { 
    S_set_error("PD_ECUlogin :: ECU login failed \n"); 
    return; 
    }
    
    unless( PD_ClearFaultMemory() ) 
    { 
    S_set_error("PD_ClearFaultMemory :: Clearing fault memory failed \n"); 
    return; 
    }
    
    return $SVTT_SUCCESS;
}

=head2 SVTT_Evaluation

    $status = SVTT_Evaluation(curveName, [flt_mand_aref, flt_opt_aref]);

This function checks the mandatory/optional faults from generated fault structure.

It does : 

- ECU Label checking, Generate HTML tables structure with following points.

- Read Faults, Mandatory faults, optional faults, ECU label check and ECU lable names of Pre and Post diagnosis tables. 

- Curve name and temperature as another table.

B<Arguments: Mandatory>

=over

=item $curveName 

Name of the Curve 

=back

B<Arguments: Optional>

=over

=item $flt_mand_aref 

Mandatory faults to check for availability

=item $flt_opt_aref  

Optional faults to check for availability
 
=back

B<Verdict Setting>

I<VERDICT_FAIL>

i. Expected mandatory faults are not found during pre or post diagnosis

ii. Temperature return from oven is -9999

iii. Not satisfy the condition given in any of given check labels comparison.

I<VERDICT_PASS>

All expected faults occurs, temperature from oven is other than -9999 and satisfys all the conditions given for check lables.

B<Return Value:>

=over

=item $status 

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

  SVTT_Evaluation('AUDI_lv124_e_01_long_term_over_voltage', ['FltSystemAsic1CfgMismatch','FltInertParameterSet','FltCoSigShort2GND'],['FltBAOffAShort2GndOrOpen','FltBAOnAShort2GndOrOpen']);
    
=cut

sub SVTT_Evaluation
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_Evaluation ( $curveName, [ $flt_mand_aref , $flt_opt_aref ] )', @args );    
    my $curveName = shift @args;
    my $flt_mand_aref = shift @args;
    my $flt_opt_aref = shift @args;
    
    my ($temperature, $pre_mand_fail, $post_mand_fail, $pre_opt_fault_not_avail, $post_opt_fault_not_avail); 

    S_w2log(1, "SVTT_Evaluation \n");

    #Checking for Initialization of sVTT
    unless($sVTT_Initialize)
    {
       S_set_error( " SVTT is not Initialized \n" , 120);
       return $SVTT_FAILED;
    }

    #Start of Input params checking
    #Mandatory faults related check conditions    
    unless(defined $flt_mand_aref)
    {
        S_set_error("No Mandatory fault are given to evaluate \n",0);
    }
    if(defined $flt_mand_aref)
    {
        my $temp = scalar(@$flt_mand_aref);
        if($temp == 0)
        {
            S_set_error("flt_mand_aref is an empty \n",114);
            return $SVTT_FAILED;
        }
    }

    #Optional faults related check conditions    
    unless(defined $flt_opt_aref)
    {
        S_set_error("No optional fault are given to evaluate \n",0);
    }
    
    if(defined $flt_opt_aref)
    {
        my $temp = scalar(@$flt_opt_aref);
        if($temp ==  0)
        {
            S_set_error("flt_opt_aref is an empty \n",114);
            return $SVTT_FAILED;
        }
    }
    #End of Input params checking

    #Reading temperature from chamber\ oven    
    if(grep {$_ =~ /^temperature$/ix} @devices)
    {
     $temperature = TEMP_get_temperature() || return;
     S_w2log(1, "Temperature read from oven/chamber :: $temperature \n");
    }
    else
    {
      S_w2log(1, "Temperature device is not provided in project constants \n");
      $temperature = 'No Temperature device to read the value';
    }
    $curveName =~ s/(.sat|.svtc)$//; #remove file extn from curve name and print in HTML
    #####Creation of HTML table
       #CurveName and Temperature
    push( @TC_HTML_TEXT, join ('','<div class="w2rep ',$module_name,'"><TABLE class="tablesorter">',
    '<tr align="center">',
        '<th bgcolor= #008000>CurveName</th>',
        '<th bgcolor= #9ACD32>Temperature(<sup>o</sup>C)</th>',
    '</tr><tr>',
        '<td>',$curveName,'</td>',
        '<td>',$temperature,'</td>',
    '</tr></TABLE></div>',"\n"));
    S_add2eval_collection( 'TEMPERATURE' , $temperature );
    #Evaluation of faults
    
    unless( SVTT_Eval_Fault_content($curveName, $flt_mand_aref, $flt_opt_aref))
    {
    S_set_error("Eval Fault Content Failed \n");
    return;
    }

    #PRE and POST Diagnosis Tables
    unless( SVTT_Evaluation_Table_Creation())
    {
    S_set_error("Evaluation Table Creation Failed \n");
    return;
    }
    
    $pre_mand_fail  = $Diagnosis{'PRE'}{'MAND_FAIL'};
    $post_mand_fail = $Diagnosis{'POST'}{'MAND_FAIL'};
    $pre_opt_fault_not_avail = $Diagnosis{'PRE'}{'OPT_NOT_AVAIL'};
    $post_opt_fault_not_avail = $Diagnosis{'POST'}{'OPT_NOT_AVAIL'};
	
	
    if( (defined (@$post_mand_fail) && (scalar(@$post_mand_fail) > 0)) || ( defined (@$pre_mand_fail) && (scalar(@$pre_mand_fail) > 0) ) || ($temperature == -9999) || ($error_flag == 1))
    {
		S_set_verdict(VERDICT_FAIL);
    }
    else
    {
        S_set_verdict(VERDICT_PASS);
    }
    %Diagnosis = ();
	$error_flag = 0;
    return $SVTT_SUCCESS;
}

=head2 SVTT_PerformDiagnosis

    $status = SVTT_PerformDiagnosis(curveName, outputChannel, action, [ecu_labels_aref, check_labels_aref]);

Diagnosis actions performed during I<POST> and I<PRE> 

1. Reading of information of ECU for given label\address.

2. Reads fault memory information from ECU.

3. Perform checking operation of information from ECU read for given labels based on expected values and operator.

4. Dumps the EEPROM data into a hex file.

5. Clears fault memory information in ECU.

6. Reads 'ECU power on time' during PRE diagnosis action only.


B<Arguments: Mandatory>

=over

=item $curveName

Name of the Curve

=item $outputChannel 

Output channel of voltage source where the voltage curve will be available.

=item $action 

Flag to hold all diagnosis action(PRE and POST) 

=back

B<Arguments: Optional>

=over

=item $ecu_labels_aref 

ECU labels or address array reference

=item $check_labels_aref 

ECU check labels or address array reference 

=back

B<Return Value:>

=over

=item $status 

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

   SVTT_PerformDiagnosis('AUDI_lv124_e_01_long_term_over_voltage', 'AO0', 'PRE',['V_SpiTFFDevice_U8R','V_SpiTFFError_U8R'],['V_SpiTFFDevice_U8R|!=|0x10','V_SpiTFFError_U8R|==|0x11']);
   
   SVTT_PerformDiagnosis('AUDI_lv124_e_01_long_term_over_voltage', 'AO0', 'POST',['V_SpiTFFDevice_U8R','V_SpiTFFError_U8R'], ['V_SpiTFFDevice_U8R|!=|0x10','V_SpiTFFError_U8R|==|0x11']); 
                        
   SVTT_PerformDiagnosis('AUDI_lv124_e_01_long_term_over_voltage', 'AO0', 'PRE');

   SVTT_PerformDiagnosis('AUDI_lv124_e_01_long_term_over_voltage', 'AO0', 'POST');
   
=cut

sub SVTT_PerformDiagnosis
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_PerformDiagnosis ( $curveName, $outputChannel, $action, [$ecu_labels_aref, $check_labels_aref] )', @args );    
    my $curveName = shift @args;
    my $outputChannel = shift @args; # volt source output channel where the voltage curve will be injected
    my $action = shift @args;#The variable holds the 'PRE' and 'POST' words.
    my $ecu_labels_aref = shift @args; #This read the label names which are given as testcase parameters
    my $check_labels_aref = shift @args; ## Will be done

    my ($diag_waitTime, $diag_voltage) = undef;

    $diag_waitTime = $main::ProjectDefaults->{'VTT'}{'Sequence_Control'}{'Diag_wait'};
    $diag_voltage = $main::ProjectDefaults->{'VTT'}{'Sequence_Control'}{'U_Diag'};
    
    unless($sVTT_Initialize)
    {
       S_set_error( " sVTT is not Initialized \n" , 120);
       return $SVTT_FAILED;
    }

    unless(($action =~ /^pre$/ix) || ($action =~ /^post$/ix))
    {
        S_set_error("Action flag should be either PRE or POST \n",114);
        return $SVTT_FAILED;
    }

    unless ($curveName =~ /(.sat|.svtc)$/)
    {
        S_set_error("$curveName should be either .sat or .svtc file format \n",114);
        return $SVTT_FAILED;    
    }

    $action = uc($action); #To maintain consistency converting whole word to upper case

    $curveName = $1 if $curveName =~ /^(.+?)(.sat|.svtc)$/i;#remove file extn while logging into report

    S_w2log(1, "SVTT_PerformDiagnosis ::$curveName  - $action \n");

    unless(defined $diag_waitTime)
    {
        S_set_error("No Diag_waitTime is configured in project defaults in {'VTT'}{'Sequence_Control'}{'Diag_wait'} \n",20);
        return $SVTT_FAILED;
    }

    unless(defined $diag_voltage)
    {
        S_set_error("No Diag_voltage is configured in project defaults in {'VTT'}{'Sequence_Control'}{'U_Diag'} \n",20);
        return $SVTT_FAILED;
    }

    S_w2log(1, "SVTT_PerformDiagnosis Output_Channel ::$outputChannel \n");
    S_w2log(1, "SVTT_PerformDiagnosis Diag_voltage ::$diag_voltage \n");
    unless ( SVTT_SetVoltage($diag_voltage, $outputChannel))
    {
        S_set_error(" Setting Voltage with U_diag failed \n");
        return; 
    }

    # wait for diagnosis 
    S_wait_ms( $diag_waitTime * 1000 ); # diag wait time is provided in seconds
    unless ( PD_ECUlogin() )
    {
        S_set_error (" PD_ECUlogin :: ECU Login Failed \n");
        return;
    }
    # read label values, if given
    if(defined $ecu_labels_aref)
    {
        unless(ref $ecu_labels_aref eq 'ARRAY')
        {
            S_set_error( "ecu_Labels_aref should be an ARRAY reference \n",114);
            return ($SVTT_FAILED);
        }

        my $temp = scalar(@$ecu_labels_aref);
        if($temp == 0)
        {
           S_set_error( "ecu_Labels_aref is an empty array \n",114);
           return ($SVTT_FAILED);
        }

        $Diagnosis{$action}{'ECU_lables'} = SVTT_ReadLabels($ecu_labels_aref) || return;
    }

    #Checking lables information 
    if(defined $check_labels_aref)
    {
        unless(ref($check_labels_aref) eq 'ARRAY')
        {
            S_set_error("check_labels_aref should be an ARRAY reference \n",114);
            return $SVTT_FAILED;
        }

        my $temp = scalar(@$check_labels_aref);
        if( $temp == 0)
        {
            S_set_error("check_labels_aref is an empty array \n",114);
            return $SVTT_FAILED;
        }

        # split the ECU labels which are variables and perfrom checking operation
        foreach my $checkdata (@$check_labels_aref)
        {
           my @check_label_data = split(/\|/, $checkdata);

           if(scalar(@check_label_data) != 3)
           {
               S_set_error("Structure of check labels should be :: ('label|operator|expectedvalue','label|operator|expectedvalue')\n ", 114);
               return $SVTT_FAILED;
           }

           unless( grep {/^$check_label_data[1]$/i} '==' , '!=' , '>=' , '<=' , '<' , '>' , 'MASK')
           {
            S_set_error( "unknown operator: $check_label_data[1]", 114 );
            return $SVTT_FAILED;
           }

           if($check_label_data[2] !~ /^0x[0-9a-f]+/i)
           {
            S_set_error("Expected value should be in hexa decimal format. Ex: 0x12ad34 \n ", 114);
            return $SVTT_FAILED;
           }
        }
        $Diagnosis{$action}{'CHECKLABLE'} = SVTT_CheckLabels($check_labels_aref) || return;
    }

    # read fault memory
	# S_user_action ( 'read fault mem', 'Ok');
    my $fltMem = PD_ReadFaultMemory() || return;
    $Diagnosis{$action}{'fault_text'} = $fltMem->{'fault_text'};
    S_wait_ms( 1000 ); # diag wait time is provided in seconds
	# S_user_action ( 'fault mem read', 'Ok');

    # prepare eeprom dump folder
    # my @timestamp = S_formated_timestamp();
    # my $timestamp_file_path = $timestamp[0] . $timestamp[1];
    # $timestamp_file_path =~ s/[.:]//ig;
    # my $newfilepath = $main::save_name . "\\eeprom_dump" ;

    # create eeprom dump folder only if it doesnot exists
    # unless (-d $newfilepath) {
        # mkdir $newfilepath;
    # }

    # read eeprom
    # my $hexfile = $curveName . '_'.$action.'Curve_'.$timestamp_file_path.'.hex' ; # file name for eeprom dump
    # my $eeprom_hexfile = $newfilepath .'/'. $hexfile ;

    # PD_DumpEEPROM($eeprom_hexfile);
    # S_w2rep('<a href="./eeprom_dump/'.$hexfile.'">EEPROM File '.$hexfile.'</a><br>');

    # Erase Fault memory
    unless( PD_ClearFaultMemory())
    {
        S_set_error("PD Clear Fault memory Failed \n");
        return;
    }

    # Read runtime counter only during pre-diagnosis action
    # if($action =~ /pre/i )
    # {
        # my $ecu_poweron_time = PD_Read_PowerOnTime();
        # my $text = '';
        # if($ecu_poweron_time == 0xffffffff)
        # {
            # $text = "- Invalid";
        # }
        # elsif ($ecu_poweron_time == 0xfffffffe)
        # {
            # $text = "- Diag Error";
        # }
        # else
        # {
            # $text = sprintf("- %02d:%02d:%02d", $ecu_poweron_time/3600, ($ecu_poweron_time/60)%60, $ecu_poweron_time%60);
        # }
        # S_w2rep('ECU Power ON Time '. $text );
    # }
    return $SVTT_SUCCESS;
}

=head2 SVTT_SetVoltage

    $status = SVTT_SetVoltage(diag_voltage, [outputChannel]);

To set voltage for diagnosis.

B<Arguments: Mandatory>

=over

=item $diag_voltage

The voltage that needs to be set.

=back

B<Arguments: Optional>

=over

=item $outputChannel 

Output channel of voltage source where the voltage curve will be available.

=back

B<Return Value:>

=over

=item $status 

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

   SVTT_SetVoltage(10, 'AO0');
   
=cut

sub SVTT_SetVoltage
{
      
      my @args = @_;
      return 0 unless S_checkFunctionArguments( 'SVTT_SetVoltage( $diag_voltage ,[ $outputChannel ] )', @args );    
      my $voltage = shift @args;
      my $channel_name = shift @args;
      
      S_w2log(1, "SVTT_SetVoltage \n");
      unless ( LC_SetVoltage($voltage) )
      {
         S_set_error(" Failed to set the voltage to U_Diag on given channel outputChannel. \n"); 
         return $SVTT_FAILED; 
      }
      return $SVTT_SUCCESS;
}

=head2 SVTT_exit

    $status = SVTT_exit();
    
Terminates the communication and releases all hardware devices and resets the flag. 

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $status 

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

   SVTT_exit();
   
=cut

sub SVTT_exit
{
    S_w2log(1, "SVTT_exit \n");
    unless($sVTT_Initialize)
    {
       S_set_error( " sVTT is not Initialized \n" , 120);
       return $SVTT_FAILED;
    }

    if(grep {$_ =~ /^diagnosis$/ix} @devices) #Production Diagnosis Closing
    {
        unless( PD_CloseDiagnosis()) 
        {
            S_set_error(" Production Diagnosis Closing failed \n");
            return;
        }
    }
     if(grep {$_ =~ /^temperature$/ix} @devices) #TemperatureChamber/Oven Closing 
    {   
        
        unless( TEMP_exit() ) 
        {
            S_set_error(" Temperature Chamber or Oven Closing failed \n");
            return;
        }
    }     
    if(grep {$_ =~ /^power$/ix} @devices)  #Power Device Closing
    {
        unless( LC_PowerDisconnect())
        {
            S_set_error(" Power Device Disconnecting failed \n");
            return;
        }
        unless( LC_Exit() )
        {
            S_set_error(" Lab Car Exit failed \n");
            return;
        }
        
    }

    $sVTT_Initialize = 0; #Reset the Flag of Initialization

    return $SVTT_SUCCESS;
}

=head2 SVTT_init

    $status = SVTT_init();
    
- Initializes the communication with all required hardware devices.

- Check the BB number within ECU and SAD file and set the flag. 

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $status 

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

   SVTT_init();
   
=cut
sub SVTT_init
{
    S_w2log(1, "SVTT_init \n");
	
    if($sVTT_Initialize)
    {
       S_set_warning( " sVTT is already Initialized \n" , 120);
       return 1;
    }

    @devices = @{$main::ProjectDefaults->{'VTT'}{'Devices'}};
	
    my $temp = scalar(@devices);
    if( $temp == 0)
    {
        S_set_error("No devices to do Initilialization of sVTT \n",114);
        return $SVTT_FAILED;
    }
    $power_device = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'power_Ubat'};
	$measurement_device = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'measure_trace_analog'};
	
    print "Power Device : $power_device\n"; 
    
    unless(defined $power_device)
    {
        S_set_error("Device ' ' is configured in LIFT_Testbenches for 'labcar -> power_Ubat', but it is not supported for 'labcar -> power_Ubat'. Supported devices are: GOS1 IXS NIDAQ TOE1 TSG4 NONE MLC IDX",20);
        return $SVTT_FAILED;
    }
    
    my $diag_voltage = $main::ProjectDefaults->{'VTT'}{'Sequence_Control'}{'U_Diag'};
	    
	if(grep {$_ =~ /^power$/ix} @devices)
    {
        unless( LC_Init() ) #Initialization of power device given in testbench configuration
        {
            S_set_error(" Initialization of power device - LC_init failed \n");
			return;
        }
        unless( LC_PowerConnect() )
        {
            S_set_error(" Initialization of power device - LC_PowerConnect failed \n");
            return;
        }
		unless( LC_SetVoltage( $diag_voltage ) )   # set voltage
        {
            S_set_error(" Initialization of power device - LC_SetVoltage failed \n");
            return;
        }
		 
		
		my $read_back_voltage = LC_GetVoltage(); 
		S_w2rep("Voltage set : $diag_voltage\nRead back voltage : $read_back_voltage\n");
		
		if ( (abs( LC_GetVoltage() - $diag_voltage ) gt 0.5 ) && ( $main::opt_offline ne 1 ) ) #check if input voltage is same as the set voltage 
		#0.5 difference value chosen to give tolerance value of reading back the analog voltage 
		{
		    S_set_error(" Self-protection check for wrong amplifier configuration failed. Check the amplifier configured. \n");
            return;
        }		
        
    }

    if(grep {$_ =~ /^temperature$/ix} @devices)    #TemperatureChamber/Oven Initialization
    {
        unless( TEMP_init() )
        {   
            S_set_error(" TemperatureChamber or Oven Initialization failed \n");
            return;
        }
    }

    if(grep {$_ =~ /^diagnosis$/ix} @devices)
    {
        unless( PD_InitDiagnosis() )    #Production Diagnosis Initialization
        {   
            S_set_error(" Production Diagnosis Initialization failed \n");
            return;
        }
        my $swversion = PD_InitCommunication() || return ; #Production Diagnosis Communication
        S_w2rep("ECU SW Version : $swversion \n");

        S_w2log(1,"BB number check is performing..... \n");
       # PD_BBCheck();
        S_w2log(1,"BB number check is finished \n");
    }
	
	
	$sVTT_Initialize = 1;  # Setting flag of Initialization

    return $SVTT_SUCCESS;
}

=head2 SVTT_PrepareCurve

    ( $status, $DSO_settings, $duration ) = SVTT_PrepareCurve(curve_name);
    
- Loads the curve to defined power supply in project constants.

- Makes DSO Settings for the curve (In case of .sat curve files)

B<Arguments:>

=over

=item $curve_name

curve_name to load the curve into power supply

=back

B<Return Value:>

=over

=item $status, $DSO_settings, $duration 

$SVTT_SUCCESS(1), DSO Settings ( Has a value only in case of .sat curves, is empty otherwise ), $duration of curve  ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

       ( $status, $DSO_settings, $duration ) = SVTT_PrepareCurve(AUDI_lv124_e_01_long_term_over_voltage.svtc);		
   
B<Notes:>   
Sample DSO_settings : 
		DSO_settings = {
						"Volt"=>"10V",
						"Time"=>"5S",						
						}
   
=cut

sub SVTT_PrepareCurve
{
   my @args = @_;
   return 0 unless S_checkFunctionArguments( 'SVTT_PrepareCurve( $curve_name )', @args );   
   my $curve_name = shift @args;
      
   my ($curve_file_path, $temperature);

    unless($sVTT_Initialize)
    {
       S_set_error( " sVTT is not Initialized \n" , 120);
       return $SVTT_FAILED;
    }

    my $curve_name_copy = $curve_name;
    $curve_name_copy =~ s/(.sat|.svtc)$//; #remove the extn .sat or .svtc

    S_w2log(1, "SVTT_PrepareCurve :: $curve_name_copy\n");
    $curve_file_path = $main::save_name."\\sVTT_Curves\\".$curve_name;
   
    unless(-e $curve_file_path)
    {
       S_w2log( 1, " Curve file '$curve_file_path' doesnot exists. Checking in the path configured in CFG file. \n");
       my $temp_path = $LIFT_config::sVTTCurve_file_path;
       {
			
            $curve_file_path = $LIFT_config::sVTTCurve_file_path.'/'.$curve_name;
       }
        #Checking for file existance again
        unless(-e $curve_file_path)
       {
           S_set_error( " Given Curve file '$curve_file_path' doesnot exists \n" , 1);
           return $SVTT_FAILED;
        }
    }

    #Checking if file is empty    
    if(-z $curve_file_path)
    {
        S_set_error("No lines to read in given Curve file :: '$curve_file_path' \n", 5);
        return $SVTT_FAILED;
    }

    #Reading temperature from chamber\ oven    
    if(grep {$_ =~ /^temperature$/ix} @devices)
    {
     $temperature = TEMP_get_temperature() || return;
     S_w2log(1, "Temperature read from oven/chamber before curve execution :: $temperature \n");
    }
    else
    {
      S_w2log(1, "Temperature device is not provided in project constants \n");
      $temperature = 'No Temperature device to read the value';
    }

    #####Creation of HTML table
       #CurveName and Temperature
    push( @TC_HTML_TEXT, join ('','<div class="w2rep ',$module_name,'"><TABLE class="tablesorter">',
    '<tr align="center">',
        '<th bgcolor= #9ACD32>Temperature(<sup>o</sup>C)</th>',
    '</tr><tr>',
        '<td>',$temperature,'</td>',
    '</tr></TABLE></div>',"\n"));

    # Initialization of arbitrary
	my ( $duration, $u_min, $u_max ) = LC_PowerConfigCurve($curve_file_path);
	
	if ( defined ( $u_min ) && defined ( $u_max ) && defined ( $duration ) )
	{
		#Horizontal division of time : 10 divisions per screen. 
		#Vertical division of voltage : 8 divisions per screen. 
		my $volt_for_dso_settings = 1; #cannot be zero
		my $time_for_dso_settings = 1;	
		$volt_for_dso_settings = ceil( ( ( $u_max - $u_min ) / 8 ) )*5 ; #rounding off to next number 
		$time_for_dso_settings = ceil( $duration / 10 );	
		my $volt_len = length $volt_for_dso_settings;
		my $time_len = length $time_for_dso_settings;
		
		if( $volt_len == 1) { $volt_for_dso_settings = check_range($volt_for_dso_settings,2,5); }
		if ( ( $volt_len == 2) || ( $volt_len == 3) ) { $volt_for_dso_settings = check_range($volt_for_dso_settings,10,10); }
				
		if( $time_len == 1) { $time_for_dso_settings = check_range($time_for_dso_settings,2,5); }
		if( $time_len == 2) { $time_for_dso_settings = check_range($time_for_dso_settings,20,50); }
		if( $time_len == 3) { $time_for_dso_settings = check_range($time_for_dso_settings,200,500); }
		
		
		$DSO_settings = {"Volt" => $volt_for_dso_settings."V", "Time" => $time_for_dso_settings."S" };		
	
	}
	
	return ( $SVTT_SUCCESS, $DSO_settings, $duration );
}

=head2 check_range

    $parameter = check_range (parameter , min_value , max_value );
    
This function checks if the input parameter is in the range of min and max values being passed and returns the updated max value. 

B<Arguments: Mandatory>

=over

=item parameter 

Scalar Value 

=item min_value 

Lower limit for the range  

=item max_value 

Upper Limit for the range

=back

B<Return Value:>

=over

=item $parameter 

Updated parameter value

=back

B<Examples:>

	$time_for_dso_settings = check_range($time_for_dso_settings,2,5)
   
=cut

sub check_range
{
	my ( $param, $min, $max );
	$param = shift;
	$min= shift;
	$max= shift;
	my @allowed_values = ( 1,2,5,10 );
	if ( $param ~~ @allowed_values ){ return $param; }
	
	if( ( ( $param > $min )  && ( $param < $max ) ) || ( $param >= $max ) ){
		$param = $max;
	}
	if ( ( $param <= $min ) )
	{
		$param = $min; 
	}
	return $param;
}

=head2 SVTT_ExecuteCurve

    $status = SVTT_ExecuteCurve($duration);
    
- If power supply is NIDAQ - Corresponding functions in Labcar for it is called : Init, start and stop Arbitrary are performed.

- If power supply is TOE1 - Corresponding functions in Labcar for it is called  : Init arbitrary, run and stop the curve are performed in Labcar

B<Arguments:>

=over

=item $duration 

Time for which the curve has to be executed.

=back

B<Return Value:>

=over

=item $status

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

	SVTT_ExecuteCurve(5.0);	

=cut

sub SVTT_ExecuteCurve
{	
	my ($temperature, $duration);
	my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_ExecuteCurve( $duration )', @args );   
    $duration = shift @args;
		
	#Start execution of arbitrary
	unless ( LC_PowerStartCurve() )
    {
    	S_set_error ( " Starting the Curve Failed \n");
        return;
    }
    
    S_w2log(1, "The arbitrary is going to run for the duration of ($duration) seconds \n"); 
    S_wait_ms( $duration * 1000 );
	#S_wait_ms used for the curve to finish fully before we call the stop curve.
             
    #After execution of arbitrary - Stop arbitrary
    unless ( LC_PowerStopCurve() )
    {
        S_set_error ( " Stopping the Curve Failed \n");
        return;
    }
    

    #Reading temperature from chamber\ oven    
    if(grep {$_ =~ /^temperature$/ix} @devices)
    {
     $temperature = TEMP_get_temperature() || return ;
     S_w2log(1, "Temperature read from oven/chamber after curve execution :: $temperature \n");
    }
    else
    {
      S_w2log(1, "Temperature device is not provided in project constants \n");
      $temperature = 'No Temperature device to read the value';
    }

    #####Creation of HTML table
       #CurveName and Temperature
    push( @TC_HTML_TEXT, join ('','<div class="w2rep ',$module_name,'"><TABLE class="tablesorter">',
    '<tr align="center">',
        '<th bgcolor= #9ACD32>Temperature(<sup>o</sup>C)</th>',
    '</tr><tr>',
        '<td>',$temperature,'</td>',
    '</tr></TABLE></div>',"\n"));
	
	return $SVTT_SUCCESS;

}

=head2 SVTT_Reset

    $status = SVTT_Reset();
    
It sets the voltage of power device to zero and waits for reset_time (given in project constants) seconds.

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $status

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

	SVTT_Reset();

=cut

sub SVTT_Reset
{
    my $reset_time = $main::ProjectDefaults->{'VTT'}{'Sequence_Control'}{'Reset_time'};

    S_w2log(1,"SVTT_Reset \n");

    unless(defined $reset_time)
    {
        S_set_error("Reset_time is missing in Project Constants \n",20);
        return $SVTT_FAILED;
    }

    unless ( SVTT_SetVoltage(0) ) 
    {
        S_set_error(" Setting with Voltage zero failed \n");
        return;
    }

    S_wait_ms($reset_time*1000, "$power_device Reset in progress...");
    S_w2log(1, "Reset done... \n");

    return $SVTT_SUCCESS;
}


=head2 SVTT_StartMeasurement

    $status = SVTT_StartMeasurement();
    
It starts the Voltage Curve Measurement.

B<Arguments:>

=over

=item None

=back

B<Return Value:>

=over

=item $status

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

	SVTT_StartMeasurement();

=cut

sub SVTT_StartMeasurement
{
    S_w2log( 1, "SVTT_StartMeasurement \n" );
    if ( $measurement_device eq 'NIDAQ' && $power_device eq 'NIDAQ' ) {
        unless ( LC_ConfigureChannels() ) {
            S_set_error(" Start Measurement - LC_ConfigureChannels failed \n");
            return $SVTT_FAILED;
        }
        unless ( LC_MeasureTraceAnalogStart() ) {
            S_set_error(" Start Measurement - LC_MeasureTraceAnalogStart failed \n");
            return $SVTT_FAILED;
        }
        unless ( LC_MeasureTraceAnalogSendSWTrigger() ) {
            S_set_error(" Start Measurement - LC_SendSWTrigger failed \n");
            return $SVTT_FAILED;
        }
        S_w2log( 1, "Measurement started... \n" );
    }
    else {
        S_set_warning(" Measurement Device has not been configured to NIDAQ. Please configure 'labcar -> measure_trace_analog' in 'Functions' section of LIFT_Testbenches.\n ");
        return 1;
    }
    return $SVTT_SUCCESS;
}


=head2 SVTT_StopAndStoreMeasurement

    $status = SVTT_StopAndStoreMeasurement( $graphFilename );
    
It stops the already running Voltage Curve Measurement and stores the graph of read measurement in the reports folder.

B<Arguments:>

=over

=item graphFilename

The name for the graph to be stored. 

=back

B<Return Value:>

=over

=item $status

$SVTT_SUCCESS(1) ::  Success

$SVTT_FAILED(-1000) :: Failure

=back

B<Examples:>

	SVTT_StopAndStoreMeasurement($graphFilename);

=cut

sub SVTT_StopAndStoreMeasurement {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_StopAndStoreMeasurement($graphFilename)', @args );
    my $graphFilename = shift @args;

    S_w2log( 1, "SVTT_StopAndStoreMeasurement \n" );

    if ( $measurement_device eq 'NIDAQ' && $power_device eq 'NIDAQ' ) {
        unless ( LC_MeasureTraceAnalogStop() ) {
            S_set_error(" Stop Measurement - LC_MeasureTraceAnalogStop failed \n");
            return $SVTT_FAILED;
        }

        unless ( LC_MeasureTraceAnalogPlotValues($graphFilename) ) {
            S_set_error(" Store Measurement - LC_MeasureTraceAnalogPlotValues failed \n");
            return $SVTT_FAILED;
        }

        S_w2log( 1, "Measurement stopped and graphs archived... \n" );

    }

    else {
        S_set_warning(" Measurement Device has not been configured to NIDAQ. Please configure 'labcar -> measure_trace_analog' in 'Functions' section of LIFT_Testbenches.\n");
        return 1;
    }
    return $SVTT_SUCCESS;
}


=head1 Non_Exported Subroutines

=head2 SVTT_curve_file_read 

    NIDAQ Power supply
        ($samples,$time,$iteration,\@arbitrary_voltage) = SVTT_curve_file_read (sVTTCurve_file_path, CurveName);
    
    Tollener Power supply
        ($samples,$current,$iteration,\@arbitrary_voltage,\@arbitrary_time) = SVTT_curve_file_read (sVTTCurve_file_path, CurveName);    
    
B<Arguments:>

=over

=item sVTTCurve file path

Path of the file where the Curve is stored. 

=item Curve name

Name of the curve 

=back

B<Return Value:>

=over

=item On Success

NIDAQ Power supply

a. name - Curve name available in  svtc file

b. samples - Samples available in svtc file

c. iteration - Iteration value available in svtc file

d. time - Time value available in svtc file

e. \@arbitrary_voltage - Array reference of voltage values

Tollener Power supply

a. name - File name available in  sat file

b. samples - Samples available in sat file

c. iteration - Iteration value available in sat file

d. \@arbitrary_time - Array reference of time values

e. \@arbitrary_voltage - Array reference of voltage values

f. current - Current value in sat file 

=item On Failure

$SVTT_FAILED (-1000)

=back

B<Examples:>

	  NIDAQ Power supply
      (175036,1,0.0002, ['3.00','0.25']) = SVTT_curve_file_read ('D:\Sandbox\TurboLIFT\sVTT_Curves\AUDI_lv124_e_08_gradual_reduction_and_quick_increase_of_the_supply_voltage.svtc', 'AUDI_lv124_e_08_gradual_reduction_and_quick_increase_of_the_supply_voltage.svtc');

=cut

sub SVTT_curve_file_read
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_curve_file_read( $sVTTCurve_file_path, $curveName )', @args );   
    my $sVTTCurve_file_path = shift @args;
    my $curvename = shift @args;
    
    my $sVTTCurve_svtc_file_path = undef;

    S_w2log(1,"SVTT_curve_file_read \n");

    my($samples_curve, $iteration_curve, $time_curve, $current_curve);
    my ($arbitrary_voltage_aref, $arbitrary_time_aref) = ();

    $sVTTCurve_svtc_file_path = $sVTTCurve_file_path;
    ################# NIDAQ supported sVTC file parser #############################
    if($power_device eq 'NIDAQ')
    {
    	
        if($sVTTCurve_file_path !~ /.sat$/i)
        {
            unless ( ($samples_curve, $iteration_curve, $time_curve, $arbitrary_voltage_aref ) = SVTT_SVTC_Parser($sVTTCurve_file_path, $curvename) )
            {
                S_set_error( " SVTT SVTC Parser Failed for SVTC file $sVTTCurve_file_path for Power Device 'NIDAQ'. \n");
                return;
            }
            return ($samples_curve, $iteration_curve, $time_curve, $arbitrary_voltage_aref );
        }
        else
        # if .sat file used, then read from sat file & then resample the voltage values & save the file as .svtc
        {
            
           unless ( ( $samples_curve, $iteration_curve, $arbitrary_time_aref, $arbitrary_voltage_aref, $current_curve ) = SVTT_SAT_parser($sVTTCurve_file_path, $curvename) ) 
           {
                S_set_error( " SVTT SAT Parser Failed for SAT file $sVTTCurve_file_path for Power Device 'NIDAQ'. \n");
                return;
           }
            $time_curve= SVTT_Resample_Voltage ($arbitrary_voltage_aref, $arbitrary_time_aref) || return;
            $time_curve = sprintf("%.6f", $time_curve);
            my $counter = 0;
            my $index = 0;
            # save the contents from .sat file to .svtc
            $sVTTCurve_svtc_file_path =~ s/.sat/.svtc/i;

           open my $SATFH,'<',"$sVTTCurve_file_path";
           unless($SATFH)
           {
               S_set_error( "couldn't open $sVTTCurve_file_path\n", 21 );
               return 0;
           }

            my @satfh_ary = <$SATFH>;
            my $satfh_ary_aref = \@satfh_ary;
                       
            $counter = convert_sat_to_svtc( $sVTTCurve_svtc_file_path, $satfh_ary_aref, $arbitrary_voltage_aref, $arbitrary_time_aref, $time_curve) || return;
            close($SATFH);

            # on mismatch in the number of samples and voltage array length
            if( $counter != scalar(@$arbitrary_voltage_aref))
            {
                S_set_error( " Converted SVTC file '$sVTTCurve_svtc_file_path'  for curve '$curvename' doesnot contain the same number of voltage value(s) and samples \n" , 114);
                
                return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
            }

            return ($counter, $iteration_curve, $time_curve, $arbitrary_voltage_aref );
        }
   }

    ################# Toellner supported SAT file parser #############################    
    if($power_device eq 'TOE1')
    {
        if($curvename !~ /.svtc/i)
        {
            unless ( ($samples_curve,$iteration_curve,$arbitrary_time_aref,$arbitrary_voltage_aref,$current_curve) = SVTT_SAT_parser($sVTTCurve_file_path, $curvename) )
            {
                S_set_error( " SVTT SAT Parser failed for SAT file $sVTTCurve_file_path for Power Device 'TOE1'. \n");
                return;
            }
            return($samples_curve,$iteration_curve,$arbitrary_time_aref,$arbitrary_voltage_aref,$current_curve);
        }
        # ignore the curves which are specific to NIDAQ , .svtc files. It is not possible to run .svtc files in toellner
        else
        {
           S_set_error( "Executing arbitrary from SVTC file $sVTTCurve_file_path is not supported in Toellner  \n" , 114);
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }
    }

}

=head2 SVTT_SVTC_Parser 

    SVTT_SVTC_Parser (svtc_file_path, svtc_curvename);
	
Reads svtc file and returns the content of file.
    
B<Arguments:>

=over

=item svtc_file_path 

Absolute path of SVTC file

=item svtc_curvename 

Name of the curve which to be parsed

=back

B<Return Value:>

=over

=item On Success

a. svtc_samples - Number of samples available in svtc file

b. svtc_time - Time value available in svtc file

c. svtc_iteration - Iteration value available in svtc file

d. svtc_arbitrary_voltage - Array reference of voltage values 

=item On Failure

['-1000', '-1000', '-1000', '-1000']

=back

B<Examples:>

  (18055, 1, 0.2, ['13.50','13.50']) = SVTT_SVTC_Parser('D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\Tools\sVTT_Curves\LV124_e_01.svtc','LV124_e_01');

=cut

sub SVTT_SVTC_Parser
{

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_SVTC_Parser( $svtc_file_path, $svtc_curvename )', @args );   
    my $svtc_file_path = shift @args;
    my $svtc_curvename = shift @args;
    
    S_w2log(1,"SVTT_SVTC_Parser :: $svtc_curvename \n");
    my($svtc_name, $svtc_samples, $svtc_iteration, $svtc_time);
    my (@svtc_arbitrary_voltage, @svtc_arbitrary_time) = ();

   open (my $SVTCFH,'<',"$svtc_file_path");
   unless($SVTCFH)
   {
       S_set_error( "couldn't open $svtc_file_path\n", 21 );
       return 0;
   }

    my @SVTCFH_ary = <$SVTCFH>;
    close($SVTCFH);
    foreach my $line (@SVTCFH_ary)
        {
            chomp($line);
            if($line !~/^\s*$/x) # checking for an empty line
            {
               #Matching 'Curve Name : AUDI_lv124_e_01_long_term_over_voltage'
               if($line =~ /^Curve\s*Name :\s+(.+)/i)
                {
                    $svtc_name = $1;
                }
               #Matching 'Samples : 36060'
               elsif($line =~ /^Samples\s*:\s*(.+)/ix)
                {
                    $svtc_samples = $1;
                }
               #Matching 'Iteration : 1'
               elsif($line =~ /^Iteration\s*:\s+(.+)/ix)
                {
                    $svtc_iteration = $1;
                }
               #matching 'Time[s] : 0.1'
               elsif($line =~ /^Time\s*\[s\]\s*:\s*(.+)/ix)
                {
                    $svtc_time = $1;
                }
               else
                {
                  #Matching other than 'U[V]'
                  unless($line=~ /U\[V\]/ix)
                    {
                        chomp($line);
                        push(@svtc_arbitrary_voltage,$line);
                    }
                }
            }
        }

        unless(defined $svtc_name)
        {
           S_set_error( " SVTC file '$svtc_file_path' for curve '$svtc_curvename' doesnot contain the Curve Name \n" , 114);
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        unless(defined $svtc_samples)
        {
           S_set_error( "SVTC file '$svtc_file_path'  for curve '$svtc_curvename' doesnot contain the Samples value \n" , 114);
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        unless(defined $svtc_iteration)
        {
           S_set_error( "SVTC file '$svtc_file_path'  for curve '$svtc_curvename' doesnot contain the Iteration value \n" , 114);
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        unless(defined $svtc_time)
        {
           S_set_error( " SVTC file '$svtc_file_path'  for curve '$svtc_curvename' doesnot contain the Time value \n" , 114);
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }
        my $svtc_arb_volt_len = scalar(@svtc_arbitrary_voltage);
        if($svtc_arb_volt_len  == 0)
        {
           S_set_error( " SVTC file '$svtc_file_path'  for curve '$svtc_curvename' doesnot contain the voltage value(s) \n" , 114);
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }
        
        if($svtc_arb_volt_len != $svtc_samples)
        {
           S_set_error( " SVTC file '$svtc_file_path'  for curve '$svtc_curvename' doesnot contain the same number of voltage value(s) and samples \n" , 114);
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }
        my $svtc_arbitrary_voltage_aref = \@svtc_arbitrary_voltage;
        return ($svtc_samples, $svtc_iteration, $svtc_time, $svtc_arbitrary_voltage_aref);
}

=head2 SVTT_SAT_parser 

    SVTT_SAT_parser (sat_file_path, sat_curvename);
	
Reads sat file and returns the content of file.
    
B<Arguments:>

=over

=item sat_file_path

Absolute path of SAT file

=item sat_curvename

Curve name which sat file to be parsed(Only for documentation purpose)  

=back

B<Return Value:>

=over

=item On Success

a. sat_samples - Samples available in sat file

b. sat_current - Current value in sat file

c. sat_iteration - Iteration value available in sat file

d. sat_arbitrary_voltage - Array reference of voltage values

e. sat_arbitrary_time - Array reference of time values

=item On Failure

['-1000', '-1000', '-1000', '-1000']

=back

B<Examples:>

  (10, 1, 1, [10.00], [3.00]) = SVTT_SAT_parser ('D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\Tools\sVTT_Curves\NiDaq_Testing2.sat', 'NiDaq_Testing2');

=cut

sub SVTT_SAT_parser
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_SAT_parser( $sat_file_path, $sat_curvename )', @args );  
    my $sat_file_path = shift @args;
    my $sat_curvename = shift @args;

    S_w2log(1,"SVTT_SAT_parser :: $sat_curvename \n");

    my($sat_name, $sat_samples, $sat_iteration, $sat_current);
    my @sat_arbitrary_voltage= ();
    my @sat_arbitrary_time = ();
    my $counter=0;

   open my $SATFH,'<',"$sat_file_path";
   unless($SATFH)
   {
       S_set_error( "couldn't open $sat_file_path\n", 21 );
       return 0;
   }

    my @SATFH_ary = <$SATFH>;
    close($SATFH);
    foreach my $line(@SATFH_ary)
    {
        chomp($line);
        if($line !~/^\s*$/x) # checking for an empty line
        {
            if($line =~ /^Dateiname\s*:\s+(.+)/x)
            {
                $sat_name = $1;
            }
            elsif($line =~ /^Punkte\s*:\s+(.+)/x)
            {
                $sat_samples = $1;
            }
            elsif($line =~ /^Strombegrenzung\s*:\s+(.+)/x)
            {
                $sat_current = $1;
            }
            elsif($line =~ /^Wiederholungen\s*:\s+(.+)/x)
            {
                $sat_iteration = $1;
            }
            else
            {
                unless(($line=~ /U\[V\]\s+t\[s\]/x) || ($counter == $sat_samples))
                {
                        my @arbit_vals = split(/\s+/,$line);
                        push(@sat_arbitrary_voltage,$arbit_vals[0]);
                        push(@sat_arbitrary_time,$arbit_vals[1]);
                        $counter++;
                }
            }
        }
    }


    if($counter < $sat_samples)
    {
        S_w2log(1,"arbitrary values are less than punkte($sat_samples) in sat file, considered count of arbitrary values:: $counter \n");
        $sat_samples = $counter;
    }

    unless(defined $sat_name)
    {
       S_set_error( " SAT file '$sat_file_path' for curve '$sat_curvename' doesnot contain the Curve Name \n" , 114);
       return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
    }

    unless(defined $sat_samples)
    {
       S_set_error( "SAT file '$sat_file_path'  for curve '$sat_curvename' doesnot contain the Samples value \n" , 114);
       return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
    }

    unless(defined $sat_iteration)
    {
       S_set_error( "SAT file '$sat_file_path'  for curve '$sat_curvename' doesnot contain the Iteration value \n" , 114);
       return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
    }

    my $temp = scalar(@sat_arbitrary_time);

    if(($temp == 1) || ($sat_arbitrary_time[0] eq ''))
    {
       S_set_error( "SAT file '$sat_file_path'  for curve '$sat_curvename' doesnot contain the time value(s) \n" , 114);
       return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
    }

    $temp = scalar(@sat_arbitrary_voltage);
    if(($temp == 1) || ($sat_arbitrary_voltage[0] eq ''))
    {
       S_set_error( "SAT file '$sat_file_path'  for curve '$sat_curvename' doesnot contain the voltage value(s) \n" , 114);
       return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
    }
    my $sat_arbitrary_time_aref = \@sat_arbitrary_time ;
    my $sat_arbitrary_voltage_aref = \@sat_arbitrary_voltage ;
    return ($sat_samples,$sat_iteration,$sat_arbitrary_time_aref,$sat_arbitrary_voltage_aref,$sat_current);
}

=head2 SVTT_ReadLabels 

	ecu_Label_Contents = SVTT_ReadLabels(ecu_labels_aref)

$ecu_Label_Contents = > {
                           'label1' => value1,
                           'Address1' = value2, 
                            };
	
Reads the content of ECU labels either if variable name or address of variable is provided.

Input lable structure

i. Label/Address : Reads one byte of information from given label
ii. Label/Address-bytes : Reads 'bytes' of information from given label
iii. Label/Address- : Reads one byte of information from given label

    
B<Arguments:>

=over

=item ECU_Labels_aref 

Array reference of ecu labels and\or address 

=back

B<Return Value:>

=over

=item On Success

ecu_Label_Contents : Hash with ecu labels or address and read content

=back

B<Examples:>

$ecu_label_contents = SVTT_ReadLabels(['V_SpiTFFDevice_U8R','V_SpiTFFError_U8R','0x080005E8-1','0x080005E9','0x080005E0-']);

$ecu_label_contents = {
                        'V_SpiTFFDevice_U8R' => 1,
                        '0x080005E8' => '0x01',
                        '0x080005E9' => '0x01',
                        '0x080005E0' => '0x01',
                        'V_SpiTFFError_U8R' => 1
                      };

=cut

sub SVTT_ReadLabels
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_ReadLabels( $ecu_labels_aref )', @args );  

    my $ecu_labels_aref = shift @args; #This read the label names which are given as testcase parameters

     S_w2log(1,"SVTT_ReadLabels \n");

    my @read_labels_name;
    my %read_labels_address;
    my %ecu_label_contents;

    # split the ECU labels which are variables and the one which are the address of the variable
    foreach my $label ( @{ $ecu_labels_aref } )
    {
        if($label =~ /^0x[0-9a-f]+/i) # contains 0x with hex address
        {
            if($label =~ /-/)    # if there are byte information
            {
                my @values = split(/-/, $label);
                if(defined($values[1]))
                {    $read_labels_address{$values[0]} = $values[1];}
                else
                {    $read_labels_address{$values[0]} = '1';} # if number of bytes not provided, assume 1 byte to be read
            }
            else
            {
                $read_labels_address{$label} = '1'; # if number of bytes not provided, assume 1 byte to be read
            }
        }
        else
        {
            push (@read_labels_name,$label);
        }
    }

    # read the ECU label by name
    foreach my $label (@read_labels_name){
        my $value_aref = PD_ReadMemoryByName( $label ) || return ;
        my $type = PD_get_type_from_name( $label ) || return;
        my $dec_value = S_aref2dec ( $value_aref , $type ) ;
        S_w2rep("$label = $dec_value ($type)\n",'blue');
        # push contents to hash
        $ecu_label_contents{$label} = $dec_value;
    }

    # read the ECU label by address
    while ((my $address, my $number_of_bytes) = each %read_labels_address) {
        my $value_aref = PD_ReadMemoryByAddress( $address, $number_of_bytes ) || return;
        my $hex_value = S_aref2hex ( $value_aref );
        S_w2rep("$address = $hex_value ($number_of_bytes)\n",'blue');
        # push contents to hash
        $ecu_label_contents{$address} = $hex_value;
    }
    return(\%ecu_label_contents);
}

=head2 SVTT_Resample_Voltage 

	time_hcf = Resample_Voltage(ECU_Voltage_aref, time_aref);

Calculates HCF of time value & modifies the voltage samples based on hcf of time.    

Input lable structure

i. Label/Address : Reads one byte of information from given label
ii. Label/Address-bytes : Reads 'bytes' of information from given label
iii. Label/Address- : Reads one byte of information from given label

B<Arguments:>

=over

=item ECU_Voltage_aref 

Reference to array of voltage values

=item time_aref 

Reference to array of time values
 
=back

B<Return Value:>

=over

=item On Success

time_hcf - hcf of time value

=back

B<Examples:>

    $time_hcf = &Resample_Voltage($ECU_Voltage_aref, $time_aref);

=cut

sub SVTT_Resample_Voltage
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_Resample_Voltage( $ECU_Voltage_aref, $time_aref )', @args );  
    my $ECU_Voltage_aref = shift @args;
    my $time_aref = shift @args;
    my $time_hcf=undef;
    my @voltage_value = ();

    # get the hcf of time value from time array
    foreach my $data (@$time_aref) { $data = $data * $SCALAR_FACTOR; }
    $time_hcf = bgcd(@$time_aref);
    $time_hcf = $time_hcf->numify();

    # propogate the voltage array based on hcf of time value
    my $index = 0;
    foreach my $time(@$time_aref)
    {
        my $loop = $time / $time_hcf;
        while($loop)
        {
            push (@voltage_value, $$ECU_Voltage_aref[$index]);
            $loop--;
        }
        $index++;
    }
    foreach(0..scalar(@$ECU_Voltage_aref)) {pop(@$ECU_Voltage_aref);}    # remove existing contents of voltage array

    push(@$ECU_Voltage_aref, @voltage_value); # update new contents to voltage array

    return ($time_hcf/$SCALAR_FACTOR);
}

=head2 SVTT_CheckLabels 

	$check_Labels_Contents = SVTT_CheckLabels(check_labels_aref);

        $check_Label_Contents = > {
              'LABELNAME\ADDR' => {
                                    'READVALUE' => 0X0000,
                                    'OPERATOR' => '!=',
                                    'EXPECTEDVALUE' => 0X0000,
                                    'RESULT' => 'PASS\FAIL'
                                   },
                            };
							
Checks the label\address value read from ECU to given compare value based on the operator given.

Operators

'==' , '!=' , '>=' , '<=' , '<' , '>' , 'MASK'

B<Arguments:>

=over

=item check_Labels_aref 

Array reference of ecu labels and\or address with operator and expected value

check_Labels_aref structure : 

('label|operator|expectedvalue','label|operator|expectedvalue') 

=back

B<Return Value:>

=over

=item On Success

check_Label_Contents : Hash with ecu labels/address and its contents

=item  On Failure 

-1000

=back

B<Examples:>

	$check_Label_Contents = SVTT_CheckLabels(['V_SpiTFFDevice_U8R|!=|0x10']);

    $check_Label_Contents = > {
              'V_SpiTFFDevice_U8R' => {
                                    'RESULT' => 'VERDICT_PASS',
                                    'READVALUE' => 1,
                                    'EXPECTEDVALUE' => '0x10',
                                    'OPERATOR' => '!='
                                  },
                              }

=cut

sub SVTT_CheckLabels
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SVTT_CheckLabels( $check_labels_aref )', @args );   
    my $check_labels_aref = shift @args; #This read the label names which are given as testcase parameters

    S_w2log(1,"SVTT_CheckLabels \n");

    my (%check_Label_Contents);
    my (@check_label_data, @result_arr);
    my ($label, $operator, $expected_val, $result, $value_aref, $hex_value);

    # split the ECU labels which are variables and perfrom checking operation
    foreach my $checkdata ( @{ $check_labels_aref } )
    {
       @check_label_data = split(/\|/, $checkdata);

       $label = $check_label_data[0];

       $operator = $check_label_data[1];

       $expected_val = $check_label_data[2];

       $check_Label_Contents{$label}{'OPERATOR'} = $operator;
       $check_Label_Contents{$label}{'EXPECTEDVALUE'} = $expected_val;
    }

    foreach my $lable_key(keys(%check_Label_Contents))
    {
        if($lable_key =~ /^0x[0-9a-f]+/i) # contains 0x with hex address
        {
            if($lable_key =~ /-/)    # if there are byte information
            {
                my @values = split(/-/, $lable_key);
                if(defined($values[1]))
                {
                    $value_aref = PD_ReadMemoryByAddress( $values[0], $values[1] ) || return;
                    $hex_value = S_aref2hex ( $value_aref );
                    S_w2rep("$values[0] = $hex_value ($values[1])\n",'blue');
                    $check_Label_Contents{$lable_key}{'READVALUE'} = $hex_value;
                    $result = EVAL_evaluate_value( $lable_key , $hex_value, $check_Label_Contents{$lable_key}{'OPERATOR'}, $check_Label_Contents{$lable_key}{'EXPECTEDVALUE'}) || return;
               }
                else
                {
                  S_w2log(1,"Number of bytes is not provided, assume 1 byte to be read");
                  $value_aref = PD_ReadMemoryByAddress( $values[0], 1 )|| return;
                  $hex_value = S_aref2hex ( $value_aref );
                  S_w2rep("$values[0] = $hex_value (1)\n",'blue');
                  $check_Label_Contents{$lable_key}{'READVALUE'} = $hex_value;
                  $result = EVAL_evaluate_value( $lable_key , $hex_value, $check_Label_Contents{$lable_key}{'OPERATOR'}, $check_Label_Contents{$lable_key}{'EXPECTEDVALUE'}) || return ;
                }
            }
            else
            {
                  S_w2log(1,"Number of bytes is not provided, assume 1 byte to be read");
                  $value_aref = PD_ReadMemoryByAddress($lable_key, 1 )|| return;
                  $hex_value = S_aref2hex ( $value_aref );
                  S_w2rep("$lable_key = $hex_value (1)\n",'blue');
                  $check_Label_Contents{$lable_key}{'READVALUE'} = $hex_value;
                  $result = EVAL_evaluate_value( $lable_key , $hex_value, $check_Label_Contents{$lable_key}{'OPERATOR'}, $check_Label_Contents{$lable_key}{'EXPECTEDVALUE'}) || return ;
            }
        }
        else
        {
         $value_aref = PD_ReadMemoryByName( $lable_key )|| return;
         my $type = PD_get_type_from_name( $lable_key )|| return;
         my $dec_value = S_aref2dec ( $value_aref , $type );
         S_w2rep("$label = $dec_value ($type)\n",'blue');
         $check_Label_Contents{$lable_key}{'READVALUE'} = $dec_value;
         $result = EVAL_evaluate_value( $lable_key , $dec_value, $check_Label_Contents{$lable_key}{'OPERATOR'}, $check_Label_Contents{$lable_key}{'EXPECTEDVALUE'}) || return ; 
        }
        $check_Label_Contents{$lable_key}{'RESULT'} = $result;
        push(@result_arr,$result); #loading array to set the check label flag pass or fail
    }
	$error_flag = 1 if( grep {/^verdict_fail$/ix} @result_arr);
    
	return(\%check_Label_Contents);
}

=head2 SVTT_Evaluation_Table_Creation 

	SVTT_Evaluation_Table_Creation();
	
Generates an HTML tables of PRE and POST diagnosis with following coloumns Read Fault, Mandatory fault, optional fault, ECU Required Label Info and ECU Check label Info

B<Arguments:>

=over

=item None 

=back

B<Return Value:>

=over

=item None

=back

B<Examples:>

	      SVTT_Evaluation_Table_Creation();

=cut

sub SVTT_Evaluation_Table_Creation
{
    my @table = ();
    my (%ecu_lables,%check_labels) = ();
    my (@keys_ecu_labels, @values_ecu_labels, @keys_check_lables) = ();

    #Table Header Variables
    my ($mand_header_string, $opt_header_string, $opt_fail_str, $opt_pass_str, $mand_pass_str, $mand_fail_str) = undef;
    my ($chk_lbl_header_string,$chk_lbl_name_str,$chk_lbl_act_val_str,$chk_lbl_operator_str,$chk_lbl_cmp_val_str,$chk_lbl_result_str)= undef;
    my ($read_lbl_header_string, $read_lbl_name_str, $read_lbl_val_str)=undef;

    S_w2log(1,"SVTT_Evaluation_Table_Creation \n");

   foreach my $action(keys(%Diagnosis))
   {
    $action = uc($action);
    my @fault_text = @{$Diagnosis{$action}->{'fault_text'}};
    my @mand_pass =  @{$Diagnosis{$action}->{'MAND_PASS'}};
    my @mand_fail =  @{$Diagnosis{$action}->{'MAND_FAIL'}};
    my @opt_pass =  @{$Diagnosis{$action}->{'OPT_AVAIL'}};
    my @opt_fail =  @{$Diagnosis{$action}->{'OPT_NOT_AVAIL'}};

    if(exists $Diagnosis{$action}->{'ECU_lables'})
    {
        %ecu_lables = %{$Diagnosis{$action}->{'ECU_lables'}};

    }
    if(exists $Diagnosis{$action}->{'CHECKLABLE'})
    {
        %check_labels = %{$Diagnosis{$action}->{'CHECKLABLE'}};
    }

    if(%ecu_lables)
    {
        @keys_ecu_labels = keys(%ecu_lables);
        @values_ecu_labels = values(%ecu_lables);
    }

    if( %check_labels)
    {
        @keys_check_lables = keys(%check_labels);
    }

    # Reading the maximum value to create number of rows
    my $highestvalue = max (scalar(@fault_text),scalar(@mand_pass),scalar(@mand_fail),scalar(@opt_pass),scalar(@opt_fail),scalar(@keys_ecu_labels),scalar(@keys_check_lables));

    #Filling rows data from Diagnosis hash
    for(my $i = 0; $i< $highestvalue; $i++)
    {
        my $str = "<tr align='center'>";

         if(defined $fault_text[$i])
         {
            $str.="<td>$fault_text[$i]</td>";
         }
         else
         {
            $str.="<td>&nbsp;</td>";
         }
         if(scalar(@mand_pass) > 0 || scalar(@mand_fail) > 0)
         {
            $mand_header_string = '<th colspan = 2> Mandatory Fault</th>';
            $mand_pass_str = '<th> PASS</th>';
            $mand_fail_str = '<th>FAIL</th>';
            if(defined $mand_pass[$i])
            {
                $str.="<td>$mand_pass[$i]</td>";
            }
            else
            {
                $str.="<td>&nbsp;</td>";
            }
            if(defined $mand_fail[$i])
            {
                $str.="<td>$mand_fail[$i]</td>";
            }
            else
            {
                $str.="<td>&nbsp;</td>";
            }
         }
         #If optional faults are available then this data generates in evaluation table
         if(scalar(@opt_pass) > 0 || scalar(@opt_fail) > 0)
         {
            $opt_header_string = '<th colspan = 2>Optional Fault</th>';
            $opt_pass_str = '<th> PASS</th>';
            $opt_fail_str = '<th>FAIL</th>';

            if(defined $opt_pass[$i])
            {
                $str.="<td>$opt_pass[$i]</td>";
            }
            else
            {
                $str.="<td>&nbsp;</td>";
            }
            if(defined $opt_fail[$i])
            {
                $str.="<td>$opt_fail[$i]</td>";
            }
            else
            {
                $str.="<td>&nbsp;</td>";
            }
         }

        #If ecu labels data is available then this data generates in evaluation table
        if(scalar(@keys_ecu_labels) > 0)
        {
         $read_lbl_header_string = '<th colspan = 2>ECU Required Label Info</th>';
         $read_lbl_name_str = '<th>Label Name/Address</th>';
         $read_lbl_val_str = '<th>Label Value</th>';

         if(defined $keys_ecu_labels[$i])
         {
            $str.="<td>$keys_ecu_labels[$i]</td>";
         }
         else
         {
           $str.="<td>&nbsp;</td>";
         }

         if(defined $values_ecu_labels[$i])
         {
           $str.="<td>$values_ecu_labels[$i]</td>";
         }
         else
         {
            $str.="<td>&nbsp;</td>";
         }
        }
        #If check labels data is available then this data generates in evaluation table
        if(scalar(@keys_check_lables) > 0)
        {
         $chk_lbl_header_string = '<th colspan = 5> ECU Check label Info</th>';
         $chk_lbl_name_str = '<th>Label Name/Address</th>';
         $chk_lbl_act_val_str = '<th>Label Value</th>';
         $chk_lbl_operator_str = '<th>Operator</th>';
         $chk_lbl_cmp_val_str = '<th>Compare Value</th>';
         $chk_lbl_result_str = '<th>Result</th>';
         if(defined $keys_check_lables[$i])
         {
            $str.="<td>$keys_check_lables[$i]</td>".
            "<td>$check_labels{$keys_check_lables[$i]}{'READVALUE'}</td>".
            "<td>$check_labels{$keys_check_lables[$i]}{'OPERATOR'}</td>".
            "<td>$check_labels{$keys_check_lables[$i]}{'EXPECTEDVALUE'}</td>".
            "<td>$check_labels{$keys_check_lables[$i]}{'RESULT'}</td>";
         }
         else
         {
            $str.="<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
         }
        }
        $str.="</tr>";
        push(@table,$str);
    }

    # Pushing into actual html array to print table    
    push( @TC_HTML_TEXT, join ('','<div class="w2rep ',$module_name,'"><TABLE class="tablesorter">',
    '<tr align="center"> <th colspan=13>',$action,'-Diagnosis</th> </tr>',
    '<tr align="center">',
        '<th rowspan = 2> Read Fault</th>',
        $mand_header_string,
        $opt_header_string,
        $read_lbl_header_string,
        $chk_lbl_header_string,
    '</tr>',
    '<tr align="center">',
        $mand_pass_str,
        $mand_fail_str,
        $opt_pass_str,
        $opt_fail_str,
        $read_lbl_name_str,
        $read_lbl_val_str,
        $chk_lbl_name_str,
        $chk_lbl_act_val_str,
        $chk_lbl_operator_str,
        $chk_lbl_cmp_val_str,
        $chk_lbl_result_str,
    '</tr>', @table,'</TABLE></div>',"\n") );

    @table = ();
 }
    return $SVTT_SUCCESS;
}

=head2 SVTT_Eval_Fault_content 

	 SVTT_Eval_Fault_content(CurveName, [ flt_mand_aref, flt_opt_aref ] );
	
This function checks the mandatory/optional faults from generated fault structure.

B<Arguments: >

=over

=item curveName 

Name of the Curve (Only for documentation purpose)

=item flt_mand_aref 

(optional) Mandatory faults to check for availability

=item flt_opt_aref

(optional)Optional faults to check for availability 

=back

B<Return Value:>

=over

=item None

=back

B<Examples:>

  SVTT_Eval_Fault_content('AUDI_lv124_e_01_long_term_over_voltage', ['FltSystemAsic1CfgMismatch','FltInertParameterSet','FltCoSigShort2GND'], ['FltBAOffAShort2GndOrOpen' , 'FltBAOnAShort2GndOrOpen'] );

=cut

sub SVTT_Eval_Fault_content
{
 
   my @args = @_;
   return 0 unless S_checkFunctionArguments( 'SVTT_Eval_Fault_content( $curveName, [$flt_mand_aref, $flt_opt_aref] )', @args );   
   my $curveName = shift @args;
   my $flt_mand_aref = shift @args;
   my $flt_opt_aref = shift @args;

   S_w2log(1, "SVTT_Eval_Fault_content :: $curveName \n");

    # Performing Mandatory and Optional Fault checking of Diagnosis
   foreach my $action (keys(%FuncLib_sVTT::Diagnosis))
   { 
     my @flt_mand_aref_local = ();
	 if ( defined $flt_mand_aref )
     {
		@flt_mand_aref_local = @$flt_mand_aref;
	 }
     
     my @flt_opt_aref_local = ();
	 if ( defined $flt_opt_aref )
     {
		@flt_opt_aref_local = @$flt_opt_aref;
	 }
     

      my (@mand_pass, @mand_fail, @opt_avail, @opt_not_avail) = ();
       #Reading all fault details
       my @fault_data  = @{$Diagnosis{$action}{'fault_text'}}; #read from ECU
       my @fault_data_temp = @fault_data; #not to spoil the contents of original @fault_data
	   	   	   
       for (my $i = 0; $i < scalar(@fault_data_temp); $i++)
       {
           for (my $j = 0; $j < scalar(@flt_mand_aref_local); $j++)
           {
               if($fault_data_temp[$i] eq $flt_mand_aref_local[$j])
               {
                   push(@mand_pass, $fault_data_temp[$i]);
                   delete $flt_mand_aref_local[$j];
                   delete $fault_data_temp[$i];
			    }
           }
       }

       @mand_fail = @flt_mand_aref_local;

       for (my $i = 0; $i < scalar(@fault_data_temp); $i++)
       {
           for (my $j = 0; $j < scalar(@flt_opt_aref_local); $j++)
           { 
               if($fault_data_temp[$i] eq $flt_opt_aref_local[$j])
               {
                   push(@opt_avail, $fault_data_temp[$i]);
                   delete $flt_opt_aref_local[$j];
                   delete $fault_data_temp[$i];
				   
               }
           }
       }
	 
	   $error_flag = 1 if (scalar (@fault_data_temp)>0);

       @opt_not_avail = (@flt_opt_aref_local,@fault_data_temp); 
       
       #Adding related fault informations
       $Diagnosis{$action}{'MAND_PASS'} = \@mand_pass;
       $Diagnosis{$action}{'MAND_FAIL'} = \@mand_fail;
       $Diagnosis{$action}{'OPT_AVAIL'} = \@opt_avail;
       $Diagnosis{$action}{'OPT_NOT_AVAIL'} = \@opt_not_avail;

####################################
       #work around for S_add2eval_collection
       my $eval_mand_pass = add2eval_contents(\@mand_pass) || return;
 
       my $eval_mand_fail = add2eval_contents(\@mand_fail) || return;

       my $eval_opt_pass = add2eval_contents(\@opt_avail) || return;

       my $eval_opt_fail = add2eval_contents(\@opt_not_avail) || return;
            
       if ($action eq 'PRE')
       {
           S_add2eval_collection( 'PRE_MAND_PASS' , $eval_mand_pass);
           S_add2eval_collection( 'PRE_MAND_FAIL' , $eval_mand_fail);
           S_add2eval_collection( 'PRE_OPT_PASS' , $eval_opt_pass );
           S_add2eval_collection( 'PRE_OPT_FAIL' , $eval_opt_fail );
       } 
       if ($action eq 'POST')
       {
           S_add2eval_collection( 'POST_MAND_PASS' , $eval_mand_pass );
           S_add2eval_collection( 'POST_MAND_FAIL' , $eval_mand_fail);
           S_add2eval_collection( 'POST_OPT_PASS' , $eval_opt_pass );
           S_add2eval_collection( 'POST_OPT_FAIL' , $eval_opt_fail );
       }
#################################### 
   }     
   return $SVTT_SUCCESS;
}

=head2 convert_sat_to_svtc 

	counter = convert_sat_to_svtc(sVTTCurve_svtc_file_path, lines, arbitrary_voltage_aref, arbitrary_time_aref, time_curve );
	
This function generates svtc file by reading the contents of sat file as arguments.

B<Arguments:>

=over

=item sVTTCurve_svtc_file_path 

SVTC file path

=item lines_aref 

contents of sat file (array reference)

=item arbitrary_voltage_aref

arbitrary voltage values read from sat file (array reference)

=item arbitrary_voltage_aref

arbitrary time values read from sat file (array reference)

=item time_curve 

resampled time value

=back

B<Return Value:>

=over

=item counter 

Number of voltage samples

=back

B<Examples:>

  counter = convert_sat_to_svtc(sVTTCurve_svtc_file_path, lines, arbitrary_voltage_aref, arbitrary_time_aref, time_curve );

=cut

sub convert_sat_to_svtc
{

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'convert_sat_to_svtc ( $sVTTCurve_svtc_file_path, $lines_aref, $arbitrary_voltage_aref, $arbitrary_time_aref, $time_curve )', @args );   
    my $sVTTCurve_svtc_file_path = shift @args ;
    my $lines_aref = shift @args;
    my $arbitrary_voltage_aref = shift @args;
    my $arbitrary_time_aref = shift @args;
    my $time_curve = shift @args;

    my @SVTCFH_ary = (); #contents of svtc file
    my $counter = 0; #number of samples of voltage
    my $index = 0;
    foreach my $line(@$lines_aref)
    {
        chomp($line);
        if($line !~/^\s*$/x) # checking for an empty line
        {
            #Matching 'Dateiname :'
            if($line =~ /^Dateiname\s*:\s+(.+)/i)    # change to Curve Name & use the filename from filepath 
            {
                if($line =~ /\\/)    # filename with entire path
                {
                    my $position = rindex($line, "\\") + 1;
                    $line = substr($line, $position);
                }
                else # only filename
                {
                    $line = $1;
                }
                $line =~ s/.sat/.svtc/i;
                $line = "Curve Name : " . $line;
            }
            #Matching 'Punkte :'
            elsif($line =~ /^Punkte\s*:\s*/ix)    # change to Samples & append length of voltage array
            {
                $line = "Samples : " . scalar(@$arbitrary_voltage_aref) ;    # append length of voltage array
            }
            #Matching 'Wiederholungen :'
            elsif($line =~ s/Wiederholungen/Iteration/ix)    # change to iteration
            {
                $line = $line . "\n" . "Time[s] : " . $time_curve;
            }
            #Matching 'Strombegrenzung :'
            elsif($line =~ /^Strombegrenzung/ix)    # ignore current value for nidaq
            {
                next;    # ignore this line
            }
              #Matching 'U[V]'
            elsif($line =~ /^(U\[V\])/ix)
            {
                $line = $1;        # use only U[V]
            }
            else
            {
                  #Matching other than 'U[V]'
                unless(($line=~ /U\[V\]\s+t\[s\]/x) )
                {
                    my $time = $time_curve*$SCALAR_FACTOR;
                    my $loop =  $$arbitrary_time_aref[$index] / $time;
                    while($loop)
                    {
                        push (@SVTCFH_ary, $$arbitrary_voltage_aref[$counter++]);    # copy contents from voltage value to svtc file
                        $loop--;
                    }
                    $index++;
                }
                next; # skip printing the line & move to the next content
            }
        }
       push (@SVTCFH_ary, $line);
    }
   open (my $SVTCFH,'>',"$sVTTCurve_svtc_file_path");
   unless($SVTCFH)
   {
       S_set_error( "couldn't open $sVTTCurve_svtc_file_path\n", 21 );
       return 0;
   }
    S_w2log(4,"$sVTTCurve_svtc_file_path :: successfully opened.");
    for(my $i = 0; $i < scalar(@SVTCFH_ary); $i ++)
    {
        print $SVTCFH $SVTCFH_ary[$i] ."\n";
    }
    close($SVTCFH);
    return $counter;
}

=head2 add2eval_contents 

	output = add2eval_contents (input);
	
This function converts the array into string (all the array elements are joined to a string separated by space) and returns it.
If the input is not defined, then it will return '---'.

B<Arguments:>

=over

=item input 

Array reference 

=back

B<Return Value:>

=over

=item output

string

=back

B<Examples:>

   'fault1    fault2    fault3    ' = add2eval_contents (['fault1', 'fault2','fault3']);
    '---' = add2eval_contents ( );

=cut

sub add2eval_contents
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'add2eval_contents( $input_aref )', @args );   
    my $input_aref = shift @args;
    my $output;
    if (scalar(@$input_aref) > 0)
    {
        foreach my $element (@$input_aref)
        {
            $output .= $element."   ";
        }
    }
    else
    {
       $output = '---' ;
    }
    return $output;
}    
1;

__END__

=head1 AUTHORS


Puneeth BA, E<lt> PuneethB.Amarnath@in.bosch.com E<gt>
Gayathri Harikrishna, E<lt> Gayathri.Harikrishna@in.bosch.com E<gt>

=head1 NOTES

B<ReturnValue>

Failure of subroutine execution :: B<-1000>

The VTT testing procedure could be found @ B<..\TurboLIFT\Tools\Documentation> folder named as B<sVTT::sVTT_description>

=head1 User Manual

 External documents realted to sVTT such as User manual or any other hardware related info docs shall be placed here

=head1 SEE ALSO

 LIFT_NIDAQ, LIFT_PD, LIFT_TEMEPRATURE, LIFT_TOE1, LIFT_Labcar documentation

=cut 
