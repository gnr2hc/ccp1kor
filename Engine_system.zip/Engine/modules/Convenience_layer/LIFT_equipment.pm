package LIFT_equipment;

######################################################

=head1 NAME

LIFT_equipment 

Provide LIFT useful functions for initializing test bench functionality for all functional layer modules (defined in LIFT_Testbenches).

=head1 SYNOPSIS

    use LIFT_equipment;

    EQUIP_init_testbench( );
    EQUIP_init_testbench( 'crash injection' );

    my $device = EQUIP_get_devices ( 'Labcar' , 'line');
    
    # obsolete function
    EQUIP_main_init(); # (old, kept for backwards compatibility, please use EQUIP_init_testbench instead)

=head1 DESCRIPTION

EQUIP_init_testbench is the main function of this package. 
It will initialize with a single call the devices for all function groups in all functional layer modules 
(namely Labcar, PD, CD, CAN_Access, FlexRay_Access, LIN_Access, Temperature, Motion and Crash_simulation) 
if they are configured in the 'Functions' section of LIFT_testbenches.pm (see all possibilities in the example below).

If you want to use EQUIP_init_testbench please make sure that you have those functional layer modules configured 
in the 'Functions' section of your LIFT_testbenches.pm like in the example below.

EQUIP_init_testbench should be called in the init campaign of a test list.

The 'Functions' section of your LIFT_testbenches.pm can now also contain so called test type sections. 
A test type section is a key with any name below the 'Functions' area. Below this test type key there are functions, function groups and devices
just like you have them normally directly below 'Functions'. The purpose of these test type sections is to have more flexibility when initializing
the test bench: If you have a full blown test bench with all kinds of devices you do not always want to initialize all devices for a certain test list.
Suppose you want to run a pure DCOM software test you will want to specify a test type section 'DCOM' which contains the function groups 
'Labcar'->'power_Ubat' (to switch on the ECU), 'PD' (to read the ECU SW version number) and 'CD' to send and receive the DCOM services:

    'Functions' => {
        # normal functions section start
        ...
        # normal functions section end

        # test type section start
        'DCOM' => {  # test type for doing a DCOM software test
            'Labcar' => {
                'power_Ubat' => 'TSG4',
            },
            'PD' => 'PD',
            'CD' => 'CAN',
        },
        ... # more test types possible
        # test type section end        
    },

When calling EQUIP_init_testbench('DCOM') only the devices that are configured for 'Labcar'->'power_Ubat', 'PD' and 'CD' will be initialized.

Similarly if you want to run a crash injection system test you will want to specify a test type 'crash injection' which contains the function groups
'Labcar'->'line'/'power_Ubat'/'measure_connector'/'measure_trace_digital'/'measure_trace_analog', 'PD', 'CD', 'CAN_Access' and 'Crash_simulation',
see the example below.

There can be several test types in parallel. The number of test types per test bench is not limited.


Old 'Functions' like POWER, PERIPHERIE (both replaced by Labcar), Diagnosis (replaced by CD), SensorEmulator (replaced by Crash_simulation)
are not supported by EQUIP_init_testbench, but they will still work with the function specific init functions for backwards compatibility.


Example use:

1. define in the LIFT_config package:

    package LIFT_config;
    ...
    ### Testbench configuration
    if ( -f "$LIFT_PRJCFG_path/LIFT_Testbenches.pm" ) {
        require "$LIFT_PRJCFG_path/LIFT_Testbenches.pm";
        $LIFT_Testbench = $LIFT_Testbenches::Testbench->{$LIFT_host};
    }

2. prepare a LIFT_Testbenches package :

    package LIFT_Testbenches;
    $Testbench = {
        ### ----------- LIFT control host -----------
        '<hostname>' => {
            ### ----------- Device Configuration Section -----------
            'Devices' => {
                ...
            }, ## end of ~~~ Device Configuration Section ~~~
            ### ----------- Function Configuration Section -----------
            'Functions' => {
                ### --- Default Functions, all supported functions are shown here.                     ---
                ### --- For your test bench select only those for which you have appropriate devices.  ---
                'Labcar' => {       # see documentaton of LIFT_labcar for possible devices
                    'line'     =>              '<device>',
                    'extended' =>              '<device>',
                    'disposal' =>              '<device>',
                    'power_Ubat' =>            '<device>',
                    'power_UF' =>              '<device>',
                    'measure_connector' =>     '<device>',
                    'measure_trace_digital' => '<device>',
                    'measure_trace_analog' =>  '<device>',
                    'measure_once' =>          '<device>',             
                },
                'PD' => 'PD',          # only device PD is currently possible 
                'CD' => '<device>',    # was formerly 'Diagnosis', 
                                       # see documentaton of LIFT_CD for possible devices
                'CAN_Access' => {
                   'basic' =>     'CANoe', # function groups: read, write, trace, simulation
                   'stimulate' => 'CANoe',
                },
                'FlexRay_Access' => {
                   'basic' =>     'CANoe', # function groups: read, write, trace, simulation
                   'stimulate' => 'CANoe',
                },
                'LIN_Access' => {
                   'basic' =>     'CANoe', # function groups: read, write, trace, simulation
                   'stimulate' => 'CANoe',
                },
                'Temperature' => { # see documentaton of LIFT_TEMPERATURE for possible devices
                    'get' => '<device>',
                    'set' => '<device>',
                },
                'Motion' => { # see documentaton of LIFT_motion for possible devices
                    'Position' => <device>,
                    'Rotate'   => <device>,
                },
                'Crash_simulation' => { # see documentaton of LIFT_crash_simulation for possible devices
                    'crash_database'  =>   '<device>',
                    'crash_sensors'   =>   '<device>',
                    'network_dynamic' =>   '<device>',
                    'trigger'         =>   '<device>',
                },
                'SPI_Access' => {
                    # !!!! SPIMaid and Manitoo can't be used together !!!!
                   'trace' =>  'SPIMaid', # possible devices: SPIMaid, Manitoo
                   'manipulate' => 'NONE', # possible devices: Manitoo
                },
                'PSI5_Access' => {
                    # !!! ManitooPAS should be connected to manitoo !!!
                    'simulate' => 'Manitoo' ,      # Manitoo
                },
                'ProdDiag' => {
                    'generation' => 'AB12',
                    'basic' => 'PDLayer',
                },
                ## end of ~~~ Default Functions ~~~
                
                ### ----------- Test Type Section (examples) -----------
                'minimal' => {  # test type for switching on and off ECU and doing PD
                    'Labcar' => {
                        'power_Ubat' => 'TSG4',
                    },
                    'PD' => 'PD',
                },
                'crash injection' => {  # test type for doing a complete crash injecton test
                    'Labcar' => {
                        'line'     =>              'TSG4',
                        'power_Ubat' =>            'TSG4',
                        'measure_connector' =>     'TSG4',
                        'measure_trace_digital' => 'TRC',
                    },
                    'PD' => 'PD',
                    'CD' => 'CAN',
                    'CAN_Access' => {
                       'basic' =>     'CANoe',
                    },
                    'Crash_simulation' => {
                        'crash_database'  =>   'MDSRESULT',
                        'crash_sensors'   =>   'QuaTe',
                        'trigger'         =>   'QuaTe',
                    },
                },
                'Manitoo' => {  # test type for switching on and off ECU using ManiToo and doing PD
                    'Labcar' => {
                        'line'              =>  'PeriBox',
                        'power_Ubat'        =>  'Manitoo',  # --> MaintooFET
                    },
                    'PD' => 'PD',
                },
                ## end of ~~~ Test Type Section ~~~
                
            }, ## end of ~~~ Function Configuration Section ~~~
        },
    };

3. call in the init campaign:

    use LIFT_equipment;

    EQUIP_init_testbench( 'minimal' );
    
Note: EQUIP_init_testbench attempts to switch on the ECU if 'power_Ubat' function group of Labcar is configured in order to be able to initialize PD.
In other words: If PD is configured, but not 'power_Ubat' function group of Labcar, then PD initialization will fail unless the ECU is manually switched on.

=cut

######################################################

use strict;
use warnings;
use Win32::OLE;
use Sys::Hostname;
use Storable qw(dclone);

use LIFT_general;
use LIFT_vector_cantool;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

# next 2 lines edited by CVS, DO NOT MODIFY

@ISA    = qw(Exporter);
@EXPORT = qw(
  EQUIP_init_testbench
  EQUIP_get_devices
  EQUIP_set_devices
  EQUIP_main_init
  );    # export subs

## holds the whole information about active devices and
## the order of devices which should be used foreach function (per Function Area)
my $initEquipment_href;

## holds the Testbench Config of the active host
my $testbench_href;

## copy of original Testbench Config if EQUIP_init_testbench is called several times
my $testbenchCopy_href;
######################################################

=head2 EQUIP_init_testbench

    EQUIP_init_testbench( [ $testType ] );
    
Initializes all functions (with associated devices) of functional layer modules that are configured for the given test type ($testType).
If no $testType is given then all default functions will be initialized.
See L</"DESCRIPTION"> for an explanation of test types. 

Returns 1 on success and 0 otherwise.

=cut

######################################################

sub EQUIP_init_testbench {
    my @args = @_;
    return unless S_checkFunctionArguments( 'EQUIP_init_testbench( [ $testType ] )', @args );

    my $testType = shift @args;

    $initEquipment_href = {};    # clear whatever was configured in a previous call to this function

    if ( not defined $testbenchCopy_href ) {

        # make a copy of the original testbench config if this function is called the first time
        $testbenchCopy_href = dclone($LIFT_config::LIFT_Testbench);
    }
    else {
        # function is called several times: restore the original testbench config from the copy
        $LIFT_config::LIFT_Testbench = dclone($testbenchCopy_href);
    }

    $testbench_href = $LIFT_config::LIFT_Testbench;    # set $testbench_href pointer to testbench config

    my $tbFunctions_href = $testbench_href->{'Functions'};

    unless ( defined $tbFunctions_href ) {
        S_set_error( "No entry 'Functions' found in testbench config (LIFT_Testbenches.pm) for LIFT host " . hostname . ". ( note : hostnames are case sensitive / 'localhost' is possible too ) \n", 21 );
        return;
    }

    if ( defined $testType ) {
        unless ( defined $tbFunctions_href->{$testType} ) {
            S_set_error( "Test type '$testType' given as argument, but no such test type defined in 'Functions' section in testbench config (LIFT_Testbenches.pm) for LIFT host " . hostname . ".\n", 21 );
            return;
        }
        $tbFunctions_href = dclone( $tbFunctions_href->{$testType} );
        $testbench_href->{'Functions'} = $tbFunctions_href;
    }
    else {
        $testType = 'default';
    }

    my @functions = keys %{$tbFunctions_href};
    if ( @functions == 0 ) {
        S_set_error( "There are no functions configured for test type '$testType' in 'Functions' section of testbench config (LIFT_Testbenches.pm) for LIFT host " . hostname . ".\n", 21 );
        return;
    }

    #
    # start initializing all modules in the functional layer if they are configured
    #
    S_w2log( 2, " EQUIP_init_testbench: Starting init for test type '$testType' ...\n" );

    my $functionAreas_href;

    # Motion must be initialized before ECU on to avoid possible errors while homing; and it is good practice to init Motion first to see problems with the device asap
    if ( defined $tbFunctions_href->{'Motion'} ) {
        eval "use LIFT_motion";
        S_w2log( 3, " EQUIP_init_testbench: Calling MOT_Init() \n" , 'blue' );
        $functionAreas_href = MOT_Init();
        $initEquipment_href->{'FunctionAreas'}{'Motion'} = $functionAreas_href;
    }

    # Labcar must be initialized before Crash_simulation to be able to switch off the ECU before CSI_Init to avoid sensor errors
    if ( defined $tbFunctions_href->{'Labcar'} ) {
        eval "use LIFT_labcar";
        S_w2log( 3, " EQUIP_init_testbench: Calling LC_Init() \n" , 'blue' );
        $functionAreas_href = LC_Init();
        $initEquipment_href->{'FunctionAreas'}{'Labcar'} = $functionAreas_href;

        # switch off the ECU if any Labcar power functions are initialized because CSI_Init could introduce sensor errors if ECU is on
        if ( defined $initEquipment_href->{'FunctionAreas'}{'Labcar'}{'power_static_Ubat'} ) {
            S_w2log( 3, " EQUIP_init_testbench: Calling LC_ECU_Off() (CSI_Init could introduce sensor errors if ECU is on)\n" , 'blue' );
            LC_ECU_Off();
            S_wait_ms('TIMER_ECU_OFF');
        }
    }

    # Crash_simulation must be initialized before CAN_Access
    if ( defined $tbFunctions_href->{'Crash_simulation'} ) {
        eval "use LIFT_crash_simulation";
        S_w2log( 3, " EQUIP_init_testbench: Calling CSI_Init() \n" , 'blue' );
        $functionAreas_href = CSI_Init();
        $initEquipment_href->{'FunctionAreas'}{'Crash_simulation'} = $functionAreas_href;
    }

    # CAN_Access, FlexRay_Access and LIN_Access must know if Crash_simulation was loaded before
    if ( defined $tbFunctions_href->{'CAN_Access'} ) {
        eval "use LIFT_can_access";
        S_w2log( 3, " EQUIP_init_testbench: Calling CA_init() \n" , 'blue' );
        CA_init();    # this function writes already to $initEquipment_href
    }

    if ( defined $tbFunctions_href->{'FlexRay_Access'} ) {
        eval "use LIFT_flexray_access";
        S_w2log( 3, " EQUIP_init_testbench: Calling FR_init() \n" , 'blue' );
        FR_init();    # this function writes already to $initEquipment_href
    }

    if ( defined $tbFunctions_href->{'LIN_Access'} ) {
        eval "use LIFT_LIN_Access";
        S_w2log( 3, " EQUIP_init_testbench: Calling LIN_init() \n" , 'blue' );
        LIN_init();    # this function writes already to $initEquipment_href
    }

    if ( defined $tbFunctions_href->{'NET_Access'} ) {
        eval "use LIFT_NET_access";
        S_w2log( 3, " EQUIP_init_testbench: Calling NET_Init() \n" , 'blue' );
        $functionAreas_href = NET_Init();
        $initEquipment_href->{'FunctionAreas'}{'NET_Access'} = $functionAreas_href;
    }

    if ( defined $tbFunctions_href->{'PSI5_Access'} ) {
        eval "use LIFT_PSI5_access";
        S_w2log( 3, " EQUIP_init_testbench: Calling PSI5_init() \n" , 'blue' );
        $functionAreas_href = PSI5_init();
        $initEquipment_href->{'FunctionAreas'}{'PSI5_Access'} = $functionAreas_href;
    }

    # restbus simulation and sensor simulation must be started before the ECU is switched on
    if ( defined $tbFunctions_href->{'Labcar'} ) {

        # switch on the ECU if any Labcar power functions are initialized because PD needs the ECU to be on
        if ( defined $initEquipment_href->{'FunctionAreas'}{'Labcar'}{'power_static_Ubat'} ) {
            S_w2log( 3, " EQUIP_init_testbench: Calling LC_ECU_On()(because PD needs the ECU to be on)\n" , 'blue' );
            LC_ECU_On();
            S_w2log( 3, " EQUIP_init_testbench: Wait until ECU is powered up ('TIMER_ECU_READY') \n" , 'blue' );
            S_wait_ms('TIMER_ECU_READY');
        }
    }

    if ( defined $tbFunctions_href->{'ProdDiag'} and defined $tbFunctions_href->{'PD'} ) {
        S_set_error( "EQUIP_init_testbench: Using both 'ProdDiag' and 'PD' is not allowed, configure any one in LIFT_Testbenches", 109 );
        return;
    }

    if ( defined $tbFunctions_href->{'ProdDiag'} ) {
        eval "use LIFT_ProdDiag";
        S_w2log( 3, " EQUIP_init_testbench: Calling PRD_init() \n" , 'blue' );
        $functionAreas_href = PRD_init();
        $initEquipment_href->{'FunctionAreas'}{'ProdDiag'} = $functionAreas_href;
    }

    # ECU must be switched on before PD can be initialized
    elsif ( defined $tbFunctions_href->{'PD'} ) {
        eval "use LIFT_PD";
        S_w2log( 3, " EQUIP_init_testbench: Calling PD_InitDiagnosis() \n" , 'blue' );
        PD_InitDiagnosis();
        S_w2log( 3, " EQUIP_init_testbench: Calling PD_InitCommunication() \n" , 'blue' );
        PD_InitCommunication();
        $initEquipment_href->{'FunctionAreas'}{'PD'}{'base'} = $tbFunctions_href->{'PD'};
    }

    # no known dependencies for below functions
    if ( defined $tbFunctions_href->{'CD'} ) {
        eval "use LIFT_CD";
        S_w2log( 3, " EQUIP_init_testbench: Calling CD_init() \n" , 'blue' );
        CD_init();
        S_w2log( 3, " EQUIP_init_testbench: Calling CD_start_simulation() \n" , 'blue' );
        CD_start_simulation();
        $initEquipment_href->{'FunctionAreas'}{'CD'}{'base'} = $tbFunctions_href->{'CD'};
    }

    if ( defined $tbFunctions_href->{'Temperature'} ) {
        eval "use LIFT_TEMPERATURE";
        S_w2log( 3, " EQUIP_init_testbench: Calling TEMP_init() \n" , 'blue' );
        $functionAreas_href = TEMP_init();
        $initEquipment_href->{'FunctionAreas'}{'Temperature'} = $functionAreas_href;
    }

    if ( defined $tbFunctions_href->{'SPI_Access'} ) {
        eval "use LIFT_spi_access";
        S_w2log( 3, " EQUIP_init_testbench: Calling SPI_init() \n" , 'blue' );
        $functionAreas_href = SPI_init();
        $initEquipment_href->{'FunctionAreas'}{'SPI_Access'} = $functionAreas_href;
    }

    S_w2log( 2, "EQUIP_init_testbench: finished \n\n" );

    return 1;
}

######################################################################

=head2 EQUIP_get_devices

    EQUIP_get_devices ( $functionArea , $functionGroup );

Returns the device(s) that is/are configured for the function area $functionArea and function group $functionGroup.
The function areas CAN_Access, FlexRay_Access and LIN_Access return device arrays (for backwards compatibility), 
all other function areas return scalars.
    
    Example:
    my @devices = EQUIP_get_devices ( 'CAN_Access' , 'read');
    my $device = EQUIP_get_devices ( 'Labcar' , 'line');
 
=cut

######################################################################

sub EQUIP_get_devices {
    my @args = @_;
    return unless S_checkFunctionArguments( 'EQUIP_get_devices ( $functionArea , $functionGroup )', @args );

    my $functionArea  = shift @args;
    my $functionGroup = shift @args;

    my $devices = $initEquipment_href->{'FunctionAreas'}{$functionArea}{$functionGroup};

    unless ($devices) {
        return;
    }

    if ( ref($devices) eq 'ARRAY' ) {
        return @{$devices};
    }
    else {
        return $devices;
    }
}

######################################################################

=head2 EQUIP_set_devices

    EQUIP_set_devices ( $functionArea , $devices_href );

=cut

######################################################################

sub EQUIP_set_devices {
    my @args = @_;
    return unless S_checkFunctionArguments( 'EQUIP_set_devices ( $functionArea , $devices_href )', @args );

    my $functionArea = shift @args;
    my $devices_href = shift @args;

    $initEquipment_href->{'FunctionAreas'}{$functionArea} = $devices_href;

    return 1;
}

1;

######################################################

=head2 EQUIP_main_init (old, kept for backwards compatibility)

    Function Name    :: EQUIP_main_init (old, kept for backwards compatibility)
    Description      :: Reads whether the Functional Area in Project Defaults is CAN or FR, and initialises according to it. 
    It will call EQUIP_CAN_ACCESS_init function if the Functional Area is CAN else EQUIP_FlexRay_ACCESS_init. 
    Syntax           :: EQUIP_main_init();
    Input Arguments  :: None 
    Return Value(s)  :: 1 - successful
    Example          :: EQUIP_main_init();

=cut

######################################################

sub EQUIP_main_init {
    S_set_warning("The function 'EQUIP_main_init' is obsolete and will be deactivated in future. Please use 'EQUIP_init_testbench' instead.");

    if ( defined $testbenchCopy_href ) {
        S_set_error( "EQUIP_init_testbench has been called before in this test run. Do not mix EQUIP_init_testbench and EQUIP_main_init. Use only EQUIP_init_testbench.\n", 109 );
        return 0;
    }

    $initEquipment_href = {};
    $testbench_href     = {};
    $testbench_href     = $LIFT_config::LIFT_Testbench;

    unless ( defined $testbench_href->{'Functions'} ) {
        S_set_error( "No entry found in testbench config (LIFT_Testbenches.pm) for LIFT host " . hostname . ". ( note : hostnames are case sensitive / 'localhost' is possible too ) \n", 21 );
        return 0;
    }

    S_w2log( 2, "\n Starting EQUIP_main_init for test bench $testbench_href...\n" );

    if ( $testbench_href->{'Functions'}{'CAN_Access'} )     { return unless EQUIP_CAN_ACCESS_init() }
    if ( $testbench_href->{'Functions'}{'FlexRay_Access'} ) { return unless EQUIP_FlexRay_ACCESS_init() }
    if ( $testbench_href->{'Functions'}{'LIN_Access'} )     { return unless EQUIP_LIN_ACCESS_init() }

    S_w2log( 2, "\n EQUIP_main_init finished \n\n" );

    return 1;
}

############################################################################################################

sub EQUIP_CAN_ACCESS_init {
    my $function;
    my $device;
    my $device_cnt;

    my $function_area = 'CAN_Access';

    S_w2log( 2, "\n Starting EQUIP_CAN_ACCESS_init...\n" );

    foreach $function ( keys %{ $testbench_href->{'Functions'}{$function_area} } ) {
        next if ref( $testbench_href->{'Functions'}{$function_area}{$function} ) ne 'ARRAY';
        $device_cnt = 0;
        foreach $device ( @{ $testbench_href->{'Functions'}{$function_area}{$function} } ) {

            if ( $device eq 'CANalyzer' ) {
                unless ( defined $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} ) {
                    if ( VEC_cantool_init( $device, $function, 'CAN' ) ) {
                        $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} = 1;
                        S_w2log( 1, " EQUIP_CAN_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                        push( @{ $initEquipment_href->{'FunctionAreas'}{$function_area}{$function} }, $device );
                        $device_cnt++;
                    }
                    else {
                        S_w2log( 1, " EQUIP_CAN_ACCESS_init : VEC_cantool_init not successful\n" );
                        return 0;
                    }
                }
                else {
                    # function on device was already initialized
                    S_w2log( 1, " EQUIP_CAN_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                    $device_cnt++;
                }
            }

            if ( $device eq 'CANoe' ) {
                unless ( defined $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} ) {
                    if ( VEC_cantool_init( $device, $function, 'CAN' ) ) {
                        $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} = 1;
                        S_w2log( 1, " EQUIP_CAN_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                        push( @{ $initEquipment_href->{'FunctionAreas'}{$function_area}{$function} }, $device );
                        $device_cnt++;
                    }
                    else {
                        S_w2log( 1, " EQUIP_CAN_ACCESS_init : VEC_cantool_init not successful\n" );
                        return 0;
                    }
                }
                else {
                    # function on device was already initialized
                    S_w2log( 1, " EQUIP_CAN_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                    $device_cnt++;
                }
            }

        }
    }

    return 1;
}

############################################################################################################

sub EQUIP_FlexRay_ACCESS_init {
    my $function;
    my $device;
    my $device_cnt;

    my $function_area = 'FlexRay_Access';

    S_w2log( 2, "\n Starting EQUIP_FlexRay_ACCESS_init...\n" );

    foreach $function ( keys %{ $testbench_href->{'Functions'}{$function_area} } ) {
        next if ref( $testbench_href->{'Functions'}{$function_area}{$function} ) ne 'ARRAY';
        $device_cnt = 0;
        foreach $device ( @{ $testbench_href->{'Functions'}{$function_area}{$function} } ) {

            if ( $device eq 'CANalyzer' ) {
                unless ( defined $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} ) {
                    if ( VEC_cantool_init( $device, $function, 'FlexRay' ) ) {
                        $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} = 1;
                        S_w2log( 1, " EQUIP_FlexRay_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                        push( @{ $initEquipment_href->{'FunctionAreas'}{$function_area}{$function} }, $device );
                        $device_cnt++;
                    }
                    else {
                        S_w2log( 1, " EQUIP_FlexRay_ACCESS_init : VEC_cantool_init not successful\n" );
                        return 0;
                    }
                }
                else {
                    # function on device was already initialized
                    S_w2log( 1, " EQUIP_FlexRay_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                    $device_cnt++;
                }
            }

            if ( $device eq 'CANoe' ) {
                unless ( defined $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} ) {
                    if ( VEC_cantool_init( $device, $function, 'FlexRay' ) ) {
                        $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} = 1;
                        S_w2log( 1, " EQUIP_FlexRay_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                        push( @{ $initEquipment_href->{'FunctionAreas'}{$function_area}{$function} }, $device );
                        $device_cnt++;
                    }
                    else {
                        S_w2log( 1, " EQUIP_FlexRay_ACCESS_init : VEC_cantool_init not successful\n" );
                        return 0;
                    }
                }
                else {
                    # function on device was already initialized
                    S_w2log( 1, " EQUIP_FlexRay_ACCESS_init : Function '$function' -> Device [$device_cnt] is '$device'\n" );
                    $device_cnt++;
                }
            }

        }
    }

    return 1;
}

######################################################################
sub EQUIP_LIN_ACCESS_init {
    my $function;
    my $device;

    my $function_area = 'LIN_Access';

    S_w2log( 2, "\n Starting EQUIP_LIN_ACCESS_init...\n" );

    foreach $function ( keys %{ $testbench_href->{'Functions'}{$function_area} } ) {
        next if ref( $testbench_href->{'Functions'}{$function_area}{$function} ) ne 'ARRAY';

        foreach $device ( @{ $testbench_href->{'Functions'}{$function_area}{$function} } ) {

            if ( $device eq 'CANoe' ) {
                unless ( defined $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} ) {
                    if ( VEC_cantool_init( $device, $function, 'LIN' ) ) {
                        $initEquipment_href->{'Devices'}{$device}{$function_area}{$function} = 1;
                        S_w2log( 1, " EQUIP_LIN_ACCESS_init : Function '$function' -> Device [$device] is '$device'\n" );
                        push( @{ $initEquipment_href->{'FunctionAreas'}{$function_area}{$function} }, $device );

                        #                  $device_cnt++;
                    }
                    else {
                        S_w2log( 1, " EQUIP_LIN_ACCESS_init : VEC_cantool_init not successful\n" );
                        return 0;
                    }
                }
                else {
                    # function on device was already initialized
                    S_w2log( 1, " EQUIP_LIN_ACCESS_init : Function '$function' -> Device [$device] is '$device'\n" );

                }
            }
        }
    }

    return 1;
}

__END__
