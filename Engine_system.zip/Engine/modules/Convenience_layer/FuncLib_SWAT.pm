#*****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package FuncLib_SWAT;

######################################################

=head1 NAME
FuncLib_SWAT

=head1 SYNOPSIS

    use FuncLib_SWAT

=head1 DESCRIPTION

   Software Acceptance tests from turbolift has generic functions for reading and writing global parameters.Using these global parameter's values test component stimulates testcase steps.
=head1 FUNCTIONS

    SWAT_TriggerTestID
    SWAT_ReadGlobalParameter
    SWAT_WriteGlobalParameter
    SWAT_EvaluateResult

=cut

######################################################

use strict;
use warnings;
use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_ProdDiag;

require Exporter;

our @ISA    = qw(Exporter);
our @EXPORT = qw(
  SWAT_TriggerTestID
  SWAT_ReadGlobalParameter
  SWAT_WriteGlobalParameter
  SWAT_EvaluateResult

);

=head2 SWAT_TriggerTestID

    $returnValue = SWAT_TriggerTestID($trigger_nbr [, $triggering_global_par,$wait_time_afterWrite_ms]);

Triggers testcase i.e sets the global triggering parameter to 1 , so that testcomponents initiates the testcase execution.

B<Arguments:>

=over

=item $trigger_nbr

Value to be written in global triggering parameter.(either 1 or 0).

=item $triggering_global_par 

(optional) Name of global parameter in which value to be written is stored.Default value is 'rb_BSWATTriggerTestID_u32' (eg: rb_BSWATTriggerTestID_u32)

=back

B<Return Value:>

=over

=item $returnValue 

1 if triggering is successfull or 0 if it is not successfull.

=back

B<Examples:>

    $returnValue = SWAT_TriggerTestID(3 , 'rb_BSWATTriggerTestID_u32');
    $returnValue = SWAT_TriggerTestID(2 , 'rb_BSWATReTriggerTestID_u32');

=cut

sub SWAT_TriggerTestID {
	my @args = @_;
	S_checkFunctionArguments( 'SWAT_TriggerTestID($trigger_nbr [, $triggering_global_par ])', @args ) or return;
	my $trigger_nbr             = shift @args;
	my $triggering_global_par   = shift @args;
	my $wait_time_afterWrite_ms = 500;

	$triggering_global_par = 'rb_BSWATTriggerTestID_u32'
	  unless ( defined($triggering_global_par) );

	S_w2log( 3, " SWAT_TriggerTestID: PRD_Write_Memory( $triggering_global_par, $trigger_nbr \n ", 'grey' );
	PRD_Write_Memory( $triggering_global_par, $trigger_nbr ) || return;

	S_wait_ms($wait_time_afterWrite_ms);
	my $options_href = { memoryContentsAsInteger => 1, };
	my $check_value = PRD_Read_Memory( $triggering_global_par, $options_href ) // return;
	S_w2log( 3, " Read Symbol $triggering_global_par => $check_value  \n", 'grey' );
	S_w2log( 3, "Global parameter $triggering_global_par has value---> $check_value after reading operation" );

	if ( $trigger_nbr == $check_value ) {
		S_w2rep("Triggering testcase is successful\n");
		return 1;
	}

	S_set_error("Triggering testcase is not successful : $triggering_global_par != $check_value");
	return 1;
}

=head2 SWAT_ReadGlobalParameter

    $returnValue = SWAT_ReadGlobalParameter($global_par_name[,$is_singleValue,$block_len,$allow_w2rep]);

Reads global paramater using parameter name.

B<Arguments:>

=over

=item $global_par_name

Value to be written in global triggering parameter.(either 1 or 0).

=item $is_singleValue

(optional) Flag to denote if value to be read is integer or array(1 or 0) default value =1

=item $block_len

(optional) Block length denotes number of bytes to be read form starting address 

=item $allow_w2rep

(optional) Use Case: If function called very often in a loop, set to 0 for shorter log-files, default =1

=back

B<Return Value:>

=over

=item $returnValue 

 value at address if reading is successfull.
 0 if it is not successfull.
 error = if value at address is  undef

=back

B<Examples:>

 1. For reading array of bytes
  $returnValue = SWAT_ReadGlobalParameter( 'rb_BSWAT_hsmRNGCheck_RandomData', 0, $tcpar_DataSizePerRequest );
 2. For reading integer
  $returnValue = SWAT_ReadGlobalParameter( 'rb_BSWAT_hsmRNGCheck_RandomData');
 3. For reading array of bytes, without writing to report
  $returnValue = SWAT_ReadGlobalParameter( 'rb_BSWAT_hsmRNGCheck_RandomData', 0, $tcpar_DataSizePerRequest, 0 );
 4. For reading integer, without writing to report
  $returnValue = SWAT_ReadGlobalParameter( 'rb_BSWAT_hsmRNGCheck_RandomData', 1, 1, 0);

=cut

sub SWAT_ReadGlobalParameter {
	my @args = @_;
	S_checkFunctionArguments( 'SWAT_ReadGlobalParameter($global_par_name[,$is_singleValue,$block_len,$allow_w2rep])', @args ) or return;
	my $global_par_name         = shift @args;
	my $is_singleValue          = shift @args; # opt
	my $block_len               = shift @args; # opt
	my $allow_w2rep             = shift @args; # opt
	my $wait_time_afterWrite_ms = 500;
	my $globalpar_Value;
	my $options_href;
	my @values_InBlockID_arr = ();
	$is_singleValue = 1 unless defined($is_singleValue);
	$allow_w2rep = 1 unless defined($allow_w2rep);

	S_w2log( 3, "Flag to check if value to be read from global parameter ($global_par_name) is integer \$is_singleValue = $is_singleValue" );

	if ($is_singleValue) {
		$options_href = { memoryContentsAsInteger => $is_singleValue };
		$globalpar_Value = PRD_Read_Memory( $global_par_name, $options_href );
		if ( $allow_w2rep ) {
			S_w2rep("SWAT_ReadGlobalParameter() :Reading Global parameter $global_par_name  =  $globalpar_Value");
		}
	}
	else {
		if ( $allow_w2rep ) {
			S_w2rep("Number of elements to be read = $block_len");
		}
		$options_href = {
			memoryContentsAsInteger => $is_singleValue,
			NbrOfBytes              => $block_len,
		};
		$globalpar_Value = PRD_Read_Memory_NOHTML( $global_par_name . "(0)", $options_href );

	}
	if ( defined($globalpar_Value) ) {
		return $globalpar_Value;
	}
	else { S_set_error("Global parameter $global_par_name is undefined"); }
	return 0;
}

=head2 SWAT_WriteGlobalParameter

    $returnValue = SWAT_WriteGlobalParameter($global_par_name,$value_to_write[,$allow_w2rep]);

Reads global paramater using parameter name.

B<Arguments:>

=over

=item $global_par_name

Value to be written in global triggering parameter.(either 1 or 0).

=item $value_to_write

value to be written in global paramter.

=item $allow_w2rep

(optional) Use Case: If function called very often in a loop, set to 0 for shorter log-files, default =1

=back

B<Return Value:>

=over

=item $returnValue 

 1 if writing is successfull.
 0 if it is not successfull.

=back

B<Examples:>

  $returnValue = SWAT_WriteGlobalParameter("rb_BSWAT_hsmRNGCheck_RandomDataLength_u16",2000);
  
  # Option to disable S_w2rep calls for reduced log-size
  $returnValue = SWAT_WriteGlobalParameter("rb_BSWAT_hsmRNGCheck_RandomDataLength_u16",2000,0);
    
=cut

sub SWAT_WriteGlobalParameter {
	my @args = @_;
	S_checkFunctionArguments( 'SWAT_WriteGlobalParameter($global_par_name,$value_to_write[,$allow_w2rep] )', @args )
	  or return;
	my $global_par_name         = shift @args;
	my $value_to_write          = shift @args;
	my $allow_w2rep             = shift @args; # opt
	$allow_w2rep = 1 unless defined($allow_w2rep);
	my $wait_time_afterWrite_ms = 500;

	S_w2log( 3, " SWAT_WriteGlobalParameter : PRD_Write_Memory( $global_par_name, $value_to_write \n ", 'grey' );
	PRD_Write_Memory( $global_par_name, $value_to_write ) || return;

	S_wait_ms($wait_time_afterWrite_ms);

	my $options_href = { memoryContentsAsInteger => 1, };
	my $check_value = PRD_Read_Memory( $global_par_name, $options_href ) // return;

	if ( $allow_w2rep ) {
		S_w2rep( "Global parameter $global_par_name has value---> $check_value after reading operation", 'grey' );
	}
	if ( $value_to_write == $check_value ) {
	    if ( $allow_w2rep ) {
			S_w2rep("Writing $value_to_write in $global_par_name is  successful\n");
	    }
		return 1;
	}
	S_set_warning("Writing $value_to_write in $global_par_name is not successful\n: $value_to_write != $check_value");
	return 0;
}

=head2 SWAT_EvaluateResult

	SWAT_EvaluateResult($result);

I<B<Description:>>	Evaluates testcase result using already mapped dictionary.Based on values result verdict is provided.

$result = Value of  Result variable read from test component.

I<B<Return:>Result is obtained after evaluation of obtained values with expected values from mapping.

I<B<Verdict:>> none

I<B<Error:>> as per S_checkFunctionArguments or if  obtained result value is not present in mapped dictionary.

=cut

=head2 SWAT_EvaluateResult

    $returnValue = SWAT_EvaluateResult($result);

Reads global paramater using parameter name.

B<Arguments:>

=over

=item $result

Result value obtained from test component.(either 0,1,2 or 3).

=back

B<Return Value:>

=over

=item $returnValue 

 1 if result value is present in mappping verdict.
 0 if result value is not present in mappping verdict.

=back

B<Examples:>

  $returnValue = SWAT_EvaluateResult(2);
  
=cut

sub SWAT_EvaluateResult {
	my @args = @_;
	S_checkFunctionArguments( 'SWAT_EvaluateResult($result)', @args ) or return;
	my $result                  = shift @args;
	my $map_intern_BSWAT_result = {
		3 => 'TEST_NOT_EXECUTED',      # constant. by default the test case is in not executed state
		2 => 'TEST_PASSED',            # constant. Value if the testcase is passed
		1 => 'TEST_FAILED',            # constant. Value if the testcase is failed
		0 => 'TEST_NOT_APPLICABLE',    # constant. Value if the testcase is not applicable (due to Compiler settings)
	};
	unless ( exists( $map_intern_BSWAT_result->{$result} ) ) { S_set_error("Given test verdict input for SWAT_EvaluateResult()  is invalid.Please pass correct arguments"); }
	S_w2rep("Obtained Result verdict is  $map_intern_BSWAT_result->{$result}");
	return 1;
}

1;
