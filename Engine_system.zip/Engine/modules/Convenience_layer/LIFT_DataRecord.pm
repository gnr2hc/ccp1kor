# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_DataRecord;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################

use strict;
use warnings;
use Moose;
use Moose::Util::TypeConstraints;
use Data::Dumper;
use namespace::autoclean;

use LIFT_general;
use LIFT_DataRecord::Member;
use HTML::Table;
use Data::Dumper;
$Data::Dumper::Indent = 0;
$Data::Dumper::Terse = 1;

require Exporter;

#our @ISA = qw(Exporter); # conflicts with BUILDARGS !

our @EXPORT = qw(
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_DataRecord 
=head1 SYNOPSIS

    use LIFT_DataRecord

    # create an empty data record object of type 'EDR'
    $dataRecordObject = LIFT_DataRecord -> create_data_record('EDR');

    # add header data to the data record and get value
    $success = $dataRecordObject -> add_data_member('RecordNumber', 1, 'Header');
    $value = $dataRecordObject -> get_header_value_raw('RecordNumber');

    # add a single data member to the empty record and get value
    $success = $dataRecordObject -> add_data_member('firstMember', 10, 'Member');
    $value = $dataRecordObject -> get_member_value_raw('firstMember');

    # add various data members from a raw data string
    # structure info describes which data elements are part of the raw data array
    $dataRecordObject -> add_members_from_raw_data($record_data_aref, $recordStructureInfo_href);

    # create a data record object of type 'DataRecord'
    # raw data is parsed according to mapping 'Mapping_DataRecord' which must be part of project defaults
    $dataRecordObject = LIFT_DataRecord -> create_data_record('DataRecord', $rawData_aref);

    # get decoded value of data member
    $value = $dataRecordObject -> get_member_value_decoded('VehicleSpeed');

    # prints the complete data
    $dataRecordObject -> print_HTML_Table("This is my data table");

=head1 DESCRIPTION

This data record class provides functions to store any kind of data record.

A data record consists of two sections: header section and member section.

The member section contains the actual data, while the header section could contain information like
diagnostic service with which the record was read, record number, record label, timestamp,...

A data record can have either only a header, only a member, or both sections.

There are two options to fill a data record with data:

1) Add all data member by member

2) Add all data at once by giving a chunk of raw data,
information on how the raw data is structured, 
and information about the members contained in the record.

=cut

=head1 ATTRIBUTES

=over

=item RecordType

Any type can be given here (e.g. EDR, SnapshotData, ExtendedData,...)

It must be considered that it is required to have a mapping of the members contained in the record
 if the record data is to be added from a chunk of raw data (option 2) in description).
 
The naming convention for this is: Mapping_RecordType

e.g.: Mapping_EDR, Mapping_SnapshotData, Mapping_ExtendedData

In the mapping, the section 'RAW_DATA_STRUCTURE' must be defined.

In this section, you can define one or more sections in your record.
In this example, there are two sections: 'HEADER_SECTION' and 'MEMBER_SECTION'.
It is possible to defined either or both of them, or a section with a different name.

Inside the section, the structure of the data must be defined.

Following options are available (all apply for HEADER and MEMBER section):


B<- Preceding identifier:>

This applies if each of the data members (or header elements) have an identifier which is an integer, 
and this identifier preceds the data values in the raw byte stream.

Mandatory attributes:

    'RAW_DATA_STRUCTURE' => {
        'HEADER_SECTION' => {
             # start counting bytes in response from 0,1,2,..
            'HEADER_SECTION_START_FROM_BYTE_INDEX' => '0',
             # ID followed by data -> only if member key is integer
            'HEADER_DATA_POSITION' => 'PRECEDING_IDENTIFIER',
             # ID nbr is one byte
            'HEADER_ID_LENGTH_IN_BYTE' => '1' ,
        },
        'MEMBER_SECTION' => {
             # start counting bytes in response from 0,1,2,..
            'MEMBER_SECTION_START_FROM_BYTE_INDEX' => '8' ,
             # ID followed by data -> only if member key is integer
            'MEMBER_DATA_POSITION' => 'PRECEDING_IDENTIFIER',
             # ID nbr is HIGHBYTE, LOWBYTE
            'MEMBER_ID_LENGTH_IN_BYTE' => '2' ,
        },
    },


B<- Ascending Order:>

This applies if each data member has an identifier which is an integer, 
and the data is reported without preceding identifier in ascending order of the IDs

Mandatory attributes:

    'RAW_DATA_STRUCTURE' => {
        'HEADER_SECTION' => {
             # start counting bytes in response from 0,1,2,..
            'HEADER_SECTION_START_FROM_BYTE_INDEX' => '0',
             # data in ascending order -> only if member key is integer
            'HEADER_DATA_POSITION' => 'ASCENDING_ORDER',
        },
        'MEMBER_SECTION' => {
             # start counting bytes in response from 0,1,2,..
            'MEMBER_SECTION_START_FROM_BYTE_INDEX' => '8' ,
             # data in ascending order -> only if member key is integer
            'MEMBER_DATA_POSITION' => 'ASCENDING_ORDER',
        },
    },


B<- Start byte index:>

This can be used in principle always. It makes sense if none of the other structures apply.

E.g. if there is on integer ID for a data element, or if the data elements are not reported in any logical order.

Note: In this case, the attribute 'StartByteIndex' must be given for each data member in the 'XXX_DATA_DEFINITION' sections!!

Mandatory attributes:

    'RAW_DATA_STRUCTURE' => {
        'HEADER_SECTION' => {
             # define 'StartByteIndex' for each header element
            'HEADER_DATA_POSITION' => 'BYTE_INDEX',
        },
        'MEMBER_SECTION' => {
             # define 'StartByteIndex' for each member
            'MEMBER_DATA_POSITION' => 'BYTE_INDEX',
        },
    },


B<- Fixed Order:>

This can be used if the data members are reported in a fixed order, but the IDs are no integers (i.e. ascending order does not apply).

Mandatory attributes:

    'RAW_DATA_STRUCTURE' => {
        'HEADER_SECTION' => {
             # start counting bytes in response from 0,1,2,..
            'HEADER_SECTION_START_FROM_BYTE_INDEX' => '0',
             # Header elements reported in fixed order
            'HEADER_DATA_POSITION' => 'FIXED_ORDER',
             # List of header keys in correct order
            'HEADER_LIST' => ['DiagService', 'DTC'] ,
        },
        'MEMBER_SECTION' => {
             # start counting bytes in response from 0,1,2,..
            'MEMBER_SECTION_START_FROM_BYTE_INDEX' => '8' ,
             #  Members reported in fixed order
            'MEMBER_DATA_POSITION' => 'FIXED_ORDER',
             # List of member keys in correct order
            'MEMBER_LIST' => ['Member1', 'Member2'],
        },
    },

=item RecordDataDescription

Hash which cotains the content of the record member mapping mentioned under attribute 'RecordType'

For the header data, the section 'HEADER_DATA_DEFINITION' must be defined.

For the member data, the sectoin 'MEMBER_DATA_DEFINITION' must be defined.

Each data element has first of all a key. This key can be either a string, or an integer. 
If the raw data structure type is 'PRECEDING_IDENTIFIER' or 'ASCENDING_ORDER', 
then the data element should have an ID that is an integer. This ID can either be the key itself, 
or it can be specified as attribute 'ID' for the data element.

The key is the access point to the data element from the test case.

B<Data attributes:>

    $Defaults -> {'Mapping_EDR'} = {
        'RAW_DATA_STRUCTURE' => {
            'HEADER_SECTION' => {
                #...
             },
    
            'MEMBER_SECTION' => {
                #...
             },
        },
        'HEADER_DATA_DEFINITION' => {
            'DTC' => { # 'DTC' is the data element key
                # specifies the number of bytes in a data sample
                'BytesPerDataSample' => 3, # MANDATORY
                # number of data samples
                'NumberOfDataSamples' => 1, # MANDATORY
                # start byte index in raw record data, count starts from 0
                'StartByteIndex' => 2, # MANDATORY for structure type 'BYTE_INDEX'
            },
        },
        
        'MEMBER_DATA_DEFINITION' => {
            'VehicleSpeed' => { # member key
                'Description' => 'COM signal with vehicle speed', # OPTIONAL
             # ID is an integer
             # can be given as attribute if member key is a string
             # MANDATORY for raw struct 'PRECEDING_IDENTIFIER', 'ASCENDING_ORDER'
                'ID' => 2,
                'BytesPerDataSample' => 1, # MANDATORY
                'NumberOfDataSamples' => 3, # MANDATORY
                'DataType' => 'numeric', # OPTIONAL, default: numeric
             # OPTIONAL, decoding info for numeric and continuous
                'Factor' => 2, 
                'Offset' => 100,
                'Unit' => 'kph',
            },
            'ExternalTemperature' => {
                #...
            },
        },
    }

=item MemberHash

Hash with list of member objects which are part of the data record

Key: Member key (same as in record member mapping), value: member object


=item MemberSectionMapping

Hash where members and sections are mapped to give the information which section a member belongs to.

Key: Member key, value: Section

=cut

has RecordType => ( is => "rw", isa => 'Str');
has MemberHash => ( is => "rw", isa => 'HashRef[Member]' );
has MemberSectionMapping => (is => "rw", isa => 'HashRef');
has HeaderDataHash => ( is => "rw", isa => 'HashRef[Member]' );

# in around BUILDARGS we can check the arguments (attributes) given to the contructor before the object is created
around BUILDARGS => sub{
    my $orig = shift;
    my $class = shift;
    my @args = @_;

    my $attributes_href;
    my $attributes = $args[0];
    my $attributesString = Dumper($attributes);
    my $callText = "LIFT_DataRecord->new( $attributesString ) was called.";

    if( not defined $attributes ){
        S_w2log(4, "LIFT_DataRecord->new() was called.\n");
        return $class->$orig();
    }

    if( ref( $attributes ) eq '' ){ # argument is a scalar
        $attributes_href = {RecordType => $attributes}; # convert into a hashref
    }
    else{
        $attributes_href = $attributes; # assume it is already a hashref
    }

    my $attributesRef = ref( $attributes_href );
    if( $attributesRef eq 'HASH' ) {
        my @attributesKeys = keys %$attributes_href;
        if( @attributesKeys > 1 ) {
            S_set_error("$callText Too many keys (@attributesKeys) given in argument hash. Only key 'RecordType' is allowed.", 109);
            return $class->$orig();
        }
        my $attributeKey = $attributesKeys[0];
        if( $attributeKey ne 'RecordType' ) {
            S_set_error("$callText Wrong key ($attributeKey) given in argument hash. Only key 'RecordType' is allowed.", 109);
            return $class->$orig();
        }
    }
    else{
        S_set_error("$callText Argument is a $attributesRef reference, but it must be a SCALAR or a HASH reference", 109);
        return $class->$orig();
    }

    S_w2log(4, "$callText\n");
    return $class->$orig($attributes_href);
};


=head1 METHODS

=head2 create_data_record

    $dataRecordObject = LIFT_DataRecord -> create_data_record( $recordType [, $rawData_aref] );

Creates a data record object of the type $recordType

=over

B<Input parameters:>

=item '$recordType'

String which describes the type of record which is to be added. 
This could be 'EDR' or 'SnapshotData', but also 'AllMySwitches'.

=item '$rawData_aref'

Array reference of raw data bytes. 
If this optional parameter is given, then the record which is created will directly be filled with data elements. 
Therefore, a mapping is required which describes the structure of the raw data, 
as well as the data elements which are inside the record. 
The function will look for a mapping in project defaults named: 
"Mapping_$recordType" -> if $recordType = 'EDR', 'Mapping_EDR'

See L</"ATTRIBUTES"> for mapping details.

=back

B<Different use Cases>:

B<usecase 1: no data given>: Create an empty data record object which can be filled with values later

    dataRecordObject = LIFT_DataRecord -> create_data_record( 'MySwitchStates' );
    $dataRecordObject -> add_data_member('Switch_BLFD', 0x01); # adds data element 'Switch_BLFD'

B<usecase 2: data given>: Create a data record object with content

    dataRecordObject = LIFT_DataRecord -> create_data_record( 'EDR', $edr_data_aref );
    $dataRecordObject -> print_HTML_Table(); # prints EDR record

B<Return values>:

Returns data record object on success, 0 otherwise

=cut

sub create_data_record{
    my $class = shift;
    my @args = @_;

    S_checkFunctionArguments( 'create_data_record( $recordType [, $rawData_aref] )', @args ) or return;

    my $recordType = shift @args;

    my $dataRecord_obj = $class -> new($recordType);

    my $rawData_aref = shift @args;

    # No raw data given - record will stay empty
    return $dataRecord_obj unless(defined $rawData_aref);

    my $rawDataStructure_href = S_get_contents_of_hash(["Mapping_$recordType"]);

    if(not defined $rawDataStructure_href){
        S_set_error("No members can be added to record, as there is no data structure defined for the given raw data");
        return;
    }

    # parse raw data and add record members
    $dataRecord_obj -> add_members_from_raw_data($rawData_aref, $rawDataStructure_href);

    return $dataRecord_obj;
}

=head2 add_data_member

    $success = $dataRecord_obj -> add_data_member(  $dataElementKey,
                                                    $rawValue 
                                                    [, $section, 
                                                    $dataDecodingInfo_href]);

With this function, a data element can be added to the record.
The data element can be added to a specific section in the record: e.g. data, header, generic, OEM,...

Input parameters:

=over

=item Data Element Key ($dataElementKey)

This is the access point from outside to the data element. 
Whenever any information about the data element is required (like raw or decoded value),
then the data element key is usually the first and manatory input to the LIFT_DataRecord function that fetches the value.

=item Raw Value ($rawValue)

The raw value can be either an array of bytes, or a single scalar value.

=item Section ($section) OPTIONAL

The section can be, 'Header', 'Data', or anything else. If it is not given, the default is considered as 'Member'.
The newly added data element will be part of the specified section

=item Member decoding Info ($dataDecodingInfo_href) OPTIONAL

The member decoding info is optional, and used to interpret the raw data values. 
If it is not given, only the raw value of the data element will be accessible.

There are different types of decoding information: 'numeric', 'interpreted', 'continuous', 'bitfield'

Depending on the type, the attributes given in the decoding info hash ref will be different.

B<Example 1: numeric>

    $dataDecodingInfo_href = {
        'Description' => 'This is my favorite data element', # optional
        'BytesPerDataSample' => 2, # mandatory
        'DataSamples' => 1, # mandatory
        'Factor' => 2, # default if not given: 1
        'Offset' => 4, # default if not given: 0
        'Unit' => 'kph' # optional
    }

B<Example 2: interpreted>

    $dataDecodingInfo_href = {
        'Description' => 'This is my favorite data element', # optional
        'BytesPerDataSample' => 2, # mandatory
        'DataSamples' => 1, # mandatory
        'DataValueTable' => { # mandatory
            2 => 'PositionA',
            3 => 'PositionB',
            0x01 => 'PositionC',
        }
    }
  
=back

Returns 1 on success, 0 otherwise

=cut

sub add_data_member{
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'add_data_member( $memberKey, $rawValue_mix [, $section, $dataDecodingInfo_href] )', @args ) or return;

    my $dataElementKey = shift @args;
    my $rawValue = shift @args;
    my $section = shift @args;
    my $dataDecodingInfo_href = shift @args;

    $section = 'member' if(not defined $section);

    if(lc($section) ne 'member' and lc($section) ne 'header'){
        S_set_error("Can't add member '$dataElementKey' because given data section is not known. Must be 'Header' or 'Member'.");
        return;
    }

    my $success = 1;
    if(ref($rawValue) eq 'ARRAY'){
        $self -> {MemberHash} -> {$section} -> {$dataElementKey} = Member -> new({ RawValuesArray => $rawValue,
                                                                DecodingInformation => $dataDecodingInfo_href});
        $success = $self -> {MemberHash} -> {$section} -> {$dataElementKey} -> decode() if(defined $dataDecodingInfo_href);
        $self -> {MemberSectionMapping} -> {$dataElementKey} = $section;
    }
    elsif(ref($rawValue) eq ''){
       $self -> {MemberHash} -> {$section} -> {$dataElementKey} = Member -> new({ RawValue => $rawValue,
                                                                DecodingInformation => $dataDecodingInfo_href});
       $success = $self -> {MemberHash} -> {$section} -> {$dataElementKey} -> decode() if(defined $dataDecodingInfo_href); 
       $self -> {MemberSectionMapping} -> {$dataElementKey} = $section;
    }
    else {
        S_set_error("Can't add member '$dataElementKey' because given raw value $rawValue is not in the expected format (array or scalar)");
        return;
    }

    return $success;
}


=head2 add_members_from_raw_data

    $success = $dataRecord_obj -> add_members_from_raw_data( $rawData_aref, $rawDataStructure_href [, $section] );

With this function, various members can be added to the data record at the same time. 
As input, an array of bytes can be given. 
Additionally, the structure information for the raw data must be given as well 
as the definition of the data members in the byte stream.

Input parameters:

=over

=item Raw Data ($rawData_aref)

Array reference with bytes of raw data. E.g. these raw data bytes might be the response of a diagnostic service. 

=item Raw Data Structure ($rawDataStructure_href)

The hash strucure shall be the same as described for the data mapping here: See L</"ATTRIBUTES"> for mapping details. 
In principle, it gives information about how the raw data is structured and which data is stored in the raw data stream.

=item Section (OPTIONAL)

This parameter is optional and describes a specific section that shall be added. 
If the section is given, then only the information related to this section is extracted from the Raw data structure mapping. 
If the section is not given, then the raw data will be interpreted for ALL sections defined in the raw data structure mapping.

=back

Returns 1 on success, 0 otherwise

=cut
sub add_members_from_raw_data{
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'add_members_from_raw_data( $rawData_aref, $rawDataStructure_href [, $section] )', @args ) or return;

    my $rawData_aref = shift @args;
    my $rawDataStructure_href = shift @args;
    my $section = shift @args;
    
    my @record_sections;

    if(not defined $section){
        my $parsingInformation_href =  $rawDataStructure_href -> {'RAW_DATA_STRUCTURE'};
        unless($parsingInformation_href){
            S_set_error("add_members_from_raw_data : Parsing information attribute 'RAW_DATA_STRUCTURE' does not exist in given raw data strucutre.");
            return;
        }
        foreach my $sectionMappingKey (keys %{$rawDataStructure_href -> {'RAW_DATA_STRUCTURE'}}){
            $sectionMappingKey =~ /(.*)_SECTION$/;
            push(@record_sections, $1) if(defined $1);
        }
    }
    else {
        @record_sections = ($section);
    }

    my $parsingSuccess = 1;
    
    foreach my $record_section (@record_sections)
    {
        my $sectionStructure_href = $rawDataStructure_href -> {'RAW_DATA_STRUCTURE'} -> {"$record_section\_SECTION"};
        unless($sectionStructure_href){
            S_set_error("add_members_from_raw_data : No parsing information provided in 'RAW_DATA_STRUCTURE' for section $record_section.");
            return;
        }
    
        my $parseType = $sectionStructure_href -> {"$record_section\_DATA_POSITION"};
        if(not defined $parseType){
            S_set_error("$record_section\_SECTION defined but no parsing info '$record_section\_DATA_POSITION'.\n"
                        ."Must be given as: BYTE_INDEX, PRECEDING_IDENTIFIER, ASCENDING_ORDER, or FIXED_ORDER");
            return;
        }
        my $sectionData_href = $rawDataStructure_href -> {"$record_section\_DATA_DEFINITION"};
        unless (defined $sectionData_href){
            S_set_error("$record_section\_DATA_DEFINITION not defined.\n"
                        ."Please define in this section the content of the record.");
            return;
        }
        if(lc($parseType) eq 'byte_index'){
            my $success = $self -> _parse_with_start_byte_index($record_section, $rawData_aref, $sectionData_href);
            $parsingSuccess = 0 unless($success);
        }
        elsif(lc($parseType) eq 'fixed_order'){
            my $dataSectionStartByteIndex = $sectionStructure_href -> {"$record_section\_SECTION_START_FROM_BYTE_INDEX"};
            if(not defined $dataSectionStartByteIndex){
                S_set_error("Parsing style '$parseType' requires definition of '$record_section\_SECTION_START_FROM_BYTE_INDEX' in 'MEMBER_SECTION' mapping");
                return;
            }
            my $dataList_aref = $sectionStructure_href -> {"$record_section\_LIST"};
            if(not defined $dataList_aref){
                S_set_error("Parsing style '$parseType' requires definition of '$record_section\_LIST' in '$record_section\_SECTION' mapping");
                return;
            }
            my $success = $self -> _parse_with_fixed_order($record_section, $dataSectionStartByteIndex, $dataList_aref, $rawData_aref, $sectionData_href);
            $parsingSuccess = 0 unless($success);
        }
        elsif(lc($parseType) eq 'preceding_identifier'){
            my $dataSectionStartByteIndex = $sectionStructure_href -> {"$record_section\_SECTION_START_FROM_BYTE_INDEX"};
            if(not defined $dataSectionStartByteIndex){
                S_set_error("Parsing style '$parseType' requires definition of '$record_section\_SECTION_START_FROM_BYTE_INDEX' in 'MEMBER_SECTION' mapping");
                return;
            }
            my $id_Length = $sectionStructure_href -> {"$record_section\_ID_LENGTH_IN_BYTE"};
            if(not defined $id_Length){
                S_set_error("Parsing style '$parseType' requires definition of '$record_section\_ID_LENGTH_IN_BYTE' in '$record_section\_SECTION' mapping");
                return;
            }
            my $success = $self -> _parse_with_preceding_id($record_section, $dataSectionStartByteIndex, $id_Length, $rawData_aref, $sectionData_href);
            $parsingSuccess = 0 unless($success);            
        }
        else{
                S_set_error("Parsing style '$parseType' not known.\n".
                            "Supported are: BYTE_INDEX, PRECEDING_IDENTIFIER, ASCENDING_ORDER, or FIXED_ORDER");
                return;
        }     
    }

    return $parsingSuccess;
}

=head2 get_member_value_decoded

    $decodedValue = $dataRecord_obj -> get_member_value_decoded( $memberKey );

This function returns the decoded data value of the given member key.
The decoded value is according to the interpretation information given in the data definition section of the record mapping.

With the 'DataType', the different decoding types can be selected. Default if it is not given is 'numeric'.

Following data types are supported:

=over

=item numeric

For the numeric data type, 'Factor' and 'Offset' given in the mapping will be applied to the raw data according to following formula:

    Decoded Value = (Raw Value * Factor) + Offset

Default for 'Factor' if not given: 1

Default for 'Offset' if not given: 0

Additionally, the attribute 'Unit' can be defined for this data type.

Example:

        '<SECTION>_DATA_DEFINITION' => {
            'VehicleSpeed' => { # member key
                'Description' => 'COM signal with vehicle speed', # OPTIONAL
                'ID' => 2, # OPTIONAL
                'BytesPerDataSample' => 1, # MANDATORY
                'NumberOfDataSamples' => 3, # MANDATORY
                'DataType' => 'numeric', # OPTIONAL, default: numeric
             # OPTIONAL, decoding info for numeric and continuous
                'Factor' => 2, 
                'Offset' => 100,
                'Unit' => 'kph',
            },
            'ExternalTemperature' => {
                #...
            },
        },
        
=item continuous (TO BE IMPLEMENTED)

Decoding formula and attributes given are same as for numeric data type.

    Decoded Value = (Raw Value * Factor) + Offset

Default for 'Factor' if not given: 1

Default for 'Offset' if not given: 0

Other than numeric, this data type always consists of a number of data samples. 
These data samples have a timing relation between each other. 
That means that it is required to give a sample rate, as well as a recording start and end type.

Absolutely mandatory is the Sample Rate in Hz: 'SampleRate_Hz'

Default for 'StartTime_sec': 0
Default for 'EndTime_sec' : Calculated based on sample rate and 'StartTime_sec'

If SampleRate_Hz and EndTime_sec are given, a consistency check is performed.

Example:

        '<SECTION>_DATA_DEFINITION' => {
            'VehicleSpeed' => { # member key
                'Description' => 'COM signal with vehicle speed', # OPTIONAL
                'ID' => 2, # OPTIONAL
                'BytesPerDataSample' => 1, # MANDATORY
                'NumberOfDataSamples' => 3, # MANDATORY
                'DataType' => 'numeric', # OPTIONAL, default: numeric
             # OPTIONAL, decoding info for numeric and continuous
                'Factor' => 2, 
                'Offset' => 100,
                'Unit' => 'kph',
                'SampleRate_Hz' => 10, #MANDATORY
                'StartTime_sec' => -1, # OPTIONAL, default: 0
                'EndTime_sec' => -0.7, # OPTIONAL, calculated based on sample rate if not given
            },
            'ExternalTemperature' => {
                #...
            },
        },

=item interpreted (TO BE IMPLEMENTED)

For this data type, a data value table has to be given in the mapping.

In this data interpretation table, descriptions or meanings for certain raw values can be given.

        '<SECTION>_DATA_DEFINITION' => {
            'Switch_BLFD' => { # member key
                'Description' => 'belt lock front driver', # OPTIONAL
                'BytesPerDataSample' => 1, # MANDATORY
                'NumberOfDataSamples' => 3, # MANDATORY
                'DataType' => 'interpreted', # OPTIONAL, default: numeric
             # MANDATORY, decoding info for interpreted
                'DataInterpretationTable' => {
                    0x00 => 'Faulty'
                    0x01 => 'PositionA',
                    0x02 => 'PositionB',
                },
            },
            'ExternalTemperature' => {
                #...
            },
        },

=item bitfield (TO BE IMPLEMENTED)

Bit interpreted data which requires 'BitFieldDefinition' in the mapping file.

Bits always start counting with 0 from right to left of a data sample.

        '<SECTION>_DATA_DEFINITION' => {
            'Switch_Configuration' => { # member key
                'Description' => 'bitfield which contains configuration status of all switches', # OPTIONAL
                'BytesPerDataSample' => 1, # MANDATORY
                'NumberOfDataSamples' => 1, # MANDATORY
                'DataType' => 'interpreted', # OPTIONAL, default: numeric
             # MANDATORY, decoding info for interpreted
                'BitFieldDefinition' => {
                    'b0' => 'BLFD_Configured'
                    'b1' => 'BLFP_Configured',
                    'b2' => 'BLFC_Configured',
                    #...
                },
            },
            'ExternalTemperature' => {
                #...
            },
        },


=back

B<Return values:>

On success, the decoded value of the member is returnd. Depending on the data type, this can be a string, or an integer, or a hash ref (e.g. in case of bitfield).

For data members with more than one data samples, an array with decoded values is returned.

In case of error, undef is returned.

=cut

sub get_member_value_decoded{
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'get_member_value_decoded( $memberKey )', @args ) or return;

    my $memberKey = shift @args;
    
    my $memberSection = $self -> {MemberSectionMapping} -> {$memberKey};
    if(not defined $memberSection){
        S_set_error("Given member key '$memberKey' does not exist in any record section");
        return;        
    }

    if(not defined $self -> {MemberHash} -> {$memberSection} -> {$memberKey}){
        S_set_error("Given member key '$memberKey' does not exist in record");
        return;
    }

    my $decodedValue = $self -> {MemberHash} -> {$memberSection} -> {$memberKey} -> DecodedValue;
    if(not defined $decodedValue){
        $decodedValue = $self -> {MemberHash} -> {$memberSection} -> {$memberKey} -> DecodedValuesArray;
    }

    return $decodedValue;
}

=head2 get_member_value_raw

    $rawValue = $dataRecord_obj -> get_member_value_raw( $memberKey [,$format] );

This function returns the raw value (data sample wise) of the given data member. 
The default format is hex, dec can be selected alternatively.

B<Input parameters:>

=over

=item Member Key

The parameter $memberKey is the unique identifier of the data member. 
It is used to identify the member for which the data shall be read.

=item Format (OPTIONAL)

Default value for the format is 'hex'.
Alternativeley, 'dec' can be selected.
The parameter describes the

=back

B<Return values:>

On success, the raw value of the data member is returned in hex or decimal format (depending on input parameter 'format')

The data is returned data sample wise, which means that for members with more than 1 data sample, an array of the raw data sample values is returned.

In case of error, undef is returned

=cut

sub get_member_value_raw{
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'get_member_value_raw( $memberKey [,$format] )', @args ) or return;

    my $memberKey = shift @args;
    my $format = shift @args;
    
    if(not defined $format){
        $format = 'hex';
    }
    if(not lc($format) =~ m/hex|dec/){
        S_set_error("Given format '$format' not known - supported is 'hex' or 'dec'");
        return;
    }

    my $memberSection = $self -> {MemberSectionMapping} -> {$memberKey};
    if(not defined $memberSection){
        S_set_error("Given member key '$memberKey' does not exist in any record section");
        return;        
    }


    if(not defined $self -> {MemberHash} -> {$memberSection} -> {$memberKey}){
        S_set_error("Given member key '$memberKey' does not exist in record");
        return;
    }

    my $rawValue;
    $rawValue = $self -> {MemberHash} -> {$memberSection} -> {$memberKey} -> RawValueDataSample if(lc($format) eq 'dec');
    $rawValue = $self -> {MemberHash} -> {$memberSection} -> {$memberKey} -> RawValue_Hex if(lc($format) eq 'hex');

    if(not defined $rawValue){
        $rawValue = $self -> {MemberHash} -> {$memberSection} -> {$memberKey} -> RawValueDataSamples if(lc($format) eq 'dec');
        $rawValue = $self -> {MemberHash} -> {$memberSection} -> {$memberKey} -> RawValueDataSamples_Hex if(lc($format) eq 'hex');
    }

    return $rawValue;
}

=head2 print_HTML_Table

    $success = $dataRecord_obj -> print_HTML_Table( [$caption]);

This function can be used to print all the record data to an HTML Table. 
All data members which are present inside the record when calling this function will be printed. 
The data will be printed section wise, the members inside a section will be alphabetically sorted.

Columns that will be printed: 'Key', 'Value', 'Unit', 'RawValue [hex]', 'Description'

The first printed 'Value' is the decoded value followed by the unit. 
For reference, additionally the raw value is printed in hex. 
If a description is available for a member, it will be printed in the last column of the table.

Input parameters:

=over

=item Caption (OPTIONAL)

The optional parameter $caption is a string which will be printed above the table as caption. 
This is useful to identify the table especially if various records of the same record type are printed. 
In case no caption is given, the attribute record attribute 'RecordType' will be used as caption.

=back

Returns 1 on success, 0 otherwise

=cut
sub print_HTML_Table {

    my $self = shift;
    my $caption = shift;

    my $dataRecordTable = HTML::Table -> new(
                            -align=>'center',
                            -rules => 'all',
                            -border=>1,
                            -width=>'50%',
                            -spacing=>0,
                            -padding=>3,
                            -style=>'color: black',);

    if(not defined $caption){
        $caption = "Record ".$self -> {RecordType};
    }

    $dataRecordTable -> setCaption($caption);
    $dataRecordTable -> addRow('Key', 'Value', 'Unit', 'RawValue [hex]', 'Description');
    $dataRecordTable -> setRowBGColor(1, "#E2E8EE");

    my $rowCount = 2;
    foreach my $section(sort keys %{$self -> {MemberHash}}){
        my @dataThisSectionHeading;
        push(@dataThisSectionHeading, $section); #Key
        # merge cells for this row
        $dataRecordTable -> addRow(@dataThisSectionHeading);
        $dataRecordTable -> setRowBGColor($rowCount, "#BFD6DE");
        $dataRecordTable -> setCellColSpan($rowCount, 1, 5); #Column Key spanned over 5 columns

        $rowCount++;

        foreach my $memberElement(sort keys %{$self -> {MemberHash}->{$section}}){
            my @dataThisRow;
            push(@dataThisRow, $memberElement); #Key
    
            my $decodedData = $self -> get_member_value_decoded($memberElement);
            $decodedData = _aref_to_string($decodedData) if(ref($decodedData) eq 'ARRAY');
            push(@dataThisRow, $decodedData);            
    
            my $decodingInfo = $self -> {MemberHash} -> {$memberElement} -> {DecodingInformation};
            push(@dataThisRow, $decodingInfo -> {'Unit'}); #Unit
    
            my $rawData = $self -> get_member_value_raw($memberElement, 'hex');
            $rawData = _aref_to_string($rawData) if(ref($rawData) eq 'ARRAY');
            push(@dataThisRow, '0x'.$rawData);
    
            push(@dataThisRow,  $self -> {MemberHash} -> {$memberElement} -> {Description});
            $dataRecordTable -> addRow(@dataThisRow);
            $dataRecordTable -> setRowBGColor($rowCount, "#CBE8F3");
            $rowCount++;
        }
    }

    push( @TC_HTML_TEXT, $dataRecordTable);

    return 1;
}

=head2 INTERNAL FUNCTIONS

=cut
=head3 _parse_with_start_byte_index

    $success = $dataRecord_obj -> _parse_with_start_byte_index( $section, $rawData_aref, $memberDataStructure_href );

Internal function which is called for data structured with a fixed start byte index. 
In this case the start byte index has to be given for each data element.

The function throws an error in case the start byte index given in the mapping for a data member exceeds the size of the given raw data. 
In case no start byte index is defined for a member, the member will be skipped!

Returns 1 on success, 0 otherwise

=cut
sub _parse_with_start_byte_index {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( '_parse_with_start_byte_index( $section, $rawData_aref, $memberDataStructure_href )', @args ) or return;

    my $section = shift @args;
    my $rawData_aref = shift @args;
    my $memberDataStructure_href = shift @args;

    my $numberOfRawDataBytes = @{$rawData_aref};
    
    my $success = 1;

    foreach my $memberKey (keys %{$memberDataStructure_href}){
        my $startByteIndex = $memberDataStructure_href -> {$memberKey} -> {'StartByteIndex'};
        unless(defined $startByteIndex){
            S_set_error("Attribute 'StartByteIndex' not defined for member '$memberKey'. Parsing continues with next member.");
            $success = 0;
            next;
        }
        my $numberOfDataSamples = $memberDataStructure_href -> {$memberKey} -> {'NumberOfDataSamples'};
        unless($numberOfDataSamples){
            S_set_error("Attribute 'NumberOfDataSamples' not defined or 0 for member '$memberKey'. Parsing continues with next member.");
            $success = 0;
            next;
        }
        my $bytesPerDataSample = $memberDataStructure_href -> {$memberKey} -> {'BytesPerDataSample'};
        unless($bytesPerDataSample){
            S_set_error("Attribute 'BytesPerDataSample' not defined or 0 for member '$memberKey'. Parsing continues with next member.");
            $success = 0;
            next;
        }

        my $numberOfBytes = $numberOfDataSamples * $bytesPerDataSample;

        my $currentByteIndex = $startByteIndex;
        if(($currentByteIndex + $numberOfBytes) > $numberOfRawDataBytes and not ($main::opt_offline)){
            S_set_error("Member $memberKey can't be added as the start or end byte index is greater than the number of bytes available.\n".
            "Start byte index: $startByteIndex, Number of bytes member: $numberOfBytes, Number of bytes record: $numberOfRawDataBytes");
            return;
        }

        my $thisMemberRawData_aref;
        foreach my $byte (1..$numberOfBytes){
            if(not (defined $rawData_aref -> [$currentByteIndex]) and ($main::opt_offline)){
                $rawData_aref -> [$currentByteIndex] = 1;
            }
            push(@{$thisMemberRawData_aref}, $rawData_aref -> [$currentByteIndex]);
            $currentByteIndex++;
        }

        if(@{$thisMemberRawData_aref} == 1){
            $self -> add_data_member($memberKey, $thisMemberRawData_aref -> [0], $section, $memberDataStructure_href -> {$memberKey});
        }
        elsif(@{$thisMemberRawData_aref} > 1){
            $self -> add_data_member($memberKey, $thisMemberRawData_aref, $section, $memberDataStructure_href -> {$memberKey});
        }
    }

    return $success;
}

=head3 _parse_with_fixed_order

    $success = $dataRecord_obj -> _parse_with_fixed_order( $section, $dataSectionStartByteIndex, $memberList_aref, $rawData_aref, $memberDataStructure_href  );

Internal function which parses the raw data based on a fixed list of members. 
The data is expected in the order as the members are inside the array.

An error will be thrown in case one of the given members is not part of the data definition hash 
or the data stream is shorter than the number of bytes that would be required to add data for all members given in the fixed list.

Returns 1 on success, 0 otherwise

=cut
sub _parse_with_fixed_order {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( '_parse_with_fixed_order( $section, $dataSectionStartByteIndex, $memberList_aref, $rawData_aref, $memberDataStructure_href )', @args ) or return;

    my $section = shift @args;
    my $dataSectionStartByteIndex = shift @args;
    my $memberList_aref = shift @args;
    my $rawData_aref = shift @args;
    my $memberDataStructure_href = shift @args;

    $rawData_aref = _create_dummy_offline_data($memberDataStructure_href, $dataSectionStartByteIndex) if($main::opt_offline);

    my $numberOfRawDataBytes = @{$rawData_aref};

    my $currentByteIndex = $dataSectionStartByteIndex;
    my @listOfMissingMembers;
    foreach my $memberKey (@{$memberList_aref}){
        if(not defined $memberDataStructure_href -> {$memberKey}){
            S_set_error("Member '$memberKey' could not be found in mapping - parsing of raw data will be aborted.");
            return;
        }

        my $numberOfDataSamples = $memberDataStructure_href -> {$memberKey} -> {'NumberOfDataSamples'};
        unless($numberOfDataSamples){
            S_set_error("Attribute 'NumberOfDataSamples' not defined or 0 for member '$memberKey'. Parsing aborted.");
            return;
        }
        my $bytesPerDataSample = $memberDataStructure_href -> {$memberKey} -> {'BytesPerDataSample'};
        unless($bytesPerDataSample){
            S_set_error("Attribute 'BytesPerDataSample' not defined or 0 for member '$memberKey'. Parsing aborted.");
            return;
        }
        my $numberOfBytes = $numberOfDataSamples * $bytesPerDataSample;

        if(($currentByteIndex + $numberOfBytes) > $numberOfRawDataBytes){
            S_set_error("Member $memberKey can't be added as the start or end byte index is greater than the number of bytes available.\n".
            "Start byte index: $currentByteIndex, Number of bytes member: $numberOfBytes, Number of bytes record: $numberOfRawDataBytes");
            return;
        }

        my $thisMemberRawData_aref;
        foreach my $byte (1..$numberOfBytes){
            push(@{$thisMemberRawData_aref}, $rawData_aref -> [$currentByteIndex]);
            $currentByteIndex++;
        }

        if(@{$thisMemberRawData_aref} == 1){
            $self -> add_data_member($memberKey, $thisMemberRawData_aref -> [0], $section, $memberDataStructure_href -> {$memberKey});
        }
        elsif(@{$thisMemberRawData_aref} > 1){
            $self -> add_data_member($memberKey, $thisMemberRawData_aref, $section, $memberDataStructure_href -> {$memberKey});
        }
        else{
            S_set_warning("No data found for $section '$memberKey'. Will not be created");
        }
    }

    return 1;
}

=head3 _parse_with_preceding_id

    $success = $dataRecord_obj -> _parse_with_preceding_id( $section, $dataSectionStartByteIndex, $id_Length, $rawData_aref, $memberDataStructure_href );

Internal function for parsing data with preceding ID. The ID length can be defined. 
Error will be thrown in case an ID is not there in the data definition mapping, 
if the record length is too short, 
if attribute 'BytesPerDataSample' is not defined, 
if attribute 'NumberOfDataSamples' is not defined.

Returns 1 on success, 0 otherwise

=cut
sub _parse_with_preceding_id {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( '_parse_with_preceding_id( $section, $dataSectionStartByteIndex, $idLength, $rawData_aref, $memberDataStructure_href )', @args ) or return;

    my $section = shift @args;
    my $dataSectionStartByteIndex = shift @args;
    my $id_Length = shift @args;
    my $rawData_aref = shift @args;
    my $memberDataStructure_href = shift @args;
    
    my $id_to_memberKey_mapping_href = _map_member_keys_to_ID($memberDataStructure_href);

    $rawData_aref = _create_dummy_offline_data($memberDataStructure_href, $dataSectionStartByteIndex, $id_Length) if($main::opt_offline);

    my $numberOfRawDataBytes = @{$rawData_aref};
    S_w2log(4, "LIFT_DataRecord -> _parse_with_preceding_id: Number of bytes in record: $numberOfRawDataBytes, Type: $section, data section start byte: $dataSectionStartByteIndex, id length: $id_Length");

    my $currentRecordByteIndex = $dataSectionStartByteIndex;
    if($currentRecordByteIndex >= $numberOfRawDataBytes - 1){
        S_set_error("No data available - data section start byte index is greater than (or equal to) number of raw data bytes.");
        return;
    }

    while($currentRecordByteIndex < $numberOfRawDataBytes - 1){ # loop until end of record is reached

        # ----- get EDID ID -----
        my $identifier_hex;

        # read $id_Length bytes in hex value
        foreach my $byteIndex ($currentRecordByteIndex..$currentRecordByteIndex + $id_Length - 1)
        {
            $identifier_hex = $identifier_hex.sprintf("%02x", $$rawData_aref[$byteIndex]);
        }

        # convert hex value of EDID ID to decimal value
        my $identifier_dec = hex($identifier_hex);
        S_w2log(4, "ID $identifier_dec (hex $identifier_hex), ID start byte index $currentRecordByteIndex");

        $currentRecordByteIndex = $currentRecordByteIndex + $id_Length;

        # ----- get data length of EDID element ----
        my $memberKey = $id_to_memberKey_mapping_href -> {$identifier_dec};
        unless(defined $memberKey){
            S_set_error("Member with key '$memberKey' not defined in data definition. Parsing aborted");
            return;
        }
        my $dataSamples = $memberDataStructure_href -> {$memberKey} -> {'NumberOfDataSamples'};
        unless($dataSamples){
            S_set_error("'NumberOfDataSamples' not defined or 0 for data '$memberKey' (ID $identifier_dec (hex: $identifier_hex)). Parsing aborted.");
            return;
        }
        my $bytesPerDataSample = $memberDataStructure_href -> {$memberKey} -> {'BytesPerDataSample'};
        unless($bytesPerDataSample){
            S_set_error("'BytesPerDataSample' not defined or 0 for data '$memberKey' (ID $identifier_dec (hex: $identifier_hex)). Parsing aborted.");
            return;
        }

        # calculate data length
        my $dataLength = ($dataSamples * $bytesPerDataSample);

        # check whether end of record has been reached
        my $bytesLeftInRecord = $numberOfRawDataBytes - $currentRecordByteIndex;
        if($bytesLeftInRecord < $dataLength){
            S_w2log(2, "LIFT_DataRecord -> Parsing raw record: member $identifier_dec expected data length -> $dataLength; detected data length -> $bytesLeftInRecord");
            S_set_error("Problem with parsing record...record length too short - not all data found for member $identifier_dec!!\n", 114);
            return;
        }

        my $thisMemberRawData_aref;
        foreach my $byte (1..$dataLength){
            push(@{$thisMemberRawData_aref}, $rawData_aref -> [$currentRecordByteIndex]);
            $currentRecordByteIndex++;
        }

        if(@{$thisMemberRawData_aref} == 1){
            $self -> add_data_member($memberKey, $thisMemberRawData_aref -> [0], $section, $memberDataStructure_href -> {$memberKey});
        }
        elsif(@{$thisMemberRawData_aref} > 1){
            $self -> add_data_member($memberKey, $thisMemberRawData_aref, $section, $memberDataStructure_href -> {$memberKey});
        }
        else{
            S_set_warning("No data found for $section '$memberKey'. Will not be created");
        }
    }

    return 1;
}


=head3 _map_member_keys_to_ID

    $id_to_memberKey_href = _map_member_keys_to_ID( $member_mapping_href);

Internal function to map member keys to integer IDs.

Case 1: ID is specified as attribute 'ID'

Case 2: Member key itself is an integer and will be treated as ID

Returns hash reference with a mapping of IDs and member keys.

Example:
    $id_to_memberKey_href = {
        1 => 'MemberKey_1',
        2 => 'MemberKey_2',
        3 => 'MemberKey_3',
        #...
    }

=cut
sub _map_member_keys_to_ID {
    my $member_mapping_href = shift;
    return unless($member_mapping_href);
    
    my $id_to_memberKey_href;
    foreach my $memberKey (sort keys %{$member_mapping_href}){
        my $id = $member_mapping_href -> {$memberKey} -> {'ID'};
        $id = $memberKey unless(defined $id);
        $id_to_memberKey_href -> {$id} = $memberKey;
    }
    return $id_to_memberKey_href;
}

=head3 _aref_to_string

    $id_to_memberKey_href = _aref_to_string( $aref [, $delimiter]);

Internal function to turn array reference into string

Apart from the array reference, the delimiter can be given as an input parameter. 
Default is " ".

Returns string

=cut
sub _aref_to_string {
    my $aref = shift;
    my $delimiter = shift;
    $delimiter = " " if(not defined $delimiter);
    
    my $string;
    foreach my $arrayElement (@{$aref}){
        $string = $arrayElement if(not defined $string); # first element
        $string .= $delimiter.$arrayElement if(defined $string);
    }
    
    return $string;
}

=head3 _create_dummy_offline_data

    $id_to_memberKey_href = _create_dummy_offline_data( $dataStructureInfo_href, $startByteIndex [, $bytesPerIdentifier]);

Internal function to create dummy offline array data

The function is used to avoid errors in offline mode which are related to not having data available e.g. from a diagnostic service to fill up the record.

Returns array reference

=cut
sub _create_dummy_offline_data {
    my $dataStructureInfo_href = shift;
    my $startByteIndex = shift;
    my $bytesPerIdentifier = shift;
    
    my $rawData_aref = [0..$startByteIndex - 1] if($startByteIndex > 0);
    
    foreach my $memberKey (sort {$a <=> $b} keys %{$dataStructureInfo_href}){
        if(defined $bytesPerIdentifier){
            my $id = $dataStructureInfo_href -> {$memberKey} -> {'ID'};
            $id = $memberKey unless(defined $id);
            my $nibbles = $bytesPerIdentifier * 2;
            my @idHex_array = split(//, sprintf("%0".$nibbles."x", $id));
            foreach my $idByte (0..$bytesPerIdentifier - 1) {
                my $idStartByteIndex = $idByte * 2;
                push(@{$rawData_aref}, hex($idHex_array[$idStartByteIndex].$idHex_array[$idStartByteIndex + 1]))
            }    
        }
        
        my $bytesPerDataSample = $dataStructureInfo_href -> {$memberKey} -> {'BytesPerDataSample'};
        next unless($bytesPerDataSample);
        my $numberOfDataSamples = $dataStructureInfo_href -> {$memberKey} -> {'NumberOfDataSamples'};
        next unless($numberOfDataSamples);
        
        foreach my $dataByte (1..$bytesPerDataSample*$numberOfDataSamples){
            push(@{$rawData_aref}, 1);
        }
    }
    
    return $rawData_aref;
}

__PACKAGE__->meta->make_immutable;

1;

