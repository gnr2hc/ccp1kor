# *****************************************************************************************************
#
#    Copyright (c)  Robert Bosch GmBH
#                 Germany
#                 All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package FuncLib_sVTT_Curves;

use strict;
use warnings;
use File::Basename;
use LIFT_general;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_sVTT_Curves ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  LV124_e_01
  LV124_e_02
  LV124_e_03
  LV124_e_04
  LV124_e_05
  LV124_e_07
  LV124_e_08
  LV124_e_09
  LV124_e_11
  LV124_e_12
  LV124_e_15
);

our ( $VERSION, $HEADER );

my $curve_init      = 0;    #global flag
my $count_iteration = 0;    #flag to check the linear curve creation count and shift the voltage array data respectively

=head1 NAME

    LIFT_sVTT_Curves 

    Curve Library for sVTT test

=head1 SYNOPSIS

    use LIFT_sVTT_Curves;

     $curve_filename = LV124_e_01($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_02($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_03($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_04($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_05($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_07($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_08($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_09($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_11($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_12($curve_params [, $u_lower, $u_upper, $curve_folder_path]);
     $curve_filename = LV124_e_15($curve_params [, $u_lower, $u_upper, $curve_folder_path]);

=head2 ProjectDefaults

 'VTT' => {
            #This section is used for controlling the voltage level of the curves while generating
            'Curve_Controls' => {
                                    'U_min' => 0,  # in volt , lower voltage limit
                                    'U_max' => 13.5,  # in volt , upper voltage limit
                                },
         },

=head2 Config file

### sVTT Curve Library Path ###

our $sVTTCurve_file_path = "..\\config\\Tools\\sVTT_Curves\\";

=head1 DESCRIPTION

To generate the Voltage curves which will be used for sVTT test in TurboLiFT.

(currently only LV124 standard curves are available)

B<Naming convention for Curve File - curvename_timestamp.svtc>

=head1 APIs

=head2 LV124_e_01 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_01($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VMIN', 'VMAX', 'TR', 'TF', 'T1', 'HOLDING_TIME_IN_VMIN', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'VMIN', 'VMAX', 'TR', 'TF', 'T1', 'HOLDING_TIME_IN_VMIN', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

                                                        T1
     VMAX                                     |---------------------|
                                             /|                     |\
                                            / |                     | \
                                           /  |                     |  \
                                          /   |                     |   \
                                         /    |                     |    \
     VMN     ----------------------------     |                     |     \
               HOLDING_TIME_IN_VMIN        TR                          TF

=for html
<IMG SRC='..\..\pics\sVTT\E01_Spec.png'  alt="LV124 E01" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_01({'CURVE_NAME' => 'LV124_e_01','VMAX' => 17, 'VMIN' => 13.5, 'HOLDING_TIME_IN_VMIN' => 5, 'TR' => 0.009, 'TF' => 0.009, 'T1' => 3600, 'NUMBER_OF_CYCLES' => 1});
    $curve_filename = LV124_e_01({'CURVE_NAME' => 'LV124_e_01','VMAX' => 17, 'VMIN' => 13.5, 'HOLDING_TIME_IN_VMIN' => 5, 'TR' => 0.009, 'TF' => 0.009, 'T1' => 3600, 'NUMBER_OF_CYCLES' => 1, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_01({'CURVE_NAME' => 'LV124_e_01','VMAX' => 17, 'VMIN' => 13.5, 'HOLDING_TIME_IN_VMIN' => 5, 'TR' => 0.009, 'TF' => 0.009, 'T1' => 3600, 'NUMBER_OF_CYCLES' => 1},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_01
{
    S_w2log( 5, "Creation of LV124_e_01 \n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VMIN', 'VMAX', 'TR', 'TF', 'T1', 'HOLDING_TIME_IN_VMIN', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_time = time();

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename      = 'lv_124_e01' . '_' . $start_time;
    my $curve_filename_path = $sat_file_savepath . "\\" . $curve_filename . ".svtc";

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_min            = $$curve_params_href{'VMIN'};
    my $v_max            = $$curve_params_href{'VMAX'};
    my $t_r              = $$curve_params_href{'TR'};
    my $t_f              = $$curve_params_href{'TF'};
    my $t_1              = $$curve_params_href{'T1'};
    my $t_hold           = $$curve_params_href{'HOLDING_TIME_IN_VMIN'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                              #in seconds
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = 0, V0 = $v_min
    # t1 = $t_hold, V1 = $v_min
    # t2 = $t_hold+$t_r , V1 = $v_max
    # t3 = $t_hold+$t_r+$t_1, V1 = $v_max
    # t4 = $t_hold+$t_r+$t_1+$t_f, V1 = $v_min

    my $volt = [ $v_min, $v_min, $v_max, $v_max, $v_min ];
    my $time = [ 0, $t_hold, ( $t_hold + $t_r ), ( $t_hold + $t_r + $t_1 ), ( $t_hold + $t_r + $t_1 + $t_f ) ];

    # limitations for curve voltage values
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my @volt_samples = ();    #stores voltage samples

    my $num_of_samples = 0;   #holds the count of the voltage samples generated based on the sampling rate
    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_data = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );    #create line curve from (t(i),V(i)) and (t(i+1), V(i+1))
        push( @volt_samples, @$volt_data );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    # write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
        # my $curve={
                    # 'time' => \@time_samples,
                    # 'Voltage'=> \@volt_samples,
                   # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_01','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }
    
    S_w2log( 5, "LV124_e_01 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "10V", "Time" => "500S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_02 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_02($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VMIN', 'U1', 'VMAX', 'TR', 'TF', 'T1', 'T2', 'T3', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'VMIN', 'U1', 'VMAX', 'TR', 'TF', 'T1', 'T2', 'T3', 'NMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

                                                    T1
            VMAX                          |---------------------|
                                         /|                     |\
                                        / |                     | \      T2
                                       /  |                     |  \-------------|
                                      /   |                     |  |             |\
                                     /    |                     |  |             | \
            VMIN           ---------|     |                     |  |             |  \
                              T3      TR                         TF               TF

=for html
<IMG SRC='..\..\pics\sVTT\E02_Spec.png'  alt="LV124 E02" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_02({'CURVE_NAME' => 'LV124_e_02','VMIN' => 16, 'U1' => 17, 'VMAX => 18, 'TR' => 0.001, 'TF' => 0.001, 'T1' => 0.4, 'T2' => 0.6, 'T3' => 2, 'NUMBER_OF_CYCLES' => 3});
    $curve_filename = LV124_e_02({'CURVE_NAME' => 'LV124_e_02','VMIN' => 16, 'U1' => 17, 'VMAX' => 18, 'TR' => 0.001, 'TF' => 0.001, 'T1' => 0.4, 'T2' => 0.6, 'T3' => 2, 'NUMBER_OF_CYCLES' => 3, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_02({'CURVE_NAME' => 'LV124_e_02','VMIN' => 16, 'U1' => 17, 'VMAX' => 18, 'TR' => 0.001, 'TF' => 0.001, 'T1' => 0.4, 'T2' => 0.6, 'T3' => 2, 'NUMBER_OF_CYCLES' => 3},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_02
{
    S_w2log( 5, "Creation of LV124_e_02 \n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VMIN', 'U1', 'VMAX', 'TR', 'TF', 'T1', 'T2', 'T3', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_min            = $$curve_params_href{'VMIN'};
    my $u_1              = $$curve_params_href{'U1'};
    my $v_max            = $$curve_params_href{'VMAX'};
    my $t_r              = $$curve_params_href{'TR'};
    my $t_f              = $$curve_params_href{'TF'};
    my $t_1              = $$curve_params_href{'T1'};
    my $t_2              = $$curve_params_href{'T2'};
    my $t_3              = $$curve_params_href{'T3'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename      = 'lv_124_e02' . '_' . $start_time;
    my $curve_filename_path = $sat_file_savepath . $curve_filename . ".svtc";

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );

            $t_2 = Unique_Random_Generator( $t_2, 'T2' );    #returns the random value for 't2' if randomness is selected
            return if ( !defined $t_2 );

            $t_3 = Unique_Random_Generator( $t_3, 'T3' );    #returns the random value for 't3' if randomness is selected
            return if ( !defined $t_3 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 1ms (tuned after verifying the curve output on oscilloscope)if it is not defined by user
    {
        $sampling_time = 0.0001;#in seconds
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = 0, V0 = $v_min
    # t1 = $t_3, V1 = $v_min
    # t2 = $t_3+$t_r , V1 = $v_max
    # t3 = $t_3+$t_r+$t_1, V1 = $v_max
    # t4 = $t_3+$t_r+$t_1+$t_f , V1 =  $u_1
    # t5 = $t_3+$t_r+$t_1+$t_f+$t_2 , V1 = $u_1
    # t6 = $t_3+$t_r+$t_1+$t_f+$t_2+$t_f, V1 = $v_min

    my $volt = [ $v_min, $v_min, $v_max, $v_max, $u_1, $u_1, $v_min ];
    my $time = [ 0, $t_3, ( $t_3 + $t_r ), ( $t_3 + $t_r + $t_1 ), ( $t_3 + $t_r + $t_1 + $t_f ), ( $t_3 + $t_r + $t_1 + $t_f + $t_2 ), ( $t_3 + $t_r + $t_1 + $t_f + $t_2 + $t_f ) ];

    #clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;     #holds the count of the voltage samples generated based on the sampling rate
    my @volt_samples   = ();    #stores voltage samples

    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;    #temporary variable
        $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    # write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;
	
    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_02','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_02 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "5V", "Time" => "5S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_03 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_03($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VMIN', 'U1', 'VMAX', 'TR', 'TF', 'T1', 'T2', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'VMIN', 'U1', 'VMAX', 'TR', 'TF', 'T1', 'T2', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

            VMAX        __________  TF         T1       TR
                            T2    |\   |              |   /|
                                  | \  |              |  / |
                                  |  \ |              | /  |
                                  |   \|              |/   |
             VMIN                 |    \______________/    |

=for html
<IMG SRC='..\..\pics\sVTT\E03_Spec.png'  alt="LV124 E03" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_03({'CURVE_NAME' => 'LV124_e_03','VMAX' => 10.8, 'VMIN' => 9, 'TR' => 0.0018, 'TF' => 0.0018, 'T1' => 0.5, 'T2' => 1, 'NUMBER_OF_CYCLES' => 3});
    $curve_filename = LV124_e_03({'CURVE_NAME' => 'LV124_e_03','VMAX' => 10.8, 'VMIN' => 9, 'TR' => 0.0018, 'TF' => 0.0018, 'T1' => 0.5, 'T2' => 1, 'NUMBER_OF_CYCLES' => 3, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_03({'CURVE_NAME' => 'LV124_e_03','VMAX' => 10.8, 'VMIN' => 9, 'TR' => 0.0018, 'TF' => 0.0018, 'T1' => 0.5, 'T2' => 1, 'NUMBER_OF_CYCLES' => 3},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_03
{
    S_w2log( 5, "Creation of LV124_e_03\n" );
    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VMIN', 'VMAX', 'TR', 'TF', 'T1', 'T2', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_min            = $$curve_params_href{'VMIN'};
    my $v_max            = $$curve_params_href{'VMAX'};
    my $t_r              = $$curve_params_href{'TR'};
    my $t_f              = $$curve_params_href{'TF'};
    my $t_1              = $$curve_params_href{'T1'};
    my $t_2              = $$curve_params_href{'T2'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename      = 'lv_124_e03' . '_' . $start_time;
    my $curve_filename_path = $sat_file_savepath . $curve_filename . ".svtc";

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );

            $t_2 = Unique_Random_Generator( $t_2, 'T2' );    #returns the random value for 't2' if randomness is selected
            return if ( !defined $t_2 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 1 ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.0001;#in seconds
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = 0, V0 = $v_max
    # t1 = $t_2, V1 = $v_max
    # t2 = $t_2+$t_f , V1 = $v_min
    # t3 = $t_2+$t_f+$t_1, V1 = $v_min
    # t4 = $t_2+$t_f+$t_1+$t_r , V1 =  $v_max

    my $volt = [ $v_max, $v_max, $v_min, $v_min, $v_max ];
    my $time = [ 0, $t_2, ( $t_2 + $t_f ), ( $t_2 + $t_f + $t_1 ), ( $t_2 + $t_f + $t_1 + $t_r ) ];

    #clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            S_w2log( 5, "Voltage $$volt[$i] clamped to Umax ($u_max)\n" );
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            S_w2log( 5, "Voltage $$volt[$i] clamped to Umin ($u_min)\n" );
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;    #holds the count of the voltage samples generated based on the sampling rate

    my @volt_samples = ();     #stores voltage samples

    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;    #temporary variable
        $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    #write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_03','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_03 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "5V", "Time" => "5S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_04 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_04($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VMIN', 'VMAX', 'TR', 'TF', 'T1', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'VMIN', 'VMAX', 'TR', 'TF', 'T1', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

                                            T1
     VMAX                         |---------------------|
                                 /|                     |\
                                / |                     | \
                               /  |                     |  \
                              /   |                     |   \
                             /    |                     |    \
     VMIN      --------------     |                     |     \
                    T1        TR                          TF

=for html
<IMG SRC='..\..\pics\sVTT\E04_Spec.png'  alt="LV124 E04" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_04({'CURVE_NAME' => 'LV124_e_04','VMIN' => 10.8, 'VMAX' => 26, 'T1' => 60, 'TR' => 0.009, 'TF' => 0.009, 'NUMBER_OF_CYCLES' => 1});
    $curve_filename = LV124_e_04({'CURVE_NAME' => 'LV124_e_04','VMIN' => 10.8, 'VMAX' => 26, 'T1' => 60, 'TR' => 0.009, 'TF' => 0.009, 'NUMBER_OF_CYCLES' => 1, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_04({'CURVE_NAME' => 'LV124_e_04','VMIN' => 10.8, 'VMAX' => 26, 'T1' => 60, 'TR' => 0.009, 'TF' => 0.009, 'NUMBER_OF_CYCLES' => 1},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_04
{
    S_w2log( 5, "Creation of LV124_e_04\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VMIN', 'VMAX', 'TR', 'TF', 'T1', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_min            = $$curve_params_href{'VMIN'};
    my $v_max            = $$curve_params_href{'VMAX'};
    my $t_r              = $$curve_params_href{'TR'};
    my $t_f              = $$curve_params_href{'TF'};
    my $t_1              = $$curve_params_href{'T1'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename      = 'lv_124_e04' . '_' . $start_time;
    my $curve_filename_path = $sat_file_savepath . $curve_filename . ".svtc";

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                              #in seconds
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = 0, V0 = $v_min
    # t1 = $t_1, V1 = $v_min
    # t2 = $t_1+$t_r , V1 = $v_max
    # t3 = $t_1+$t_r+$t_1, V1 = $v_max
    # t4 = $t_1+$t_r+$t_1+$t_f , V1 =  $v_min

    my $volt = [ $v_min, $v_min, $v_max, $v_max, $v_min ];    #volt-sequence, curve specification
    my $time = [ 0, $t_1, ( $t_1 + $t_r ), ( $t_1 + $t_r + $t_1 ), ( $t_1 + $t_r + $t_1 + $t_f ) ];    #time-sequence in s, curve specification

    #clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            S_w2log( 5, "Voltage $$volt[$i] clamped to Umax ($u_max)\n" );
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            S_w2log( 5, "Voltage $$volt[$i] clamped to Umin ($u_min)\n" );
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;     #holds the count of the voltage samples generated based on the sampling rate
    my @volt_samples   = ();    #stores voltage samples

    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;    #temporary variable
        $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    #write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_04','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_04 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "10V", "Time" => "20S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_05 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_05($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'U_MIN', 'U_MAX', 'TR', 'TF', 'T1', 'BREAK_BETWEEN_CYCLES', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'U_MIN', 'U_MAX', 'TR', 'TF', 'T1', 'BREAK_BETWEEN_CYCLES', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

                                                   T1
      VMAX                                 |---------------------|
                                          /|                     |\
                                         / |                     |  \
                                        /  |                     |    \
                                       /   |                     |      \
                                      /    |                     |        \
     VMIN     ------------------------     |                     |          \
               BREAK_BETWEEN_CYCLES     TR                            TF

=for html
<IMG SRC='..\..\pics\sVTT\E05_Spec.png'  alt="LV124 E05" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_05({'CURVE_NAME' => 'LV124_e_05','U_MIN' => 13.5, 'U_MAX' => 27, 'TR' => 0.001, 'T1' => 0.3, 'TF' => 0.03, 'BREAK_BETWEEN_CYCLES' => 60, 'NUMBER_OF_CYCLES' => 10});
    $curve_filename = LV124_e_05({'CURVE_NAME' => 'LV124_e_05','U_MIN' => 13.5, 'U_MAX' => 27, 'TR' => 0.001, 'T1' => 0.3, 'TF' => 0.03, 'BREAK_BETWEEN_CYCLES' => 60, 'NUMBER_OF_CYCLES' => 10, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_05({'CURVE_NAME' => 'LV124_e_05','U_MIN' => 13.5, 'U_MAX' => 27, 'TR' => 0.001, 'T1' => 0.3, 'TF' => 0.03, 'BREAK_BETWEEN_CYCLES' => 60, 'NUMBER_OF_CYCLES' => 10},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_05
{
    S_w2log( 5, "Creation of LV124_e_05\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'U_MIN', 'U_MAX', 'TR', 'TF', 'T1', 'BREAK_BETWEEN_CYCLES', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name             = $$curve_params_href{'CURVE_NAME'};
    my $v_min                  = $$curve_params_href{'U_MIN'};
    my $v_max                  = $$curve_params_href{'U_MAX'};
    my $t_r                    = $$curve_params_href{'TR'};
    my $t_f                    = $$curve_params_href{'TF'};
    my $t_1                    = $$curve_params_href{'T1'};
    my $t_Break_between_cycles = $$curve_params_href{'BREAK_BETWEEN_CYCLES'};
    my $number_of_cycles       = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness             = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time          = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();    # store time of LIFT start

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename = 'lv_124_e05'.'_'.$start_time;
    my $curve_filename_path = $sat_file_savepath.$curve_filename.".svtc";;

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_1 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 0.1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.0001;#in seconds
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = 0, V0 = $v_min
    # t1 = $t_Break_between_cycles, V1 = $v_min
    # t2 = $t_Break_between_cycles + $t_r , V1 = $v_max
    # t3 = $t_Break_between_cycles + $t_r + $t_1 , V1 = $v_max
    # t4 = $t_Break_between_cycles + $t_r + $t_1+ $t_f , V1 =  $v_min

    my $volt = [ $v_min, $v_min, $v_max, $v_max, $v_min ];    #volt-sequence, curve specification
    my $time = [ 0, $t_Break_between_cycles, ( $t_Break_between_cycles + $t_r ), ( $t_Break_between_cycles + $t_r + $t_1 ), ( $t_Break_between_cycles + $t_r + $t_1 + $t_f ) ];    #time-sequence in s, curve specification

    #clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my @volt_samples   = ();    #stores voltage samples
    my $num_of_samples = 0;     #holds the count of the voltage samples generated based on the sampling rate

    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;    #temporary variable
        $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    # write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_05','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_05 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "10V", "Time" => "100S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_07 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_07($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'START_VOLTAGE', 'RATE_OF_VOLTAGE_CHANGE', 'U1', 'T1', 'MIN_VOLTAGE', 'U2', 'T2', 'FINAL_VOLTAGE', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'START_VOLTAGE', 'RATE_OF_VOLTAGE_CHANGE', 'U1', 'T1', 'MIN_VOLTAGE', 'U2', 'T2', 'FINAL_VOLTAGE', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

       VBMAX     \                           /
                  \                         /
                   \   V1              V2  /
       VBMIN _____  \______          _____/
                     |    |\        /|    |
                     |    | \      / |    |
                     |    |  \    /  |    |
                     |    |   \  /   |    |
         0V  ______  |    |    \/    |    |
                       T1              T2

=for html
<IMG SRC='..\..\pics\sVTT\E07_Spec.png'  alt="LV124 E07" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_07({'CURVE_NAME' => 'LV124_e_07','START_VOLTAGE' => 16, 'RATE_OF_VOLTAGE_CHANGE' => 0.5, 'U1' => 6, 'T1' => 60, 'MIN_VOLTAGE' => 0, 'U2' => 6, 'T2' => 60, 'FINAL_VOLTAGE' => 16,'NUMBER_OF_CYCLES' => 1});
    $curve_filename = LV124_e_07({'CURVE_NAME' => 'LV124_e_07','START_VOLTAGE' => 16, 'RATE_OF_VOLTAGE_CHANGE' => 0.5, 'U1' => 6, 'T1' => 60, 'MIN_VOLTAGE' => 0, 'U2' => 6, 'T2' => 60, 'FINAL_VOLTAGE' => 16,'NUMBER_OF_CYCLES' => 1, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_07({'CURVE_NAME' => 'LV124_e_07','START_VOLTAGE' => 16, 'RATE_OF_VOLTAGE_CHANGE' => 0.5, 'U1' => 6, 'T1' => 60, 'MIN_VOLTAGE' => 0, 'U2' => 6, 'T2' => 60, 'FINAL_VOLTAGE' => 16,'NUMBER_OF_CYCLES' => 1},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_07
{
    S_w2log( 5, "Creation of LV124_e_07\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'START_VOLTAGE', 'RATE_OF_VOLTAGE_CHANGE', 'U1', 'T1', 'MIN_VOLTAGE', 'U2', 'T2', 'FINAL_VOLTAGE', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_start          = $$curve_params_href{'START_VOLTAGE'};
    my $v_rate           = $$curve_params_href{'RATE_OF_VOLTAGE_CHANGE'};
    my $v_1              = $$curve_params_href{'U1'};
    my $t_1              = $$curve_params_href{'T1'};
    my $v_min            = $$curve_params_href{'MIN_VOLTAGE'};
    my $v_2              = $$curve_params_href{'U2'};
    my $t_2              = $$curve_params_href{'T2'};
    my $v_final          = $$curve_params_href{'FINAL_VOLTAGE'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();    # store time of LIFT start

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename = 'lv_124_e07'.'_'.$start_time;
    my $curve_filename_path = $sat_file_savepath.$curve_filename.".svtc";;

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );

            $t_2 = Unique_Random_Generator( $t_2, 'T2' );    #returns the random value for 't2' if randomness is selected
            return if ( !defined $t_2 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                              #in seconds
    }

    my ( @volt1, @time1 ) = ();                              #fall in voltage curve from Start_voltage to U1
    my ( @volt2, @time2 ) = ();                              #fall in voltage curve from U1 to Min_Voltage
    my ( @volt3, @time3 ) = ();                              #rise in voltage curve from Min_Voltage to U_2
    my ( @volt4, @time4 ) = ();                              #rise in voltage curve from U_2 to Final_Voltage

    #voltage and time samples calculation for fall in voltage curve from Start_voltage to U1 in steps of 0.5V/min
    my $v_temp = $v_start;
    push( @volt1, $v_temp );
    push( @time1, 0 );
    for ( my $i = 60 ; $v_temp > $v_1 ; )
    {
        $v_temp -= 0.5;
        push( @volt1, $v_temp );
        push( @time1, $i );
        $i += 60;
    }

    #voltage and time samples calculation for fall in voltage curve from U1 to Min_Voltage in steps of 0.5V/min
    my $time1_last = $time1[-1];
    $v_temp = $v_1;
    my $t_temp = $time1_last + $t_1;
    push( @volt2, $v_temp );
    push( @time2, $t_temp );
    for ( my $i = ( $t_temp + 60 ) ; $v_temp > 0 ; )
    {
        $v_temp -= 0.5;
        push( @volt2, $v_temp );
        push( @time2, $i );
        $i += 60;
    }

    #voltage and time samples calculation for rise in voltage curve from Min_Voltage to U_2 in steps of 0.5V/min
    $v_temp = $v_min;
    $t_temp = $time2[-1];
    push( @volt3, $v_temp );
    push( @time3, $t_temp );
    for ( my $i = ( $t_temp + 60 ) ; $v_temp < $v_2 ; )
    {
        $v_temp += 0.5;
        push( @volt3, $v_temp );
        push( @time3, $i );
        $i += 60;
    }

    #voltage and time samples calculation for rise in voltage curve from U_2 to Final_Voltage in steps of 0.5V/min
    my $time3_last = $time3[-1];
    $v_temp = $v_2;
    $t_temp = $time3_last + $t_2;
    push( @volt4, $v_temp );
    push( @time4, $t_temp );
    for ( my $i = ( $t_temp + 60 ) ; $v_temp < $v_final ; )
    {
        $v_temp += 0.5;
        push( @volt4, $v_temp );
        push( @time4, $i );
        $i += 60;
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = @time1, V0 = @volt1
    # t1 = @time2 , V1 = @volt2
    # t2 = @time3 , V1 = @volt3
    # t3 = @time4 , V1 = @volt4

    my $volt = [ @volt1, @volt2, @volt3, @volt4 ];
    my $time = [ @time1, @time2, @time3, @time4 ];

    # clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;    #holds the count of the voltage samples generated based on the sampling rate

    my @volt_samples = ();     #stores voltage samples

    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;    #temporary variable
        $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    # write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_07','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_07 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "5V", "Time" => "500S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_08 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_08($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'START_VOLTAGE', 'VOLTAGE_DROP', 'V1', 'T1', 'MIN_VOLTAGE', 'T2', 'FINAL_VOLTAGE', 'TR', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'Curve_name' - Name of the curve (as in API)
    'START_VOLTAGE', 'VOLTAGE_DROP', 'V1', 'T1', 'MIN_VOLTAGE', 'T2', 'FINAL_VOLTAGE', 'TR', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).


       VBmax     \                                              /|
                   \                                           / |
                     \    V1                                  /  |
       VBmin _____     \______                               /   |
                        |    |\                             /    |
                        |    |  \                          /     |
                        |    |    \                       /      |
                        |    |      \                    /       |
         0V  ______     |    |        \_________________/        |
                          T1                 T2             TR

=for html
<IMG SRC='..\..\pics\sVTT\E08_Spec.png'  alt="LV124 E08" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_08({'CURVE_NAME' => 'LV124_e_08','START_VOLTAGE' => 16, 'VOLTAGE_DROP' => 0.5, 'V1' => 6, 'T1' => 60, 'MIN_VOLTAGE' => 0, 'T2' => 60, 'FINAL_VOLTAGE' => 16, 'TR' => 0.4, 'NUMBER_OF_CYCLES' => 1});
    $curve_filename = LV124_e_08({'CURVE_NAME' => 'LV124_e_08','START_VOLTAGE' => 16, 'VOLTAGE_DROP' => 0.5, 'V1' => 6, 'T1' => 60, 'MIN_VOLTAGE' => 0, 'T2' => 60, 'FINAL_VOLTAGE' => 16, 'TR' => 0.4, 'NUMBER_OF_CYCLES' => 1, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_08({'CURVE_NAME' => 'LV124_e_08','START_VOLTAGE' => 16, 'VOLTAGE_DROP' => 0.5, 'V1' => 6, 'T1' => 60, 'MIN_VOLTAGE' => 0, 'T2' => 60, 'FINAL_VOLTAGE' => 16, 'TR' => 0.4, 'NUMBER_OF_CYCLES' => 1},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_08
{
    S_w2log( 5, "Creation of LV124_e_08\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'START_VOLTAGE', 'VOLTAGE_DROP', 'V1', 'T1', 'MIN_VOLTAGE', 'T2', 'FINAL_VOLTAGE', 'TR', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_start          = $$curve_params_href{'START_VOLTAGE'};
    my $v_rate           = $$curve_params_href{'VOLTAGE_DROP'};
    my $v_1              = $$curve_params_href{'V1'};
    my $t_1              = $$curve_params_href{'T1'};
    my $v_min            = $$curve_params_href{'MIN_VOLTAGE'};
    my $t_2              = $$curve_params_href{'T2'};
    my $v_final          = $$curve_params_href{'FINAL_VOLTAGE'};
    my $t_r              = $$curve_params_href{'TR'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();    # store time of LIFT start

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename      = 'lv_124_e08' . '_' . $start_time;
    my $curve_filename_path = $sat_file_savepath . $curve_filename . ".svtc";

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );

            $t_2 = Unique_Random_Generator( $t_2, 'T2' );    #returns the random value for 't2' if randomness is selected
            return if ( !defined $t_2 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                              #in seconds
    }

    my ( @volt1, @time1 ) = ();                              #fall in voltage curve from Start_voltage to V1
    my ( @volt2, @time2 ) = ();                              #fall in voltage curve from V1 to min_voltage

    #voltage and time samples calculation for fall in voltage curve from Start_voltage to V1 in steps of 0.5V/min
    my $v_temp = $v_start;
    push( @volt1, $v_temp );
    push( @time1, 0 );
    for ( my $i = 60 ; $v_temp > $v_1 ; )
    {
        $v_temp -= 0.5;
        push( @volt1, $v_temp );
        push( @time1, $i );
        $i += 60;
    }

    #voltage and time samples calculation for fall in voltage curve from V1 to min_voltage in steps of 0.5V/min
    my $time1_last = $time1[-1];
    $v_temp = $v_1;
    my $t_temp = $time1_last + $t_1;
    push( @volt2, $v_temp );
    push( @time2, $t_temp );
    for ( my $i = ( $t_temp + 60 ) ; $v_temp > 0 ; )
    {
        $v_temp -= 0.5;
        push( @volt2, $v_temp );
        push( @time2, $i );
        $i += 60;
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = @time1, V0 = @volt1
    # t1 = @time2 , V1 = @volt2
    # t2 = $time2[-1] , V1 = $volt2[-1]
    # t3 = $time2[-1]+$t_2 , V1 = $volt2[-1]
    # t3 = $time2[-1]+$t_2+$t_r , V1 = $v_final

    my $volt = [ @volt1, @volt2, $volt2[-1], $volt2[-1], $v_final ];    #volt-sequence, curve specification
    my $time         = [ @time1, @time2, $time2[-1], ( $time2[-1] + $t_2 ), ( $time2[-1] + $t_2 + $t_r ) ];    #time-sequence in s, curve specification
    my @volt_samples = ();                                                                                     #stores voltage samples
                                                                                                               #clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;    #holds the count of the voltage samples generated based on the sampling rate
    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;    #temporary variable
        $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    #write the voltage samples to SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_08','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_08 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "5V", "Time" => "1000S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_09 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_09($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VMAX', 'VTH', 'DELTA_V1', 'DELTA_V2', 'T2', 'TR', 'TF', 'NUMBER_OF_CYCLES', 'T1', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'Curve_name' - Name of the curve (as in API)
    'VMAX', 'VTH', 'DELTA_V1', 'DELTA_V2', 'T2', 'TR', 'TF', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).


                       T2
     VMAX     ___      ___        ___          ___ _ _ _ _               ___                __                  ___
                 \ T1 /  |\      /|  \        /            \            /   \              /  \                /
                  \__/   | \    / |   \      /              \          /     \            /    \              /
        DELTA V1  _______|  \__/  |    \    /                \        /       \          /      \            /
     VTH      ___________   |  |  |  |  \__/                  \      /         \        /        \          /
                          TF     TR                            \    /           \      /          \        /
                                                    _______     \__/             \    /            \      /
                                         DELTA V2   ____________                  \__/              \    /
    0V_______________________________________________________________________________________________\__/

=for html
<IMG SRC='..\..\pics\sVTT\E09_Spec.png'  alt="LV124 E09" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_09({'CURVE_NAME' => 'LV124_e_09','VMAX' => 8, 'VTH' => 6, 'DELTA_V1' => 0.5, 'DELTA_V2' => 0.2, 'T2' => 11, 'TR' => 0.009, 'TF' => 0.009, 'NUMBER_OF_CYCLES' => 1, 'T1' => 5});
    $curve_filename = LV124_e_09({'CURVE_NAME' => 'LV124_e_09','VMAX' => 8, 'VTH' => 6, 'DELTA_V1' => 0.5, 'DELTA_V2' => 0.2, 'T2' => 11, 'TR' => 0.009, 'TF' => 0.009, 'NUMBER_OF_CYCLES' => 1, 'T1' => 5, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_09({'CURVE_NAME' => 'LV124_e_09','VMAX' => 8, 'VTH' => 6, 'DELTA_V1' => 0.5, 'DELTA_V2' => 0.2, 'T2' => 11, 'TR' => 0.009, 'TF' => 0.009, 'NUMBER_OF_CYCLES' => 1, 'T1' => 5},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_09
{
    S_w2log( 5, "Creation of LV124_e_09\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VMAX', 'VTH', 'DELTA_V1', 'DELTA_V2', 'T2', 'TR', 'TF', 'NUMBER_OF_CYCLES', 'T1' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_max            = $$curve_params_href{'VMAX'};
    my $v_th             = $$curve_params_href{'VTH'};
    my $delta_v1         = $$curve_params_href{'DELTA_V1'};
    my $delta_v2         = $$curve_params_href{'DELTA_V2'};
    my $t_2              = $$curve_params_href{'T2'};
    my $t_r              = $$curve_params_href{'TR'};
    my $t_f              = $$curve_params_href{'TF'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $t_1              = $$curve_params_href{'T1'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();    # store time of LIFT start

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename = 'lv_124_e09'.'_'.$start_time;
    my $curve_filename_path = $sat_file_savepath.$curve_filename.".svtc";

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );

            $t_2 = Unique_Random_Generator( $t_2, 'T2' );    #returns the random value for 't2' if randomness is selected
            return if ( !defined $t_2 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 0.1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                              #in seconds
    }

    my @v_temp  = ();
    my @v_temp1 = ();
    my @t_temp  = ();
    my @t_temp1 = ();
    $t_temp1[4] = 0;
    push( @v_temp, $v_max );                                 #the curve starts at v_max
    push( @t_temp, 0 );                                      #time starts at 0
    my $v_limit = $v_max;

    for ( my $i = 1 ; $v_limit > $v_th ; $i++ )              #calculate the voltage samples for v_limit >= v_th for the step of delta_v1
    {
        $v_temp1[$i] = sprintf( "%.5f", $v_max );
        $v_temp1[ $i + 1 ] = sprintf( "%.5f", ( $v_max - ( $i * $delta_v1 ) ) );
        $v_temp1[ $i + 2 ] = sprintf( "%.5f", ( $v_max - ( $i * $delta_v1 ) ) );
        $v_temp1[ $i + 3 ] = sprintf($v_max);

        push( @v_temp, $v_temp1[$i], $v_temp1[ $i + 1 ], $v_temp1[ $i + 2 ], $v_temp1[ $i + 3 ] );
        $v_limit = $v_temp1[ $i + 1 ];
    }

    for ( my $i = 1 ; $v_limit >= 0 ; $i++ )                 #calculate the voltage samples for v_limit >= 0 for the step of delta_v2
    {
        $v_temp1[$i] = sprintf( "%.5f", $v_max );
        $v_temp1[ $i + 1 ] = sprintf( "%.5f", ( $v_temp[-2] - $delta_v2 ) );
        $v_temp1[ $i + 2 ] = sprintf( "%.5f", ( $v_temp[-2] - $delta_v2 ) );
        $v_temp1[ $i + 3 ] = sprintf( "%.5f", $v_max );

        $v_limit = $v_temp1[ $i + 1 ];
        if ( $v_limit < 0 )
        {
            last;
        }
        push( @v_temp, $v_temp1[$i], $v_temp1[ $i + 1 ], $v_temp1[ $i + 2 ], $v_temp1[ $i + 3 ] );
    }

    for ( my $i = 1 ; $i <= scalar( (@v_temp) - 1 ) ; )    #calculate the time array for previously calculated voltage array
    {
        $t_temp1[$i]       = $t_temp[-1] + $t_2;
        $t_temp1[ $i + 1 ] = $t_temp1[$i] + $t_f;
        $t_temp1[ $i + 2 ] = $t_temp1[ $i + 1 ] + $t_1;
        $t_temp1[ $i + 3 ] = $t_temp1[ $i + 2 ] + $t_r;
        push( @t_temp, $t_temp1[$i], $t_temp1[ $i + 1 ], $t_temp1[ $i + 2 ], $t_temp1[ $i + 3 ] );
        $i += 4;
    }
    my $volt         = \@v_temp;
    my $time         = \@t_temp;
    my @volt_samples = ();                                 #stores voltage samples

    #clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;    #holds the count of the voltage samples generated based on the sampling rate

    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    # write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;
    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_10','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_09 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "10V", "Time" => "100S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_11 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_11($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VB', 'VT', 'VS', 'VA', 'VR', 'T50', 'TF, 'T4', 'T5', 'T6', 'T7', 'T8', 'TR', 'FREQ', 'BREAK_BETWEEN_TWO_CYCLES', 'NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'VB', 'VT', 'VS', 'VA', 'VR', 'T50', 'TF, 'T4', 'T5', 'T6', 'T7', 'T8', 'TR', 'FREQ', 'BREAK_BETWEEN_TWO_CYCLES', 'NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).


    VB   _____                                                           ________
             |\                                   |  1/F    |           /|
             |  \                                __         __         / |  _____
             |   \                              (  )       (  )       /  |
             |    \                            (    )     (    )     /   |    VR
             |     \                         /       (    )    (    /    |
     VA   ___|_____ \                       /         (__)      (__/     |  ______
             |       \                     /|                      |     |
             |        \                   / |                      |     |
     VS   ___|______   \            _____/  |                      |     |
             |          \          /|    |  |                      |     |
             |           \        / |    |  |                      |     |
      VT   __|______      \______/  |    |  |                      |     |
             |      TF    |  T4  |T5| T6 |T7|         T8           |  Tr |


=for html
<IMG SRC='..\..\pics\sVTT\E11_Spec_normal_severe.png'  alt="LV124 E11 Normal and Severe Tests" border="0">
<IMG SRC='..\..\pics\sVTT\E11_Spec_short_long.png'  alt="LV124 E11 Short and long Tests" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_11({'CURVE_NAME' => 'LV124_e_11','VB' => 11, 'VT' => 7, 'VS' =>8, 'VA' => 9, 'VR' => 0, 'T50' => 0.011, 'TF' => 0.0009, 'T4' => 0.015, 'T5' => 0.07, 'T6' => 0.240, 'T7' => 0.07, 'T8' => 0.600, 'TR' => 0.0009, 'FREQ' => 0, 'BREAK_BETWEEN_TWO_CYCLES' => 5,'NUMBER_OF_CYCLES' => 10});
    $curve_filename = LV124_e_11({'CURVE_NAME' => 'LV124_e_11','VB' => 11, 'VT' => 7, 'VS' =>8, 'VA' => 9, 'VR' => 0, 'T50' => 0.011, 'TF' => 0.0009, 'T4' => 0.015, 'T5' => 0.07, 'T6' => 0.240, 'T7' => 0.07, 'T8' => 0.600, 'TR' => 0.0009, 'FREQ' => 0, 'BREAK_BETWEEN_TWO_CYCLES' => 5,'NUMBER_OF_CYCLES' => 10, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_11({'CURVE_NAME' => 'LV124_e_11','VB' => 11, 'VT' => 7, 'VS' =>8, 'VA' => 9, 'VR' => 0, 'T50' => 0.011, 'TF' => 0.0009, 'T4' => 0.015, 'T5' => 0.07, 'T6' => 0.240, 'T7' => 0.07, 'T8' => 0.600, 'TR' => 0.0009, 'FREQ' => 0, 'BREAK_BETWEEN_TWO_CYCLES' => 5,'NUMBER_OF_CYCLES' => 10},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_11
{
    S_w2log( 5, "Creation of LV124_e_11\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VB', 'VT', 'VS', 'VA', 'VR', 'T50', 'TF', 'T4', 'T5', 'T6', 'T7', 'T8', 'TR', 'FREQ', 'BREAK_BETWEEN_TWO_CYCLES', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name = $$curve_params_href{'CURVE_NAME'};
    my $v_b        = $$curve_params_href{'VB'};
    my $v_t        = $$curve_params_href{'VT'};
    my $v_s        = $$curve_params_href{'VS'};
    my $v_a        = $$curve_params_href{'VA'};
    my $v_r        = $$curve_params_href{'VR'};

    my $t_50             = $$curve_params_href{'T50'};
    my $t_f              = $$curve_params_href{'TF'};
    my $t_4              = $$curve_params_href{'T4'};
    my $t_5              = $$curve_params_href{'T5'};
    my $t_6              = $$curve_params_href{'T6'};
    my $t_7              = $$curve_params_href{'T7'};
    my $t_8              = $$curve_params_href{'T8'};
    my $t_r              = $$curve_params_href{'TR'};
    my $freq             = $$curve_params_href{'FREQ'};
    my $cycle            = $$curve_params_href{'BREAK_BETWEEN_TWO_CYCLES'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();    # store time of LIFT start

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename = 'lv_124_e11'.'_'.$start_time;
    my $curve_filename_path = $sat_file_savepath.$curve_filename.".svtc";;

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_4 = Unique_Random_Generator( $t_4, 'T4' );    #returns the random value for 't4' if randomness is selected
            return if ( !defined $t_4 );

            $t_5 = Unique_Random_Generator( $t_5, 'T5' );    #returns the random value for 't5' if randomness is selected
            return if ( !defined $t_5 );

            $t_6 = Unique_Random_Generator( $t_6, 'T6' );    #returns the random value for 't6' if randomness is selected
            return if ( !defined $t_6 );

            $t_7 = Unique_Random_Generator( $t_7, 'T7' );    #returns the random value for 't7' if randomness is selected
            return if ( !defined $t_7 );

            $t_8 = Unique_Random_Generator( $t_8, 'T8' );    #returns the random value for 't8' if randomness is selected
            return if ( !defined $t_8 );

            $t_50 = Unique_Random_Generator( $t_50, 'T50' );    #returns the random value for 't50' if randomness is selected
            return if ( !defined $t_50 );
        }
    }

    unless ($sampling_time)                                     #sampling time is 0.1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                                 #in seconds
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = 0, V0 = $v_b
    # t1 = $t1 , V1 = $v_b
    # t2 = $t1+$t_50 , V1 = $v_b
    # t3 = $t1+$t_50+$t_f , V1 = $v_t
    # t4 = $t1+$t_50+$t_f+$t_4 , V1 = $v_t
    # t5 = $t1+$t_50+$t_f+$t_4+$t_5 , V1 = $v_s
    # t6 = $t1+$t_50+$t_f+$t_4+$t_5+$t_6 , V1 = $v_s
    # t7 = $t1+$t_50+$t_f+$t_4+$t_5+$t_6+$t_7 , V1 = $v_a

    my $volt = [ $v_b, $v_b, $v_b, $v_t, $v_t, $v_s, $v_s, $v_a ];
    my $t1   = $cycle;
    my $time = [ 0, $t1, ( $t1 + $t_50 ), ( $t1 + $t_50 + $t_f ), ( $t1 + $t_50 + $t_f + $t_4 ), ( $t1 + $t_50 + $t_f + $t_4 + $t_5 ), ( $t1 + $t_50 + $t_f + $t_4 + $t_5 + $t_6 ), ( $t1 + $t_50 + $t_f + $t_4 + $t_5 + $t_6 + $t_7 ) ];
    my $last_volt_value;

    #clamp upper voltage to U_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;     #holds the count of the voltage samples generated based on the sampling rate
    my @volt_samples   = ();    #stores voltage samples

    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;    #temporary variable
                                  #create the first segment of curve till t7.
        $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $last_volt_value = $volt_samples[-1];    #last voltage sample of first segment of curve

    my @time_samples1 = ();
    if ( $freq > 0 )                         #generate sine wave if freq is defined else generate normal line
    {
        for ( my $i = $$time[-1] ; $i <= ( $$time[-1] + 10 ) ; )
        {
            push( @time_samples1, $i );
            $i = $i + $sampling_time;
        }

        foreach my $time_sine_value (@time_samples1)
        {
            my $volt_sine_value = undef;
            $volt_sine_value = ( $last_volt_value + 1 ) + ( 1 * sin( 2 * 3.14 * $freq * $time_sine_value ) );
            $volt_sine_value = sprintf( "%.5f", $volt_sine_value );
            push( @volt_samples, $volt_sine_value );
        }
    }
    else
    {
        for ( my $i = $$time[-1] ; $i <= ( $$time[-1] + 10 ) ; )
        {
            push( @time_samples1, $i );
            $i = $i + $sampling_time;
        }
        my $volt1 = [ $last_volt_value, $v_a ];
        my $time1 = [ ( 1 + $t_50 + $t_f + $t_4 + $t_5 + $t_6 + $t_7 ), ( 1 + $t_50 + $t_f + $t_4 + $t_5 + $t_6 + $t_7 + $t_8 ) ];

        for ( my $i = 0 ; $i < ( scalar(@$volt1) - 1 ) ; $i++ )
        {
            my $volt_aref = undef;    #temporary variable
            $volt_aref = Create_linear_curve( $$time1[$i], $$volt1[$i], $$time1[ $i + 1 ], $$volt1[ $i + 1 ], $sampling_time );
            push( @volt_samples, @$volt_aref );
        }
    }

    $last_volt_value = $volt_samples[-1];    #last value of second segment of curve

    my $volt2 = [ $last_volt_value, $v_b, $v_b ];
    my $time2 = [ ( $time_samples1[-1] ), ( $time_samples1[-1] + $t_r ), ( $time_samples1[-1] + $t_r + $t1 ) ];

    for ( my $i = 0 ; $i < ( scalar(@$volt2) - 1 ) ; $i++ )
    {
        my $volt_aref = undef;               #temporary variable
        $volt_aref = Create_linear_curve( $$time2[$i], $$volt2[$i], $$time2[ $i + 1 ], $$volt2[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    # write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;
    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_11','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_11 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "10V", "Time" => "20S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_12 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_12($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VMIN', 'VMAX', 'T1', 'TR', 'TF', 'NUMBER_OF_CYCLES', 'DELTA_V', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'VMIN', 'VMAX', 'T1', 'TR', 'TF', 'NUMBER_OF_CYCLES', 'DELTA_V' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

                                         T1
     Vmax                         |_____________|
                                 /|             |\
                                / |             | \
                               /  |             |  \
                              /   |             |   \
                             /    |             |    \
     Vmin      _____________/     |             |     \
                    T1        TR                  TF

=for html
<IMG SRC='..\..\pics\sVTT\E12_Spec.png'  alt="LV124 E12" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_12({'CURVE_NAME' => 'LV124_e_12','VMIN' => 11.8,'VMAX' => 15, 'T1' => 2, 'TR' => 0.301, 'TF' => 0.301, 'NUMBER_OF_CYCLES' => 10, 'DELTA_V' => 0.7});
    $curve_filename = LV124_e_12({'CURVE_NAME' => 'LV124_e_12','VMIN' => 11.8,'VMAX' => 15, 'T1' => 2, 'TR' => 0.301, 'TF' => 0.301, 'NUMBER_OF_CYCLES' => 10, 'DELTA_V' => 0.7, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_12({'CURVE_NAME' => 'LV124_e_12','VMIN' => 11.8,'VMAX' => 15, 'T1' => 2, 'TR' => 0.301, 'TF' => 0.301, 'NUMBER_OF_CYCLES' => 10, 'DELTA_V' => 0.7},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_12
{
    S_w2log( 5, "Creation of LV124_e_12\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VMIN', 'VMAX', 'T1', 'TR', 'TF', 'NUMBER_OF_CYCLES', 'DELTA_V' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_min            = $$curve_params_href{'VMIN'};
    my $v_max            = $$curve_params_href{'VMAX'};
    my $t_1              = $$curve_params_href{'T1'};
    my $t_r              = $$curve_params_href{'TR'};
    my $t_f              = $$curve_params_href{'TF'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};
    my $delta_v          = $$curve_params_href{'DELTA_V'};
    my $randomness       = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time    = $$curve_params_href{'SAMPLING_TIME'};

    my $curve_time = time();    # store time of LIFT start

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename      = 'lv_124_e12' . '_' . $start_time;
    my $curve_filename_path = $sat_file_savepath . $curve_filename . ".svtc";

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 0.1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                              #in seconds
    }

    # voltage value of the curve at the given time. These values are taken as arrays'.
    # t0 = 0, V0 = $v_min - $delta_v
    # t1 = $t_1 , V1 = $v_min - $delta_v
    # t2 = $t_1 + $t_r , V1 = $v_max - $delta_v
    # t3 = $t_1 + $t_r + $t_1 , V1 = $v_max - $delta_v
    # t3 = $t_1 + $t_r+ $t_1 + $t_f , V1 = $v_min - $delta_v

    my $volt = [ ( $v_min - $delta_v ), ( $v_min - $delta_v ), ( $v_max - $delta_v ), ( $v_max - $delta_v ), ( $v_min - $delta_v ) ];    #volt-sequence, curve specification
    my $time = [ 0, $t_1, ( $t_1 + $t_r ), ( $t_1 + $t_r + $t_1 ), ( $t_1 + $t_r + $t_1 + $t_f ) ];                                      #time-sequence in s, curve specification

    #limitations for curve voltage values to the defined limits
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my @volt_samples   = ();    #stores voltage samples
    my $num_of_samples = 0;     #holds the count of the voltage samples generated based on the sampling rate
    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );    #create line curve from (t(i),V(i)) and (t(i+1), V(i+1))
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path" || die "couldn't open $curve_filename\n";
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    #write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_12','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_12 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "10V", "Time" => "10S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head2 LV124_e_15 curve

I<B<Syntax : >>

    $curve_filename = LV124_e_15($curve_params [, $u_lower, $u_upper, $curve_folder_path] );

I<B<Arguments    : >>

    curve_params : Hash reference  containing keys - 'CURVE_NAME', 'VMAX', 'VMIN', 'DELTA_V1', 'T1', 'T2', 'TR', 'TF','NUMBER_OF_CYCLES', 'RANDOMNESS', 'SAMPLING_TIME'
    u_lower      : User defined curve minimum allowable voltage
    u_upper      : User defined curve maximum allowable voltage
    curve_folder_path : path to save the generated votlage curve file

    'CURVE_NAME' - Name of the curve (as in API)
    'VMAX', 'VMIN', 'DELTA_V1', 'T1', 'T2', 'TR', 'TF','NUMBER_OF_CYCLES' - Curve related params (refer specification)
    'RANDOMNESS' - controls the randomness (stochastic) curve
    'SAMPLING_TIME' - sampling time of curve

    u_lower, u_upper and curve_folder_path are optional parameters. These are read from GUI if the user creates curves from GUI.
    If not, these are read from project constants (u_lower, u_upper ) and config file(curve_folder_path).

               t1  t2
     Vmax  ___    ___      ___        ___ ........ __              ___
         ____ \__/   \    /   \      /               \            /
delta_V1 ____________ \__/  tf \    / tr              \          /
                                \__/                   \        /
                                                        \      /
                                                         \    /
     Vmin ________________________________________________\__/

=for html
<IMG SRC='..\..\pics\sVTT\E15_Spec.png'  alt="LV124 E15" border="0">

I<B<Return values : >>

    curve_filename : voltage curve file name

I<B<Example : >>

    $curve_filename = LV124_e_15({'CURVE_NAME' => 'LV124_e_15','VMAX' => 0, 'VMIN' => -14,'DELTA_V1' => -1, 'T1' => 60, 'T2' => 60,'TR' => 10, 'TF' => 10, 'NUMBER_OF_CYCLES' => 1});
    $curve_filename = LV124_e_15({'CURVE_NAME' => 'LV124_e_15','VMAX' => 0, 'VMIN' => -14,'DELTA_V1' => -1, 'T1' => 60, 'T2' => 60,'TR' => 10, 'TF' => 10, 'NUMBER_OF_CYCLES' => 1, 'RANDOMNESS' => 'YES', 'SAMPLING_TIME' => 0.1},0,20);
    $curve_filename = LV124_e_15({'CURVE_NAME' => 'LV124_e_15','VMAX' => 0, 'VMIN' => -14,'DELTA_V1' => -1, 'T1' => 60, 'T2' => 60,'TR' => 10, 'TF' => 10, 'NUMBER_OF_CYCLES' => 1},0,20,"c:\\temp\\svtt_curves");

=cut

sub LV124_e_15
{
    S_w2log( 5, "Creation of LV124_e_15\n" );

    my $curve_params_href = shift;
    my $u_lower           = shift;
    my $u_upper           = shift;
    my $curve_folder_path = shift;

    # required curve parameters
    my @required_keys = ( 'CURVE_NAME', 'VMAX', 'VMIN', 'DELTA_V1', 'T1', 'T2', 'TR', 'TF', 'NUMBER_OF_CYCLES' );

    # passed curve parameters
    my @passed_keys = keys(%$curve_params_href);

    # check whether all the required curve parameters are passed
    my $status = Check_input_arguments( \@passed_keys, \@required_keys );
    return if ( !$status );

    # initialize the values of $sat_file_savepath, $u_min, $u_max
    my ( $sat_file_savepath, $u_min, $u_max ) = Curve_init( $u_lower, $u_upper, $curve_folder_path );
    if ( !$curve_init )
    {
        S_set_error( "Curve Initialization not successful", 21 );
        return 0;
    }

    my $curve_time = time();

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($curve_time);
    my $start_time = sprintf( "%02d%02d%04d", $hour, $min, $sec );

    my $curve_filename      = 'LV124_e_15' . '_' . $start_time;
    my $curve_filename_path = $sat_file_savepath . $curve_filename . ".svtc";

    my $curve_name       = $$curve_params_href{'CURVE_NAME'};
    my $v_max            = $$curve_params_href{'VMAX'};
    my $v_min            = $$curve_params_href{'VMIN'};
    my $delta_v1         = $$curve_params_href{'DELTA_V1'};
    my $t_1              = $$curve_params_href{'T1'};
    my $t_2              = $$curve_params_href{'T2'};
    my $t_r              = $$curve_params_href{'TR'};
    my $t_f              = $$curve_params_href{'TF'};
    my $number_of_cycles = $$curve_params_href{'NUMBER_OF_CYCLES'};

    my $randomness    = $$curve_params_href{'RANDOMNESS'};
    my $sampling_time = $$curve_params_href{'SAMPLING_TIME'};

    if ( defined $randomness )
    {
        if ( $randomness eq "YES" )
        {
            $t_r = Unique_Random_Generator( $t_r, 'TR' );    #returns the random value for 'tr' if randomness is selected
            return if ( !defined $t_r );

            $t_f = Unique_Random_Generator( $t_f, 'TF' );    #returns the random value for 'tf' if randomness is selected
            return if ( !defined $t_f );

            $t_1 = Unique_Random_Generator( $t_1, 'T1' );    #returns the random value for 't1' if randomness is selected
            return if ( !defined $t_1 );

            $t_2 = Unique_Random_Generator( $t_2, 'T2' );    #returns the random value for 't2' if randomness is selected
            return if ( !defined $t_2 );
        }
    }

    unless ($sampling_time)                                  #sampling time is 0.1ms (tuned after verifying the curve output on oscilloscope) if it is not defined by user
    {
        $sampling_time = 0.001;                              #in seconds
    }

    my @v_temp  = ();
    my @v_temp1 = ();
    my @t_temp  = ();
    my @t_temp1 = ();
    $t_temp1[0] = 0;
    push( @v_temp, $v_max );                                 #the curve starts at v_max
    push( @t_temp, 0 );                                      #time starts at 0
    my $v_limit = $v_max;

    for ( my $i = 1 ; $v_limit > $v_min ; $i++ )             #calculate the voltage samples for v_limit <= v_min for the step of delta_v1
    {
        $v_temp1[$i] = sprintf( "%.5f", $v_max );
        $v_temp1[ $i + 1 ] = sprintf( "%.5f", ( $v_max + ( $i * $delta_v1 ) ) );
        $v_temp1[ $i + 2 ] = sprintf( "%.5f", ( $v_max + ( $i * $delta_v1 ) ) );
        $v_temp1[ $i + 3 ] = sprintf($v_max);
        push( @v_temp, $v_temp1[$i], $v_temp1[ $i + 1 ], $v_temp1[ $i + 2 ], $v_temp1[ $i + 3 ] );
        $v_limit = $v_temp1[ $i + 1 ];
    }

    for ( my $i = 1 ; $i <= scalar( (@v_temp) - 1 ) ; )      #calculate the time array for previously calculated voltage array
    {
        $t_temp1[$i]       = $t_temp[-1] + $t_2;
        $t_temp1[ $i + 1 ] = $t_temp1[$i] + $t_f;
        $t_temp1[ $i + 2 ] = $t_temp1[ $i + 1 ] + $t_1;
        $t_temp1[ $i + 3 ] = $t_temp1[ $i + 2 ] + $t_r;
        push( @t_temp, $t_temp1[$i], $t_temp1[ $i + 1 ], $t_temp1[ $i + 2 ], $t_temp1[ $i + 3 ] );
        $i += 4;
    }

    my $volt         = \@v_temp;
    my $time         = \@t_temp;
    my @volt_samples = ();                                   #stores voltage samples

    #clamp upper voltage to u_max, lower voltage to U_min
    for ( my $i = 0 ; $i < scalar(@$volt) ; $i++ )
    {
        if ( $$volt[$i] > $u_max )
        {
            $$volt[$i] = $u_max;
        }
        elsif ( $$volt[$i] < $u_min )
        {
            $$volt[$i] = $u_min;
        }
    }

    my $num_of_samples = 0;    #holds the count of the voltage samples generated based on the sampling rate
    for ( my $i = 0 ; $i < ( scalar(@$volt) - 1 ) ; $i++ )
    {
        my $volt_aref = Create_linear_curve( $$time[$i], $$volt[$i], $$time[ $i + 1 ], $$volt[ $i + 1 ], $sampling_time );
        push( @volt_samples, @$volt_aref );
    }

    $num_of_samples = scalar(@volt_samples);

    #open the curve file and write the following header info
    open my $SVTC, '>', "$curve_filename_path";
    unless ($SVTC)
    {
        S_set_error( "couldn't open $curve_filename\n", 21 );
        return 0;
    }
    print $SVTC "Curve Name : $curve_name\n";
    print $SVTC "Samples : $num_of_samples\n";
    print $SVTC "Iteration : $number_of_cycles\n";
    print $SVTC "Time[s] : $sampling_time\n";
    print $SVTC "\nU[V]\n";

    #write voltage samples to $SVTC file
    for ( my $k = 0 ; $k < scalar(@volt_samples) ; $k++ )
    {
        print $SVTC "$volt_samples[$k]\n";
    }

    close($SVTC);
    $count_iteration = 0;

    # if (scalar(@volt_samples) < 1000000)
    # {
    
        # my @time_samples = ();
        # my $temp = 0;
        # for (my $k = 0; $k <  $num_of_samples; $k++)
        # {
            # $temp = $temp + $sampling_time;
            # push (@time_samples, $temp);
        # } 
            # my $curve={
                        # 'time' => \@time_samples,
                        # 'Voltage'=> \@volt_samples,
                       # };

        # S_create_graph($curve,$curve_filename_path, 'LV_124_E_15','black', 'interpolate_points');
        # S_add_pic2html ( "./sVTT_Curves/$curve_filename.png",'width=400', "./sVTT_Curves/$curve_filename.txt.unv");
    # }
    # else
    # {
       # S_set_error( "Graph cannot be displayed as there are too many points which cannot be handelled", 0);
    # }

    S_w2log( 5, "LV124_e_15 is created at $curve_filename_path \n" );
    S_w2rep( '<a href="./sVTT_Curves/' . $curve_filename . ".svtc". '">Curve File :: ' . $curve_filename . '</a><br>' );
	my $DSO_setting = {"Volt" => "10V", "Time" => "200S" };
    return ( $curve_filename_path,$DSO_setting );
}

=head1 Non exported functions

=head2 Create_linear_curve

I<B<Syntax : >>

    \@Volt_data = Create_linear_curve($Time1,$Volt1,$Time2,$Volt2);

I<B<Arguments    : >>

    $Time1 = start time of the curve
    $Volt1 = starting voltage of the curve
    $Time2 = end time of the curve
    $Volt2 = end voltage of the curve

I<B<Return values : >>

    \@Volt_data = array reference of Volt samples between Volt1 and Volt2


I<B<Examples : >>

    \@Volt_data = Create_linear_curve(0,0,4,5);

I<B<Curve : >>

             /(4,5) (time2, volt2)
            /
           /
          /
         /
        /
        (0,0) (time1, volt1)

To find out the samples , use Point-Slope Form from Two Points formula

(V-V1) = [(V2-V1)/(T2-T1)](T-T1)

=cut

sub Create_linear_curve
{
    my ( $time1, $volt1, $time2, $volt2, $sampling_time ) = @_;
    my $offset = $volt1;    #offset
    my $slope;

    if ( $time2 == $time1 )
    {
        $slope = 0;         #for vertical straight line slope = 0, so hard coded.
    }
    else
    {
        $slope = ( $volt2 - $volt1 ) / ( $time2 - $time1 );    #slope
    }

    my $time_count = sprintf( "%.0f", ( $time2 - $time1 ) / $sampling_time );

    my $time_temp = $time1;
    my ( @time_data, @volt_data ) = ();
    $time_data[0] = $time1;                                    #first value shall be $Time1

    for ( my $i = 1 ; $i <= $time_count ; $i++ )
    {
        $time_temp = $time_temp + $sampling_time;              #calculate the time intervals with sampling_time as the time gap between the time samples
        $time_temp = sprintf( "%.5f", $time_temp );
        push( @time_data, $time_temp );
    }

    for ( my $i = 0 ; $i < scalar(@time_data) ; $i++ )         #calculate voltage samples for every time samples
    {
        my $volt_temp = ( $slope * ( $time_data[$i] - $time1 ) ) + $offset;
        $volt_temp = sprintf( "%.5f", $volt_temp );
        push( @volt_data, $volt_temp );
    }

    if ( $count_iteration != 0 )
    {
        shift @volt_data;
    }

    $count_iteration++;
    return ( \@volt_data );
}

=head2 Curve_init

I<B<Syntax : >>

    ($sat_file_savepath, $u_min, $u_max) = Curve_init( [,$u_min, $u_max, $sat_file_savepath] );

I<B<Arguments    : >>

    u_min - User defined curve minimum allowable voltage (optional)
    u_max - User defined curve maximum allowable voltage (optional)
    sat_file_savepath - path to save the generated votlage curve file (optional)

I<B<Description : >>

 This function reads 'U_min', 'U_max' from Project Defaults and sVTTCurve_file_path from cfg file if $u_min, $u_max, $sat_file_savepath are not specified.

 By default, sVTTCurve_file_path is the current test report folder.

 If not success, then it will throw error.

refer L</ProjectDefaults> for Project Defaults settings.

I<B<Return values : >>

  sat_file_savepath - curve file path where the curve file is stored
  u_min - Minimum allowable voltage value
  u_max - Maximum allowable voltage value
  undef - On failure

I<B<Examples : >>

    ($sat_file_savepath, $u_min, $u_max) = Curve_init($u_min, $u_max, $sat_file_savepath);

=cut

sub Curve_init
{
    my $u_min             = shift;
    my $u_max             = shift;
    my $sat_file_savepath = shift;

    $curve_init = 0;    #reset the init flag

    unless ( defined $sat_file_savepath )
    {
        $sat_file_savepath = $main::save_name . "\\sVTT_Curves\\";
        $sat_file_savepath = File::Spec->rel2abs( dirname($sat_file_savepath) );
        $sat_file_savepath = $sat_file_savepath . "\\sVTT_Curves\\";
        S_w2log( 4, "sat_file_savepath is $sat_file_savepath\n" );
        unless ( -d $sat_file_savepath )
        {
            mkdir $sat_file_savepath;
        }
    }

    unless ( defined $u_min )
    {
        S_w2log( 5, "Reading U_min from ProjectDefaults->{'VTT'}\n" );
        $u_min = $main::ProjectDefaults->{'VTT'}{'Curve_Controls'}{'U_min'};
        unless ( defined $u_min )
        {
            S_set_error( " couldnot read 'U_min' from project defaults. Defaults->{'VTT'}{'Curve_Controls'}{'U_min'}\n", 20 );
            return ( undef, undef, undef );
        }
        S_w2log( 5, "U_min is $u_min\n" );
    }

    unless ( defined $u_max )
    {
        S_w2log( 5, "Reading U_max from ProjectDefaults->{'VTT'}\n" );
        $u_max = $main::ProjectDefaults->{'VTT'}{'Curve_Controls'}{'U_max'};
        unless ( defined $u_max )
        {
            S_set_error( " couldnot read 'U_max' from project defaults. Defaults->{'VTT'}{'Curve_Controls'}{'U_max'}\n", 20 );
            return ( undef, undef, undef );
        }
        S_w2log( 5, "U_max is $u_max\n" );
    }

    unless ( $u_max > $u_min )
    {
        S_set_error( " 'U_max' should be greaterthan 'U_min'\n", 114 );
        return ( undef, undef, undef );
    }

    $curve_init = 1;    #on success, init flag is set
    return ( $sat_file_savepath, $u_min, $u_max );
}

=head2 Unique_Random_Generator

I<B<Syntax : >>

    $rand_val = Unique_Random_Generator( $param_value , $param_name );

I<B<Arguments : >>

    minval - minimum value
    maxval - maximum value

I<B<Description : >>

    This function returns a random value in the range minval to maxval.

I<B<Return values : >>

    rand_val - random value in the range minval to maxval when randomness is selected
    param_value - param value which is passed as input

I<B<Examples : >>

    $rand_val = Unique_Random_Generator( $param_value , $param_name );

=cut

sub Unique_Random_Generator
{
    my $param_value = shift;
    my $param_name  = shift;

    if ( $param_value =~ m/^\d*\.?\d*\|\d*\.?\d*$/ )
    {
        my @temp   = split( /\|/, $param_value );
        my $minval = $temp[0];
        my $maxval = $temp[1];
        S_w2log( 5, "min value of Parameter $param_name : $minval \n" );
        S_w2log( 5, "man value of Parameter $param_name : $maxval \n" );
        if ( $minval >= $maxval )
        {
            S_set_error( "Min is greaterthan or equal to max for parameter $param_name\n ", 114 );
            return;
        }
        my $rand_val = sprintf( "%0.3f", ( rand( $maxval - $minval ) ) ) + $minval;
        S_w2log( 5, "Random value of Parameter $param_name : $rand_val \n" );
        return $rand_val;
    }
    else
    {
        S_w2log( 5, "Parameter for randomness of $param_name not given in par file \n" );
        return $param_value;
    }
}

=head2 Check_input_arguments

I<B<Syntax : >>

    $rand_val = Check_input_arguments( $input_aref, $expected_aref);

I<B<Arguments    : >>

    input_aref - input array reference
    expected_aref - expected array reference

I<B<Description : >>

This function checks whether input array passed contains all the expected elements by comparing it with expected_aref.

I<B<Return values : >>

    undef - On failure
    1 - On success

I<B<Examples : >>

    Check_input_arguments ($input_aref, $expected_aref);

=cut

sub Check_input_arguments
{
    my $input_aref    = shift;
    my $expected_aref = shift;

    if ( scalar @$input_aref < scalar @$expected_aref )
    {
        S_set_error( "Curve_name parameter doesnot contain required number of elements\n", 0 );
    }

    foreach my $check_param (@$expected_aref)
    {
        if ( grep( {/^$check_param$/} @$input_aref ) )
        {
            next;
        }
        else
        {
            S_set_error( "Curve_name parameter doesnot contain key '$check_param'\n", 110 );
            return;
        }
    }
    return 1;
}

1;
__END__

=head1 AUTHORS

 Archana Gopalakrishna, E<lt> Archana.Gopalakrishna@in.bosch.com E<gt>

=head1 NOTES

=head1 User Manual

=head1 SEE ALSO

=cut