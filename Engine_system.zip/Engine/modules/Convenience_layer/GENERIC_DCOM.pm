# C:\ISMPerl\V5_6_1\bin\Perl.exe
package GENERIC_DCOM;

=head1 NAME

GENERIC_DCOM 

Provide GENERIC useful functions for DCOM tests 

=cut

#####################################################################

=head1 SYNOPSIS

    use GENERIC_DCOM;
    
    GDCOM_init 
    GDCOM_final 
    GDCOM_start_communication 
    GDCOM_stop_communication 
    GDCOM_request
    GDCOM_request_general 
    GDCOM_evaluate_phys
    GDCOM_evaluate_hex
    GDCOM_getNRCfromMapping 
    GDCOM_getSupportedSubFunsfromMapping 
    GDCOM_ReadandEvaluteSession 
    GDCOM_StartSession 
    GDCOM_getRequestInfofromMapping
    GDCOM_evaluate_response_bytes
    GDCOM_clear_DTCs
    GDCOM_ecu_reset
    GDCOM_set_addressing_mode  
    GDCOM_start_CyclicTesterPresent
    GDCOM_stop_CyclicTesterPresent
    GDCOM_SecurityAccess_Unlock
    GDCOM_GetAccessToRequest
    GDCOM_SecurityAccessECULock
    GDCOM_read_and_eval_fcm_cu
    GDCOM_read_and_eval_DTCStatusBits
    GDCOM_read_and_eval_FaultStatusBits
    GDCOM_read_and_eval_DTCExtDataRecbyDTCNum
    GDCOM_CA_Trace_get_ReqResp
    GDCOM_CheckRequestIsExistInMapping
    GDCOM_getRequestLabelValue
    GDCOM_requestlength_manipulation
    GDCOM_start_CyclicMessage
    GDCOM_stop_CyclicMessage
    GDCOM_GenerateInvalidSet
    GDCOM_getSupportedIdentifersfromMapping

    Other functions should not be used in test cases.


=head1 Diag mapping

The DIAG Mapping is used by LIFT_DCOM and GENERIC_DCOM to be able to access DCOM requests and responses by name (instead of by byte sequences).

It may be generated from pdx/odx files using the following tool:

    TurboLIFT\Tools\GDCOM_Tool\Release\GDCOM_Configurator.exe

However there are different versions of pdx/odx files by different customers and the tool cannot handle all versions.
 
Diag mapping file contents examples:

    "Mapping_DIAG" => {
        
        "DiagServices" => {
            "StartSession" => {
                "Service_ID" => "10" ,
                "Supported_SubFuns" => {
                    "DefaultSession"                   => "01" ,
                    "ProgrammingSession"               => "02" ,
                    "ExtendedSession"                  => "03" ,
                    ...
                },
                "NEG_Responses" => {
                    "NR_busyRepeatRequest"      => { 
                        "Response" =>  "7F 10 21" , 
                        "Mode" =>  "strict" , 
                        "Desc" =>  "StartSession: busyRepeatRequest" , 
                        "AddrModes" => ["Physical","Functional"]
                    },
                    "NR_conditionsNotCorrect" => { 
                        "Response" =>  "7F 10 22" , 
                        "Mode" =>  "strict" , 
                        "Desc" =>  "StartSession: conditionsNotCorrect", 
                        "AddrModes" => ["Physical","Functional"]
                    },
                    ...
                },
            },
            ...
        },
    
        "Requests_Responses" => {
            "StartSession_DefaultSession" => {
                "Requests" => {
                    "REQ_StartSession_DefaultSession" => { 
                        "Request" => "10 01"
                    },
                },
                "POS_Responses" => {
                    "PR_StartSession_DefaultSession"  => { 
                        "Response" =>  "50 01 00 32 01 F4" , 
                        "Mode" =>  "strict" , 
                        "Desc" =>  "Start Session: StartSession_DefaultSession" , 
                        "DataLength" => "" , 
                        "DoorsIDs" => [ "" ]
                    },
                },
            },
            "WriteMemorybyAddress" => {
                "Requests" => {
                    "REQ_WriteMemorybyAddress" => { 
                        "Request" => "3D 14 Addr Len" , 
                    },
                    "REQ_WriteMemorybyAddress__getwriteaccess" => { 
                        "DependentRequest" => "27 03 | 67 03 x4 | 27 04 y4 | 67 04", 
                        "Function" => "add_const", 
                        "Parameters" => "70384",
                        "Desc" => "Get write access for Write memory by address",
                    },
                },
                "POS_Responses" => {
                    "PR_WriteMemorybyAddress" => { 
                        "Response" => "7D 14 Addr Len" , 
                        "Mode" =>  "relax" , 
                        "Desc" =>  "PR: Write Data to memory ", 
                    },
                },
                "allowed_in_sessions" => [ "DevelopmentSession"  ] ,
                "DID" =>  "3D 14 " ,
            },
            ...
        },
    
    	"GlobalNRC" => {
    		"10" => "generalReject",
    		"11" => "serviceNotSupported",
            ...
    	},
    },

=cut

#####################################################################

use LIFT_DCOM;
use LIFT_general;
use DCOM_SecurityAccess_KeyAlgo;
use DCOM_user_functions;
# use Data::Dumper;
#use STEPS_compact;
use strict qw(vars);
          
use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;
# next 2 lines edited by CVS, DO NOT MODIFY
    
@ISA = qw(Exporter);
@EXPORT = qw(

                GDCOM_init 
                GDCOM_final 
                GDCOM_start_communication 
                GDCOM_stop_communication 
                GDCOM_request_general 
                GDCOM_delay 
                GDCOM_comment 
                GDCOM_ecu_on
                GDCOM_ecu_off
                GDCOM_wait_for_user 
                GDCOM_tcpar 
                GDCOM_tcpar_mandatory 
                GDCOM_tcpar_optional 
                GDCOM_ignition_on
                GDCOM_ignition_off
                GDCOM_SetEeprom
                GDCOM_GetEeprom
                GDCOM_get_environment
                GDCOM_GetEepromMultipleLocations
                GDCOM_SetEepromMultipleLocations
                GDCOM_DelEepromMultipleLocations
                GDCOM_evaluate_phys
                GDCOM_evaluate_hex
                GDCOM_request_func 
                GDCOM_CA_read_can_signals 
                GDCOM_CA_write_can_signals 
                GDCOM_CA_disable_messages
                GDCOM_CA_enable_messages
                GDCOM_CA_trace_start
                GDCOM_CA_trace_stop
                GDCOM_request_w2html
                GDCOM_request
                GDCOM_getSupportedSubFunsfromMapping
                GDCOM_getReqestResponseFromMapping
                GDCOM_getNRCfromMapping
                GDCOM_request_w2html
                GDCOM_ReadandEvaluteSession 
                GDCOM_StartSession 
                GDCOM_resolve_label_value 
                GDCOM_set_error 
                GDCOM_getRequestInfofromMapping
                GDCOM_getDID_FixedDataValueFromMapping
                GDCOM_get_DID_2_EEPROMMapping 
                GDCOM_evaluate_response_bytes
                GDCOM_clear_DTCs
                GDCOM_set_electric_signals
                GDCOM_reset_electric_signals
                GDCOM_manipulate_lines
                GDCOM_SetVehicleSpeed 
                GDCOM_set_target_speed 
                GDCOM_goto_target_speed
                GDCOM_set_wheel_speeds_kmh 
                GDCOM_reset_wheel_speeds_kmh 
                GDCOM_set_Engine_speed 
                GDCOM_reset_Engine_speed
                GDCOM_ecu_reset
                GDCOM_w2TestStep
                GDCOM_set_addressing_mode
                GDCOM_Variant_Learning
                GDCOM_dependent_requests 
                GDCOM_LC_set_label 
                GDCOM_set_Ubatt 
                GDCOM_set_verdict   
                GDCOM_reset_speed 
                GDCOM_start_CyclicTesterPresent
                GDCOM_stop_CyclicTesterPresent    
                GDCOM_SecurityAccess_GetSeed
                GDCOM_SecurityAccess_Unlock
                GDCOM_GetAccessToRequest
                GDCOM_send_multiple_requests
                GDCOM_CAN_SendMessage
                GDCOM_trace_can_get_message_data
                GDCOM_SecurityAccessECULock
                GDCOM_SecurityAccess_GetKey
                GDCOM_GetProjSupServicesFromMapping
                GDCOM_read_and_eval_fcm_rb
                GDCOM_read_and_eval_fcm_cu
                GDCOM_read_and_eval_DTCStatusBits
                GDCOM_read_and_eval_FaultStatusBits
                GDCOM_read_and_eval_DTCInformation
                GDCOM_wait_ms
                GDCOM_Timer
                GDCOM_get_SW_version
                GDCOM_read_and_eval_DTCExtDataRecbyDTCNum
                GDCOM_get_FaultValue_from_mapping
                GDCOM_read_and_eval_RDBID_Data_phys
                GDCOM_read_and_eval_RDBID_Data_hex
                GDCOM_read_and_eval_ReadService_Data_phys
                GDCOM_read_and_eval_ReadService_Data_hex
                GDCOM_get_allrequests_of_service_fromMapping
                GDCOM_w2html
                GDCOM_CA_Trace_get_ReqResp
                GDCOM_CA_eval_ReqResp_from_dataref
                GDCOM_CA_eval_ResponseTime_from_dataref
                GDCOM_get_ReqResp_from_dataref
                GDCOM_config_labelvalue_of_request
                GDCOM_FR_trace_start
                GDCOM_FR_trace_stop
                GDCOM_FR_Trace_get_ReqResp
                GDCOM_FR_eval_ReqResp_from_dataref
                GDCOM_FR_eval_ResponseTime_from_dataref
                GDCOM_call_user_function
                GDCOM_PD_request_general
                GDCOM_getRequestLabelValue
                GDCOM_PD_getNRCfromMapping
                GDCOM_requestlength_manipulation
                GDCOM_start_CyclicMessage
                GDCOM_stop_CyclicMessage
                GDCOM_GenerateInvalidSet
                GDCOM_getSupportedIdentifersfromMapping
                GDCOM_CheckRequestIsExistInMapping
                GDCOM_getSupportedRIDsInfofromMapping
            ); # export subs

####################
# global variables #
####################

my $TP_handle = undef;
my $Com_handle = undef; #global handle for start and stop communication functions.
my $DiagMapping = {};
my $Testbench = {};

# ******************************************************************************
# ******************************************************************************
#
# DCOM Test Commands - Abstract Command Set
#
# ******************************************************************************
# ******************************************************************************

#####################################################################

=head2 GDCOM_init

    GDCOM_init ( @KEYWORDS );
    
Initializes a compact test.
Initializes global variable CAN and Diag mapping variables. To be called before calling any other function.
Accepts any of the following keywords:

   'EA_CONFIG': configures EA trace (measurement)
   'CA_CONFIG': configures CAN read/write/trace
   'FR_CONFIG': configures Flexray read/write/trace
   'FCM_DEL'  : deletes RB and customer (if configured) fault memory
   'ECU_ON'   : switches the ECU on with default voltage
   'SPEED'    : by default the speed of the target vehicle is set to 0
   
Example:

   GDCOM_init ('EA_CONFIG','ECU_ON');

=cut

#####################################################################

sub GDCOM_init {
   
   my @KEYWORDS = @_;
   # begin table
   DCOM_w2html( "Sl.;TimeStamp;Request;Response;Verdict;Mode;Description" , "BT","white","courier","gray");
   DCOM_w2html( "Initialize TestBench (@KEYWORDS) &5" , "T"  , 'black' , "Courier" );   
   GDCOM_w2TestStep("Heading","Precondition: \n   ".join(',', @KEYWORDS));

   $DiagMapping = S_get_contents_of_hash(['Mapping_DIAG']);

   unless( $DiagMapping ) {
       S_set_error( '$Default->{"Mapping_DIAG"} is not defined (or) Mapping_DIAG.pm file is not included in CFG' , 20 );
       return;
   }

   return( DCOM_init(@KEYWORDS));
}

#####################################################################

=head2 GDCOM_final

    GDCOM_final ( @KEYWORDS );
    
Finalizes a compact test. Accepts any of the following keywords:

   'FCM_DEL' : deletes RB and customer (if configured) fault memory
   'ECU_OFF' : switches the ECU off

Example:

   GDCOM_final ('FCM_DEL','ECU_OFF');

=cut

#####################################################################

sub GDCOM_final {
   
   my @KEYWORDS = @_;
   DCOM_final(@KEYWORDS);

   #end table 
   DCOM_w2html( "" , "ET");
   #write to html log file
   DCOM_w2tc_html();
   GDCOM_w2TestStep("Heading","Finalization: \n   ".join(',', @KEYWORDS));
   return;
}

################################################################################

=head2 GDCOM_start_communication

    GDCOM_start_communication ( [ $COMMENT ] );

Starts diagnosis communication. For K line projects, the tester sends the
configured StartCommunication request. Furthermore, the cyclic transmission
of TesterPresent messages is started (depending on the tester configuration).
The response to such a request is not evaluated in detail.

    $COMMENT    The comment is written to the test report. This field is optional.

Example:

   GDCOM_start_communication ('my comment');

=cut

################################################################################

sub GDCOM_start_communication {

    my $COMMENT = shift;
     DCOM_w2TestStep("TestStep", "Start Communication");
   $Com_handle = DCOM_start_communication ($COMMENT);

}

################################################################################

=head2 GDCOM_stop_communication

    GDCOM_stop_communication ( [ $COMMENT ] );

Stops diagnosis communication. For K line projects, the tester sends the
configured StopCommunication request.
The response to such a request is not evaluated.
Furthermore, the cyclic transmission of TesterPresent messages is stopped
(depending on the tester configuration).

    $COMMENT    The comment is written to the test report. This field is optional.

Example:

    GDCOM_stop_communication ('my comment');

=cut

################################################################################

sub GDCOM_stop_communication {

    my $COMMENT = shift;

    DCOM_w2TestStep("TestStep" ,"Stop Communication");
    
    DCOM_stop_communication ($COMMENT,$Com_handle);
    $Com_handle = undef;
    return 1;
}

################################################################################

=head2 GDCOM_request_general

    $response = GDCOM_request_general ( $REQUEST , $EXPECTED_RESPONSE [, \%Label_Value , $NO_EVAL_SWITCH]);

Sends the given request to ECU and evaluates the response.

Special Scenario : For Dependent Services, the request label is obtained from 'DependentRequest' entry for the respective service from Diagmapping.

Eample : Before writing data bytes to the given address using WriteMemorybyAddress service, the access needs to be obtained. This access request can be put to 'DependentRequest'.

    $REQUEST            Request message to be sent. (Abstract label from the diag mapping file) 

    $EXPECTED_RESPONSE  Expected response. (Abstract label from the diag mapping file)

    \$labelvalue        Reference for the parameter which is read from the parameter file (optional parameter)

    $NO_EVAL_SWITCH        If defined then Evaluation of the obtained response will be skipped (optional parameter)

    Return Value        The ECU response.

Example:

    GDCOM_request_general ( 'REQ_StartSession_DefaultSession' , 'PR_StartSession_DefaultSession','Data' ,$NO_EVAL_SWITCH);
    GDCOM_request_general ( 'REQ_StartSession_DefaultSession' , 'NR_serviceNotSupported');

=cut

################################################################################

sub GDCOM_request_general {

    my $REQUEST = shift;
    my $EXPECTED_RESPONSE = shift;
    my $Label_Value = shift;
    my $NO_EVAL_SWITCH = shift;
    
    my $response;
        
    $response= DCOM_request_general($REQUEST,$EXPECTED_RESPONSE,$Label_Value,$NO_EVAL_SWITCH);
    

    return $response;
}

#####################################################################

=head2 GDCOM_evaluate_phys

    DCOM_evaluate_phys ( $detected_response, $expected_hashref, $label_group );

Example:

    GDCOM_evaluate_phys($detected_response, $expected_hashref, $label_group);
    example hash reference
      $expected_hashref = {  'sig1' => '10 20 40 50' ,    
                             'sig2' => '11 22 33 44' ,
                             'sig3' => '99', 
                          };

=cut

#####################################################################�

sub GDCOM_evaluate_phys{

  my $detected_response = shift;
  my $expected_hashref = shift;
  my $label_group = shift;
  
  my( 
      $expected_value,
      $tolerance,
    );
  
  unless(defined $label_group)
  {
        DCOM_set_error( " too less parameters ! SYNTAX: GDCOM_evaluate_phys ", 110 );
        return 0;
  }

  foreach my $datalabel(keys %$expected_hashref)
  {
      $expected_value = $expected_hashref->{$datalabel};
            ### if value has to be checked with tolerance ( e.g '100.0%3.5' or '- 10 % 3' )
        if ( $expected_value =~ /([+-]?\s*\w+\.?\d*)\s*%\s*(\d+\.?\d*)/i )
        {
            $expected_value = $1; $tolerance = $2;
            GDCOM_w2TestStep("TestStep" , "Eval: $datalabel = $expected_value (tolerance - $tolerance %)" );
            DCOM_evaluate_phys($detected_response,$datalabel,$expected_value,$label_group, $tolerance , 'relative');
        }
        elsif ( $expected_value =~ /([+-]?\s*\w+\.?\d*)\s*\?\s*(\d+\.?\d*)/i )
        {
            $expected_value = $1; $tolerance = $2;
            GDCOM_w2TestStep("TestStep" , "Eval: $datalabel = $expected_value (tolerance - +/- $tolerance)" );
            DCOM_evaluate_phys($detected_response,$datalabel,$expected_value,$label_group, $tolerance , 'absolute');
        }
        else  ### check values directly without tolerance
        {
            GDCOM_w2TestStep("TestStep" , "Eval: $datalabel = $expected_value" );
            DCOM_evaluate_phys($detected_response,$datalabel,$expected_value,$label_group);
        }
  }
  return 1;
}

#####################################################################

=head2 GDCOM_evaluate_hex

    GDCOM_evaluate_hex ( $detected_response, $expected_hashref, $label_group);

Example:

    example hash reference
      $expected_hashref = {  'sig1' => '10 20 40 50' ,    
                             'sig2' => '11 22 33 44' ,
                             'sig3' => '99', 
                          };


=cut

#####################################################################�

sub GDCOM_evaluate_hex{
  my $detected_response = shift;
  my $expected_hashref = shift;
  my $label_group = shift;
  
  my $expected_value;

  unless(defined $label_group)
  {
        DCOM_set_error( " too less parameters ! SYNTAX: GDCOM_evaluate_hex ", 110 );
        return 0;
  }

  foreach my $datalabel(keys %$expected_hashref)
  {
    $expected_value = $expected_hashref->{$datalabel};
    GDCOM_w2TestStep("TestStep" , "Eval:" , "$datalabel = '$expected_value'" );
    DCOM_evaluate_hex($detected_response,$datalabel,$expected_value,$label_group);
  }
  return 1;
}

################################################################################

=head2 GDCOM_request

    $det_response = GDCOM_request ( $REQUEST , $EXPECTED_RESPONSE , $MODE , [ $COMMENT ] );

Sends the given request to ECU and evaluates the response.

    $REQUEST            Request message to be sent. Hex bytes separated by spaces
                        should be used.
    $EXPECTED_RESPONSE  Expected response. See DCOM_evaluate() for details.
    $MODE               Response evaluation mode. See DCOM_evaluate() for details.
                        'strict'           Length of expected response has to match exactly.
                        'relax'            Only the specified response bytes have to match.
                                           Additional bytes can be sent by the ECU.
                        'quiet'            No ECU response must be sent.
                        'optional strict'  'strict' or 'quiet'
                        'optional relax'   'relax' or 'quiet'
    $COMMENT            The comment is written to the test report. This field is optional.

    Return Value        The ECU response.

Example:

    GDCOM_request ('1A 80', '5A 80', 'strict', 'my comment');

=cut

################################################################################

sub GDCOM_request {

    my $REQUEST = shift;
    my $EXPECTED_RESPONSE = shift;
    my $MODE = shift;
    my $COMMENT = shift;

    my $det_response;

    $det_response= DCOM_request($REQUEST, $EXPECTED_RESPONSE, $MODE, $COMMENT);
    
    return $det_response;
}

################################################################################

=head2 GDCOM_getNRCfromMapping

     GDCOM_getNRCfromMapping($service,$NRCLabel);
     
returns a refernce for the NegetiveResponse defined in the $service service refering to the diagmapping file.     
    
   e.g. $NRCInfo = GDCOM_getNRCfromMapping('StartSession','NR_LengthIncorrect');

=cut

################################################################################

sub GDCOM_getNRCfromMapping {
  my $service = shift;
  my $NRCLabel = shift;
  my $NRCInfo; #hash ref to get NRC information
    
  $NRCInfo->{'Response'} = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Response'};
  $NRCInfo->{'Mode'}  = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Mode'};
  $NRCInfo->{'Desc'}  = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Desc'};
  $NRCInfo->{'AddrModes'}  = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'AddrModes'};

  return $NRCInfo;
}

################################################################################

=head2 GDCOM_getSupportedSubFunsfromMapping

    $supported_sub_functions=GDCOM_getSupportedSubFunsfromMapping($service);

returns a refernce for the Subfunctions which are supported in the $service service refering to the diagmapping file.
    
   e.g. GDCOM_getSupportedSubFunsfromMapping('StartSession');    

=cut

################################################################################

sub GDCOM_getSupportedSubFunsfromMapping {
  my $service = shift;
   
  my $supported_sub_functions;
    
  $supported_sub_functions = $DiagMapping->{'DIAG_SERVICES'}{$service}{'Supported_SubFuns'};
  
   return $supported_sub_functions;
   
}

################################################################################

=head2 GDCOM_ReadandEvaluteSession
       
       GDCOM_ReadandEvaluteSession($Session);
       
Reads the current session and evaluates it. 

e.g. GDCOM_ReadandEvaluteSession('DefaultSession',$ActiveDiagnosticSession_label); 

ActiveDiagnosticSession_label = ReadDatabyID_F186_ActiveDiagnosticSession (as defined in mapping file)

=cut

################################################################################

sub GDCOM_ReadandEvaluteSession { 

 my $session = shift;
 my $ActiveDiagnosticSession_label = shift;
 my ( $request,
      $response,
      $detected_response,
      $RequestLabel,
      $RequestInfo,
      $mode,
      $desc,
     );
   my $supported_sub_functions = GDCOM_getSupportedSubFunsfromMapping('StartSession' );
  
   unless (defined( $session )) {
        DCOM_set_error( " too less parameters ! SYNTAX: GDCOM_ReadandEvaluteSession ( $session [,$ActiveDiagnosticSession_label] )", 110 );
        return 0;
    }
  $session =~ s/(_supressPOSResp)//;    
    if (defined $ActiveDiagnosticSession_label)
    {  
      $RequestLabel = $ActiveDiagnosticSession_label; 
    }
    else 
    {
  $RequestLabel = "ReadDatabyID_F186_ActiveDiagnosticSession";

    }
        
  $RequestInfo = GDCOM_getRequestInfofromMapping($RequestLabel);  

  $request = $RequestInfo->{'Requests'}{"REQ_".$RequestLabel}{'Request'};  
  $response = $RequestInfo->{'POS_Responses'}{"PR_".$RequestLabel}{'Response'}." ".$supported_sub_functions -> {$session};
  $mode = 'strict';
  $desc =  "Evaluate active session is ".$session;
  $detected_response = GDCOM_request($request,$response,$mode,$desc); 

  GDCOM_w2TestStep("TestStep" , "$request - $RequestLabel","$response - $desc" );
  
#   DCOM_evaluate_hex ( $detected_response , 'ActiveDiagnosticSession' , $supported_sub_functions -> {$session} , 'ReadDatabyID'  );

  return 1;
}

################################################################################

=head2 GDCOM_StartSession
       
       GDCOM_StartSession($Session, [CheckAcitveSession]);  
       
            
       
       e.g GDCOM_StartSession('DefaultSession' , 'CheckActiveSession' ,$ActiveDiagnosticSession_label);
       $ActiveDiagnosticSession_label = ReadDatabyID_F186_ActiveDiagnosticSession (as defined in mapping file)

=cut

################################################################################

sub GDCOM_StartSession { 

   my $session = shift;
   my $CheckActiveSession = shift;
   my $ActiveDiagnosticSession_label = shift;
   my ( $request,
        $response,
      ); 
     
   unless(defined( $session )) {
        DCOM_set_error( " too less parameters ! SYNTAX: GDCOM_StartSession ( $session )", 110 );
        return 0;
    }

#check for security access for the session 
#---------------
   GDCOM_GetAccessToRequest("StartSession_".$session);

#Enter a session
#---------------

  $request = "REQ_StartSession_".$session;
  $response = "PR_StartSession_".$session;

  GDCOM_request_general( $request , $response);
#check whether ECU is in correct session
#---------------  
   if ( defined $CheckActiveSession)
    { 
        if ($CheckActiveSession eq "CheckActiveSession")
        {
            if (defined $ActiveDiagnosticSession_label)
            {
                GDCOM_ReadandEvaluteSession($session,$ActiveDiagnosticSession_label);
            }
            else
            {
                GDCOM_ReadandEvaluteSession($session);
            }
        }
   
       else 
       {
            DCOM_set_error( "String miss match ! $CheckActiveSession should be 'CheckActiveSession' ", 0 );
        }
    }
  return 1;
}

################################################################################

=head2 GDCOM_getRequestInfofromMapping
 
    $RequestInfo=GDCOM_getRequestInfofromMapping($Request);

returns a refernce for the Request information from the DiagMapping file
    
   e.g. GDCOM_getRequestInfofromMapping('ReadDatabyID_ECUProgrammingInformation');    

=cut

################################################################################

sub GDCOM_getRequestInfofromMapping {
  my $request = shift;   
  my $requestInfo;

  $requestInfo = $DiagMapping->{'Requests_Responses'}{$request};
  unless(defined $requestInfo)
  {
    GDCOM_set_error("$request not defined in the Diagmapping file!", 20 );
    return;
  }
  return $requestInfo;
}

################################################################################

=head2 GDCOM_evaluate_response_bytes
 
    $RequestInfo=GDCOM_evaluate_response_bytes($Label, $response , $startbyte , $expected_value);

=cut

################################################################################

sub GDCOM_evaluate_response_bytes
{
  my $label = shift;
  my $response = shift;
  my $startbyte = shift;
  my $expectedvalue = shift;
  DCOM_evaluate_response_bytes($label,$response,$startbyte,$expectedvalue);
  return 1;
}

################################################################################

=head2 GDCOM_clear_DTCs

  Function to Clear DTCs

=cut

################################################################################

sub GDCOM_clear_DTCs
{
  DCOM_clear_DTCs();
  return 1;
}

################################################################################

=head2 GDCOM_ecu_reset

  Function to Reset ECU
  
  For Hard or soft reset, $reset_type = DCOM_HardReset or DCOM_SoftReset
  
  For reset through Ubatt, $reset_type = Ubatt
  
  For reset through Ignition On off without sleep, $reset_type = IgnOnOff_WithoutSleep
  
  For reset through Ignition on off with sleep, $reset_type = IgnOnOff_WithSleep  
  
example : GDCOM_ecu_reset($reset_type);  

=cut

################################################################################

sub GDCOM_ecu_reset
{ 
    my $reset_type = shift;
    
    DCOM_ecu_reset($reset_type);
    return 1;
 
}

################################################################################

=head2 GDCOM_set_addressing_mode

  this function sets the addresssing mode of the service to either 'Physical', 'Functional' or  'disposal'.
  
  
example : GDCOM_set_addressing_mode($tcpar_address_mode);  

=cut

################################################################################

sub GDCOM_set_addressing_mode
{ 
    my $address_mode = shift;
    DCOM_w2TestStep("TestStep" , "Set Addressing mode to - $address_mode"); 
    DCOM_set_addressing_mode($address_mode);     
    return 1;
}

################################################################################

=head2 GDCOM_start_CyclicTesterPresent

  send the TesterPresent request continuously.
  input parameters $msg_aref, $msgID,$cycle are optional. If not defined , then they are read from Project Defaults.
  Only one Tester Present message is allowed cyclically.
  use GDCOM_stop_CyclicTesterPresent to stop the cyclically sent TP. 
  If the function is used to send second TP message cyclically, error is thrown.
  
  example : GDCOM_start_CyclicTesterPresent($msg_aref,$msgID,$cycle);  

=cut

################################################################################

sub GDCOM_start_CyclicTesterPresent
{
    my $msg_aref = shift;
    my $msgID = shift;
    my $cycle = shift;

    GDCOM_w2TestStep("TestStep" , "Start Cyclic TesterPresent request transmission");
    if(defined $TP_handle)
    {
        GDCOM_set_error("Cyclic Tester Present is already sent. Please call GDCOM_stop_CyclicTesterPresent();" , 21 );
        return 0;
   }
    $TP_handle =  DCOM_start_CyclicTesterPresent($msg_aref, $msgID,$cycle); 
    return 1;
}

################################################################################

=head2 GDCOM_stop_CyclicTesterPresent

  disable the TesterPresent request automatically. Message handle is handled globally.   
  
example : GDCOM_stop_CyclicTesterPresent();  

=cut

################################################################################

sub GDCOM_stop_CyclicTesterPresent
{  
    unless (defined $TP_handle)
    {
       GDCOM_set_error("cyclic Tester Present not started. Please call GDCOM_start_CyclicTesterPresent" , 21 );
       return;
    }
  GDCOM_w2TestStep("TestStep" , "Stop Cyclic TesterPresent request transmission");
  DCOM_stop_CyclicTesterPresent($TP_handle);
  undef $TP_handle;
  return 1;
}

#####################################################################

=head2 GDCOM_SecurityAccess_Unlock

    GDCOM_SecurityAccess_Unlock ( $SecurityAccessLevel );

    for the specificed SecurityAccessLevel below steps are performed
    Request for Seed
    Calculate the Key (using the seed and the specified Key Calculation algorithm)
    Send the correct Key

Example:

    GDCOM_SecurityAccess_Unlock( 'Level2_20103' );

=cut

#####################################################################

sub GDCOM_SecurityAccess_Unlock {
  my $SecurityAccessLevel = shift;
  my(
     $seed,
     @seed_bytes,
     $function,
     $parameters,
     @key_bytes,
     %label_value,
     $requestInfo,
     $request,
     $response,
     $detected_response,     
     );
  undef $seed;
    
  $seed = GDCOM_SecurityAccess_GetSeed($SecurityAccessLevel); 

  if($main::opt_offline)
  { 
  # for test spec creation this is required
      $request = "REQ_SecurityAccess_".$SecurityAccessLevel."__SendKey";  
      $response = "PR_SecurityAccess_".$SecurityAccessLevel."__SendKey";    
      $detected_response  =  GDCOM_request_general($request, $response);
      return 1;
  }    
   
  if(defined $seed)
  { 
    @seed_bytes = split(/ /,$seed);
    $request = "SecurityAccess_".$SecurityAccessLevel;     
    $requestInfo = $DiagMapping->{'Requests_Responses'}{$request}{'Requests'}{"REQ_".$request."__SendKey"};
    $function = "DCOM_SecurityAccess_KeyAlgo::".$requestInfo->{'Function'};
    $parameters = $requestInfo->{'Parameters'};
    @key_bytes = &{ $function } ( $parameters , @seed_bytes );   # command to calculate the key

    $label_value{'Key'} = join(' ', @key_bytes);
    $request = "REQ_SecurityAccess_".$SecurityAccessLevel."__SendKey";  
    $response = "PR_SecurityAccess_".$SecurityAccessLevel."__SendKey";    
    $detected_response  =  GDCOM_request_general($request, $response, \%label_value);    
  }
  return 1;
}

#####################################################################

=head2 GDCOM_GetAccessToRequest

      GDCOM_GetAccessToRequest($RequestLabel ,$ReqArray,$NO_EVAL_SWITCH);
      Function to get access permissions to execute a request.
      Usually SecurityAccess sometimes it can be some any other request

=cut

#####################################################################

sub GDCOM_GetAccessToRequest
{
  my $RequestLabel = shift;
  my $ReqArray = shift;
  my $NO_EVAL_SWITCH = shift;
  my (
      $request_info,
      @RequestArray,
      $request,
      $response,
      %label_value,
      @request_config,
      $function,
     );
     
   if(defined $RequestLabel)
   {
         $request_info =  GDCOM_getRequestInfofromMapping ($RequestLabel);
       if(defined $request_info->{'Requests'}{"REQ_".$RequestLabel."_GetAccess"})
       {
           @RequestArray = @{$request_info->{'Requests'}{"REQ_".$RequestLabel."_GetAccess"}};
       } #end of if
       else
       {
          DCOM_comment('S', "REQ_".$RequestLabel."_GetAccess is not defined in the DiagMapping file. May be it is optional");
       }
     }
     #if second argument is given do not take from the Diag mapping file
     if(defined $ReqArray)
     {
      @RequestArray = @$ReqArray; 
   }
    for(my $i=0;$i<@RequestArray;$i++)
    {
    $request = $RequestArray[$i];   
    
    # Security access request handling
    # ------------------------
    if( $request=~ /^SecurityAccess/ )
    {
      $request =~ s/SecurityAccess_//;
      GDCOM_SecurityAccess_Unlock($request);
    }
    # Function Calls from DCOM_user_functions.pm
    # ------------------------
    elsif($request=~ /^FUNC_/)
    {
      undef @request_config;
      $request =~ s/FUNC_//;
      @request_config = split(/\|/, $request );
      $function = "DCOM_user_functions::".$request_config[0];
      shift @request_config;

      GDCOM_w2TestStep("TestStep" , "Call user defined function $request");    
      DCOM_w2html("Call user defined function -> '$request' &5", "T" , "Blue");
  
      &{ $function }( @request_config );   # call the function in DCOM_user_functions
    }
    # General Requests with or without arguments
    # ------------------------
    elsif($request=~ /^REQ_/ )
    {  
      undef @request_config;     
      @request_config = split(/\|/, $request);  
      $request = $request_config[0];
      $response = $request;
      $response =~ s/REQ_/PR_/;
      shift @request_config;
      if(defined $request_config[0])
      {
        foreach(my $i = 0; $i< scalar(@request_config); $i++)
        {
          $label_value{$request_config[$i]} = $request_config[$i+1];
          $i++;
        }
      }       
      GDCOM_request_general( $request , $response , \%label_value ,$NO_EVAL_SWITCH);      
    }
    else
    {
      GDCOM_set_error( "$request is not a valid request" , 110 );
    }        
  }#end of for loop
}

################################################################################

=head2 GDCOM_SecurityAccessECULock

     GDCOM_SecurityAccessECULock($NumberOfAttempts,$SecurityAccessLevel,$invalidKey);
     
returns a refernce for the NegetiveResponse defined in the $service service refering to the diagmapping file.     
    
   e.g. GDCOM_SecurityAccessECULock('3','Level02_90866','FF FF FF');
        $countervalue = GDCOM_SecurityAccessECULock('3','Level02_90866','FF FF FF'[,'0103_InvalKeyCount']);

=cut

################################################################################

sub GDCOM_SecurityAccessECULock {
    my $NumberOfAttempts = shift;
    my $SecurityAccessLevel = shift;
    my (
    $request,
    $response,
    $detected_response,
    %label_value,
    $i,
    $requestInfo,
    @key_bytes,
    $function,
    $parameters,
    @seed_bytes,
    $seed,
    $NRCInfo,
    );
    
    GDCOM_w2TestStep("Comment" , "\n Lock the ECU\n");    
      if($main::opt_offline)
  { 
# for test spec creation this is required
      $request = "REQ_SecurityAccess_".$SecurityAccessLevel."__SendKey";  
      $response = "PR_SecurityAccess_".$SecurityAccessLevel."__SendKey";    
      $detected_response  =  GDCOM_request_general($request, $response);
      return 1;
  }    

# Request for Seed
#---------------

  for($i=0;$i<$NumberOfAttempts;$i++)
  {
  $seed = GDCOM_SecurityAccess_GetSeed($SecurityAccessLevel); 

# read InvalidKey Negative Responses from diagmapping file
#---------------   
   $NRCInfo = GDCOM_getNRCfromMapping('SecurityAccess','NR_invalidKey');
   
  if(defined $seed)
  { 
    @seed_bytes = split(/ /,$seed);
    $request = "SecurityAccess_".$SecurityAccessLevel;     
    $requestInfo = $DiagMapping->{'Requests_Responses'}{$request}{'Requests'}{"REQ_".$request."__SendKey"};
    $function = "DCOM_SecurityAccess_KeyAlgo::".$requestInfo->{'Function'};
    $parameters = $requestInfo->{'Parameters'};
    @key_bytes = &{ $function } ( $parameters , @seed_bytes );   # command to calculate the key

    $key_bytes[0] = hex($key_bytes[0])+1;
    $key_bytes[0] = sprintf ("%0X" , $key_bytes[0]);

    $label_value{'Key'} = join(' ', @key_bytes);
    $request = "REQ_SecurityAccess_".$SecurityAccessLevel."__SendKey";  
    $response = "NR_invalidKey";    
    $detected_response  =  GDCOM_request_general($request, $response, \%label_value);    
   }
  }
   GDCOM_comment('M',"ECU is locked");  
  return 1;
}

################################################################################

=head2 GDCOM_read_and_eval_fcm_cu

Reads customer fault memory, compares the contents with given parameters and sets a verdict.
See CD_evaluate_faults for more details about mandatory, optional and disjunction faults.  

example : $Verdict = GDCOM_read_and_eval_fcm_cu($CU_mandatory_faults_aref, [ $optional_faults_aref, $disjunction_faults_aref,  $ReadDTC_subfunction, $dtc_status_mask ] );  

=cut

################################################################################

sub GDCOM_read_and_eval_fcm_cu {
    my $CU_mandatory_faults_aref = shift;
    my $CU_optional_faults_aref = shift;
    my $CU_disjunction_faults_aref = shift;
    my $ReadDTC_subfunction = shift;
    my $dtc_status_mask = shift;
    my $Verdict;

  GDCOM_w2TestStep("Comment" , "\n Read and Evaluate Customer Fault Memory\n");
  DCOM_w2html("Read and Evaluate DTCs\n".join('\n   ',@$CU_mandatory_faults_aref)."&5", "T");
#   if($main::opt_offline){return 1; }
    DCOM_read_and_eval_fcm_cu($CU_mandatory_faults_aref,$CU_optional_faults_aref , $CU_disjunction_faults_aref ,$ReadDTC_subfunction,$dtc_status_mask);  
    return 1;
}


################################################################################

=head2 GDCOM_read_and_eval_DTCStatusBits

  Read and evaluate the DTC Status Bits for a given Fault
  For UDS Standard the DTC Status Bits are
    Bit 0 - testFailed
    Bit 1 - testFailedThisOperationCycle
    Bit 2 - pendingDTC
    Bit 3 - confirmedDTC
    Bit 4 - testNotCompletedSinceLastClear
    Bit 5 - testFailedSinceLastClear
    Bit 6 - testNotCompletedThisOperationCycle
    Bit 7 - warningIndicatorRequested
    
    Example: GDCOM_read_and_eval_DTCStatusBits( $DTCStatusBits_expected  )
    DTCStatusBits_expected = FaultName and the DTC Status Bits -> HASH REF
    dtc_status_mask        = DTC Status mask                   -> SCALAR   
    $DTCStatusBits_expected = { 'WSSFLLineFault' => '0b10010100' , 'CANMsg1Timeout' => '0b00001000' }


=cut

################################################################################


sub GDCOM_read_and_eval_DTCStatusBits
{
  my $DTCStatusBits_expected = shift;
  DCOM_read_and_eval_DTCStatusBits( $DTCStatusBits_expected );
  return 1;
}

################################################################################

=head2 GDCOM_read_and_eval_FaultStatusBits

  Read and Evaluate Fault Status Bits
  The Fault Status bits is specific to product areas
  In PS the Fault Status bits are 
      - current bit
        - active bit
        - disturb bit    
        - filtered bit
        - latched bit
        - stored bit  

=cut

################################################################################


sub GDCOM_read_and_eval_FaultStatusBits
{
  my $FaultStatusBits_expected = shift;
  DCOM_read_and_eval_FaultStatusBits($FaultStatusBits_expected);
  return 1;
}

#####################################################################

=head2 GDCOM_read_and_eval_DTCExtDataRecbyDTCNum

    GDCOM_read_and_eval_DTCExtDataRecbyDTCNum (  );
    Read and evaluate DTC Extended Data Record by DTC Number

=cut

#####################################################################
sub GDCOM_read_and_eval_DTCExtDataRecbyDTCNum
{
  my $DTCExtDataRecbyDTCNum_expected = shift;
  my $fault_name                     = shift;
  my $DTCExtDataRecordNumber         = shift;
  my $mode                           = shift;
  DCOM_read_and_eval_DTCExtDataRecbyDTCNum( $DTCExtDataRecbyDTCNum_expected , $fault_name , $DTCExtDataRecordNumber , $mode );
  return 1;
}

#####################################################################

=head2 GDCOM_CA_Trace_get_ReqResp

    GDCOM_CA_Trace_get_ReqResp ( $AddressingMode, $ReqID, $RespID, $TransportProtocol ,$CANBusNumber);
      $AddressingMode = 'physical' or 'functional'
      When $AddtressingMode is specified then the $ReqID and $RespID will be taken from project defaults
      If any other ReqID/RespID (usecase: RespopnseOnEvent) is required then $AddressingMode should be undef 
      and then required IDs can be given
       
    $TransportProtocol = 'ISOTP' or 'raw'
      Currenlty the function supports only ISOTP protocol.
      When the protocol is specified as raw, then all the message data with specified IDs will be given in the Dataref
    
    $CANBusNumber - 1 or 2 
    $Dataref =>{
    
        'Req_Resp' =>{
                        'Time1' => {
                                      'Request'        => 'REQ1',
                                      'Response'       => [ 'RESP11' , 'RESP12' ],
                                      'ResponseTiming' => [ 'Time11' , 'Time12' ],
                                                          
                                   }
                        'Time2' => {


                                   }
                                   ......        
                     }


        'RequestInfo'    => {
                             'Time1' => {
                                          'Request' => 'REQ1'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                             'Time2' => {
                                          'Request' => 'REQ2'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                            },
                                        
        'ResponseInfo'    => {
                             'Time1' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }
                             'Time2' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }                                          
                                }
    
#                   'Request' => {
#                                   'Time1' => 'REQ1'
#                                   'Time2' => 'REQ2'
#                                   .... 
#                                 }
#                   'Response' => {
#                                   'Time1' => 'RESP1'
#                                   'Time2' => 'RESP2'
#                                   .... 
#                                 }                                
               }  
    

=cut

#####################################################################�

sub GDCOM_CA_Trace_get_ReqResp
{
  my $AddressingMode = shift;
  my $ReqID = shift;
  my $RespID = shift;
  my $TransportProtocol = shift;
  my $CANBusNumber = shift;
  my $Req_Resp_dataref;  
    
  $Req_Resp_dataref = DCOM_CA_Trace_get_ReqResp( $AddressingMode, $ReqID, $RespID, $TransportProtocol ,$CANBusNumber);
  return $Req_Resp_dataref;
}

################################################################################

=head2 GDCOM_CheckRequestIsExistInMapping

    $RequestInfo=GDCOM_CheckRequestIsExistInMapping($Request);
    
    returns 1 if request is present in diagmapping file else return 0
    
   e.g. GDCOM_CheckRequestIsExistInMapping('COMControl_NETTxControl_disableTx_NM'); 

=cut

################################################################################

sub GDCOM_CheckRequestIsExistInMapping{
    my $service = shift;
    my $requestInfo;

    S_set_error( "'GDCOM_CheckRequestIsExistInMapping' function  - not tested\n", 0 ); #warning to say function is not tested        
    
    unless (defined( $service )) {
        S_set_error( "! too less parameters ! SYNTAX: GDCOM_CheckRequestIsExistInMapping ( service )", 110 );
        return 0;
    }
    
    $requestInfo = $DiagMapping->{'Requests_Responses'}{$service};
    
    if(defined $requestInfo){return 1;}
    else {return 0;}
}

#####################################################################

=head2 GDCOM_getRequestLabelValue

    GDCOM_getRequestLabelValue ($Request_label,$Label_data);
   NoTe: very specific to PS.

=cut

#####################################################################�

sub GDCOM_getRequestLabelValue { 
  
  my $Request_label  = shift;
  my $Label_data = shift;
  my $Request_label_short;
  my $Request_label_value ;

           $Request_label_short =$Request_label;  
          if($Request_label =~ /\_\_/ ){
           $Request_label =~ /(\w*)(\_\_)/;
           $Request_label_short = $1;
          }
         $Request_label_short =~ s/(REQ_)//;
          S_w2log (4,"\n Request Label Before  = $Request_label\n");
       my $ParentHash = GDCOM_getRequestInfofromMapping($Request_label_short);
       $Request_label_value = $ParentHash->{'Requests'}{$Request_label}{'Request'};
       S_w2log (4,"\n Request Label before updating  the parameter values  = $Request_label_value\n");
        #Replace the Label name  with the value in the Hash
        if(defined $Label_data){
            foreach my $label (keys %$Label_data){
              next if( $label eq 'Request' );
              $Request_label_value =~ s/$label/$Label_data->{$label}/;
            }#end of foreach   
             S_w2log (4,"\n Request Label ater updating  the parameter values  = $Request_label_value\n");
        } # End of  defined
        
        unless(defined($Request_label_value)){
          S_w2log (4,"\nRequest :$Request_label_short is not defined in the 'Request' section of Diag Mapping file.\n");
          return 0;
         }
     return $Request_label_value;    
  }


################################################################################

=head2 GDCOM_requestlength_manipulation

     GDCOM_requestlength_manipulation($Req_Label,$Label_data,$signed_length);
     
       $Req_Label      -> Request label specified in the diag mapping File               
       $Label_data     -> Hash data to replace the the string in the diag mapping File  
       $signed_length  -> Length to be modified in  the request 
    
    Returns the "Request" value defined in  the Daig mappping File with the length modification
Example:

   $Label_value = GDCOM_requestlength_manipulation( 'SecurityAccess__SeedLevel1',undef,+1); #one byte addition in request
   $Label_value = GDCOM_requestlength_manipulation( 'SecurityAccess__KeyLevel1',$Label_data,1); #one byte deletion in request
    Eg : returns value : 00 A1 00

=cut

################################################################################

sub GDCOM_requestlength_manipulation {
    
  my $Req_Label = shift;
  my $Label_data= shift;
  my $signed_length= shift;
  my $requestdata_original;
  my $requestdatachanged;
  my $index;
  my @request_bytes;
  $requestdata_original = GDCOM_getRequestLabelValue ($Req_Label,$Label_data);
   @request_bytes = split(/ /, $requestdata_original);
        #foreach (@request_bytes){$_ = "0x".$_;}
  if ($signed_length == 0 )   {
         S_w2rep ( "Signed value are defined as zero  so No Length manipuation is done\n" );
  }
  if ($signed_length > 0 )  {
         S_w2rep ( "Signed value are defined as $signed_length (positive) \n" );

         for($index =1 ;$index<=$signed_length;$index ++) {
             push (@request_bytes,"01");
         }
       
  }
  
   if ($signed_length < 0 )  {
         S_w2rep ( "Signed value are defined as $signed_length (Negative) \n" );
         $signed_length=~s/\-//g; # remove the - ve sign 
         for($index =1 ;$index<=$signed_length;$index ++) {
             pop (@request_bytes);
         }
         
  }
         $requestdatachanged = join (" ",@request_bytes);
         S_w2rep ("Requestvalue after Length updation $signed_length value $requestdatachanged \n",'orange' );
         return ($requestdatachanged);

}


################################################################################

=head2 GDCOM_start_CyclicMessage

    $MSG_Handle = GDCOM_start_CyclicMessage ($CycleTime, $AddressingMode, $Req_Label [, $Label_data]);
    returns the message handle of the cyclic message sent.

=cut

################################################################################

sub GDCOM_start_CyclicMessage {
    my $cycleTime      = shift;
    my $addressingMode = shift;
    my $req_Label      = shift;
    my $label_data     = shift;    # Optional

    S_w2rep("GDCOM_start_CyclicMessage ($req_Label,$label_data,$cycleTime, $addressingMode)");
    
    my $requestdata = GDCOM_getRequestLabelValue( $req_Label, $label_data );
    my @request_bytes = split( / /, $requestdata );

    foreach (@request_bytes) { $_ = hex($_); }
    unshift( @request_bytes, scalar(@request_bytes) );

    for ( my $index = $#request_bytes + 1 ; $index < 8 ; $index++ ) {
        push( @request_bytes, 0 );
    }

    my $msgID = S_get_contents_of_hash( [ 'CUSTOMER_DIAGNOSIS', 'RequestID_' . $addressingMode ] );
    unless ( defined $msgID ) {
        S_set_error( "GDCOM_start_CyclicMessage : Entry 'RequestID_'.$addressingMode' for CUSTOMER_DIAGNOSIS not found in ProjectConst. ", 114 );
        return;
    }

    S_w2rep("Transmitting $req_Label with ID : $msgID , for every $cycleTime");
    my $msg_Handle = DCOM_start_CyclicMessage( \@request_bytes, $msgID, $cycleTime );
    return $msg_Handle;
}

################################################################################

=head2 GDCOM_stop_CyclicMessage

    GDCOM_stop_CyclicMessage ($handle);
    $handle - message handle of the cyclic message to be stopped.

=cut

################################################################################

sub GDCOM_stop_CyclicMessage 
{
  my $handle = shift;
  
    unless (defined $handle)
    {
        S_set_error("Too Less Parameters! SYNTAX: GDCOM_stop_CyclicMessage( $handle)" , 110 );
        return;        
    }    
    return DCOM_stop_CyclicMessage($handle);
}

################################################################################

=head2 GDCOM_GenerateInvalidSet

    Generates the Invalid set for RID and LID for IOControl and Routine Control services 

=cut

################################################################################

   
sub GDCOM_GenerateInvalidSet{
    my $Valid_ref = shift ;
    my $LengthOfData = shift;

    S_set_error( "'GDCOM_GenerateInvalidSet' function  - not tested\n", 0 ); #warning to say function is not tested    
    unless (defined( $Valid_ref )) {
        S_set_error( "! too less parameters ! SYNTAX: GDCOM_GenerateInvalidSet ( Valid_ref )", 110 );
        return 0;
    }
    
    unless (defined( $LengthOfData )) {
        S_set_error( "! too less parameters ! SYNTAX: GDCOM_GenerateInvalidSet ( LengthOfData )", 110 );
        return 0;
    }
    
    my @ValidAry= @$Valid_ref;
    my @DecArray;
    my @returnArray;    
    
    foreach (@ValidAry)
    {
        push(@DecArray,hex($_)); 
    }
    
    my @subArray;
    my $lp ;
    
    for ($lp = 0; $lp < (scalar @DecArray);$lp++)
    { 
        my $PlusOne = ($DecArray[$lp] + 1);
        my $MinusOne = ($DecArray[$lp] - 1);
        
        unless(grep { $_ == $MinusOne } @DecArray)
        {
            push( @subArray, $MinusOne);    
        }

        unless(grep { $_ == $PlusOne } @DecArray)
        {
            push( @subArray, $PlusOne);
        }        
    };


    #@subArray = grep { !$_{$_}++ } @subArray;
    
    if ( $LengthOfData <= 2)
    {
        foreach(@subArray)
        {
            unless($_ >= 0xFF)
            {
                push(@returnArray,sprintf("%02X",$_));
            }
        }
    }
    

    if ( $LengthOfData > 2)
    {
        foreach(@subArray)
        {
            unless($_ >= 0xFFFF)
            {
                push(@returnArray,sprintf("%04X",$_));
            }
        }    
    }
        
    return @returnArray;
}

################################################################################

=head2 GDCOM_getSupportedIdentifersfromMapping

    $supported_sub_functions=GDCOM_getSupportedIdentifersfromMapping($service);

returns a refernce for the Subfunctions which are supported in the $service service refering to the diagmapping file.
    
   e.g. GDCOM_getSupportedIdentifersfromMapping('StartSession');    

=cut

################################################################################

sub GDCOM_getSupportedIdentifersfromMapping {
    my $service = shift;
    my $supported_sub_functions;
    S_set_error( "'GDCOM_getSupportedIdentifersfromMapping' function  - not tested\n", 0 ); #warning to say function is not tested    
    unless (defined( $service )) {
        S_set_error( "! too less parameters ! SYNTAX: GDCOM_getSupportedIdentifersfromMapping ( service )", 110 );
        return 0;
    }
    
    $supported_sub_functions = $DiagMapping->{'DIAG_SERVICES'}{$service}{'Supported_IDs'};
    return $supported_sub_functions;
   
}






=head1 Not to be used in test cases

################################################################################
################################################################################
################################################################################

The below APIs are also exported from GENERIC_DCOM module and are listed here for reference, but these APIs should not be used in test cases
because functionality is duplicated (e.g. GDCOM_delay) or because it is CC-AS specific. However some of these APIs are used in generic DCOM tests
that are shared between CC-AS and CC-PS.

################################################################################
################################################################################
################################################################################

=head2 GDCOM_delay

    GDCOM_delay ( $TIME_S [, $COMMENT ] );

Waits for $TIME_S seconds. Depending on the usage of DCOM_start_communication
and DCOM_stop_communication before, TesterPresent messages might be sent during
the delay time.

    $TIME_S     Time to wait in seconds. Values like 0.5 are also allowed.
    $COMMENT    The comment is written to the test report. This field is optional.

Example:

    GDCOM_delay ('5','my comment');

=cut

################################################################################

sub GDCOM_delay {

    my $TIME_S = shift;
    my $COMMENT = shift;

    unless(defined $COMMENT){$COMMENT = "Wait for $TIME_S (sec)"; }
    DCOM_w2html( "$COMMENT &5" , "T"  , 'black' , "Courier" );
    DCOM_w2TestStep("TestStep" , $COMMENT );
    DCOM_delay ($TIME_S, $COMMENT);
     
    return 1;
}

#####################################################################

=head2 GDCOM_comment

    GDCOM_comment ($STYLE , $TEXT);

Writes $TEXT into the test report. Text size is determined by $STYLE.

    $STYLE      Specifies output formatting in the report (font size).
                'L'     large comment, using HTML tag <H2>
                'M'     medium comment, using HTML tag <H3>
                else    normal comment
    $COMMENT    The comment is written to the test report.

Example:

   GDCOM_comment('M', 'my comment');

=cut

################################################################################

sub GDCOM_comment {

    my $STYLE = shift;
    my $TEXT = shift;

    
    DCOM_comment($STYLE, $TEXT);
    
    return 1;

}

################################################################################

=head2 GDCOM_ecu_on

  Function to Switch On ECU

=cut

################################################################################

sub GDCOM_ecu_on
{ 
# Separate Powersupply used - Video area
  DCOM_w2html( "Switch ON ECU (Ubatt = 'U_BATT_DEFAULT', IgnOn, Wait for ECU ready) &5" , "T"  , 'black' , "Courier" );
  GDCOM_w2TestStep("TestStep" , "SwitchOn ECU, Wait till ECU is initialized");
  $Testbench = $LIFT_config::LIFT_Testbench;
  if ( defined $Testbench->{'Devices'}{'POWER_SUPPLY'} )
  {    
    PS_SetVoltage( 'U_BATT_DEFAULT' );
    # Ignition ON ?
  }
  else
  {
#     SC_ecu_on();
      DCOM_ecu_on();
  }
  
  return 1;  
}

################################################################################

=head2 GDCOM_ecu_off

  Function to Switch On ECU

=cut

################################################################################

sub GDCOM_ecu_off
{ 
# Separate Powersupply used - Video area

  DCOM_w2html( "Switch OFF ECU (Ubatt = 0, IgnOff, Wait for ECU off) &5" , "T"  , 'black' , "Courier" );
  GDCOM_w2TestStep("TestStep" , "SwitchOff ECU");

  if ( defined $Testbench->{'Devices'}{'POWER_SUPPLY'} )
  {    
    PS_SetVoltage( 0 );
    #Ignition off?
  }
  else
  {
#     SC_ecu_off();
      DCOM_ecu_off();
  }
  
  return 1;  
}

################################################################################

=head2 GDCOM_wait_for_user

    GDCOM_wait_for_user ( $TEXT );

Pauses test execution and displays $TEXT to the user in a separate window.
The user has the choice between 'yes' and 'no'. 'yes' sets the testcase verdict
to VERDICT_PASS, 'no' sets the testcase verdict to VERDICT_FAIL.

Example:

    GDCOM_wait_for_user ('my text');

=cut

################################################################################

sub GDCOM_wait_for_user {

    my $TEXT = shift;

    DCOM_wait_for_user ($TEXT);
    return 1;
}

################################################################################

=head2 GDCOM_tcpar

    PARTAMETER_VALUE_REF = GDCOM_tcpar ( $PARAMETER_NAME );

Reads the value of a testcase parameter $PARAMETER_NAME and returns a reference to it.

Example:

    GDCOM_tcpar('TIMING_P2max');

=cut

#####################################################################

sub GDCOM_tcpar {

   my $PARAMETER_NAME = shift;
   my $value_ref;
   $value_ref = DCOM_tcpar ( $PARAMETER_NAME );
   return $value_ref;
}

#####################################################################

=head2 GDCOM_tcpar_mandatory

    PARAMETER_VALUE_REF = GDCOM_tcpar_mandatory ( $PARAMETER_NAME );

Reads the value of a mandatory testcase parameter $PARAMETER_NAME and returns a reference to it.
If parameters doesnt exist prints error and returns undef

=cut

#####################################################################

sub GDCOM_tcpar_mandatory {

   my $PARAMETER_NAME = shift;
   my $value_ref;
   $value_ref = DCOM_tcpar ( $PARAMETER_NAME );
   
   unless( defined $value_ref ) {
        DCOM_set_error( "Missing mandatory parameter '$PARAMETER_NAME'" , 110 );
        return 0;
    }
   return $value_ref;
}

#####################################################################

=head2 GDCOM_tcpar_optional

    PARAMETER_VALUE_REF = GDCOM_tcpar_optional ( $PARAMETER_NAME );

Reads the value of a optional testcase parameter $PARAMETER_NAME and returns a reference to it.
If parameters doesnt exists printout error and returns undef

=cut

#####################################################################

sub GDCOM_tcpar_optional {

    my $PARAMETER_NAME = shift;
    
    unless (defined( $PARAMETER_NAME )) {
        DCOM_set_error( "Missing optional parameters '$PARAMETER_NAME' !", 0 );
        return ;
    }

    my $value_ref = GDCOM_tcpar( $PARAMETER_NAME , 'byref' );
       
    unless( defined $value_ref ) {
        DCOM_comment('s' , "Missing optional parameter '$PARAMETER_NAME' !" );
        return ;
    }  
    return $value_ref;
}

#####################################################################

=head2 GDCOM_ignition_on

    Function to switch on Ignition

=cut

#####################################################################

sub GDCOM_ignition_on
{  

  DCOM_w2html( "Switch ON Ignition(KL15) &5" , "T"  , 'black' , "Courier" );
  DCOM_ignition_on();  
  return 1;
}

#####################################################################

=head2 GDCOM_ignition_off

    Function to switch on Ignition

=cut

#####################################################################

sub GDCOM_ignition_off
{  

   DCOM_w2html( "Switch Off Ignition(KL15) &5" , "T"  , 'black' , "Courier" );
   DCOM_ignition_off();   
  return 1;
}

#####################################################################

=head2 GDCOM_SetEeprom

    $success = GDCOM_SetEeprom ( $ADDRESS, $DATASTRING [, $MODE ] ); #setting using directly address

    $success = GDCOM_SetEeprom ( $ADDRESS, $DATASTRING [, $MODE ] );

#if PDM Concept is used
     DIAG_write_EEPROM_Gen9PDM ( $write_PDMLabel, $datastring); --> Basic,Normal
     DIAG_write_EEPROM_Gen9PDM ( $write_PDMLabel, $datastring, $arrayindex); --> Array,Normal
     DIAG_write_EEPROM_Gen9PDM ( $write_PDMLabel, $datastring, "NO_OPTION", $offset, $length); --> Basic,Partial
     DIAG_write_EEPROM_Gen9PDM ( $write_PDMLabel, $datastring, $arrayindex, $offset, $length); -->Array,Partial     

Writes data given in $DATASTRING to EEPROM from start address $ADDRESS onwards in mode $MODE.

    $ADDRESS    : string containing the start address in the EEPROM in hex (e.g. '0x0393')
    $DATASTRING : string containing hex bytes separated by white space (e.g. '12 3A FF')
    $MODE       : 'normal' (default), 'safe', 'buffered'

In 'normal' mode only the bytes given in $DATASTRING are written to EEPROM.
In 'safe' mode additionally a checksum byte and an access byte ('AB') is written to EEPROM.
In 'buffered' mode everything that is written in 'safe' mode is written twice
(data bytes, checksum byte, access byte, data bytes, checksum byte, access byte).
Returns 1 if a positive response is sent by the ECU, otherwise 0

Example:

    GDCOM_SetEeprom('0x0380','01 02 03 04 05 06','safe');

=cut

#####################################################################

sub GDCOM_SetEeprom
{

  my $returnval;

    #DCOM_SetEeprom - should be updated to handle PDM
   $returnval = DCOM_SetEeprom ( @_ );
   

  return $returnval;
}

#####################################################################

=head2 GDCOM_GetEeprom

    $value = GDCOM_GetEeprom ( $ADDRESS, $LENGTH );

Reads $LENGTH bytes data from EEPROM, beginning @ $ADDRESS.

    $ADDRESS    : string containing the start address in the EEPROM in hex (e.g. '0x0393')
    $LENGTH:    : number of bytes that have to be read

Returns the read bytes

Example:

    @BYTES = GDCOM_GetEeprom ( $ADDRESS, $LENGTH);
    @BYTES = GDCOM_GetEeprom ( $read_PDMlabel ); --> Basic,Normal
    @BYTES = GDCOM_GetEeprom ( $read_PDMlabel, $arrayindex); --> Array,Normal
    @BYTES = GDCOM_GetEeprom ( $read_PDMlabel, "NO_OPTION", $offset, $length); --> Basic,Partial
    @BYTES = GDCOM_GetEeprom ( $read_PDMlabel, $arrayindex, $offset, $length); -->Array,Partial

=cut

#####################################################################

sub GDCOM_GetEeprom
{  
  my $returnval;

  $returnval = DCOM_GetEeprom ( @_);
  
  return $returnval;
  
  
}

#####################################################################

=head2 GDCOM_get_environment

    $value = GDCOM_get_environment()

Returns the current test environment used for DCOM tests. Possible return values:

    - 'DNCSIM' = Simulation environment with DNCSIM executable
    - 'TARGET' = Environment with real ECU.

=cut

################################################################################

sub GDCOM_get_environment
{
 
  my $env;
  $env = DCOM_get_environment();
  
  return $env; 
}

#####################################################################

=head2 GDCOM_GetEepromMultipleLocations

    $success = GDCOM_GetEepromMultipleLocations ( $AddressValue_ref ); #setting using directly address

=cut

################################################################################

sub GDCOM_GetEepromMultipleLocations
{
  my $AddressValue_ref = shift;
  my (
       @arguments,
       @options,
       $text,
       $EEPROM_Dataref,
    );
    
  foreach(keys %$AddressValue_ref){
   $text = "$text".$_;
   if( $AddressValue_ref->{$_} ne ""){
      $text = $text."->".$AddressValue_ref->{$_}."\n";
   }
   else{
      $text = $text."\n";
   }
  }
  DCOM_w2html("Read EEPROM vaules - \n $text &5" , 'T' , "Blue");

  foreach my $location(keys %$AddressValue_ref)
  {
    undef @arguments;
    undef @options;
    push(@arguments, $location);
    @options = split(/:/,$AddressValue_ref->{$location});
    push(@arguments,@options);
    $EEPROM_Dataref->{$location} = GDCOM_GetEeprom(@arguments);    
  }
  return $EEPROM_Dataref;
}
#####################################################################

=head2 GDCOM_SetEepromMultipleLocations

    $success = GDCOM_SetEeprom ( $AddressValue_ref ); #setting using directly address

=cut

################################################################################

sub GDCOM_SetEepromMultipleLocations
{
  my $AddressValue_ref = shift;
  my (
       @arguments,
       @options,
       $text,
    );
    
  foreach(keys %$AddressValue_ref){$text = "$text".$_."->".$AddressValue_ref->{$_}."\n";}
  DCOM_w2html("Set EEPROM vaules - \n $text &5" , 'T' , "Blue");

  foreach my $location(keys %$AddressValue_ref)
  {
    undef @arguments;
    undef @options;
    push(@arguments, $location);
    @options = split(/:/,$AddressValue_ref->{$location});
    push(@arguments,@options);
    GDCOM_SetEeprom(@arguments);    
  }
  return 1;
}

#####################################################################

=head2 GDCOM_DelEepromMultipleLocations

    $success = GDCOM_DelEepromMultipleLocations ( $AddressValue_ref ); #setting using directly address

=cut

################################################################################

sub GDCOM_DelEepromMultipleLocations
{
  my $AddressValue_ref = shift;
  my (
       @arguments,
       @options,
       $text,
    );
    
  foreach(keys %$AddressValue_ref){
   $text = "$text".$_;
   if($AddressValue_ref->{$_} ne ""){
      $text = $text."->".$AddressValue_ref->{$_}."\n";
   }
   else{
      $text = $text."\n";
   }
  }
  DCOM_w2html("Delete EEPROM Locations - \n $text &5" , 'T' , "Blue");

  foreach my $location(keys %$AddressValue_ref)
  {
    undef @arguments;
    undef @options;
    push(@arguments, $location);
    @options = split(/:/,$AddressValue_ref->{$location});
    push(@arguments,@options);
    GDCOM_DelEeprom(@arguments);    
  }
  return 1;
}


################################################################################

=head2 GDCOM_request_func

    $response = GDCOM_request_func ( $REQUEST , $EXPECTED_RESPONSE , $MODE , [ $COMMENT ] );

Sends the given request to ECU through functional addressing mode and evaluates the response.

    $REQUEST            Request message to be sent. Hex bytes separated by spaces
                        should be used.
    $EXPECTED_RESPONSE  Expected response. See DCOM_evaluate() for details.
    $MODE               Response evaluation mode. See DCOM_evaluate() for details.
                        'strict'           Length of expected response has to match exactly.
                        'relax'            Only the specified response bytes have to match.
                                           Additional bytes can be sent by the ECU.
                        'quiet'            No ECU response must be sent.
                        'optional strict'  'strict' or 'quiet'
                        'optional relax'   'relax' or 'quiet'
    $COMMENT            The comment is written to the test report. This field is optional.

    Return Value        The ECU response.

Example:

    GDCOM_request_func ('14 FF 00', '', 'quiet', 'my comment');

=cut

################################################################################

sub GDCOM_request_func {

    my $REQUEST = shift;
    my $EXPECTED_RESPONSE = shift;
    my $MODE = shift;
    my $COMMENT = shift;

    my $response;
 
    $response= DCOM_request_func ( $REQUEST , $EXPECTED_RESPONSE , $MODE , [ $COMMENT ] ); 
       
}

#####################################################################

=head2 GDCOM_CA_read_can_signals

    GDCOM_CA_read_can_signals ( @CAN_signals_Ref , $mode);

=cut

#####################################################################

sub GDCOM_CA_read_can_signals {
  my $CAN_signals = shift;
  my $mode = shift;
  my $Signal_value_ref;
  $Signal_value_ref = DCOM_CA_read_can_signals ( $CAN_signals , $mode );
  return $Signal_value_ref;
}

#####################################################################

=head2 GDCOM_CA_write_can_signals

 GDCOM_CA_write_can_signals ( $can_signal_value_hashref [, 'phys|hex'] );

For each CAN signal defined in $can_signal_value_hashref: write the corresponding 
value on CAN. Absolute or relative values are possible (see example). 
If no second parameter is given, then 'phys' is used as default' 

    example for $can_signal_value_hashref :
        $can_signal_value_hashref = {  'sig1' => '1' ,   # sets sig1 = 1
                                       'sig2' => '++1'   # sets sig2 = sig2 + 1
                                       'sig3' => '--1'   # sets sig3 = sig3 - 1
                                    };

=cut

#####################################################################

# before using CAN write or CAN read we need to configure ? 

sub GDCOM_CA_write_can_signals {
    my $can_signal_value_hashref = shift;
    my $mode = shift;
  
    DCOM_CA_write_can_signals ( $can_signal_value_hashref , $mode );
    return 1;

}

#####################################################################

=head2 GDCOM_CA_disable_messages

    GDCOM_CA_disable_messages ( @CAN_messages );

=cut

#####################################################################

sub GDCOM_CA_disable_messages{
  my @CAN_messages = @_ ;
  DCOM_CA_disable_messages ( @CAN_messages );
  return 1;
}

#####################################################################

=head2 GDCOM_CA_enable_messages

    GDCOM_CA_enable_messages ( @CAN_messages );

=cut

#####################################################################

sub GDCOM_CA_enable_messages{
  
  my @CAN_messages = @_ ;
  DCOM_CA_enable_messages ( @CAN_messages );
  return 1;
}

#####################################################################

=head2 GDCOM_CA_trace_start

    GDCOM_CA_trace_start ( );

=cut

#####################################################################

sub GDCOM_CA_trace_start{ 

    #configured before with CA_trace_configure() and
    #started with CA_trace_start()
    DCOM_CA_trace_start( );
    
    return 1;
}

#####################################################################

=head2 GDCOM_CA_trace_stop

    CAN_trace_file_name = GDCOM_CA_trace_stop ( [ $store_file_name ] );
    
Stop CAN trace and store into test documentation with <store_file_name> or default file name
the stored file name will be returned

=cut

#####################################################################

sub GDCOM_CA_trace_stop{

     my $store_file_name = shift;
     my $CA_trace_data_file_name;
     
    #configured before with CA_trace_configure() and
    #started with CA_trace_start()
     $CA_trace_data_file_name = DCOM_CA_trace_stop ( $store_file_name );

   return $CA_trace_data_file_name;   
}

###################################################################

=head2 GDCOM_request_w2html

    GDCOM_request_w2html ( req, exp , det, mode , desc,);


=cut

###################################################################

sub GDCOM_request_w2html{
  my $request = shift;
  my $exp_resp = shift;
  my $det_resp = shift;
  my $mode = shift;
  my $desc = shift;
  DCOM_request_w2html ( $request, $exp_resp , $det_resp, $mode , $desc);
  
  return 1;
}

#####################################################################

=head2 GDCOM_resolve_label_value

    GDCOM_resolve_label_value ( $Label );

Example:

    GDCOM_resolve_label_value();

=cut

#####################################################################�

sub GDCOM_resolve_label_value {
  my $label = shift;
  my $value;
  
  $value = DCOM_resolve_label_value($label);
  return $value;  
}

#####################################################################

=head2 GDCOM_set_error

    GDCOM_set_error ( [ $err_text ] [, $err_code ] );

Writes an error text containing $err_text and $err_code to STDOUT,
standard logfile and HTML test case report.
Sets system state for the execution engine depending on $err_code.

Example:

    GDCOM_set_error();

=cut

#####################################################################�

sub GDCOM_set_error { 
  my $err_text = shift; 
  my $err_code = shift; 
    
  DCOM_set_error(  $err_text  ,  $err_code  );  
  return 1;  
}

################################################################################

=head2 GDCOM_getDID_FixedDataValueFromMapping
 
    $DIDFixedDataValueInfo=GDCOM_getDID_FixedDataValueFromMapping();

returns a refernce for the Request information from the DiagMapping file
    
   e.g. GDCOM_getDID_FixedDataValueFromMapping();    

=cut

################################################################################

sub GDCOM_getDID_FixedDataValueFromMapping {
  my $DIDFixedDataValueInfo = $DiagMapping->{'DID_FixedDataValue'};
  unless(defined $DIDFixedDataValueInfo)
  {
    GDCOM_set_error("'DID_FixedDataValue' not defined in the Diagmapping file!", 20 );
    return;
  }
  return $DIDFixedDataValueInfo;
}

################################################################################

=head2 GDCOM_get_DID_2_EEPROMMapping
 
    $DID_2_EEPROMMapping=GDCOM_get_DID_2_EEPROMMapping();

returns a refernce for the Request information from the DiagMapping file
    
   e.g. GDCOM_getDID_EEPROMDeliveryDataFromMapping();    

=cut

################################################################################

sub GDCOM_get_DID_2_EEPROMMapping {
  my $DID_2_EEPROMMapping = $DiagMapping->{'DID_2_EEPROMMapping'};
  unless(defined $DID_2_EEPROMMapping)
  {
    GDCOM_set_error("'DID_2_EEPROMMapping' not defined in the Diagmapping file!", 20 );
    return;
  }
  return $DID_2_EEPROMMapping;
}

################################################################################

=head2 GDCOM_Variant_Learning

  Function to Variant Learning

=cut

################################################################################

sub GDCOM_Variant_Learning
{
    my $VariantLearning = shift;
    my $Ubatt_Zero;
    my $Ubatt_Default;
    $Ubatt_Zero -> {'Ubatt'}='0';
    $Ubatt_Default ->{'Ubatt'}='13.8';
    if ($VariantLearning eq "one_ign_cycle")
    {
     GDCOM_set_electric_signals($Ubatt_Zero);
     GDCOM_ecu_off();
     GDCOM_delay ('3');
     GDCOM_set_electric_signals($Ubatt_Default);
     GDCOM_ecu_on();
    }
    elsif ($VariantLearning eq "two_ign_cycle")
    {
    # first IGN cycle
    GDCOM_set_electric_signals($Ubatt_Zero);
    GDCOM_ecu_off();
    GDCOM_delay ('3');
    GDCOM_set_electric_signals($Ubatt_Default);     
    GDCOM_ecu_on();
    
    GDCOM_delay ('3');
    
    # Second IGN cycle
    GDCOM_set_electric_signals($Ubatt_Zero);
    GDCOM_ecu_off();
    GDCOM_delay ('3');
    GDCOM_set_electric_signals($Ubatt_Default);       
    GDCOM_ecu_on();
    }
}

################################################################################

=head2 GDCOM_set_electric_signals

  Set Electrical signals to the value specified
    example for $electrical_signal_value_hashref :
        $electrical_signal_value_hashref = {  'sig1' => '1' ,   # sets sig1 = 1
                                       'sig2' => '2'   # sets sig2 = 2
                                       'sig3' => '3'   # sets sig3 = 3
                                    };

=cut

################################################################################

sub GDCOM_set_electric_signals
{
  my $electrical_signal_value_hashref = shift;
  DCOM_set_electric_signals($electrical_signal_value_hashref);
  return 1;
}

################################################################################

=head2 GDCOM_reset_electric_signals

  Reset Electrical signals to the normal value
  GDCOM_reset_electric_signals($electrical_signals_ref)

=cut

################################################################################

sub GDCOM_reset_electric_signals
{
  my $electrical_signals_ref = shift;
  DCOM_reset_electric_signals($electrical_signals_ref);
  return 1;
}
 
#####################################################################

=head2 GDCOM_manipulate_lines

    GDCOM_manipulate_lines($ManipulatioType, $ListofLines_ref , [ $Timeduation] )
    $ManipulatioType - Only allowed types are 
                          'interrupt' 
                          'short'
                          'undo_interrupt'
                          'undo_short'
   $ListofLines_ref - Array of Lines to be manipulated
   $Timeduation - Duration for which Interruption/Short has tobe done.
                  This parameter is not valid for undo_interrupt/undo_short

=cut

#####################################################################

sub GDCOM_manipulate_lines
{
  my $ManipulationType = shift;
  my $ListofLines_ref = shift;
  my $Timeduration = shift;
  
  return ( DCOM_manipulate_lines($ManipulationType, $ListofLines_ref ) );  
}

################################################################################

=head2 GDCOM_SetVehicleSpeed

 function to set the vehicle speed to the defined value.

=cut

################################################################################

sub GDCOM_Set_Vehicle_Speed {
   my $vehicle_speed = shift ;
   
   return 1;    
 }   
 
#####################################################################

=head2 GDCOM_set_target_speed

    GDCOM_set_target_speed ( $SPEED  );

Accelerates or decelerates simulator vehicle to given $SPEED.
See EXT_goto_target_speed for more details.

=cut

#####################################################################

sub GDCOM_set_target_speed {

   my $speed = shift;
   GDCOM_w2TestStep("TestStep" , "Set the Vehicle speed = $speed km/h");
   DCOM_set_target_speed( $speed); 

   return 1;
} 
#####################################################################

=head2 GDCOM_goto_target_speed

    GDCOM_goto_target_speed ( $SPEED  );

Accelerates or decelerates simulator vehicle to given $SPEED.
See EXT_goto_target_speed for more details.

=cut

#####################################################################

sub GDCOM_goto_target_speed {

   my $speed = shift;
   GDCOM_w2TestStep("TestStep" , "Set the Vehicle speed = $speed km/h");
   DCOM_goto_target_speed( $speed); 

   return 1;
} 

#####################################################################

=head2 GDCOM_set_wheel_speeds_kmh

    GDCOM_set_wheel_speeds_kmh (  $SPEED_FL [, $SPEED_FR , $SPEED_RL , $SPEED_RR ] );

=cut

#####################################################################

sub GDCOM_set_wheel_speeds_kmh {

   my @params = @_;
   DCOM_set_wheel_speeds_kmh(@params);
   
   return 1;
}

#####################################################################

=head2 GDCOM_reset_wheel_speeds_kmh

    GDCOM_reset_wheel_speeds_kmh( );

=cut

#####################################################################

sub GDCOM_reset_wheel_speeds_kmh {

   DCOM_reset_wheel_speeds_kmh();
   
   return 1;
}
#####################################################################

=head2 GDCOM_reset_Engine_speed

    GDCOM_reset_Engine_speed 

=cut

#####################################################################

sub GDCOM_reset_Engine_speed {

   GDCOM_w2TestStep("TestStep" , "Reset the Engine speed");
   DCOM_reset_Engine_speed();
   
   return 1;
}

#####################################################################

=head2 GDCOM_set_Engine_speed

    GDCOM_set_Engine_speed 

=cut

#####################################################################

sub GDCOM_set_Engine_speed {

   my $label = shift;
   my $value = shift;
   GDCOM_w2TestStep("TestStep" , "Set the Engine speed = $value km/h");
   DCOM_set_Engine_speed($label,$value);
   
   return 1;
}

################################################################################

=head2 GDCOM_w2TestStep

  Function to write to Test Step
  
example : GDCOM_w2TestStep($Text);  

=cut

################################################################################

sub GDCOM_w2TestStep
{   
    my $TestStepType = shift;
    my $TestStep = shift;  
    my $ExpectedResult = shift;   
    
    DCOM_w2TestStep($TestStepType, $TestStep, $ExpectedResult);
    return 1;
}

################################################################################

=head2 GDCOM_dependent_requests

  this function sets the addresssing mode of the service to either 'Physical' or 'Functional'.
  
example : GDCOM_dependent_requests ( $REQUESTS, $FUNCTION, $ARGUMENT [, $COMMENT, $DELAY ] );

=cut

################################################################################

sub GDCOM_dependent_requests
{ 
my $request = shift;
my $function = shift;
my $Parameters = shift;
my $description = shift;
 
    DCOM_dependent_requests( $request, $function , $Parameters, $description);
     
     return 1;
}

1;

#####################################################################

=head2 GDCOM_LC_set_label

    GDCOM_LC_set_label ( $LABEL , $VALUE );

Sets label $LABEL to value $VALUE on the LabCar.

Example:

    GDCOM_LC_set_label('model_target_speed', 10);

=cut

#####################################################################

sub GDCOM_LC_set_label {
    my  $LABEL=shift;
    my $VALUE= shift;
    DCOM_LC_set_label ( $LABEL , $VALUE );
    GDCOM_delay('3');
}

#####################################################################

=head2 GDCOM_set_Ubatt

    GDCOM_set_Ubatt ( BatteryVoltage );

Set Battery Voltage

=cut

#####################################################################

sub GDCOM_set_Ubatt {

    my $U_batt_given = shift;
    return( DCOM_set_Ubatt($U_batt_given));
}

#####################################################################

=head2 GDCOM_set_verdict

    GDCOM_set_verdict ( verdict );

Set Testcase verdict

=cut

#####################################################################

sub GDCOM_set_verdict {

    my $verdict = shift;
    return( DCOM_set_verdict($verdict));
}

#####################################################################

=head2 GDCOM_reset_speed

    GDCOM_reset_speed ( ); 
 resets the simulator vehicle speed to Zero .

=cut

#####################################################################

sub GDCOM_reset_speed {

   GDCOM_comment('M', " Resetting the vehicle speed to Zero \n ");
#    LC_set_target_speed ( @params );
   DCOM_reset_speed();

   return 1;
}

#####################################################################

=head2 GDCOM_SecurityAccess_GetSeed

    GDCOM_SecurityAccess_GetSeed ( $SecurityAccessLevel );

   for the specificed SecurityAccessLevel below steps are performed
    Request for Seed
    extract the seed value from the response and return it.

Example:

    GDCOM_SecurityAccess_GetSeed( 'Level3_98066' );

=cut

#####################################################################

sub GDCOM_SecurityAccess_GetSeed {
  my $SecurityAccessLevel = shift;
  my(
      $request,
      $response,
      $detected_response,
      @response_bytes,
      $i,
      $seed,
    );
    
  if($main::opt_offline)
  { 
  # for test spec creation this is required
      $request = "REQ_SecurityAccess_".$SecurityAccessLevel."__RequestSeed";  
      $response = "PR_SecurityAccess_".$SecurityAccessLevel."__RequestSeed";
      $detected_response  =  GDCOM_request_general($request, $response);
      return 1;
  }    
    
  unless(defined $SecurityAccessLevel)
  {
    GDCOM_set_error("Missing parameter 'SecurityAccessLevel'!" , 20 );
    return;
  }
  $request = "REQ_SecurityAccess_".$SecurityAccessLevel."__RequestSeed";  
  $response = "PR_SecurityAccess_".$SecurityAccessLevel."__RequestSeed";
  $detected_response  =  GDCOM_request_general($request, $response);
  undef $seed;
  @response_bytes = split(/ /,$detected_response );
  
  if($response_bytes[0] eq "7F")
  {
    return; 
  }  
  for($i=2;$i<scalar(@response_bytes);$i++)
  {
    unless(defined $seed){$seed = $response_bytes[$i];next;}
    $seed = $seed." ".$response_bytes[$i];
  }

  return $seed;
}

#####################################################################

=head2 GDCOM_send_multiple_requests

     GDCOM_send_multiple_requests($RequestList , [ $CommonNRC ])
     $RequestList =  @( "REQ_WriteDatabyID_40_Disable_Flash_Protection|Data|00" , "SecurityAcess_SPS")

=cut

#####################################################################

sub GDCOM_send_multiple_requests
{
  my $RequestList = shift;
  my $CommonNRC = shift;
  my (
      $request_info,
      @RequestArray,
      $request,
      $response,
      %label_value,
      @request_config,
      $function,
     );
     
   @RequestArray = @$RequestList;   
    for(my $i=0;$i<@RequestArray;$i++)
    {
    $request = $RequestArray[$i];   
    
    # Security access request handling
    # ------------------------
    if( $request=~ /^SecurityAccess/ )
    {
      $request =~ s/SecurityAccess_//;
      GDCOM_SecurityAccess_Unlock($request);
    }
    # General Requests with or without arguments
    # ------------------------
    elsif($request=~ /^REQ_/ )
    {  
      undef @request_config;     
      @request_config = split(/\|/, $request);  
      $request = $request_config[0];
      $response = $request;
      $response =~ s/REQ_/PR_/;
      if(defined $CommonNRC){
         $response = $CommonNRC;
      }
      shift @request_config;
      if(defined $request_config[0])
      {
        foreach(my $i = 0; $i< scalar(@request_config); $i++)
        {
          $label_value{$request_config[$i]} = $request_config[$i+1];
          $i++;
        }
      }       
      GDCOM_request_general( $request , $response , \%label_value );         
    }
    else
    {
      GDCOM_set_error( "$request is not a valid request" , 110 );
    }        
  }#end of for loop
}

################################################################################

=head2 GDCOM_CAN_SendMessage

    Sends a CAN message cyclically for the given cycle_time(ms).

Example:
 
    $MSG_handle= GDCOM_CAN_SendMessage($CANrequest, $requestID, $cycle_time [,$comment]);

=cut

################################################################################

sub GDCOM_CAN_SendMessage {

    my $CANrequest_aref=shift;
    my $requestID = shift;
    my $cycle_time = shift;
    my $comment=shift;
    my $MSG_handle;
     
    $MSG_handle = DCOM_CAN_SendMessage( $CANrequest_aref, $requestID, $cycle_time);
#     return $MSG_handle; ### no need of returning the handle unless it is used to stop the message from being sent cyclically
      return 1;
}
################################################################################

=head2 GDCOM_getCANmessagefromCANmapping

     GDCOM_getCANmessagefromCANmapping($message);
     
returns a refernce for the NegetiveResponse defined in the $service service refering to the diagmapping file.     
    
   e.g. $message = GDCOM_getCANmessagefromCANmapping('ESP_21');

=cut

################################################################################

sub GDCOM_getCANmessagefromCANmapping {
  my $message = shift;
  my $CANInfo; #hash ref to get NRC information

  my $CAN_mapping = S_get_contents_of_hash(['Mapping_CAN']);

  unless( $CAN_mapping ) {
     S_set_error( '$Default->{"Mapping_CAN"} is not defined (or) Mapping_CAN.pm file is not included in CFG' , 20 );
     return;
  }

  $CANInfo->{'Cycle'}  = $CAN_mapping->{'CAN_MESSAGES'}{$message}{'CYCLE'};
  return $CANInfo;
}

#####################################################################

=head2 GDCOM_trace_can_get_message_data

    $message_ref = GDCOM_trace_can_get_message_data ( $can_log_file , $can_frame , $can_bus_nbr );

Reads a single frame from a Canalyzer logfile. $can_log_file is the full name of the logfile.
$can_frame is symbolic name or decimal or hexadecimal value of the CAN frame in the logfile.
Returns reference to hash structure:

      $message_ref->{$timestamp}{'DLC'} = DLC;
      $message_ref->{$timestamp}{'DATA'} = raw bytes of message;

=cut

######################################################
sub GDCOM_trace_can_get_message_data
{

   my $can_log_file = shift;
   my $can_message  = shift;
   my $can_bus_nbr = shift;

   my ($msg_cnt, $all_msgs);

   unless (defined( $can_message )) {
     S_set_error( "SYNTAX: GDCOM_trace_can_get_message_data( can_log_file , can_message , can_bus_nbr)", 110 ); return ;
   }

   unless( defined $can_bus_nbr ) {
     $can_bus_nbr = 1;
   }

   return 1 if $main::opt_offline; # just return if running in offline mode

   my $Trace_FH = new FileHandle;
   unless( $Trace_FH->open( $can_log_file ) ) { S_set_error( " Couldnt open CAN Trace '$can_log_file' ", 131 ); return; }

   $msg_cnt = 0;
   S_w2log( 4, " GDCOM_trace_can_get_message_data : Reading CAN frame '$can_message' on Bus-Nbr $can_bus_nbr from $can_log_file)\n" );

   while( <$Trace_FH> ) {
        ## try to match:
        ##      0.0171 1  Bremse_1   Rx   d 8 00 18 00 00 FE FE 00 18
        if( /^
          \s*        # leading spaces
          (\d+\.\d+)    # timestamp
          \s+        # spaces
          $can_bus_nbr     # bus ID must be right !!!
          \s+        # spaces
          $can_message
          x?
          \s+        # spaces
          [TxRq]+      # match Rx or Tx or TxRq
          \s+        # spaces
          d
          \s+        # spaces
          (\d+)      # DLC
          (.+)$      # all Data unil end of line
          /ix )
        {
            $msg_cnt++;
            $all_msgs->{$1}{'DLC'} = $2;
            $all_msgs->{$1}{'DATA'} = $3;
        }
    }
    $Trace_FH->close;

    S_w2log( 4, " GDCOM_trace_can_get_message_data : Found $can_message -> $msg_cnt times\n" );

    return $all_msgs;
}

#####################################################################

=head2 GDCOM_SecurityAccess_GetKey

    GDCOM_SecurityAccess_GetKey ( $Seed ,$SecurityAccessLevel);

Example:

    GDCOM_SecurityAccess_GetKey( '00 22 00 45','Level_20103' );

=cut

#####################################################################

sub GDCOM_SecurityAccess_GetKey {
  my $seed = shift;
  my $SecurityAccessLevel = shift;
  my(
      $request,
      $response,
      $detected_response,
      @response_bytes,
      $Key,
      @seed_bytes,
      $function,
      $parameters,
      @key_bytes,
      %label_value,
      $requestInfo,      
    );
    
        if($main::opt_offline)
        { 
        # for test spec creation this is required
            $request = "REQ_SecurityAccess_".$SecurityAccessLevel."__SendKey";  
            $response = "PR_SecurityAccess_".$SecurityAccessLevel."__SendKey";    
            $detected_response  =  GDCOM_request_general($request, $response);
            return 1;
        }    
          
        unless(defined $seed)
        {
          GDCOM_set_error("Missing parameter 'Seed'!" , 20 );
          return;
        }
        @seed_bytes = split(/ /,$seed);
        $request = "SecurityAccess_".$SecurityAccessLevel;     
        $requestInfo = $DiagMapping->{'Requests_Responses'}{$request}{'Requests'}{"REQ_".$request."__SendKey"};
        $function = "DCOM_SecurityAccess_KeyAlgo::".$requestInfo->{'Function'};
        $parameters = $requestInfo->{'Parameters'};
        @key_bytes = &{ $function } ( $parameters , @seed_bytes );   # command to calculate the key
    
        $Key = join(' ', @key_bytes);
        return $Key;
}

################################################################################

=head2 GDCOM_GetProjSupServicesFromMapping
 
    $ProjSup_services = GDCOM_GetProjSupServicesFromMapping();

returns a refernce for the Request information from the DiagMapping file
    
   e.g. GDCOM_GetProjSupServicesFromMapping();    

=cut

################################################################################

sub GDCOM_GetProjSupServicesFromMapping {

  my $ProjSup_services = $DiagMapping->{'PRJ_SUPPORTED_SERVICES'};
  unless(defined $ProjSup_services)
  {
    GDCOM_set_error("'PRJ_SUPPORTED_SERVICES' not defined in the Diagmapping file!", 20 );
    return;
  }
  return $ProjSup_services;
}

################################################################################

=head2 GDCOM_read_and_eval_fcm_rb

Reads RB fault memory, compares the contents with given parameters and sets a verdict.
See PD_evaluate_faults for more details about mandatory, optional and disjunction faults.  

example : $Verdict = DCOM_read_and_eval_fcm_rb($RB_mandatory_faults_aref, $RB_optional_faults_aref, $RB_disjunction_faults_aref);  

=cut

################################################################################

sub GDCOM_read_and_eval_fcm_rb {
    my $RB_mandatory_faults_aref = shift;
    my $RB_optional_faults_aref = shift;
    my $RB_disjunction_faults_aref = shift;
    my $Verdict;

  GDCOM_w2TestStep("Comment" , "\n Read and Evaluate Bosch Fault Memory\n");
  DCOM_w2html("Read and Evaluate Bosch Fault Memory&5", "T");
  if($main::opt_offline){return 1; }
  $Verdict = DCOM_read_and_eval_fcm_rb($RB_mandatory_faults_aref, $RB_optional_faults_aref, $RB_disjunction_faults_aref); 
  return $Verdict;
}

###################################################################

=head2 GDCOM_wait_ms

    GDCOM_wait_ms ( $WAIT_TIME );

=cut

###################################################################
sub GDCOM_wait_ms {
  my $WAIT_TIME = shift;
  DCOM_wait_ms( $WAIT_TIME );
  return 1;
}

###################################################################

=head2 GDCOM_Timer

    GDCOM_Timer ($timer_name, $timer_action, [$time_value] )
    $timer_action -> set_timer_zero
                  -> wait_ms_until
                  -> read_timer

=cut

###################################################################

sub GDCOM_Timer
{
  my $timer_action = shift;
  my $timer_name = shift;
  my $time_value = shift;
  if(lc($timer_action) eq 'set_timer_zero' )
  {
    DCOM_set_timer_zero($timer_name);
  }
  elsif(lc($timer_action) eq 'wait_ms_until' )
  {
    DCOM_wait_ms_until( $time_value, $timer_name);
  }
  elsif(lc($timer_action) eq 'read_timer' )
  {
    return DCOM_read_timer( $timer_name );    
  } 
  else
  {
    return 0;
  } 
}

#####################################################################

=head2 GDCOM_get_SW_version

    $version = GDCOM_get_SW_version ( );
    returns the ECU SW Version Number

=cut

#####################################################################
sub GDCOM_get_SW_version {
    my( 
         $function,
         $SWVersion,
      );
    
    $function = "DCOM_user_functions::get_SW_version";
    $SWVersion = &{ $function }( );   # command to calculate the key
    return $SWVersion;
}

#####################################################################

=head2 GDCOM_get_FaultValue_from_mapping

    GDCOM_get_FaultValue_from_mapping ( $fault_name , $fault_group);
    $fault_group = 'CU' or 'RB'
    Get the value of the Fault from the Fault Mapping File

=cut

#####################################################################

sub GDCOM_get_FaultValue_from_mapping
{
  my $fault_name = shift;
  my $fault_group = shift;
  return DCOM_get_FaultValue_from_mapping($fault_name , $fault_group);
}


#####################################################################

=head2 GDCOM_read_and_eval_RDBID_Data_phys

    GDCOM_read_and_eval_ResponseData_phys ( $expected_hashref );

Example:

    GDCOM_read_and_eval_RDBID_Data_phys( $expected_hashref );
    example hash reference
    $expected_hashref = {    'sig1' => '10' ,    
                             'sig2' => '20%5' ,
                             'sig3' => '99?5', 
                        };

=cut

#####################################################################�

sub GDCOM_read_and_eval_RDBID_Data_phys
{
  my $expected_hashref = shift;
  my ( $all_data_values, $request, $response ,
       $supported_sub_functions , $supported_sub_functions_reverse,
       $split_words, $all_expected_values_hashref, $DID_label,
     );
  
  $supported_sub_functions= GDCOM_getSupportedSubFunsfromMapping('ReadDatabyID');
  foreach my $key ( keys %$supported_sub_functions) {  
     $supported_sub_functions->{$key} =~ s/\s*//g;   
     $supported_sub_functions_reverse->{$supported_sub_functions->{$key}} = $key;
  }
# Read from all the required DIDs before evaluation
#--------------------  
  foreach my $datalabel(keys %$expected_hashref)
  {
        @$split_words = split(/\_/, $datalabel);   
        $DID_label = $supported_sub_functions_reverse->{@$split_words[0]};
        unless(defined $all_data_values->{$DID_label})
        {
          $request = "REQ_ReadDatabyID_".$DID_label;
          $response = "PR_ReadDatabyID_".$DID_label;
          $all_data_values->{$datalabel} = GDCOM_request_general($request,$response);
        }
        $all_expected_values_hashref->{$DID_label}{$datalabel} = $expected_hashref->{$datalabel};  
  }
  foreach my $datalabel(keys %$all_expected_values_hashref)
  {
    GDCOM_evaluate_phys($all_data_values->{$datalabel}, $all_expected_values_hashref->{$datalabel}, 'ReadDatabyID')
  }
}

#####################################################################

=head2 GDCOM_read_and_eval_RDBID_Data_hex

    GDCOM_read_and_eval_RDBID_Data_hex ( $expected_hashref );

Example:

    GDCOM_read_and_eval_RDBID_Data_hex( $expected_hashref );
    example hash reference
    $expected_hashref = {    'sig1' => '10' ,    
                             'sig2' => '20 30 00' ,
                             'sig3' => '99', 
                        };

=cut

#####################################################################�

sub GDCOM_read_and_eval_RDBID_Data_hex
{
  my $expected_hashref = shift;
  my ( $all_data_values, $request, $response , 
       $supported_sub_functions , $supported_sub_functions_reverse,
       $split_words, $all_expected_values_hashref, $DID_label
     );
  
  $supported_sub_functions= GDCOM_getSupportedSubFunsfromMapping('ReadDatabyID');
  foreach my $key ( keys %$supported_sub_functions) {  
     $supported_sub_functions->{$key} =~ s/\s*//g;   
     $supported_sub_functions_reverse->{$supported_sub_functions->{$key}} = $key;
  }
# Read from all the required DIDs before evaluation
#--------------------  
  foreach my $datalabel(keys %$expected_hashref)
  {
        @$split_words = split(/\_/, $datalabel);   
        $DID_label = $supported_sub_functions_reverse->{@$split_words[0]};
        unless(defined $all_data_values->{$DID_label})
        {
          $request = "REQ_ReadDatabyID_".$DID_label;
          $response = "PR_ReadDatabyID_".$DID_label;
          $all_data_values->{$datalabel} = GDCOM_request_general($request,$response);
        }
        $all_expected_values_hashref->{$DID_label}{$datalabel} = $expected_hashref->{$datalabel};  
  }

  foreach my $datalabel(keys %$all_expected_values_hashref)
  {
    GDCOM_evaluate_hex($all_data_values->{$datalabel}, $all_expected_values_hashref->{$datalabel}, 'ReadDatabyID')
  }
}

#####################################################################

=head2 GDCOM_read_and_eval_ReadService_Data_phys

    GDCOM_read_and_eval_ReadService_Data_phys ( $expected_hashref ,  [ $ReadServiceLabel , $Label_Value ]);

Example:

    GDCOM_read_and_eval_ReadService_Data_phys( $expected_hashref );
    example hash reference
    $expected_hashref = {    'sig1' => '10' ,    
                             'sig2' => '20%5' ,
                             'sig3' => '99?5', 
                        };

=cut

#####################################################################�
sub GDCOM_read_and_eval_ReadService_Data_phys
{
  my $expected_hashref = shift;
  my $ReadServiceLabel = shift;
  my $Label_Value = shift;
  my ( $all_data_values, $request, $response , 
       $supported_sub_functions , $supported_sub_functions_reverse,
       $split_words, $all_expected_values_hashref, $DID_label, $split_words, %label_value,
     );

    unless (defined $expected_hashref)
    {
        S_set_error( "! too less parameters ! SYNTAX: GDCOM_read_and_eval_ReadService_Data_phys( expected_hashref [, ReadServiceLabel, Label_Value])", 110 );
        return 0;
    }
    
    unless(defined $ReadServiceLabel)
    {
        $ReadServiceLabel = "ReadDatabyID";
    }
  $supported_sub_functions= GDCOM_getSupportedSubFunsfromMapping($ReadServiceLabel);
  foreach my $key ( keys %$supported_sub_functions) {  
     $supported_sub_functions->{$key} =~ s/\s*//g;   
     $supported_sub_functions_reverse->{$supported_sub_functions->{$key}} = $key;
  }
# Read from all the required DIDs before evaluation
#--------------------  


  foreach my $datalabel(keys %$expected_hashref)
  {
        @$split_words = split(/\_/, $datalabel);   
        $DID_label = $supported_sub_functions_reverse->{@$split_words[0]};
        unless(defined $all_data_values->{$DID_label})
        {          
          $request = "REQ_".$ReadServiceLabel."_".$DID_label;
          $response = "PR_".$ReadServiceLabel."_".$DID_label;
          
          $all_data_values->{$DID_label} = GDCOM_request_general($request,$response,$Label_Value); 
        }
        $all_expected_values_hashref->{$DID_label}{$datalabel} = $expected_hashref->{$datalabel};  
  }

  foreach my $datalabel(keys %$all_expected_values_hashref)
  {
    GDCOM_evaluate_phys($all_data_values->{$datalabel}, $all_expected_values_hashref->{$datalabel}, $ReadServiceLabel);
  }

}

#####################################################################

=head2 GDCOM_read_and_eval_ReadService_Data_hex

    GDCOM_read_and_eval_ReadService_Data_hex ( $expected_hashref, [ $ReadServiceLabel , $Label_Value ] );

Example:

    GDCOM_read_and_eval_ReadService_Data_hex( $expected_hashref );
    example hash reference
    $expected_hashref = {    'sig1' => '10' ,    
                             'sig2' => '20 30 00' ,
                             'sig3' => '99', 
                        };

=cut

#####################################################################�

sub GDCOM_read_and_eval_ReadService_Data_hex
{
  my $expected_hashref = shift;
  my $ReadServiceLabel = shift;
  my $Label_Value = shift;
  
  my ( $all_data_values, $request, $response , 
       $supported_sub_functions , $supported_sub_functions_reverse,
       $split_words, $all_expected_values_hashref, $DID_label, $split_words
     );
 
    unless (defined $expected_hashref)
    {
        S_set_error( "! too less parameters ! SYNTAX: GDCOM_read_and_eval_ReadService_Data_hex( expected_hashref [, ReadServiceLabel, Label_Value])", 110 );
        return 0
    } 
    
    unless(defined $ReadServiceLabel)
    {
        $ReadServiceLabel = "ReadDatabyID";
    }

  $supported_sub_functions= GDCOM_getSupportedSubFunsfromMapping($ReadServiceLabel);
  foreach my $key ( keys %$supported_sub_functions) {  
     $supported_sub_functions->{$key} =~ s/\s*//g;   
     $supported_sub_functions_reverse->{$supported_sub_functions->{$key}} = $key;
  }
# Read from all the required DIDs before evaluation
#--------------------  
  foreach my $datalabel(keys %$expected_hashref)
  {
        @$split_words = split(/\_/, $datalabel);   
        $DID_label = $supported_sub_functions_reverse->{@$split_words[0]};
        unless(defined $all_data_values->{$DID_label})
        {
          $request = "REQ_".$ReadServiceLabel."_".$DID_label;
          $response = "PR_".$ReadServiceLabel."_".$DID_label;
          $all_data_values->{$DID_label} = GDCOM_request_general($request,$response,$Label_Value);
        }
        $all_expected_values_hashref->{$DID_label}{$datalabel} = $expected_hashref->{$datalabel};  
  }
  foreach my $datalabel(keys %$all_expected_values_hashref)
  {
    GDCOM_evaluate_hex($all_data_values->{$datalabel}, $all_expected_values_hashref->{$datalabel}, $ReadServiceLabel);
  }
}

#####################################################################

=head2 GDCOM_get_allrequests_of_service_fromMapping

    GDCOM_get_allrequests_of_service_fromMapping ( $service_name );
    
    returns the hash with all requests from the service name given

Example:

    GDCOM_get_allrequests_of_service_fromMapping( $service_name );


=cut

#####################################################################�

sub GDCOM_get_allrequests_of_service_fromMapping
{
  my $service_name = shift;
  my (
        $request_resonses_hashref,
        $requests_of_service,
     );
  $request_resonses_hashref =  $DiagMapping->{'Requests_Responses'};
  foreach my $request(keys %$request_resonses_hashref){
    if( $request =~ /^$service_name/ ){
      $requests_of_service->{$request} =  $DiagMapping->{'Requests_Responses'}{$request};      
    }
  }
  return $requests_of_service;
}

#####################################################################

=head2 GDCOM_CA_eval_ReqResp_from_dataref

    GDCOM_CA_eval_ReqResp_from_dataref ( $AddressingMode,  $ReqResp_ref, [ $label_value, $start_time, $end_time]  );
    
    example:
    $ReqResp_ref = %{
                      'REQ_StartSession_ExtendedSession' => 'PR_StartSession_ExtendedSession|'
                    }
    

=cut

#####################################################################�

sub GDCOM_CA_eval_ReqResp_from_dataref
{
   my $AddressingMode = shift;
   my $ReqResp_ref = shift;
   my $label_value = shift;
   
   my $DataRef = GDCOM_CA_Trace_get_ReqResp( $AddressingMode );
   DCOM_eval_ReqResp_from_dataref( $DataRef , $ReqResp_ref , $label_value );
   return 1;
}

#####################################################################

=head2 GDCOM_CA_eval_ResponseTime_from_dataref

    GDCOM_CA_eval_ResponseTime_from_dataref (  $AddressingMode, $RespTime_ref, [ $label_value, $start_time, $end_time]  );
    
    example:
    $RespTime_ref = %{
                      'REQ_StartSession_ExtendedSession'    => "300%5",
                      'REQ_StartSession_ProgrammingSession' => "800%5",
                    }
    

=cut

#####################################################################�

sub GDCOM_CA_eval_ResponseTime_from_dataref
{
   my $AddressingMode = shift;
   my $RespTime_ref = shift;
   my $label_value = shift;
   
   my $DataRef = GDCOM_CA_Trace_get_ReqResp( $AddressingMode );
   DCOM_eval_ResponseTime_from_dataref( $DataRef , $RespTime_ref , $label_value );
   return 1;

}

#####################################################################

=head2 GDCOM_get_ReqResp_from_dataref

    GDCOM_get_ReqResp_from_dataref ( $dataref , $request, [ $label_value, $start_time, $end_time]  );
    

=cut

#####################################################################�

sub GDCOM_get_ReqResp_from_dataref
{
  my $dataref = shift;
  my $request = shift;
  my $label_value = shift;
  my $start_time = shift;
  my $end_time = shift;
  return DCOM_get_ReqResp_from_dataref( $dataref , $request , $label_value , $start_time , $end_time)  ;
}

#####################################################################

=head2 GDCOM_config_labelvalue_of_request

    $label_value_adjusted = GDCOM_config_labelvalue_of_request ( $request, $label_value );
    

=cut

#####################################################################�
sub GDCOM_config_labelvalue_of_request
{
   my $request = shift;
   my $label_value = shift;
   return DCOM_config_labelvalue_of_request( $request , $label_value);
}

#####################################################################

=head2 GDCOM_getReqestResponseFromMapping

    $RequestDetails = GDCOM_labelvalue ( $request, $label_value );
    

=cut

#####################################################################�
sub GDCOM_getReqestResponseFromMapping
{
   my $request_label = shift;
   my $label_value = shift;
   return DCOM_getReqestResponseFromMapping( $request_label , $label_value );
}

#####################################################################

=head2 GDCOM_FR_trace_start

    GDCOM_FR_trace_start (  );
    Note : please refer docu of FR_trace_start().

=cut

#####################################################################
sub GDCOM_FR_trace_start {

   return DCOM_FR_trace_start ( );
}


#####################################################################

=head2 GDCOM_FR_trace_stop

    FlexRay_trace_file_name = GDCOM_FR_trace_stop ( [ $store_file_name ] );
    
Stop FlexRay trace and store into test documentation with <store_file_name> or default file name
the stored file name will be returned

=cut

#####################################################################
sub GDCOM_FR_trace_stop 
{
   my $store_file_name = shift;
   my ( 
         $FR_trace_data_file_name,
         $FR_trace_signals_file_name,
      );
   
   ( $FR_trace_data_file_name , $FR_trace_signals_file_name ) = DCOM_FR_trace_stop ( $store_file_name );
   
   return $FR_trace_signals_file_name if ( $FR_trace_signals_file_name );
   return $FR_trace_data_file_name;
}
#####################################################################

=head2 GDCOM_FR_Trace_get_ReqResp

    GDCOM_FR_Trace_get_ReqResp (  );
    

=cut

#####################################################################�

sub GDCOM_FR_Trace_get_ReqResp
{
  my $AddressingMode = shift;
  my $ReqID = shift;
  my $RespID = shift;
  my $TransportProtocol = shift;
  my $Req_Resp_dataref;

  $Req_Resp_dataref = DCOM_FR_Trace_get_ReqResp( $AddressingMode, $ReqID, $RespID, $TransportProtocol );
  return $Req_Resp_dataref;
}

#####################################################################

=head2 GDCOM_FR_eval_ReqResp_from_dataref

    GDCOM_FR_eval_ReqResp_from_dataref ( $AddressingMode,  $ReqResp_ref, [ $label_value, $start_time, $end_time]  );
    
    example:
    $ReqResp_ref = %{
                      'REQ_StartSession_ExtendedSession' => 'PR_StartSession_ExtendedSession|'
                    }
    

=cut

#####################################################################�

sub GDCOM_FR_eval_ReqResp_from_dataref
{
   my $AddressingMode = shift;
   my $ReqResp_ref = shift;
   my $label_value = shift;
   
   my $DataRef = GDCOM_FR_Trace_get_ReqResp( $AddressingMode );
   DCOM_eval_ReqResp_from_dataref( $DataRef , $ReqResp_ref , $label_value );
   return 1;
}

#####################################################################

=head2 GDCOM_FR_eval_ResponseTime_from_dataref

    GDCOM_FR_eval_ResponseTime_from_dataref (  $AddressingMode, $RespTime_ref, [ $label_value, $start_time, $end_time]  );
    
    example:
    $RespTime_ref = %{
                      'REQ_StartSession_ExtendedSession'    => "300%5",
                      'REQ_StartSession_ProgrammingSession' => "800%5",
                    }
    

=cut

#####################################################################�

sub GDCOM_FR_eval_ResponseTime_from_dataref
{
   my $AddressingMode = shift;
   my $RespTime_ref = shift;
   my $label_value = shift;
   
   my $DataRef = GDCOM_FR_Trace_get_ReqResp( $AddressingMode );
   DCOM_eval_ResponseTime_from_dataref( $DataRef , $RespTime_ref , $label_value );
   return 1;
}

#####################################################################

=head2 GDCOM_w2html

    GDCOM_w2html (  );
    

=cut

#####################################################################�
sub GDCOM_w2html
{
  DCOM_w2html(@_);
  return 1;
}

#####################################################################

=head2 GDCOM_call_user_function

    GDCOM_call_user_function ( @args );
    Function to make calls to functions defined in DCOM_user_functions.pm

=cut

#####################################################################�

sub GDCOM_call_user_function
{
   my  $function = shift;
   $function = "DCOM_user_functions::".$function;
   
   GDCOM_w2TestStep("TestStep" , "Call user defined function $function");    
   DCOM_w2html("Call user defined function -> '$function' &5", "T" , "Blue");
   
   &{ $function }( @_ );   # call the function in DCOM_user_functions
   return 1;    
}

################################################################################

=head2 GDCOM_PD_getNRCfromMapping

     GDCOM_PD_getNRCfromMapping($NRCLabel);
     
returns a refernce for the NegetiveResponse defined in the $service service refering to the diagmapping file.     
    
   e.g. $NRCInfo = GDCOM_getNRCfromMapping('NR_Write_Cell_requestOutOfRange');

=cut

################################################################################

sub GDCOM_PD_getNRCfromMapping {
  my $label = shift;
  my $NRCInfo; #hash ref to get NRC information
  my $service;
  my $NRC_Type;  
  my $NRCLabel= $label ;
  
  my @label_split_array =split(/_/,$label);  
   $NRC_Type = $label_split_array[-1]; # get the last paramter as a NRC value
   S_w2rep ( "NRC_Type = $NRC_Type \n" );
   if($label =~ /NR_(.*?)_$NRC_Type/i) {
        $service= $1;
   }
   else
   {
        S_set_error( "SYNTAX: $NRCLabel not in  the format NR_(.*?)_$NRC_Type ", 114 ); 
   }

    $NRCLabel =~ s/$service\_//i; # Remove the service name from the passing  paramter
    #S_w2log (3, "service = $service \n" );
    #S_w2log (3,"$label = $label \n" ); 
    #S_w2log (3, "NRCLabel = $NRCLabel \n" );
          
  unless( defined $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}){
       S_w2rep ( "$NRCLabel not defined under NEG_Responses in the Diag Mapping nothing done\n",'orange' );
        S_set_error( "SYNTAX: $NRCLabel not defined under NEG_Responses in the Diag Mapping nothing done", 114 ); 
       return 0;  
  }
    
  $NRCInfo->{'Response'} = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Response'};
  $NRCInfo->{'Mode'}  = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Mode'};
  $NRCInfo->{'Desc'}  = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Desc'};
  $NRCInfo->{'DataLength'}  = $DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'DataLength'};
    S_w2log(3, "Response  = $NRCInfo->{'Response'}.\n");
    S_w2log(3, "Mode  = $NRCInfo->{'Mode'}.\n");
    S_w2log(3, "Desc  = $NRCInfo->{'Desc'}.\n");
    S_w2log(3, "DataLength  = $NRCInfo->{'DataLength'}.\n");
   
  return $NRCInfo;
}


####################### GDCOM_getSupportedRIDsInfofromMapping ###################

=head2 GDCOM_getSupportedRIDsInfofromMapping
 
    $RequestInfo=GDCOM_getSupportedRIDsInfofromMapping($Request);

returns a refernce for the Request information from the DiagMapping file
    
   e.g. GDCOM_getSupportedRIDsInfofromMapping('ReadDatabyID_ECUProgrammingInformation');    

=cut

################################################################################

sub GDCOM_getSupportedRIDsInfofromMapping {
    my $request = shift;   
    my $requestInfo;
    
    S_set_error( "'GDCOM_getSupportedRIDsInfofromMapping' function  - not tested\n", 0 ); #warning to say function is not tested    
    
    unless (defined( $request )) {
        S_set_error( "! too less parameters ! SYNTAX: GDCOM_getSupportedRIDsInfofromMapping ( service )", 110 );
        return 0;
    }
    
    $requestInfo = $DiagMapping->{'DIAG_SERVICES'}{$request}{'Supported_RIDs'};
    
    unless(defined $requestInfo)
    {
        GDCOM_set_error("GDCOM_getSupportedRIDsInfofromMapping: $request not defined in the Diagmapping file!", 110 );
        return;
    }

    return $requestInfo;
}


1;