package FuncLib_SPI_SensorSimulation;

use strict;
use warnings;

use LIFT_general;
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_spi_access;
use LIFT_numerics;
use POSIX qw /ceil/;
use List::Util qw[min max];

require Exporter;

our ( $VERSION, $HEADER );

our @ISA = qw(Exporter);

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);
our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );
our @EXPORT    = qw(
  SPISIM_Init
  SPISIM_PrepareCrashData
  SPISIM_UploadCrashData
  SPISIM_TriggerCrash
  SPISIM_Exit
);

my $SPISIM_init_flag = 0;

my $sensor_data_shift_href = {
    'SMA660' => '>> 1',
    'SMA760' => '>> 2',
    'SMA720' => '>> 2',
    'UFSD'   => '>> 3',
    'UFSP'   => '>> 3',
    'PASFD'  => '>> 2',
    'PASFP'  => '>> 2',
    'PASMD'  => '>> 2',
    'PASMP'  => '>> 2',
};

=head1 NAME

FuncLib_SPI_SensorSimulation $Revision :

=head1 SYNOPSIS

    use FuncLib_SPI_SensorSimulation;
    
    #
    # Functions of this module should be called from LIFT_crash_simulation.pm
    #
    #
    # 'Mapping_SPI' must be defined 
    #       according to project in Mapping_SPI_network.pm
    #
    #  Location of Template Mapping: 
    #       g:/MKS/Projects/TurboLIFT/Template/config/Mapping_SPI_network.pm.
    #
    # spi decoder files to be used from :
    #       g:/MKS/Projects/TurboLIFT/Tools/SPIMaid/SPI_decoder_files
    
    SPISIM_Init();
    
    SPISIM_PrepareCrashData($options_href);
    
    SPISIM_UploadCrashData($options_href);
    
    SPISIM_TriggerCrash();
    
    SPISIM_Exit();
    

=head1 DESCRIPTION

    Provides functions for SPI sensor simulation where the Sensor data is manipulated on SPI line.

=cut

=head1 CONFIGURATION

=head2 Testbench Configuration for SPI sensor simulation using SPISIM

    'Devices' => {
        ...
        'Manitoo' => {
                'Connection_Type' => 'COM15',
                    # Supported types 'COM<PORT_NUMBER>', 'USB'
                    # COM<PORT_NUMBER> : COM port detected when connected to TestPC
                    # USB : USB-A to USB-A connector.
                    # Drivers needs to be installed for this : refer link
                    # https://inside-docupedia.bosch.com/confluence/display/MOBIT/Setup+USB+connection+for+mobiTOOL
                    
                'FET_HW_Type' => 'FET_3_Ports' ,
                'FET_PortsSelection' => 1 , 
            }, 
        ...
    },
        
    'Functions' => {
        ...
        ### --- Function Area : Crash_simulation, function groups for crash database access, download to simulators and triggering the simulated crash
        'Crash_simulation' => {
          'crash_database'  =>   'SPI_SensorSimulation',
          'crash_sensors'   =>   'SPI_SensorSimulation',
          'trigger'         =>   'SPI_SensorSimulation',
        },
        ...  
    },

=cut

=head1 Functions

=head2 SPISIM_Init

    SPISIM_Init();
    
Initialises the SPI device configured for dynamic stimulation.

B<Arguments: None>

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub SPISIM_Init {

    my @args = @_;
    return unless S_checkFunctionArguments( 'SPISIM_Init ()', @args );

    if ($SPISIM_init_flag) {
        S_w2log( 3, "SPISIM_Init : SPISIM already initialized! Nothing to do...\n" );
        return 1;
    }

    #STEP Initialise SPI device
    return unless ( SPI_init() );

    $SPISIM_init_flag = 1;

    return 1;

}

=head2 SPISIM_Exit

    SPISIM_Exit();
    
Stops the dynamic stimulation of configured SPI device.

B<Arguments: None>

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub SPISIM_Exit {

    my @args = @_;
    return unless S_checkFunctionArguments( 'SPISIM_Exit ()', @args );

    return unless ( Check_spisim_init() );

    #STEP Initialise SPI device
    return unless ( SPI_stop_manipulation() );

    return 1;

}

=head2 SPISIM_UploadCrashData

    SPISIM_UploadCrashData($options_href);
    
Downloads the crash data into Manitoo.

B<Arguments:>

=over

=item $options_href

    my $options_href = {
                'Node'   => 'SMA760',
                'Command'  => 'RD_SENSOR_DATA_CH1',
                'Signal'     => 'data',
                'CrashData' => [-1,0,0,0,0, ],
            };

=back

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub SPISIM_UploadCrashData {

    my @args = @_;
    return unless S_checkFunctionArguments( 'SPISIM_UploadCrashData ( $options_href )', @args );
    my $options_href = shift @args;

    return unless ( Check_spisim_init() );

    #STEP Download the crash data into manitoo
    my $status = SPI_load_signal_manipulation(
        'Node'      => $options_href->{Node},
        'Command'   => $options_href->{Command},
        'Signal'    => $options_href->{Signal},
        'CrashData' => $options_href->{CrashData},
    );

    return unless ($status);
    S_w2log( 3, "Uploading crash data for '$options_href->{Node}' to manitoo completed", 'green' );
    return 1;

}

=head2 SPISIM_PrepareCrashData

    SPISIM_PrepareCrashData($sensors_data_href, $crashData_href);
    
Prepares the crash data to be loaded into Manitoo.

    -> resamples data to 500 US,
    -> shifts data bits specific to sensor,
    -> filling of SPI data bit positions

Fills 'STIMULATION' section in $crashData_href with crash data in format CRASH_SENSORS_SPI_SensorSimulation.

B<Arguments:>

=over

=item $sensors_data_href

Sensors data containing device name , channel name, crash data and sampling time.

     my $sensors_data_href = {
         <Sensor_Name_1> => {
             {
                'device_name'   => $deviceName, # name must match the CREIS mapping
                'channel_name'  => $channelName, # name must match the CREIS mapping
                'data_aref'     => $data_aref, # crash data
                'sampling_time' => $samplingTime_us, # sampling time in micro seconds.
            };
         }
            .....
            
        <Sensor_Name_n> => {
            {
                'device_name'   => $deviceName, # name must match the CREIS mapping
                'channel_name'  => $channelName, # name must match the CREIS mapping
                'data_aref'     => $data_aref, # crash data
                'sampling_time' => $samplingTime_us, # sampling time in micro seconds.
            };
         }
     }
            
=item $crashData_href

   crash data href returned from function 'CSI_GetCrashDataFromMDS'.

=back

B<Return Value:>

1 on Success and $crashData_href filled with SPISIM data
 
'undef' on failure.

=cut

sub SPISIM_PrepareCrashData {

    my @args = @_;
    return unless S_checkFunctionArguments( 'SPISIM_PrepareCrashData ( $sensors_data_href, $crashData_href )', @args );
    my $sensors_data_href = shift @args;
    my $crashData_href    = shift @args;

    return unless ( Check_spisim_init() );

    my $spisim_crash_data_href = {};
    foreach my $sensorName ( keys %{$sensors_data_href} ) {

        #STEP collect spi details cs, channel name, spi command, resolution in lsb/g
        my $check_crash_data_aref = $sensors_data_href->{$sensorName}{data_aref};
        my $number_of_matches = grep { $_ != 0 } @$check_crash_data_aref;
        if ( $number_of_matches > 15 ) {    # filter out invalid data, only Fill channels which has crash data
            $spisim_crash_data_href->{$sensorName} = Fill_spi_details( $sensors_data_href->{$sensorName} );
            return unless ( $spisim_crash_data_href->{$sensorName} );
        }
    }

    my @check_crash_data_size;
    foreach my $sensorName ( keys %{$spisim_crash_data_href} ) {
        my $size = @{ $spisim_crash_data_href->{$sensorName}{spi_data_aref} };
        push( @check_crash_data_size, $size );
    }

    my $min = ( min @check_crash_data_size ) - 1;    # array index starts with 0 hence '-1'

    # set all channels data size to lowest channel size, as manitoo can process only if all channels are of same size
    map { $#{ $spisim_crash_data_href->{$_}{spi_data_aref} } = $min } keys %{$spisim_crash_data_href};

    $crashData_href->{'STIMULATION'}{'CRASH_SENSORS_SPI_SensorSimulation'} = $spisim_crash_data_href;
    return 1;
}

=head2 SPI_TriggerCrash

    SPI_TriggerCrash();
    
Starts the crash simulation on the SPI device configured.

B<Arguments:None>

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub SPISIM_TriggerCrash {

    my @args = @_;
    return unless S_checkFunctionArguments( 'SPISIM_TriggerCrash ()', @args );

    return unless ( Check_spisim_init() );

    return unless ( SPI_start_manipulation() );

    return 1;

}

sub Init_SPI_SensorSimulation {

    #STEP Initialise SPI device
    return unless ( SPI_init() );

    return 1;
}

=head2 Fill_spi_details

    Fill_spi_details($options_href);
    
Fills the spi details to be downloaded to Manitoo.

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub Fill_spi_details {

    my @args = @_;
    return unless S_checkFunctionArguments( 'Fill_spi_details ( $options_href )', @args );

    my $options_href = shift @args;

    my $spi_mapping_details_href = S_get_contents_of_hash( ['Mapping_SPI'] );
    my $deviceName               = $options_href->{'device_name'};
    my $channelName              = $options_href->{'channel_name'};
    my $data_aref                = $options_href->{'data_aref'};
    my $samplingTime_us          = $options_href->{'sampling_time'};

    unless ( grep { $_ eq $deviceName } keys %{$spi_mapping_details_href} ) {
        S_set_error( "SPISIM_UploadCrashData: Device name '$deviceName' not present in Mapping_SPI", 109 );
        return;
    }

    my $spi_details_href = {};

    unless ( $spi_mapping_details_href->{$deviceName}{Channels}{$channelName} ) {
        S_set_error( "Fill_spi_details: Channel name '$channelName' not found for device : $deviceName ", 109 );
        return;
    }

    #STEP fill CS, sampling time, resolution, spi_command
    $spi_details_href->{chipSelect} = $spi_mapping_details_href->{$deviceName}{CS_Pin};
    $spi_details_href->{spi_cmd}    = $spi_mapping_details_href->{$deviceName}{Channels}{$channelName}{SPI_COMMAND};
    my @spi_cmd = split( /::/, $spi_details_href->{spi_cmd} );
    $spi_details_href->{spi_signal} = $spi_cmd[-1];
    $spi_details_href->{spi_cmd}    = $spi_cmd[0];
    $spi_details_href->{node}       = $deviceName;

    $spi_details_href->{resoLSBPerG}        = $spi_mapping_details_href->{$deviceName}{Channels}{$channelName}{RESOLUTION_G_PER_LSB};
    $spi_details_href->{spi_data_width}     = $spi_mapping_details_href->{$deviceName}{Channels}{$channelName}{COMPLETE_DATA_WIDTH_IN_BITS};
    $spi_details_href->{spi_data_start_pos} = $spi_mapping_details_href->{$deviceName}{Channels}{$channelName}{ACTUAL_DATA_BIT_START_POS};
    $spi_details_href->{spi_data_end_pos}   = $spi_mapping_details_href->{$deviceName}{Channels}{$channelName}{ACTUAL_DATA_BIT_END_POS};

    # convert data samples to sampling time of 500 us
    $spi_details_href->{spi_data_aref} = Convert_sample_time( $samplingTime_us, $data_aref );

    # convert LSB/g
    return unless ( Convert_To_Spi_Data($spi_details_href) );

    return $spi_details_href;

}

=head2 Convert_sample_time

    Convert_sample_time($samplingTime_us, $data_aref);
    
Converts the sampling time of crash data to 500us which is required for Manitoo.

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub Convert_sample_time {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Convert_sample_time ( $samplingTime_us, $data_aref )', @args );

    my $samplingTime_us = shift @args;
    my $data_aref       = shift @args;

    my $resampled_href = NUM_ResampleData(
        {
            'dataIn_aref' => $data_aref,
            'dtIn_sec'    => $samplingTime_us / 1000000,
            'dtOut_sec'   => 0.0005,                       # 500us
        }
    );

    if ( $resampled_href->{status} >= 0 ) {
        return $resampled_href->{dataOutValues_aref};
    }
    else {
        return;
    }

}

=head2 Convert_To_Spi_Data

    Convert_To_Spi_Data($samplingTime_us, $data_aref);
    
Converts the crash data to sensor data bit field in MISO response.

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub Convert_To_Spi_Data {
    my @args = @_;

    return unless S_checkFunctionArguments( 'Convert_To_Spi_Data ( $spi_details_href )', @args );

    my $spi_details_href = shift @args;

    my $data_aref = [];

    foreach my $dataVal ( @{ $spi_details_href->{spi_data_aref} } ) {

        $dataVal = Fill_data_position( $spi_details_href, $dataVal );
        return unless ($dataVal);
        push( @$data_aref, $dataVal );
    }
    $spi_details_href->{spi_data_aref} = $data_aref;
    return $spi_details_href;
}

=head2 Fill_data_position

    Fill_data_position($spi_details_href, $dataVal);
    
Fills the data bit positions of the sensor based on the data length of the sensor SPI command.

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub Fill_data_position {

    my @args = @_;

    return unless S_checkFunctionArguments( 'Fill_data_position ( $spi_details_href, $dataVal )', @args );
    my $spi_details_href = shift @args;
    my $dataVal          = shift @args;

    my @result_arr    = ();
    my $neg_data_flag = 0;
    my $data_in_g     = $dataVal;

    # set negative data flag
    $neg_data_flag = 1 if ( $dataVal != abs $dataVal );

    if ( exists $sensor_data_shift_href->{ $spi_details_href->{node} } ) {
        $dataVal = ( eval $dataVal . $sensor_data_shift_href->{ $spi_details_href->{node} } );
    }

    my $actual_data_width   = ( $spi_details_href->{spi_data_end_pos} - $spi_details_href->{spi_data_start_pos} ) + 1;
    my $complete_data_width = $spi_details_href->{spi_data_width};
    my $data_width_in_hex   = ceil( $actual_data_width / 4 );

    # Convert to binary and also hex for filling the the data into actual bit positions
    my @bindata = split( //, sprintf( "%0" . $actual_data_width . "B", $dataVal ) );
    $dataVal = sprintf( "%X", oct( "0b" . join( '', @bindata ) ) );

    # extract only the required actual data in case of negative data values, since the hex data will be of 32 bits
    if ($neg_data_flag) {
        $dataVal = substr( $dataVal, -$data_width_in_hex );
    }

    my $data_string = '';
    @bindata = reverse split( //, sprintf( "%B", hex $dataVal ) );

    # fill the data into actual bit positions
    foreach my $index ( 0 .. ( $complete_data_width - 1 ) ) {

        if ( $index >= ( $spi_details_href->{spi_data_start_pos} ) and $index <= ( $spi_details_href->{spi_data_end_pos} ) ) {
            $data_string = shift @bindata // 0;
            unshift @result_arr, $data_string;
        }
        else {
            unshift @result_arr, 0;    # fill 0's if it is not actual data bit position

        }
    }

    @bindata = () if ($neg_data_flag);

    # no data bits should be left after filling into complete data bit positions.
    if (@bindata) {
        S_set_error( "Fill_data_position: value '$data_in_g' exceeds the spi data range for node $spi_details_href->{node} and command $spi_details_href->{spi_cmd}. Check the data start and end position in Mapping_SPI_network.pm", 109 );
        return;
    }

    # convert the data to 4 nibbles in hex in order to download the crash data to manitoo
    return sprintf( "%04X", oct( "0b" . join( "", @result_arr ) ) );
}

sub Check_spisim_init {
    unless ($SPISIM_init_flag) {
        S_set_error( "Check_spisim_init: SPISIM not initialised call SPISIM_init() to initialise!", 120 );
        return;
    }
    return 1;
}

1;
