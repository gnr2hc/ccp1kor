package  DCOM_FaultMonitoring;

use vars qw( @ISA @EXPORT);
use Exporter;
BEGIN {	
	our @ISA = qw(Exporter);
	our @EXPORT = qw(

              FaultMonitoring_StartSession
              FaultMonitoring_ReadCommonTCPar
              FaultMonitoring_CreateFaults
              FaultMonitoring_ResetFaults
              FaultMonitoring_GetunlearnCounter
              FaultMonitoring_EvaluateFaults
              FaultMonitoring_EvaluateFaultStatus
              FaultMonitoring_Evaluate_ExtDataRecbyDTCNum
              FaultMonitoring_ReadandEvalDTC
              FaultMonitoring_ReadandEvalDTCStatusBits
              FaultMonitoring_ReadandEvalFaultStatusBits
              FaultMonitoring_ReadandEvalExtDataRecbyDTCNum
              FaultMonitoring_ReadPDSporadicCounter
              FaultMonitoring_ECUReset
              FaultMonitoring_ECU_reset_times
              FaultMonitoring_SetFaultPreconditions
              FaultMonitoring_ResetFaultPreconditions
              FaultMonitoring_StoringFaultData
              FaultMonitoring_InternalFaultWithoutIdleMode
              FaultMonitoring_ResetinternalFaultPreconditions
              FaultMonitoring_CreateCrash
              FaultMonitoring_CreateInternalFaults
              FaultMonitoring_ReadCrashReocrder
              FaultMonitoring_CustomerPriority
              FaultMonitoring_CreateAdaptationfault
              FaultMonitoring_UndoAdaptationfault
              FaultMonitoring_dtclist
              Faultmonitoring_checkDTC
              FaultMonitoring_FaultCheck
              FaultMonitoring_File_to_other
              );
}    
          
use GENERIC_DCOM;
use LIFT_DCOM;
use DCOM_user_functions;
use LIFT_general;
use LIFT_PD;
use LIFT_CD;
use LIFT_can_access;
use LIFT_CANoe;
use INCLUDES_Project;

my ( 
     $TCPAR,
     $detected_CAN_signals_old,
   );

#-------------------------------------------------------------------------------
# ReadCommonTCPar
#-------------------------------------------------------------------------------
sub FaultMonitoring_ReadCommonTCPar
{
  undef $TCPAR;

# General parameters
#-------------
  $TCPAR->{'purpose'}              = GDCOM_tcpar_optional('purpose');
  $TCPAR->{'session'}              = GDCOM_tcpar_optional('session');  
  $TCPAR->{'address_mode'}         = GDCOM_tcpar_optional('address_mode');    
  $TCPAR->{'DTCStatusMask'}        = GDCOM_tcpar_optional('DTCStatusMask');                 
  $TCPAR->{'ExtDataRecNum'}        = GDCOM_tcpar_optional('ExtDataRecNum');                 
  $TCPAR->{'ECUReset'}             = GDCOM_tcpar_optional('ECUReset');

# Fault Creation parameters
#-------------
  $TCPAR->{'interrupt_lines'}      = GDCOM_tcpar_optional('interrupt_lines');               
  $TCPAR->{'short_lines'}          = GDCOM_tcpar_optional('short_lines');               
  $TCPAR->{'disable_CAN_messages'} = GDCOM_tcpar_optional('disable_CAN_messages');               
  $TCPAR->{'set_can_signals_phys'} = GDCOM_tcpar_optional('set_can_signals_phys');
  $TCPAR->{'set_can_signals_hex'}  = GDCOM_tcpar_optional('set_can_signals_hex');
# Fault Creation parameters for second faultlist
#-------------
  $TCPAR->{'interrupt_lines_2'}      = GDCOM_tcpar_optional('interrupt_lines_2');               
  $TCPAR->{'short_lines_2'}          = GDCOM_tcpar_optional('short_lines_2');               
  $TCPAR->{'disable_CAN_messages_2'} = GDCOM_tcpar_optional('disable_CAN_messages_2');               
  $TCPAR->{'set_can_signals_phys_2'} = GDCOM_tcpar_optional('set_can_signals_phys_2');
  $TCPAR->{'set_can_signals_hex_2'}  = GDCOM_tcpar_optional('set_can_signals_hex_2');  


# Fault precondition parameters
#-------------
  $TCPAR->{'preset_electric_signals_1'} = GDCOM_tcpar_optional('preset_electric_signals_1');
  $TCPAR->{'preset_can_signals_phys_1'} = GDCOM_tcpar_optional('preset_can_signals_phys_1');
  $TCPAR->{'preset_can_signals_hex_1'}  = GDCOM_tcpar_optional('preset_can_signals_hex_1');
  $TCPAR->{'preset_function_calls_1'}   = GDCOM_tcpar_optional('preset_function_calls_1');

  $TCPAR->{'preset_electric_signals_2'} = GDCOM_tcpar_optional('preset_electric_signals_2');
  $TCPAR->{'preset_can_signals_phys_2'} = GDCOM_tcpar_optional('preset_can_signals_phys_2');
  $TCPAR->{'preset_can_signals_hex_2'}  = GDCOM_tcpar_optional('preset_can_signals_hex_2');
  $TCPAR->{'preset_function_calls_2'}   = GDCOM_tcpar_optional('preset_function_calls_2');

# Evaluation Parameters
#-------------
  $TCPAR->{'FINIT_CU_faults_expected'}       = GDCOM_tcpar_optional('FINIT_CU_faults_expected');
  $TCPAR->{'FINIT_RB_faults_expected'}       = GDCOM_tcpar_optional('FINIT_RB_faults_expected');
  $TCPAR->{'FINIT_DTCStatusBits_expected'}   = GDCOM_tcpar_optional('FINIT_DTCStatusBits_expected');
  $TCPAR->{'FINIT_FaultStatusBits_expected'} = GDCOM_tcpar_optional('FINIT_FaultStatusBits_expected');

  $TCPAR->{'FACTIVE_duration'}                        = GDCOM_tcpar_optional('FACTIVE_duration');
  $TCPAR->{'FACTIVE_CU_faults_expected'}              = GDCOM_tcpar_optional('FACTIVE_CU_faults_expected');
  
  S_w2log(1, $TCPAR->{'FACTIVE_CU_faults_expected'} . "");
  
  $TCPAR->{'FACTIVE_RB_faults_expected'}              = GDCOM_tcpar_optional('FACTIVE_RB_faults_expected');
  $TCPAR->{'FACTIVE_DTCStatusBits_expected'}          = GDCOM_tcpar_optional('FACTIVE_DTCStatusBits_expected');
  $TCPAR->{'FACTIVE_FaultStatusBits_expectesd'}        = GDCOM_tcpar_optional('FACTIVE_FaultStatusBits_expected');
  $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_phys'}= GDCOM_tcpar_optional('FACTIVE_ExtDataRecbyDTCNum_expected_phys');
  $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_hex'} = GDCOM_tcpar_optional('FACTIVE_ExtDataRecbyDTCNum_expected_hex');

  $TCPAR->{'FRESET_duration'}                         = GDCOM_tcpar_optional('FRESET_duration');
  $TCPAR->{'FRESET_CU_faults_expected'}               = GDCOM_tcpar_optional('FRESET_CU_faults_expected');
  $TCPAR->{'FRESET_RB_faults_expected'}               = GDCOM_tcpar_optional('FRESET_RB_faults_expected');
  $TCPAR->{'FRESET_DTCStatusBits_expected'}           = GDCOM_tcpar_optional('FRESET_DTCStatusBits_expected');
  $TCPAR->{'FRESET_FaultStatusBits_expected'}         = GDCOM_tcpar_optional('FRESET_FaultStatusBits_expected');
  $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_phys'} = GDCOM_tcpar_optional('FRESET_ExtDataRecbyDTCNum_expected_phys');
  $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_hex'}  = GDCOM_tcpar_optional('FRESET_ExtDataRecbyDTCNum_expected_hex');

  $TCPAR->{'FHISTORY_CU_faults_expected'}               = GDCOM_tcpar_optional('FHISTORY_CU_faults_expected');
  $TCPAR->{'FHISTORY_DTCStatusBits_expected'}           = GDCOM_tcpar_optional('FHISTORY_DTCStatusBits_expected');
  $TCPAR->{'FHISTORY_FaultStatusBits_expected'}         = GDCOM_tcpar_optional('FHISTORY_FaultStatusBits_expected');
  $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_phys'} = GDCOM_tcpar_optional('FHISTORY_ExtDataRecbyDTCNum_expected_phys');
  $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_hex'}  = GDCOM_tcpar_optional('FHISTORY_ExtDataRecbyDTCNum_expected_hex');

  $TCPAR->{'FNOTACTIVE_CU_faults_expected'}               = GDCOM_tcpar_optional('FNOTACTIVE_CU_faults_expected');
  $TCPAR->{'FNOTACTIVE_DTCStatusBits_expected'}           = GDCOM_tcpar_optional('FNOTACTIVE_DTCStatusBits_expected');
  $TCPAR->{'FNOTACTIVE_FaultStatusBits_expected'}         = GDCOM_tcpar_optional('FNOTACTIVE_DTCStatusBits_expected');
  $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys'} = GDCOM_tcpar_optional('FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys');
  $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex'}  = GDCOM_tcpar_optional('FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex');

  $TCPAR->{'FACTIVE_STORED_duration'}                           = GDCOM_tcpar_optional('FACTIVE_STORED_duration');
  $TCPAR->{'FACTIVE_STORED_CU_faults_expected'}                 = GDCOM_tcpar_optional('FACTIVE_STORED_CU_faults_expected');
  $TCPAR->{'FACTIVE_STORED_RB_faults_expected'}                 = GDCOM_tcpar_optional('FACTIVE_STORED_RB_faults_expected');
  $TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected'}             = GDCOM_tcpar_optional('FACTIVE_STORED_DTCStatusBits_expected');
  $TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected'}           = GDCOM_tcpar_optional('FACTIVE_STORED_FaultStatusBits_expected');
  $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys'}   = GDCOM_tcpar_optional('FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys');
  $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex'}    = GDCOM_tcpar_optional('FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex');

  $TCPAR->{'FACTIVE_NOT_STORED_duration'}                        = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_duration');
  $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected'}              = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_CU_faults_expected');
  $TCPAR->{'FACTIVE_NOT_STORED_RB_faults_expected'}              = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_RB_faults_expected');
  $TCPAR->{'FACTIVE_NOT_STORED_DTCStatusBits_expected'}          = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_DTCStatusBits_expected');
  $TCPAR->{'FACTIVE_NOT_STORED_FaultStatusBits_expected'}        = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_FaultStatusBits_expected');
  $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys'}= GDCOM_tcpar_optional('FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys');
  $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex'} = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex');
# Evaluation Parameters for faultlist 2
#-------------
  $TCPAR->{'FINIT_CU_faults_expected_2'}       = GDCOM_tcpar_optional('FINIT_CU_faults_expected_2');
  $TCPAR->{'FINIT_RB_faults_expected_2'}       = GDCOM_tcpar_optional('FINIT_RB_faults_expected_2');
  $TCPAR->{'FINIT_DTCStatusBits_expected_2'}   = GDCOM_tcpar_optional('FINIT_DTCStatusBits_expected_2');
  $TCPAR->{'FINIT_FaultStatusBits_expected_2'} = GDCOM_tcpar_optional('FINIT_FaultStatusBits_expected_2');

  $TCPAR->{'FACTIVE_duration_2'}                        = GDCOM_tcpar_optional('FACTIVE_duration_2');
  $TCPAR->{'FACTIVE_CU_faults_expected_2'}              = GDCOM_tcpar_optional('FACTIVE_CU_faults_expected_2');
  
  S_w2log(1, $TCPAR->{'FACTIVE_CU_faults_expected_2'} . "");
  
  $TCPAR->{'FACTIVE_RB_faults_expected_2'}              = GDCOM_tcpar_optional('FACTIVE_RB_faults_expected_2');
  $TCPAR->{'FACTIVE_DTCStatusBits_expected_2'}          = GDCOM_tcpar_optional('FACTIVE_DTCStatusBits_expected_2');
  $TCPAR->{'FACTIVE_FaultStatusBits_expectesd_2'}        = GDCOM_tcpar_optional('FACTIVE_FaultStatusBits_expected_2');
  $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_phys_2'}= GDCOM_tcpar_optional('FACTIVE_ExtDataRecbyDTCNum_expected_phys_2');
  $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_hex_2'} = GDCOM_tcpar_optional('FACTIVE_ExtDataRecbyDTCNum_expected_hex_2');

  $TCPAR->{'FRESET_duration_2'}                         = GDCOM_tcpar_optional('FRESET_duration_2');
  $TCPAR->{'FRESET_CU_faults_expected_2'}               = GDCOM_tcpar_optional('FRESET_CU_faults_expected_2');
  $TCPAR->{'FRESET_RB_faults_expected_2'}               = GDCOM_tcpar_optional('FRESET_RB_faults_expected_2');
  $TCPAR->{'FRESET_DTCStatusBits_expected_2'}           = GDCOM_tcpar_optional('FRESET_DTCStatusBits_expected_2');
  $TCPAR->{'FRESET_FaultStatusBits_expected_2'}         = GDCOM_tcpar_optional('FRESET_FaultStatusBits_expected_2');
  $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_phys_2'} = GDCOM_tcpar_optional('FRESET_ExtDataRecbyDTCNum_expected_phys_2');
  $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_hex_2'}  = GDCOM_tcpar_optional('FRESET_ExtDataRecbyDTCNum_expected_hex_2');

  $TCPAR->{'FHISTORY_CU_faults_expected_2'}               = GDCOM_tcpar_optional('FHISTORY_CU_faults_expected_2');
  $TCPAR->{'FHISTORY_DTCStatusBits_expected_2'}           = GDCOM_tcpar_optional('FHISTORY_DTCStatusBits_expected_2');
  $TCPAR->{'FHISTORY_FaultStatusBits_expected_2'}         = GDCOM_tcpar_optional('FHISTORY_FaultStatusBits_expected_2');
  $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_phys_2'} = GDCOM_tcpar_optional('FHISTORY_ExtDataRecbyDTCNum_expected_phys_2');
  $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_hex_2'}  = GDCOM_tcpar_optional('FHISTORY_ExtDataRecbyDTCNum_expected_hex_2');

  $TCPAR->{'FNOTACTIVE_CU_faults_expected_2'}               = GDCOM_tcpar_optional('FNOTACTIVE_CU_faults_expected_2');
  $TCPAR->{'FNOTACTIVE_DTCStatusBits_expected_2'}           = GDCOM_tcpar_optional('FNOTACTIVE_DTCStatusBits_expected_2');
  $TCPAR->{'FNOTACTIVE_FaultStatusBits_expected_2'}         = GDCOM_tcpar_optional('FNOTACTIVE_DTCStatusBits_expected_2');
  $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys_2'} = GDCOM_tcpar_optional('FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys_2');
  $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex_2'}  = GDCOM_tcpar_optional('FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex_2');

  $TCPAR->{'FACTIVE_STORED_duration_2'}                           = GDCOM_tcpar_optional('FACTIVE_STORED_duration_2');
  $TCPAR->{'FACTIVE_STORED_CU_faults_expected_2'}                 = GDCOM_tcpar_optional('FACTIVE_STORED_CU_faults_expected_2');
  $TCPAR->{'FACTIVE_STORED_RB_faults_expected_2'}                 = GDCOM_tcpar_optional('FACTIVE_STORED_RB_faults_expected_2');
  $TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected_2'}             = GDCOM_tcpar_optional('FACTIVE_STORED_DTCStatusBits_expected_2');
  $TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected_2'}           = GDCOM_tcpar_optional('FACTIVE_STORED_FaultStatusBits_expected_2');
  $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys_2'}   = GDCOM_tcpar_optional('FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys_2');
  $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex_2'}    = GDCOM_tcpar_optional('FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex_2');

  $TCPAR->{'FACTIVE_NOT_STORED_duration_2'}                        = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_duration_2');
  $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected_2'}              = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_CU_faults_expected_2');
  $TCPAR->{'FACTIVE_NOT_STORED_RB_faults_expected_2'}              = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_RB_faults_expected_2');
  $TCPAR->{'FACTIVE_NOT_STORED_DTCStatusBits_expected_2'}          = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_DTCStatusBits_expected_2');
  $TCPAR->{'FACTIVE_NOT_STORED_FaultStatusBits_expected_2'}        = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_FaultStatusBits_expected_2');
  $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys_2'}= GDCOM_tcpar_optional('FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys_2');
  $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex_2'} = GDCOM_tcpar_optional('FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex_2');
#-------------------------------data locally required by TC------------------------------------------------------------------------------------------
  $TCPAR->{'data'}; 
  
  return $TCPAR;
}


sub FaultMonitoring_StartSession
{

# start communication with ECU
#------------------------------
  GDCOM_start_communication('Starts Communication');
  
  if (defined $TCPAR->{'address_mode'})
   { 
     GDCOM_set_addressing_mode($TCPAR->{'address_mode'});
   }
  
# Enter a session an check whether ECU is in correct session
# -----------------------------------------------------------  
  GDCOM_StartSession ( $TCPAR->{'session'} , 'CheckActiveSession');
  return 1;
}
#-------------------------------------------------------------------------------
# CreateFault
#-------------------------------------------------------------------------------
sub FaultMonitoring_CreateFaults
{
	my $Faultlist_number = shift||1;
	 GDCOM_comment('M',"faultlist number is $Faultlist_number ");
	 if ($Faultlist_number eq "1")
   { 
         GDCOM_comment('M',"faultlist number is $Faultlist_number //1 ");
  # create Interrupt Lines fault
  #---------------  
    if(defined $TCPAR->{'interrupt_lines'})
    {      
      
	     my $deviceref = $TCPAR->{'interrupt_lines'};
      	  foreach my $device (@$deviceref){
      	  	DEVICE_setDeviceState ($device, 'Openline');
        }
      #GDCOM_manipulate_lines('interrupt' , $TCPAR->{'interrupt_lines'} );   
    }
  # create short Lines fault
  #---------------  
    if(defined $TCPAR->{'short_lines'})
    {
      GDCOM_manipulate_lines('short' , $TCPAR->{'short_lines'} );
    }
  # create CAN fault
  #---------------
    if(defined $TCPAR->{'disable_CAN_messages'})
    {
      COM_stopMessages($TCPAR->{'disable_CAN_messages'});
    }
    if(defined $TCPAR->{'FACTIVE_duration'})
    {
      GDCOM_delay($TCPAR->{'FACTIVE_duration'}/1000 , "Wait - FACTIVE Duration ($TCPAR->{'FACTIVE_duration'})ms");    
    }    
   }  
   
   if ($Faultlist_number eq "2") 						### FaultList number is checked for 2nd
   { 
          GDCOM_comment('M',"faultlist number is $Faultlist_number //2 ");
  # create Interrupt Lines fault
  #---------------  
    if(defined $TCPAR->{'interrupt_lines_2'})
    {      
     my $deviceref = $TCPAR->{'interrupt_lines_2'};
      	  foreach my $device (@$deviceref){
      	  	DEVICE_setDeviceState ($device, 'Openline');
        }
    }
  # create short Lines fault
  #---------------  
    if(defined $TCPAR->{'short_lines_2'})
    {
      GDCOM_manipulate_lines('short' , $TCPAR->{'short_lines_2'} );
    }
  # create CAN fault
  #---------------
    if(defined $TCPAR->{'disable_CAN_messages_2'})
    {
      COM_stopMessages($TCPAR->{'disable_CAN_messages_2'});
    }
    if(defined $TCPAR->{'FACTIVE_duration'})
    {
      GDCOM_delay($TCPAR->{'FACTIVE_duration'}/1000 , "Wait - FACTIVE Duration ($TCPAR->{'FACTIVE_duration'} )ms");    
    }    
   }  
  
    return 1;
}

#-------------------------------------------------------------------------------
# ResetFault
#-------------------------------------------------------------------------------
sub FaultMonitoring_ResetFaults
{
	my $Faultlist_number = shift ||1;
	 if ($Faultlist_number eq "2") 						### FaultList number is checked for 2nd
   { 
   	GDCOM_comment('M',"removing fault condition 2");      
  # Undo Interrupt Lines
  #---------------  
  if(defined $TCPAR->{'interrupt_lines_2'})
  {
   # GDCOM_manipulate_lines('undo_interrupt' , $TCPAR->{'interrupt_lines_2'} ); 
    GDCOM_comment('M',"undo all interrupts"); 
    #DCOM_manipulate_lines('undo_interrupt' , $TCPAR->{'interrupt_lines_2'} ); 
        my $deviceref = $TCPAR->{'interrupt_lines_2'};
      	  foreach my $device (@$deviceref){
      	  	DEVICE_resetDeviceState ($device, 'Openline');
        }     
  }
  # Undo short Lines
  #---------------  
  if(defined $TCPAR->{'short_lines_2'})
  {
    GDCOM_manipulate_lines('undo_short' , $TCPAR->{'short_lines_2'} ); 
    GDCOM_comment('M',"undo all shorts");      
  }
  # clear CAN fault
  #---------------
  if(defined $TCPAR->{'disable_CAN_messages_2'})
  {
    COM_startMessages($TCPAR->{'disable_CAN_messages_2'});
  }
  # Wait for fault reset to happen
  #---------------
  if(defined $TCPAR->{'FRESET_duration_2'})
  {
    GDCOM_delay($TCPAR->{'FRESET_duration_2'}/1000 , "Wait - FRESET Duration ($TCPAR->{'FRESET_duration_2'} )ms");    
  }
   }
  if ($Faultlist_number eq "1") 						### FaultList number is checked for 2nd
   { 
   	GDCOM_comment('M',"removing fault condition 1");   
  # Undo Interrupt Lines
  #---------------  
  if(defined $TCPAR->{'interrupt_lines'})
  {
  	 GDCOM_comment('M',"undo all interrupts"); 
    #GDCOM_manipulate_lines('undo_interrupt' , $TCPAR->{'interrupt_lines'} ); 
        my $deviceref = $TCPAR->{'interrupt_lines'};
      	  foreach my $device (@$deviceref){
      	  	DEVICE_resetDeviceState ($device, 'Openline');
        }
        
  }
  # Undo short Lines
  #---------------  
  if(defined $TCPAR->{'short_lines'})
  {
    GDCOM_manipulate_lines('undo_short' , $TCPAR->{'short_lines'} ); 
    GDCOM_comment('M',"undo all shorts");      
  }
  # clear CAN fault
  #---------------
  if(defined $TCPAR->{'disable_CAN_messages'})
  {
    COM_startMessages($TCPAR->{'disable_CAN_messages'});
  }
  # Wait for fault reset to happen
  #---------------
  if(defined $TCPAR->{'FRESET_duration'})
  {
    GDCOM_delay($TCPAR->{'FRESET_duration'}/1000 , "Wait - FRESET Duration ($TCPAR->{'FRESET_duration'} )ms");    
  }
   }
   
   
   
   
   
  return 1;
}

#-------------------------------------------------------------------------------
# EvaluteFaults
#-------------------------------------------------------------------------------
sub FaultMonitoring_EvaluateFaults
{
  $phase = shift; 
  my $Faultlist_number = shift||1;
 
# start communication with ECU
if ($Faultlist_number eq "1") 						### FaultList number is checked for 2nd
   { 
#---------------    
  if(($phase eq 'FINIT') && (defined $TCPAR->{'FINIT_CU_faults_expected'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FINIT_CU_faults_expected'},$TCPAR->{'ReadDTC_Subfunction'}, $TCPAR->{'DTCStatusMask'} );
  }
  if(($phase eq 'FACTIVE')&& (defined $TCPAR->{'FACTIVE_CU_faults_expected'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FACTIVE_CU_faults_expected'},$TCPAR->{'ReadDTC_Subfunction'}, $TCPAR->{'DTCStatusMask'} );
  }
  if(($phase eq 'FRESET')&& (defined $TCPAR->{'FRESET_CU_faults_expected'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FRESET_CU_faults_expected'},$TCPAR->{'ReadDTC_Subfunction'}, $TCPAR->{'DTCStatusMask'} );
  }
  if(($phase eq 'FHISTORY')&& (defined $TCPAR->{'FHISTORY_CU_faults_expected'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FHISTORY_CU_faults_expected'}, $TCPAR->{'ReadDTC_Subfunction'},$TCPAR->{'DTCStatusMask'} );
  }
  if(($phase eq 'FNOTACTIVE')&& (defined $TCPAR->{'FNOTACTIVE_CU_faults_expected'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FNOTACTIVE_CU_faults_expected'}, $TCPAR->{'ReadDTC_Subfunction'} , $TCPAR->{'DTCStatusMask'} );
  }
  if(($phase eq 'FACTIVE_STORED')&& (defined $TCPAR->{'FACTIVE_STORED_CU_faults_expected'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FACTIVE_STORED_CU_faults_expected'},$TCPAR->{'ReadDTC_Subfunction'}, $TCPAR->{'DTCStatusMask'} );
  }
  if(($phase eq 'FACTIVE_NOT_STORED')&& (defined $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected'},$TCPAR->{'ReadDTC_Subfunction'}, $TCPAR->{'DTCStatusMask'} );
  }
   }
   if ($Faultlist_number eq "2") 						### FaultList number is checked for 2nd
   { 
#---------------    
  if(($phase eq 'FINIT') && (defined $TCPAR->{'FINIT_CU_faults_expected_2'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FINIT_CU_faults_expected_2'},$TCPAR->{'ReadDTC_Subfunction_2'}, $TCPAR->{'DTCStatusMask_2'} );
  }
  if(($phase eq 'FACTIVE')&& (defined $TCPAR->{'FACTIVE_CU_faults_expected_2'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FACTIVE_CU_faults_expected_2'},$TCPAR->{'ReadDTC_Subfunction_2'}, $TCPAR->{'DTCStatusMask_2'} );
  }
  if(($phase eq 'FRESET')&& (defined $TCPAR->{'FRESET_CU_faults_expected_2'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FRESET_CU_faults_expected_2'},$TCPAR->{'ReadDTC_Subfunction_2'}, $TCPAR->{'DTCStatusMask_2'} );
  }
  if(($phase eq 'FHISTORY')&& (defined $TCPAR->{'FHISTORY_CU_faults_expected_2'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FHISTORY_CU_faults_expected_2'}, $TCPAR->{'ReadDTC_Subfunction_2'},$TCPAR->{'DTCStatusMask_2'} );
  }
  if(($phase eq 'FNOTACTIVE')&& (defined $TCPAR->{'FNOTACTIVE_CU_faults_expected_2'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FNOTACTIVE_CU_faults_expected_2'}, $TCPAR->{'ReadDTC_Subfunction_2'} , $TCPAR->{'DTCStatusMask_2'} );
  }
  if(($phase eq 'FACTIVE_STORED')&& (defined $TCPAR->{'FACTIVE_STORED_CU_faults_expected_2'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FACTIVE_STORED_CU_faults_expected_2'},$TCPAR->{'ReadDTC_Subfunction_2'}, $TCPAR->{'DTCStatusMask_2'} );
  }
  if(($phase eq 'FACTIVE_NOT_STORED')&& (defined $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected_2'}))
  {
    FaultMonitoring_ReadandEvalDTC($TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected_2'},$TCPAR->{'ReadDTC_Subfunction_2'}, $TCPAR->{'DTCStatusMask_2'} );
  }
   }
   
   
  return;
}

#-------------------------------------------------------------------------------
# EvaluteFaults
#-------------------------------------------------------------------------------
sub FaultMonitoring_EvaluateFaultStatus
{
  $phase = shift; 
  my $Faultlist_number = shift||1;  
  if ($Faultlist_number eq "1") 						### FaultList number is checked for 2nd
   { 
  if($phase eq 'FINIT')
  {
      if( defined $TCPAR->{'FINIT_DTCStatusBits_expected'})
        { FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FINIT_DTCStatusBits_expected'}); }
      if( defined $TCPAR->{'FINIT_FaultStatusBits_expected'})
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FINIT_FaultStatusBits_expected'});}
  }
  if(($phase eq 'FACTIVE'))
  {
      if( defined $TCPAR->{'FACTIVE_DTCStatusBits_expected'})
        { FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_DTCStatusBits_expected'}); }
      if( defined $TCPAR->{'FACTIVE_FaultStatusBits_expected'})
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_FaultStatusBits_expected'});}
  }
  if(($phase eq 'FRESET')&& (defined $TCPAR->{'FRESET_CU_faults_expected'}))
  {
      if( defined $TCPAR->{'FRESET_DTCStatusBits_expected'})
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FRESET_DTCStatusBits_expected'});}
      if( defined $TCPAR->{'FRESET_FaultStatusBits_expected'})
        { FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FRESET_FaultStatusBits_expected'}); }
  }
  if(($phase eq 'FHISTORY')&& (defined $TCPAR->{'FHISTORY_CU_faults_expected'}))
  {
      if( defined $TCPAR->{'FHISTORY_DTCStatusBits_expected'})      
        { FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FHISTORY_DTCStatusBits_expected'}); }
      if( defined $TCPAR->{'FHISTORY_FaultStatusBits_expected'})
        { FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FHISTORY_FaultStatusBits_expected'}); }
  }
  if(($phase eq 'FNOTACTIVE')&& (defined $TCPAR->{'FNOTACTIVE_CU_faults_expected'}))
  {
      if( defined $TCPAR->{'FNOTACTIVE_DTCStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FNOTACTIVE_DTCStatusBits_expected'});}
      if( defined $TCPAR->{'FNOTACTIVE_FaultStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FNOTACTIVE_FaultStatusBits_expected'});}
  }
  if(($phase eq 'FACTIVE_STORED')&& (defined $TCPAR->{'FACTIVE_STORED_CU_faults_expected'}))
  {
      if( defined $TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected'});}
      if( defined $TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected'});}
  }
  if(($phase eq 'FACTIVE_NOT_STORED')&& (defined $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected'}))
  {
      if( defined $TCPAR->{'FACTIVE_NOT_STORED_DTCStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_NOT_STORED_DTCStatusBits_expected'});}
      if( defined $TCPAR->{'FACTIVE_NOT_STORED_FaultStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_NOT_STORED_FaultStatusBits_expected'});}
  }
  if(($phase eq 'FACTIVE_STORED')&& (defined $TCPAR->{'FACTIVE_STORED_CU_faults_expected'}))
  {
      if( defined $TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected'});}
      if( defined $TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected'});}
  }
   }
   if ($Faultlist_number eq "2") 						### FaultList number is checked for 2nd
   { 
  if($phase eq 'FINIT')
  {
      if( defined $TCPAR->{'FINIT_DTCStatusBits_expected_2'})
        { FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FINIT_DTCStatusBits_expected_2'}); }
      if( defined $TCPAR->{'FINIT_FaultStatusBits_expected'})
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FINIT_FaultStatusBits_expected_2'});}
  }
  if(($phase eq 'FACTIVE'))
  {
      if( defined $TCPAR->{'FACTIVE_DTCStatusBits_expected_2'})
        { FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_DTCStatusBits_expected_2'}); }
      if( defined $TCPAR->{'FACTIVE_FaultStatusBits_expected_2'})
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_FaultStatusBits_expected_2'});}
  }
  if(($phase eq 'FRESET')&& (defined $TCPAR->{'FRESET_CU_faults_expected_2'}))
  {
      if( defined $TCPAR->{'FRESET_DTCStatusBits_expected_2'})
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FRESET_DTCStatusBits_expected_2'});}
      if( defined $TCPAR->{'FRESET_FaultStatusBits_expected_2'})
        { FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FRESET_FaultStatusBits_expected_2'}); }
  }
  if(($phase eq 'FHISTORY')&& (defined $TCPAR->{'FHISTORY_CU_faults_expected_2'}))
  {
      if( defined $TCPAR->{'FHISTORY_DTCStatusBits_expected_2'})      
        { FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FHISTORY_DTCStatusBits_expected_2'}); }
      if( defined $TCPAR->{'FHISTORY_FaultStatusBits_expected_2'})
        { FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FHISTORY_FaultStatusBits_expected_2'}); }
  }
  if(($phase eq 'FNOTACTIVE')&& (defined $TCPAR->{'FNOTACTIVE_CU_faults_expected_2'}))
  {
      if( defined $TCPAR->{'FNOTACTIVE_DTCStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FNOTACTIVE_DTCStatusBits_expected_2'});}
      if( defined $TCPAR->{'FNOTACTIVE_FaultStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FNOTACTIVE_FaultStatusBits_expected_2'});}
  }
  if(($phase eq 'FACTIVE_STORED')&& (defined $TCPAR->{'FACTIVE_STORED_CU_faults_expected_2'}))
  {
      if( defined $TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected_2'});}
      if( defined $TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected_2'});}
  }
  if(($phase eq 'FACTIVE_NOT_STORED')&& (defined $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected_2'}))
  {
      if( defined $TCPAR->{'FACTIVE_NOT_STORED_DTCStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_NOT_STORED_DTCStatusBits_expected_2'});}
      if( defined $TCPAR->{'FACTIVE_NOT_STORED_FaultStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_NOT_STORED_FaultStatusBits_expected_2'});}
  }
  if(($phase eq 'FACTIVE_STORED')&& (defined $TCPAR->{'FACTIVE_STORED_CU_faults_expected_2'}))
  {
      if( defined $TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalDTCStatusBits($TCPAR->{'FACTIVE_STORED_DTCStatusBits_expected_2'});}
      if( defined $TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected_2'})      
        {FaultMonitoring_ReadandEvalFaultStatusBits($TCPAR->{'FACTIVE_STORED_FaultStatusBits_expected_2'});}
  }
   }
  return;
}


#-------------------------------------------------------------------------------
# EvaluteFaults
#-------------------------------------------------------------------------------
sub FaultMonitoring_Evaluate_ExtDataRecbyDTCNum
{
  my $phase = shift;
  my $Faultlist_number = shift||1;
  
  if ($Faultlist_number eq "1") 						### FaultList number is checked for 2nd
   { 
    if($phase eq 'FACTIVE') 
    {
      DCOM_comment('s' , "FaultMonitoring_Evaluate_ExtDataRecbyDTCNum: evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_phys'}){
        DCOM_comment('s' , "FACTIVE_ExtDataRecbyDTCNum_expected_phys\n");
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_phys'} , $TCPAR->{'FACTIVE_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'} , 'phys' );
      }
      if(defined $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_hex'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_hex'} , $TCPAR->{'FACTIVE_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'} , 'hex' );
      }
    	 
    }
    if($phase eq 'FRESET')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_phys'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_phys'} , $TCPAR->{'FRESET_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'phys');
      }
      if(defined $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_hex'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_hex'} , $TCPAR->{'FRESET_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'hex');
      }
    }
    if($phase eq 'FHISTORY')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_phys'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_phys'} , $TCPAR->{'FHISTORY_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'phys');  
      }
      if(defined $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_hex'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_hex'} , $TCPAR->{'FHISTORY_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'hex');  
      }
    }
    if($phase eq 'FNOTACTIVE')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys'} , $TCPAR->{'FNOTACTIVE_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'phys');
      }
      if(defined $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex'} , $TCPAR->{'FNOTACTIVE_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'hex');
      }
    }
    if($phase eq 'FACTIVE_STORED')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys'} , $TCPAR->{'FACTIVE_STORED_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'phys');
      }
      if(defined $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex'} , $TCPAR->{'FACTIVE_STORED_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'hex');
      }
    }
    if($phase eq 'FACTIVE_NOT_STORED')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys'} , $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'phys');
      }      
      if(defined $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex'} , $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected'} , $TCPAR->{'ExtDataRecNum'}, 'hex');
      }      
    }
   } 
   if ($Faultlist_number eq "2") 						### FaultList number is checked for 2nd
   { 
   	if($phase eq 'FACTIVE') 
    {
      DCOM_comment('s' , "FaultMonitoring_Evaluate_ExtDataRecbyDTCNum: evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_phys_2'}){
        DCOM_comment('s' , "FACTIVE_ExtDataRecbyDTCNum_expected_phys_2\n");
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_phys_2'} , $TCPAR->{'FACTIVE_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'} , 'phys' );
      }
      if(defined $TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_hex_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_ExtDataRecbyDTCNum_expected_hex_2'} , $TCPAR->{'FACTIVE_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'} , 'hex' );
      }
    	 
    }
    if($phase eq 'FRESET')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_phys_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_phys_2'} , $TCPAR->{'FRESET_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'phys');
      }
      if(defined $TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_hex_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FRESET_ExtDataRecbyDTCNum_expected_hex_2'} , $TCPAR->{'FRESET_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'hex');
      }
    }
    if($phase eq 'FHISTORY')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_phys_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_phys_2'} , $TCPAR->{'FHISTORY_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'phys');  
      }
      if(defined $TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_hex_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FHISTORY_ExtDataRecbyDTCNum_expected_hex_2'} , $TCPAR->{'FHISTORY_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'hex');  
      }
    }
    if($phase eq 'FNOTACTIVE')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_phys_2'} , $TCPAR->{'FNOTACTIVE_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'phys');
      }
      if(defined $TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FNOTACTIVE_ExtDataRecbyDTCNum_expected_hex_2'} , $TCPAR->{'FNOTACTIVE_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'hex');
      }
    }
    if($phase eq 'FACTIVE_STORED')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_phys_2'} , $TCPAR->{'FACTIVE_STORED_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'phys');
      }
      if(defined $TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex_2'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_STORED_ExtDataRecbyDTCNum_expected_hex_2'} , $TCPAR->{'FACTIVE_STORED_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'hex');
      }
    }
    if($phase eq 'FACTIVE_NOT_STORED')
    {
      DCOM_comment('s' , "Evaluating DTCExtendedDataRecordbyDTCNumber in phase '$phase' ");
      if(defined $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_phys_2'} , $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'phys');
      }      
      if(defined $TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex'}){
        FaultMonitoring_ReadandEvalExtDataRecbyDTCNum($TCPAR->{'FACTIVE_NOT_STORED_ExtDataRecbyDTCNum_expected_hex_2'} , $TCPAR->{'FACTIVE_NOT_STORED_CU_faults_expected_2'} , $TCPAR->{'ExtDataRecNum_2'}, 'hex');
      }      
    }
   }
  return;
}

sub FaultMonitoring_ReadandEvalDTC
{
   my $faults_expected    = shift;
   my $ReadDTC_Subfuction = shift;
   my $DTCStatusMask      = shift;
   
  unless(defined $ReadDTC_Subfuction ){ $ReadDTC_Subfuction = 0x02; $DTCStatusMask = 0x08} 
  GDCOM_read_and_eval_fcm_cu($faults_expected,undef,undef, $ReadDTC_Subfuction , $DTCStatusMask);

  return 1;
}
#-------------------------------------------------------------------------------
# ReadandEvalDTCStatusBits
#-------------------------------------------------------------------------------
sub FaultMonitoring_ReadandEvalDTCStatusBits
{
  my $DTCStatusBits_expected = shift;  
  GDCOM_read_and_eval_DTCStatusBits($DTCStatusBits_expected); #request with any one of the Status Bit is set
  return;
}

#-------------------------------------------------------------------------------
# ReadandEvalDTCStatusBits
#-------------------------------------------------------------------------------
sub FaultMonitoring_ReadandEvalFaultStatusBits
{
  my $FaultStatusBits_expected = shift;    
  GDCOM_read_and_eval_FaultStatusBits( $FaultStatusBits_expected  );
  return;
}

#-------------------------------------------------------------------------------
# FaultMonitoring_ReadandEvalExtDataRecbyDTCNum
#-------------------------------------------------------------------------------
sub FaultMonitoring_ReadandEvalExtDataRecbyDTCNum
{
  my $ExtDataRecbyDTCNum_expected = shift;
  my $Faults_expected_aref = shift;
  my $ExtDataRecNum = shift;
  my $mode = shift;
  my( $fault );

  DCOM_comment('s' , "FaultMonitoring_ReadandEvalExtDataRecbyDTCNum: Evaluating DTCExtended DataRecord in mode $mode");
  foreach $fault( @$Faults_expected_aref )
  {
    DCOM_comment( 's' , "Evaluating the DTCExtendedDataRecord for DTC $fault");
    DCOM_comment( 's' , "Evaluating the DTCExtendedDataRecord for Record number $ExtDataRecNum");
    GDCOM_read_and_eval_DTCExtDataRecbyDTCNum( $ExtDataRecbyDTCNum_expected , $fault, $ExtDataRecNum , $mode );
  }
  return;
}

#-------------------------------------------------------------------------------
# ECUReset
#-------------------------------------------------------------------------------
sub FaultMonitoring_ECUReset
{
  my $index;
  if(defined $TCPAR->{'ECUReset'})
  {
    DCOM_w2html("Reset the ECU ( ResetType:".$TCPAR->{'ECUReset'}{'ResetType'}."&5", "T" , 'blue', "Courier" );
    unless(defined $TCPAR->{'ECUReset'}{'COUNT'}){
      $TCPAR->{'ECUReset'}{'COUNT'} = 1;
    }
    foreach $index (1..$TCPAR->{'ECUReset'}{'COUNT'})
    {
      GDCOM_ecu_reset($TCPAR->{'ECUReset'}{'ResetType'});
    }
  }
}
#-------------------------------------------------------------------------------
# ECUReset no of times
#-------------------------------------------------------------------------------
sub FaultMonitoring_ECU_reset_times
{
  my $times = shift;	
  my $index;
  if(defined $TCPAR->{'ECUReset'})
 {
    for ($index=0, $index<$times,$index+1 )
    {
      GDCOM_ecu_reset($TCPAR->{'ECUReset'}{'ResetType'});
      DCOM_comment('M', 'ECU reset done');
    }
   
 } 
}

#-------------------------------------------------------------------------------
# FaultMonitoring_SetFaultPreconditions
#-------------------------------------------------------------------------------
sub FaultMonitoring_SetFaultPreconditions
{
  my $preset_phase = shift;
  
  if( $preset_phase eq "preset1" )
  {
    if(defined $TCPAR->{'preset_electric_signals_1'})
    {
       DCOM_set_electric_signals($TCPAR->{'preset_electric_signals_1'});
      
    }
    if(defined $TCPAR->{'preset_can_signals_phys_1'})
    { 
	   	S_w2rep("preset_can_signals_phys_1 is Defined \n");
	    foreach my $signal(keys %{$TCPAR->{'preset_can_signals_phys_1'}})
       {
       	 
        $detected_CAN_signals_old->{$signal} = COM_GetSignalValue($signal); 
         S_w2rep("CURRENT SIGNAL is $signal set to VALUE $detected_CAN_signals_old->{$signal} \n");
         S_w2rep("SIGNAL is $signal set to VALUE $TCPAR->{'preset_can_signals_phys_1'}{$signal} \n");
         COM_setSignalState($signal,$TCPAR->{'preset_can_signals_phys_1'}{$signal}); 
       }    
    }
    if(defined $TCPAR->{'preset_can_signals_hex_1'})
    {
    	
     S_w2rep("preset_can_signals_hex_1 is Defined \n");
      foreach my $signal(keys %{$TCPAR->{'preset_can_signals_hex_1'}})
       {
        $detected_CAN_signals_old{$signal} =COM_GetSignalValue($signal); 
         S_w2rep("CURRENT SIGNAL is $signal set to VALUE $detected_CAN_signals_old->{$signal} \n");
         S_w2rep("SIGNAL is $signal set to VALUE $TCPAR->{'preset_can_signals_hex_1'}{$signal} \n");
         COM_setSignalState($signal,$TCPAR->{'preset_can_signals_hex_1'}{$signal}); 
       }    
    }
    if(defined $TCPAR->{'preset_function_calls'})
    {
        foreach $function(@{$TCPAR->{'preset_function_calls'}}){
          &{ $function }( );
        }
    }
 }

  if( $preset_phase eq "preset2" )
  {
    if(defined $TCPAR->{'preset_electric_signals_2'})
    {
      DCOM_set_electric_signals($TCPAR->{'preset_electric_signals_2'});
    }
    if(defined $TCPAR->{'preset_can_signals_phys_2'})
    {
       S_w2rep("preset_can_signals_phys_2 is Defined \n");	
       foreach my $signal(keys %{$TCPAR->{'preset_can_signals_phys_2'}})
       {
         $detected_CAN_signals_old{$signal} =COM_GetSignalValue($signal); 
         S_w2rep("CURRENT SIGNAL is $signal set to VALUE $detected_CAN_signals_old->{$signal} \n");
         S_w2rep("SIGNAL is $signal set to VALUE $TCPAR->{'preset_can_signals_phys_2'}{$signal} \n");
         COM_setSignalState($signal,$TCPAR->{'preset_can_signals_phys_2'}{$signal}); 
       }    
    }
    if(defined $TCPAR->{'preset_can_signals_hex_2'})
    {
     S_w2rep("preset_can_signals_hex_2 is Defined \n");	
     foreach my $signal(keys %{$TCPAR->{'preset_can_signals_hex_2'}})
       {
       
        $detected_CAN_signals_old{$signal} =COM_GetSignalValue($signal); 
        S_w2rep("CURRENT SIGNAL is $signal set to VALUE $TCPAR->{'preset_can_signals_hex_2'}{$signal} \n");
        S_w2rep("SIGNAL is $signal set to VALUE $TCPAR->{'preset_can_signals_hex_2'}{$signal} \n");
         COM_setSignalState($signal,$TCPAR->{'preset_can_signals_hex_2'}{$signal}); 
       }    
    }
    if(defined $TCPAR->{'preset_function_calls_2'})
    {
        foreach $function(@{$TCPAR->{'preset_function_calls_2'}}){
          &{ $function }( );
        }
    }
 }
}

#-------------------------------------------------------------------------------
# FaultMonitoring_ResetFaultPreconditions
#-------------------------------------------------------------------------------
sub FaultMonitoring_ResetFaultPreconditions

{
  
  if( $preset_phase eq "preset1" )
  {
    if(defined $TCPAR->{'preset_electric_signals_1'})
    {
      DCOM_reset_electric_signals($TCPAR->{'preset_electric_signals_1'});
    }
    if(defined $TCPAR->{'preset_can_signals_phys_1'})
    {
       foreach my $signal(keys %{$TCPAR->{'preset_can_signals_phys_1'}})
       {
        S_w2rep("CURRENT SIGNAL is $signal set to VALUE $detected_CAN_signals_old->{$signal} \n");
         COM_setSignalState($signal,$detected_CAN_signals_old->{$signal}); 
       } 
    }
 }
}

#-------------------------------------------------------------------------------
# FaultMonitoring_StoringFaultData
#-------------------------------------------------------------------------------
sub FaultMonitoring_StoringFaultData
{
	
  my $ExtDataRecbyDTCNum_expected = shift;
  my $Faults_expected_aref = shift;
  my $ExtDataRecNum = shift;
  my $mode = shift;
  my( $fault );

  
  return 1;
}


#-------------------------------------------------------------------------------
# FaultMonitoring_ResetinternalFaultPreconditions
#-------------------------------------------------------------------------------
sub FaultMonitoring_ResetinternalFaultPreconditions
{   
	my $name;
	my $value;
	$name = $main::ProjectDefaults->{'INTERNAL_VAR'}{'Noidlemode'};
	PD_WriteMemoryByName($name,$TCPAR->{'data'});			#writting same value as rad earlier
	GDCOM_ecu_reset();
	GDCOM_wait_ms('TIMER_ECU_OFF');
	
	return 1;
}

#-------------------------------------------------------------------------------
# FaultMonitoring_CreateCrash
#-------------------------------------------------------------------------------
sub FaultMonitoring_CreateCrash
{
	my $crashfile =shift;					#crashfile mapping to be done in the project constant	
	my $configfile;							#configfile to be declared in the Project Constants
	my $trigger;
	
	if(defined $TCPAR->{'crashfile'})
	{
	$trigger = 1;
	$crashfile = $main::ProjectDefaults->{'CRASH'}{$crashfile};
  	IDX_PrepareInjection($configfile,'$crashfile',$trigger);
  	DCOM_wait_ms(5000);
	}
	
  	return 1;
}


#-------------------------------------------------------------------------------
# FaultMonitoring_ReadCrashReocrder
#-------------------------------------------------------------------------------
sub FaultMonitoring_ReadCrashReocrder
{
	$request = "REQ_ReadDatabyID_".$data_label;    
    $response = "PR_ReadDatabyID_".$data_label;
    $response = GDCOM_request_general( $request , $response );   
    return 1;
}

#-------------------------------------------------------------------------------
# FaultMonitoring_CreateInternalFaults
#-------------------------------------------------------------------------------
sub FaultMonitoring_CreateInternalFaults
{
	my $name;
	my $value;
	$name = $main::ProjectDefaults->{'INTERNAL_VAR'}{'Noidlemode'};
	$TCPAR->{'data'} = PD_ReadMemoryByName($name);
	PD_WriteMemoryByName($name,[0x01]);					#replacing the calue with 0x01.
	PD_ECUreset();
	GDCOM_wait_ms('TIMER_ECU_READY');
	return 1;
}

#-------------------------------------------------------------------------------
# FaultMonitoring_ReadPDSporadicCounter
#-------------------------------------------------------------------------------
sub FaultMonitoring_ReadPDSporadicCounter
{
	#####################
	
   my $fault_name = 'FltAB1FPResistanceOpen';	
	#my $fault_name =shift;
   my $flt_mem_struct = PD_GetExtendedFaultInformation();
   return 1 if ($main::opt_offline); # return 1 in offline

    my $extended_struct ;
    unless (defined( $fault_name )) {
        S_set_error( "! too less parameters ! SYNTAX: status = FaultMonitoring_ReadPDSporadicCounter(fault_name)", 110 );
        return 0;
    }

    if( ref($flt_mem_struct) ne "HASH" ){
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;   #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue (keys %flt_mem_keys){
        #set $extended_struct = 1, if Extendedfaultinfo found
        if((exists $flt_mem_struct->{$keyvalue} ) && ($flt_mem_keys{$keyvalue} == 0)){
            $extended_struct = 1;
        }
    }
    
    foreach my $keyvalue (keys %flt_mem_keys){
        #check, if all mandatory keys are present
        if(not exists $flt_mem_struct->{$keyvalue}) {
            if(($flt_mem_keys{$keyvalue} == 1) || ($extended_struct == 1)) {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return 0;
            }
        }
        #check, if all mandatory keys are defined
        elsif(not defined $flt_mem_struct->{$keyvalue}){
            if(($flt_mem_keys{$keyvalue} == 1) || ($extended_struct == 1)) {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return 0;
            }        
        }
        else {  #check if all key's array reference contains defined array elements
            if(S_check_array($flt_mem_struct->{$keyvalue},"\$flt_mem_struct->{'$keyvalue'}") == 0) {
                S_set_error( "S_check_array reported an error" , 114);
                return 0;
            }
        }
    }
    
    foreach my $index (0..@{$flt_mem_struct->{'fault_text'}}-1){
      # compare each fault in lowercase (case insensitive)
      if (lc($flt_mem_struct->{'fault_text'}[$index]) eq lc($fault_name)){
        my $spstatus = $flt_mem_struct->{'SpoCnt'}[$index];
        S_w2log( 2, " PD_get_fault_status: $fault_name has sporadic counter $spstatus\n" );
        return ($status); 
      }
    }
    


	#####################
}

#-------------------------------------------------------------------------------
# FaultMonitoring_CustomerPriority
#-------------------------------------------------------------------------------
sub FaultMonitoring_CustomerPriority
{
	my $Priority_reported = shift,
	my $custPriotity;
	$custPriotity = Project_Faultmonitoring_customerpriority($Priority_reported);		
	return 	$custPriotity;
}
#-------------------------------------------------------------------------------
# FaultMonitoring_CreateAdaptationfault
#-------------------------------------------------------------------------------
sub FaultMonitoring_CreateAdaptationfault
{
	my $tcpar_device_name = shift || 'AB1FD'; 
        S_w2rep(" Setting Initial condition for adaptation","blue");
     
        GDCOM_GetAccessToRequest("WriteDatabyID_0500_ParamValue");
   		DIAG_AdaptDeadapt($tcpar_device_name,'Adapt'); 
	         
}

#-------------------------------------------------------------------------------
# FaultMonitoring_GetunlearnCounter
#-------------------------------------------------------------------------------

sub FaultMonitoring_GetunlearnCounter
{

# start communication with ECU
#------------------------------
  GDCOM_start_communication('Starts Communication');
  
  if (defined $TCPAR->{'address_mode'})
   { 
     GDCOM_set_addressing_mode($TCPAR->{'address_mode'});
   }
# -----------------------------------------------------------  
  if (defined $TCPAR->{'session'})
  {
    GDCOM_StartSession ( $TCPAR->{'session'} , 'CheckActiveSession');	
  }
  
     
  %fault_name = $TCPAR->{'FACTIVE_CU_faults_expected'};
  #$DTC = $GENERIC_ProjectDefaults->{'CU_ERRORS'}{$fault_name};
  $DTC = DCOM_get_FaultValue_from_mapping(%fault_name, 'CU');
  $DTC = join(' ',$DTC =~ /..?/sg); #split it into 2chars and then join with spaces
  $DTCExtDataRecordNumber = 'FF';
  unless(defined $eval_mode ){ 
    $eval_mode = 'phys';
  }
  $bytes_per_DTC = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTCbytes'};
  DCOM_comment ('M',"$bytes_per_DTC");
  DCOM_comment ('M',"$DTCExtDataRecordNumber is the record number");
  $label_value->{'DTCExtDataRecordNumber'} = $DTCExtDataRecordNumber;
  $label_value->{'DTC'} = $DTC;
  $request  = "REQ_ReadDTC_reportDTCExtendedDataRecordByDTCNumber";
  $response = "PR_ReadDTC_reportDTCExtendedDataRecordByDTCNumber";
  $detected_response = DCOM_request_general($request,$response, $label_value);
  @bytes = split(/ /, $detected_response );
  @bytes=splice(@bytes, 0, 2+$bytes_per_DTC+5);
  $unlearn=splice(@bytes, 0, 1);
 
  return $unlearn;
}





#-------------------------------------------------------------------------------
# FaultMonitoring_UndoAdaptationfault
#-------------------------------------------------------------------------------
sub FaultMonitoring_UndoAdaptationfault
{
	
	my $tcpar_device_name = shift || 'AB1FD'; 
	 ########################################################################################       
     S_w2rep("Performing the deadaptation ","blue");
	 GDCOM_GetAccessToRequest("WriteDatabyID_0500_ParamValue");
     DIAG_AdaptDeadapt($tcpar_device_name,'Deadapt');	
    
}
#########################################################################################


#-------------------------------------------------------------------------------
# FaultMonitoring_dtclist
#-------------------------------------------------------------------------------
sub FaultMonitoring_dtclist
{
	$bytes_per_DTC = $LIFT_config::LIFT_ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}->{'DTCbytes'};
	########################################################################################       
			GDCOM_getRequestInfofromMapping("ReadDTC_reportDTCByStatusMask");

             $write_request       = "REQ_ReadDTC_reportDTCByStatusMask";    
             $response            = "PR_ReadDTC_reportDTCByStatusMask";
             $response = GDCOM_request_general( $write_request,$response);
 
   			 @detected_value_data = split (/ /,$response);
			 GDCOM_comment('M',"@detected_value_data");  
$r=3; 


splice(@detected_value_data,0,3);
$lastindex=$#detected_value_data;
for($noofDTC = 0;$noofDTC<= ((($lastindex)+1)/4); $noofDTC++)
{
	 @DTClist = splice(@detected_value_data,0,$bytes_per_DTC+1);
	 @DTClist1 = splice(@DTClist,0,$bytes_per_DTC);
	     $detected_value =undef;
             for($i=0;$i<=scalar(@DTClist1);$i++)
             {
             $detected_value = $detected_value."".$DTClist1[$i];     
             }
	    $ListofDtc[$noofDTC]=$detected_value;
}
     		 
     		 GDCOM_comment('M',"@ListofDtc");
		     return @ListofDtc;
    
}
#########################################################################################

#-------------------------------------------------------------------------------
# Faultmonitoring_checkDTC
#-------------------------------------------------------------------------------
sub Faultmonitoring_checkDTC
{
	 my ( $array1, $array2 ) = @_;
	 my @dtclist1=@$array1;
	 my @dtclist2=@$array2;
	 my ($i,$q);
	 my (@DTC_found,@DTC_notfound);
	 my ($length1,$length2);
	 $length1=$#dtclist1;
	 $length2=$#dtclist2;
	
	 if($length1 ge $length2)
	 {
	 	for($i=0;$i<$length1;++$i)			#running for the length of the longer dtc list
	 	{
	 		$found=0;
	 		for($q=0;$q<$length2;++$q)				#running for the length of the smaller dtc list
	 		{
	 			if ($dtclist1[$i] eq $dtclist2[$q])
	 			{
	 			push(@DTC_found,$dtclist1[$i]);

	 			$found=1;
	 			}elsif(($dtclist1[$i] ne $dtclist2[$q])&&($found eq 0)&&($q eq ($length2-1)))
	 			{
	 			push(@DTC_notfound,$dtclist1[$i]);
				GDCOM_comment('M',"DTCs FOUND $dtclist1[$i] in list one");
				}
				#checking the uncommon dtcs in the second list
				if ($dtclist2[$i] eq $dtclist1[$q])
	 			{
	 			$found=1;
	 			}elsif(($dtclist2[$i] ne $dtclist1[$q])&&($found eq 0)&&($q eq ($length2-1)))
	 			{
	 			push(@DTC_notfound,$dtclist2[$i]);
				GDCOM_comment('M',"DTCs FOUND $dtclist2[$i] in list two");
	 			}
					
					

				
	 		}
	 	}
	 }
	 elsif($length2 gt $length1)
	 {
	 	for($i=0;$i<$length2;++$i)			#running for the length of the longer dtc list
	 	{
	 		$found=0;
	 		for($q=0;$q<$length1;++$q)				#running for the length of the smaller dtc list
	 		{
	 			if ($dtclist2[$i] eq $dtclist1[$q])
	 			{
	 			push(@DTC_found,$dtclist2[$i]);
	 			$found=1;
	 			}elsif(($dtclist2[$i] ne $dtclist1[$q])&&($found eq 0)&&($q eq $length1))
	 			{
	 			push(@DTC_notfound,$dtclist2[$i]);	
	 			}
	 		}
	 	}
	 
	 	
	 }
	 GDCOM_comment('M',"DTCs FOUND @DTC_found");
	 GDCOM_comment('M',"UNCOMMON DTCs @DTC_notfound");
	
	 
	 return (\@DTC_found,\@DTC_notfound);
	    
}

#########################################################################################


#-------------------------------------------------------------------------------
# FaultMonitoring_FaultCheck
#-------------------------------------------------------------------------------
sub FaultMonitoring_FaultCheck
{
	my $fault_name =shift;
	my $qualitime =shift;
	my $dequalitime = shift;
	
    #________________________________________________________________FAULT INFO______________________________________________#
	#--------------------------------------
	my ($requestInfoDTC,$requestInfoDevice,$requestInfoCondition,$requestDeviceType,$requestqualitime,$requestdequalitime,$requestfaultpriority,$faultpropunl,$faultpropwl)=Project_Faultmonitoring_fetchinfo($fault_name);   		
	#--------------------------------------
	
	GDCOM_comment('M',"Read DTC information using 19 06 service");
	my ($DTCExtDataRecordNumber,$DTC_detected);
	$DTCExtDataRecordNumber = 'FF';
	$label_value->{'DTCExtDataRecordNumber'} = "$DTCExtDataRecordNumber";
 	
 	$DTC = DCOM_get_FaultValue_from_mapping($fault_name, 'CU');
 	GDCOM_comment('M',"$DTC from .flt file");
    $DTC = join(' ',$requestInfoDTC =~ /..?/sg); #split it into 2chars and then join with spaces
	
	GDCOM_comment('M',$DTC);
 	$label_value->{'DTC'} = $DTC;
  	$request  = "REQ_ReadDTC_reportDTCExtendedDataRecordByDTCNumber";
  	$response = "PR_ReadDTC_reportDTCExtendedDataRecordByDTCNumber";
  	$detected_response = DCOM_request_general($request,$response, $label_value);       
       
        @detected_value_data = split (/ /,$detected_response);  
             $detected_value = undef;                                           
             for($i=0;$i<=scalar(@detected_value_data);$i++)
             {
             $detected_value = $detected_value." ".$detected_value_data[$i];
             
             }  
          $priority_reported =$detected_value_data[7];            
   		$DTC_detected=$detected_value_data[2]." ".$detected_value_data[3]." ".$detected_value_data[4];
   		$unlearn_value=$detected_value_data[10];
   		#__________________________________________________CD FAULT STATUS____________________________________________________#
   		$bytes_per_DTC = $LIFT_config::LIFT_ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}->{'DTCbytes'};
   		$faultstatus= $detected_value_data[2+$bytes_per_DTC];
  		if (($faultpropwl eq '1')&&($faultstatus eq '89'))
   			{
   			S_w2rep("status of the fault is $faultstatus");
   			S_set_verdict(VERDICT_PASS);
   			}
   		elsif(($faultpropwl eq '0')&&($faultstatus eq '09'))
   			{
   			S_w2rep("status of the fault is $faultstatus");
   			S_set_verdict(VERDICT_PASS);
   			}
   		else
   			{
   			S_set_verdict(VERDICT_FAIL);	
   			}
  		
 		#___________________________________________________DTC CHECK_______________________________________________________#
   		if (($DTC eq $DTC_detected))
   		{
   			S_w2rep("DTC is same as found in .flt file");
   			S_set_verdict(VERDICT_PASS);
   		}else
   		{
   			S_w2rep("DTC mis match");
   			S_set_verdict(VERDICT_FAIL);
   			S_set_error( "! DTC mis match", 00 );
   		}
   		#_________________________________________________PRIORITY CHECK_____________________________________________________#
   		$priority_reported=FaultMonitoring_CustomerPriority($priority_reported);
   		$tcpar_priority=$requestfaultpriority;
   		if ($priority_reported eq $tcpar_priority)
   		{
   		 S_w2rep("\n The Customer Priority is $priority_reported \n","blue");
         S_set_verdict(VERDICT_PASS);
   		}
   		else
   		{
   		S_w2rep("\n The Customer Priority is $priority_reported \n","blue");
         S_set_verdict(VERDICT_FAIL);	
   		}
   		#_________________________________________________UNLEARN COUNTER___________________________________________________#
   		
   		if ($faultpropunl eq NA)
   		{
   			if($unlearn_value eq 'FF')
   			{
   			S_w2rep("\n The Unlearn conter value is $unlearn_value \n","blue");
            S_set_verdict(VERDICT_PASS);
   			}
   		}else
   		{
   			   			
   		}
   		#___________________________________________________WARNING LAMP______________________________________________________#
   		
   		if ($faultpropwl eq 1)
   		{
   			$lampvalue= CAN_get_Signal_value ( 1, 'Airbag_01', 'AB_Lampe' ); 
   			if($lampvalue eq 1)
   			{
   			S_w2rep("\n The lamp signal value is $lampvalue \n","blue");
            S_set_verdict(VERDICT_PASS);
   			}else
   			{
   			S_w2rep("\n The lamp signal value is $lampvalue \n","blue");
           # S_set_verdict(VERDICT_FAIL);
   			}
 			
   		}else
   		{
   		   	$lampvalue= CAN_get_Signal_value ( 1, 'Airbag_01', 'AB_Lampe' ); 	
   			if($lampvalue eq 0)
   			{
   			S_w2rep("\n The lamp signal value is $lampvalue \n","blue");
            S_set_verdict(VERDICT_PASS);
   			}else
   			{
   			S_w2rep("\n The lamp signal value is $lampvalue \n","blue");
            S_set_verdict(VERDICT_FAIL);
   			}   			
   		}
   		
   		#____________________________________________________________________________________________________________________________________#
   		
   		
   		return 1;
}
#########################################################################################
#-------------------------------------------------------------------------------
# FaultMonitoring_File_to_other
#-------------------------------------------------------------------------------
sub FaultMonitoring_File_to_other
{
	my @name = shift;
	my @data;
	return 1;
}


1;
