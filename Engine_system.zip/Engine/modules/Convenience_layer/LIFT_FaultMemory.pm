# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_FaultMemory;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################

use strict;
use warnings;
use Moose;
use Moose::Util::TypeConstraints;
use Data::Dumper;
use namespace::autoclean;
use Storable qw(dclone);
use File::Slurp;
use Excel::Writer::XLSX;

use LIFT_general;
use LIFT_FaultMemory::FaultEntry;
use LIFT_FaultMemory::FaultEntry::Bosch;
use LIFT_FaultMemory::FaultEntry::Disturbance;
use LIFT_FaultMemory::FaultEntry::Customer;
use LIFT_CD;
use LIFT_PD;
use LIFT_ProdDiag;
use Data::Dumper;
use XML::Simple;
use File::Basename;


$Data::Dumper::Indent = 0;
$Data::Dumper::Terse = 1;

require Exporter;

#our @ISA = qw(Exporter); # conflicts with BUILDARGS !

our @EXPORT = qw(
);

our ( $VERSION, $HEADER );

# global variables for Excel fault table creation
my $faultTableKeywords_href;
my ($format_Header, $format_Header2, $format_leftHeader, $format_centerHeader, $format_rightHeader, $format_Content, $format_leftContent, $format_centerContent, $format_rightContent, $format_whiteText, $format_dynEnvFail);


=head1 NAME

LIFT_FaultMemory 

=head1 SYNOPSIS

    use LIFT_FaultMemory
    
    # create a fault memory object of type 'Bosch' and reads the faults from ECU
    my $faultMemory_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    
    # get number of faults stored after read_fault_memory was called
    my $nbrOfFaults = $faultMemory_obj -> get_number_of_faults();

    # get the value of any fault attribute
    my $occurrenceCounter_AB1FP_OpenLine
            = $faultMemory_obj -> get_fault_attribute({
                                        'FaultName' => 'rb_sqm_AB1FP_flt',
                                        'Attribute' => 'OccurrenceCounter'});

    # Evaluate fauls with detailed status
    my $expectedFaults_href = {
        'mandatory' => {
            '1' => {
                'FaultName' => 'rb_sqm_SquibResistanceOpenBT1FD_flt',
                'DecodedStatus' => {'TestFailed' => 0,},                
            },
            '2' => {
                'FaultName' => 'rb_sqm_SquibResistanceOpenAB1FD_flt',
                'DecodedStatus' => {'TestFailed' => 1,},                
            }
        }
    };
    $faultMemory_obj -> evaluate_faults($expectedFaults_href);
    
    
    # Check for an empty fault memory
    $faultMemory_obj -> evaluate_faults({});
    
    # Evaluate mandatory, disjunction, and optional faults
    # (only presence in fault memory)
    my $expectedFaults_href = {
        'mandatory' => ['mand_fault_1', 'mand_fault_2', 'mand_fault_3'],
        'disjunction' => ['disjunction_fault_1', 'disjunction_fault_2'],
        'optional' => ['optional_fault_1'],
    };
    $faultMemory_obj -> evaluate_faults($expectedFaults_href);

    # check whether a fault is present in the fault memory
    $faultPresence = $faultMemory_obj -> check_fault_presence ('my_present_fault');

    # check presence for various faults at the same time
    $faultPresence_href = $faultMemory_obj -> check_fault_presence (
                                                        ['my_present_fault',
                                                         'dummy_fault'] );

=head1 DESCRIPTION

This fault memory class provides functions for reading and evaluating fault memories of various types.

Before calling any other functions, 'read_fault_memory' shall be called to initialize the class and read the fault memory from the ECU.

After that, all methods of the returned object can be called.

=cut

=head1 ATTRIBUTES

=over

=item Type

Supported types are: Bosch, Primary, Plant, Disturbance, Customer

Default if not given: Primary

=cut

my @fmTypes = qw( Bosch Primary Plant Disturbance Customer );

enum 'FMType', \@fmTypes;

has Type => ( is => "rw", isa => 'FMType', default => 'Primary', lazy => 1 );

has FaultEntriesHash => ( is => "rw", isa => 'HashRef[FaultEntry]' );

# in around BUILDARGS we can check the arguments (attributes) given to the contructor before the object is created
around BUILDARGS => sub{
    my $orig = shift;
    my $class = shift;
    my @args = @_;

    my $attributes_href;
    my $attributes = $args[0];
    my $attributesString = Dumper($attributes);
    my $callText = "LIFT_FaultMemory->new( $attributesString ) was called.";

    if( not defined $attributes ){
        S_w2log(4, "LIFT_FaultMemory->new() was called.\n");
        return $class->$orig();
    }

    if( ref( $attributes ) eq '' ){ # argument is a scalar
        $attributes_href = {Type => $attributes}; # convert into a hashref
    }
    else{
        $attributes_href = $attributes; # assume it is already a hashref
    }

    my $attributesRef = ref( $attributes_href );
    if( $attributesRef eq 'HASH' ) {
        my @attributesKeys = keys %$attributes_href;
        if( @attributesKeys > 1 ) {
            S_set_error("$callText Too many keys (@attributesKeys) given in argument hash. Only key 'Type' is allowed.", 109);
            return $class->$orig();
        }
        my $attributeKey = $attributesKeys[0];
        if( $attributeKey ne 'Type' ) {
            S_set_error("$callText Wrong key ($attributeKey) given in argument hash. Only key 'Type' is allowed.", 109);
            return $class->$orig();
        }
        my $type = $attributes_href->{$attributeKey};
        unless( grep { $_ eq $type } @fmTypes ) {
            S_set_error("$callText Wrong type ($type) given as argument. Only the following types are allowed: @fmTypes", 109);
            return $class->$orig();
        }
    }
    else{
        S_set_error("$callText Argument is a $attributesRef reference, but it must be a SCALAR or a HASH reference", 109);
        return $class->$orig();
    }

    S_w2log(4, "$callText\n");
    return $class->$orig($attributes_href);
};


=head1 METHODS

=head2 read_fault_memory

    $faultMemory_obj = read_fault_memory( [$type] );

Calls read_from_ECU to read the fault memory from the ECU by calling PD or CD services.
The service called depends on the fault memory type, which is specified when the fault memory object is created.
The returned faults are stored in fault entry objects. The attributes of the fault entry depend on the fault memory type.

=over

=item Type 'Primary'

calls PD_ReadFaultMemory (PRIMARY_FLT_MEM) or PRD_Read_Fault_Memory('PRIMARY') depending on test bench config
fault entry attributes: DTC, BoschFaultNbr, FaultName, RawStatus, DecodedStatus 

=item Type 'Bosch'

calls PD_ReadFaultMemory (BOSCH_FLT_MEM) or PRD_Read_Fault_Memory('BOSCH') depending on test bench config

fault entry attributes: DTC, BoschFaultNbr, FaultName, RawStatus, DecodedStatus, 
OccurrenceCounter, EventDebugData, ASIC_Temperature, GeneralStatus, Qualification_poweron_cycle, 
Dequalification_poweron_cycle, QualificationTime, DequalificationTime

=item Type 'Plant'

calls PD_ReadFaultMemory (PLANT_FLT_MEM) or PRD_Read_Fault_Memory('PLANT') depending on test bench config

fault entry attributes: DTC, BoschFaultNbr, FaultName, RawStatus, DecodedStatus

=item Type 'Disturbance'

calls PD_ReadFaultMemory (DISTURBANCE_FLT_MEM) or PRD_Read_Fault_Memory('DISTURBANCE') depending on test bench config

fault entry attributes: DTC, BoschFaultNbr, FaultName, RawStatus, DecodedStatus, 
EventDebugData, GeneralStatus, DisturbanceCounter

=item Type 'Customer'

calls CD_read_DTC('0x02', '0x04');
'0x02' is the service for reading DTC specified by UDS protocol (subfunction of service 0x19)
'0x04' is a fault status mask to read only DTCs which are actually stored in the fault memory ('Confirmed DTC' bit set in fault status)

fault entry attributes: DTC, FaultName, RawStatus, DecodedStatus 

=back

$faultMemory_obj is the return value of LIFT_FaultMemory -> new

On error: 0 (e.g. non-valid type given)

=cut

sub read_fault_memory{
    my $class = shift;
    my @args = @_;
    S_checkFunctionArguments( 'read_fault_memory( [ $type ] )', @args ) or return;

    my $type = shift @args;

    my $faultMemory_obj = $class -> new($type);
    
    $faultMemory_obj -> read_from_ECU();
    
    return $faultMemory_obj;
}

=head2 read_from_ECU

    $success = $faultMemory_obj -> read_from_ECU([$type]);
    
--- It is recommended to use 'read_fault_memory' to create the fault memory object and read from ECU at the same time ---

Reads the fault memory from the ECU by calling PD or CD services.
The service called depends on the fault memory type, which is specified when the fault memory object is created.
The returned faults are stored in fault entry objects. The attributes of the fault entry depend on the fault memory type.

See documentation of 'read_fault_memory' for details on fault memory types.

$faultMemory_obj is the return value of LIFT_FaultMemory -> new

Returns 1 on success, 0 otherwise

=cut

sub read_from_ECU {
    my $self = shift;

    my $success = 1;

    my $type = $self -> Type;


    # Part A: Read from ECU
    my $fault_href;
    my $fault_href_type;
    #IF fault type is Customer?
    if($type eq 'Customer'){ # Customer Diagnosis
        #IF-YES-START
        #STEP Read faults using CD
        $fault_href = CD_read_DTC('0x02', '0x20'); #all DTC in quali/dequali state
        $fault_href_type = 'HoA';
        $success = 0 if($fault_href -> {'response'} ne 'PR');
        #IF-YES-END
    }
    else { # Production Diagnosis
        #IF-NO-START
        #IF LIFT_ProdDiag is initialized?
        if ( $LIFT_ProdDiag::prodDiag_Initialized ) {
            #IF-YES-START
            #STEP Read faults using LIFT_ProdDiag and using type
            $fault_href = PRD_Read_Fault_Memory( $type );
            $fault_href_type = 'HoH';
            $success = 0 if(not defined $fault_href);
            #IF-YES-END
    	}
    	else{
            #IF-NO-START
            #STEP Read faults using LIFT_PD and using type
            # Optional parameter : nType - 0, 1, 3, 4, PLANT_FLT_MEM, PRIMARY_FLT_MEM, BOSCH_FLT_MEM, DISTURBANCE_FLT_MEM
            my $typeNumber = _get_fault_type_number($type);
            $fault_href = PD_ReadFaultMemory($typeNumber);
            $fault_href_type = 'HoA';
            $success = 0 if(not defined $fault_href);
            #IF-NO-END
    	}
        #IF-NO-END
    }

    return $success unless($success);

    # Part B: Add read fault entries
    S_w2log(4, "read_from_ECU: reset any existing fault entries before adding newly read faults");
    $self -> {FaultEntriesHash} = undef;

    #IF fault hash is HoH?
    if ( $fault_href_type eq 'HoH' ) {
        #IF-YES-START
        #LOOP-START Loop over numercally sorted keys of fault hash
        foreach my $entryIndex ( sort {$a <=> $b} keys %$fault_href ){
            #CALL _create_fault_entry_HoH for current key
            my $entry_obj = $self -> _create_fault_entry_HoH($fault_href, $entryIndex);
        }
        #LOOP-END last key reached?
        #IF-YES-END
	}
	else{
        #IF-NO-START
        #STEP Get number of faults read
        my $numberOfFaults = @{$fault_href -> {"DTC"}};
        #LOOP-START Loop over fault indices 0 .. number of faults - 1
        foreach my $entryIndex ( 0 .. $numberOfFaults-1 ) {
            #CALL _create_fault_entry_HoA for current fault index
            my $entry_obj = $self -> _create_fault_entry_HoA($fault_href, $entryIndex);
        }
        #LOOP-END last fault index reached?
        #IF-NO-END
	}

    #STEP Get fault names for fault table
    my $faultTableCsvString = '';
    my $all_entries_aref = $self -> get_faults_with_properties({});
    if( @$all_entries_aref == 0 ) {
        $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, '_NoFault', 'Detected');
    }
    foreach my $fault_entry_obj ( @$all_entries_aref ){
        $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $fault_entry_obj -> FaultName, 'Detected');
    }
    _add_faults_to_csv_file($faultTableCsvString);
    
    #STEP end
    return $success;
}

=head2 read_snapshot_data

    $success = $faultMemory_obj -> read_snapshot_data($faultName [, $snapshotRecordNbr]);

Function to read snapshot record data for a specific fault. 
It will trigger the UDS customer diagnosis service in FaultEntry::Customer for reading snapshot data.

Input parameters:

=over

=item Fault name

Give the fault name of which the data shall be read. 
If the snapshot for all faults present in the fault memory shall be read, give this parameter as 'all'.

=item Snapshot record number (OPTIONAL)

Give the snapshot record number that shall be read. Default is 255.

Note: Check in the project requirements how many snapshot data records are supported.

=back

B<Different use Cases>:

B<usecase 1: read snapshot data for one fault>:

    # Calls service to read snapshot data record 1 for rb_AB1FD_flt
    $faultMemory_obj -> read_snapshot_data('rb_AB1FD_flt');

B<usecase 2: read snapshot data for all faults>:

    # Calls service to read snapshot data record 2 for all faults present in the fault memory
    $faultMemory_obj -> read_snapshot_data('all', 2);

B<Return values>:

Returns 1 on success, 0 otherwise

=cut

sub read_snapshot_data {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'read_snapshot_data( $faultName [, $snapshotRecordNbr] )', @args ) or return;


    my $faultName = shift @args;
    my $snapshotRecordNbr = shift @args;

    if(not $self -> {Type} eq 'Customer'){
        S_set_error("Reading snapshot data is only applicable for customer fault entries.\n".
                    "Create fault memory of type 'Customer' first.");
        return;
    }
    
    my $success = 1;
    my @faultsNotSuccessFul;
    if(lc($faultName) eq 'all'){
        foreach my $faultEntryNbr (sort keys %{$self -> {FaultEntriesHash}}){
            my $successfulRead = $self -> {FaultEntriesHash} -> {$faultEntryNbr} -> read_snapshot_data($snapshotRecordNbr);
            unless($successfulRead){
               $success = 0;
               push(@faultsNotSuccessFul, $self -> {FaultEntriesHash}-> {$faultEntryNbr} -> FaultName()); 
            }
        }
    }
    else{
        if($main::opt_offline){
            $self -> {FaultEntriesHash} = undef; # reset fault entries hash
            my $fault_HoA = {   "fault_text" => [$faultName],
                                "DTC"        => [0x000112],
                                "state"      => ['0xAF'], };
            $self -> _create_fault_entry_HoA($fault_HoA, 0);      
        }

        my $faultEntryObject_aref = $self -> get_faults_with_properties({'FaultName' => $faultName});

        if(@{$faultEntryObject_aref} == 0){
            S_set_error("No fault entry found with given 'FaultName': $faultName");
            return;
        }

        my $faultEntryObject = $faultEntryObject_aref -> [0];
        my $successfulRead = $faultEntryObject -> read_snapshot_data($snapshotRecordNbr);
        unless($successfulRead){
           $success = 0;
           push(@faultsNotSuccessFul, $faultName); 
        }        
    }

    if($success == 0){
        S_set_error("Could not read snapshot data successfully for following faults: @faultsNotSuccessFul");
        return;
    }

    return 1;
}

=head2 read_extended_data

    $success = $faultMemory_obj -> read_extended_data($faultName [, $extendedRecordNbr]);

Function to read extended record data for a specific fault. 
It will trigger the UDS customer diagnosis service in FaultEntry::Customer for reading extended data.

Input parameters:

=over

=item Fault name

Give the fault name of which the data shall be read. 
If the extended for all faults present in the fault memory shall be read, give this parameter as 'all'.

=item extended record number (OPTIONAL)

Give the extended record number that shall be read. Default is 255.

Note: Check in the project requirements how many extended data records are supported.

=back

B<Different use Cases>:

B<usecase 1: read extended data for one fault>:

    # Calls service to read extended data record 1 for rb_AB1FD_flt
    $faultMemory_obj -> read_extended_data('rb_AB1FD_flt');

B<usecase 2: read extended data for all faults>:

    # Calls service to read extended data record 2 for all faults present in the fault memory
    $faultMemory_obj -> read_extended_data('all', 2);

B<Return values>:

Returns 1 on success, 0 otherwise

=cut

sub read_extended_data {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'read_extended_data( $faultName [, $extendedRecordNbr] )', @args ) or return;


    my $faultName = shift @args;
    my $extendedRecordNbr = shift @args;

    if(not $self -> {Type} eq 'Customer'){
        S_set_error("Reading extended data is only applicable for customer fault entries.\n".
                    "Create fault memory of type 'Customer' first.");
        return;
    }
    
    my $success = 1;
    my @faultsNotSuccessFul;
    if(lc($faultName) eq 'all'){
        foreach my $faultEntryNbr (sort keys %{$self -> {FaultEntriesHash}}){
            my $successfulRead = $self -> {FaultEntriesHash} -> {$faultEntryNbr} -> read_extended_data($extendedRecordNbr);
            unless($successfulRead){
               $success = 0;
               push(@faultsNotSuccessFul, $self -> {FaultEntriesHash}-> {$faultEntryNbr} -> FaultName()); 
            }
        }
    }
    else{
        if($main::opt_offline){
            $self -> {FaultEntriesHash} = undef; # reset fault entries hash
            my $fault_HoA = {   "fault_text" => [$faultName],
                                "DTC"        => [0x000112],
                                "state"      => ['0xAF'], };
            $self -> _create_fault_entry_HoA($fault_HoA, 0);      
        }

        my $faultEntryObject_aref = $self -> get_faults_with_properties({'FaultName' => $faultName});

        if(@{$faultEntryObject_aref} == 0){
            S_set_error("No fault entry found with given 'FaultName': $faultName");
            return;
        }

        my $faultEntryObject = $faultEntryObject_aref -> [0];
        my $successfulRead = $faultEntryObject -> read_extended_data($extendedRecordNbr);
        unless($successfulRead){
           $success = 0;
           push(@faultsNotSuccessFul, $faultName); 
        }        
    }

    if($success == 0){
        S_set_error("Could not read extended data successfully for following faults: @faultsNotSuccessFul");
        return;
    }

    return 1;
}

=head2 get_snapshot_data_value_raw

    $success = $faultMemory_obj -> get_snapshot_data_value_raw($faultName, $dataKey [, $snapshotRecordNbr, $format]);

Note: Before calling this function, 'read_snapshot_data' must be called.

The decoded value of a specific snapshot data element for a specific fault entry in a specific record number can be read.

Prerequisites:

=over

=item The given fault has to be present in the fault memory

=item The given data key has to be present in the snapshot data record (see project specific 'Mapping_SnapshotData')

=item The given snapshot record number must be valid

=back

Input parameters:

=over

=item Fault Name

Name of fault for which snapshot data value shall be obtained

=item Data Key

Data element in snapshot data record for which the value shall be returneds

=item Snapshot Record Nbr (OPTIONAL)

Give the snapshot record number that shall be read. Default is 255.

Note: Check in the project requirements how many snapshot data records are supported. 
The same record number should be read previously with read_snapshot_data()

=item Format (OPTIONAL)

Default format for return value is 'hex'

Alternative option is 'dec'

=back

B<Return values:>

Value as integer or array depending on data element
Undef in case of error

=cut

sub get_snapshot_data_value_raw {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'get_snapshot_data_value_raw( $faultName, $dataKey [, $snapshotRecordNbr, $format] )', @args ) or return;


    my $faultName = shift @args;
    my $dataKey = shift @args;
    my $snapshotRecordNbr = shift @args;
    my $format = shift @args;
    if(not defined $format){
        $format = 'hex';
    }

    if(not $self -> {Type} eq 'Customer'){
        S_set_error("Snapshot data is only applicable for customer fault entries.\n".
                    "Create fault memory of type 'Customer' first.");
        return;
    }

    if($main::opt_offline){
        $self -> {FaultEntriesHash} = undef; # reset fault entries hash
        my $fault_HoA = {   "fault_text" => [$faultName],
                            "DTC"        => [0x000112],
                            "state"      => ['0xAF'], };
        $self -> _create_fault_entry_HoA($fault_HoA, 0);      
    }

    my $faultEntryObject_aref = $self -> get_faults_with_properties({'FaultName' => $faultName});
    if(@{$faultEntryObject_aref} == 0){
        S_set_error("No fault entry found with given 'FaultName': $faultName");
        return;
    }
    my $faultEntryObject = $faultEntryObject_aref -> [0];
    my $value = $faultEntryObject -> get_snapshot_data_value_raw($dataKey, $snapshotRecordNbr, $format);

    return $value;
}

=head2 get_extended_data_value_raw

    $success = $faultMemory_obj -> get_extended_data_value_raw($faultName, $dataKey [, $extendedRecordNbr, $format]);

Note: Before calling this function, 'read_extended_data' must be called.

The decoded value of a specific extended data element for a specific fault entry in a specific record number can be read.

Prerequisites:

=over

=item The given fault has to be present in the fault memory

=item The given data key has to be present in the extended data record (see project specific 'Mapping_ExtendedData')

=item The given extended record number must be valid

=back

Input parameters:

=over

=item Fault Name

Name of fault for which extended data value shall be obtained

=item Data Key

Data element in extended data record for which the value shall be returns

=item extended Record Nbr (OPTIONAL)

Give the extended record number that shall be read. Default is 255.

Note: Check in the project requirements how many extended data records are supported. 
The same record number should be read previously with read_extended_data()

=item Format (OPTIONAL)

Default format for return value is 'hex'

Alternative option is 'dec'

=back

B<Return values:>

Value as integer or array depending on data element
Undef in case of error

=cut

sub get_extended_data_value_raw {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'get_extended_data_value_raw( $faultName, $dataKey [, $extendedRecordNbr, $format] )', @args ) or return;


    my $faultName = shift @args;
    my $dataKey = shift @args;
    my $extendedRecordNbr = shift @args;
    my $format = shift @args;
    if(not defined $format){
        $format = 'hex';
    }

    if(not $self -> {Type} eq 'Customer'){
        S_set_error("extended data is only applicable for customer fault entries.\n".
                    "Create fault memory of type 'Customer' first.");
        return;
    }

    if($main::opt_offline){
        $self -> {FaultEntriesHash} = undef; # reset fault entries hash
        my $fault_HoA = {   "fault_text" => [$faultName],
                            "DTC"        => [0x000112],
                            "state"      => ['0xAF'], };
        $self -> _create_fault_entry_HoA($fault_HoA, 0);      
    }

    my $faultEntryObject_aref = $self -> get_faults_with_properties({'FaultName' => $faultName});
    if(@{$faultEntryObject_aref} == 0){
        S_set_error("No fault entry found with given 'FaultName': $faultName");
        return;
    }
    my $faultEntryObject = $faultEntryObject_aref -> [0];
    my $value = $faultEntryObject -> get_extended_data_value_raw($dataKey, $extendedRecordNbr, $format);

    return $value;
}


=head2 get_snapshot_data_value_decoded

    $success = $faultMemory_obj -> get_snapshot_data_value_decoded($faultName, $dataKey [, $snapshotRecordNbr]);

Note: Before calling this function, 'read_snapshot_data' must be called.

The decoded value of a specific snapshot data element for a specific fault entry in a specific record number can be read.

Prerequisites:

=over

=item The given fault has to be present in the fault memory

=item The given data key has to be present in the snapshot data record (see project specific 'Mapping_SnapshotData')

=item The given snapshot record number must be valid

=back

Input parameters:

=over

=item Fault Name

Name of fault for which snapshot data value shall be obtained

=item Data Key

Data element in snapshot data record for which the value shall be returneds

=item Snapshot Record Nbr (OPTIONAL)

Give the snapshot record number that shall be read. Default is 255.

Note: Check in the project requirements how many snapshot data records are supported.
The same record number should be read previously with read_snapshot_data()

=back

B<Return values:>

Value as string or array depending on data element
Undef in case of error

=cut

sub get_snapshot_data_value_decoded {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'get_snapshot_data_value_decoded( $faultName, $dataKey [, $snapshotRecordNbr] )', @args ) or return;


    my $faultName = shift @args;
    my $dataKey = shift @args;
    my $snapshotRecordNbr = shift @args;

    if(not $self -> {Type} eq 'Customer'){
        S_set_error("Snapshot data is only applicable for customer fault entries.\n".
                    "Create fault memory of type 'Customer' first.");
        return;
    }

    if($main::opt_offline){
        $self -> {FaultEntriesHash} = undef; # reset fault entries hash
        my $fault_HoA = {   "fault_text" => [$faultName],
                            "DTC"        => [0x000112],
                            "state"      => ['0xAF'], };
        $self -> _create_fault_entry_HoA($fault_HoA, 0);      
    }

    my $faultEntryObject_aref = $self -> get_faults_with_properties({'FaultName' => $faultName});
    if(@{$faultEntryObject_aref} == 0){
        S_set_error("No fault entry found with given 'FaultName': $faultName");
        return;
    }
    my $faultEntryObject = $faultEntryObject_aref -> [0];
    my $value = $faultEntryObject -> get_snapshot_data_value_decoded($dataKey, $snapshotRecordNbr);

    return $value;
}

=head2 get_extended_data_value_decoded

    $success = $faultMemory_obj -> get_extended_data_value_decoded($faultName, $dataKey [, $extendedRecordNbr]);

Note: Before calling this function, 'read_extended_data' must be called.

The decoded value of a specific extended data element for a specific fault entry in a specific record number can be read.

Prerequisites:

=over

=item The given fault has to be present in the fault memory

=item The given data key has to be present in the extended data record (see project specific 'Mapping_ExtendedData')

=item The given extended record number must be valid

=back

Input parameters:

=over

=item Fault Name

Name of fault for which extended data value shall be obtained

=item Data Key

Data element in extended data record for which the value shall be returneds

=item extended Record Nbr (OPTIONAL)

Give the extended record number that shall be read. Default is FF.

Note: Check in the project requirements how many extended data records are supported.
The same record number should be read previously with read_extended_data()

=back

B<Return values:>

Value as string or array depending on data element
Undef in case of error

=cut

sub get_extended_data_value_decoded {
    my $self = shift;
    my @args = @_;

    S_checkFunctionArguments( 'get_extended_data_value_decoded( $faultName, $dataKey [, $extendedRecordNbr] )', @args ) or return;


    my $faultName = shift @args;
    my $dataKey = shift @args;
    my $extendedRecordNbr = shift @args;

    if(not $self -> {Type} eq 'Customer'){
        S_set_error("extended data is only applicable for customer fault entries.\n".
                    "Create fault memory of type 'Customer' first.");
        return;
    }

    if($main::opt_offline){
        $self -> {FaultEntriesHash} = undef; # reset fault entries hash
        my $fault_HoA = {   "fault_text" => [$faultName],
                            "DTC"        => [0x000112],
                            "state"      => ['0xAF'], };
        $self -> _create_fault_entry_HoA($fault_HoA, 0);      
    }

    my $faultEntryObject_aref = $self -> get_faults_with_properties({'FaultName' => $faultName});
    if(@{$faultEntryObject_aref} == 0){
        S_set_error("No fault entry found with given 'FaultName': $faultName");
        return;
    }
    my $faultEntryObject = $faultEntryObject_aref -> [0];
    my $value = $faultEntryObject -> get_extended_data_value_decoded($dataKey, $extendedRecordNbr);

    return $value;
}

=head2 write_to_file

    $filename_stored = $faultMemory_obj -> write_to_file( [ $filename_to_store ] );

    Error :
        - when given $filename_to_store is already existing
        - when path of given $filename_to_store cant be created
        - when XML-file storing function not successful

=cut

sub write_to_file {
    my $self = shift;
    my @args = @_;
    S_checkFunctionArguments( 'write_to_file( [ $filename_to_store ] )', @args ) or return;
    my $filename_to_store = shift @args;

    unless ( defined $filename_to_store ) {
       $filename_to_store = $main::REPORT_PATH. "/LIFT_FaultMemory_Dump_" .S_get_date_extension() .".xml";
    }
    
    my $file_name_path = dirname $filename_to_store;

    unless ( -d dirname $file_name_path ) {
        unless ( make_path $file_name_path ) {
            S_set_error("Could not create path '$file_name_path'");
            return;
        }
        S_w2log( 5, " Path created : '$file_name_path' \n", 'grey' );
    }

    if( -f $filename_to_store )  {
        S_set_error(" XML-file which have to be stored is already existing ('$filename_to_store') -> to be removed before calling write_to_file");
        return;
    }

    S_w2log( 3 , " write_to_file: calling XMLout() in order to store file '$filename_to_store'\n" );
    unless ( XMLout(
                        $self,
                        rootname   => 'LIFT_FaultMemory_Dump',
                        outputfile => $filename_to_store, 
                        AttrIndent => 1, XMLDecl    => 1,
                        #                     keyattr => [ ] ,
                    ) )
    {
        S_set_error("Error while creating XML-file '$filename_to_store' : $!");
        return;
    }

    unless( -f $filename_to_store ) {
        S_set_error( "XMLout function did not stored the filename '$filename_to_store' \n" );
        return;
    }

    #STEP return filename_stored
    return $filename_to_store;
}


=head2 load_from_file

    $loaded_faultMemory_obj = LIFT_FaultMemory -> load_from_file( $filename_to_load );
    
    Error :
        - when given $filename_to_load is not existing

=cut

sub load_from_file {
    my $class = shift;
    my @args = @_;
    S_checkFunctionArguments( 'load_from_file( $filename_to_load )', @args ) or return;

    my $filename_to_load = shift @args;
    unless( -f $filename_to_load ) {
        S_set_error("Give file doesnt exist '$filename_to_load' ");
        return;
    }
    
    my $obj_data_from_file;
    S_w2log(3, " load_from_file: calling  XMLin( $filename_to_load, ForceArray => 1, ) \n");
    unless ( $obj_data_from_file = XMLin( $filename_to_load, ForceArray => 1, ) )  {
        S_set_error("Error while reading XML-file '$filename_to_load' : $!");
        return;
    }
 
 
    #
    # BLESS HERE 
    #
    bless $obj_data_from_file, $class;
 
    #STEP return FaultMemory object
    return $obj_data_from_file;
}



=head2 get_number_of_faults

    $numberOfFaults = $faultMemory_obj -> get_number_of_faults();

Returns the number of faults which are currently stored in the fault memory object.
Before calling $faultMemory_obj -> read_from_ECU() the number of faults will be zero.
If the fault memory is empty, the number of faults will be zero.

=cut

sub get_number_of_faults {
    my $self = shift;

    my $numberOfFaults;

    #IF Are any fault entries defined?
    if(defined $self -> {FaultEntriesHash}){
        #IF-YES-START
        #STEP Get number of faults
        $numberOfFaults = keys %{$self -> {FaultEntriesHash}};
        #IF-YES-END
    }
    else {
        #IF-NO-START
        #STEP number of faults = 0
        S_w2log(4, "No faults defined yet - maybe read_from_ECU has not been called? \n");
        $numberOfFaults = 0;
        #IF-NO-END
    }

    #STEP return number of faults
    return $numberOfFaults;
}

=head2 check_fault_presence

Option 1: Check presence of one fault

    my $faultPresence = $faultMemory_object -> check_fault_presence ($faultName);

Option 2: Check presence of various faults

    my $faultPresence_href = $faultMemory_object -> check_fault_presence ($faultNames_aref);

This function returns the presence of one or more faults in the fault memory object.

It is not relevant whether the fault is qualified or has a specific state - it only has to be there.

The function can be called either for one or for various faults.

The return value will differ depending on the type of input (scalar or array reference).



Option 1: Check presence of one fault

=over

=item parameter 'Fault name'

Fault name should be given as a scalar input to the function.

E.g.: 'rb_AB1FD_OpenLine'

=item return value 'Fault presence'

On success, either 'present' or 'not_present' will be returned as scalar string.

=back

Option 2: Check presence of various faults

=over

=item parameter 'Fault names'

Fault names should be given as an array reference

E.g.: ['rb_AB1FD_OpenLine', 'rb_AB1FP_OpenLine', 'rb_HOODP_OpenLine']

=item return value 'Fault presence'

On success, a hash reference with the information about fault presence will be returned

E.g.:
    $return_href = {'rb_AB1FD_OpenLine' => 'present',
                    'rb_AB1FP_OpenLine' => 'not_present',
                    'rb_HOODP_OpenLine' => 'present,};

=back

In case there is no fault name given as input parameter (either scalar or aref), the function will set an error and return nothing.

=cut

sub check_fault_presence {
    
    my $self = shift; # object reference
    my $faultName_inputPar = shift;

    unless(defined $faultName_inputPar){
        S_set_error("check_fault_presence : Missing mandatory parameter fault name!\n"
                    ."Give either single fault name as scalar or list of fault names as array reference!");
        return;
    }

    # Check whether function was called with scalar or array reference as input parameter
    my $faultNames_aref;
    if(not ref($faultName_inputPar)){
        # input par is not a reference, but a scalar
        push(@{$faultNames_aref}, $faultName_inputPar);
    }
    elsif(ref($faultName_inputPar) eq 'ARRAY'){
        $faultNames_aref = $faultName_inputPar;
    }
    else{
        my $ref = ref($faultName_inputPar);
        S_set_error("check_fault_presence: Parameter fault name is given as '$ref' reference.\n"
                    ."Only scalar or array reference is supported!");
        return;
    }

    my $returnValues_href;
    foreach my $faultName (@{$faultNames_aref}){
        my $entry_obj_aref = $self -> get_faults_with_properties( {'FaultName' => $faultName} );
        if(@{$entry_obj_aref}){
            $returnValues_href -> {$faultName} = 'present';
        }
        else{
            $returnValues_href -> {$faultName} = 'not_present';            
        }   
    }
    
    if(not ref($faultName_inputPar)){ #return scalar value if input argument was scalar
        return $returnValues_href -> {$faultName_inputPar};
    }

    return $returnValues_href; #return hash ref with presence of all requested faults
}


=head2 get_fault_attribute

    $attributeValue = $faultMemory_obj -> get_fault_attribute({'DTC' => $dtc,           # or )
                                                    'BoschFaultNbr' => $boschFaultNbr,  # or )
                                                    'FaultName' => $faultName,          #    ) and
                                                    'Attribute' => $attributeLabel});   #

Returns value of the requested attribute for a certain fault.
The format of the input parameter is hash with information about the fault as well as the attribute label.

Following are the keys to specify the fault (at least one must be given):

=over

=item 'DTC'

$dtc in decimal or hex format to specify the fault
'DTC' is not unique - it might be there various times

=item 'BoschFaultNbr'

$boschFaultNbr integer Bosch fault ID is unique for each fault to specify the fault

=item 'FaultName'

$faultName: String with name of fault as displayed in fault memory

=back

The attribute label will be specified with the key:

=over

=item 'Attribute'

$attributeLabel is a string of the information that shall be returned for the specified fault.
The available attributes for each fault entry depend on the fault memory type.
The attributes are described in the documentation of L</"read_fault_memory">

=back

Returns attribute value if successful and 0 otherwise.

Reasons for not being successful:

=over

=item 'Attribute' not given in parameter hash

=item no fault entry found that matches the specified fault

=item given 'Attribute' does not exist for fault memory type

=cut

sub get_fault_attribute {
    my $self = shift;
    my $parameter_href = shift;

    #STEP get mandatory parameter 'Attribute'
    my $attribute = $parameter_href -> {Attribute};
    #IF parameter 'Attribute' does not exist
    unless(defined $attribute){
        #IF-YES-START
        #STEP return with error missing parameter
        S_set_error("Missing mandatory parameter 'Attribute'", 110);
        return 0;
        #IF-YES-END
    }
    #IF-NO-START

    #STEP get fault details
    my $searchParams_href;
    $searchParams_href  -> {BoschFaultNbr} = $parameter_href -> {BoschFaultNbr};
    $searchParams_href -> {DTC} = $parameter_href -> {DTC};
    $searchParams_href -> {FaultName} = $parameter_href -> {FaultName};

    #IF Is no fault info defined?
    if(not defined $searchParams_href  -> {BoschFaultNbr} and not defined $searchParams_href -> {DTC} and not defined $searchParams_href -> {FaultName}){
        #IF-YES-START
        #STEP set error for missing parameter and return 0
        S_set_error("get_fault_attribute : Specify fault either by giving: 'DTC', 'FaultName', or 'BoschFaultNbr'.", 110);
        return 0;
        #IF-YES-END
    }
    #IF-NO-START

    #IF Is offline mode?
    if($main::opt_offline){
        $self -> {FaultEntriesHash} = undef; # reset fault entries hash
        #IF-YES-START
        #STEP create a dummy fault that matches fault details
        my $faultNum = $searchParams_href  -> {BoschFaultNbr}  // 1;
        my $dtc = $searchParams_href -> {DTC} // 1;
        my $faultName = $searchParams_href -> {FaultName} // 'dummy_fault_offline';
        my $fault_HoA = {
            "fltnum"                => [$faultNum],
            "fault_text"            => [$faultName],
            "DTC"                   => [sprintf("%02x", $dtc)],
            "state"                 => ['0xAF'],
            "DisturbanceState"      => ['0x01'],
            "GeneralState"          => ['0x69'],
            "EventDebug"         => ['0x01'],    # Holds event values in DFM and BFM respectively
            "OccuranceCounter"   => [1],
            "DisturbanceCounter" => [2],
            "QualificationTime"             => [2],
            "DequalificationTime"           => [1],
            "Qualification_poweron_cycle"   => [2],
            "Dequalification_poweron_cycle" => [2],
            "ASIC_Temperature" => [48],
        };
        $self -> _create_fault_entry_HoA($fault_HoA, 0);
        #IF-YES-END
    }
    #IF-NO-START
    #IF-NO-END

    #CALL _find_matching_fault_entry
    my $entry_obj_aref = $self -> _find_matching_fault_entry($searchParams_href);
    #IF Is more than one fault object found?
    if( @{$entry_obj_aref} > 1){
        #IF-YES-START
        #STEP log error and return nothing
        S_set_error("More than one fault entry found for given parameters. Try unique Bosch fault number instead of DTC!");
        return 0;
        #IF-YES-END
    }
    #IF-NO-START
    #IF Are 0 fault objects found?
    elsif(@{$entry_obj_aref} == 0){
        #IF-YES-START
        #STEP log error and return nothing
        S_set_error("No fault entry found for given parameters. Create fault and call 'read_from_ECU' before reading fault attributes!");
        return 0;
        #IF-YES-END
    }
    #IF-NO-START

    #STEP Get entry object reference
    my $entry_obj = $entry_obj_aref -> [0];

    #STEP check whether 'Attribute' exists for entry object
    my $allAttributeNames_href = _get_list_of_object_attributes($entry_obj);
    my $attributeValue;
    #IF Is attribute existing?
    if(exists $allAttributeNames_href -> {$attribute}){
        #IF-YES-START
        #STEP get attribute value
        $attributeValue = $entry_obj -> $attribute;
        #IF-YES-END
    }
    else {
        #IF-NO-START
        #STEP set error and return 0
        my $type = $self -> Type;
        S_set_error("Given attribute '$attribute' is not defined for fault entry of type '$type'");
        return 0;
        #IF-NO-END
    }

    #IF-NO-END
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END

    #STEP return attribute value
    return $attributeValue;
}

=head2 evaluate_specific_faults

    $verdict = $faultMemory_obj -> evaluate_specific_faults( $expected_faults_href
                                                    [, $eval_keyword ] );

Function evaluates only status of given faults.
Additional faults will not be considered at all.
If no fault is given, function throws error.
Give teststeps if wanted

Apart from presence of the fault in the fault memory, all attributes of a fault can be given with an expected value.

The verdict for a specific fault will only be passed if the fault is present and all other given attributes are also in the expected state.

B<Input parameters:>

=over

=item $expected_faults_href

This input parameter is a hash reference which contains specific expected faults with expected properties. It can be one or more faults.

=item $eval_keyword

If given then S_teststep_expected and S_teststep_detected are called.
That means the testcase should have a teststep (S_teststep) with the SAME eval keyword, so that the expected and detected values can be linked.

It is recommended to use this feature as it will create a good overview of the evaluation in the DOORS TR when uploading the TurboLIFT results.

Example: Give each expected fault as a hash of all properties that must be fulfilled

 $expected_faults_href = {
       'rb_sqm_SquibResistanceOpen_AB1FD'  # expected fault 1 => {
            
             'DecodedStatus' => { # fault property
                 'TestFailed' => 0, # fault should be dequalified
                 'WarningLamp' => 1, # fault should set warning lamp
             },
         },                 
         'rb_sqm_SquibResistanceOpen_AB2FD'  # expected fault 2 => {
              'DecodedStatus' => { # fault property
                 'TestFailed' => 0, # fault should be dequalified
                 'WarningLamp' => 1, # fault should set warning lamp
             },
         }
     

=back

B<Use Case: >
 
    # Create AB1FD open line fault...

    S_teststep("Read Bosch fault memory after fault qualification",
                'AUTO_NBR',
                'read_Bosch_after_quali');
    
    my $faultMemObject = LIFT_FaultMemory -> read_fault_memory('Bosch');

    my $expectedFaults = {
        'rb_sqm_SquibResistanceOpen_AB1FD' => {
                'DecodedStatus' => { 'TestFailed' => 1,}, # fault in qualified state
            }
    };

    my $verdict = $faultMemObject -> evaluate_specific_faults($expectedFaults, # expected faults
                                        'read_Bosch_after_quali') # eval keyword

B<Error Return:>

0: mandatory parameter expected faults href not given

0: empty expected faults href is given

on success: evaluation verdict -> 'VERDICT_PASS' or 'VERDICT_FAIL'

=cut

sub evaluate_specific_faults {
    
    my $self = shift;
    my @args = @_;

    #STEP Check whether mandatory parameter fault properties is defined
    return 0 unless S_checkFunctionArguments( 'LIFT_FaultMemory::evaluate_specific_faults ( $expected_faults_href [, $evalKeyword])', @args );
    my $expected_faults_href = shift @args;
    my $evalKeyword = shift @args;
    
    if (!keys %{$expected_faults_href}){
        S_set_error("hash ref for expected faults is empty , this function checks for specific fault, for evaluation of empty fault memory , please use 'evaluate_faults' ");
        return 0;
    }

    #STEP get expected specific faults given to validate
    my $verdict = evaluate_mandatory_faults( $self, $expected_faults_href, {},  $evalKeyword );

    return $verdict;
}

=head2 evaluate_faults

    $verdict = $faultMemory_obj -> evaluate_faults( $expected_faults_href
                                                    [, $eval_keyword ] );

This function evaluates the faults actually stored in fault memory against the faults which are expected to be stored.

Apart from presence of the fault in the fault memory, all attributes of a fault can be given with an expected value.

The verdict for a specific fault will only be passed if the fault is present and all other given attributes are also in the expected state.

At the end, it will be checked whether any additional unexpected faults are present in the fault memory.
If this is the case, the verdict will be 'VERDICT_FAIL'.

B<Input parameters:>

=over

=item $expected_faults_href

This input parameter is a hash reference which contains all the expected mandatory, disjunction, and optional faults.

B<mandatory:> fault has to be present with specified properties in fault memory

B<disjunction:> at least one of the faults has to be present with specified properties in fault memory

B<optional:> faults can be present or not present with any properties - no fail.
In addition to the given optional faults the 'TEMP_OPTIONAL_FAULTS' defined in project constants will be considered.

Option 1: Give each expected fault as a hash of all properties that must be fulfilled

 $expected_faults_href = {
     'mandatory' => { # fault category
         'FaultName' => { # expected mandatory fault 1
             'DecodedStatus' => { # fault property
                 'TestFailed' => 0, # fault should be dequalified
                 'WarningLamp' => 1, # fault should set warning lamp
             },
         },                 
         'FaultName' => { # expected mandatory fault 2
              ...,
         }
     }
     'disjunction' => {
       'FaultName'=> { # expected disjunction fault 1
             
             'DecodedStatus' => {
                 'TestFailed' => 1,
             },
         },
         'FaultName' => { # expected disjunction fault 2
             
             'DecodedStatus' => {
                 'WarningLamp' => 1,
             },
         },
     },
     'optional' => { # only attributes FaultName, DTC, BoschFaultNbr allowed and only 1 attribute per fault
        'FaultName' => {
             ...,
         },
         'FaultName' => {
              ...,
         },
     },
 };

Option 2: Give just the expected fault names in a list

 $expected_faults_href = {
     'mandatory' => [ 'mandatory_fault_1', 'mandatory_fault_2 ],
     'disjunction' => [ 'disjunction_1', 'disjunction_2' ],
     'optional' => [ 'optional_fault_1' ],
 };

Option 3: Check for an empty fault memory

 $expected_faults_href = {};

=item $eval_keyword

If given then S_teststep_expected and S_teststep_detected are called.
That means the testcase should have a teststep (S_teststep) with the SAME eval keyword, so that the expected and detected values can be linked.

It is recommended to use this feature as it will create a good overview of the evaluation in the DOORS TR when uploading the TurboLIFT results.

=back

B<Use Case: >

    # Create AB1FD open line fault...

    S_teststep("Read Bosch fault memory after fault qualification",
                'AUTO_NBR',
                'read_Bosch_after_quali');
    
    my $faultMemObject = LIFT_FaultMemory -> read_fault_memory('Bosch');

    my $expectedFaults = {
        'rb_sqm_SquibResistanceOpen_AB1FD' => {
                'DecodedStatus' => { 'TestFailed' => 1,}, # fault in qualified state
            }
    };

    my $verdict = $faultMemObject -> evaluate_faults($expectedFaults, # expected faults
                                        'read_Bosch_after_quali') # eval keyword

B<Error Return:>

0: mandatory parameter expected faults href not given

on success: evaluation verdict -> 'VERDICT_PASS' or 'VERDICT_FAIL'

=cut

sub evaluate_faults{
  
    my $self = shift;
    my @args = @_;

    #STEP Check whether mandatory parameter fault properties is defined
    return 0 unless S_checkFunctionArguments( 'LIFT_FaultMemory::evaluate_faults ( $expected_faults_href [, $evalKeyword])', @args );
    my $expected_faults_href = shift @args;
    my $evalKeyword = shift @args;
    
    my $faultEvaluationSummary_href = {};

    ### EVALUATION OF MANDATORY FAULTS ###

    #STEP get expected mandatory faults
    my $verdict = evaluate_mandatory_faults( $self, $expected_faults_href -> {'mandatory'}, $faultEvaluationSummary_href,  $evalKeyword );

    ### EVALUATION OF DISJUNCTION FAULTS ###
    my $disjunction_verdict = evaluate_disjunction_faults( $self, $expected_faults_href -> {'disjunction'}, $faultEvaluationSummary_href,  $evalKeyword );
    $verdict = $disjunction_verdict if $disjunction_verdict eq 'VERDICT_FAIL';

    ### EVALUATION OF OPTIONAL FAULTS ###
    evaluate_optional_faults( $self, $expected_faults_href -> {'optional'}, $faultEvaluationSummary_href,  $evalKeyword );

    ### ADDITIONAL FAULTS ###
    my $additional_verdict = evaluate_additional_faults( $self, $faultEvaluationSummary_href,  $evalKeyword );
    $verdict = $additional_verdict if $additional_verdict eq 'VERDICT_FAIL';

    _create_HTML_table_fault_eval_summary($faultEvaluationSummary_href, $self -> Type);

    return $verdict;
}

sub evaluate_mandatory_faults{
    my $self = shift;
    my $mandatoryFaults_href = shift;
    my $faultEvaluationSummary_href = shift;
    my $evalKeyword = shift;
    
    $mandatoryFaults_href = {} unless(defined $mandatoryFaults_href);
    my $mandatoryFaultsCopy_href = dclone($mandatoryFaults_href); # using a copy to avoid any change on the input argument

    #IF Are mandatory faults given as array?
    if(ref($mandatoryFaultsCopy_href) eq 'ARRAY'){
        #IF-YES-START
        #CALL _convert_fault_name_aref_to_href
        $mandatoryFaultsCopy_href = _convert_fault_name_aref_to_href($mandatoryFaultsCopy_href);
        #IF-YES-END
    }
        #IF-NO-START
        #IF-NO-END

    my $faultTableCsvString = '';
    my $mandatoryVerdict = 'VERDICT_PASS';
    foreach my $thisFaultName (keys %{$mandatoryFaultsCopy_href}){
        my $mandatoryFaultProperty_href = $mandatoryFaultsCopy_href -> {$thisFaultName};
        $mandatoryFaultProperty_href -> {'FaultName'} = $thisFaultName;
        $faultEvaluationSummary_href -> {$thisFaultName} -> {'FaultName'} = $thisFaultName;
        $faultEvaluationSummary_href -> {$thisFaultName} -> {'ExpectedType'} = 'mandatory';   

        my ($faultsWithProperties_aref, $propertyDetails) = $self -> get_faults_with_properties($mandatoryFaultProperty_href, 1);
        my $thisFaultPropertyNumber;
        my ($expectedPropertiesString, $detectedPropertiesString, $mismatchPropertiesString);
        foreach my $faultNumber(%{$propertyDetails}){
            next unless(exists $propertyDetails -> {$faultNumber} -> {'FaultName'});
            if($propertyDetails -> {$faultNumber} -> {'FaultName'} -> {'detected'} eq $thisFaultName){
                $thisFaultPropertyNumber = $faultNumber;
                ($expectedPropertiesString, $detectedPropertiesString, $mismatchPropertiesString)= _fault_properties_to_string($propertyDetails -> {$thisFaultPropertyNumber}, ['FaultName', 'DTC', 'BoschFaultNbr']);
                last;
            }
        }
        
        my $numberOfFaults = @{$faultsWithProperties_aref};
        if($numberOfFaults == 0){
            S_w2log(3, "Mandatory fault '$thisFaultName' not stored with given properties\n");
            S_set_verdict(VERDICT_FAIL);
            $mandatoryVerdict = 'VERDICT_FAIL';
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'expected'} = 'present';
            if(defined $thisFaultPropertyNumber){
                S_teststep_expected("Fault '$thisFaultName' : $expectedPropertiesString", "$evalKeyword") if(defined $evalKeyword);
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'OtherProperties'} = $propertyDetails -> {$thisFaultPropertyNumber};
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'present';   
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $self -> get_fault_attribute({'FaultName' => $thisFaultName,
                                                                                                            'Attribute' => 'DTC'});
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $self -> get_fault_attribute({'FaultName' => $thisFaultName,
                                                                                                            'Attribute' => 'BoschFaultNbr'});

                S_teststep_detected("Fault '$thisFaultName' stored in fault memory, but not all properties matching:\n".
                                    "$detectedPropertiesString", "$evalKeyword") if(defined $evalKeyword);
                S_teststep_mismatch("Fault '$thisFaultName': $mismatchPropertiesString") if(defined $evalKeyword);
                S_w2rep("\n");
                $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $thisFaultName, 'Properties_wrong');
            }
            else{
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'not present';                
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $mandatoryFaultProperty_href -> {'DTC'} // 'n/a';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $mandatoryFaultProperty_href -> {'BoschFaultNbr'} // 'n/a';
                S_teststep_expected("Fault '$thisFaultName' stored in fault memory", "$evalKeyword") if(defined $evalKeyword);
                S_teststep_detected("Fault '$thisFaultName' not present in fault memory", "$evalKeyword") if(defined $evalKeyword);
                S_teststep_mismatch("Fault '$thisFaultName' : (EXP) Stored <=> Not stored (DET)") if(defined $evalKeyword);
                S_w2rep("\n");
                $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $thisFaultName, 'Missing');
            }

            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Verdict'} = 'VERDICT_FAIL';
        }
        elsif($numberOfFaults == 1){
            S_w2log(4, "Mandatory fault '$thisFaultName' stored with given properties\n");
            my $detectedStoredFault_obj = $faultsWithProperties_aref -> [0];
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $detectedStoredFault_obj -> DTC;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $detectedStoredFault_obj -> BoschFaultNbr // 'n/a';
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'expected'} = 'present';
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'present';
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'OtherProperties'} = $propertyDetails -> {$thisFaultPropertyNumber};
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Verdict'} = 'VERDICT_PASS';
            S_teststep_expected("Fault '$thisFaultName': \n $expectedPropertiesString", "$evalKeyword") if(defined $evalKeyword);
            S_teststep_detected("Fault '$thisFaultName':\n".
                                "$detectedPropertiesString", "$evalKeyword") if(defined $evalKeyword);
            S_w2rep("\n");
            $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $thisFaultName, 'Expected');
        }
        else{ #should not be possible
            S_set_warning("Fault $thisFaultName with given fault properties is found more than once. Is fault name not unique?");
        }
    }

    _add_faults_to_csv_file($faultTableCsvString);

    if($mandatoryVerdict eq 'VERDICT_PASS'){
        S_w2log(3, "All expected mandatory faults are stored with given properties\n");
        S_set_verdict(VERDICT_PASS);
    }

    return $mandatoryVerdict;
}

sub evaluate_disjunction_faults{
    my $self = shift;
    my $disjunctionFaults_href = shift;
    my $faultEvaluationSummary_href = shift;
    my $evalKeyword = shift;

    $disjunctionFaults_href = {} unless(defined $disjunctionFaults_href);
    my $disjunctionFaultsCopy_href = dclone($disjunctionFaults_href); # using a copy to avoid any change on the input argument

    #IF Are disjunction faults given as array?
    if(ref($disjunctionFaultsCopy_href) eq 'ARRAY'){
        #IF-YES-START
        #CALL _convert_fault_name_aref_to_href
        $disjunctionFaultsCopy_href = _convert_fault_name_aref_to_href($disjunctionFaultsCopy_href);
        #IF-YES-END
    }
        #IF-NO-START
        #IF-NO-END

    my $disjunctionVerdict = 'VERDICT_FAIL';
    my @disjunctionFaults;
    my @storedDisjunctionFault; #only for teststep printout
    my $faultTableCsvString = '';
    foreach my $thisFaultName (keys %{$disjunctionFaultsCopy_href}){
        my $disjunctionFaultProperty_href = $disjunctionFaultsCopy_href -> {$thisFaultName};
        $disjunctionFaultProperty_href -> {'FaultName'} = $thisFaultName;
        my $thisFaultName = $disjunctionFaultProperty_href -> {'FaultName'};
        if(exists $faultEvaluationSummary_href -> {$thisFaultName}){
            S_set_warning("Fault $thisFaultName already evaluated - don't give twice");
            next;
        }
        push(@disjunctionFaults, $thisFaultName);
        $faultEvaluationSummary_href -> {$thisFaultName} -> {'FaultName'} = $thisFaultName;
        $faultEvaluationSummary_href -> {$thisFaultName} -> {'ExpectedType'} = 'disjunction';
             $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'expected'} = '[present]';
        my ($faultsWithProperties_aref, $propertyDetails) = $self -> get_faults_with_properties($disjunctionFaultProperty_href, 1);
        my $thisFaultPropertyNumber;
        foreach my $faultNumber(%{$propertyDetails}){
            next unless(exists $propertyDetails -> {$faultNumber} -> {'FaultName'});
            if($propertyDetails -> {$faultNumber} -> {'FaultName'} -> {'detected'} eq $thisFaultName){
                $thisFaultPropertyNumber = $faultNumber;
                last;
            }
        }

        my $numberOfFaults = @{$faultsWithProperties_aref};
        if($numberOfFaults == 0){
            S_w2log(4, "Disjunction fault '$thisFaultName' not stored with given properties\n");
            if($thisFaultPropertyNumber){
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'OtherProperties'} = $propertyDetails -> {$thisFaultPropertyNumber};
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'present';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $self -> get_fault_attribute({'FaultName' => $thisFaultName,
                                                                                                            'Attribute' => 'DTC'});
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $self -> get_fault_attribute({'FaultName' => $thisFaultName,
                                                                                                            'Attribute' => 'BoschFaultNbr'});
            }
            else{
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'not present';                
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $disjunctionFaultProperty_href -> {'DTC'} // 'n/a';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $disjunctionFaultProperty_href -> {'BoschFaultNbr'} // 'n/a';
            }
        }
        elsif($numberOfFaults == 1){
            S_w2log(4, "Disjunction fault '$thisFaultName' stored with given properties\n");
            $disjunctionVerdict = 'VERDICT_PASS';
            push(@storedDisjunctionFault, $thisFaultName);
            my $detectedStoredFault_obj = $faultsWithProperties_aref -> [0];
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $detectedStoredFault_obj -> DTC;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $detectedStoredFault_obj -> BoschFaultNbr;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'present';
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'OtherProperties'} = $propertyDetails -> {$thisFaultPropertyNumber};
            $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $thisFaultName, 'Expected');
        }
        else{ #should not be possible
            S_set_warning("Fault $thisFaultName with given fault properties is found more than once. Is fault name not unique?");
        }
    }

    #STEP Set disjunction verdict as it is only clear after looping through all disjunction faults
    foreach my $disjunctionFaultName (@disjunctionFaults){
        $faultEvaluationSummary_href -> {$disjunctionFaultName} -> {'Verdict'} = $disjunctionVerdict ;
    }

    if($disjunctionVerdict eq 'VERDICT_PASS'){
        S_w2log(3, "Disjunction fault evaluation: At least one of following faults stored: @disjunctionFaults\n");
        S_teststep_expected("At least one of following faults stored with all given properties: @disjunctionFaults", $evalKeyword) if(defined $evalKeyword);

        S_w2log(3, "Disjunction fault(s) stored: @storedDisjunctionFault\n");
        S_teststep_detected("Disjunction fault(s) stored with all given properties: @storedDisjunctionFault", $evalKeyword) if(defined $evalKeyword);
        S_set_verdict(VERDICT_PASS);
    }
    elsif($disjunctionVerdict eq 'VERDICT_FAIL' and @disjunctionFaults){
        S_w2log(3, "Disjunction fault evaluation: At least one of following faults stored: @disjunctionFaults\n");
        S_teststep_expected("At least one of following faults stored with all given properties: @disjunctionFaults", $evalKeyword) if(defined $evalKeyword);

        S_w2log(3, "None of the given disjunction faults stored\n");
        S_teststep_detected("None of the expected disjunction faults stored with all given properties", $evalKeyword) if(defined $evalKeyword);
        S_set_verdict(VERDICT_FAIL);
        foreach my $thisFaultName ( @disjunctionFaults ) {
            $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $thisFaultName, 'Missing');
        }
    }
    else{ # No disjunction faults are evaluated
        $disjunctionVerdict = 'VERDICT_PASS';
        S_set_verdict(VERDICT_PASS);
    }

    _add_faults_to_csv_file($faultTableCsvString);

    return $disjunctionVerdict;
}


sub evaluate_optional_faults{
    my $self = shift;
    my $optionalFaults_href = shift;
    my $faultEvaluationSummary_href = shift;
    my $evalKeyword = shift;

    #STEP get expected optional faults from project defaults
    my @expected_optional_list_from_defaults = ();
    if ( exists $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} ){
        S_w2log( 5, " Add project defined optional faults '" . @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } . "'\n" );
        push( @expected_optional_list_from_defaults, @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } );
    }
    $optionalFaults_href = {} unless(defined $optionalFaults_href);
    my $optionalFaultsCopy_href = dclone($optionalFaults_href); # using a copy to avoid any change on the input argument

    #IF Are disjunction faults given as array?
    if(ref($optionalFaultsCopy_href) eq 'ARRAY'){
        #IF-YES-START
        #STEP add project defaults optional faults to aref
        push(@{$optionalFaultsCopy_href}, @expected_optional_list_from_defaults);
        #CALL _convert_fault_name_aref_to_href
        $optionalFaultsCopy_href = _convert_fault_name_aref_to_href($optionalFaultsCopy_href);
        #IF-YES-END
    }
    else{
        #IF-NO-START
        #STEP add optional faults from project defaults to given href
        #my $numberOfGivenOptionalFaults = keys %{$optionalFaultsCopy_href};
        #my $faultNbr = $numberOfGivenOptionalFaults + 1;
        my $optionalFaultsDefaults_href = _convert_fault_name_aref_to_href(\@expected_optional_list_from_defaults);
        %{$optionalFaultsCopy_href} = (%{$optionalFaultsCopy_href}, %{$optionalFaultsDefaults_href});
        #IF-NO-END
    }

    my $faultTableCsvString = '';
    foreach my $thisFaultName (keys %{$optionalFaultsCopy_href}){
        my $optionalFaultProperty_href = $optionalFaultsCopy_href -> {$thisFaultName};
        $optionalFaultProperty_href -> {'FaultName'} = $thisFaultName;
        if(exists $faultEvaluationSummary_href -> {$thisFaultName}){
            S_set_warning("Fault $thisFaultName already evaluated - don't give twice");
            next;
        }
        $faultEvaluationSummary_href -> {$thisFaultName} -> {'FaultName'} = $thisFaultName;
        $faultEvaluationSummary_href -> {$thisFaultName} -> {'ExpectedType'} = 'optional';
        $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'expected'} = 'present|not present';
        my ($faultsWithProperties_aref, $propertyDetails) = $self -> get_faults_with_properties($optionalFaultProperty_href, 1);
        my $thisFaultPropertyNumber;
        foreach my $faultNumber(%{$propertyDetails}){
            next unless(exists $propertyDetails -> {$faultNumber} -> {'FaultName'});
            if($propertyDetails -> {$faultNumber} -> {'FaultName'} -> {'detected'} eq $thisFaultName){
                $thisFaultPropertyNumber = $faultNumber;
                last;
            }
        }

        my $numberOfFaults = @{$faultsWithProperties_aref};
        if($numberOfFaults == 0){
            S_w2log(4, "Optional fault '$thisFaultName' not stored with given properties\n");
            if($thisFaultPropertyNumber){
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'OtherProperties'} = $propertyDetails -> {$thisFaultPropertyNumber};
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'present';   
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $self -> get_fault_attribute({'FaultName' => $thisFaultName,
                                                                                                            'Attribute' => 'DTC'});
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $self -> get_fault_attribute({'FaultName' => $thisFaultName,
                                                                                                            'Attribute' => 'BoschFaultNbr'});
            }
            else{
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'not present';                
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $optionalFaultProperty_href -> {'DTC'} // 'n/a';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $optionalFaultProperty_href -> {'BoschFaultNbr'} // 'n/a';
            }
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Verdict'} = 'VERDICT_PASS';
        }
        elsif($numberOfFaults == 1){
            S_w2log(4, "Optional fault '$thisFaultName' stored with given properties\n");
            my $detectedStoredFault_obj = $faultsWithProperties_aref -> [0];
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'OtherProperties'} = $propertyDetails -> {$thisFaultPropertyNumber};
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $detectedStoredFault_obj -> DTC;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $detectedStoredFault_obj -> BoschFaultNbr;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'present';
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'Verdict'} = 'VERDICT_PASS';

            $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $thisFaultName, 'Additional');
        }
        else{ #should not be possible
            S_set_warning("Fault $thisFaultName with given fault properties is found more than once. Is fault name not unique?");
        }
    }

    _add_faults_to_csv_file($faultTableCsvString);

    return 'VERDICT_PASS';  
}

sub evaluate_additional_faults{
    my $self = shift;
    my $faultEvaluationSummary_href = shift;
    my $evalKeyword = shift;

    my $additional_verdict = 'VERDICT_PASS';

    my $type = $self -> Type;
    my $evaluated_DTCs_href;
    if($type eq 'Customer'){
        S_w2log(4, "Fault entries with same DTC will not be evaluated as additional fault.\n".
                    "(Same DTC will be mapped to various fault names");
        foreach my $faultName (keys %{$faultEvaluationSummary_href}){
            my $dtc =  $faultEvaluationSummary_href -> {$faultName} -> {'DTC'};
            next if($dtc eq 'n/a');
            $evaluated_DTCs_href -> {$dtc} = 1;
        }
    }

    my @additionalFaults; #for documentation only
    foreach my $faultEntryNbr (keys %{$self -> {FaultEntriesHash}}){
        my $faultEntry_obj = $self -> {FaultEntriesHash} -> {$faultEntryNbr};
        my $thisFaultName = $faultEntry_obj -> FaultName;
        if(not exists $faultEvaluationSummary_href -> {$thisFaultName}){
            my $dtc = $faultEntry_obj -> DTC;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'FaultName'} = $thisFaultName;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'DTC'} = $faultEntry_obj -> DTC;
            $faultEvaluationSummary_href -> {$thisFaultName} -> {'BoschFaultNbr'} = $faultEntry_obj -> BoschFaultNbr;

            if($type eq 'Customer' and exists $evaluated_DTCs_href -> {$dtc}){
                S_w2log(4, "Additional fault '$thisFaultName' is mapped to same DTC as already evaluated fault\n");
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'ExpectedType'} = 'additional';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'DTC present';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Verdict'} = 'VERDICT_PASS';               
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'expected'} = 'DTC present';
            }
            else{
                push(@additionalFaults, $thisFaultName);
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'expected'} = 'not present';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'ExpectedType'} = 'additional';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Presence'} -> {'detected'} = 'present';
                $faultEvaluationSummary_href -> {$thisFaultName} -> {'Verdict'} = 'VERDICT_FAIL';               
            }
        }
    }

    S_teststep_expected("No additional faults stored", $evalKeyword) if(defined $evalKeyword);
    if(@additionalFaults){
        S_w2log(3, "Following additional faults stored: @additionalFaults \n");
        S_set_verdict(VERDICT_FAIL);
        $additional_verdict = VERDICT_FAIL;
        S_teststep_detected("Following additional faults stored: @additionalFaults", $evalKeyword) if(defined $evalKeyword);

        my $faultTableCsvString = '';
        foreach my $faultName ( @additionalFaults ){
            $faultTableCsvString = _add_fault_to_csv_string($faultTableCsvString, $faultName, 'Unexpected');
        }
        _add_faults_to_csv_file($faultTableCsvString);
    }
    else{
        S_w2log(3, "No additional faults stored\n");
        S_set_verdict(VERDICT_PASS);
        S_teststep_detected("No additional faults stored", $evalKeyword) if(defined $evalKeyword);        
    }

    return $additional_verdict;
}

sub _convert_fault_name_aref_to_href{
    my $faultName_aref = shift;
    my $faultName_href = {};

    #LOOP-START loop through each fault name in array
    foreach my $faultName (@{$faultName_aref}){
        #STEP add current fault name to fault name hash
        $faultName_href -> {$faultName} = {"FaultName" => $faultName};
    }
    #LOOP-END

    return $faultName_href;
}

sub _create_HTML_table_fault_eval_summary{
    my $faultEvaluationSummary_href = shift;
    my $faultMemType = shift;

    my $fault_eval_table = HTML::Table -> new(
                            -align=>'center',
                            -rules => 'all',
                            -border=>1,
                            -width=>'50%',
                            -spacing=>0,
                            -padding=>3,
                            -style=>'color: black',
    );
    $fault_eval_table->setCaption("Fault Evaluation Table ($faultMemType fault memory)");
    $fault_eval_table->addRow('FaultName', 'DTC', 'BoschFaultNbr', 'Type', 'Evaluation', '', '', '');
    $fault_eval_table->addRow('', '', '', '', 'Attribute','','Expected', 'Detected');
    $fault_eval_table->setCellRowSpan(1, 1, 2); #Column FaultName spanned over first two rows
    $fault_eval_table->setCellRowSpan(1, 2, 2); #Column DTC spanned over first two rows
    $fault_eval_table->setCellRowSpan(1, 3, 2); #Column BoschFaultNbr spanned over first two rows
    $fault_eval_table->setCellRowSpan(1, 4, 2); #Column Type spanned over first two rows
    $fault_eval_table->setCellColSpan(1, 5, 4); #Column Evaluation spanned over last three columns
    $fault_eval_table->setCellColSpan(2, 5, 2); #Column Attribute spanned over two columns
    $fault_eval_table->setRowBGColor(1, "#E2E8EE");
    $fault_eval_table->setRowBGColor(2, "#E2E8EE");

    my @mandatoryFaults = ();
    my @disjunctionFaults = ();
    my @optionalFaults = ();
    my @additionalFaults = ();
    
    foreach my $evaluatedFault (keys %{$faultEvaluationSummary_href}){
        my $type = $faultEvaluationSummary_href -> {$evaluatedFault} -> {'ExpectedType'};
        push(@mandatoryFaults, $evaluatedFault) if($type eq 'mandatory');
        push(@disjunctionFaults, $evaluatedFault) if($type eq 'disjunction');
        push(@optionalFaults, $evaluatedFault) if($type eq 'optional');
        push(@additionalFaults, $evaluatedFault) if($type eq 'additional');
    }

    my $rowNbr = 3;
    $rowNbr = _add_evaluated_faults_to_table($rowNbr, $fault_eval_table, \@mandatoryFaults, $faultEvaluationSummary_href);
    $rowNbr = _add_evaluated_faults_to_table($rowNbr, $fault_eval_table, \@disjunctionFaults, $faultEvaluationSummary_href);
    $rowNbr = _add_evaluated_faults_to_table($rowNbr, $fault_eval_table, \@optionalFaults, $faultEvaluationSummary_href);
    $rowNbr = _add_evaluated_faults_to_table($rowNbr, $fault_eval_table, \@additionalFaults, $faultEvaluationSummary_href);

    $fault_eval_table = '<div class="TCtable">'.$fault_eval_table . '</div>';
    push( @TC_HTML_TEXT, $fault_eval_table);

    return 1;
}

sub _add_evaluated_faults_to_table {
    my $rowNbr = shift;
    my $fault_eval_table = shift;
    my $listOfFaults_aref = shift;
    my $faultEvaluationSummary_href = shift;

    foreach my $evaluatedFault (@{$listOfFaults_aref}){
        my @dataThisRow;
        push(@dataThisRow, $faultEvaluationSummary_href -> {$evaluatedFault} -> {'FaultName'});
        if($faultEvaluationSummary_href -> {$evaluatedFault} -> {'DTC'} eq 'n/a'){
            push(@dataThisRow, $faultEvaluationSummary_href -> {$evaluatedFault} -> {'DTC'});                        
        }
        else{
            push(@dataThisRow, "0x".sprintf("%X", $faultEvaluationSummary_href -> {$evaluatedFault} -> {'DTC'}));            
        }
        push(@dataThisRow, $faultEvaluationSummary_href -> {$evaluatedFault} -> {'BoschFaultNbr'});
        push(@dataThisRow, $faultEvaluationSummary_href -> {$evaluatedFault} -> {'ExpectedType'});
        push(@dataThisRow, 'Presence');
        push(@dataThisRow, '');
        push(@dataThisRow, $faultEvaluationSummary_href -> {$evaluatedFault} -> {'Presence'} -> {'expected'});
        push(@dataThisRow, $faultEvaluationSummary_href -> {$evaluatedFault} -> {'Presence'} -> {'detected'});

        $fault_eval_table->addRow(@dataThisRow);
        $fault_eval_table->setCellColSpan($rowNbr, 5, 2); #Column Attribute spanned over two columns
        $fault_eval_table->setCellBGColor($rowNbr,1,'green') if($faultEvaluationSummary_href -> {$evaluatedFault} -> {'Verdict'} eq 'VERDICT_PASS');
        $fault_eval_table->setCellBGColor($rowNbr,1,'red') if($faultEvaluationSummary_href -> {$evaluatedFault} -> {'Verdict'} eq 'VERDICT_FAIL');
 
        $rowNbr++;
        
        next unless($faultEvaluationSummary_href -> {$evaluatedFault} -> {'OtherProperties'});
        my $otherProperties_href = $faultEvaluationSummary_href -> {$evaluatedFault} -> {'OtherProperties'};
        my $additionalRows = 0;
        foreach my $validatedProperty (sort keys %{$otherProperties_href}){
            next if($validatedProperty eq 'FaultName');

            my @dataThisPropertyRow = ('', '', '', '', $validatedProperty);
            
            if(exists $otherProperties_href -> {$validatedProperty} -> {'expected'}){
                push(@dataThisPropertyRow, '');
                push(@dataThisPropertyRow, $otherProperties_href -> {$validatedProperty} -> {'expected'});
                push(@dataThisPropertyRow, $otherProperties_href -> {$validatedProperty} -> {'detected'});
                $fault_eval_table->addRow(@dataThisPropertyRow);
                $fault_eval_table->setCellColSpan($rowNbr + $additionalRows, 5, 2); #Column Attribute spanned over two columns
                $additionalRows++;
            }
            else{ #nested property
                my $spanRowNumber = $rowNbr + $additionalRows;
                my $nestedRows = 0;
                foreach my $subProperty (keys %{$otherProperties_href -> {$validatedProperty}}){
                    my @dataSubPropertyRow;
                    if($nestedRows){
                         @dataSubPropertyRow = ('', '', '', '', '');
                    }
                    else{
                        @dataSubPropertyRow = @dataThisPropertyRow;
                    }                   
                    push(@dataSubPropertyRow, $subProperty);
                    push(@dataSubPropertyRow, $otherProperties_href -> {$validatedProperty} -> {$subProperty} -> {'expected'});
                    push(@dataSubPropertyRow, $otherProperties_href -> {$validatedProperty} -> {$subProperty} -> {'detected'});                
                    $fault_eval_table->addRow(@dataSubPropertyRow);
                    $nestedRows++;
                    $additionalRows++;    
                }
                $fault_eval_table->setCellRowSpan($spanRowNumber, 5, $nestedRows);                           
            }
        }
        $fault_eval_table->setCellRowSpan($rowNbr - 1, 1, $additionalRows + 1);
        $fault_eval_table->setCellRowSpan($rowNbr - 1, 2, $additionalRows + 1);
        $fault_eval_table->setCellRowSpan($rowNbr - 1, 3, $additionalRows + 1);
        $fault_eval_table->setCellRowSpan($rowNbr - 1, 4, $additionalRows + 1);
        
        $rowNbr = $rowNbr + $additionalRows;
    }

   
    return $rowNbr;
}

sub _fault_properties_to_string {
    my $faultProperties_href = shift;
    my $exclude_properties_aref = shift;
    
    my $excludeProperties_href;
    foreach my $excluedeProperty(@{$exclude_properties_aref}){
        $excludeProperties_href -> {$excluedeProperty} = 1;
    }
    
    my ($expectedPropertiesString, $detectedPropertiesString, $mismatchPropertiesString);
    
    foreach my $faultProperty (sort keys %{$faultProperties_href})
    {
        next if(exists $excludeProperties_href -> {$faultProperty});

        $expectedPropertiesString .= "\n" if(defined $expectedPropertiesString); #newline from second property onwards
        $detectedPropertiesString .= "\n" if(defined $expectedPropertiesString); #newline from second property onwards

        if(exists $faultProperties_href -> {$faultProperty} -> {'expected'}){
            my $expectedValue = $faultProperties_href -> {$faultProperty} -> {'expected'};
            my $detectedValue = $faultProperties_href -> {$faultProperty} -> {'detected'};
            $mismatchPropertiesString .= "$faultProperty : (EXP) $expectedValue <=> $detectedValue (DET)\n" if($expectedValue ne $detectedValue);
            $expectedPropertiesString .= $faultProperty." = ".$expectedValue;
            $detectedPropertiesString .= $faultProperty." = ".$detectedValue;
    
        }
        else{
            $expectedPropertiesString .= $faultProperty." -> ";
            $detectedPropertiesString .= $faultProperty." -> ";
            foreach my $subProperty (sort keys %{$faultProperties_href -> {$faultProperty}}){
                my $expectedValue = $faultProperties_href -> {$faultProperty} -> {$subProperty} -> {'expected'};
                my $detectedValue = $faultProperties_href -> {$faultProperty} -> {$subProperty} -> {'detected'};
                $mismatchPropertiesString .= "$faultProperty -> $subProperty : (EXP) $expectedValue <=> $detectedValue (DET)\n" if($expectedValue ne $detectedValue);
                $expectedPropertiesString .= $subProperty." = ".$expectedValue."   ";
                $detectedPropertiesString .= $subProperty." = ".$detectedValue."   ";
            }    
        }
    }
    
    return ($expectedPropertiesString, $detectedPropertiesString, $mismatchPropertiesString);
}

=head2 get_faults_with_properties

    $entry_obj_aref
            = $faultMemory_obj -> get_faults_with_properties( $fault_properties_href );

    ($entry_obj_aref, $propertyMatchingDetails_href)
            = $faultMemory_obj -> get_faults_with_properties(
                                        $fault_properties_href
                                        [, $returnPropertyMatchingDetails]);

This function returns a list of fault entry objects which fulfill the given properties.
Optionally, a hash ref with the detailed evaluation of each fault that is present in the fault memory,
telling whether the property was fulfilled or not, is given.
Properties can be any given attributes with their expected values of the fault entry class.

B<Input parameters:>

=over

=item '$fault_properties_href'

Hash reference with a collection of all properties the returned faults should fulfill.
Depending on the fault memory type, the available fault entry properties change!
(E.g. the 'OccurrenceCounter' property is only available for fault memories of type 'Bosch')

Example:
a) Return a fault entry which has the name 'looking_for_me', is in dequalified state, and turns on the warning lamp

    $fault_properties_href = {'FaultName' => 'looking_for_me',
                              'DecodedStatus' => {
                                  'TestFailed' => 0,
                                  'WarningLamp' => 1,},
                             };

b) Return all fault entries which are in qualified state

    $fault_properties_href = { 'DecodedStatus' => {'TestFailed' => 1} };

=item $returnPropertyMatchingDetails

This parameter can be set either to '1' or '0'/undef.

If the parameter is set to 1, in addition to the list of fault entries which match the given properties,
a hash reference with details on which fault was matching / not matching which property will be returned.

This might be useful for printouts.

=back

B<Return values:>

=over

=item $entry_obj_aref

This is a list of fault entry objects. All attributes and methods of each object in the list can be accessed.

E.g. if the fault name of the first entry in the list is required, following would be the code:

    my $firstFaultEntryObject = $entry_obj_aref -> [0];
    my $faultNameFirstEntry = $firstFaultEntryObject -> FaultName;

(FaultName is a built-in method of the fault entry object which returns the value of the attribute 'FaultName')

=item $propertyMatchingDetails_href
This hash reference contains the detailed expected/detected for each given fault property and each fault in the fault memory.

Example:

    $propertyMatchingDetails_href = {
            1 => { # fault entry 1 -> not matching
                'FaultName' => {'expected' => 'looking_for_me',
                                'detected' => 'i_am_different},
                'DecodedStatus' => {
                    'TestFailed' => {'expected' => 0,
                                     'detected' => 1},
                    'WarningLamp' => {'expected' => 1,
                                      'detected' => 1},}, 
                },
             2 => { # fault entry 2 -> matching
                'FaultName' => {'expected' => 'looking_for_me',
                                'detected' => 'looking_for_me},
                'DecodedStatus' => {
                    'TestFailed' => {'expected' => 0,
                                     'detected' => 0},
                    'WarningLamp' => {'expected' => 1,
                                      'detected' => 1},},
                },
             },
             '3' =>{
                 ...
             },
             ...
         };

=back

B<Use Case 1:> Get all faults in qualified state

    my $faultMemory_obj = LIFT_FaultMemory -> read_fault_memory();
    $entry_obj_aref
        = $faultMemory_obj -> get_faults_with_properties(
                                {'DecodedStatus' => {'TestFailed' => 1}});

    my $numberOfQualifiedFaults = @{$entry_obj_aref};
    my @faultNamesInQualifedState = ();

    foreach my $fault_entry_obj(@{$entry_obj_aref})
    {
        push(   @faultNamesInQualifedState,
                $fault_entry_obj -> FaultName);
    }

    S_w2rep("Following faults are qualified: @faultNamesInQualifedState");

B<Error return:>

The function will return 'undef' and throw an error if any of the given properties are not supported
for fault entries of the given fault memory type.
(E.g. if property 'OccurrenceCounter' is given for a primary fault memory object)

=cut

sub get_faults_with_properties{
    my $self = shift;
    my $fault_properties_href = shift;
    my $return_property_details = shift;

    my @args;
    push(@args, $fault_properties_href);

    #STEP Check whether mandatory parameter fault properties is defined
    return 0 unless S_checkFunctionArguments( 'LIFT_FaultMemory::get_faults_with_properties ( $fault_properties_href )', @args );

    my $allAttributeNames_href;
    my $entries_with_property_aref = [];
    my $fault_entries_href = $self->{FaultEntriesHash};
    my $propertyMatchingDetails_href; #hash with key 'PropertyName' and value 'expected' and 'detected'

    #LOOP-START loop through all fault entries in fault memory
    foreach my $fault_number ( sort {$a <=> $b} keys %$fault_entries_href ) {
        #STEP get entry object
        my $entry_obj = $fault_entries_href -> {$fault_number};

        #IF are valid attributes for object known?
        if(not defined $allAttributeNames_href){ #only required once, as all fault entry objects of same fault memory are of same type
            #IF-NO-START
            #CALL _get_list_of_object_attributes
            $allAttributeNames_href = _get_list_of_object_attributes($entry_obj);
            #IF-NO-END
        }
        #IF-YES-START
        #IF-YES-END

        my $all_properties_fulfilled = 1;
        #LOOP-START loop through all properties that must match
        foreach my $property ( keys %{ $fault_properties_href } ) {
            #IF is not existing given property in fault entry properties?
            if(not exists $allAttributeNames_href -> {$property}){
                #IF-YES-START
                #STEP set error and go to next property
                S_set_error("Invalid fault property '$property' defined. Will not be considered");
                next;
                #IF-YES-END
            }
                #IF-NO-START
                #IF-NO-END

            #STEP compare desired value with actual fault entry property value
            my $desired_value = $fault_properties_href -> {$property};
            my $entry_value = $entry_obj -> {$property};
            if(ref($desired_value) eq 'HASH'){
                $propertyMatchingDetails_href -> {$fault_number} -> {$property} = {};
                my $thisPropertyFulfilled = _compare_hashes($desired_value, $entry_value, $propertyMatchingDetails_href -> {$fault_number} -> {$property});
                $all_properties_fulfilled = 0 unless($thisPropertyFulfilled);
            }
            else{
                $propertyMatchingDetails_href  -> {$fault_number} -> {$property} -> {'expected'} = $desired_value;
                $propertyMatchingDetails_href  -> {$fault_number} -> {$property} -> {'detected'} = $entry_value;
                #IF desired and actual values are not equal?
                if( $entry_value ne $desired_value ) {
                    #IF-YES-START
                    #STEP not all properties fulfilled, step out of loop
                    $all_properties_fulfilled = 0;
                    #IF-YES-END
                }
                    #IF-NO-START
                    #IF-NO-END                
            }
        }
        #LOOP-END all given properties checked?

        #IF are all checked properties matching?
        if( $all_properties_fulfilled ) {
            #IF-YES-START
            #STEP add fault entry object to array with all matched objects
            push(@{$entries_with_property_aref}, $entry_obj);
            #IF-YES-END
        }
            #IF-NO-START
            #IF-NO-END
    }
    #LOOP-END last fault entry reached?

    #STEP return array of all matched objects
    if($return_property_details){
        return ($entries_with_property_aref, $propertyMatchingDetails_href);
    }

    return $entries_with_property_aref;
}

=head2 clear_in_ECU

    $success = $faultMemory_obj -> clear_in_ECU();

Clears the fault memory in the ECU by calling PD or CD services.
The service called depends on the fault memory type, which is specified when the fault memory object is created.

=over

=item Type 'Primary' or 'Bosch' or 'Plant' or 'Disturbance'

calls PRD_Clear_Fault_Memory()  or PD_ClearFaultMemory() depending on testbench configuration

=item Type 'Customer'

calls CD_clear_DTC();

=back

B<Return values:>

=over

=item $success

Returns 1 on success, 0 otherwise

=back

B<Use Cases:>

A fault memory object exists already, e.g. first read fault memory, then clear fault memory for type 'Primary':

    # create fault memory object and read fault memory
    $faultMemory_obj = read_fault_memory( 'Primary' );
    # clear fault memory
    $success = $faultMemory_obj -> clear_in_ECU();

A fault memory object does not yet exist, e.g. first clear fault memory, then read fault memory for type 'Primary':

    # create (empty) fault memory object
    $faultMemory_obj = LIFT_FaultMemory -> new( {Type => 'Primary'} );
    # clear fault memory
    $success = $faultMemory_obj -> clear_in_ECU();
    # read fault memory
    $success = $faultMemory_obj -> read_from_ECU();

=cut

sub clear_in_ECU{
    my $self = shift;

    my $success = 1;

    my $type = $self -> Type;

    S_w2log(4, "LIFT_FaultMemory::clear_in_ECU: clearing fault memory of type $type...\n");

    #IF fault type is Customer?
    if($type eq 'Customer'){ # Customer Diagnosis
        #IF-YES-START
        #STEP Clear faults using CD
        my $response_aref = CD_clear_DTC( );
        $success = 0 if($response_aref == 0);
        #IF-YES-END
    }
    else { # Production Diagnosis
        #IF-NO-START
        #IF LIFT_ProdDiag is initialized?
        if ( $LIFT_ProdDiag::prodDiag_Initialized ) {
            #IF-YES-START
            #STEP Clear faults using LIFT_ProdDiag
            $success = PRD_Clear_Fault_Memory();
            $success = 0 if(not defined $success);
            #IF-YES-END
    	}
    	else{
            #IF-NO-START
            #STEP Clear faults using LIFT_PD
            $success = PD_ClearFaultMemory();
            #IF-NO-END
    	}
        #IF-NO-END
    }

    #STEP Return $success
    return $success;
}


=head2 manipulate_in_ECU

    $success = $faultMemory_obj -> manipulate_in_ECU( [ $manipulationConfig_href ] );

Manipulates the fault memory in the ECU by calling PD service PRD_Manipulate_Fault_Memory or PD_ManipulateFaultMemory 
(depending on testbench configuration).

This method is B<not> applicable for objects of Type 'Customer'.

B<Arguments:>

=over

=item $manipulationConfig_href

    $manipulationConfig_href = {
        'fault_name' => <fault>,  # string with a fault name that shall be manipulated
        'action'     => <action>, # either "qualify" or "dequalify" (case independent)
    }
    
If $manipulationConfig_href is not defined then all faults of the type of $faultMemory_obj will be dequalified.

=back


B<Return values:>

=over

=item $success

Returns 1 on success, 0 otherwise

=back

B<Use Cases:>

A fault memory object exists already, e.g. first read fault memory, then manipulate fault memory to dequalify faults

    # create fault memory object and read fault memory
    $faultMemory_obj = read_fault_memory( 'Primary' );
    # manipulate fault memory, here: dequalify all faults in Primary fault memory
    $success = $faultMemory_obj -> manipulate_in_ECU();

A fault memory object does not yet exist, e.g. manipulate fault memory to qualify a fault

    # create (empty) fault memory object
    $faultMemory_obj = LIFT_FaultMemory -> new( {Type => 'Primary'} );
    # manipulate fault memory, here: qualify fault 'rb_pom_VerLow_flt'
    $success = $faultMemory_obj -> manipulate_in_ECU( { fault_name => 'rb_pom_VerLow_flt', action => 'qualify' } );

=cut

sub manipulate_in_ECU{
    my @args = @_;
    my $self = shift @args;

    #STEP Check if given parameters are correct
    return 0 unless S_checkFunctionArguments( 'LIFT_FaultMemory::manipulate_in_ECU ([ $manipulationConfig_href ])', @args );
    my $manipulationConfig_href = shift @args;

    my $success = 1;

    my $type = $self -> Type;

    my $manipulationConfigString = Dumper($manipulationConfig_href);
    S_w2log(4, "LIFT_FaultMemory::manipulate_in_ECU: manipulating fault memory of type $type with arguments $manipulationConfigString...\n");

    my $fault_href;
    #IF fault type is Customer?
    if($type eq 'Customer'){ # Customer Diagnosis
        #IF-YES-START
        #STEP Throw error and return
        S_set_error("Method 'manipulate_in_ECU' is not supported for fault memory of type 'Customer'.\n");
        return 0;
        #IF-YES-END
    }
        #IF-NO-START
        #IF-NO-END
    #IF LIFT_ProdDiag is initialized?
    if ( $LIFT_ProdDiag::prodDiag_Initialized ) {
        #IF-YES-START
        #STEP Manipulate faults using LIFT_ProdDiag
        if( not defined $manipulationConfig_href ) {
            $manipulationConfig_href = {'fault_type' => $type};
        }
        $success = PRD_Manipulate_Fault_Memory( $manipulationConfig_href );
        $success = 0 if(not defined $success);
        #IF-YES-END
	}
	else{
        #IF-NO-START
        #STEP Manipulate faults using LIFT_PD
        my ($faultname, $action);
        if( not defined $manipulationConfig_href ) {
            $faultname = _get_fault_type_number($type); # $faultname is the fault type number in this case
            $action = "dequalify";
        }
        else{
            $faultname = $manipulationConfig_href->{fault_name};
            $action = $manipulationConfig_href->{action};
        }
        $success = PD_ManipulateFaultMemory($faultname, $action);
        $success = 0 if(not defined $success);
        #IF-NO-END
	}

    #STEP Return $success
    return $success;
}

=head2 create_fault_table

    $success = LIFT_FaultMemory -> create_fault_table();

Reads the fault data that are stored in LIFT_FaultTableData.csv and creates an Excel table in the same folder,
which gives the user an overview of all faults that were read or evaluated during the whole test list.

B<ATTENTION: >

This function is called in the END block of this module, so it creates the Excel fault table for each test run automatically

=cut

sub create_fault_table{
    my $class = shift;
    
    my $faultDetailsTable_href = {};
    my $faultSummaryTable_href = {};

    #CALL _get_fault_table_data_from_csv
    _get_fault_table_data_from_csv($faultDetailsTable_href, $faultSummaryTable_href);

    #CALL _create_xlsx_fault_table
    _create_xlsx_fault_table($faultDetailsTable_href, $faultSummaryTable_href);
}


=head1 INTERNAL FUNCTIONS

=cut

=head2 _find_matching_fault_entry

    $entry_obj_aref = $self -> _find_matching_fault_entry($searchParams_href);

Searches a fault where the given attributes: 'BoschFaultNbr', 'DTC', and 'FaultName' are matching.

Either 1 or various attributes can be given - the fault entry has to match with all given values to be returned as match.

Input parameters:

=over

=item Search params hash ref

Hash reference containing all attributes and values which shall be checked.

Example 1: BoschFaultNbr

    $searchParams_href = {
        'BoschFaultNbr' => 200,
    }

Example 2: DTC and fault name must match

    $searchParams_href = {
        'DTC' => 200,
        'FaultName' => 'rb_fault_blabla',
    }


=back

Returns an array reference containing all fault entry objects which match all given attributes
(only in case of attribute DTC it can be more than one, as BoschFaultNbr and FaultName are unique)

=cut

sub _find_matching_fault_entry {
    my $self = shift;
    my $searchParams_href = shift;

    my @searchAttributes;
    push(@searchAttributes, 'BoschFaultNbr') if(defined $searchParams_href -> {BoschFaultNbr});
    push(@searchAttributes, 'DTC') if(defined $searchParams_href -> {DTC});
    push(@searchAttributes, 'FaultName') if(defined $searchParams_href -> {FaultName});

    my $entry_obj_aref = [];

    #LOOP-START go through each fault entry object in fault memory
    foreach my $faultEntryIndex (keys %{$self -> {FaultEntriesHash}})
    {
        my $thisFaultEntry_obj = $self -> {FaultEntriesHash} -> {$faultEntryIndex};
        my $thisFaultEntryMatches = 1;
        #LOOP-START go through all search attributes in fault entry
        foreach my $searchAttribute (@searchAttributes)
        {
            my $detectedValue = $thisFaultEntry_obj -> $searchAttribute; # calls get method for attribute $searchAttribute
            my $expectedValue = $searchParams_href -> {$searchAttribute};
            #Todo: Handle inconsistent search params -> e.g. one search parameter fulfilled, other not fulfilled
            #IF found search attribute value matches expected attribute value?
            if(($searchAttribute eq 'FaultName') and $detectedValue ne $expectedValue){ # string compare for 'FaultName'
                #IF-YES-START
                #STEP Fault entry matches
                $thisFaultEntryMatches = 0;
                last;
                #IF-YES-END
            }
            elsif(($searchAttribute ne 'FaultName') and $detectedValue != $expectedValue){ #  numeric compare for other attributes (DTC, BoschFaultNbr)
                $thisFaultEntryMatches = 0;
                last;
            }
            #IF-NO-START
            #IF-NO-END
            #LOOP-END last search attribute reached?
        }
        #IF found matching fault entry?
        if($thisFaultEntryMatches){
            #IF-YES-START
            #STEP add fault entry to list of found entries
            push(@{$entry_obj_aref}, $thisFaultEntry_obj);
            #IF-YES-END
        }
        #IF-NO-START
        #IF-NO-END
        #LOOP-END last fault entry reached?
    }

    #STEP return list of found entries
    return $entry_obj_aref;
}

=head2 _create_fault_entry_HoA

    $success = $self -> _create_fault_entry_HoA($fault_HoA, $entryIndex );

Creates fault entry of a certain index from a fault hash of type HoA (LIFT_PD/LIFT_CD).

Attributes which are set for the fault entry after creation are depending on fault entry type.

Will be called by function read_from_ECU

Returns 1 on success

=cut

sub _create_fault_entry_HoA {
    my $self = shift;
    my $fault_HoA = shift;
    my $entryIndex = shift;
    
    my $entryObjectsNumber = keys %{$self -> {FaultEntriesHash}};

    my $type = $self -> Type;
    my $entry_obj;
    #IF fault type is Primary?
    if( $type eq 'Primary'){
        #IF-YES-START
        $entry_obj = FaultEntry -> new;
        #CALL _set_basic_attributes_from_PD
        _set_basic_attributes_from_PD($entry_obj, $fault_HoA, $entryIndex);
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF fault type is Plant?
    elsif($type eq 'Plant'){
        #IF-YES-START
        $entry_obj = FaultEntry -> new;
        #CALL _set_basic_attributes_from_PD
        _set_basic_attributes_from_PD($entry_obj, $fault_HoA, $entryIndex);
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF fault type is Bosch?
    elsif( $type eq 'Bosch' ){
        #IF-YES-START
        $entry_obj = FaultEntry::Bosch -> new;
        #CALL _set_basic_attributes_from_PD
        _set_basic_attributes_from_PD($entry_obj, $fault_HoA, $entryIndex);
        #STEP Set fault entry object attributes: EventDebugData, GeneralStatus, Qualification_poweron_cycle, Dequalification_poweron_cycle, QualificationTime, DequalificationTime, OccurrenceCounter
        $entry_obj -> EventDebugData( hex($fault_HoA->{EventDebug}[$entryIndex]) );
        $entry_obj -> GeneralStatus( hex($fault_HoA->{GeneralState}[$entryIndex]));
        $entry_obj -> Qualification_poweron_cycle( $fault_HoA->{Qualification_poweron_cycle}[$entryIndex] );
        $entry_obj -> Dequalification_poweron_cycle( $fault_HoA->{Dequalification_poweron_cycle}[$entryIndex] );
        $entry_obj -> QualificationTime( $fault_HoA->{QualificationTime}[$entryIndex] );
        $entry_obj -> DequalificationTime( $fault_HoA->{DequalificationTime}[$entryIndex] );
        $entry_obj -> OccurrenceCounter( $fault_HoA->{OccuranceCounter}[$entryIndex] );
        my $masterAsicTemperature = $fault_HoA->{ASIC_Temperature}[$entryIndex];
        $entry_obj -> ASIC_Temperature( $masterAsicTemperature ) if($masterAsicTemperature);
        $entry_obj -> decode_GeneralStatus();
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF fault type is Disturbance?
    elsif( $type eq 'Disturbance' ){
        #IF-YES-START
        #STEP Set fault entry object attributes: BoschFaultNbr, FaultName, DTC, EventDebugData, GeneralStatus, DisturbanceCounter, DisturbanceStatus
        $entry_obj = FaultEntry::Disturbance -> new;
        $entry_obj -> BoschFaultNbr( $fault_HoA->{fltnum}[$entryIndex] );
        $entry_obj -> FaultName( $fault_HoA->{fault_text}[$entryIndex] );
        $entry_obj -> DTC( hex($fault_HoA->{DTC}[$entryIndex]) );
        $entry_obj -> EventDebugData( hex($fault_HoA->{EventDebug}[$entryIndex]) );
        $entry_obj -> GeneralStatus( hex($fault_HoA->{GeneralState}[$entryIndex]) );
        $entry_obj -> DisturbanceCounter( $fault_HoA->{DisturbanceCounter}[$entryIndex] );
        $entry_obj -> RawStatus( hex($fault_HoA->{DisturbanceState}[$entryIndex]) );
        $entry_obj -> decode_Status();
        $entry_obj -> decode_GeneralStatus();
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF fault type is Customer?
    elsif($type eq 'Customer'){
        #IF-YES-START
        my $faultName = $fault_HoA->{fault_text}[$entryIndex];
        my @mappedFaultNames = split('<br>', $faultName);
         
        foreach my $mappedFaultName (@mappedFaultNames){
            S_w2log(4, "Add customer fault name '$mappedFaultName'");
          #STEP Set fault entry object attributes: RawStatus, DTC, FaultName
            $entry_obj = FaultEntry::Customer -> new;
            $entry_obj -> RawStatus(  hex($fault_HoA->{state}[$entryIndex]) );
            $entry_obj -> DTC(  hex($fault_HoA->{DTC}[$entryIndex]) );
            $entry_obj -> FaultName($mappedFaultName );
            #CALL decode_Status on fault entry object
            $entry_obj -> decode_Status();          
            $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
            $entryObjectsNumber++;
        }
          #IF-YES-END
    }
    #IF-NO-START
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END

    #STEP Return entry object 
    return 1;
}

=head2 _create_fault_entry_HoH

    $success = $self -> _create_fault_entry_HoH($fault_HoH, $entryIndex );

Creates fault entry of a certain index from a fault hash of type HoH (LIFT_ProdDiag).

Attributes which are set for the fault entry after creation are depending on fault entry type.

Will be called by function read_from_ECU

Returns 1 on success

=cut

sub _create_fault_entry_HoH {
    my $self = shift;
    my $fault_HoH = shift;
    my $entryIndex = shift;
    
    my $entryObjectsNumber = keys %{$self -> {FaultEntriesHash}};

    my $type = $self -> Type;
    my $entry_obj;
    #IF fault type is Primary?
    if( $type eq 'Primary'){
        #IF-YES-START
        $entry_obj = FaultEntry -> new;
        #CALL _set_basic_attributes_from_ProdDiag
        _set_basic_attributes_from_ProdDiag($entry_obj, $fault_HoH, $entryIndex);
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF fault type is Plant?
    elsif($type eq 'Plant'){
        #IF-YES-START
        $entry_obj = FaultEntry -> new;
        #CALL _set_basic_attributes_from_ProdDiag
        _set_basic_attributes_from_ProdDiag($entry_obj, $fault_HoH, $entryIndex);
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF fault type is Bosch?
    elsif( $type eq 'Bosch' ){
        #IF-YES-START
        $entry_obj = FaultEntry::Bosch -> new;
        #CALL _set_basic_attributes_from_ProdDiag
        _set_basic_attributes_from_ProdDiag($entry_obj, $fault_HoH, $entryIndex);
        #STEP Set fault entry object attributes: EventDebugData, GeneralStatus, Qualification_poweron_cycle, Dequalification_poweron_cycle, QualificationTime, DequalificationTime, OccurrenceCounter
        my $eventDebugData = $fault_HoH->{$entryIndex}{EventDebug_Data_HB} . substr( $fault_HoH->{$entryIndex}{EventDebug_Data_LB}, -2 );
        $entry_obj -> EventDebugData( hex($eventDebugData) );
        $entry_obj -> GeneralStatus( hex($fault_HoH->{$entryIndex}{GeneralStatus}) );
        $entry_obj -> Qualification_poweron_cycle( $fault_HoH->{$entryIndex}{Qualification_PowerOn_Cycle} );
        $entry_obj -> Dequalification_poweron_cycle( $fault_HoH->{$entryIndex}{Dequalification_PowerOn_Cycle} );
        $entry_obj -> QualificationTime( $fault_HoH->{$entryIndex}{QualificationTime} );
        $entry_obj -> DequalificationTime( $fault_HoH->{$entryIndex}{DequalificationTime} );
        $entry_obj -> OccurrenceCounter( $fault_HoH->{$entryIndex}{OccurrenceCounter} );
        my $masterAsicTemperature = $fault_HoH->{$entryIndex}{ASIC_Temperature};
        $entry_obj -> ASIC_Temperature( $masterAsicTemperature ) if($masterAsicTemperature);
        $entry_obj -> decode_GeneralStatus();
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF fault type is Disturbance?
    elsif( $type eq 'Disturbance' ){
        #IF-YES-START
        #STEP Set fault entry object attributes: BoschFaultNbr, FaultName, DTC, EventDebugData, GeneralStatus, DisturbanceCounter, DisturbanceStatus
        $entry_obj = FaultEntry::Disturbance -> new;
        $entry_obj -> BoschFaultNbr( $fault_HoH->{$entryIndex}{FaultID} );
        $entry_obj -> FaultName( $fault_HoH->{$entryIndex}{FaultName} );
        $entry_obj -> DTC( hex($fault_HoH->{$entryIndex}{DTC}) );
        my $eventDebugData = $fault_HoH->{$entryIndex}{EventDebug_Data_HB} . substr( $fault_HoH->{$entryIndex}{EventDebug_Data_LB}, -2 );
        $entry_obj -> EventDebugData( hex($eventDebugData) );
        $entry_obj -> GeneralStatus( hex($fault_HoH->{$entryIndex}{GeneralStatus}) );
        $entry_obj -> DisturbanceCounter( $fault_HoH->{$entryIndex}{DisturbaneceCounter} );
        $entry_obj -> RawStatus(  hex($fault_HoH->{$entryIndex}{Status}) );
        $entry_obj -> decode_Status();
        $entry_obj -> decode_GeneralStatus();
        #IF-YES-END
        $self -> {FaultEntriesHash} -> {$entryObjectsNumber} = $entry_obj;
    }
    #IF-NO-START
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END

    #STEP Return entry object 
    return 1;
}

=head2 _set_basic_attributes_from_PD

    $success = $self -> _set_basic_attributes_from_PD($fault_HoA, $entryIndex );

Called internally by _create_fault_entry_HoA to set the fault entry attributes which are common throughout different fault entry types.

Returns 1 on success

=cut

sub _set_basic_attributes_from_PD{
    my $entry_obj = shift;
    my $fault_HoA = shift;
    my $entryIndex = shift;

    #STEP Set fault entry object attributes: BoschFaultNbr, FaultName, DTC, RawStatus
    $entry_obj -> BoschFaultNbr( $fault_HoA->{fltnum}[$entryIndex] );
    $entry_obj -> FaultName( $fault_HoA->{fault_text}[$entryIndex] );
    $entry_obj -> DTC( hex($fault_HoA->{DTC}[$entryIndex]) );
    $entry_obj -> RawStatus(  hex($fault_HoA->{state}[$entryIndex]) );

    #CALL decode_Status on fault entry object
    $entry_obj -> decode_Status();

    return 1;
}

=head2 _set_basic_attributes_from_ProdDiag

    $success = $self -> _set_basic_attributes_from_ProdDiag($fault_HoH, $entryIndex );

Called internally by _create_fault_entry_HoH to set the fault entry attributes which are common throughout different fault entry types.

Returns 1 on success

=cut

sub _set_basic_attributes_from_ProdDiag{
    my $entry_obj = shift;
    my $fault_HoH = shift;
    my $entryIndex = shift;

    #STEP Set fault entry object attributes: BoschFaultNbr, FaultName, DTC, RawStatus
    $entry_obj -> BoschFaultNbr( $fault_HoH->{$entryIndex}{FaultID} );
    $entry_obj -> FaultName( $fault_HoH->{$entryIndex}{FaultName} );
    $entry_obj -> DTC( hex($fault_HoH->{$entryIndex}{DTC}) );
    $entry_obj -> RawStatus(  hex($fault_HoH->{$entryIndex}{Status}) );

    #CALL decode_Status on fault entry object
    $entry_obj -> decode_Status();

    return 1;
}

=head2 _get_list_of_object_attributes

    $object_attributes_href = $self -> _get_list_of_object_attributes( );

Function to obtain all attributes of an object.

B<Return values:>

Hash reference containing as key the attribute names which are there in the given object

    $object_attributes_href = {
        'AttributeName1' => 1,
        'AttributeName2' => 1,
        #...
    }

=cut

sub _get_list_of_object_attributes {

    my $object = shift;

    my $attributeList_href;

    #STEP Get list of valid attributes
    my @allAttributes = $object -> meta -> get_all_attributes();
    foreach my $mooseAttribute_href (@allAttributes){
        my $thisAttributeName = $mooseAttribute_href -> {name};
        $attributeList_href -> {$thisAttributeName} = 1;
    }

    return $attributeList_href;
}

=head2 _compare_hashes

    $entry_obj_aref = _compare_hashes( $expectedHash, $detectedHash );

Compares two hashes.
All values of keys in expected hash will be compared.
In case there are additional keys in detected hash, they will be ignored.

Match if:
All keys in expected hash exist with the same value in detected hash.

No match if:
Not both are real hashes.
Key in expected hash not existing in detected hash.
Value of key in expected hash not matching with value of same key in detected hash.

Return 1 on match, 0 on no match.

=cut

sub _compare_hashes {
    my $expectedHash = shift;
    my $detectedHash = shift;
    my $compareResult_href = shift;

    my $match = 1;
    
    if(ref($expectedHash) ne 'HASH'){
        return 0;
    }
    elsif(ref($detectedHash) ne 'HASH'){
        return 0;
    }

    foreach my $keyInExpected ( keys %{ $expectedHash } ) {
        $compareResult_href -> {$keyInExpected} -> {'expected'} = $expectedHash -> {$keyInExpected};

        if(not exists $detectedHash -> {$keyInExpected}){
            $compareResult_href -> {$keyInExpected} -> {'detected'} = 'key not present';
            $match = 0;
        }
        else{
            $compareResult_href -> {$keyInExpected} -> {'detected'} = $detectedHash -> {$keyInExpected};            
        }

        my $expectedValueThisKey = $expectedHash -> {$keyInExpected};
        my $detectedValueThisKey = $detectedHash -> {$keyInExpected};
        if($expectedValueThisKey ne $detectedValueThisKey){
            $match = 0;
        }
        
    }

    return $match;
}

sub _convert_fault_name_href_to_fault_nbr_href{
    my $faultName_href = shift;
    my $faultNbr = shift;
    my $fault_nbr_href = {};

    #STEP set fault number (key for fault name hash) to 1 or given value
    $faultNbr = 1 unless(defined $faultNbr);
    #LOOP-START loop through each fault name in array
    foreach my $faultName (keys %{$faultName_href}){
        #STEP add current fault name to fault name hash
        $fault_nbr_href -> {$faultNbr}=$faultName_href->{$faultName};
        $fault_nbr_href -> {$faultNbr} -> {'FaultName'} = $faultName;
        #STEP count up fault number
        $faultNbr++;
    }
    #LOOP-END

    return $fault_nbr_href;
}

sub CreateFaultsForUnitTest {

    my $self = shift;
    my $fault_HoA = shift;

    $self -> {FaultEntriesHash} = undef;


    #STEP Get number of faults read
    my $numberOfFaults = @{$fault_HoA -> {"DTC"}};
    #LOOP-START Loop over fault indices 0 .. number of faults - 1
    foreach my $entryIndex ( 0 .. $numberOfFaults-1 ) {
        #CALL _create_fault_entry_HoA for current fault index
        my $entry_obj = $self -> _create_fault_entry_HoA($fault_HoA, $entryIndex);
    }
    #LOOP-END last fault index reached

    return 1;
}

sub _get_fault_type_number{
    my $faultTypeString = shift;

    my $pdFaultMemoryType_href = {
        'Bosch' => BOSCH_FLT_MEM,
        'Primary' => PRIMARY_FLT_MEM,
        'Disturbance' => DISTURBANCE_FLT_MEM,
        'Plant' => PLANT_FLT_MEM,
    };
    
    my $faultTypeNumber = $pdFaultMemoryType_href -> {$faultTypeString};
    
    return $faultTypeNumber;
}

=head2 _add_fault_to_csv_string

    $csvString = _add_fault_to_csv_string( $csvString, $faultName, $faultEvaluationKeyword );

Builds a csv string from the current test case name, the given $faultName and given $faultEvaluationKeyword:

"$testCase;$faultName;$faultEvaluationKeyword\n"

This csv string is added to the given $csvString.

The newly built $csvString is returned.

=cut

sub _add_fault_to_csv_string{
    my $csvString = shift;
    my $faultName = shift;
    my $faultEvaluationKeyword = shift;
    
    #STEP get current test case name
    my $testCase = $main::CURRENT_TC // '';
    
    #STEP build csv string and add to the given $csvString
    $csvString .= "$testCase;$faultName;$faultEvaluationKeyword\n";
    
    #STEP return $csvString
    return $csvString;
}

=head2 _add_faults_to_csv_file

    $success = _add_faults_to_csv_file( $csvString );

Opens file LIFT_FaultTableData.csv in report path and appends $csvString to the file.
If the file does not exists it is created.

=cut

sub _add_faults_to_csv_file{
    my $csvString = shift;

    return if $csvString eq '';

    #STEP open fault table data file for append
    my $faultTableCsvFile = $main::REPORT_PATH. "/LIFT_FaultTableData.csv";
    my $fh;
    unless ( open $fh, '+>>', $faultTableCsvFile ) {
        S_w2log(4, "WARNING: Can't open $faultTableCsvFile for fault table data writing: $!");
        return;
    }

    #STEP write csv string
    print $fh $csvString;

    #STEP close fault table data file
    unless ( close($fh) ) {
        S_w2log(4, "WARNING: Can't close $faultTableCsvFile for fault table data writing: $!");
        return;
    }

    return 1;
    
}

=head2 _get_fault_table_data_from_csv

    $success = _get_fault_table_data_from_csv( $faultDetailsTable_href, $faultSummaryTable_href );

Opens file LIFT_FaultTableData.csv in report path and reads its contents.
Builds from file contents 2 data structures:

    $faultSummaryTable_href = {
        <fault name> => {
            Detected         => <number>,
            Expected         => <number>,
            Additional       => <number>,
            Unexpected       => <number>,
            Missing          => <number>,
            Properties_wrong => <number>,
            Result           => 'problem'|'ok'
        },
        ...
    };

    $faultDetailsTable_href = {
        <test case> => {
            <fault name> => {
                Detected         => <number>,
                Expected         => <number>,
                Additional       => <number>,
                Unexpected       => <number>,
                Missing          => <number>,
                Properties_wrong => <number>,
            },
            ...
            Result => 'problem'|'ok'
        },
        ...
    };

=cut

sub _get_fault_table_data_from_csv{
    my $faultDetailsTable_href = shift;
    my $faultSummaryTable_href = shift;

    #STEP define keywords and comments
    my @faultTableKeywords = qw(Detected Expected Additional Unexpected Missing Properties_wrong);
    my @faultTableKeywordComments = (
        "only read",
        "expected mandatory and detected and expected properties (if any) are matching",
        "expected optional and detected",
        "not expected (neither mandatory nor optional) but detected",
        "expected mandatory but not detected",
        "expected mandatory and detected but not all expected properties matching",
    );
    $faultTableKeywords_href->{keywords} = \@faultTableKeywords;
    $faultTableKeywords_href->{comments} = \@faultTableKeywordComments;

    #STEP read contents of file LIFT_FaultTableData.csv
    my $faultTableCsvFile = $main::REPORT_PATH. "/LIFT_FaultTableData.csv";
    my @csvLines = read_file($faultTableCsvFile);
    
    #LOOP-START loop over lines of csv file
    foreach my $line ( @csvLines ) {
        chomp $line;

        #STEP split line in $testCase, $faultName and $faultEvaluationKeyword
        my ($testCase, $faultName, $faultEvaluationKeyword) = split( /;/, $line );

        #STEP increase $faultDetailsTable_href->{$testCase}{$faultName}{$faultEvaluationKeyword}
        if( not defined $faultDetailsTable_href->{$testCase}{$faultName} ) {
            foreach my $keyword ( @faultTableKeywords ) {
                $faultDetailsTable_href->{$testCase}{$faultName}{$keyword} = 0;
            }
        }
        $faultDetailsTable_href->{$testCase}{$faultName}{$faultEvaluationKeyword}++;

        #STEP increase $faultSummaryTable_href->{$faultName}{$faultEvaluationKeyword}
        if( not defined $faultSummaryTable_href->{$faultName} ) {
            foreach my $keyword ( @faultTableKeywords ) {
                $faultSummaryTable_href->{$faultName}{$keyword} = 0;
            }
        }
        $faultSummaryTable_href->{$faultName}{$faultEvaluationKeyword}++;
    }
    #LOOP-END last line?

    #STEP calculate Result in summary table
    foreach my $faultName ( keys %{ $faultSummaryTable_href } ) {
        if( $faultSummaryTable_href->{$faultName}{Unexpected} > 0 or $faultSummaryTable_href->{$faultName}{Missing} > 0 or $faultSummaryTable_href->{$faultName}{Properties_wrong} > 0 ) {
            $faultSummaryTable_href->{$faultName}{Result} = 'problem';
        }
        else{
            $faultSummaryTable_href->{$faultName}{Result} = 'ok';            
        }
    }

    #STEP calculate Result in details table
    foreach my $testCase ( keys %{ $faultDetailsTable_href } ) {
        my $result = 'ok';
        foreach my $faultName ( keys %{ $faultDetailsTable_href->{$testCase} } ) {
            if( $faultDetailsTable_href->{$testCase}{$faultName}{Unexpected} > 0 or $faultDetailsTable_href->{$testCase}{$faultName}{Missing} > 0 or $faultDetailsTable_href->{$testCase}{$faultName}{Properties_wrong} > 0 ) {
                $result = 'problem';
                last;
            }
        }
        $faultDetailsTable_href->{$testCase}{Result} = $result;
    }

    return 1;
}

=head2 _create_xlsx_fault_table

    $success = _create_xlsx_fault_table( $faultDetailsTable_href, $faultSummaryTable_href );

Creates the Excel fault table and fills the worksheet "Summary" from the data in $faultSummaryTable_href
and the worksheet "Details" from the data in $faultDetailsTable_href.

=cut

sub _create_xlsx_fault_table{
    my $faultDetailsTable_href = shift;
    my $faultSummaryTable_href = shift;

    #STEP create the Excel workbook
    my $faultTableXlsxFile = $main::REPORT_PATH. "/LIFT_FaultTable.xlsx";
    my $workbook = Excel::Writer::XLSX->new($faultTableXlsxFile);
    if( not defined $workbook ) {
        S_set_error("Cannot create Excel file $faultTableXlsxFile");
        return;
    }
    
    #CALL _set_xlsx_formats
    _set_xlsx_formats($workbook);

    #CALL _create_ws_summary
    _create_ws_summary($workbook, $faultSummaryTable_href );
    
    #CALL _create_ws_details
    _create_ws_details($workbook, $faultDetailsTable_href, $faultSummaryTable_href );

    #STEP write workbook
    $workbook->close();

    return 1;
}

=head2 _set_xlsx_formats

    $success = _set_xlsx_formats( $workbook );

Defines in workbook $workbook all required formats for the Excel table.

=cut

sub _set_xlsx_formats{
    my $workbook = shift;

    #STEP define header formats
    $format_Header = $workbook->add_format( valign => 'vcenter', align    => 'center', top => 2, left => 2, right => 2, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    $format_Header2 = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 2, right => 2, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    $format_leftHeader = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 2, right => 1, bottom => 2, bold => 1, bg_color => '#DDD9C4', text_wrap => 1 );
    $format_centerHeader = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 1, right => 1, bottom => 2, bold => 1, bg_color => '#DDD9C4', text_wrap => 1 );
    $format_rightHeader = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 1, right => 2, bottom => 2, bold => 1, bg_color => '#DDD9C4', text_wrap => 1 );

    #STEP define content formats
    $format_Content = $workbook->add_format( top => 1, left => 2, right => 2, bottom => 1, );
    $format_leftContent = $workbook->add_format( top => 1, left => 2, right => 1, bottom => 1, );
    $format_centerContent = $workbook->add_format( top => 1, left => 1, right => 1, bottom => 1, );
    $format_rightContent = $workbook->add_format( top => 1, left => 1, right => 2, bottom => 1, );

    #STEP define additional formats for certain content cells
    $format_whiteText      = $workbook->add_format( color    => 'white' );
    $format_dynEnvFail         = $workbook->add_format( color     => '#9C0006', bg_color => '#FFC7CE' );

    return 1;
}

=head2 _create_ws_summary

    $success = _create_ws_summary( $workbook, $faultSummaryTable_href );

Creates and fills in workbook $workbook the worksheet "Summary" with data from $faultSummaryTable_href.

=cut

sub _create_ws_summary{
    my $workbook = shift;
    my $faultSummaryTable_href = shift;

    #STEP create work sheet
    my @faultTableKeywords = @{$faultTableKeywords_href->{keywords}};
    my @faultTableKeywordComments = @{$faultTableKeywords_href->{comments}};
    my $numberOfKeywords = @faultTableKeywords;
    my $worksheet = $workbook->add_worksheet("Summary");

    #STEP in row 1 create a merged cell "Summary"
    my $row = 1;
    my $column = 3;
    $worksheet->merge_range( $row, $column, $row, $column+$numberOfKeywords-1, "Summary", $format_Header );

    #STEP in row 2 write the header cells
    $row++;
    $worksheet->write( $row, 1,  "RB Faults",  $format_Header2 );
    $worksheet->write( $row, 2,  "Result",  $format_Header2 );
    $worksheet->write( $row, 3, $faultTableKeywords[0],  $format_leftHeader );
    $worksheet->write_comment( $row, 3, $faultTableKeywordComments[0] );
    foreach my $index ( 1 .. $numberOfKeywords-2 ) {
        $worksheet->write( $row, 3+$index, $faultTableKeywords[$index],  $format_centerHeader );
        $worksheet->write_comment( $row, 3+$index, $faultTableKeywordComments[$index] );
    }    
    $worksheet->write( $row, 3+$numberOfKeywords-1, $faultTableKeywords[$numberOfKeywords-1],  $format_rightHeader );
    $worksheet->write_comment( $row, 3+$numberOfKeywords-1, $faultTableKeywordComments[$numberOfKeywords-1] );

    #LOOP-START loop over faults in $faultSummaryTable_href
    my $start_row = $row + 1;
    foreach my $fault ( sort keys %{ $faultSummaryTable_href } ) {
        $row++;
        #STEP in subsequent rows write the table contents
        $worksheet->write( $row, 1,  $fault,  $format_Content );
        $worksheet->write( $row, 2,  $faultSummaryTable_href->{$fault}{Result},  $format_Content );
        $worksheet->write( $row, 3,  $faultSummaryTable_href->{$fault}{$faultTableKeywords[0]},  $format_leftContent );
        foreach my $index ( 1 .. $numberOfKeywords-2 ) {
            $worksheet->write( $row, 3+$index,  $faultSummaryTable_href->{$fault}{$faultTableKeywords[$index]},  $format_centerContent );
        }    
        $worksheet->write( $row, 3+$numberOfKeywords-1,  $faultSummaryTable_href->{$fault}{$faultTableKeywords[$numberOfKeywords-1]},  $format_rightContent );
    }
    my $last_row = $row;
    #LOOP-END last fault?

    #STEP set white text for cells with value == 0
    $worksheet->conditional_formatting(
        $start_row,
        3,
        $last_row,
        3+$numberOfKeywords-1,
        {
            type     => 'cell',
            criteria => '==',
            value    => 0,
            format   => $format_whiteText,
        }
    );

    #STEP set red background for cells with value > 0 in the last 3 keyword columns
    $worksheet->conditional_formatting(
        $start_row,
        3+$numberOfKeywords-3,
        $last_row,
        3+$numberOfKeywords-1,
        {
            type     => 'cell',
            criteria => '>',
            value    => 0,
            format   => $format_dynEnvFail,
        }
    );

    #STEP set red background for Result cells with value "problem"
    $worksheet->conditional_formatting(
        $start_row,
        2,
        $last_row,
        2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'problem',
            format   => $format_dynEnvFail,
        }
    );

    #STEP set row and column widths
    $worksheet->set_row( 2, 110 );
    $worksheet->set_column( 1, 1, 42 );
    $worksheet->set_column( 3, 3+$numberOfKeywords-1, 7 );

    #STEP add auto filter
    $worksheet->autofilter( $start_row - 1, 1, $last_row, 3+$numberOfKeywords-1 );

    return 1;
}

=head2 _create_ws_details

    $success = _create_ws_details( $workbook, $faultDetailsTable_href, $faultSummaryTable_href );

Creates and fills in workbook $workbook the worksheet "Details" with data from $faultDetailsTable_href and $faultSummaryTable_href.

=cut

sub _create_ws_details{
    my $workbook = shift;
    my $faultDetailsTable_href = shift;
    my $faultSummaryTable_href = shift;

    #STEP create work sheet
    my @allFaults = sort keys %{ $faultSummaryTable_href };
    my @faultTableKeywords = @{$faultTableKeywords_href->{keywords}};
    my @faultTableKeywordComments = @{$faultTableKeywords_href->{comments}};
    my $numberOfKeywords = @faultTableKeywords;
    my $worksheet = $workbook->add_worksheet("Details");

    #STEP in row 1 create merged cells "Summary" for each fault
    my $row = 1;
    my $column = 3;
    foreach my $fault ( @allFaults ) {
        $worksheet->merge_range( $row, $column, $row, $column+$numberOfKeywords-1, $fault, $format_Header );
        $column += $numberOfKeywords;
    }

    #STEP in row 2 start the header cells ("Test Case" and "Result")
    $row++;
    $worksheet->write( $row, 1,  "Test Case",  $format_Header2 );
    $worksheet->write( $row, 2,  "Result",  $format_Header2 );

    #STEP in row 2 write the header cells for each fault
    $column = 3;
    foreach my $fault ( @allFaults ) {
        my $blank = '       '; # 7 blanks if auto filter is added
        $worksheet->write( $row, $column,  $blank.$faultTableKeywords[0],  $format_leftHeader );
        $worksheet->write_comment( $row, $column, $faultTableKeywordComments[0] );
        foreach my $index ( 1 .. $numberOfKeywords-2 ) {
            $worksheet->write( $row, $column+$index,  $blank.$faultTableKeywords[$index],  $format_centerHeader );
            $worksheet->write_comment( $row, $column+$index, $faultTableKeywordComments[$index] );
        }    
        $worksheet->write( $row, $column+$numberOfKeywords-1,  $blank.$faultTableKeywords[$numberOfKeywords-1],  $format_rightHeader );
        $worksheet->write_comment( $row, $column+$numberOfKeywords-1, $faultTableKeywordComments[$numberOfKeywords-1] );
        $column += $numberOfKeywords;
    }

    #LOOP-START loop over test cases in $faultDetailsTable_href
    my $start_row = $row + 1;
    foreach my $testCase ( sort keys %{ $faultDetailsTable_href } ) {

        #STEP in next row start the content cells for "Test Case" and "Result"
        $row++;
        $worksheet->write( $row, 1,  $testCase,  $format_Content );
        my $result = $faultDetailsTable_href->{$testCase}{Result};
        $worksheet->write( $row, 2,  $result,  $format_Content );
        delete $faultDetailsTable_href->{$testCase}{Result};

        #LOOP-START loop over all faults in the table
        $column = 3;
        foreach my $fault ( @allFaults ) {
            
            #STEP set value 0 for all keywords if the current fault is not defined for the current test case
            if( not defined $faultDetailsTable_href->{$testCase}{$fault} ) {
                foreach my $keyword ( @faultTableKeywords ) {
                    $faultDetailsTable_href->{$testCase}{$fault}{$keyword} = 0;
                }
            }

            #STEP write the table contents for the current fault
            $worksheet->write( $row, $column,  $faultDetailsTable_href->{$testCase}{$fault}{$faultTableKeywords[0]},  $format_leftContent );
            foreach my $index ( 1 .. $numberOfKeywords-2 ) {
                $worksheet->write( $row, $column+$index,  $faultDetailsTable_href->{$testCase}{$fault}{$faultTableKeywords[$index]},  $format_centerContent );
            }    
            $worksheet->write( $row, $column+$numberOfKeywords-1,  $faultDetailsTable_href->{$testCase}{$fault}{$faultTableKeywords[$numberOfKeywords-1]},  $format_rightContent );
            $column += $numberOfKeywords;
        }
        #LOOP-END last fault?
    }
    my $last_row = $row;
    #LOOP-END last test case?

    #LOOP-START loop over all faults in the table
    $column = 3;
    foreach my $fault ( @allFaults ) {

        #STEP set white text for cells with value == 0
        $worksheet->conditional_formatting(
            $start_row,
            $column,
            $last_row,
            $column+$numberOfKeywords-1,
            {
                type     => 'cell',
                criteria => '==',
                value    => 0,
                format   => $format_whiteText,
            }
        );
    
        #STEP set red background for cells with value > 0 in the last 3 keyword columns of a fault
        $worksheet->conditional_formatting(
            $start_row,
            $column+$numberOfKeywords-3,
            $last_row,
            $column+$numberOfKeywords-1,
            {
                type     => 'cell',
                criteria => '>',
                value    => 0,
                format   => $format_dynEnvFail,
            }
        );
        $column += $numberOfKeywords;
    }
    #LOOP-END last fault?

    #STEP set red background for Result cells with value "problem"
    $worksheet->conditional_formatting(
        $start_row,
        2,
        $last_row,
        2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'problem',
            format   => $format_dynEnvFail,
        }
    );


    #STEP set row and column widths
    $worksheet->set_row( 2, 110 );
    $worksheet->set_column( 1, 1, 42 );
    $worksheet->set_column( 3, 3+@allFaults*$numberOfKeywords-1, 4.29 );

    #STEP add auto filter
    $worksheet->autofilter( $start_row - 1, 1, $last_row, 3+@allFaults*$numberOfKeywords-1 );

    return 1;
}

END {
    # create the Excel fault table if perl is ending
    create_fault_table();
}

__PACKAGE__->meta->make_immutable;

1;

