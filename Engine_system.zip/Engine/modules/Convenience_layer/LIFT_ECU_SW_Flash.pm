# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_ECU_SW_Flash;

use strict;
use warnings;
use LIFT_general;
use LIFT_Renesas_ECU_Flash;
use LIFT_PRITT;
use LIFT_labcar;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  ECU_SW_AutoFlash
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_ECU_SW_Flash $Revision: 1.2

=head1 SYNOPSIS

    use LIFT_ECU_SW_Flash

    $result = ECU_SW_AutoFlash([$hexFilepath]);
    
=head1 DESCRIPTION

This is a convenience layer module for flashing ECU software. Calls the device layer function depending on the device configured in Testbench. 

=head1 CONFIGURATION

=head2 Testbench Configuration (LIFT_Testbenches.pm)

    'Devices' => {
        ...
        'Renesas_Flash_Tool' =>
        {

         ##################################
         #      PARAMETERS FOR V2.05      #
         ##################################

         #1. ECU_type ( mandatory )
         #2. FlashTool_Sl_Num ( mandatory )
         #3. Project_Workspace ( if not given, default workspace based on ECU_type will be taken )
         #4. FlashTool_exe_path ( if not given, version of exe will be considered 
                                  based on Project_Workspace )
         1. 'ECU_type' => 'R1L1MB',       #  ECU_type can be R1L, R1L1MB, D4 or D3
                                          #  RenesasR1xTypeB = "R1L"
                                          #  RenesasR1x10623 = "R1L"
                                          #  RenesasR1xTypeC = "R1L1MB"
                                          #  RenesasR1x10643 = "R1L1MB"
                                          #  RenesasP1xD3    = "D3"
                                          #  RenesasP1xD4    = "D4"

             folder structure should be as following:
             e.g: if the ECU_type is : "R1L1MB"
             ..\config\Tools\Renesas\R1L1MB_ecuFlash and must contain .rpj and .fcf files
             
            user can also use their own configuration by giving it as ECU type string in the format:
            'rwsProj;needsCleanHex;extendCodeFlash'
            e.g.: geely;1;1 
            where geely has to be a folder below config/Tools/Renesas with same structure like 
            R1L1MB_ecuFlash
         
         2. 'FlashTool_Sl_Num' => '3es049632c',   #  written on flashtool

         3. 'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # default project workspace
            
             NOTE: workspace path should be the folder path for V2.05

         
           # Complete path of the renesas flash exe
           # IF not configured, by default the exe for version 2.05 will be taken from the path: 
           # C:\Program Files (x86)\Renesas Electronics\Programming Tools\
           #   Renesas Flash Programmer V2.05\RFP.exe

         4. 'FlashTool_exe_path' => 'C:\Program Files (x86)\Renesas Electronics\Programming Tools\
                                    Renesas Flash Programmer V3.06\RFPV3.exe',

         NOTE: If the 'FlashTool_exe_path' is not configured then based on the 'Project_Workspace'
                 the default exe for V2.05 or V3.06 is considered
        
         ##################################
         #      PARAMETERS FOR V3.06      #
         ##################################
         
         #1. Project_Workspace ( mandatory: created using RFP V3.06 )
         #2. FlashTool_exe_path ( if not given version of exe will be considered
                                  based on Project_Workspace )

         #1. PROJECT WORKSPACE
         
         # CASE 1: Single Workspace File (.rpj)
         
         # Select erase, program and verify options in a single .rpj file 
         # and also (.hex and dflash.hex or merged.hex)
         
         # NOTE: Please check once if this is supported by flashing manually.

         'Project_Workspace' => "$PRJCFG_path . '\Tools\Renesas\vw_h4.rpj",   

         # CASE 2: Multiple Workspace Files (.rpj)

         # Select separate .rpj files when erase and program are not supported 
         # in the same connect cycle of Renesas Flash Tool.

         # Note: Order of execution of .rpj file is based on the configuration in parameter:
         #      'Project_Workspace'.

         'Project_Workspace' => ["$PRJCFG_path . '\Tools\Renesas\vw_m04_erase.rpj",
                                 "$PRJCFG_path . '\Tools\Renesas\vw_m04_program.rpj"],

         #2. FLASH TOOL EXE PATH

         'FlashTool_exe_path' => 'C:\Program Files (x86)\Renesas Electronics\Programming Tools\
                                  Renesas Flash Programmer V3.06\RFPV3.exe',
                                  
         NOTE: If the 'FlashTool_exe_path' is not configured then based on the 'Project_Workspace'
               the default exe for V2.05 or V3.06 will be considered.
        },
    },
    
=head1 FUNCTIONS


=head2 ECU_SW_AutoFlash

    $result = ECU_SW_AutoFlash([,$hexFilepath_mix]);

Flashes the ECU SW using the Renesas Flash Programmer Tool. Calls the device layer function of Renesas.
Calls pritt and labcar functionality to control ECU on and off.

Steps followed while flashing the SW:

1. ECU off

2. Init PRITT.

3. Connect PRITT.

4. ECU on 

5. Flash ECU SW with Renesas.

6. ECU off 

7. disconnect PRITT

8. ECU on and wait 5sec

B<Arguments:>

=over

=item $hexFilepath_mix

B<FOR V2.05 :> The absolute path of hex file for the SW to be flashed. 
If not mentioned here, reads the SAD file path from the config file and uses the same path to search for .hex and _dlash.hex file.
Supports flashing for .hex and dflash.hex files only.

B<FOR V3.06 :> The absolute path of hex/merged hex file for the SW to be flashed.

If not mentioned here, reads the SAD file path from the config file and uses the same path to search for *.hex file.

If *merged.hex is present in the folder then it will be considered for flashing, else *merged.hex will be prepared from hex and dflah hex file. 

B<NOTE: Suported for E2 emulator, not for E1 emulator.
        Supports flashing of only *merged.hex file only
        The hex file configured in *.rpj will not be considered for flashing>

=back

B<Return Values:>

=over

=item $result

1 - offline, success

undef - error

=back

B<Examples:>

B<FOR V2.05 :> Supports flashing for .hex and dflash.hex files, dflash hex file is considered based on .hex file.

1. In case of single hex file to be flashed.

   $result = ECU_SW_AutoFlash('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3.hex');

B<FOR V3.06 :>

1. Merged Hex file from sad file path configured in config is considered.

   $result = ECU_SW_AutoFlash();

2. Flashing only merged hex file.
 
   $result = ECU_SW_AutoFlash('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3_merged.hex');
   
3. when hex file is passed as argument , TurboLIFT searches for merged hex in same folder as that of hex file path
    if present then merged hex file is considered for flashing, else
    merged hex file is prepared from hex file and dflash hex file, provided dflash hex is present in the same folder.
 
   $result = ECU_SW_AutoFlash('C:\TSG4\config\TO1201_B2_0035_BB100062_Cat3.hex');

B<Notes:>

FOR V2.05:
RFP.exe should be present in the path "C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V2.05\RFP.exe".
and corresponding project files to be present in "..\config\Tools\Renesas" for the ECU type that is mentioned.

FOR V3.06:
RFP.exe should be present in the path "C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V3.06\RFPV3.exe".
corresponding project files must be configured in LIFT_Testbenches.pm.

=cut

sub ECU_SW_AutoFlash {
    my @args            = @_;
    my $hexFilepath_mix = shift @args;
    my $result;

    S_w2log( 2, "ECU_SW_AutoFlash\n" );

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    PRT_init() || return;
    PRT_connect() || return;
    S_wait_ms(1000);
    LC_ECU_On();
    S_wait_ms(1000);
    $result = Renesas_ECU_AutoFlash($hexFilepath_mix);
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    PRT_disconnect();

    LC_ECU_On();
    S_wait_ms(5000);

    return $result;
}

1;
