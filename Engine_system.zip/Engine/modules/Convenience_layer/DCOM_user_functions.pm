package DCOM_user_functions;

=head1 NAME

DCOM_user_functions 

Provide user defined functions for DCOM tests

=head1 SYNOPSIS

    use DCOM_user_functions;

    ...

=cut

use strict qw(vars);
use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(   
            	get_SW_version                             
            );


use LIFT_DCOM;
use LIFT_general;


#####################################################################
               
=head2 get_SW_version
               
    $version = get_SW_version(  )
    Function to get the SW version Number    

=cut

#####################################################################

sub get_SW_version
{
    my $SWVersion;
    if(grep {$_ eq 'none'} @{$STEPS_config::STEPS_Testbench->{'Functions'}{'Simulator'}{'general'}} )
    {                                          
      $SWVersion = read_SW_version();   # command to get SW Version
      print "DCOM_get_SW_version -- $SWVersion\n";
      $ENV{'ECU_SW_VERSION'} = "SWVersion:$SWVersion";
    }
    else
    {
#       $SWVersion = DIAG_log_SW_version();    
    }
}

#####################################################################
               
=head2 read_SW_version
               
    $version = read_SW_version(  )
    Function to read the SW version Number (for non AS projects)    

=cut

#####################################################################

sub read_SW_version
{

	my (@HEX_vals,$Request_response, $SW_Version);
	
 	STEPS_DCOM::DCOM_start_communication('Starts Communication');
	
	#request 
	S_w2rep("Sending Requrest 22 F1 89\n");
	$Request_response = STEPS_DCOM::DCOM_request('22 F1 89', '62 F1 89', 'relax',"read SW Version");
	
	#format string to return
	$SW_Version = substr($Request_response,9,12);
	@HEX_vals = split(/ /,$SW_Version);
	$SW_Version = "";
	
	#put ASCII chars	
	$SW_Version = pack("cccc", hex($HEX_vals[0]),hex($HEX_vals[1]),hex($HEX_vals[2]),hex($HEX_vals[3]));
	S_w2rep("SW_Version is $SW_Version\n");

  STEPS_DCOM::DCOM_stop_communication('Starts Communication');

	return $SW_Version;
}




