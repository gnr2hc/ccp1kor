# C:\ISMPerl\V5_6_1\bin\Perl.exe
package LIFT_DCOM;

=head1 NAME

LIFT_DCOM 

Provide LIFT useful functions for DCOM tests

Note:
DCOM_check_scan_table, DCOM_SimTester and DCOM_SimTester_WaitForResponse should not be used in test cases

=head1 SYNOPSIS

    use LIFT_DCOM;

    DCOM_comment
    DCOM_start_communication
    DCOM_stop_communication
    DCOM_delay
    DCOM_wait_for_user
    DCOM_request
    DCOM_enable_CommAsynchronous
    DCOM_disable_CommAsynchronous
    DCOM_evaluate
    DCOM_scan_table
    DCOM_not_in_scan_table
    DCOM_check_scan_table
    DCOM_dependent_requests
    DCOM_check_label
    DCOM_define_label
    DCOM_set_label
    DCOM_check_NET_signal
    DCOM_param
    DCOM_tcpar
    DCOM_prjpar
    DCOM_SimTester
    DCOM_SimTester_WaitForResponse
    DCOM_read_label
    DCOM_IC
    DCOM_SetEeprom
    DCOM_GetEeprom
    DCOM_LC_set_label
    DCOM_LC_check_label
    DCOM_LC_set_signal
    DCOM_LC_check_signal
    DCOM_LC_bind_const
    DCOM_LC_release_const
    DCOM_LC_do_interrupt_line
    DCOM_LC_undo_interrupt_line
    DCOM_get_environment
    DCOM_request_func
    DCOM_request_general
    DCOM_check_request_definition
    DCOM_resolve_label_value
    DCOM_evaluate_phys
    DCOM_evaluate_hex
    DCOM_w2html
    DCOM_w2tc_html
    DCOM_write_campaign_report
    DCOM_request_w2html
    DCOM_setSamtecParam
    DCOM_calc_value_phys
    DCOM_init
    DCOM_final
    DCOM_ecu_on
    DCOM_ecu_off
    DCOM_ignition_on
    DCOM_ignition_off
    DCOM_clear_DTCs
    DCOM_CA_read_can_signals
    DCOM_CA_write_can_signals
    DCOM_CA_disable_messages
    DCOM_CA_enable_messages
    DCOM_CA_trace_start
    DCOM_CA_trace_stop
    DCOM_set_error
    DCOM_set_electric_signals   
    DCOM_reset_electric_signals 
    DCOM_set_target_speed
    DCOM_goto_target_speed
    DCOM_set_wheel_speeds_kmh
    DCOM_set_Engine_speed
    DCOM_reset_Engine_speed
    DCOM_ecu_reset
    DCOM_manipulate_lines 
    DCOM_w2TestStep
    DCOM_set_addressing_mode
    DCOM_evaluate_response_bytes
    DCOM_set_Ubatt
    DCOM_set_verdict
    DCOM_reset_speed
    DCOM_start_CyclicTesterPresent
    DCOM_start_CyclicMessage
    DCOM_stop_CyclicTesterPresent
    DCOM_stop_CyclicMessage
    DCOM_CAN_SendMessage
    DCOM_read_and_eval_fcm_rb
    DCOM_read_and_eval_fcm_cu
    DCOM_read_and_eval_DTCStatusBits
    DCOM_read_and_eval_FaultStatusBits
    DCOM_read_and_eval_DTCInformation
    DCOM_wait_ms
    DCOM_set_timer_zero
    DCOM_wait_ms_until
    DCOM_read_timer
    DCOM_clear_all_fcm
    DCOM_read_and_eval_DTCExtDataRecbyDTCNum
    DCOM_get_FaultValue_from_mapping
    DCOM_CA_Trace_get_ReqResp
    DCOM_config_labelvalue_of_request
    DCOM_getReqestResponseFromMapping
    DCOM_get_ReqResp_from_dataref
    DCOM_eval_ReqResp_from_dataref
    DCOM_eval_ResponseTime_from_dataref
    DCOM_FR_trace_start
    DCOM_FR_trace_stop
    DCOM_FR_Trace_get_ReqResp

=cut

use LIFT_general;       # use STEPS_general;
                        # use STEPS_labcar_ng;
use LIFT_CD;            # use STEPS_diag;
use LIFT_evaluation;    # use STEPS_evaluation;
use DCOM_user_functions;
                        # use STEPS_DCOM_mapping;
                        # use STEPS_DNCSIM;
use LIFT_CANoe;         # use STEPS_can_access;
use LIFT_MLC;
use LIFT_PD; 
use LIFT_labcar;

use LIFT_can_access;
                       # use STEPS_TKWinX;
                        
use LIFT_vector_cantool;
use Data::Dumper;

use strict qw(vars);

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;
# next 2 lines edited by CVS, DO NOT MODIFY

@ISA = qw(Exporter);
@EXPORT = qw(  
              DCOM_comment
              DCOM_start_communication
              DCOM_stop_communication
              DCOM_delay
              DCOM_wait_for_user
              DCOM_request
              DCOM_enable_CommAsynchronous
              DCOM_disable_CommAsynchronous
              DCOM_evaluate
              DCOM_scan_table
              DCOM_not_in_scan_table
              DCOM_check_scan_table
              DCOM_dependent_requests
              DCOM_check_label
              DCOM_define_label
              DCOM_set_label
              DCOM_check_NET_signal
              DCOM_param
              DCOM_tcpar
              DCOM_prjpar
              DCOM_SimTester
              DCOM_SimTester_WaitForResponse
              DCOM_read_label
              DCOM_IC
              DCOM_SetEeprom
              DCOM_GetEeprom
              DCOM_LC_set_label
              DCOM_LC_check_label
              DCOM_LC_set_signal
              DCOM_LC_check_signal
              DCOM_LC_bind_const
              DCOM_LC_release_const
              DCOM_LC_do_interrupt_line
              DCOM_LC_undo_interrupt_line
              DCOM_get_environment
              DCOM_request_func
              DCOM_request_general
              DCOM_check_request_definition
              DCOM_resolve_label_value
              DCOM_evaluate_phys
              DCOM_evaluate_hex
              DCOM_w2html
              DCOM_w2tc_html
              DCOM_write_campaign_report
              DCOM_calc_value_phys
              DCOM_request_w2html
              DCOM_setSamtecParam
              DCOM_init
              DCOM_final
              DCOM_ecu_on
              DCOM_ecu_off
              DCOM_ignition_on
              DCOM_ignition_off
              DCOM_clear_DTCs
              DCOM_CA_read_can_signals
              DCOM_CA_write_can_signals
              DCOM_CA_disable_messages
              DCOM_CA_enable_messages
              DCOM_CA_trace_start
              DCOM_CA_trace_stop
              DCOM_set_error
              DCOM_set_target_speed
              DCOM_goto_target_speed
              DCOM_set_wheel_speeds_kmh
              DCOM_set_Engine_speed
              DCOM_reset_Engine_speed
              DCOM_ecu_reset
              DCOM_manipulate_lines
              DCOM_w2TestStep
              DCOM_set_addressing_mode
              DCOM_set_electric_signals
              DCOM_evaluate_response_bytes
              DCOM_reset_electric_signals
              DCOM_set_Ubatt
              DCOM_set_verdict
              DCOM_reset_speed
              DCOM_start_CyclicTesterPresent
              DCOM_start_CyclicMessage
              DCOM_stop_CyclicTesterPresent
              DCOM_stop_CyclicMessage
              DCOM_CAN_SendMessage
              DCOM_read_and_eval_fcm_rb
              DCOM_read_and_eval_fcm_cu
              DCOM_read_and_eval_DTCStatusBits
              DCOM_read_and_eval_FaultStatusBits
              DCOM_read_and_eval_DTCInformation
              DCOM_wait_ms
              DCOM_set_timer_zero
              DCOM_wait_ms_until
              DCOM_read_timer
              DCOM_clear_all_fcm
              DCOM_read_and_eval_DTCExtDataRecbyDTCNum
              DCOM_get_FaultValue_from_mapping
              DCOM_CA_Trace_get_ReqResp
              DCOM_config_labelvalue_of_request
              DCOM_getReqestResponseFromMapping
              DCOM_get_ReqResp_from_dataref
              DCOM_eval_ReqResp_from_dataref
              DCOM_eval_ResponseTime_from_dataref
              DCOM_FR_trace_start
              DCOM_FR_trace_stop
              DCOM_FR_Trace_get_ReqResp
              DCOM_getRequestInfofromMapping
              @DoorsIDs
                ); # export subs

####################
# global variables #
####################
my $last_response;
my $EVAL_REPORT_LABEL = 'TEST_STEPS';
our @TC_HTML_TEXT;
our @DoorsIDs;

my (    $TC_cnt, 
        @HTML_TEXT ,
        $STEPS_campaign_report, 
        $count_pass,
        $count_fail,
        $count_none,
        $count_inconc,
        $RB_faults,
        $CU_faults,
        $row_number,
        $write_2_inner_table,
        $current_verdict,
        $TestStepNumber,
        $timer_ref,               # hash reference to timer structure
    );
$TC_cnt = 0;
$row_number = 1;
$TestStepNumber = 1;
undef $write_2_inner_table;
my $GENERIC_Testbench       = {};
my $GENERIC_DCOM_data       = {};
my $GENERIC_ProjectDefaults = {};
my $ProjectDefaults         = {};
my $GENERIC_DiagMapping     = {};
my $GENERIC_CAN_mapping     = {};

our $DCOM_MAPPING;
our $RequestID;
our $ResponseID;
our $FlowControlID;

my $P3_mintime_value;
my $CA_trace_data_file_name;
my $FR_trace_data_file_name;
my $FR_trace_signals_file_name;


# ******************************************************************************
# ******************************************************************************
#
# DCOM Test Commands - Abstract Command Set
#
# ******************************************************************************
# ******************************************************************************


#####################################################################

=head2 DCOM_comment

    DCOM_comment ($STYLE , $TEXT);

Writes $TEXT into the test report. Text size is determined by $STYLE.

    $STYLE      Specifies output formatting in the report (font size).
                'L'     large comment, using HTML tag <H2>
                'M'     medium comment, using HTML tag <H3>
                else    normal comment
    $COMMENT    The comment is written to the test report.

Example:

   DCOM_comment('M', 'my comment');

=cut

################################################################################

sub DCOM_comment {

    my $STYLE = shift;
    my $TEXT = shift;

    my $html_string;

    # check parameters --------------------------------------------------------

    unless (defined( $TEXT )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_comment (STYLE, TEXT)", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # log entries -------------------------------------------------------------

    # standard STEPS logging
    S_w2log( 3, "$TEXT" );
#     S_add2eval_collection( $EVAL_REPORT_LABEL, "$TEXT" );
   
    # for HTML: modify the HTML output of STEPS by putting our own formatting there
    $html_string = pop (@TC_HTML_TEXT);

    if( uc($STYLE) eq 'L' ){
        $html_string = "</P>\n<H2 style='margin-left:1cm'>$html_string</H2><P style='margin-left:1cm'>\n";
    }
    elsif( uc($STYLE) eq 'M' ){
        $html_string = "</P>\n<H3 style='margin-left:1cm'>$html_string</H3><P style='margin-left:1cm'>\n";
    }
    else{
        # no change for small comments
    }

    push( @TC_HTML_TEXT, $html_string );

    # IF DNCSIM: log the entry into DNCSIM log file
    if ( DCOM_get_environment() eq 'DNCSIM' )
    {
        DNCSIM_LogEntry( $TEXT ) if defined $TEXT;
    }

    return 1;
}

################################################################################

=head2 DCOM_start_communication

    DCOM_start_communication ( [ $COMMENT ] );

Starts diagnosis communication. For K line projects, the tester sends the
configured StartCommunication request. Furthermore, the cyclic transmission
of TesterPresent messages is started (depending on the tester configuration).
The response to such a request is not evaluated in detail.

    $COMMENT    The comment is written to the test report. This field is optional.

Example:

   DCOM_start_communication ('my comment');

=cut

################################################################################

sub DCOM_start_communication {

    my $COMMENT = shift;
my $Tester_handle;

    S_w2log(3, "DCOM_start_communication: starting communication with ECU.\n");
    S_w2log(3, "     Comment = $COMMENT\n" ) if defined $COMMENT;
     S_add2eval_collection( $EVAL_REPORT_LABEL, "starting communication with ECU." );
    # IF (DNCSIM)
    if ( DCOM_get_environment() eq 'DNCSIM' )
    {
        S_w2rep("\n");
        DNCSIM_LogEntry ($COMMENT) if defined $COMMENT;

        if ($GENERIC_DCOM_data->{'DNCSIM_START_Request'})
        {
           DCOM_request ($GENERIC_DCOM_data->{'DNCSIM_START_Request'},
           $GENERIC_DCOM_data->{'DNCSIM_START_Response'},
           'relax', 'request due to DCOM_start_communication call')
        }
    }
    # ELSE (LABCAR)
    else
    {
       $Tester_handle =  DCOM_start_CyclicTesterPresent();
       # DCOM_comment('M',"message handle DCOM_start_communication -  $Tester_handle");
        DCOM_delay(0.5);
        CA_trace_stop();       
        CA_trace_start();        
        S_w2rep("\n");
        return $Tester_handle;
    }


}

################################################################################

=head2 DCOM_stop_communication

    DCOM_stop_communication ( [ $COMMENT ] );

Stops diagnosis communication. For K line projects, the tester sends the
configured StopCommunication request.
The response to such a request is not evaluated.
Furthermore, the cyclic transmission of TesterPresent messages is stopped
(depending on the tester configuration).

    $COMMENT    The comment is written to the test report. This field is optional.

Example:

    DCOM_stop_communication ('my comment');

=cut

################################################################################

sub DCOM_stop_communication {
    
    my $COMMENT = shift;
    my $TP_handle = shift;
    
    S_w2log(3, "DCOM_stop_communication: stopping communication with ECU.\n");
    S_w2log(3, "     Comment = $COMMENT\n" ) if defined $COMMENT;
     S_add2eval_collection( $EVAL_REPORT_LABEL, "stopping communication with ECU." );
    # IF (DNCSIM)
    if ( DCOM_get_environment() eq 'DNCSIM' )
    {
        S_w2rep("\n");
        DNCSIM_LogEntry( $COMMENT ) if defined $COMMENT;

        if ($GENERIC_DCOM_data->{'DNCSIM_STOP_Request'})
        {
            DCOM_request ($GENERIC_DCOM_data->{'DNCSIM_STOP_Request'},
                          $GENERIC_DCOM_data->{'DNCSIM_STOP_Response'},
                          'relax', 'request due to DCOM_start_communication call')
        }

    }
    # ELSE (LABCAR)
    else
    {
        if (defined $TP_handle)
        {
            DCOM_stop_CyclicTesterPresent($TP_handle);
        } 
        CA_trace_stop();
    }

    return 1;
}

################################################################################

=head2 DCOM_delay

    DCOM_delay ( $TIME_S [, $COMMENT ] );

Waits for $TIME_S seconds. Depending on the usage of DCOM_start_communication
and DCOM_stop_communication before, TesterPresent messages might be sent during
the delay time.

    $TIME_S     Time to wait in seconds. Values like 0.5 are also allowed.
    $COMMENT    The comment is written to the test report. This field is optional.

Example:

    DCOM_delay ('5','my comment');

=cut

################################################################################

sub DCOM_delay {

    my $TIME_S = shift;
    my $COMMENT = shift;

    my $TIME_MS = $TIME_S * 1000.0;

    S_w2log(3, "DCOM_delay: wait for $TIME_MS ms.\n" );
    S_w2log(3, "     Comment = $COMMENT\n" ) if defined $COMMENT;
     S_add2eval_collection( $EVAL_REPORT_LABEL, "$COMMENT" )if defined $COMMENT;
    # IF (DNCSIM)
    if ( DCOM_get_environment() eq 'DNCSIM' )
    {
        # Note: Usually an automatic transmission of TesterPresent messages
        # should be considered in case of DNCSIM. This should be based on a
        # P3-dependent timing constant, and it should be active if a StartComm
        # function was called before.
        # The actual target tester does the same during delays.

        DNCSIM_RunProcesses( $TIME_MS );
    }
    # ELSE (LABCAR)
    else
    {
        S_wait_ms( $TIME_MS );
    }

    S_w2rep("\n");
    return 1;
}

################################################################################

=head2 DCOM_wait_for_user

    DCOM_wait_for_user ( $TEXT );

Pauses test execution and displays $TEXT to the user in a separate window.
The user has the choice between 'yes' and 'no'. 'yes' sets the testcase verdict
to VERDICT_PASS, 'no' sets the testcase verdict to VERDICT_FAIL.

Example:

    DCOM_wait_for_user ('my text');

=cut

################################################################################

sub DCOM_wait_for_user {

    my $TEXT = shift;

    # check parameters --------------------------------------------------------

    unless (defined( $TEXT )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_wait_for_user('TEXT');", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # raise question to the user ----------------------------------------------

    S_w2log(3, "DCOM_wait_for_user: displaying message and waiting for user input.\n    " );
    
    my $response = S_user_action ( "$TEXT\n\n     Test step OK?\n     ('No' sets testcase verdict to FAIL)", 'YesNo' );

    if( $response =~ /no/i ){
        S_set_verdict('VERDICT_FAIL');
    }

    S_w2rep("\n");
    return 1;
}

################################################################################

=head2 DCOM_request

    $response = DCOM_request ( $REQUEST , $EXPECTED_RESPONSE , $MODE , [ $COMMENT , $NO_EVAL_SWITCH] );

Sends the given request to ECU and evaluates the response.

    $REQUEST            Request message to be sent. Hex bytes separated by spaces
                        should be used.
    $EXPECTED_RESPONSE  Expected response. See DCOM_evaluate() for details.
    $MODE               Response evaluation mode. See DCOM_evaluate() for details.
                        'strict'           Length of expected response has to match exactly.
                        'relax'            Only the specified response bytes have to match.
                                           Additional bytes can be sent by the ECU.
                        'quiet'            No ECU response must be sent.
                        'optional strict'  'strict' or 'quiet'
                        'optional relax'   'relax' or 'quiet'
    $COMMENT            The comment is written to the test report. This field is optional.
    $NO_EVAL_SWITCH     This argument skips the evaluation when set. This field is optional.

    Return Value        The ECU response.

Example:

    DCOM_request ('1A 80', '5A 80', 'strict', 'my comment');

=cut

################################################################################

sub DCOM_request {

    my $REQUEST = shift;
    my $EXPECTED_RESPONSE = shift;
    my $MODE = shift;
    my $COMMENT = shift;
    my $NO_EVAL_SWITCH = shift;
    my @request_bytes;
    my $response;
    my $response_bytes;
    # check parameters --------------------------------------------------------

    unless (defined( $MODE )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_request( REQUEST , EXPECTED_RESPONSE , MODE , [ COMMENT ,$NO_EVAL_SWITCH] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # sending the request message ---------------------------------------------

    S_w2log(3, "DCOM_request: sending request.\n");
    S_w2log(3, "     Request = $REQUEST\n");

    # IF (DNCSIM)
    if ( DCOM_get_environment() eq 'DNCSIM' )
    {
        $REQUEST =~ s/ /,/g;     # substitute spaces ' ' with ','

        $response = DCOM_SimTester( $REQUEST,"PHYSICAL" );

        $response =~ s/,/ /g;
    }
    # ELSE (LABCAR)
    else {
        # TODO: from review point of view, it seems that the MODE parameter is not
        # used as intended in case of DTS 6 tester usage. At least for K line projects
        # this does not work correctly at the moment.
        # TKWinX_configure_phys('');
#         $response = DIAG_send_request ( $REQUEST , $MODE );
          if($main::opt_offline)
          { 
            DCOM_w2html( "$REQUEST;Exp:$EXPECTED_RESPONSE ;PASS;$MODE;$COMMENT" , "T"  , 'green' , "Courier" );
            return 1;
          }    

          @request_bytes = split(/ /, $REQUEST);
          foreach (@request_bytes){$_ = "0x".$_;}
          $response_bytes = CD_send_request_wait_response(\@request_bytes);
          foreach (@$response_bytes){$_ = sprintf("%02X",$_);}
          $response = join(' ',  @$response_bytes);
          if(@$response_bytes[0] eq "7F")
          {
              $COMMENT = $COMMENT."\n Detected NRC -> ".$GENERIC_DiagMapping->{'GlobalNRC'}{@$response_bytes[2]};
          }
    }

    $last_response = uc($response);
    if($last_response eq "0")
    {
      $last_response = ""; 
    }

    # evaluating the response -------------------------------------------------
    unless(defined $NO_EVAL_SWITCH )
    {
      $current_verdict = DCOM_evaluate( $EXPECTED_RESPONSE, $MODE, $COMMENT );
    }
    
       if( $current_verdict eq VERDICT_PASS){
          DCOM_w2html( "$REQUEST;Exp:$EXPECTED_RESPONSE\nDet:$last_response;PASS;$MODE;$COMMENT" , "T"  , 'green' , "Courier" );    
      }
      else{
          DCOM_w2html( "$REQUEST;Exp:$EXPECTED_RESPONSE\nDet:$last_response;FAIL;$MODE;$COMMENT" , "T"  , 'red' , "Courier" );
      }

    return $response;
}


################################################################################

=head2 DCOM_request_func

    $response = DCOM_request_func ( $REQUEST , $EXPECTED_RESPONSE , $MODE , [ $COMMENT ] );

Sends the given request to ECU through functional addressing mode and evaluates the response.

    $REQUEST            Request message to be sent. Hex bytes separated by spaces
                        should be used.
    $EXPECTED_RESPONSE  Expected response. See DCOM_evaluate() for details.
    $MODE               Response evaluation mode. See DCOM_evaluate() for details.
                        'strict'           Length of expected response has to match exactly.
                        'relax'            Only the specified response bytes have to match.
                                           Additional bytes can be sent by the ECU.
                        'quiet'            No ECU response must be sent.
                        'optional strict'  'strict' or 'quiet'
                        'optional relax'   'relax' or 'quiet'
    $COMMENT            The comment is written to the test report. This field is optional.

    Return Value        The ECU response.

Example:

    DCOM_request_func ('14 FF 00', '', 'quiet', 'my comment');

=cut

################################################################################

sub DCOM_request_func {

    my $REQUEST = shift;
    my $EXPECTED_RESPONSE = shift;
    my $MODE = shift;
    my $COMMENT = shift;

    my $response;

    # check parameters --------------------------------------------------------

    unless (defined( $MODE )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_request( REQUEST , EXPECTED_RESPONSE , MODE , [ COMMENT ] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # sending the request message ---------------------------------------------

    S_w2log(3, "DCOM_request_func: sending request.\n");
    S_w2log(3, "     Request = $REQUEST\n");

    #IF (DNCSIM)
    if ( DCOM_get_environment() eq 'DNCSIM' )
    {
        $REQUEST =~ s/ /,/g;     # substitute spaces ' ' with ','
        
        $response = DCOM_SimTester( $REQUEST,"FUNCTIONAL" );

        $response =~ s/,/ /g;
    }
    #ELSE (LABCAR)
    else 
    {
      #IF TESTER TKWINX AND PROTOCOL ISOTP
      if(       ($GENERIC_Testbench->{'Devices'}{'TKWinX'}{'Protocol'} eq 'ISOTP') )
      {
        TKWinX_configure_func('');

        $response = DIAG_send_request ( $REQUEST , $MODE );
      }
      #ELSE FUNCTIONAL ADDRESSING IS NOT SUPPORTED
      else
      {
        S_set_error( " functional addressing only supported for ISOTP and TKWINX!", 110 );
        S_w2rep ("\n");
        return 0;
      }
    }

    $last_response = uc($response);

    if ($last_response == 0 )
     {
       if ($MODE eq 'quiet')
       {
         $last_response = $EXPECTED_RESPONSE;
       }
     }

#     TKWinX_configure_phys('');
    # evaluating the response -------------------------------------------------

    DCOM_evaluate( $EXPECTED_RESPONSE, $MODE, $COMMENT );

    return $response;
}

#####################################################################

=head2 DCOM_enable_CommAsynchronous

    DCOM_enable_CommAsynchronous ( );

This is a GMLAN specific functionality.
It enables the reception of frames on seperate (or additional) IDs.
Only for Samtec.

=cut

#####################################################################

sub DCOM_enable_CommAsynchronous {

    S_w2log(3, "\nDCOM_enable_CommAsynchronous\n");

    # IF (DNCSIM)
    if ( DCOM_get_environment() eq 'DNCSIM' ) {
        # NOT SUPPORTED
        return;
    }
    # (LABCAR)
    unless( DIAG_enable_CommAsynchronous ( ) ) {
        # ERROR
        return;
    }
    return 1;

}

#####################################################################

=head2 DCOM_disable_CommAsynchronous

    DCOM_disable_CommAsynchronous ( );

This is a GMLAN specific functionality.
It disables the reception of frames on seperate (or additional) IDs.
Only for Samtec.


=cut

#####################################################################

sub DCOM_disable_CommAsynchronous {

    S_w2log(3, "\nDCOM_disable_CommAsynchronous\n");

    # IF (DNCSIM)
    if ( DCOM_get_environment() eq 'DNCSIM' ) {
        # NOT SUPPORTED
        return;
    }
    # (LABCAR)
    unless( DIAG_disable_CommAsynchronous ( ) ) {
        # ERROR
        return;
    }
    return 1;

}

################################################################################

=head2 DCOM_evaluate

    DCOM_evaluate ( $EXPECTED_RESPONSE , $MODE , [ $COMMENT ] );

Evaluates the last response to DCOM_request.

    $EXPECTED_RESPONSE  Expected response definition in the following format:

    <bytes>[ MASK: <bytes>][ DataTyp: <number-sequence> Delta: <integer>]

    <bytes>             : Arbitrary number of bytes separated by whitespace (e.g. 50 C1).
    MASK                : Causes only parts of the response to be evaluated.
    DataTyp             : Allows to evaluate values out of the response with respect
                          to a given delta range.
    <number-sequence>   : Sequence of the byte numbers (separated by whitespace) to form an integer value.
                          Byte numbers start with 1. Example: 2 1, which means that in the above example
                          the integer value would be 0xC150 = 49488.
    <integer>           : positive integer number


    $MODE               Specifies the response evaluation mode.

                        'strict'          response must have exactly the same number of bytes as $EXPECTED_RESPONSE
                        'relax'           response must have at least the number of bytes as $EXPECTED_RESPONSE
                        'quiet'           response must be empty (no response)
                        'optional strict' = strict or quiet
                        'optional relax'  = relax or quiet

The bytes of the response are compared with the bytes of $EXPECTED_RESPONSE.
If a MASK is defined then it is applied to both response and $EXPECTED_RESPONSE and the
results are compared.
If DataTyp and Delta is defined then an integer value is calculated out of both
response and $EXPECTED_RESPONSE according to <number-sequence>.
A comparison is then made if the integer values of response and $EXPECTED_RESPONSE
match within the given Delta value.
If the comparison results in a match then the verdict is set to VERDICT_PASS, otherwise
to VERDICT_FAIL.

Example:

    DCOM_evaluate('50 C0 MASK: ff f0 DataTyp: 2 1 Delta: 02', 'strict', 'my comment');

    Assume the response from the ECU is '51 C1'.
    The mask is applied: expected 50C0 & fff0 = 50C0
                         response 51C1 & fff0 = 51C0
    The integer value is calculated: expected C050
                                     response C051
    The difference is less than 2 (Delta), so the verdict will be set to VERDICT_PASS.


    DCOM_evaluate('61 01 19 MASK: 00 00 ff DataTyp: 3 Delta: 05', 'strict', 'my comment');

    Assume the response from the ECU is '61 02 15'.
    The mask is applied: expected 610119 & 0000ff = 000019
                         response 610215 & 0000ff = 000015
    The integer value is calculated: expected 19
                                     response 15
    The difference (i.e.19 - 15 = 4)is less than 5 (Delta), so the verdict will be set to VERDICT_PASS.


    DCOM_evaluate('58 10 MASK: 00 0f', 'strict', 'my comment');

    Assume the response from the ECU is '58 A0'.
    The mask is applied: expected 5810 & 000f = 0000
                         response 58A0 & 000f = 0000
    So the verdict will be set to VERDICT_PASS


<Design>

    write $COMMENT
    $last_response = last response of tester
    extract $DataTyp and $Delta from $EXPECTED_RESPONSE
    # treat empty responses
    if $last_response is empty {
        if $MODE contains 'quiet' or 'optional' {
            set VERDICT_PASS
        }
        else{
            set VERDICT_FAIL
        }
        return verdict
    }
    # treat easy FAIL cases
    if ($MODE contains 'quiet') or
       (length of $last_response < length of $EXPECTED_RESPONSE) or
       ($MODE == 'strict' and length of $last_response != length of $EXPECTED_RESPONSE) {
            set and return VERDICT_FAIL
    }
    $response = $last_response reduced to length of $EXPECTED_RESPONSE
    # treat MASK
    if $EXPECTED_RESPONSE contains a MASK {
        $response = $response & MASK
        $EXPECTED_RESPONSE = $EXPECTED_RESPONSE & MASK
    }
    # response evaluation without DataTyp
    if $EXPECTED_RESPONSE does not contain DataTyp {
        if $response == $EXPECTED_RESPONSE {
            set VERDICT_PASS
        }
        else{
            set VERDICT_FAIL
        }
    }
    # response evaluation with DataTyp
    else{
        calculate $response_value from $response and $DataTyp (byte sequence)
        calculate $expected_value from $EXPECTED_RESPONSE and $DataTyp (byte sequence)
        if abs($response_value-$expected_value) <= $Delta {
            set VERDICT_PASS
        }
        else{
            set VERDICT_FAIL
        }
    }
    return verdict

=cut

################################################################################

sub DCOM_evaluate {

    my $EXPECTED_RESPONSE = shift;
    my $MODE = shift;
    my $COMMENT = shift;

    my $ECU_response = $last_response;
    my ($expected_message, $mask, $data_type, $delta, $mask_type, $verdict, $logtext,
        @expected_message_bytes, @ECU_response_bytes, @mask_bytes, $index,
        @expected_message_numbers, @ECU_response_numbers);

    # check parameters --------------------------------------------------------

    unless (defined( $MODE )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_evaluate( EXPECTED_RESPONSE , MODE , [ COMMENT ] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # perform evaluation ------------------------------------------------------

    S_w2log(3, "DCOM_evaluate: check ECU response.\n");
    S_w2log(3, "     Comment         = $COMMENT\n" ) if defined $COMMENT;
    S_w2log(3, "     Eval Mode       = $MODE\n");
    S_w2log(3, "     Actual Response = $ECU_response\n");

  # exchange the term DataTyp with xDataTyp: this is required because the first two
  # characters of DataTyp (DA) could not be distinguished from valid hex values
  # by the later used regular expressions
  $EXPECTED_RESPONSE =~ s/DataTyp/xDataTyp/i;

    # extract mask, data type and delta from $EXPECTED_RESPONSE
    if( $EXPECTED_RESPONSE =~ /^([0-9a-fA-F ]*)((MASK|xDataTyp).+)?/i ){      # '50 C0 MASK: ff f0 DataTyp: 2 1 Delta: 02
        $expected_message = $1;
        $mask_type = $2;
        $expected_message =~ s/\s+$//;
        S_w2log(3, "     Expected        = $expected_message\n");
    }
    else{
        S_set_error( "Given expected response ($EXPECTED_RESPONSE) is invalid.", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # extract MASK, if MASK is defined before DataTyp
    if( $mask_type =~ /MASK:\s*(([0-9A-F]{2}\s+)+)xDataTyp/i ){
        $mask = $1;
    }
    # extract MASK, if MASK is defined after xDataTyp
    elsif( $mask_type =~ /MASK:\s*(([0-9A-F]{2}\s*)+)/i ){
        $mask = $1;
    }
    elsif( $mask_type =~ /MASK:/i ){
        S_set_error( "Mask definition in given expected response ($EXPECTED_RESPONSE) is invalid.", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # extract DataTyp and Delta
    if( $mask_type =~ /xDataTyp:\s*((\d\d?\s+)+)Delta:\s*([0-9A-F\s]+)/i ){
        $data_type = $1;
        $delta = $3;
    }
    elsif( $mask_type =~ /(xDataTyp:)|(Delta:)/ ){
        S_set_error( "DataTyp or Delta definition in given expected response ($EXPECTED_RESPONSE) is invalid.", 110 );
        S_w2rep ("\n");
        return 0;
    }



    # treat empty responses
    if($ECU_response eq ''){
        if($MODE =~ /quiet|optional/i) {
            S_w2log(3, "     Eval Info       = No ECU response and mode is 'quiet' or 'optional'.\n");
            S_w2log(3, "     Verdict         = PASS\n");
            $verdict = 'VERDICT_PASS';
        }
        else{
            S_w2log(3, "     Eval Info       = No ECU response and mode is not 'quiet' or 'optional'.\n");
            S_w2log(3, "     Verdict         = FAIL\n");
            $verdict = 'VERDICT_FAIL';
        }

        S_w2rep("\n");
        S_set_verdict( $verdict );
        S_w2rep ("\n");
        return $verdict;
    }

    # treat easy FAIL case 1: mode = quiet and non-empty response
    if( $MODE =~ /quiet/i ){
        S_w2log(3, "     Eval Info       = ECU response and mode is 'quiet'.\n");
        S_w2log(3, "     Verdict         = FAIL\n");
       $verdict = 'VERDICT_FAIL';
       S_w2rep("\n");
       S_set_verdict( $verdict );
       S_w2rep ("\n");
       return $verdict;
    }

    # treat easy FAIL case 2: ECU response has less bytes than expected response
    if( length($last_response) < length($expected_message) ){
        S_w2log(3, "     Eval Info       = ECU response has fewer bytes than expected response.\n");
        S_w2log(3, "     Verdict         = FAIL\n");
        $verdict = 'VERDICT_FAIL';
        S_w2rep("\n");
        S_set_verdict( $verdict );
        S_w2rep ("\n");
        return $verdict;
    }

    # treat easy FAIL case 3: mode = strict and ECU response has not same number of bytes than expected response
    if( ( $MODE =~ /strict/i ) and ( length($last_response) != length($expected_message) ) ){
        S_w2log(3, "     Eval Info       = Mode is 'strict' and ECU response has not the same number of bytes than expected response.\n");
        S_w2log(3, "     Verdict         = FAIL\n");
        $verdict = 'VERDICT_FAIL';
        S_w2rep("\n");
        S_set_verdict( $verdict );
        S_w2rep ("\n");
        return $verdict;
    }

    # split strings into bytes and calculate byte values
    @expected_message_bytes = split(/ /, $expected_message);
    foreach my $byte (@expected_message_bytes){push(@expected_message_numbers, hex($byte))}
    @ECU_response_bytes = split(/ /, $ECU_response);
    foreach my $byte (@ECU_response_bytes){push(@ECU_response_numbers, hex($byte))}

    # treat MASK
    if( defined( $mask ) ){
        S_w2log(3, "     Mask            = $mask\n");
        @mask_bytes = split(/ /, $mask);

        $index = 0;
        foreach my $byte (@mask_bytes){
            $expected_message_numbers[$index] = $expected_message_numbers[$index] & hex($byte);
            $expected_message_bytes[$index] = sprintf('%02X', $expected_message_numbers[$index]);
            $ECU_response_numbers[$index] = $ECU_response_numbers[$index] & hex($byte);
            $ECU_response_bytes[$index] = sprintf('%02X', $ECU_response_numbers[$index]);
            $index++;
        }
        S_w2log(3, "     Masked Response = @ECU_response_bytes\n");
        S_w2log(3, "     Masked Expected = @expected_message_bytes\n");
    }

    # response evaluation without DataTyp
    unless( defined( $data_type ) ){
        my $mismatch = 0;
        $index = 0;
        # compare each number
        foreach my $number (@expected_message_numbers){
            if( $number != $ECU_response_numbers[$index] ){
                $mismatch = 1;
                last;
            }
            $index++;
        }

        if( $mismatch ){
            S_w2log(3, "     Eval Info       = ECU response does not match expected response with mode '$MODE'.\n");
            S_w2log(3, "     Verdict         = FAIL\n");
            $verdict = 'VERDICT_FAIL';
        }
        else{
            S_w2log(3, "     Eval Info       = ECU response matches expected response with mode '$MODE'.\n");
            S_w2log(3, "     Verdict         = PASS\n");
            $verdict = 'VERDICT_PASS';
        }
    }
    # response evaluation with DataTyp
    else{
        S_w2log(3, "     Data Bytes      = $data_type\n");
        S_w2log(3, "     Delta           = $delta\n");
        my (@new_ECU_response_bytes, @new_expected_message_bytes);
        my @data_indices = split(/ /, $data_type);
        $delta =~ s/\s//g;
        my $delta_dec = hex( $delta );
        $index = 0;
        # reorganize bytes in ECU_response and expected_response according to $data_type
        foreach my $data_index (@data_indices){
            $new_ECU_response_bytes[$index] = $ECU_response_bytes[$data_index-1];
            $new_expected_message_bytes[$index] = $expected_message_bytes[$data_index-1];
            $index++;
        }

        #calculate $response_value and $expected_value from $response and $DataTyp (byte sequence)
        my $response_value = hex( join('',  @new_ECU_response_bytes) );
        my $expected_value = hex( join('',  @new_expected_message_bytes) );

        if( abs( $response_value - $expected_value ) <= $delta_dec ){
            S_w2log(3, "     Eval Info       = Value ($response_value) calculated from ECU response, Mask and DataTyp matches equivalent value ($expected_value) from expected response within given delta ($delta_dec).\n");
            S_w2log(3, "     Verdict         = PASS\n");
            $verdict = 'VERDICT_PASS';
        }
        else{
            S_w2log(3, "     Eval Info       = Value ($response_value) calculated from ECU response, Mask and DataTyp does not match equivalent value ($expected_value) from expected response within given delta ($delta).\n");
            S_w2log(3, "     Verdict         = FAIL\n");
            $verdict = 'VERDICT_FAIL';
        }
    }

    S_w2rep("\n");
    S_set_verdict( $verdict );
    S_w2rep ("\n");
    return $verdict;

}

################################################################################

=head2 DCOM_scan_table

    DCOM_scan_table ( $STARTBYTE, $LENGTH, $EXPECTED_RESPONSE [, $COMMENT ] )

Checks if the expected response is found in the last ECU response. The response
is expected to have multiple values in a kind of table that should be searched.

Takes the last ECU response and extracts from byte $STARTBYTE (counted from 1)
the next $LENGTH bytes and compares them with $EXPECTED_RESPONSE taking into
account the mask if one is defined (see DCOM_evaluate about how to define a mask).
If no match is found then the next $LENGTH bytes are taken from the ECU response
and again compared with $EXPECTED_RESPONSE and so on.
$RESULT is set to 1 if a match was found and to 0 if no match was found at all.

Sets the verdict to PASS if a match was found, otherwise FAIL.
DCOM_not_in_scan_table judges the result in the opposite way.

Example:

    DCOM_request ('18 00 ff 00','58',relax,'my comment');
    DCOM_scan_table ('3','3','52 00 80','my comment');

    Assume the response from the ECU is '58 03 52 06 00 56 20 80 52 00 80'.
    Starting from the third byte the next 3 bytes are compared with '52 00 80'
    Since no match is found, the next 3 bytes are taken from the ECU response
    and again compared.and so on
    The last 3 bytes match with the expected response
    So the verdict will be set to VERDICT_PASS.

=cut

################################################################################

sub DCOM_scan_table {

    my $STARTBYTE = shift;
    my $LENGTH = shift;
    my $EXPECTED_RESPONSE = shift;
    my $COMMENT = shift;

    my $verdict;

    # check parameters --------------------------------------------------------

    unless (defined( $EXPECTED_RESPONSE )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_scan_table ( OFFSET, LENGTH, EXPECTED_RESPONSE [, COMMENT ] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # perform evaluation ------------------------------------------------------

    S_w2log(3, "DCOM_scan_table: check if response part is found.\n");
    S_w2log(3, "     Comment         = $COMMENT\n") if defined $COMMENT;

    my $success = DCOM_check_scan_table ( $STARTBYTE, $LENGTH, $EXPECTED_RESPONSE );

    # check if syntax problem was found
    return if $success == -1;

    if( $success ){
        S_w2log(3, "     Verdict         = PASS\n");
        $verdict = 'VERDICT_PASS';
    }
    else{
        S_w2log(3, "     Verdict         = FAIL\n");
        $verdict = 'VERDICT_FAIL';
    }

    S_w2rep("\n");
    S_set_verdict( $verdict );
    S_w2rep ("\n");
    return $verdict;
}

################################################################################

=head2 DCOM_not_in_scan_table

    DCOM_not_in_scan_table ( $STARTBYTE, $LENGTH, $EXPECTED_RESPONSE [, $COMMENT ] )

Checks if the expected response is NOT found in the last ECU response. The response
is expected to have multiple values in a kind of table that should be searched.

Takes the last ECU response and extracts from byte $STARTBYTE (counted from 1)
the next $LENGTH bytes and compares them with $EXPECTED_RESPONSE taking into
account the mask if one is defined (see DCOM_evaluate about how to define a mask).
If no match is found then the next $LENGTH bytes are taken from the ECU response
and again compared with $EXPECTED_RESPONSE and so on.
$RESULT is set to 1 if a match was found and to 0 if no match was found at all.

Sets the verdict to PASS if no match was found, otherwise FAIL.
DCOM_scan_table judges the result in the opposite way.

Example:

    DCOM_not_in_scan_table ('4','2','10 81','my comment');

=cut

################################################################################

sub DCOM_not_in_scan_table {

    my $STARTBYTE = shift;
    my $LENGTH = shift;
    my $EXPECTED_RESPONSE = shift;
    my $COMMENT = shift;

    my $verdict;

    # check parameters --------------------------------------------------------

    unless (defined( $EXPECTED_RESPONSE )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_not_in_scan_table ( OFFSET, LENGTH, EXPECTED_RESPONSE [, COMMENT ] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    # perform evaluation ------------------------------------------------------

    S_w2log(3, "DCOM_not_in_scan_table: check if response part is found.\n");
    S_w2log(3, "     Comment         = $COMMENT\n") if defined $COMMENT;

    my $success = DCOM_check_scan_table ( $STARTBYTE, $LENGTH, $EXPECTED_RESPONSE );

    # check if syntax problem was found
    return if $success == -1;

    if( $success ){
        S_w2log(3, "     Verdict         = FAIL\n");
        $verdict = 'VERDICT_FAIL';
    }
    else{
        S_w2log(3, "     Verdict         = PASS\n");
        $verdict = 'VERDICT_PASS';
    }

    S_w2rep("\n");
    S_set_verdict( $verdict );
    S_w2rep ("\n");
    return $verdict;
}

################################################################################

=head2 DCOM_check_scan_table

    $RESULT = DCOM_check_scan_table ( $STARTBYTE, $LENGTH, $EXPECTED_RESPONSE )

Internal support function that is used by DCOM_scan_table and DCOM_not_in_scan_table.

Takes the last ECU response and extracts from byte $STARTBYTE (counted from 1)
the next $LENGTH bytes and compares them with $EXPECTED_RESPONSE taking into
account the mask if one is defined (see DCOM_evaluate about how to define a mask).
If no match is found then the next $LENGTH bytes are taken from the ECU response
and again compared with $EXPECTED_RESPONSE and so on.

$RESULT is set to 1 if a match was found and to 0 if no match was found at all.
It is set to -1 is a syntax error was found.

Example:

    $result1 = DCOM_check_scan_table ( 3, 2, '30 40' );
    $result2 = DCOM_check_scan_table ( 3, 2, '30 40 MASK: F0 F0' );

    If the last ECU response was '5A 80 11 22 33 44 55 66' then
    $result1 = 0 and $result2 = 1

=cut

################################################################################

sub DCOM_check_scan_table {

    my $STARTBYTE = shift;
    my $LENGTH = shift;
    my $EXPECTED_RESPONSE = shift;

    my $ECU_response = $last_response;
    my ($expected_message, $mask, $data_type, $delta, $mask_type, $verdict, $logtext,
        @expected_message_bytes, @ECU_response_bytes, @mask_bytes, $index, $number,
        @expected_message_numbers, @ECU_response_numbers, $data_index, $mismatch, $position);

    # check parameters --------------------------------------------------------

    unless (defined( $EXPECTED_RESPONSE )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_check_scan_table ( OFFSET, LENGTH, EXPECTED_RESPONSE )", 110 );
        S_w2rep ("\n");
        return -1;
    }

    # perform evaluation ------------------------------------------------------

    S_w2log(3, "     Actual Response = $ECU_response\n");

    # extract mask from $EXPECTED_RESPONSE
    if( $EXPECTED_RESPONSE =~ /^([0-9a-fA-F ]+)(MASK.+)?/i ){      # 50 C0 MASK: ff f0
        $expected_message = $1;
        $mask_type = $2;
        $expected_message =~ s/\s+$//;
        S_w2log(3, "     Expected Bytes  = $expected_message\n");
        S_w2log(3, "     Start Byte      = $STARTBYTE\n");
        S_w2log(3, "     Length          = $LENGTH\n");
    }
    else{
        S_set_error( "Given expected response ($EXPECTED_RESPONSE) is invalid.", 110 );
        S_w2rep ("\n");
        return -1;
    }

    # extract MASK
    if( $mask_type =~ /MASK:\s*(([0-9A-F]{2}\s*)+)/i ){
        $mask = $1;
        S_w2log(3, "     Mask            = $mask\n");
        @mask_bytes = split(/ /, $mask);

    }
    elsif( $mask_type =~ /MASK:/i ){
        S_set_error( "Mask definition in given expected response ($EXPECTED_RESPONSE) is invalid.", 110 );
        S_w2rep ("\n");
        return -1;
    }

    # split strings into bytes and calculate byte values
    @expected_message_bytes = split(/ /, $expected_message);
    foreach my $byte (@expected_message_bytes){push(@expected_message_numbers, hex($byte))}
    @ECU_response_bytes = split(/ /, $ECU_response);
    foreach my $byte (@ECU_response_bytes){push(@ECU_response_numbers, hex($byte))}

    # check if length of expected response matches $LENGTH
    if( $LENGTH != @expected_message_bytes ){
        S_set_error( "Given length = $LENGTH does not match length of given expected response ($EXPECTED_RESPONSE).", 110 );
        S_w2rep ("\n");
        return -1;
    }

    # shift offset bytes from ECU response
    splice(@ECU_response_bytes, 0, $STARTBYTE-1);
    splice(@ECU_response_numbers, 0, $STARTBYTE-1);


    $position = $STARTBYTE;

    if(@ECU_response_bytes >= $LENGTH){
        while( @ECU_response_bytes >= $LENGTH ){

            $mismatch = 0;
            for( $index = 0; $index < $LENGTH; $index++){
                if( defined($mask) ){
                    my $byte = $mask_bytes[$index];
                    $expected_message_numbers[$index] = $expected_message_numbers[$index] & hex($byte);
                    $expected_message_bytes[$index] = sprintf('%02X', $expected_message_numbers[$index]);
                    $ECU_response_numbers[$index] = $ECU_response_numbers[$index] & hex($byte);
                    $ECU_response_bytes[$index] = sprintf('%02X', $ECU_response_numbers[$index]);
                }

                if( $expected_message_numbers[$index] != $ECU_response_numbers[$index] ){
                    $mismatch = 1;
                    last;
                }
            }

            unless( $mismatch ){
                last;
            }

            splice(@ECU_response_bytes, 0, $LENGTH);
            splice(@ECU_response_numbers, 0, $LENGTH);
            $position += $LENGTH;
        }
    }
    else{
        $mismatch = 1;
    }

    if( $mismatch ){
        S_w2log(3, "     Eval Info       = No matching bytes found in ECU response for expected response (@expected_message_bytes) after applying the mask (if defined).\n");
        return 0;
    }
    else{
        S_w2log(3, "     Eval Info       = Matching bytes found in ECU response at position $position for expected response (@expected_message_bytes) after applying the mask (if defined).\n");
        return 1;
    }

}

################################################################################

=head2 DCOM_dependent_requests

    DCOM_dependent_requests ( $REQUESTS, $FUNCTION, $ARGUMENT [, $COMMENT, $DELAY ] );

Sends multiple requests to ECU and checks if the responses match with the
corresponding expected values. Both requests and expected responses are defined
in $REQUESTS and separated with '|'.
Requests may depend on previously received responses using the notation 'xn' for
n bytes in one of the responses and 'yn' for n bytes calculated with a
user defined function $FUNCTION and an argument $ARGUMENT in one of the requests.
The user defined functions must be defined in STEPS_DCOM_user_functions.pm or
STEPS_DCOM_PRJ_user_functions.pm.

Example:

    DCOM_dependent_requests( '27 01 | 67 01 x4 | 27 02 y4 | 67 04 37' , 'add_const' , 12345 , 'Security Access' );

    - send request 27 01
    - Expect response 67 01 + 4 additional bytes,
    - feed 12345 and the 4 bytes into the user defined function add_const and get 4 new bytes
    - send request 27 02 + 4 new bytes
    - expect response 67 04 37.

OR

If the SeedKey Algoritm is available as an executable 

    DCOM_dependent_requests ( $REQUESTS, $EXECUTABLE, [, $COMMENT ] );

Sends multiple requests to ECU and checks if the responses match with the
corresponding expected values. Both requests and expected responses are defined
in $REQUESTS and separated with '|'.
Requests may depend on previously received responses using the notation 'xn' for
n bytes in one of the responses and 'yn' for n bytes calculated with a
user defined function available as an Executable.
To generate the executable:
Place the 'C' code to calculate the Key in the template KeyCalc.c_tpl available at 
Testcases\_CONFIGURATIONS\DCOM09_Ref_TESTSUITE_BB29888\_CONFIGURATION\_TOOLS\Exe
Rename the file with '.c' extension and compile the code to get executable. 
Place the executable at the same location.
While sending the requests for security access use corresponding EXE in request.

Example:

    DCOM_dependent_requests( '27 01 | 67 01 x4 | 27 02 y4 | 67 04 37' , 'SECA.exe' , 'Security Access' );

    - send request 27 01
    - Expect response 67 01 + 4 additional bytes,
    - feed the 4 bytes into the executable with the seed key algorithm
    - send request 27 02 + 4 new bytes
    - expect response 67 04 37.

=cut

################################################################################

sub DCOM_dependent_requests {

my @Arguments = @_;
my $REQUESTS = shift;
eval { require "STEPS_DCOM_PRJ_user_functions.pm" };
     
if( ((scalar(@Arguments)) == 4) || ((scalar(@Arguments)) == 5) ){
    my $FUNCTION = shift;
    my $ARGUMENT = shift;
    my $COMMENT = shift;
    my $DELAY   = shift;

    my ( 
        @Send, @MessageArray, $remember_flag,
        $function, @Calc, @Remember, $numbytes, 
        $ii, @ResponseValues, $request, $response,
        $count, @Expected, $match, $verdict
        );

    my $pass = 1;

    unless (defined( $ARGUMENT )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_dependent_requests ( REQUESTS, FUNCTION, ARGUMENT [, COMMENT ] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    S_w2log(3, "DCOM_dependent_requests: process special request/response sequence.\n" );
    S_w2log(3, "     Comment         = $COMMENT\n" ) if defined $COMMENT;

    return 1 if $main::opt_offline;

    my @Messages = split(/\|/, $REQUESTS);     # extract all messages (send and receive) from $REQUESTS
                                               # they are separated by the character |

    my $odd = 1;
    foreach my $Message (@Messages) {
    $Message =~ s/^\s+//;   # remove leading blanks

    if( $odd ){     # odd messages are messages to be sent
        @Send = ();

        @MessageArray = split(/\s/, $Message);  # create list of bytes to be sent


        $remember_flag = 0;
        foreach (@MessageArray) {
            unless ( $_ =~ /^.{2}$/ ){          # byte is not built of two characters
                S_set_error("Wrong format of byte $_ in send message $Message", 109);
                S_w2rep ("\n");
                return 0;
                }

                if ( $_ =~ /^y(.)$/ ){            # first character of byte is y
                    $numbytes = $1;               # extract number of bytes to send
                    $remember_flag = 1;           # set a flag that remembered bytes must be sent
                }
                elsif ( $_ =~ /^x.$/ ){           # first character of byte is x
                    S_set_error("'x' not allowed in send message $Message", 109);
                    S_w2rep ("\n");
                    return 0;
                }
                else{                       # normal byte
                     unless($remember_flag){
                          push(@Send, $_);    # add byte to expected response only if remember flag is not set
                    }
                }
            }

            if( $remember_flag ){
                $function = "STEPS_DCOM_user_functions::".$FUNCTION;

                if( not defined &{ $function } ){
                    $function = "STEPS_DCOM_PRJ_user_functions::".$FUNCTION;
                }

                if( defined &{ $function } ){
                    S_w2log(3, "\n     Function Call   = $FUNCTION ($ARGUMENT, @Remember)\n");
                    @Calc = &{ $function } ( $ARGUMENT , @Remember );   # command to calculate the key
                    S_w2log(3, "     Function Result = @Calc\n");
                }
                else{
                    S_set_error("Given function $function is not defined in STEPS_DCOM_user_functions.pm or STEPS_DCOM_PRJ_user_functions.pm", 109);
                    S_w2rep ("\n");
                    return 0;
                }

                if( $#Calc+1-$numbytes >= 0 ){
                    for( $ii=$#Calc+1-$numbytes; $ii<=$#Calc; $ii++){
                        push(@Send, $Calc[$ii]);    # add the calculated bytes to the send message
                    }
                }
                else{
                    # in some cases the calculated number has several leading zeros
                    # in such cases we have to fill the send message with zero bytes
                    for( $ii=0; $ii<$numbytes-$#Calc-1; $ii++){
                        push(@Send, '00');    # add leading zero bytes to the send message
                    }
                    for( $ii=0; $ii<=$#Calc; $ii++){
                        push(@Send, $Calc[$ii]);    # add the calculated bytes to the send message
                    }

                }

            }

            $request = join(' ', @Send);
            S_w2log(3, "\n     Request         = $request\n");

            if ($DELAY)
            {
            DCOM_delay ($DELAY);
            }
            # IF (DNCSIM)
        if ( DCOM_get_environment() eq 'DNCSIM' )
        {
            $request =~ s/ /,/g;     # substitute spaces ' ' with ','
            $response = DCOM_SimTester( $request,"PHYSICAL" );
            $response =~ s/,/ /g;  # substitute ',' with spaces ' '
            }
            # ELSE (LABCAR)
            else
            {
               $response = CD_send_request_wait_response ( $request);
            }

      $last_response = uc($response);

            @ResponseValues = split(/\s/, $last_response);  # get response from ECU
            S_w2log(3, "     Actual Response = @ResponseValues\n");

        }
        else{       # even messages are expected responses
            @MessageArray = split(/\s/, $Message);  # create list of expected bytes

            $count = 1;
            $remember_flag = 0;
            @Remember = ();
            @Expected = ();
            foreach (@MessageArray) {       # loop over all bytes
                unless ( $_ =~ /^.{2}$/ ){      # byte is not built of two characters
                   S_set_error("Wrong format of byte $_ in response message $Message", 109);
                   S_w2rep ("\n");
                   return 0;
               }

               if ( $_ =~ /^x(.)$/ ){      # first character of byte is x
                    $numbytes = $1;     # extract number of bytes to read and remember
                    $remember_flag = 1;     # set a flag that bytes must be remembered
                    if( defined @ResponseValues[($count+$numbytes-2)] ){
                        @Remember = @ResponseValues[($count-1)..($count+$numbytes-2)];  # store bytes that must be remembered
                    }
                    else{
                         S_w2log(3, "     Eval Info       = Length of ECU response too small for x$numbytes in response message $Message\n");

                         S_w2log(3, "     Verdict         = FAIL\n");
                         S_w2rep ("\n");
                         S_set_verdict( 'VERDICT_FAIL' );
                         S_w2rep ("\n");
                         return 0;
                    }
                }
                elsif ( $_ =~ /^y.$/ ){     # first character of byte is y
                    S_set_error("'y' now allowed in response message $Message");
                    S_w2rep ("\n");
                    return 0;
               }
                else{                       # normal byte
                    unless($remember_flag){
                        push(@Expected, $_);    # add byte to expected response only if remember flag is not set
                    }
                }

                $count++;
            }


            S_w2log(3, "     Expected        = @Expected\n");

            $count = 0;
            $match = 1;
            foreach( @Expected ){
                if( $Expected[$count] ne $ResponseValues[$count] ){
                    $match = 0;
                    last;
                }
                $count++;
            }

            if ( $match ){
                S_w2log(3, "     Verdict         = PASS\n");
            }
            else{
                S_w2log(3, "     Verdict         = FAIL\n");
                $pass = 0;
            }

        }   # end of odd/even messages
        $odd = ! $odd;

    }   # end of loop over all messages

    if( $pass ){
        $verdict = 'VERDICT_PASS';
    }
    else{
        $verdict = 'VERDICT_FAIL';
    }

    S_w2rep ("\n");
    S_set_verdict( $verdict );
    S_w2rep ("\n");
    return $verdict;
  }
  
  if((scalar(@Arguments)) == 3)
  {
  
     my $EXECUTABLE = shift;
     my $COMMENT = shift;
     my ($seed, $hexseed, $key, $hexkey, $ExeFullPath);    

    my (
        @Send, @MessageArray, $remember_flag,
        $function, @Calc, @Remember, $numbytes, 
        $ii, @ResponseValues, $request, $response,
        $count, @Expected, $match, $verdict
        );

    my $pass = 1;
    
    S_w2log(3, "DCOM_dependent_requests: process special request/response sequence.\n" );
    S_w2log(3, "     Comment         = $COMMENT\n" ) if defined $COMMENT;

    return 1 if $main::opt_offline;

    my @Messages = split(/\|/, $REQUESTS);     # extract all messages (send and receive) from $REQUESTS
                                               # they are separated by the character |

    my $odd = 1;
    foreach my $Message (@Messages) {
    $Message =~ s/^\s+//;   # remove leading blanks

    if( $odd ){     # odd messages are messages to be sent
        @Send = ();

        @MessageArray = split(/\s/, $Message);  # create list of bytes to be sent


        $remember_flag = 0;
        foreach (@MessageArray) {
            unless ( $_ =~ /^.{2}$/ ){          # byte is not built of two characters
                S_set_error("Wrong format of byte $_ in send message $Message", 109);
                S_w2rep ("\n");
                return 0;
                }

                if ( $_ =~ /^y(.)$/ ){            # first character of byte is y
                    $numbytes = $1;               # extract number of bytes to send
                    $remember_flag = 1;           # set a flag that remembered bytes must be sent
                }
                elsif ( $_ =~ /^x.$/ ){           # first character of byte is x
                    S_set_error("'x' not allowed in send message $Message", 109);
                    S_w2rep ("\n");
                    return 0;
                }
                else{                       # normal byte
                     unless($remember_flag){
                          push(@Send, $_);    # add byte to expected response only if remember flag is not set
                    }
                }
            }

            if( $remember_flag ){
            
                 $seed = join( "",  @Remember );  # join the seed bytes to hex value 
                 $hexseed = hex($seed);
                 $ExeFullPath = $LIFT_config::DiagTestSTEPS_Paths->{"EXE"} . "\\$EXECUTABLE";
                 open(README, "$ExeFullPath $hexseed |") or die "Couldn't fork: $!\n"; 
                 while (<README>) # Get key
                 {
                  $key = hex($_);
                  $hexkey = sprintf("%X", $key);
                 }
                 close(README);
                              
                 for($ii=$numbytes; $ii>0; $ii--){
                   push( @Calc , substr( $hexkey , (-($ii)*2) , 2 ) );    # split Key hex number into bytes
                 }             
                          
                if( $#Calc+1-$numbytes >= 0 ){
                    for( $ii=$#Calc+1-$numbytes; $ii<=$#Calc; $ii++){
                        push(@Send, $Calc[$ii]);    # add the calculated bytes to the send message
                    }
                }
                else{
                    # in some cases the calculated number has several leading zeros
                    # in such cases we have to fill the send message with zero bytes
                    for( $ii=0; $ii<$numbytes-$#Calc-1; $ii++){
                        push(@Send, '00');    # add leading zero bytes to the send message
                    }
                    for( $ii=0; $ii<=$#Calc; $ii++){
                        push(@Send, $Calc[$ii]);    # add the calculated bytes to the send message
                    }

                }

            }

            $request = join(' ', @Send);
            S_w2log(3, "\n     Request         = $request\n");

            # IF (DNCSIM)
        if ( DCOM_get_environment() eq 'DNCSIM' )
        {
            $request =~ s/ /,/g;     # substitute spaces ' ' with ','
            $response = DCOM_SimTester( $request,"PHYSICAL" );
            $response =~ s/,/ /g;  # substitute ',' with spaces ' '
            }
            # ELSE (LABCAR)
            else
            {
               $response = CD_send_request_wait_response ( $request);
            }

      $last_response = uc($response);

            @ResponseValues = split(/\s/, $last_response);  # get response from ECU
            S_w2log(3, "     Actual Response = @ResponseValues\n");

        }
        else{       # even messages are expected responses
            @MessageArray = split(/\s/, $Message);  # create list of expected bytes

            $count = 1;
            $remember_flag = 0;
            @Remember = ();
            @Expected = ();
            foreach (@MessageArray) {       # loop over all bytes
                unless ( $_ =~ /^.{2}$/ ){      # byte is not built of two characters
                   S_set_error("Wrong format of byte $_ in response message $Message", 109);
                   S_w2rep ("\n");
                   return 0;
               }

               if ( $_ =~ /^x(.)$/ ){      # first character of byte is x
                    $numbytes = $1;     # extract number of bytes to read and remember
                    $remember_flag = 1;     # set a flag that bytes must be remembered
                    if( defined @ResponseValues[($count+$numbytes-2)] ){
                        @Remember = @ResponseValues[($count-1)..($count+$numbytes-2)];  # store bytes that must be remembered
                    }
                    else{
                         S_w2log(3, "     Eval Info       = Length of ECU response too small for x$numbytes in response message $Message\n");

                         S_w2log(3, "     Verdict         = FAIL\n");
                         S_w2rep ("\n");
                         S_set_verdict( 'VERDICT_FAIL' );
                         S_w2rep ("\n");
                         return 0;
                    }
                }
                elsif ( $_ =~ /^y.$/ ){     # first character of byte is y
                    S_set_error("'y' now allowed in response message $Message");
                    S_w2rep ("\n");
                    return 0;
               }
                else{                       # normal byte
                    unless($remember_flag){
                        push(@Expected, $_);    # add byte to expected response only if remember flag is not set
                    }
                }

                $count++;
            }


            S_w2log(3, "     Expected        = @Expected\n");

            $count = 0;
            $match = 1;
            foreach( @Expected ){
                if( $Expected[$count] ne $ResponseValues[$count] ){
                    $match = 0;
                    last;
                }
                $count++;
            }

            if ( $match ){
                S_w2log(3, "     Verdict         = PASS\n");
            }
            else{
                S_w2log(3, "     Verdict         = FAIL\n");
                $pass = 0;
            }

        }   # end of odd/even messages
        $odd = ! $odd;

    }   # end of loop over all messages

    if( $pass ){
        $verdict = 'VERDICT_PASS';
    }
    else{
        $verdict = 'VERDICT_FAIL';
    }

    S_w2rep ("\n");
    S_set_verdict( $verdict );
    S_w2rep ("\n");
    return $verdict;
  
  }    
}

################################################################################

=head2 DCOM_check_label

    VERDICT = DCOM_check_label ( $LABEL , $EXP_VALUE1 [, $EXP_VALUE2 ] );

Reads the value of label $LABEL from the current environment (e.g. DNCSIM,
LabCar, ...) and compares it with given expected value(s).

If only $EXP_VALUE1 is given then it will be checked if label value == $EXP_VALUE1.
If $EXP_VALUE1 and $EXP_VALUE2 are given then it will be checked if $EXP_VALUE1 <= label value <= $EXP_VALUE2.

Labels are defined in STEPS_exec\modules\STEPS_DCOM_mapping.pm.

Example:

    VERDICT = DCOM_check_label( 'DNCSIM_TIMING_P2max', 50); # FOR DNCSIM
    VERDICT = DCOM_check_label( 'Ubatt', 12);  # FOR LABCAR

=cut

################################################################################

sub DCOM_check_label {

    my $LABEL = shift;
    my $EXP_VALUE1 = shift;
    my $EXP_VALUE2 = shift;
    my $verdict;

    unless (defined( $EXP_VALUE1 )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_check_label( LABEL , EXP_VALUE1 [, EXP_VALUE2 ] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    S_w2log(3, "DCOM_check_label: read value from test environment and check the result.\n" );
    S_w2log(3, "     Label          = $LABEL\n" );
    if ( defined( $EXP_VALUE2 ) and ($EXP_VALUE2 ne '') )
    {
      S_w2log(3, "     Expected Value = $EXP_VALUE1 .. $EXP_VALUE2\n" );
    }
    else
    {
      S_w2log(3, "     Expected Value = $EXP_VALUE1\n" );
    }

    my $detected_value = DCOM_read_label( $LABEL );
    S_w2log(3, "     Actual Value   = $detected_value\n\n" );

    if ( defined( $EXP_VALUE2 ) and ($EXP_VALUE2 ne '') )
    {
        $verdict = EVAL_evaluate_interval ( $LABEL , $EXP_VALUE1 , $EXP_VALUE2 , $detected_value );
    }
    else
    {
        $verdict = EVAL_evaluate_value ( $LABEL , $EXP_VALUE1 , $detected_value );
    }

    S_w2rep ("\n");
    return $verdict;
}

################################################################################

=head2 DCOM_check_NET_signal

    VERDICT = DCOM_check_NET_signal ( $SIGNAL , $EXP_VALUE1 [, $EXP_VALUE2 ] );

Reads the value of signale $SIGNAL from the configured NET using Canoe/Canalyzer.

If only $EXP_VALUE1 is given then it will be checked if label value == $EXP_VALUE1.
If $EXP_VALUE1 and $EXP_VALUE2 are given then it will be checked if $EXP_VALUE1 <= label value <= $EXP_VALUE2.

Signals are defined in your DBC and CAN mapping perl module

Example:

    VERDICT = DCOM_check_NET_signal( 'Signal1', 50); 

=cut

################################################################################

sub DCOM_check_NET_signal {

    my $SIGNAL = shift;
    my $EXP_VALUE1 = shift;
    my $EXP_VALUE2 = shift;
    my $verdict;

    unless (defined( $EXP_VALUE1 )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_check_NET_signal( SIGNAL , EXP_VALUE1 [, EXP_VALUE2 ] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    S_w2log(3, "DCOM_check_NET_signal: read value from test environment and check the result.\n" );
    S_w2log(3, "     Signal          = $SIGNAL\n" );
    if ( defined( $EXP_VALUE2 ) and ($EXP_VALUE2 ne '') )
    {
      S_w2log(3, "     Expected Value = $EXP_VALUE1 .. $EXP_VALUE2\n" );
    }
    else
    {
      S_w2log(3, "     Expected Value = $EXP_VALUE1\n" );
    }

    CA_read_configure();
    my ($detected_value) = CA_read_can_signal($SIGNAL, "hex");
    S_w2log(3, "     Actual Value   = $detected_value\n\n" );

    if ( defined( $EXP_VALUE2 ) and ($EXP_VALUE2 ne '') )
    {
        $verdict = EVAL_evaluate_interval ( $SIGNAL , $EXP_VALUE1 , $EXP_VALUE2 , $detected_value );
    }
    else
    {
        $verdict = EVAL_evaluate_value ( $SIGNAL , $EXP_VALUE1 , $detected_value );
    }

    S_w2rep ("\n");
    return $verdict;
}

################################################################################

=head2 DCOM_define_label

    DCOM_define_label ( $label, $environment, $direction, $int_label [, $transform] );

Defines a new label mapping for a given environment.

    $label          name of the label to be used in DCOM_check_label, DCOM_set_label
                    calls
    $environment    environment for which the mapping is valid
                    'DNCSIM' = host PC simulation
                    'TARGET' = LabCar usage
    $direction      decied if the label is used for read or write access
                    'IN'     = usage for DCOM_check_label
                    'OUT'    = usage for DCOM_set_label
    $int_label      the internal label to be used for the selected test environment
                    (i.e. the DNCSIM_GetVariable or LC_read_label values)
    $transform      optional possibility to perform scaling / bit extraction on
                    the label values; refer to STEPS_DCOM_mapping functions
                    for the available possibilities

Example:

    DCOM_define_label( 'label name', 'DNCSIM', 'IN', 'internal lable name');

=cut

################################################################################

sub DCOM_define_label {

  my $label = shift;
  my $env = shift;
  my $direction = shift;
  my $int_label = shift;
  my $transform = shift;

    unless (defined( $int_label )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_define_label ( label, environment, direction, int_label [, transform] )", 110 );
        S_w2rep ("\n");
        return 0;
    }

    if (($env ne 'DNCSIM') and ($env ne 'TARGET')) {
        S_set_error( " invalid environment: valid are DNCSIM, TARGET", 109 );
        S_w2rep ("\n");
        return 0;
    }

    if (($direction ne 'IN') and ($direction ne 'OUT')) {
        S_set_error( " invalid direction: valid are IN, OUT", 109 );
        S_w2rep ("\n");
        return 0;
    }

  # logging
    S_w2log(3, "DCOM_define_label: add a new label mapping\n" );
    S_w2log(3, "     Label          = $label\n" );
    S_w2log(3, "     Environment    = $env\n" );
    S_w2log(3, "     Direction      = $direction\n" );
    S_w2log(3, "     Internal Label = $int_label\n" );
    S_w2log(3, "     Transformation = $transform\n" ) if defined $transform;

  # store the new mapping
  if ($direction eq 'IN')
  {
    if ($env eq 'DNCSIM')
    {
      $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_read_label}->{$label}->{Cmd} = "DNCSIM_GetVariable";
    }
    elsif ($env eq 'TARGET')
    {
      $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_read_label}->{$label}->{Cmd} = "LC_read_label";
    }
    $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_read_label}->{$label}->{Label} = $int_label;
    $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_read_label}->{$label}->{MappingFunction} = $transform if defined $transform;
  }
  elsif ($direction eq 'OUT')
  {
    if ($env eq 'DNCSIM')
    {
      $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_set_label}->{$label}->{Cmd} = "DNCSIM_SetVariable";
    }
    elsif ($env eq 'TARGET')
    {
    $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_set_label}->{$label}->{Cmd} = "LC_set_label";
    }
    $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_set_label}->{$label}->{Label} = $int_label;
    $STEPS_DCOM_mapping::DCOM_MAPPING->{$env}->{DCOM_set_label}->{$label}->{MappingFunction} = $transform if defined $transform;
  }

  S_w2rep ("\n");
  return 1;
}

################################################################################

=head2 DCOM_set_label

    $value = DCOM_set_label ( $label, $value )

Sets the value of the given label from the current environment (e.g. DNCSIM,
LabCar, ...).

Labels are defined in STEPS_exec\modules\STEPS_DCOM_mapping.pm.

Example:

    DCOM_set_label('Ubatt', 12.0);

=cut

################################################################################

sub DCOM_set_label
{
  my $label = shift;
  my $value = shift;

  my $call;
  my $func;
  my $unit_arg;

    unless (defined( $value )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_set_label ( label, value )", 110 );
        S_w2rep ("\n");
        return 0;
    }

  # logging
    S_w2log(3, "DCOM_set_label: change value of a test environment setting\n" );
    S_w2log(3, "     Label          = $label\n" );
    S_w2log(3, "     Value          = $value\n" );

  # get mapping entry
  my $config = DCOM_get_environment();
  if (defined $DCOM_MAPPING->{$config}->{DCOM_set_label}->{$label})
  {
    # prepare unit argument, if available
    if (defined $DCOM_MAPPING->{$config}->{'DCOM_set_label'}->{$label}->{'Unit'})
    {
      $unit_arg = ", '" . $DCOM_MAPPING->{$config}->{'DCOM_set_label'}->{$label}->{'Unit'} . "'";
    }

    # prepare call to mapping function
    $func = $DCOM_MAPPING->{$config}->{'DCOM_set_label'}->{$label}->{'MappingFunction'};

    if (not $func) {
      # if no mapping function is defined, identity is the default value
      $func = 'ident(value)';
    }
    else
    {
      S_w2log(3, "     Value Mapping  = $func\n" );
    }

    # place the value in the evaluation function and call it
    $func =~ s/value/$value/g;
    $value = eval $func;

    # prepare function call
    $call = $DCOM_MAPPING->{$config}->{'DCOM_set_label'}->{$label}->{'Cmd'} . "('" .  $DCOM_MAPPING->{$config}->{'DCOM_set_label'}->{$label}->{Label} . "', '$value' $unit_arg)";
    S_w2log(3, "     Label Mapping  = $call\n" );

    # call the function specified in the mapping table
    my $result = eval $call;

    # we're done
    S_w2rep ("\n");
    return $result;
  }
  else
  {
    # no entry in the mapping table was found, so we call the default functions
    # for each environment
    # IF (DNCSIM)
    if ($config eq 'DNCSIM')
    {
        S_w2log(3, "     Label Mapping  = not found => DNCSIM_SetVariable('$label', $value)\n" );

        S_w2rep ("\n");
        return DNCSIM_SetVariable ($label, $value);
    }
    # ELSE (LABCAR)
    else
    {
        S_w2log(3, "     Label Mapping  = not found => LC_set_label('$label', $value)\n" );
        S_w2rep ("\n");
        return LC_set_label ($label, $value);
    }
  }
}

# ******************************************************************************
# ******************************************************************************
#
# DCOM Test Commands - Parameter Access
#
# ******************************************************************************
# ******************************************************************************

################################################################################

=head2 DCOM_param

    $value = DCOM_param ( $param );

Reads the value of the parameter $param defined in the test configuration of
the current environment.

Example:

    DCOM_param ('DNCSIM_TIMING_P2max');

=cut

################################################################################

sub DCOM_param {

  my $param = shift;

  unless (defined( $param )) {
    S_set_error( "! too less parameters ! SYNTAX: DCOM_param ( PARAMETER_NAME )", 110 );
    return 0;
  }

  unless (defined $GENERIC_DCOM_data->{$param})
  {
    S_set_error( "! unknown parameter $param, not defined in the testbench configuration", 109 );
    return 0;
  }

  my $value = $GENERIC_DCOM_data->{$param};
  S_w2log (3, "DCOM_param: reading parameter $param = $value\n");
  S_w2rep ("\n");

  return $value;
}

#####################################################################

=head2 DCOM_tcpar

    PARTAMETER_VALUE_REF = DCOM_tcpar ( $PARAMETER_NAME );

Reads the value of the testcase parameter $PARAMETER_NAME and returns a reference to it.

Example:

    DCOM_tcpar('DNCSIM_TIMING_P2max');

=cut

#####################################################################

sub DCOM_tcpar {

   my $PARAMETER_NAME = shift;
   my $PARA_TEXT;
   my $TEMP_REF;

   unless (defined( $PARAMETER_NAME )) {
      S_set_error( "! too less parameters ! SYNTAX: DCOM_tcpar ( PARAMETER_NAME )", 110 );
      return 0;
   }

   S_w2log( 1, "DCOM_tcpar: reading TC parameter $PARAMETER_NAME...\n");

   my $value_ref = S_read_testcase_parameter( $PARAMETER_NAME , 'byref' );

   if(defined $value_ref)
   {
     if( ref($value_ref) eq "HASH" )
     {
       undef $TEMP_REF;
       foreach (keys %$value_ref){ push(@$TEMP_REF , "'$_' => '$value_ref->{$_}'");}
       $PARA_TEXT = $PARAMETER_NAME." = %( ".join(' , ',@$TEMP_REF)." )";
#        S_add2eval_collection( 'TCPAR_DATA', $PARA_TEXT);   
         S_add2eval_collection( 'Test Preparation', $PARA_TEXT);
 
     } 
     elsif( ref($value_ref) eq "ARRAY" )
     {
       undef $TEMP_REF;
       @$TEMP_REF = @$value_ref;
       foreach (@$TEMP_REF){$_ = "'$_'";}
       $PARA_TEXT = $PARAMETER_NAME." = @(".join(' , ',@$TEMP_REF).")";     
       S_add2eval_collection( 'Test Preparation', $PARA_TEXT);
     }
     else
     {
       $PARA_TEXT = "$PARAMETER_NAME = '$value_ref'";         
       S_add2eval_collection( 'Test Preparation', $PARA_TEXT);
     }
  }   
  return $value_ref;
}

#####################################################################

=head2 DCOM_prjpar

    PARTAMETER_VALUE_REF = DCOM_prjpar ( $PARAMETER_NAME );

Reads the value of the testcase parameter $PARAMETER_NAME and returns a reference to it.

Example:

    DCOM_prjpar('DNCSIM_TIMING_P2max');

=cut

#####################################################################

sub DCOM_prjpar {

   my $PARAMETER_NAME = shift;

   unless (defined( $PARAMETER_NAME )) {
      S_set_error( "! too less parameters ! SYNTAX: DCOM_prjpar ( PARAMETER_NAME )", 110 );
      return 0;
   }

   S_w2log( 1, "DCOM_prjpar: reading project parameter $PARAMETER_NAME...\n");

   my $value_ref = S_read_project_parameter( $PARAMETER_NAME );

   return $value_ref;
}

# ******************************************************************************
# ******************************************************************************
#
# Internal Help Functions
#
# ******************************************************************************
# ******************************************************************************

#####################################################################

=head2 DCOM_SimTester

    $response = DCOM_SimTester ( REQUEST, AdrType );

This function simulates the tester behaviour and sends back the response. The
timing configuration of this tester is done as part of the testbench setup.
As a default feature, several negative responses are directly handled by this
implementation.

- NRC $78: polling for responses is continued until a final response is received
- NRC $21: request is re-transmitted until a final positive response is received
- NRC $23: same handling as NRC $21

Following timing values can be set:
- P2max:      timeout for first response after request has been sent
- P2maxExt:   timeout for subsequent responses after first negative response $78
              was received
- RetryLimit: number of retries in case of negative responses $78, $21, $23

Example:

     DCOM_SimTester('10,89',"PHYSICAL");

=cut

#####################################################################

sub DCOM_SimTester
{
    my $REQUEST = shift;
    my $AdrType = shift;

    my ( $response , @ECU_RESP);
    my ( $timer_P2max, $timer_P2maxExt, $timer_P2maxCurrent );
    my ( $loop_count, $loop_count_max );

    # get the configured P2max and P2maxExtended timeout values
    $timer_P2max = $GENERIC_DCOM_data->{'DNCSIM_TIMING_P2max'};
    unless ( defined $timer_P2max ) {
    $timer_P2max = 50;
    };

    $timer_P2maxExt = $GENERIC_DCOM_data->{'DNCSIM_TIMING_P2maxExt'};
    unless ( defined $timer_P2maxExt ) {
    $timer_P2maxExt = $timer_P2max;
    };

    $loop_count_max = $GENERIC_DCOM_data->{'DNCSIM_TIMING_RetryLimit'};
    unless ( defined $loop_count_max ) {
    $loop_count_max = 1000;
    };

  $loop_count = 0;
  $timer_P2maxCurrent = $timer_P2max;

    # send the request based on the addressing mode
    if($AdrType eq "PHYSICAL")
    {
        DNCSIM_SendRequest( $REQUEST );
    }
    else
    {
        DNCSIM_SendFuncRequest( $REQUEST );
    }

  while ($loop_count < $loop_count_max)
  {
    # run for up to P2max time
    $response = uc( DCOM_SimTester_WaitForResponse ($timer_P2maxCurrent) );
    @ECU_RESP = split(/\,/,$response);

    # check for no response case
    if ($response eq "")
    {
      return "";
    }
      # check for negative response code $78 = ResponsePending
      elsif (($ECU_RESP[0] eq "7F") && ($ECU_RESP[2] eq "78"))
      {
      # change P2max to P2maxExtended
      $timer_P2maxCurrent = $timer_P2maxExt;
      }
    # check for negative response code $21 = BusyRepeatRequest and $23 = RoutineNotComplete
        elsif (($ECU_RESP[0] eq "7F") && (($ECU_RESP[2] eq "21") || ($ECU_RESP[2] eq "23")))
        {
          # wait for a fixed time of 10 ms
          DNCSIM_RunProcesses (10);

          # re-send request to DNCSIM client
          if($AdrType eq "PHYSICAL")
          {
            DNCSIM_SendRequest( $REQUEST );
          }
          else
          {
            DNCSIM_SendFuncRequest( $REQUEST );
          }

      # set P2max to the normal P2max
      $timer_P2maxCurrent = $timer_P2max;
        }
        # we have a final response
    else
    {
      return $response;
    }

    $loop_count++;
  }

  # if we reach here, the retry limit has been exceeded => we just return the
  # last negative response
  return $response;
}

################################################################################

=head2 DCOM_SimTester_WaitForResponse

  $response = DCOM_SimTester_WaitForResponse ( $TIMEOUT );

Rune DNCSIM execution and waits for a response until the specified timeout
has expired. The function checks if a response is available every 10 ms.

  $TIMEOUT    Maximum time to wait in ms

Example:

    DCOM_SimTester_WaitForResponse('$timer_P2max');

=cut

################################################################################

sub DCOM_SimTester_WaitForResponse
{
my $TIMEOUT = shift;
my $response;

  while (($TIMEOUT > 0) && ($response eq ""))
  {
      DNCSIM_RunProcesses ($TIMEOUT > 10 ? 10 : $TIMEOUT);
      $TIMEOUT -= 10;
      $response = uc( DNCSIM_GetResponse () );
  }

  return $response;
}

################################################################################

=head2 DCOM_get_environment

    $value = DCOM_get_environment()

Returns the current test environment used for DCOM tests. Possible return values:

    - 'DNCSIM' = Simulation environment with DNCSIM executable
    - 'TARGET' = Environment with real ECU.

=cut

################################################################################

sub DCOM_get_environment
{

  my @DNCSIM_Handlebench = @{$GENERIC_Testbench->{'Functions'}{'Simulator'}{'general'}};

  if( uc($DNCSIM_Handlebench[0]) eq 'DNCSIM' )
  {
    return 'DNCSIM';
  }
  elsif( uc($DNCSIM_Handlebench[0]) eq 'LABCAR')
  {
    return 'TARGET';
  }
  else
  {
    return 'NONE';
  }

}

################################################################################

=head2 DCOM_read_label

    $value = DCOM_read_label ( $label )

Reads the value of the given label from the current environment (e.g. DNCSIM,
LabCar, ...).

Labels are defined in STEPS_exec\modules\STEPS_DCOM_mapping.pm.

Example:

    DCOM_read_label('Ubatt');

=cut

################################################################################

sub DCOM_read_label
{
  my $label = shift;

  my $call;
  my $func;

  # get mapping entry
  my $config = DCOM_get_environment();
  if (defined $DCOM_MAPPING->{$config}->{'DCOM_read_label'}->{$label})
  {
    $call = $DCOM_MAPPING->{$config}->{'DCOM_read_label'}->{$label}->{'Cmd'} . "('" .  $DCOM_MAPPING->{$config}->{DCOM_read_label}->{$label}->{Label} . "')";
    $func = $DCOM_MAPPING->{$config}->{'DCOM_read_label'}->{$label}->{'MappingFunction'};
  }

  # check if an entry was found
  if ($call)
  {
    # if no mapping function is defined, identity is the default value
    if (not $func) {
        $func = 'ident(value)';
        S_w2log(3, "     Label Mapping  = $call\n" );
    }
    else
    {
        S_w2log(3, "     Label Mapping  = $call -> $func\n" );
    }

    # call the function specified in the mapping table
    my $value = eval $call;

    # place the value in the evaluation function and call it
    $func =~ s/value/$value/g;

    my $result = eval $func;

    # we're done
    return $result;
  }
  else
  {
    # no entry in the mapping table was found, so we call the default functions
    # for each environment
    # IF (DNCSIM)
    if ($config eq 'DNCSIM')
    {
        S_w2log(3, "     Label Mapping  = not found => DNCSIM_GetVariable('$label')\n" );
        return DNCSIM_GetVariable ($label);
        }
    # ELSE (LABCAR)
    else
    {
        S_w2log(3, "     Label Mapping  = not found => LC_read_label('$label')\n" );
        return LC_read_label ($label);
    }
  }
}

#####################################################################

=head2 DCOM_IC

    DCOM_IC();
    DCOM_IC($suppress_battreset);

Does an ignition and batterycycle or just an ignition cycle, based on the
parameters $suppress_battreset.

    $suppress_battreset: if provided and > 0 not battery cycle will be done

Example:

    DCOM_IC(); # with battery reset
    DCOM_IC(1); # without battery reset

=cut

#####################################################################

sub DCOM_IC
{
  my $suppress_battreset = shift();
  my $config = DCOM_get_environment();

  # IF (DNCSIM)
  if ( $config eq 'DNCSIM' )
  {
    DNCSIM_Reset();
  }
  # ELSE IF (TARGET)
  elsif ( $config eq 'TARGET')
  {
    if($suppress_battreset >0)
    {
#       LC_set_UZ(off);            # CODE NOT CLEAR
#       DCOM_delay(1);             # CODE NOT CLEAR
#       LC_set_UZ(on);             # CODE NOT CLEAR
    }
    else
    {
#       LC_set_UZ(off);            # CODE NOT CLEAR
#       LC_set_Ubatt ( 0 );        # CODE NOT CLEAR
#       DCOM_delay(1);
#       LC_set_Ubatt ( 'U_BATT_DEFAULT' );    # CODE NOT CLEAR
#       LC_set_UZ(on);             # CODE NOT CLEAR
    }
  }
  # ELSE (NONE)
  else
  {
    DCOM_wait_for_user('Switch OFF & ON the POWER SUPPLY to the ECU');
  }
}

#####################################################################

=head2 DCOM_SetEeprom

    $success = DCOM_SetEeprom ( $ADDRESS, $DATASTRING [, $MODE ] );

Writes data given in $DATASTRING to EEPROM from start address $ADDRESS onwards in mode $MODE.

    $ADDRESS    : string containing the start address in the EEPROM in hex (e.g. '0x0393')
    $DATASTRING : string containing hex bytes separated by white space (e.g. '12 3A FF')
    $MODE       : 'normal' (default), 'safe', 'buffered'

In 'normal' mode only the bytes given in $DATASTRING are written to EEPROM.
In 'safe' mode additionally a checksum byte and an access byte ('AB') is written to EEPROM.
In 'buffered' mode everything that is written in 'safe' mode is written twice
(data bytes, checksum byte, access byte, data bytes, checksum byte, access byte).
Returns 1 if a positive response is sent by the ECU, otherwise 0

Example:

    DCOM_SetEeprom('0x0380','01 02 03 04 05 06','safe');

=cut

#####################################################################

sub DCOM_SetEeprom
{
#   my $ADDRESS = shift();
#   my $DATASTRING = shift();
#   my $MODE = shift();

  my $returnval;
  my ( $ADDRESS, $DATASTRING, $MODE ) = @_; #for old Gen08/DNCSim
  # IF (DNCSIM)
  if ( DCOM_get_environment() eq 'DNCSIM' )
  {
    if( defined( $MODE ) ){
       unless( $MODE =~ /normal/i or $MODE =~ /safe/i or $MODE =~ /buffered/i ){
           S_set_error( "Invalid MODE $MODE; must be one of: 'normal', 'safe', 'buffered'", 114 );
           return 0;
       }
    }
    else
    {
      $MODE = "normal";
    }

    if($MODE eq "normal")
    {
      $MODE = "EENORMALMODE";
    }
    if( $MODE eq "safe")
    {
      $MODE = "EESAFEMODE";
    }
    if( $MODE eq "buffered")
    {
      $MODE = "EEBUFFEREDMODE";
    }

    $DATASTRING =~ s/ /,/g;     # substitute spaces ' ' with ','
    $returnval = DNCSIM_EEPROM_SetData($ADDRESS, $DATASTRING, $MODE);

    DNCSIM_Reset();

    DCOM_delay(1);
  }
  # ELSE (LABCAR)
  else
  {
 
    DCOM_stop_communication();
    DIAG_start_comm( 'RB' );
#     $returnval = DIAG_write_EEPROM ( $ADDRESS, $DATASTRING, $MODE);
    $returnval = DIAG_write_EEPROM ( @_ );
    DCOM_comment("s", "DIAG_write_EEPROM: Arguments ".join(" ; ",@_));    
    DIAG_stop_comm( 'RB' );
    DCOM_start_communication();
  }

  return $returnval;
}

#####################################################################

=head2 DCOM_GetEeprom

    $value = DCOM_GetEeprom ( $ADDRESS, $LENGTH );

Reads $LENGTH bytes data from EEPROM, beginning @ $ADDRESS.

    $ADDRESS    : string containing the start address in the EEPROM in hex (e.g. '0x0393')
    $LENGTH:    : number of bytes that have to be read

Returns the read bytes

Example:

    DCOM_GetEeprom ('0x0380', 6);

=cut

#####################################################################

sub DCOM_GetEeprom
{
#   my $ADDRESS = shift();
#   my $LENGTH = shift();
   my @Arguments = @_;
  my $returnval;                         
  
  # IF (DNCSIM)
  if ( DCOM_get_environment() eq 'DNCSIM' )
  {

#     $returnval = DNCSIM_EEPROM_GetData($ADDRESS, $LENGTH);
      $returnval = DNCSIM_EEPROM_GetData(@Arguments );

    DNCSIM_Reset();

    DCOM_delay(1);
  }
  # ELSE (LABCAR)
  else
  {
  }

  return $returnval;
}

# ******************************************************************************
# ******************************************************************************
#
# DCOM Test Commands - LabCar Access Functions
#
# ******************************************************************************
# ******************************************************************************

#####################################################################

=head2 DCOM_LC_set_label

    DCOM_LC_set_label ( $LABEL , $VALUE );

Sets label $LABEL to value $VALUE on the LabCar.
Labels are defined in STEPS_exec\modules\STEPS_LabcarMappingV3.pm.
See also documentation of function LC_set_label in modules::STEPS_labcar_ng.

Example:

    DCOM_LC_set_label('model_target_speed', 10);

=cut

#####################################################################

sub DCOM_LC_set_label {

    my @params = @_;

    return LC_set_label( @params );
}

#####################################################################

=head2 DCOM_LC_check_label

    VERDICT = DCOM_LC_check_label ( $LABEL , $EXP_VALUE1 [, $EXP_VALUE2 ] );

Reads the value of label $LABEL on the LabCar and compares it with
given expected value(s).

If only $EXP_VALUE1 is given then it will be checked if label value == $EXP_VALUE1.
If $EXP_VALUE1 and $EXP_VALUE2 are given then it will be checked if $EXP_VALUE1 <= label value <= $EXP_VALUE2.

Labels are defined in STEPS_exec\modules\STEPS_LabcarMappingV3.pm.

Example:

    DCOM_LC_check_label('label name', 20);

=cut

#####################################################################

sub DCOM_LC_check_label {

    my $LABEL = shift;
    my $EXP_VALUE1 = shift;
    my $EXP_VALUE2 = shift;

    unless (defined( $EXP_VALUE1 )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_LC_check_label( LABEL , EXP_VALUE1 [, EXP_VALUE2 ] )", 110 );
        return 0;
    }

    my $detected_value = LC_read_label( $LABEL );

    if( defined( $EXP_VALUE2 ) and ($EXP_VALUE2 ne '') ){
        return EVAL_evaluate_interval ( $LABEL , $EXP_VALUE1 , $EXP_VALUE2 , $detected_value );
    }
    else{
        return EVAL_evaluate_value ( $LABEL , $EXP_VALUE1 , $detected_value );
    }
}

#####################################################################

=head2 DCOM_LC_set_signal

    DCOM_LC_set_signal ( $SIGNAL , $VALUE );

Sets signal $SIGNAL to value $VALUE on the LabCar.
See also documentation of function LC_set_signal in modules::STEPS_labcar_ng.

Example:

    DCOM_LC_set_signal('signal name', 1);

=cut

#####################################################################

sub DCOM_LC_set_signal {

    my @params = @_;

    return LC_set_signal( @params );
}

#####################################################################

=head2 DCOM_LC_check_signal

    VERDICT = DCOM_LC_check_signal ( $SIGNAL , $EXP_VALUE1 [, $EXP_VALUE2 ] );

Reads the value of signal $SIGNAL on the LabCar and compares it with
given expected value(s).

If only $EXP_VALUE1 is given then it will be checked if signal value == $EXP_VALUE1.
If $EXP_VALUE1 and $EXP_VALUE2 are given then it will be checked if $EXP_VALUE1 <= signal value <= $EXP_VALUE2.

Example:

    DCOM_LC_check_signal('signal name', 1);

=cut

#####################################################################

sub DCOM_LC_check_signal {

    my $SIGNAL = shift;
    my $EXP_VALUE1 = shift;
    my $EXP_VALUE2 = shift;

    unless (defined( $EXP_VALUE1 )) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_LC_check_signal( SIGNAL , EXP_VALUE1 [, EXP_VALUE2 ] )", 110 );
        return 0;
    }

    my $detected_value = LC_read_signal( $SIGNAL );

    if( defined( $EXP_VALUE2 ) and ($EXP_VALUE2 ne '') ){
        return EVAL_evaluate_interval ( $SIGNAL , $EXP_VALUE1 , $EXP_VALUE2 , $detected_value );
    }
    else{
        return EVAL_evaluate_value ( $SIGNAL , $EXP_VALUE1 , $detected_value );
    }
}

#####################################################################

=head2 DCOM_LC_bind_const

    DCOM_LC_bind_const ( $LABEL , $VALUE );

Freezes LabCar controlled label $LABEL to a constant value $VALUE on the LabCar.
See also documentation of function LC_bind_stimuli_to_constant in modules::STEPS_labcar_ng.

Example:

    DCOM_LC_bind_const(PressureCircuit1, 0);

=cut

#####################################################################

sub DCOM_LC_bind_const {

    my @params = @_;

    return LC_bind_stimuli_to_constant( @params );
}

#####################################################################

=head2 DCOM_LC_release_const

    DCOM_LC_release_const ( $LABEL );

Releases label $LABEL to LabCar control.
See also documentation of function LC_release_stimuli_from_constant in modules::STEPS_labcar_ng.

Example:

    DCOM_LC_release_const(PressureCircuit1);

=cut

#####################################################################

sub DCOM_LC_release_const {

    my @params = @_;

    return LC_release_stimuli_from_constant( @params );
}

#####################################################################

=head2 DCOM_LC_do_interrupt_line

    DCOM_LC_do_interrupt_line ( @LINES );

Interrupts the lines @LINES on the LabCar.
See also documentation of function LC_do_interrupt_line in modules::STEPS_labcar_ng.

Example:

    DCOM_LC_do_interrupt_line(WSSFL_line);

=cut

#####################################################################

sub DCOM_LC_do_interrupt_line {

    my @params = @_;

    my @DNCSIM_Handlebench = @{$GENERIC_Testbench->{'Functions'}{'Simulator'}{'general'}};
    if( uc($DNCSIM_Handlebench[0]) eq 'DNCSIM' ) {
      return DNCSIM_LC_do_interrupt_line( @params ); }
    else {
      return LC_do_interrupt_line( @params ); }
}

#####################################################################

=head2 DCOM_LC_undo_interrupt_line

    DCOM_LC_undo_interrupt_line ( @LINES );

Reconnects the lines @LINES on the LabCar.
See also documentation of function LC_undo_interrupt_line in modules::STEPS_labcar_ng.

Example:

    DCOM_LC_undo_interrupt_line(WSSFL_line);

=cut

#####################################################################�

sub DCOM_LC_undo_interrupt_line {

    my @params = @_;
   # IF (DNCSIM)
   if ( DCOM_get_environment() eq 'DNCSIM' )
   {
    return DNCSIM_LC_undo_interrupt_line( @params );
   }
   # ELSE (LABCAR)
   else
   {
    return LC_undo_interrupt_line( @params );
   }
}

######################################################

=head2 DCOM_setSamtecParam

    DCOM_setSamtecParam ( $PARAMID, $CONTENT );

    Sets the SamTec parameter $PARAMID to $CONTENT.
    For more information about the possible parameters
    please have a look into the SamDiaX helpfile (automatically
    installed at your PC with TKWinX)

=cut

######################################################

sub DCOM_setSamtecParam
{  
    my $PARAMID = shift;
    my $CONTENT = shift;
    
    TKWinX_setSamtecParam($PARAMID,$CONTENT);

    return 1;
}

#####################################################################

=head2 DCOM_request_general

    DCOM_request_general ( $Request , $Response , $LabelValueMapping );

    Request and Response are given as logical names
    The value for the labels are taken from the DiagMapping file
Example:

    DCOM_request_general( 'REQ_StartSession_DefaultSession' , 'PR_StartSession_DefaultSession' );
    DCOM_request_general( 'REQ_StartSession_DefaultSession' , 'NR_serviceNotSupported' );

=cut

#####################################################################�

sub DCOM_request_general {
  my ($Request_label, $Response_label, $Label_Value, $NO_EVAL_SWITCH);
  undef $Request_label;
  undef $Response_label;
  undef $Label_Value;
  
  $Request_label  = shift;
  $Response_label = shift;
  $Label_Value    = shift;
  $NO_EVAL_SWITCH = shift;
  
  my $Request_label_short;
  my ( 
       $Request_value,
       $Response_value,       
       $mode,
       $description,
       $function,
       $parameters,
       $response,
       $detected_response,
       $doors_reqIDS,
       %data,
       @response_bytes,
       $data_start_byte,
       $data_length,
       $detected_data,
       $text, 
       @array,      
     );
  # $Request_label =~ s/REQ_//i;     
  $Request_label_short = $Request_label;  
  if( $Request_label =~ /\_\_/ ){
    $Request_label =~ /(\w*)(\_\_)/;
    $Request_label_short = $1;
  }
  $Request_label_short =~ s/(REQ_)//;

  unless( defined $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}){
      # S_w2log ( 4, "\nDCOM_request_general: $Request_label not defined in the Diag Mapping nothing done\n");
      S_set_error ( "\nDCOM_request_general: $Request_label not defined in the Diag Mapping nothing done\n", 20 );
      DCOM_w2html( " $Request_label not defined in the Diag Mapping&5" , "T"  , 'red' , "Courier" );
        return 0;  
  }
  unless( defined $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}){
       # S_w2log (4,"\nRequest $Request_label not defined in the Diag Mapping nothing done. May be request is not available in project\n");
       S_set_error ( "\nRequest $Request_label not defined in the Diag Mapping nothing done. May be request is not available in project\n", 20 );
       DCOM_w2html( " $Request_label not defined in the Diag Mapping&5" , "T"  , 'red' , "Courier" );
        return 0;  
  }

  
# for DependedRequest
#----------------------------------
  if( exists $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'DependentRequest'}){  
    $Request_value = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'DependentRequest'};
    unless(defined($Request_value)){
      S_set_error ("\nSub_Request : $Request_value is not defined in the Diag Mapping nothing done for sub request.\n",20);
      return 0;
    }
    $function = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'Function'};
    $parameters = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'Parameters'};
    $description = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'Desc'};
    S_w2rep ("\nDCOM_dependent_requests $Request_value, $function , $parameters, $description \n");
    S_add2eval_collection( $EVAL_REPORT_LABEL, "    dependent_requests: $Request_value function: $function parameters: $parameters desc: $description");
    DCOM_dependent_requests( $Request_value, $function , $parameters, $description);
    return 1;      
  }

# if Request/Response is having label & values
#----------------------------------
  if( exists $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'Request'}){

    $Request_value = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'Request'};
    unless(defined($Request_value)){
      S_set_error ("\nRequest : $Request_value is not defined in the Diag Mapping nothing done for sub request.\n", 20);
      return 0;
    }
    $Response_value = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'Response'};
    $mode           = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'Mode'};
    $description    = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'Desc'};
    $doors_reqIDS   = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'DoorsIDs'};
    $data_start_byte =  $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'DataStartByte'};
    $data_length =  $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'DataLength'};
        
    push(@DoorsIDs , @$doors_reqIDS );
    if(defined $Label_Value){
        foreach my $label(keys %{$Label_Value}){
          next if( $label eq 'Request' );
          $Request_value =~ s/$label/$Label_Value->{$label}/;
          $Response_value =~ s/$label/$Label_Value->{$label}/;
        }#end of foreach    
    }#end of if
    else{
        foreach my $label(keys %{$GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}}){
          next if( $label eq 'Request' );
          $Request_value =~ s/$label/$GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{$label}/;
          $Response_value =~ s/$label/$GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{$label}/;
          $data{$label} = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{$label};
        
        }#end of foreach
    }#end of else

    #
    # get the negative response from the services
    #
        @array = split( "_" , $Request_label_short);
        $Request_label_short = $array[0];
#       $Request_label_short =~ /(\w*)(\_)/;
#       $Request_label_short = $1; 
      if(defined $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}){
        $Response_value = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Response'};
        $mode = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Mode'};
        $description = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Desc'};
        $doors_reqIDS = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'DoorsIDs'};
        push(@DoorsIDs , @$doors_reqIDS );
      }
    
    S_w2log( 4, "DCOM_request_general: Req: $Request_value Exp_resp:$Response_value mode:$mode desc: $description \n" );
#     S_add2eval_collection( $EVAL_REPORT_LABEL, "    req: $Request_value exp_resp:$Response_value mode:$mode desc: $description" );
    S_add2eval_collection( $EVAL_REPORT_LABEL, "    $Request_label($Request_value):$Response_label($Response_value)" );
    if ($mode eq "quiet") {
        DCOM_w2TestStep("TestStep" , "$Request_value - $Request_label","- no response");
    }
    else {
        DCOM_w2TestStep("TestStep" , "$Request_value - $Request_label","$Response_value - $Response_label");
    }


    $text=<<EOT2;
      Request          : $Request_label  -> $Request_value
      Expected_Response: $Response_label -> $Response_value
      Eval Mode        : $mode
      Description      : $description
EOT2
    S_w2log( 3, "$text\n" );

    undef $response;
    $response = DCOM_request($Request_value, $Response_value, $mode, $description ,$NO_EVAL_SWITCH ); 
    return 1 if $main::opt_offline;

    S_w2log( 4, "DCOM_request_general: det_resp: $response\n" );
    S_add2eval_collection( $EVAL_REPORT_LABEL, "    det_resp: $response");


    if(defined $data_start_byte) {   
        @response_bytes = split(/ /,$response );             
        $detected_data = undef;
        foreach(my $i = $data_start_byte; $i<($data_start_byte+$data_length);$i++ ){        
            if(defined $detected_data){ 
                $detected_data = $detected_data." ".$response_bytes[$i]
            }
            else { 
                $detected_data = $response_bytes[$i]
            }
        }
        $data{'Data'} = $detected_data;    
        return ($response, $data{'Data'} );
    }   
    return $response;         
}  

# direct Requests
#----------------------------

    unless( exists $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label}{'Request'}) {  
        $Request_value = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'Requests'}{$Request_label};
        DCOM_comment('s', "request_value selected is $Request_value");
        if(defined $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}){
            $Response_value = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'Response'};
            $mode = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'Mode'};
            $description = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'Desc'};
            $doors_reqIDS = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'POS_Responses'}{$Response_label}{'DoorsIDs'};
        }  
        elsif(defined $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'NEG_Responses'}{$Response_label}) {
            $Response_value = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Response'};
            $mode = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Mode'};
            $description = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Desc'};
            $doors_reqIDS = $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'DoorsIDs'};
        }
#
# get the negative respsonse from the services
#
#       $Request_label_short =~ /(\w*)(\_)/;
#       $Request_label_short = $1;
        @array = split( "_" , $Request_label_short);
        $Request_label_short = $array[0];
    
        if(defined $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}){
            $Response_value = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Response'};
            $mode = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Mode'};
            $description = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'Desc'};
            $doors_reqIDS = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$Request_label_short}{'NEG_Responses'}{$Response_label}{'DoorsIDs'};
        }
        push(@DoorsIDs , @$doors_reqIDS );
        S_add2eval_collection( $EVAL_REPORT_LABEL, "    req: $Request_value exp_resp:$Response_value mode:$mode desc: $description");
        if ($mode eq "quiet") {
            DCOM_w2TestStep("TestStep" , "$Request_value - $Request_label"," - no response");
        }
        else {
             DCOM_w2TestStep("TestStep" , "$Request_value - $Request_label","$Response_value - $Response_label");       
        }

#--------------------
   $text=<<EOT2;
   
      Request          : $Request_label  -> $Request_value
      Expected_Response: $Response_label -> $Response_value
      Eval Mode        : $mode
      Description      : $description
EOT2
#--------------------

        S_w2log( 3, "$text\n" );

        $response = DCOM_request($Request_value, $Response_value, $mode, $description , $NO_EVAL_SWITCH);  
        return 1 if $main::opt_offline;
        S_w2rep( "DCOM_request_general: Response: $response\n" );
        S_add2eval_collection( $EVAL_REPORT_LABEL, "    det_resp: $response");
    } # end of direct requests        
    return $response;
}

#####################################################################

=head2 DCOM_check_request_definition

    DCOM_check_request_definition ( $Request );

    checks if a request is defined in the DiagMapping file
    
Example:

    DCOM_check_request_definition('DefaultSession' );

=cut

#####################################################################�

sub DCOM_check_request_definition {
  my $Request_label = shift;
  
  my $Request_label_short;

  # $Request_label =~ s/REQ_//i;
  $Request_label_short = $Request_label;  
  if( $Request_label =~ /\_\_/ ){
    $Request_label =~ /(\w*)(\_\_)/;
    $Request_label_short = $1;
  }
  $Request_label_short =~ s/(REQ_)//i;
  unless( defined $GENERIC_DiagMapping->{'Requests_Responses'}{$Request_label_short}){
        S_set_error ("\n DCOM_check_request_definition: $Request_label_short not defined in the Diag Mapping nothing done\n", 20);
        return 0;  
  }
}

#####################################################################

=head2 DCOM_resolve_label_value

    DCOM_resolve_label_value ( $Label );

Example:

    DCOM_resolve_label_value();

=cut

#####################################################################�

sub DCOM_resolve_label_value {
  my $label = shift;
  
  my ( 
      $value,
     );
  unless( defined $GENERIC_DiagMapping->{'label_value_mapping'}{$label}){
        S_w2rep ("\n Label $label not defined in the Diag Mapping\n");
        S_set_error( "Label $label not defined in Diag Mapping\n", 20 );
        return 0;  
  }
  $value = $GENERIC_DiagMapping->{'label_value_mapping'}{$label};
  S_w2rep( "DCOM_resolve_label_value: Label: $label Value: $GENERIC_DiagMapping->{'label_value_mapping'}{$label}\n" );
  
  return $value;  
}

#####################################################################

=head2 DCOM_evaluate_phys

    DCOM_evaluate_phys ( $response , $label, $expected_value_phys , $tolerance, $tolerance_type );

Example:

    DCOM_evaluate_phys();

=cut

#####################################################################�

sub DCOM_evaluate_phys{
  my $response = shift;
  my $label = shift;
  my $expected_value_phys = shift;
  my $label_group = shift;
  my $tolerance = shift;
  my $tolerance_type = shift;
  
  my ( 
      $value,
      $start_bit,
      $offset,
      $factor,
      $value_hex,
      $length,
      $data_bytes,
      $length_of_hex,
      $value_bin,
      $temp,
      $number_of_bytes,
      $i,
      $dummy_data_bytes,
      $mask,
      $start_byte,
      $data_typ,
      $response_bytes,
      $detected_value_hex,
      $detected_value_phys,
      $detected_value_bin,
      $sign_type,
      $signal_msb,
      $doors_reqIDS,
      $tolerance_text,
      $text
     );
      
  unless( defined $tolerance ){ $tolerance = 0; }
  if( $tolerance_type eq 'absolute' ){$tolerance_text = "+/-".$tolerance;}
  if( $tolerance_type eq 'relative' ){$tolerance_text = $tolerance."%";}

  if(defined $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label} ){
    $start_bit = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'STARTBIT'};
    $length    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'LENGTH'};
    $offset    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'OFFSET'};
    $factor    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'FACTOR'};
    $sign_type = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'TYPE'};
    $doors_reqIDS = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'DoorsIDs'};
    push(@DoorsIDs , @$doors_reqIDS )if(defined $doors_reqIDS);
  }
  elsif( defined $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}){
    $start_bit = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'STARTBIT'};
    $length    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'LENGTH'};
    $offset    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'OFFSET'};
    $factor    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'FACTOR'};
    $sign_type = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'TYPE'};  
    $doors_reqIDS = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'DoorsIDs'};
    push(@DoorsIDs , @$doors_reqIDS )if(defined $doors_reqIDS);
  }
  else{
      S_w2rep ("\n Label '$label' not defined in (diagmapping) Response_Phys2Hex\n");
      S_set_error( "Label '$label' not defined in (diagmapping) Response_Phys2Hex\n", 20);
      return 0;  
  }  
  S_add2eval_collection( $EVAL_REPORT_LABEL, "    Evaluate_phys:$label = $expected_value_phys");
  unless(defined $write_2_inner_table){
    DCOM_w2html( "dummy&5" , "BTI"  );
    $text = "Signal;Exp;Det;Tol;Verdict";
    DCOM_w2html( "$text" , "TI" , "black", "Courier", "Lightpink");
    $write_2_inner_table = 1;
  }
  if($main::opt_offline){
  DCOM_w2html( "$label;$expected_value_phys;$detected_value_phys;$tolerance_text;PASS" , "TI"  , 'green' , "Courier" );    
  } 
  @$response_bytes = split(/ /, $response);
    
  $start_byte = int( $start_bit / 8 );
  
  $mask = "1" x $length;
  $mask = sprintf ("%0X" , (eval('0b'.$mask)) << ( $start_bit % 8) );
  $mask = ("0" x (length($mask) % 2 ) ) . $mask;
  $number_of_bytes = length($mask)/2;
   
  for($i = $start_byte  ; $i > ( $start_byte - $number_of_bytes);$i--){
      unless( defined $response_bytes->[$i]){
        S_w2rep ("\nResponse_Phys2Hex: Length of Response is not correct. Byte $i is not having any value \n");
        S_set_error( "Response_Phys2Hex: Length of Response is not correct. Byte $i is not having any value\n", 0 );
        return 0;  
    }
    $detected_value_hex = $response_bytes->[$i].$detected_value_hex;
  }
  
  S_w2rep ("\nResponse_Phys2Hex: detected Hex value $detected_value_hex \n");
 
  $detected_value_hex = hex($detected_value_hex);
  $mask = hex($mask);  
  $detected_value_hex = $detected_value_hex & $mask;
  
  $detected_value_bin = sprintf("%0b", $detected_value_hex);
  $detected_value_bin = ("0" x ($length - length($detected_value_bin)) ).$detected_value_bin;
  
  $detected_value_hex = sprintf ("%0X" , (eval('0b'.$detected_value_bin)) >> ( $start_bit % 8) );
  $detected_value_hex = hex( $detected_value_hex );
  
  if( $sign_type eq 'SIGNED' and $detected_value_bin =~ /^1/ ) {
            $mask = "1" x $length;
            $mask = sprintf ("%0X" , (eval('0b'.$mask)) );
            $mask = hex($mask);
            $detected_value_hex = ~ $detected_value_hex & $mask;   # 2 - complement (change all bits)
            S_w2rep ("\nResponse_Phys2Hex: just to check $mask, $detected_value_hex\n");
            $detected_value_phys =  $detected_value_hex * $factor + $offset ; 
            $detected_value_phys = $detected_value_phys * -1;               
  }
  else{
    $detected_value_phys =  $detected_value_hex * $factor + $offset ;  
  }
 
  S_w2rep ("\nResponse_Phys2Hex: Response bytes @$response_bytes \n detected value: $detected_value_hex (hex) $detected_value_phys (phys) ,mask: $mask msb:$detected_value_bin\n");
  $text = $text."Hex Value = $detected_value_hex \n Physical Value = $detected_value_phys \n";
  $current_verdict = EVAL_evaluate_value($label, $detected_value_phys , "==" , $expected_value_phys, $tolerance , $tolerance_type );

#   $text = "$label;$expected_value_phys;$detected_value_phys;$tolerance;$current_verdict";
#   DCOM_w2html( "$text" , "TI" );

  if( $current_verdict eq VERDICT_PASS){
        DCOM_w2html( "$label;$expected_value_phys;$detected_value_phys;$tolerance_text;PASS" , "TI"  , 'green' , "Courier" );    
    }
    else{
        DCOM_w2html( "$label;$expected_value_phys;$detected_value_phys;$tolerance_text;FAIL" , "TI"  , 'red' , "Courier" );
    }
  return;  
}

#####################################################################

=head2 DCOM_evaluate_hex

    DCOM_evaluate_hex ( response , data_label, expected_value_hex , label_group);

Example:

    DCOM_evaluate_hex();

=cut

#####################################################################�

sub DCOM_evaluate_hex{
  my $det_response = shift;
  my $label = shift;
  my $expected_value_hex = shift;
  my $label_group = shift;

  my ( 
        $start_bit,
        $length,
        $doors_reqIDS,
        $response_bytes,
        $start_byte,
        $mask,
        $number_of_bytes,
        $i,
        $detected_value_hex,
        $tolerance,
        $byte,
        $byte_mask,
        $j,
     );
  undef $byte_mask;
  undef $detected_value_hex;
  
  if(defined $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label} ){
    $start_bit = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'STARTBIT'};
    $length    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'LENGTH'};
    $doors_reqIDS = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'DoorsIDs'};
    push(@DoorsIDs , @$doors_reqIDS )if(defined $doors_reqIDS);    
  }
  elsif( defined $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}){
    $start_bit = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'STARTBIT'};
    $length    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'LENGTH'};
    $doors_reqIDS = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'DoorsIDs'};
    push(@DoorsIDs , @$doors_reqIDS )if(defined $doors_reqIDS);
  }
  else{
      S_w2rep ("\n Label '$label' not defined in (diagmapping) Response_Phys2Hex\n");
      S_set_error( "Label '$label' not defined in (diagmapping) Response_Phys2Hex\n", 20 );
      return 0;  
  }  
#   S_add2eval_collection( $EVAL_REPORT_LABEL, "    Evaluate_hex:$label = $expected_value_hex");
  unless(defined $write_2_inner_table){
    DCOM_w2html( "dummy&5" , "BTI"  );
    my $text = "Signal;Exp;Det;Tol;Verdict";
    DCOM_w2html( "$text" , "TI" , "black", "Courier", "Lightpink");
    $write_2_inner_table = 1;
  }
  @$response_bytes = split(/ /, $det_response);

   if($main::opt_offline){
   DCOM_w2html( "$label;$expected_value_hex;$detected_value_hex;$tolerance;PASS" , "TI"  , 'green' , "Courier" );
   }    
  
    $start_byte = int( $start_bit / 8 );
    $number_of_bytes = $length / 8;
    if($length % 8 )
    {
      $number_of_bytes++; 
    }
    $mask = "0" x ( $start_bit % 8); # to shift the bits to get the correct bit position
    $mask = "1" x ( $length - ( $start_bit % 8)).$mask;
    for($i=0; $i<$number_of_bytes; $i++){
        $byte = substr( $mask , $i*8 , 8 ); 
        $byte = eval('0b'.$byte);
        push( @$byte_mask , $byte );     
    }
    
    for($i = $start_byte,$j=0  ; $i > ( $start_byte - $number_of_bytes);$i--,$j++){
      unless( defined $response_bytes->[$i]){
        S_w2rep ("\nResponse_Phys2Hex: Length of Response is not correct. Byte $i is not having any value \n");
        S_set_error( "Response_Phys2Hex: Length of Response is not correct. Byte $i is not having any value\n", 0 );
        return 0;  
      }
      $byte = hex($response_bytes->[$i]);
      $byte = $byte & $byte_mask->[$j];
      $byte = sprintf( "%02X" , $byte);
      if(defined $detected_value_hex){ $detected_value_hex = $byte." ".$detected_value_hex;}
      else{$detected_value_hex = $byte; }
    }
    S_w2rep ("\nResponse_Phys2Hex: detected Hex value $detected_value_hex \n");    

# remove any extra spaces in $expected_value_hex
     $expected_value_hex =~ s/(\s+)/ /g;

    S_w2rep ("\n DCOM_evaluate_hex: compare exp: $expected_value_hex det: $detected_value_hex \n");    
    if($detected_value_hex eq $expected_value_hex ){
        S_set_verdict('VERDICT_PASS'); 
         DCOM_w2html( "$label;$expected_value_hex;$detected_value_hex;0;PASS" , "TI"  , 'green' , "Courier" );  
   }
    else
    {
        S_set_verdict('VERDICT_FAIL');   
        DCOM_w2html( "$label;$expected_value_hex;$detected_value_hex;0;FAIL" , "TI"  , 'red' , "Courier" );       
    }
    
    return 1;
}

###################################################################

=head2 DCOM_w2html

    DCOM_w2html ( $TEXT , [style] [color] [font] [bgcolor]);

Writes $TEXT to STDOUT, standard logfile and standard report file.

=cut

###################################################################

sub DCOM_w2html {
    my $text  = shift;
    my $STYLE = shift;
    my $color = shift;
    my $font  = shift;
    my $bgcolor = shift;
    my $i;
    my( @cell_contents,
        $text1,
        @table_values,
        $length,
        $TC_time_sec,
        $htmlText,
      );
    my $current_time = time; 

    $TC_time_sec = S_get_TC_time();
    
    unless(defined $bgcolor){$bgcolor = 'white';}
    unless(defined $font){ $font = 'Courier'}
    unless(defined $color){ $color = 'black';}
    $text =~ s/\n/<BR>/g;
    
    if(defined $write_2_inner_table){
        unless( uc($STYLE) eq 'TI' ){
              $text1 = "</TABLE></TD></TR>\n<P style='margin-left:1cm'><span style=\"font-family:$font\" style=\"color:$color\">\n";
              push( @HTML_TEXT,  $text1 );
              undef $write_2_inner_table;  
#               return;
        }
    }
    
    unless(defined $STYLE){$STYLE = 'S';}
    if( uc($STYLE) eq 'L' ){
        $text = "</P>\n<H2 style='margin-left:1cm'><span style=\"font-family:$font\" style=\"color:$color\">$text</span</H2><P style='margin-left:1cm'><span style=\"font-family:Courier\" style=\"color:$color\">\n";
    }
    elsif( uc($STYLE) eq 'M' ){
        $text = "</P><H3 style='margin-left:0.1cm'><span style=\"font-family:$font\" style=\"color:$color\">$text</span</H3><P style='margin-left:1cm'><span style=\"font-family:Courier\" style=\"color:$color\">\n";
    }
    elsif( uc($STYLE) eq 'S' ){
        unless ( $color eq "black" ) { $text = "<span style=\"color:$color\">$text</span>\n"; }
        $text = "$text\n";
        # no change for small comments
    }
    elsif( uc($STYLE) eq 'BT' ){
          $htmlText = "\n</P>\n<TABLE id = \"TestSteps\" style=\"font-family:$font\" style='margin-left:1cm' BORDER CELLSPACING=1 CELLPADDING=4>\n";
          push( @HTML_TEXT,  $htmlText );        
          @table_values = split(";",$text);
          $length = @table_values;
          for($i = 0; $i< $length ; $i++ ){
           $htmlText = "<TD nowrap ALIGN=LEFT bgcolor=\"$bgcolor\"><P><span style=\"color:$color\">$table_values[$i]</span></TD>";
           push( @HTML_TEXT,  $htmlText );                             
          }
          return;  
    }
    elsif( uc($STYLE) eq 'BTI' ){
          @cell_contents = split("&",$text);
          unless(defined $cell_contents[1]){$cell_contents[1] = 1; }

          $text = "<TR><TD ALIGN=LEFT bgcolor=\"$bgcolor\"><P><span style=\"color:$color\">$row_number</span></TD>";
          push( @HTML_TEXT,  $text );
          $text = "<TD colspan=1 nowrap ALIGN=LEFT bgcolor=\"$bgcolor\"><P><span style=\"color:$color\">$TC_time_sec</span></TD>";
          push( @HTML_TEXT,  $text );                      

          $text = "</P><TD colspan=$cell_contents[1] ALIGN=LEFT bgcolor=\"white\"><TABLE style=\"font-family:$font\" BORDER CELLSPACING=1 CELLPADDING=4>\n";
          push( @HTML_TEXT,  $text );        
          $row_number++;
          return;  
    }
    elsif( uc($STYLE) eq 'T' | uc($STYLE) eq 'TI'){
          @table_values = split(";",$text);
          $length = @table_values;
          
          if($text =~ /(PASS)/){push( @HTML_TEXT, "<TR id=\"PASS\">");}
          elsif($text =~ /(FAIL)/){push( @HTML_TEXT, "<TR id=\"FAIL\">");}
          else{ push( @HTML_TEXT, "<TR id=\"GenText\">"); }
          
          if(uc($STYLE) eq 'T' ){
            $text = "<TD colspan=$cell_contents[1] nowrap ALIGN=LEFT bgcolor=\"$bgcolor\"><P><span style=\"color:$color\">$row_number</span></TD>";
            push( @HTML_TEXT,  $text );
            $text = "<TD colspan=$cell_contents[1] nowrap ALIGN=LEFT bgcolor=\"$bgcolor\"><P><span style=\"color:$color\">$TC_time_sec</span></TD>";
            push( @HTML_TEXT,  $text );                      
            $row_number++;
          }          
          for($i = 0; $i< $length ; $i++ ){
            undef @cell_contents;
            @cell_contents = split("&",$table_values[$i]);
            unless(defined $cell_contents[1]){$cell_contents[1] = 1; }
            if(defined $color){
              $text = "<TD colspan=$cell_contents[1] nowrap ALIGN=LEFT bgcolor=\"$bgcolor\"><P><span style=\"color:$color\">$cell_contents[0]</span></TD>";                            
            }
            else{
              $text = "<TD colspan=$cell_contents[1] nowrap ALIGN=LEFT><P>$cell_contents[0]</TD>";            
            }
            push( @HTML_TEXT,  $text );                    
          }   
          push( @HTML_TEXT, "</TR>\n");
          return;
    }
    elsif( uc($STYLE) eq 'ET' ){
          $text = "</TABLE>\n<P style='margin-left:1cm'><span style=\"font-family:$font\" style=\"color:$color\">\n";
          push( @HTML_TEXT,  $text );  
          $row_number = 1;        
          return;
    }
    elsif( uc($STYLE) eq 'ETI' ){
          $text = "</TABLE></TD></TR>\n<P style='margin-left:1cm'><span style=\"font-family:$font\" style=\"color:$color\">\n";
          push( @HTML_TEXT,  $text );
          undef $write_2_inner_table;  
          return;
    }
    else{
        # no change for small comments
    }
    push( @HTML_TEXT,  $text );

}

###################################################################

=head2 DCOM_w2tc_html

    DCOM_w2tc_html ( $FILENAME );

Writes the report of the testcase to the HTML testcase file.

=cut

###################################################################

sub DCOM_w2tc_html {
    my $file = shift;
    my( $text,
        $verdict_color,
        $verdict,
        $tc_name,
        $steps_log,
        $test_start_time,
        $start_date,
        $start_time,
        $tc_id,
        $add_text
      );
    
    $test_start_time = time(); # store time od STEPS start
   ($start_date, $start_time) = S_formated_timestamp($test_start_time);
    
    DCOM_w2html( "\nExecuted on: $start_date $start_time \n" , 'S' , 'brown' );
    DCOM_w2html( "<--------------------------------- END OF THE TEST ---------------------------------> \n\n" , 'S');
        
    my $save_path = $main::save_name;
       
    my $count = sprintf("%04d",$TC_cnt );
    if(defined $file ){$tc_id = $file; }
    else{$tc_id= $main::CURRENT_TC if $main::CURRENT_TC; }
    #  $file = "c:\\temp\\".$tc_id.".html";
    $tc_name = $tc_id;
    $STEPS_campaign_report->{$TC_cnt}{'ID'} = $tc_id; 

    $tc_id =~ s/\./\-/g;
    if( $main::opt_offline){ $tc_id =  "offline_".$count."_".$tc_id."_NT.html";}
    else{ $tc_id = $count."_".$tc_id."_NT.html"; }
    $steps_log = $tc_id;
    $steps_log =~ s/_NT\.html/\.html/;
    $file =  $save_path."\\".$tc_id;

    $STEPS_campaign_report->{$TC_cnt}{'SL_NO'} = $TC_cnt; 
    $STEPS_campaign_report->{$TC_cnt}{'VERDICT'} = $VERDICT; 
    $STEPS_campaign_report->{$TC_cnt}{'html_log'} = $tc_id; 
    
    S_w2log( 2, " Writing $file \n");
    unless( open( TC_HTML, ">$file" ) ) { 
    my $file_length = length( $file );
    $add_text = "(NOTE: file length = $file_length) " if $file_length >= 255;
    S_set_error( "Error opening $file $add_text: $!", 1 );
    return 0;
    }

#     if($VERDICT eq "VERDICT_PASS") {print TC_HTML "<B><span style=\"color:green\">VERDICT: PASS</span></B><BR>\n";$count_pass++;$verdict_color="green"}; 
#     if($VERDICT eq "VERDICT_FAIL") {print TC_HTML "<B><span style=\"color:red\">>VERDICT: FAIL</span></B><BR>\n";$count_fail++;$verdict_color="red"}; 
#     if($VERDICT eq "VERDICT_NONE") {print TC_HTML "<B><span style=\"color:blue\">>VERDICT: NONE</span></B><BR>\n";$count_none++;$verdict_color="blue"}; 
#     if($VERDICT eq "VERDICT_INCONC") {print TC_HTML "<B><span style=\"color:magenta\">>VERDICT: INCONC</span></B><BR>\n";$count_inconc++;$verdict_color="magenta"}; 
    if($VERDICT eq "VERDICT_PASS")  {$count_pass++;$verdict = "PASS";$verdict_color="green"}; 
    if($VERDICT eq "VERDICT_FAIL")  {$count_fail++;$verdict = "FAIL";$verdict_color="red"}; 
    if($VERDICT eq "VERDICT_NONE")  {$count_none++;$verdict = "NONE";$verdict_color="blue"}; 
    if($VERDICT eq "VERDICT_INCONC"){$count_inconc++;$verdict = "INCONC";$verdict_color="magenta"}; 
   
    
    
    $text=<<EOHTML;
    
<!-- Java Script to Filter PASS / FAIL -->
<script type="text/javascript">
function showhideRows(obj)
{
  var table = document.getElementById('TestSteps');
  var len = table.rows.length;
   if(!obj.checked)
   {
      for(i=1 ; i< len; i++)
      {
        if(table.rows[i].id == obj.value)
        {    
            table.rows[i].style.display = 'none';   
            table.rows[i].style.visibility="hidden";       
        }
      }
    }
    else
    {
      for(i=1 ; i< len; i++)
      {
        if(table.rows[i].id == obj.value)
        {    
            table.rows[i].style.display = '';  
            table.rows[i].style.visibility="visible";           
        }
      }  
  }
}

</script> 
    
<!-- Overall result -->
<TABLE style="font-family:Courier"  BORDER CELLSPACING=1 CELLPADDING=4 WIDTH=900>
    <!-- Test ID  -->
        <TR>
            <TD WIDTH="20%" ALIGN=LEFT><P>TEST ID</TD>
            <TD WIDTH="80%" ALIGN=LEFT>$tc_name</TD>
        </TR>
    <!-- Verdict -->
        <TR>
            <TD WIDTH="20%" ALIGN=LEFT><P>VERDICT</TD>
            <TD WIDTH="80%" ALIGN=LEFT><span style="color:$verdict_color">$verdict</span></TD>
        </TR>
    <!-- Link to STEPS log -->
        <TR>
            <TD WIDTH="20%" ALIGN=LEFT><P>STEPS Log</TD>
            <TD WIDTH="80%" ALIGN=LEFT><P><A HREF="$steps_log">$tc_name</A></TD></TR>
        </TR>
</TABLE>  
    <!-- horizontal line -->
    <P ALIGN="CENTER"><HR></P>   
<FORM  name = Filter>
<H4 style='font-family:Arial'>Filter Test Steps based on Verdict </H4>
<INPUT TYPE=CHECKBOX checked ID="PASS" OnClick="showhideRows(PASS);" VALUE = 'PASS' > Passed</TD>
<INPUT TYPE=CHECKBOX checked ID="FAIL" OnClick="showhideRows(FAIL);"  VALUE = 'FAIL' >Failed</TD>
</FORM>
    <P ALIGN="CENTER"><HR></P>   
       
EOHTML
    
    print TC_HTML $text;
    
  if( $main::opt_offline)
 { 
  print TC_HTML "<H2 style=\"font-family:Arial\">Running in offline mode, not on real hardware HW</H2></A>";
  }
  else 
  { 
  print TC_HTML "<H2 style=\"font-family:Arial\">Running on real Hardware HW</H2></A>";
  }
    
#     print TC_HTML "<B>".$TC_cnt."</B><BR>\n";
    #  print TC_HTML "<B>".$VERDICT."</B><BR>\n";
    
    print TC_HTML @HTML_TEXT;
    undef @HTML_TEXT; #empty hash for next test

    unless( close( TC_HTML ) ) { S_set_error( "Error closing $file : $!", 1); return 0;  }
    $TC_cnt++;           # Increment the Test counter
    $TestStepNumber = 1; #Reset Test Step counter
    
    undef $RB_faults; #empty RB faults for next test
    undef $CU_faults; #empty CU faults for next test
  return 1;
}

###################################################################

=head2 DCOM_write_campaign_report

    DCOM_write_campaign_report (  );


=cut

#####################################################################

sub DCOM_write_campaign_report{
    my(
        @temp,
        $campaign_log,
        $save_path,
        $text,
        $verdict_color,
        $verdict,  
        $link,
        $campaign_name,
        $tc_id,
        $add_text,
        $count_total,
       );
    $save_path = $main::save_name;        
    $save_path =~ s/\\/\//g; #replace "\" with "/"
    S_w2rep("save path $save_path\n");   
    
    @temp = split("/" , $save_path);
    $campaign_name = pop( @temp );

    $save_path = $LIFT_config::LIFT_LOG_path;    
    $campaign_log = $save_path."\\".$campaign_name."_result_NT.html";
    S_w2rep("dir name $campaign_log\n");

    unless( open( CAMPAIGN_HTML, ">$campaign_log" ) ) { 
        my $file_length = length( $campaign_log );
        $add_text = "(NOTE: file length = $campaign_log) " if $file_length >= 255;
        S_set_error( "Error opening $campaign_log $add_text: $!", 1 );
        return 0;
    }

# write the result summary 

    print CAMPAIGN_HTML $text;
    
    $count_total = $count_pass + $count_fail + $count_inconc + $count_none ;
    $text=<<EOHTML;
<!DOCTYPE HTML PUBLIC "-//W3C//HTML 3.2 Final//EN">
<!-- Start HTML Header -->
    <HTML><HEAD>
    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1252">
    <META NAME="Generator" CONTENT="STEPS exec engine ">
    <TITLE>STEPS RESULT: $campaign_log </TITLE>
    </HEAD>
<!-- End HTML Header -->
<!-- Start HTML Body -->
<BODY DIR=LTR BGCOLOR="#FFFFFF">
    <!-- STEPS Headline -->
    <H1 style="font-family:Arial" ALIGN=MIDDLE>DCOM UDS Test Campaign</H1>

    <!-- horizontal line -->
    <P ALIGN="CENTER"><HR></P>

    <!-- Result Summary headline -->
    <H2 style="font-family:Arial">Result Summary</H2>

    <!-- Overall result -->
    <TABLE style="font-family:Courier" style='margin-left:3cm' BORDER CELLSPACING=1 CELLPADDING=4 WIDTH=120>
        <!-- Verdict | Count -->
            <TR>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:black"><P>Verdict</TD>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:black">Count</span></TD>
            </TR>
            <TR>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:green"><P>PASS</TD>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:green">$count_pass</span></TD>
            </TR>
            <TR>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:red"><P>FAIL</TD>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:red">$count_fail</span></TD>
            </TR>
            <TR>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:magenta"><P>INCONC</TD>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:magenta">$count_inconc</span></TD>
            </TR>
            <TR>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:blue"><P>NONE</TD>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:blue">$count_none</span></TD>
            </TR>
            <TR>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:black"><P>Total</TD>
                <TD WIDTH="10%" ALIGN=RIGHT><span style="color:black">$count_total</span></TD>
            </TR>
    </TABLE>            
EOHTML
    print CAMPAIGN_HTML $text;


    $text=<<EOHTML;
    <!-- headline " Execution List "-->
    <!-- horizontal line -->
    <P ALIGN="CENTER"><HR></P>
    <H2 style="font-family:Arial">Execution List</H2>
    <!-- start main table of testcase execution -->
    <TABLE style="font-family:Courier" BORDER CELLSPACING=1 CELLPADDING=4 WIDTH=900>
        <!-- header of table of testcase execution -->
        <!-- Nbr | TC_ID | VERDICT -->
        <TR ALIGN=MIDDLE>
            <TD WIDTH="4%"><P>Nbr</TD>
            <TD WIDTH="60%"><P>Testcase ID</TD>
            <TD WIDTH="6%"><P>VERDICT</TD>
        </TR>

EOHTML
    print CAMPAIGN_HTML $text;

    foreach my $count(sort {$a<=>$b} keys %$STEPS_campaign_report){
        S_w2rep("$STEPS_campaign_report->{$count}{'SL_NO'}...$STEPS_campaign_report->{$count}{'ID'}...$STEPS_campaign_report->{$count}{'VERDICT'}\n");
        $tc_id = $STEPS_campaign_report->{$count}{'ID'};
        $tc_id =~ s/\.html//g;
        $link = $campaign_name."//".$STEPS_campaign_report->{$count}{'html_log'};
        if($STEPS_campaign_report->{$count}{'VERDICT'} eq "VERDICT_PASS") {$verdict = "PASS";$verdict_color = "green"; $count_pass++;}; 
        if($STEPS_campaign_report->{$count}{'VERDICT'} eq "VERDICT_FAIL") {$verdict = "FAIL";$verdict_color = "red";$count_fail++;}; 
        if($STEPS_campaign_report->{$count}{'VERDICT'} eq "VERDICT_NONE") {$verdict = "NONE";$verdict_color = "blue";$count_none++;}; 
        if($STEPS_campaign_report->{$count}{'VERDICT'} eq "VERDICT_INCONC") {$verdict = "NONE";$verdict_color = "red";$count_inconc++;}; 

    $text=<<EOHTML;
        <!-- info line of testcase: $STEPS_campaign_report->{$count}{'ID'} -->
        <!-- Nbr | TC_ID | VERDICT -->
            <TR>
                <TD WIDTH="4%" ALIGN=RIGHT><P>$count</TD>
                <TD WIDTH="60%"><A HREF="$link">$tc_id</A></TD>
                <TD WIDTH="6%" ALIGN=MIDDLE><span style="color:$verdict_color"><P>$verdict</span></TD>
            </TR>
EOHTML
    print CAMPAIGN_HTML $text;
    }#end of foreach    

}

#####################################################################

=head2 DCOM_calc_value_phys

    DCOM_calc_value_phys ( $response , $label, $label_group );

Example:

    DCOM_calc_value_phys();

=cut

#####################################################################�

sub DCOM_calc_value_phys{
  my $response = shift;
  my $label = shift;
  my $label_group = shift;
  
  my ( 
      $value,
      $start_bit,
      $offset,
      $factor,
      $value_hex,
      $length,
      $data_bytes,
      $length_of_hex,
      $value_bin,
      $temp,
      $number_of_bytes,
      $i,
      $dummy_data_bytes,
      $mask,
      $start_byte,
      $data_typ,
      $response_bytes,
      $detected_value_hex,
      $detected_value_phys,
      $detected_value_bin,
      $sign_type,
      $signal_msb,
      $doors_reqIDS,
      $text,
     );
  if(defined $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label} ){
    $start_bit = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'STARTBIT'};
    $length    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'LENGTH'};
    $offset    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'OFFSET'};
    $factor    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'FACTOR'};
    $sign_type = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'TYPE'};
    $doors_reqIDS = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label_group}{$label}{'DoorsIDs'};
    push(@DoorsIDs , @$doors_reqIDS )if(defined $doors_reqIDS);
  }
  elsif( defined $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}){
    $start_bit = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'STARTBIT'};
    $length    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'LENGTH'};
    $offset    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'OFFSET'};
    $factor    = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'FACTOR'};
    $sign_type = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'TYPE'};  
    $doors_reqIDS = $GENERIC_DiagMapping->{'Response_Phys2Hex'}{$label}{'DoorsIDs'};
    push(@DoorsIDs , @$doors_reqIDS )if(defined $doors_reqIDS);
  }
  else{
      S_w2rep ("\n Label '$label' not defined in (diagmapping) Response_Phys2Hex\n");
      S_set_error( "Label '$label' not defined in (diagmapping) Response_Phys2Hex\n", 20 );
      return 0;  
  }  
  @$response_bytes = split(/ /, $response);
    
  $start_byte = int( $start_bit / 8 );
  
  $mask = "1" x $length;
  $mask = sprintf ("%0X" , (eval('0b'.$mask)) << ( $start_bit % 8) );
  $mask = ("0" x (length($mask) % 2 ) ) . $mask;
  $number_of_bytes = length($mask)/2;
   
  for($i = $start_byte  ; $i > ( $start_byte - $number_of_bytes);$i--){
      unless( defined $response_bytes->[$i]){
        S_w2rep ("\nResponse_Phys2Hex: Length of Response is not correct. Byte $i is not having any value \n");
        S_set_error( "Response_Phys2Hex: Length of Response is not correct. Byte $i is not having any value\n", 0 );
        return 0;  
    }
    $detected_value_hex = $response_bytes->[$i].$detected_value_hex;
  }
  
  S_w2rep ("\nResponse_Phys2Hex: detected Hex value $detected_value_hex \n");
  $detected_value_hex = hex($detected_value_hex);
  $mask = hex($mask);  
  $detected_value_hex = $detected_value_hex & $mask;
  
  $detected_value_bin = sprintf("%0b", $detected_value_hex);
  $detected_value_bin = ("0" x ($length - length($detected_value_bin)) ).$detected_value_bin;
  
  $detected_value_hex = sprintf ("%0X" , (eval('0b'.$detected_value_bin)) >> ( $start_bit % 8) );
  $detected_value_hex = hex( $detected_value_hex );
  
  if( $sign_type eq 'SIGNED' and $detected_value_bin =~ /^1/ ) {
            $mask = "1" x $length;
            $mask = sprintf ("%0X" , (eval('0b'.$mask)) );
            $mask = hex($mask);
            $detected_value_hex = ~ $detected_value_hex & $mask;   # 2 - complement (change all bits)
            S_w2rep ("\nResponse_Phys2Hex: just to check $mask, $detected_value_hex\n");
            $detected_value_phys =  $detected_value_hex * $factor + $offset ; 
            $detected_value_phys = $detected_value_phys * -1;               
  }
  else{
    $detected_value_phys =  $detected_value_hex * $factor + $offset ;  
  }
 
  S_w2rep ("\nResponse_Phys2Hex: Response bytes @$response_bytes \n detected value: $detected_value_hex (hex) $detected_value_phys (phys) ,mask: $mask msb:$detected_value_bin\n");
  return( $detected_value_phys );  
}

###################################################################

=head2 DCOM_request_w2html

    DCOM_request_w2html ( req, exp , det, mode , desc,);


=cut

###################################################################

sub DCOM_request_w2html{
  my $request = shift;
  my $exp_resp = shift;
  my $det_resp = shift;
  my $mode = shift;
  my $desc = shift;
  if( $current_verdict eq VERDICT_PASS){
      DCOM_w2html( "$request;Exp:$exp_resp\nDet:$det_resp;PASS;$mode;$desc" , "T"  , 'green' , "Courier" );    
  }
  else{
      DCOM_w2html( "$request;Exp:$exp_resp\nDet:$det_resp;FAIL;$mode;$desc" , "T"  , 'red' , "Courier" );
  }
  return 1;

}

#####################################################################

=head2 DCOM_init

    DCOM_init ( @KEYWORDS );
    
Initializes a compact test. Accepts any of the following keywords:

   'EA_CONFIG': configures EA trace (measurement)
   'CA_CONFIG': configures CAN read/write/trace
   'FR_CONFIG': configures Flexray read/write/trace
   'FCM_DEL':   deletes RB and customer (if configured) fault memory
   'ECU_ON':    switches the ECU on with default voltage

=cut

#####################################################################

sub DCOM_init {
   
   my @KEYWORDS = @_;
   my $fltmem1;
   my $TC_SRT_ID       = DCOM_tcpar('SRT_ID');       #Automatically generated from DOORS
   my $TC_SRT_fullname = DCOM_tcpar('SRT_fullname'); #Automatically generated from DOORS
   my $res;

   $GENERIC_Testbench       = $LIFT_config::LIFT_Testbench;
   $GENERIC_DCOM_data       = $LIFT_config::LIFT_DCOM_data;
   $GENERIC_ProjectDefaults = $LIFT_config::LIFT_ProjectDefaults;
   $ProjectDefaults         = $main::ProjectDefaults;
   
   $GENERIC_DiagMapping = S_get_contents_of_hash(['Mapping_DIAG']);

    unless( $GENERIC_DiagMapping )
    {
        S_set_error( '$Default->{"Mapping_DIAG"} is not defined (or) Mapping_DIAG.pm file is not included in CFG' , 20 );
        return;
    }

    $GENERIC_CAN_mapping = S_get_contents_of_hash(['Mapping_CAN']);
    
    unless( $GENERIC_CAN_mapping )
    {
        S_set_error( '$Default->{"Mapping_CAN"} is not defined (or) Mapping_CAN.pm file is not included in CFG' , 20 );
        return;
    }

   S_w2rep("DCOM_init: initializing DCOM test case with keyword(s) @KEYWORDS...\n");

   S_w2log(5, "DCOM_init: resetting all scheduler timers and globals.\n");

   if( grep( /CA_CONFIG/i, @KEYWORDS ) ){
      CA_trace_stop();  
      DCOM_delay(3);
      CA_trace_start();  
      DCOM_delay(3);
    }
   if( grep( /ECU_ON/i, @KEYWORDS ) ){
    DCOM_ecu_on ();
   }
   if( grep( /FCM_DEL/i, @KEYWORDS ) ){
    PD_ECUlogin();# pyi2kor 09-10-2012
    $fltmem1 = PD_GetExtendedFaultInformation();
    PD_ClearFaultMemory(); 
   }
  
  return 1;
}

#####################################################################

=head2 DOCM_final

    DOCM_final ( @KEYWORDS );
    
Finalizes a compact test. Accepts any of the following keywords:

   'SPEED'   : decelerates vehicle to speed 0
   'UNDO'    : resets all line manipulations and bind_stimuli_to_XXX manipulations
   'FCM_DEL' : deletes RB and customer (if configured) fault memory
   'ECE13'   : switches ECU off and on, accelerates to 30km/h and brakes to 0km/h; i.e. remove ECE13 fault
   'ECU_OFF' : switches the ECU off

=cut

#####################################################################

sub DCOM_final {
   

   my @KEYWORDS = @_;

   my $label;
   my( 
        $zip_filename,
        $count,
        $filename,
        $temp_store_path,
        $zip_handle,
        $res,
        $fltmem1,
     );
     
     ######
       my @TCIDData = split(/\./,$main::CURRENT_TC);
       print "TCIDData is @TCIDData\n";
   S_add2eval_collection( 'TC_NAME', "$TCIDData[0]");
#    S_add2eval_collection( 'TCPAR_NAME', "* $TCIDData[1]");
   S_add2eval_collection( 'Test Heading', "* $TCIDData[1]");
   S_add2eval_collection( 'Review State', "Proposed");
   S_add2eval_collection( 'Test State', "not done");
    S_add2eval_collection( 'Type', "Test Case");
   #####################
   
    if($main::opt_offline){return 1;}

     CA_trace_stop();  
     
    S_w2rep("DCOM_final: finalizing DCOM test case with keyword(s) @KEYWORDS...\n");
    
    
    
   
   
   if( grep( /FCM_DEL/i, @KEYWORDS ) ){
   $fltmem1 = PD_GetExtendedFaultInformation();
      PD_ClearFaultMemory();
      CD_clear_DTC();
   }

   if( grep( /ECU_OFF/i, @KEYWORDS ) ){
        DCOM_ecu_off ();
     }
    $count = sprintf("%04d",$TC_cnt );
    $filename = $count."_".$main::CURRENT_TC;
    $filename =~ s/\./\-/g;
    $temp_store_path = "C:\\temp\\$filename"."\.asc";
    print "can trace store path is $temp_store_path\n";
    CA_trace_store($temp_store_path);
    
    $zip_filename = $main::save_name."\\".$filename."\.tgz";   

     $zip_handle = S_open_zip ( $zip_filename );
     S_add_to_zip ( $zip_handle ,  $temp_store_path );
   S_close_zip ( $zip_handle );
    unlink ( $temp_store_path )     || S_set_error( " Couldn't delete old CAN Trace '$temp_store_path'\n" ,21);
    DCOM_delay(3);
    return 1;
}

################################################################################

=head2 DCOM_ecu_on

    DCOM_ecu_on ();

Checks if battery voltage was set before and sets battery voltage
to project default if not. Switches ECU on.

=cut

################################################################################

sub DCOM_ecu_on {

    DCOM_w2html( "Switch On ECU (Ubatt = U_BATT_DEFAULT, IgnOn, Wait for ECU Ready) &5", "T", 'black', "Courier" );
    S_w2rep("Switch On ECU (Ubatt = U_BATT_DEFAULT, IgnOn, Wait for ECU Ready)\n");
    LC_SetVoltage('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    return 1;
}

#####################################################################

=head2 DCOM_ecu_off

    DCOM_ecu_off ();  

Switches ECU off.

=cut

#####################################################################

sub DCOM_ecu_off {

    S_w2rep(" DCOM_ecu_off: switching off ECU ...\n");
    LC_SetVoltage(0);
    S_wait_ms('TIMER_ECU_OFF');
    return 1;
}

#####################################################################

=head2 DCOM_ignition_on

    DCOM_ignition_on ();

Switches Ignition on.

=cut

#####################################################################

sub DCOM_ignition_on {

   return 1;
}

#####################################################################

=head2 DCOM_ignition_off

    DCOM_ignition_off ();

Switches Ignition off.

=cut

#####################################################################

sub DCOM_ignition_off {

   return 1;
}

#####################################################################

=head2 DCOM_clear_DTCs

  clears the DTC.

example : DCOM_clear_DTCs();

=cut

###################################################################

sub DCOM_clear_DTCs
{
  my $request;
  my $response;
  
# DCOM_start_communication(); 
  $request = 'REQ_ClearDTC__ClearDTCAll';
  $response = 'PR_ClearDTC__ClearDTCAll';
  DCOM_request_general($request, $response);
#   DCOM_stop_communication();
  
  return 1;
}

#####################################################################

=head2 DCOM_CA_read_can_signals

    DCOM_CA_read_can_signals ( @CAN_signals_ref , $mode );

=cut

#####################################################################

sub DCOM_CA_read_can_signals {
    my $CAN_signals = shift;
    my $mode = shift;

    my $SignalValue_ref;
    my $unit;
    my $SignalInfo;
    DCOM_w2html("Read + Store CAN Signals\n".join("\n",@$CAN_signals)."&5" , 'T' , "Blue" );
    $unit = "";

    if( $mode eq 'phys')
    {
       foreach my $signal(@$CAN_signals)
       {
        ($SignalValue_ref->{$signal} , $unit) =  CA_read_can_signal( $signal, 'phys');
       }    
    }
    if( $mode eq 'hex')
    {
       foreach my $signal(@$CAN_signals)
       {
        ($SignalValue_ref->{$signal} , $unit) =  CA_read_can_signal( $signal, 'hex');
       }    
    }
#     foreach $signal(@$CAN_signals)
#     {
#          $SignalInfo = CA_get_can_signal_info($signal);
#         ($SignalValue_ref->{$signal} , $unit) = CAN_get_Signal_value( $SignalInfo->{'MESSAGE_INFO'}{'CAN_BUS_NBR'}, $SignalInfo->{'MESSAGE'},$signal);
#     }
    return $SignalValue_ref;
}

#####################################################################

=head2 DCOM_CA_write_can_signals

    DCOM_CA_write_can_signals ( $can_signal_value_hashref , $mode );

=cut

#####################################################################

sub DCOM_CA_write_can_signals {
    my $can_signal_value_hashref = shift;
    my $mode = shift;
    my @CANSignals = keys %$can_signal_value_hashref;
    my $text;
    my $SignalInfo;
    
    if( $mode eq 'phys')
    {
       foreach my $signal(keys %$can_signal_value_hashref)
       {
         CA_write_can_signal( $signal, $can_signal_value_hashref->{$signal}, 'phys');
       }    
    }
    if( $mode eq 'hex')
    {
       foreach my $signal(keys %$can_signal_value_hashref)
       {
        CA_write_can_signal( $signal, $can_signal_value_hashref->{$signal} ,'hex');
       }    
    }
#     foreach $signal(keys %$can_signal_value_hashref)
#     {
#         $text = "$text".$_."->".$can_signal_value_hashref->{$_}."\n";
#         $SignalInfo = CA_get_can_signal_info($signal);
#         CAN_set_Signal_value($SignalInfo->{'MESSAGE_INFO'}{'CAN_BUS_NBR'}, $SignalInfo->{'MESSAGE'},$signal,$can_signal_value_hashref->{$signal} );    
#     }
    DCOM_w2html("Set CAN Signals\n $text &5" , 'T' , "Blue");
#     SC_CA_write_can_signals ( $can_signal_value_hashref , $mode );
    return 1;

}

#####################################################################

=head2 DCOM_CA_disable_messages

    DCOM_CA_disable_messages ( @CAN_messages );

=cut

#####################################################################

sub DCOM_CA_disable_messages{
  my @CAN_messages = @_ ;
  my $MessageInfo;
  DCOM_w2html("Disable CAN Messages\n".join(/"\n"/,@CAN_messages) , "T");
  foreach my $Message(@CAN_messages)
  {
    $MessageInfo = CA_get_can_message_info($Message);
    CAN_set_EnvVar_value($MessageInfo->{'CANOE_DISABLE'} , 0 );
  }
  return 1;
}

#####################################################################

=head2 DCOM_CA_enable_messages

    DCOM_CA_enable_messages ( @CAN_messages );

=cut

#####################################################################

sub DCOM_CA_enable_messages{
  
  my @CAN_messages = @_ ;
  my $MessageInfo;
  DCOM_w2html("Disable CAN Messages\n".join(/"\n"/,@CAN_messages) , "T");
  foreach my $Message(@CAN_messages)
  {
    $MessageInfo = CA_get_can_message_info($Message);
    CAN_set_EnvVar_value($MessageInfo->{'CANOE_DISABLE'} , 1 );
  }
  return 1;
}

#####################################################################

=head2 DCOM_CA_trace_start

    DCOM_CA_trace_start ( );

=cut

#####################################################################

sub DCOM_CA_trace_start{ 

    #configured before with CA_trace_configure() and
    #started with CA_trace_start()
    CA_trace_start();
    
    return 1;
}

#####################################################################

=head2 DCOM_CA_trace_stop

    CAN_trace_file_name = DCOM_CA_trace_stop ( [ $store_file_name ] );
    
Stop CAN trace and store into test documentation with <store_file_name> or default file name
the stored file name will be returned

=cut

#####################################################################

sub DCOM_CA_trace_stop{

     my $store_file_name = shift;
     
    #configured before with CA_trace_configure() and
    #started with CA_trace_start()
    CA_trace_stop();
   $CA_trace_data_file_name = CA_trace_store($store_file_name);
   return $CA_trace_data_file_name;
        
}

################################################################################

=head2 DCOM_set_error

    DCOM_set_error ( [ $ERR_TEXT ] [, $ERR_CODE ] );

Writes an error text containing $ERR_TEXT and $ERR_CODE to STDOUT,
standard logfile and HTML test case report.
Sets system state for the execution engine depending on $ERR_CODE.

=cut

################################################################################

sub DCOM_set_error { 
    my $err_text = shift; #optional
    my $err_code = shift; #optional
    
    S_set_error (  $err_text  ,  $err_code  );
    S_w2rep ("\n");
  return 1;
}

#####################################################################

=head2 DCOM_evaluate_response_bytes

    DCOM_evaluate_response_bytes ( label, response , startbyte , expected_value);

Example:

    DCOM_evaluate_response_bytes();

=cut

#####################################################################�

sub DCOM_evaluate_response_bytes{
  my $LABEL = shift; 
  my $RESPONSE = shift;
  my $STARTBYTE = shift;
  my $EXPECTEDVALUE = shift;
  
  unless(defined $EXPECTEDVALUE)
  {
    DCOM_set_error("DCOM_evaluate_response_bytes: too less parameters ", 110);
    return;
  }
  my(
      @response_bytes,
      @expected_bytes,
      $length,
      $response_length,
      $detected_value,
      $i,
    );
    
   undef $detected_value;
   @expected_bytes = split(/ /,$EXPECTEDVALUE);
   $length = @expected_bytes;
   
   @response_bytes = split(/ /,$RESPONSE);
   $response_length = @response_bytes;

    unless(defined $write_2_inner_table){
      DCOM_w2html( "dummy&5" , "BTI"  );
      my $text = "Signal;Exp;Det;Verdict";
      DCOM_w2html( "$text" , "TI" , "black", "Courier", "Lightpink");
      $write_2_inner_table = 1;
    }

   if($main::opt_offline){
    DCOM_w2html( "$LABEL;$EXPECTEDVALUE;$detected_value;NA" , "TI"  , 'blue' , "Courier" );
    return 1;
    }    
   if($response_length< ($STARTBYTE+$length))
   {
    DCOM_set_error('Response length is not long enough to evaluate' , 103);
    return;
   }
   for($i=$STARTBYTE;$i<$STARTBYTE+$length;$i++)
   {
     unless(defined $detected_value){$detected_value = $response_bytes[$i];next;}
     $detected_value = $detected_value." ".$response_bytes[$i];
   }
   my $current_verdict = EVAL_evaluate_string ( $LABEL , $EXPECTEDVALUE , $detected_value );  

    if( $current_verdict eq VERDICT_PASS){
        DCOM_w2html( "$LABEL;$EXPECTEDVALUE;$detected_value;PASS" , "TI"  , 'green' , "Courier" );    
     }
    else{
        DCOM_w2html( "$LABEL;$EXPECTEDVALUE;$detected_value;FAIL" , "TI"  , 'red' , "Courier" );
    }
   return 1;
}

################################################################################

=head2 DCOM_set_electric_signals

  Set Electrical signals to the value specified
    example for $electrical_signal_value_hashref :
        $electrical_signal_value_hashref = {  'sig1' => '1' ,   # sets sig1 = 1
                                       'sig2' => '2'   # sets sig2 = 2
                                       'sig3' => '3'   # sets sig3 = 3
                                    };


=cut

################################################################################

sub DCOM_set_electric_signals
{
  my $electrical_signal_value_hashref = shift;
  my $value;
  
  my @ElectricSignals = keys %$electrical_signal_value_hashref;
  my $text;
  foreach(keys %$electrical_signal_value_hashref){$text = "$text".$_."->".$electrical_signal_value_hashref->{$_}."\n";}
  DCOM_w2html("Set Electric Signals\n $text &5" , 'T' , "Blue");
  DCOM_w2TestStep("TestStep" , "Set Electrical Signals $text");
  foreach my $signal(keys %$electrical_signal_value_hashref)
  {
    $value = $electrical_signal_value_hashref->{$signal};
      MLC_SetResistance($signal, $value);
      DCOM_delay( 2 , 'Wait 2s');

  }
  return 1;
}

################################################################################

=head2 DCOM_reset_electric_signals


  Reset Electrical signals to the normal value
  DCOM_reset_electric_signals($electrical_signals_ref)

=cut

################################################################################

sub DCOM_reset_electric_signals
{
  my $electrical_signals_ref = shift;
  
  DCOM_w2html("Reset Electric Signals\n".join("\n",@$electrical_signals_ref)."&5" , 'T' , "Blue" );
  MLC_UndoShortLine();
  return 1;
}

#####################################################################

=head2 DCOM_set_target_speed

    DCOM_set_target_speed ( $SPEED  );

Accelerates or decelerates simulator vehicle to given $SPEED.
See EXT_goto_target_speed for more details.

=cut

#####################################################################

sub DCOM_set_target_speed {
   my $speed = shift;

   S_w2rep( " SC_set_target_speed: set model target speed $speed... and dont wait\n");
   if( @{$GENERIC_Testbench->{'Functions'}{'Simulator'}{'general'}}[0] eq 'LabCar')
   {
   }
   else
   {
      CAN_set_EnvVar_value($ProjectDefaults->{'CANSignalMapping'}{'VehicleSpeed'}{'Signal'} , $speed /0.01 );
   }

   return 1;
}

#####################################################################

=head2 DCOM_goto_target_speed

    DCOM_goto_target_speed ( $SPEED [, $MUE [, $TIMEOUT ]] );

Accelerates or decelerates simulator vehicle to given $SPEED in km/h.
See EXT_goto_target_speed for more details.

=cut

#####################################################################

sub DCOM_goto_target_speed {

   my @params = @_;

   return 1;
}

#####################################################################

=head2 DCOM_set_wheel_speeds_kmh

    DCOM_set_wheel_speeds_kmh (  $SPEED_FL [, $SPEED_FR , $SPEED_RL , $SPEED_RR ] );

=cut

#####################################################################

sub DCOM_set_wheel_speeds_kmh {

   my @params = @_;
   my $ErrorText;
   my @wheels = ("WheelSpeedFL", "WheelSpeedFR", "WheelSpeedRL", "WheelSpeedRR");
   my $i;   
    for($i=0;$i<4;$i++)
    {
      $ErrorText = "ProjectDefaults->CANSignalMapping->$wheels[$i] not defined ";
      print "here --- $ProjectDefaults->{'CANSignalMapping'}{$wheels[$i]}\n";
      if( defined $params[$i] & ( !defined $ProjectDefaults->{'CANSignalMapping'}{$wheels[$i]}{'Signal'} | ( $ProjectDefaults->{'CANSignalMapping'}{$wheels[$i]}{'Signal'} eq '')))
      { 
       DCOM_set_error($ErrorText,20);
       return;
      }
      if(defined $params[$i] )
      { 
        DCOM_comment('s', "Setting $ProjectDefaults->{'CANSignalMapping'}{$wheels[$i]} = $params[$i] kmph");
        CAN_set_EnvVar_value($ProjectDefaults->{'CANSignalMapping'}{$wheels[$i]}{'Signal'} , $params[$i] );
      }
    }
    return 1;
}

#####################################################################

=head2 DCOM_reset_wheel_speeds_kmh

    DCOM_reset_wheel_speeds_kmh ( );

    Resets the simulator vehicle's speed back to a given value or default speed.
    Note : User has to write a Function and save in DCOM_user_functions.pm    

=cut

#####################################################################

sub DCOM_reset_wheel_speeds_kmh {

    print "User Function should be Developed\n";
    # function to be used is GDCOM_call_user_function.
   return 1;
}

#####################################################################

=head2 DCOM_set_Engine_speed

    DCOM_set_Engine_speed 

=cut

#####################################################################

sub DCOM_set_Engine_speed {
   my $speed = shift;
   my $ErrorText = "ProjectDefaults->CANSignalMapping->EngineSpeed not defined ";

  if( !defined $ProjectDefaults->{'CANSignalMapping'}{'EngineSpeed'} | ( $ProjectDefaults->{'CANSignalMapping'}{'EngineSpeed'} eq ''))
  { 
    DCOM_set_error($ErrorText,20);
    return;
  }
  if(defined $speed)
  {  
    DCOM_comment('s', "Setting $ProjectDefaults->{'CANSignalMapping'}{'EngineSpeed'} = $speed rpm");
    CAN_set_EnvVar_value($ProjectDefaults->{'CANSignalMapping'}{'EngineSpeed'} , $speed );
  }
   return 1;
}

#####################################################################

=head2 DCOM_reset_Engine_speed

    DCOM_reset_Engine_speed 
    Note : User has to write a Function and save in DCOM_user_functions.pm    

=cut

#####################################################################

sub DCOM_reset_Engine_speed {

    print "User Function should be Developed\n";
    # function to be used is GDCOM_call_user_function.

   return 1;
}

################################################################################

=head2 DCOM_ecu_reset

  Function to Reset ECU
  
  For Hard or soft reset, $reset_type = DCOM_HardReset or DCOM_SoftReset
  
  For reset through Ubatt, $reset_type = Ubatt
  
  For reset through Ignition On off without sleep, $reset_type = IgnOnOff_WithoutSleep
  
  For reset through Ignition on off with sleep, $reset_type = IgnOnOff_WithSleep

=cut

################################################################################

sub DCOM_ecu_reset {
    my $reset_type = shift;
    my $request;
    my $response;

    if ( $reset_type eq "IgnOnOff_WithoutSleep" ) {
        DCOM_comment( 's', "Reset ECU type $reset_type" );
        DCOM_w2TestStep( "TestStep", "IgnitionOff, NoWait, IgnitionOn" );
        DCOM_ignition_off();
        DCOM_ignition_on();
    }
    elsif ( $reset_type eq "IgnOnOff_WithSleep" ) {
        DCOM_comment( 's', "Reset ECU type $reset_type" );
        DCOM_w2TestStep( "TestStep", "IgnitionOff, Wait 3s, IgnitionOn" );
        DCOM_ignition_off();
        DCOM_wait_ms('TIMER_ECU_OFF');
        DCOM_ignition_on();
    }
    elsif ( $reset_type eq "Ubatt" ) {
        DCOM_comment( 's', "Reset ECU type $reset_type" );
        DCOM_w2TestStep( "TestStep", "Set IgnitionOff, Ubatt=0, Wait 3sec" );

        # Perform Ubat reset
        DCOM_comment( 's', "Set Ubatt = 0" );
        LC_SetVoltage(0);
        DCOM_delay( '3', "Wait 3s for Reset" );
        DCOM_w2TestStep( "TestStep", "Set Ubatt=Default, IgnitionOn, Wait 3sec" );
        DCOM_comment( 's', "Set Ubatt = U_BATT_DEFAULT" );
        LC_SetVoltage('U_BATT_DEFAULT');
    }
    elsif ( $reset_type =~ /^DCOM/ ) {
        $reset_type =~ s/^DCOM/ECUReset/;
        DCOM_w2TestStep( "comment", "Reset ECU type $reset_type" );

        #Send Request to reset the ECU (Soft Reset)
        #---------------
        $request  = "REQ_" . $reset_type;
        $response = "PR_" . $reset_type;
        DCOM_request_general( $request, $response );
        DCOM_wait_ms('TIMER_ECU_OFF');
    }

    return 1;

}

#####################################################################

=head2 DCOM_manipulate_lines

    DCOM_manipulate_lines($ManipulatioType, $ListofLines_ref )
    $ManipulatioType - Only allowed types are 
                          'interrupt' 
                          'short'          # only two lines possible in LIFT?
                          'undo_interrupt'
                          'undo_short'

=cut

#####################################################################

sub DCOM_manipulate_lines
{
  my $ManipulatioType = shift;
  my $ListofLines_ref = shift;
  my $Time_duration = shift;
  
  unless(defined $ListofLines_ref)
  {
      S_set_error( " too less parameters ! SYNTAX: DCOM_manipulate_lines('TypeOfManipulation' , 'ListofLines' );", 110 );
      S_w2rep ("\n");
      return 0;  
  }
  if( $ManipulatioType eq 'interrupt' )
  {
    DCOM_w2TestStep("TestStep" , "Interrupt Lines (".join(' , ',  @$ListofLines_ref).")");
    DCOM_w2html("Interrupt Lines (".join(' , ',  @$ListofLines_ref).")&5" , "T", 'magenta', "Courier" );
     if($main::opt_offline){ return 1;}
      foreach(@$ListofLines_ref)
      {
        MLC_DisconnectLine($_);
      }
  }
  elsif($ManipulatioType eq 'short' )
  {
      DCOM_w2TestStep("TestStep" , "Short Lines (".join(' , ',  @$ListofLines_ref).")");
    DCOM_w2html("Short Lines (".join(' , ',  @$ListofLines_ref).")&5" , "T", 'magenta', "Courier" );
    if($main::opt_offline){ return 1;}
      MLC_ShortLine(@$ListofLines_ref[0],@$ListofLines_ref[1]); 
  }
  elsif($ManipulatioType eq 'undo_interrupt' )
  {
    DCOM_w2TestStep("TestStep" , "Undo Interrupt of Lines (".join(' , ',  @$ListofLines_ref).")");
    DCOM_w2html("Undo Interrupt Lines (".join(' , ',  @$ListofLines_ref).")&5" , "T", 'magenta', "Courier" );
    if($main::opt_offline){ return 1;}
      foreach(@$ListofLines_ref)
      {
        MLC_ReconnectLine($_);
      }   
  }  
  elsif($ManipulatioType eq 'undo_short' )
  {
    DCOM_w2TestStep("TestStep" , "Undo Short of Lines (".join(' , ',  @$ListofLines_ref).")");
    DCOM_w2html("Undo Short Lines (".join(' , ',  @$ListofLines_ref).")&5" , "T", 'magenta', "Courier" );
    if($main::opt_offline){ return 1;}   
      MLC_UndoShortLine();    
  }
  else
  {
      S_set_error( " Type of manipulation is not correct (interrupt, short, undo_interrupt, undo_short are only allowed)", 110 );
      DCOM_w2html("Type of manipulation is not correct&5" , "T", 'magenta', "Courier" );
      S_w2rep ("\n");
      return 0;    
  }  
}

################################################################################

=head2 DCOM_w2TestStep

  Function to write to Test Step
  
example : DCOM_w2TestStep($TestStepType, $TestStep, [ $ExpectedResult ]);

    $TestStepType = 'Heading'  -> Heading of a section (No Test Step Number assigned)
    $TestStepType = 'TestStep' -> TestStep (TestStep and Expected Result )  
    $TestStepType = 'Comment'  -> Generic Comment 

=cut

################################################################################

sub DCOM_w2TestStep
{    
    my $TestStepType = shift; 
    my $TestStep = shift; 
    my $ExpectedResult = shift;
    unless(defined $ExpectedResult){$ExpectedResult = "-";}
    
    if($TestStepType eq 'Heading') 
    {
          S_add2eval_collection( 'Test Specification', $TestStep );
          S_add2eval_collection( 'Expected Result', $TestStep );
        $TestStepNumber = 1;
    }
    if($TestStepType eq 'TestStep') 
    {
        $TestStepNumber = sprintf( "%02d" ,$TestStepNumber);
        S_add2eval_collection( 'Test Specification', "   (".$TestStepNumber.") ".$TestStep );
        S_add2eval_collection( 'Expected Result', "   (".$TestStepNumber.") ".$ExpectedResult );
        $TestStepNumber++;
    }
     if($TestStepType eq 'Comment') 
    {
        S_add2eval_collection( 'Test Specification', $TestStep );
        S_add2eval_collection( 'Expected Result', $TestStep );        
    }
       
    return 1;
}

################################################################################

=head2 DCOM_set_addressing_mode

  this function sets the addresssing mode of the service to either 'Physical', 'Functional' or  'disposal'.
  
  
example : DCOM_set_addressing_mode($address_mode);  

=cut

################################################################################

sub DCOM_set_addressing_mode
{  
   my $address_mode = shift;
   my ($ResponseID, $Timeout);
   ($RequestID, $FlowControlID, $ResponseID, $Timeout,$P3_mintime_value) = CD_set_addressing_mode ($address_mode);  
   # ($RequestID,$FlowControlID) = CD_set_addressing_mode ($address_mode);  
   return 1;
     
}
################################################################################

=head2 CA_get_can_signal_info

 can_signal_info = CA_get_can_signal_info ( CAN_signal_name );

is a hash reference containing the signal info from STEPS CAN Mapping module plus the message info


               'SIGNAL_NAME'   => 'MO2_Fzg_kmh',      
               'CANOE_ENV_VAR' => 'EnvMO2_Fzg_kmh',
               'SENDER'        => 'Otto',
               'MESSAGE'       => 'Motor_2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 24, 
               'LENGTH'        => 8, 
               'OFFSET'        => 0.000000, 
               'FACTOR'        => 1.280000,
               'FORMAT'        => 'INTEL', 
               'TYPE'          => 'UNSIGNED', 
               'UNIT'          => 'km/h',
               'LC_READ_PHYS'  => 'MO2_Fzg_kmh.Motor_2.CAN_engine', 
               'LC_WRITE_PHYS' => 'MO2_Fzg_kmh.Motor_2.CAN_engine', 
               'LC_MODEL_CTRL' => 0, 
               'LC_EDIT_BYTES' => { 3 => '0b11111111' }, 
               'MESSAGE_INFO'  => {
                           'ID'          => 648,
                           'DLC'         => 8,
                           'SENDER'      => 'Otto',
                           'CAN_BUS_NBR' => 1,
                           'CYCLE'       => 10,
                           'LC_CONTROL'  => 'Motor_2_USED.Motor_2.CAN_engine',
                           'LC_DLC'      => 'Motor_2_DLC.Motor_2.CAN_engine',
                                   }

=cut

######################################################

sub CA_get_can_signal_info
{
   my ( $can_signal_name ) = shift @_ ;

   my $returned_sig_info; my $message; 

   unless( defined $can_signal_name ) {
      S_set_error( " SYNTAX: CA_get_can_signal_info( $can_signal_name )", 110 );
      return;
   }

   unless( $returned_sig_info = $GENERIC_CAN_mapping->{ $can_signal_name } ) {
      S_set_error( " LIFT CanMapping doesnt contain info for signal : '$can_signal_name'", 0 );
      return;
   }

   unless( $message = $returned_sig_info->{'MESSAGE'} ) {
      S_set_error( " LIFT CanMapping doesnt contain 'MESSAGE' for signal : '$can_signal_name'", 0 );
      return;
   }
   
   unless( $returned_sig_info->{'MESSAGE_INFO'} = $GENERIC_CAN_mapping->{'CAN_MESSAGES'}{$message} ) {
      S_set_error( " LIFT CanMapping doesnt contain 'CAN_MESSAGES' info for message 'MESSAGE' for signal : '$message'", 0 );
      return;
   }

   return $returned_sig_info;
}

######################################################

=head2 CA_get_can_message_info

 can_message_info = CA_get_can_message_info ( can_message_name );

is a hash reference containing the message info from STEPS CAN Mapping module 


                  'ID'          => 648,
                  'DLC'         => 8,
                  'SENDER'      => 'Otto',
                  'CAN_BUS_NBR' => 1,
                  'CYCLE'       => 10,
                  'LC_CONTROL'  => 'Motor_2_USED.Motor_2.CAN_engine',
                  'LC_DLC'      => 'Motor_2_DLC.Motor_2.CAN_engine',
                  'CAN_SIGNALS' => [ SIGNAL1 , SIGNAL2 , ... ]

=cut

######################################################

sub CA_get_can_message_info
{
   my ( $can_message_name ) = shift @_ ;

   my $returned_msg_info; my @signals;

   unless( defined $can_message_name ) {
      S_set_error( " SYNTAX: CA_get_can_message_info( $can_message_name )", 110 );
      return;
   }

   unless( $returned_msg_info = $GENERIC_CAN_mapping->{ 'CAN_MESSAGES' }{ $can_message_name } ) {
      S_set_error( " LIFT CanMapping doesnt contain info for message : '$can_message_name'", 20 );
      return;
   }

   foreach my $signal ( keys %$GENERIC_CAN_mapping ) {
      next unless "HASH" eq ref $GENERIC_CAN_mapping->{$signal};
      push( @signals , $signal ) if $can_message_name eq $GENERIC_CAN_mapping->{$signal}{'MESSAGE'};
   }
   
   $returned_msg_info->{'CAN_SIGNALS'} = \@signals;

   return $returned_msg_info;
}

#####################################################################

=head2 DCOM_set_Ubatt

    DCOM_set_Ubatt ( BatteryVoltage );

Set Battery Voltage

=cut

#####################################################################

sub DCOM_set_Ubatt {

    my $u_batt_given = shift;
    LC_SetVoltage($u_batt_given);
}

#####################################################################

=head2 DCOM_set_verdict

    DCOM_set_verdict ( verdict );

Set Testcase verdict

=cut

#####################################################################

sub DCOM_set_verdict {

    my $verdict = shift;
    return( S_set_verdict($verdict));
}

#####################################################################

=head2 DCOM_reset_speed

    DCOM_reset_speed ( ); 
 resets the simulator vehicle speed to Zero .

=cut

#####################################################################

sub DCOM_reset_speed {

   S_w2rep( " resetting the speed back to Zero\n");
#    LC_set_target_speed ( @params );
  CAN_set_EnvVar_value('Signal_ESP_v_Signal' , 0 );

   return 1;
}

################################################################################

=head2 DCOM_start_CyclicTesterPresent

  send the TesterPresent request continuosly.
  input parameters $msg_aref, $msgID,$cycle are optional. If not defined , then they are read from Project Defaults.
  
  Project Defaults : 'CUSTOMER_DIAGNOSIS' =   {
                                                'RequestID_functional' => '0x700', #as hex string     
                                                'CAN_TesterPresent_Req' =>[0x02,0x3E,0x80,0x00,0x00,0x00,0x00,0x00], #do not add DLC in the request
                                                'CAN_TesterPresent_Time' => 4000,   # cyclic TP cycle time is milli sec   
                                              }        

example : DCOM_start_CyclicTesterPresent($msg_aref, $msgID,$cycle);  

=cut

################################################################################



sub DCOM_start_CyclicTesterPresent
{
    my $msg_aref = shift;
       my $msgID = shift;
    my $cycle = shift;

    unless(defined $msg_aref) 
    { 
        $msg_aref = $ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'CAN_TesterPresent_Req'};
        DCOM_comment('s',"DCOM_start_CyclicTesterPresent : msg_aref read from Project Defaults");
    }

    unless(defined $msgID) 
    {
        $msgID = $ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'RequestID_functional'};
        DCOM_comment('s',"DCOM_start_CyclicTesterPresent : msgID read from Project Defaults");
    }
    
       unless(defined $cycle) 
    {
        $cycle = $ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'CAN_TesterPresent_Time'};
        DCOM_comment('s',"DCOM_start_CyclicTesterPresent : cycle read from Project Defaults");
    }
       
       DCOM_comment('s',"DCOM_start_CyclicTesterPresent parameters : $msg_aref , $msgID, $cycle, $P3_mintime_value ");
    DCOM_comment('s'," start cyclic TestPresent");
   my $TP_handle = DCOM_start_CyclicMessage($msg_aref, $msgID,$cycle,$P3_mintime_value);
   # DCOM_comment('s',"message handle DCOM_start_CyclicTesterPresent -  $TP_handle");    
    return $TP_handle;
}


################################################################################

=head2 DCOM_start_CyclicMessage
  
  send the any message request continuosly.
  
example : DCOM_start_CyclicMessage($msg_aref,$msgID,$cycle);  

=cut

################################################################################


sub DCOM_start_CyclicMessage
{
    my $msg_aref = shift;
    my $msgID = shift;
    my $cycle = shift;
    
   unless(defined($msg_aref)){
    S_set_error("Too less parameters. 'Array Reference' not found.!! Syntax: DCOM_start_CyclicMessage(msg_aref,msgID,cycle) ",110);
    return 0;
    
   }
   unless(defined($cycle)){
    S_set_error("Too less parameters. 'cycleTime' not found.!! DCOM_start_CyclicMessage(msg_aref,msgID,cycle)", 110);
    return 0;
    
   }

   unless(defined($msgID)){
    S_set_error("Too less parameters. 'Msg ID' not found.!! DCOM_start_CyclicMessage(msg_aref,msgID,cycle)", 110);
    return 0;
    
   }

    DCOM_comment('s',"DCOM_start_CyclicMessage parameters : $msg_aref , $msgID, $cycle ");
    DCOM_comment('s'," start cyclic message");
    my $MSG_handle = CD_send_message( $msg_aref, $msgID,$cycle);
    return $MSG_handle;
}




################################################################################

=head2 DCOM_stop_CyclicTesterPresent

  stop the sending of TesterPresent request continuously.
  
example : DCOM_stop_CyclicTesterPresent();  

=cut

################################################################################

sub DCOM_stop_CyclicTesterPresent
{
  my $status;
  my $handle = shift;
  
    unless (defined $handle)
    {
        S_set_error("Too Less Parameters! SYNTAX: DCOM_stop_CyclicTesterPresent( $handle)" , 110 );
        return;
    }
  DCOM_comment('s',"stop cyclic TestPresent");
  $status = DCOM_stop_CyclicMessage($handle);

  return $status;
}



################################################################################

=head2 DCOM_stop_CyclicMessage

  stop the sending of cyclic message continuously.
  This function will stop the message that is been sent continuously by DCOM_start_CyclicMessage function. 
  It takes the message handler returned by DCOM_start_CyclicMessage internally and stops the message.
  
example : DCOM_stop_CyclicMessage();  

=cut

################################################################################

sub DCOM_stop_CyclicMessage
{
  my $status;
  my $handle = shift;
  unless(defined $handle)
  {
    S_set_error( " too less parameters ! SYNTAX: DCOM_stop_CyclicMessage( $handle)", 110 );
    return 0;
   }
  DCOM_comment('s',"stop cyclic message");
  $status = CD_stop_message( $handle );
  return $status;
}


################################################################################

=head2 DCOM_CAN_SendMessage

  Sends a CAN message cyclically for the given cycle_time(ms).
  
example : $MSG_handle= DCOM_CAN_SendMessage($CANrequest, $requestID, $cycle_time [,$comment]);  

=cut

################################################################################

sub DCOM_CAN_SendMessage
{
    my $CANrequest_aref=shift;
    my $requestID = shift;
    my $cycle_time = shift;
    my $comment=shift;
    my $MSG_handle;
     
    $MSG_handle = CD_send_message( $CANrequest_aref, $requestID, $cycle_time);
    return 1;
}

################################################################################

=head2 DCOM_read_and_eval_fcm_rb

Reads RB fault memory, compares the contents with given parameters and sets a verdict.
See PD_evaluate_faults for more details about mandatory, optional and disjunction faults.  

example : $Verdict = DCOM_read_and_eval_fcm_rb($RB_mandatory_faults_aref, $RB_optional_faults_aref, $RB_disjunction_faults_aref);  

=cut

################################################################################

sub DCOM_read_and_eval_fcm_rb
{
    my $RB_mandatory_faults_aref = shift; 
    my $RB_optional_faults_aref = shift;
    my $RB_disjunction_faults_aref = shift;          
    my $Verdict;
    my $flt_mem_struct;
    unless ( defined $RB_mandatory_faults_aref ) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_read_and_eval_fcm_rb( $RB_mandatory_faults_aref)", 110 );
        return 0;
    }
         
    if ($$RB_mandatory_faults_aref[0] eq "NoFault")
    {
      if($main::opt_offline){return 1; }    
      $flt_mem_struct = PD_GetExtendedFaultInformation();         
      $Verdict = PD_evaluate_faults( $flt_mem_struct, [] );
    }
    else 
    { 
      if($main::opt_offline){return 1; }
      $flt_mem_struct = PD_GetExtendedFaultInformation();             
      $Verdict = PD_evaluate_faults( $flt_mem_struct, $RB_mandatory_faults_aref, $RB_optional_faults_aref, $RB_disjunction_faults_aref ); 
      return $Verdict;
    }                        
}
################################################################################

=head2 DCOM_read_and_eval_fcm_cu

Reads customer fault memory, compares the contents with given parameters and sets a verdict.
See CD_evaluate_faults for more details about mandatory, optional and disjunction faults.  

example : $Verdict = DCOM_read_and_eval_fcm_cu($CU_mandatory_faults_aref, $optional_faults_aref, $disjunction_faults_aref);  

=cut

################################################################################

sub DCOM_read_and_eval_fcm_cu
{
    my $CU_mandatory_faults_aref = shift;   
    my $CU_optional_faults_aref = shift;
    my $CU_disjunction_faults_aref = shift;
    my $ReadDTC_subfunction = shift;
    my $dtc_status_mask = shift;
    my $Verdict;
    my $detected_DTC;
  DCOM_w2TestStep("Comment" , "\n Read and evaluate FCM for Customer \n");
  if($main::opt_offline){return 1; }
    
    $detected_DTC = DCOM_get_DTC( $ReadDTC_subfunction , $dtc_status_mask);
    DCOM_evaluate_fault_words( 'CU' , $detected_DTC , $CU_mandatory_faults_aref , $CU_optional_faults_aref , $CU_disjunction_faults_aref );
    return 1;
}

################################################################################

=head2 DCOM_read_and_eval_DTCStatusBits
  
example : DCOM_read_and_eval_DTCStatusBits();  

=cut

################################################################################
sub DCOM_read_and_eval_DTCStatusBits
{
  my $expected_DTCStatusBits = shift;
  my (
        $DTCStatusBits,
        $detected_DTC,
      );

  DCOM_w2TestStep("Comment" , "\n Read and evaluate DTC Status Bits \n");
  if($main::opt_offline){return 1; }
  
  $detected_DTC  = CD_read_DTC(0x02,0x89);
  foreach my $fault_name(keys %$expected_DTCStatusBits)
  {
    CD_check_fault_status( $detected_DTC, $fault_name, $expected_DTCStatusBits->{$fault_name} & $ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTC_SAM'});   
  }
# Through PD Diag
  foreach my $fault_name(keys %$expected_DTCStatusBits)
  {
    PD_ReadFaultMemory(); 
    $DTCStatusBits = PD_getISOfaultbits($fault_name);
    $DTCStatusBits = S_0x2dec($DTCStatusBits);
    LIFT_evaluation::EVAL_evaluate_value ( $fault_name, $DTCStatusBits, '==' , S_0x2dec($expected_DTCStatusBits->{$fault_name}) & 127 );
  }    
  return 1;
}

################################################################################

=head2 DCOM_read_and_eval_FaultStatusBits
  
example : DCOM_read_and_eval_FaultStatusBits();  

=cut

################################################################################
sub DCOM_read_and_eval_FaultStatusBits
{
  my $expected_FaultStatusBits = shift;
  my $Fault_struct;
   $Fault_struct = PD_ReadFaultMemory();
   
    DCOM_w2TestStep("Comment" , "\n Read and evaluate Fault Status Bits \n");
    if($main::opt_offline){return 1; }   
   foreach my $fault_name(keys %$expected_FaultStatusBits)
   {
     PD_check_fault_status( $Fault_struct, $fault_name, $expected_FaultStatusBits->{$fault_name} );   
   }
}
###################################################################

=head2 DCOM_wait_ms

    DCOM_wait_ms ( $WAIT_TIME );

Pauses the system for $WAIT_TIME milliseconds.
$WAIT_TIME can be either a number
or a symbolic name that is defined in $main::ProjectDefaults->{'TIMER'}.
$WAIT_TIME must be greater than 0 !
Note that STEPS is not a realtime system, so the accuracy and the
smallest possible value of wait time will depend on the
system on which STEPS is running.

=cut

###################################################################
sub DCOM_wait_ms {
  my $WAIT_TIME = shift;
  S_wait_ms( $WAIT_TIME );
  return 1;
}

#####################################################################

=head2 DCOM_set_timer_zero

    DCOM_set_timer_zero ( [ $TIMER_NAME ] );
    
Sets the scheduler timer with the name $TIMER_NAME to zero.
This is a precondition for using the function DCOM_wait_ms_until and DCOM_read_timer.
If no $TIMER_NAME is given then the default timer ('timer_default') is set to zero.

=cut

#####################################################################
sub DCOM_set_timer_zero {

   my $timer_name = shift;
   
   unless( defined( $timer_name ) ){
      $timer_name = 'timer_default';
   }

   S_w2rep("DCOM_set_timer_zero: setting scheduler timer '$timer_name' to zero...\n");
   my $time_zero = Win32::GetTickCount();
   
   $timer_ref ->{ $timer_name } = $time_zero;
   
   return 1;
}



#####################################################################

=head2 DCOM_wait_ms_until

    DCOM_wait_ms_until ( $TIME_VALUE , [ $TIMER_NAME ] );
    
Waits until $TIME_VALUE ms have passed after having set the timer $TIMER_NAME
to zero (by using the function DCOM_set_timer_zero).
If no $TIMER_NAME is given then the default timer ('timer_default') is used.
If $TIME_VALUE ms have already passed when calling this function then a warning
is given and no wait is performed.

This function shall be used to synchronize stimuli sets with other manipulations
or measurements (e.g. line manipulations, reading of lamps).

=cut

#####################################################################
sub DCOM_wait_ms_until {

   my $time_value = shift;
   my $timer_name = shift;

   unless( defined( $timer_name ) ){
      $timer_name = 'timer_default';
   }

   S_w2rep("DCOM_wait_ms_until: waiting until scheduled time $time_value is reached for timer '$timer_name'...\n");

   unless( $timer_ref ->{ $timer_name } > 0 ){
      S_set_error( " Timer '$timer_name' has not been set to zero before. Please use DCOM_set_timer_zero before.", 114 );
      return 0;
   }

   my $T_now = Win32::GetTickCount();
   my $wait_time = $time_value - ( $T_now - $timer_ref ->{ $timer_name } );

   if( $wait_time > 0 ){
      S_wait_ms( $wait_time );
  }
   elsif( $wait_time < 0 ){
      $wait_time *= -1;
      S_set_error( "No wait because we are $wait_time after scheduled time", 0 );
   }
   else{
      # nothing to do
   }
   
   return 1;
}


#####################################################################

=head2 DCOM_read_timer

    $time = DCOM_read_timer ( [ $TIMER_NAME ] );

Returns runtime of $TIMER_NAME after having set the timer $TIMER_NAME
to zero (by using the function DCOM_set_timer_zero).
If no $TIMER_NAME is given then the default timer ('timer_default') is used.

=cut

#####################################################################
sub DCOM_read_timer {

   my $timer_name = shift;

   unless( defined( $timer_name ) ){
      $timer_name = 'timer_default';
   }

   unless( $timer_ref ->{ $timer_name } > 0 ){
      S_set_error( " Timer '$timer_name' has not been set to zero before. Please use DCOM_set_timer_zero before.", 114 );
      return 0;
   }

   my $T_now = Win32::GetTickCount();
   my $time = ( $T_now - $timer_ref ->{ $timer_name } );
   
   return $time;
}
  
#####################################################################

=head2 DCOM_clear_all_fcm

       DCOM_clear_all_fcm ();
       Deletes RB and customer (if configured) fault memory.

=cut

#####################################################################
sub DCOM_clear_all_fcm
{

    return 1;
}  

######################################################

=head2 DCOM_get_DTC

    %FAULTS = DCOM_get_DTC ();


=cut

######################################################
sub DCOM_get_DTC{
    my $subfunction = shift;
    my $statusmask  = shift;
    my $detected_DTC;
    
    DCOM_w2TestStep("Comment" , "\n Read DTC value for  $subfunction with $statusmask \n");

    if($main::opt_offline){return 1; } 
    unless( defined $subfunction ){ $subfunction = 0x02; $statusmask = 0x08; }
    $detected_DTC = CD_read_DTC($subfunction, $statusmask );       
    return $detected_DTC;
}

######################################################

=head2 DCOM_evaluate_fault_words

    VERDICT = DCOM_evaluate_fault_words( "RB|CU" ,
                                         \%detected_faults ,
                                         \@mandatory_faults,
                                    [    \@optional_faults, ]
                                    [    \@disjunction_faults, ]
                                        );

=cut

######################################################

sub DCOM_evaluate_fault_words
{
    my $fault_type = shift;
    my $detected_DTC = shift;
    my $mandatory_faults_aref = shift;   
    my $optional_faults_aref = shift;
    my $disjunction_faults_aref = shift;
    my $Verdict;

    unless ( defined $mandatory_faults_aref ) {
        S_set_error( " too less parameters ! SYNTAX: DCOM_read_and_eval_fcm_xx( $mandatory_faults_aref)", 110 );
        return 0;
    }
    if( $fault_type eq "CU")
    {
      if ($$mandatory_faults_aref[0] eq "NoFault")
      {
        DCOM_w2TestStep("Comment" , "\n Read and Evaluate Customer Fault Memory for NO FAULT\n");    
        if($main::opt_offline){return 1; }  
        $Verdict      = CD_evaluate_faults( $detected_DTC, [] );    
      }
      else 
      {
        DCOM_w2TestStep("Comment" , "\n Read and Evaluate Customer Fault Memory for CU_mandatory_faults\n");
        if($main::opt_offline){return 1; } 
        $Verdict      = CD_evaluate_faults( $detected_DTC, $mandatory_faults_aref,$optional_faults_aref, $disjunction_faults_aref ); 
        DCOM_comment ('s',"evalution is over");      
        return $Verdict;             
      }
    }     
}

#####################################################################

=head2 DCOM_read_and_eval_DTCExtDataRecbyDTCNum

    DCOM_read_and_eval_DTCExtDataRecbyDTCNum ( $DTCExtDataRecbyDTCNum_expected , $fault_name , [ $DTCExtDataRecordNumber , $eval_mode] );
    Read and evaluate DTC Extended Data Record by DTC Number

=cut

#####################################################################
sub DCOM_read_and_eval_DTCExtDataRecbyDTCNum
{
  my $DTCExtDataRecbyDTCNum_expected = shift;
  my $fault_name                     = shift;
  my $DTCExtDataRecordNumber         = shift;
  my $eval_mode                      = shift;
  my ($request, $response, $detected_response, $label_value, @bytes, $expected_value, 
      $bytes_per_DTC, $DTC, $record_name, $found,
      $tolerance,
     );
     
  my $DTCExtDataRecbyDTCNum_detected;
  my $ExtDataRecConfig = $GENERIC_DiagMapping->{'ReadDTCInformation_service_config'}{'DTCExtendedDataRecordByDTCNumber'};
  
#   $DTC = $GENERIC_ProjectDefaults->{'CU_ERRORS'}{$fault_name};
  $DTC = DCOM_get_FaultValue_from_mapping($fault_name, 'CU');
  $DTC = join(' ',$DTC =~ /..?/sg); #split it into 2chars and then join with spaces
  
  unless(defined $DTCExtDataRecordNumber ){ 
    $DTCExtDataRecordNumber = 'FF';
  }
  unless(defined $eval_mode ){ 
    $eval_mode = 'phys';
  }
  $bytes_per_DTC = $LIFT_config::LIFT_ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}->{'DTCbytes'}; 
  
  unless(defined $bytes_per_DTC )
  { 
        S_set_error( "'DTCbytes' are not defined in Diagamapping under 'CUSTOMER_DIAGNOSIS'", 20 );
      return 0;
  }

  $label_value->{'DTCExtDataRecordNumber'} = $DTCExtDataRecordNumber;
  $label_value->{'DTC'} = $DTC;
  $request  = "REQ_ReadDTC_reportDTCExtendedDataRecordByDTCNumber";
  $response = "PR_ReadDTC_reportDTCExtendedDataRecordByDTCNumber";
  $detected_response = DCOM_request_general($request,$response, $label_value);

  @bytes = split(/ /, $detected_response );
  # remove header bytes from response message (2bytes for 59 06, bytes per dtc and 1 byte of Status)
   splice(@bytes, 0, 2+$bytes_per_DTC+1);# changed by pyi2kor
    
  while( scalar(@bytes) > 0)
  {
    my $record_number = splice(@bytes, 0,1 ); #get the first recordnumber
    unless(defined $ExtDataRecConfig->{$record_number}){
      S_set_error( "DCOM_read_and_eval_DTCExtDataRecbyDTCNum: Record Number $record_number '$record_number' not found in ReadDTCInformation_service_config ", 110 );
      last;
    }    
    $record_name = $ExtDataRecConfig->{$record_number}{'Name'};
    $DTCExtDataRecbyDTCNum_detected->{$record_name} = join(' ',splice(@bytes, 0,$ExtDataRecConfig->{$record_number}{'NumberofBytes'} ));
  }
  if($eval_mode =~ /phys/i ){
    foreach my $data_label( keys %$DTCExtDataRecbyDTCNum_expected ){
      undef $found;
      foreach my $record_name(keys %$DTCExtDataRecbyDTCNum_detected ){
        if( grep( /$data_label/i, keys %{$GENERIC_DiagMapping->{'Response_Phys2Hex'}{$record_name}} ) ){
            $expected_value = $DTCExtDataRecbyDTCNum_expected->{$data_label}; 
            S_w2rep("Evaluating $data_label under $record_name\n");
            if ( $expected_value =~ /([+-]?\s*\w+\.?\d*)\s*%\s*(\d+\.?\d*)/i )
            {
                $expected_value = $1; $tolerance = $2;
                DCOM_w2TestStep("TestStep" , "Eval: $data_label = $expected_value (tolerance - $tolerance %)" );
                DCOM_evaluate_phys($DTCExtDataRecbyDTCNum_detected->{$record_name},$data_label,$expected_value,$record_name, $tolerance , 'relative');
            }
            elsif ( $expected_value =~ /([+-]?\s*\w+\.?\d*)\s*\?\s*(\d+\.?\d*)/i )
            {
                $expected_value = $1; $tolerance = $2;
                DCOM_w2TestStep("TestStep" , "Eval: $data_label = $expected_value (tolerance - +/- $tolerance)" );
                DCOM_evaluate_phys($DTCExtDataRecbyDTCNum_detected->{$record_name},$data_label,$expected_value,$record_name, $tolerance , 'absolute');
            }
            else  ### check values directly without tolerance
            {
                DCOM_w2TestStep("TestStep" , "Eval: $data_label = $expected_value" );
                DCOM_evaluate_phys($DTCExtDataRecbyDTCNum_detected->{$record_name},$data_label,$expected_value,$record_name);
            }        
#           DCOM_evaluate_phys($DTCExtDataRecbyDTCNum_detected->{$record_name}, $data_label , $expected_value ,$record_name);
          $found = 1;
        }
      }
      unless( $found )
      {
        #Set Error here;
      }
    }
  }
 elsif($eval_mode =~ /hex/i ){
    foreach my $data_label( keys %$DTCExtDataRecbyDTCNum_expected ){
      undef $found;
      foreach my $record_name(keys %$DTCExtDataRecbyDTCNum_detected ){
        if( grep( /$data_label/i, keys %{$GENERIC_DiagMapping->{'Response_Phys2Hex'}{$record_name}} ) ){
          S_w2rep("Evaluating $data_label under $record_name\n");
          DCOM_evaluate_hex($DTCExtDataRecbyDTCNum_detected->{$record_name}, $data_label , $DTCExtDataRecbyDTCNum_expected->{$data_label},$record_name);
          $found = 1;
        }
      }
      unless( $found )
      {
        #Set Error here;
      }
    }
  }
  return 1;
}

#####################################################################

=head2 DCOM_get_FaultValue_from_mapping

    DCOM_get_FaultValue_from_mapping ( $fault_name , $fault_group);
    $fault_group = 'CU' or 'RB'
    Get the value of the Fault from the Fault Mapping File

=cut

#####################################################################

sub DCOM_get_FaultValue_from_mapping
{
  my $fault_name = shift;
  my $fault_group = shift;
  my $fault_value;

  DCOM_w2TestStep("Comment" , "\n Read and evaluate Fault value from mapping \n");
  if($main::opt_offline){return 1; }
  
  if( $fault_group eq 'RB' )
  {
      # ? 
  }
  elsif( $fault_group eq 'CU' )
  {
      $fault_value = CD_get_FaultDTC($fault_name);
  }
  DCOM_comment('s' ,  "DCOM_get_FaultValue_from_mapping: Value for Fault $fault_name is $fault_value\n");
  return $fault_value;
}
#####################################################################

=head2 DCOM_CA_Trace_get_ReqResp

    DCOM_CA_Trace_get_ReqResp ( $AddressingMode , [ $ReqID , $RespID ] , $TransportProtocol ]);
    
    $AddressingMode = 'physical' or 'functional'
      When $AddtressingMode is specified then the $ReqID and $RespID will be taken from project defaults
      If any other ReqID/RespID (usecase: RespopnseOnEvent) is required then $AddressingMode should be undef 
      and then required IDs can be given
       
    $TransportProtocol = 'ISOTP' or 'raw'
      Currenlty the function supports only ISOTP protocol.
      When the protocol is specified as raw, then all the message data with specified IDs will be given in the Dataref
    
    $Dataref =>{
    
        'Req_Resp' =>{
                        'Time1' => {
                                      'Request'        => 'REQ1',
                                      'Response'       => [ 'RESP11' , 'RESP12' ],
                                      'ResponseTiming' => [ 'Time11' , 'Time12' ],
                                                          
                                   }
                        'Time2' => {


                                   }
                                   ......        
                     }


        'RequestInfo'    => {
                             'Time1' => {
                                          'Request' => 'REQ1'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                             'Time2' => {
                                          'Request' => 'REQ2'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                            },
                                        
        'ResponseInfo'    => {
                             'Time1' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }
                             'Time2' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }                                          
                                }
    
#                   'Request' => {
#                                   'Time1' => 'REQ1'
#                                   'Time2' => 'REQ2'
#                                   .... 
#                                 }
#                   'Response' => {
#                                   'Time1' => 'RESP1'
#                                   'Time2' => 'RESP2'
#                                   .... 
#                                 }                                
               }  

=cut

#####################################################################

sub DCOM_CA_Trace_get_ReqResp
{
  my $AddressingMode = shift;
  my $ReqID = shift;
  my $RespID = shift;
  my $TransportProtocol = shift;
  my $CANBusNumber  = shift;
  my ( 
        $ReqRespDataRef,
        $FlowID,
        $DiagInfo
      );

  undef $ReqID;
  undef $RespID;
  undef $DiagInfo;
  unless ( $CA_trace_data_file_name ) {
      S_w2rep( " DCOM_CA_Trace_get_ReqResp: no current CAN trace file available !! Did you called DCOM_CA_trace_stop() before ? \n");
      return;
   }

  unless(defined $AddressingMode){
    if(!defined $ReqID | !defined $RespID){
      S_set_error("DCOM_CA_Trace_get_ReqResp: Since Addressing mode is not specified, you need to give the ReqID and RespID!" , 109);
      return 0;        
    }
  }

  ($ReqID,$FlowID,$RespID) =CD_set_addressing_mode($AddressingMode);
   $ReqID =~ s/0x//g;
   $FlowID =~ s/0x//g;
   $RespID =~ s/0x//g;
   #$CANBusNumber = $DiagInfo->{'CAN_Bus_Number'};
  if( lc($TransportProtocol) eq "isotp" ){
   $ReqRespDataRef = DCOM_CA_Trace_get_ReqResp_ISOTP($CA_trace_data_file_name, $ReqID, $RespID, $FlowID , $RespID , $CANBusNumber);
  }
  elsif( lc($TransportProtocol) eq "raw" ){
    $ReqRespDataRef = DCOM_CA_Trace_get_ReqResp_raw($CA_trace_data_file_name, $ReqID, $RespID, $FlowID , $RespID , $CANBusNumber );
  }
  elsif( lc($TransportProtocol) eq "gmlan" ){
    $ReqRespDataRef = DCOM_CA_Trace_get_ReqResp_GMLAN($CA_trace_data_file_name, $ReqID, $RespID, $FlowID , $RespID , $CANBusNumber );
  }
  return $ReqRespDataRef;
}

#####################################################################

=head2 DCOM_CA_Trace_get_ReqResp_ISOTP

    DCOM_CA_Trace_get_ReqResp_ISOTP ( $trace_file , $ReqID , $RespID , $ReqID1, $ReqID1);
    $Dataref =>{
    
        'Req_Resp' =>{
                        'Time1' => {
                                      'Request'        => 'REQ1',
                                      'Response'       => [ 'RESP11' , 'RESP12' ],
                                      'ResponseTiming' => [ 'Time11' , 'Time12' ],
                                                          
                                   }
                        'Time2' => {


                                   }
                                   ......        
                     }


        'RequestInfo'    => {
                             'Time1' => {
                                          'Request' => 'REQ1'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                             'Time2' => {
                                          'Request' => 'REQ2'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                            },
                                        
        'ResponseInfo'    => {
                             'Time1' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }
                             'Time2' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }                                          
                                }
    
#                   'Request' => {
#                                   'Time1' => 'REQ1'
#                                   'Time2' => 'REQ2'
#                                   .... 
#                                 }
#                   'Response' => {
#                                   'Time1' => 'RESP1'
#                                   'Time2' => 'RESP2'
#                                   .... 
#                                 }                                
               }  

=cut

#####################################################################

sub DCOM_CA_Trace_get_ReqResp_ISOTP
{
    my $trace_file = shift;
    my $ReqID   = shift;
    my $RespID  = shift;   
    my $ReqID1  = shift;
    my $RespID1 = shift;   
    my $CANBusNumber = shift;
     
    my (          
          $MsgInfo, 
          $ReqRespDataRef,
          $TimeStamp2,
          $Request,
          $Response,
          $Length,
          $RequestBytes,
          $ResponseBytes,
          $ReqRespDataRef_Ap,
          $ResponseTime,
          $TimeStamps,
          $Response_join,
          $Request_join,
          $Response_TP,
          $Request_TP,
          $ExtendedAddressing,
          $DataStartByte,
       );

    my $CA_data_ref = {};

#     return 1 if $main::opt_offline;  

   S_w2rep( "\n\nDCOM_CA_Trace_get_ReqResp_ISOTP: Req ID = $ReqID;Resp ID = $RespID;Req ID = $ReqID1;Resp ID = $RespID1\n");
   unless(defined $CANBusNumber){
      $CANBusNumber = 1;
   }
   $ExtendedAddressing = $GENERIC_ProjectDefaults->{'DIAGNOSIS'}{'ExtAddressing'};
# Request processing
#---------------
    $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $ReqID , $CANBusNumber ); 
    S_dump2log(1,$CA_data_ref);   
    
    foreach my $TimeStamp(keys %$CA_data_ref)
    {
      $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($CA_data_ref->{$TimeStamp}{'DATA'});
    }

    if(defined $ReqID1){
      $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $ReqID1, $CANBusNumber );          
      foreach my $TimeStamp(keys %$CA_data_ref)
      {
        $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($CA_data_ref->{$TimeStamp}{'DATA'});
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Request'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Request_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
      @$RequestBytes = split(/ /,$Request);
      
      if( $ExtendedAddressing  == 1 ){
         $Length = hex($$RequestBytes[1]);
         $DataStartByte = 2;
      }
      else{      
         $Length = hex($$RequestBytes[0]);
         $DataStartByte = 1;
      }
      
      if($Length < 8)
      {
        $Request_TP->{'RequestType'} = 'SingleFrame';
        next if( $$RequestBytes[1] eq '3E');        
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = join(' ',splice(@$RequestBytes, $DataStartByte ,$Length));        
        $Request_TP->{'Request'} = $ReqRespDataRef_Ap->{'Request'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
      if($Length == 16 ){ #10
        $Request_TP->{'RequestType'} = 'MultiFrame';
        $Request_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Request'}{$TimeStamp};

        $Length = hex(join('',splice(@$RequestBytes, 0,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Request_join = join(' ',splice(@$RequestBytes,0,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
          @$RequestBytes = split(/ /,$Request);
          $Request_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Request'}{$TimeStamp};

          if($Length>7){          
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,1,7));
            $Length = $Length -7;
          }
          else{
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,1,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = $Request_join;
        $Request_TP->{'Request'} = $Request_join;
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
    }


# Response processing
#---------------
    $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $RespID , $CANBusNumber );

    foreach my $TimeStamp(keys %$CA_data_ref)
    {
      $ReqRespDataRef->{'Response'}{$TimeStamp} = $CA_data_ref->{$TimeStamp}{'DATA'};
    }
    if(defined $RespID1){
      $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $RespID1, $CANBusNumber );          
      foreach my $TimeStamp(keys %$CA_data_ref)
      {
        $ReqRespDataRef->{'Response'}{$TimeStamp} = $CA_data_ref->{$TimeStamp}{'DATA'};
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Response'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Response_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
      @$ResponseBytes = split(/ /,$Response);
      $Length = hex($$ResponseBytes[0]);

      if($Length < 8)
      {
        next if( $$ResponseBytes[1] eq '7E');        
        $Response_TP->{'ResponseType'} = 'SingleFrame';
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = join(' ',splice(@$ResponseBytes, 1,$Length));
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
      if($Length == 16 ){ #10
        $Response_TP->{'ResponseType'} = 'MultiFrame';
        $Response_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Response'}{$TimeStamp};

        $Length = hex(join('',splice(@$ResponseBytes, 0,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Response_join = join(' ',splice(@$ResponseBytes,0,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
          @$ResponseBytes = split(/ /,$Response);
          $Response_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Response'}{$TimeStamp};
          if($Length>7){          
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,1,7));
            $Length = $Length -7;
          }
          else{
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,1,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = $Response_join;
        $Response_TP->{'Response'} = $Response_join;
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
    }
    $ReqRespDataRef_Ap = DCOM_NET_Trace_get_ReqResp_ArrangeReqResp($ReqRespDataRef_Ap);
    if( S_read_loglevel() > 3){
      DCOM_w2html_ReqResp($ReqRespDataRef_Ap);
    }    
    return $ReqRespDataRef_Ap;
}

#####################################################################

=head2 DCOM_CA_Trace_get_ReqResp_raw
    
    It will fetch the CAN or CANFD req and resp  data into  href.
    RedID or RespID : must be without '0x' e.g. '651'
    
    DCOM_CA_Trace_get_ReqResp_raw ( $trace_file , $ReqID , $RespID , $CANBusNumber );
    $Dataref =>{
                  'Request' => {
                                  'Time1' => 'REQ1'
                                  'Time2' => 'REQ2'
                                  .... 
                                }
                  'Response' => {
                                  'Time1' => 'RESP1'
                                  'Time2' => 'RESP2'
                                  .... 
                                }                                
               }  

=cut

#####################################################################

sub DCOM_CA_Trace_get_ReqResp_raw
{
    my $trace_file = shift;
    my $ReqID  = shift;
    my $RespID = shift;    
    my $ReqID1  = shift;
    my $RespID1 = shift;   
    my $CANBusNumber = shift;
    my (          
          $MsgInfo, 
          $ReqRespDataRef,
          $TimeStamp2,
          $Request,
          $Response,
          $Length,
          $RequestBytes,
          $ResponseBytes,
          $ReqRespDataRef_Ap,
          $ResponseTime,
          $i,
          $TimeStamps,
          $Response_join,
          $Request_join,
       );

    my $CA_data_ref = {};

     return [] if $main::opt_offline;  

# Request processing
#---------------
    $CA_data_ref = DCOM_VEC_trace_can_canfd_get_message_data( $trace_file , $ReqID , $CANBusNumber );    
    foreach my $TimeStamp(keys %$CA_data_ref)
    {
      $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($CA_data_ref->{$TimeStamp}{'DATA'});
    }
    if(defined $ReqID1){
      $CA_data_ref = DCOM_VEC_trace_can_canfd_get_message_data( $trace_file , $ReqID1, $CANBusNumber );          
      foreach my $TimeStamp(keys %$CA_data_ref)
      {
        $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($CA_data_ref->{$TimeStamp}{'DATA'});
      }    
    }

# Response processing
#---------------
    $CA_data_ref = DCOM_VEC_trace_can_canfd_get_message_data( $trace_file , $RespID , $CANBusNumber );

    foreach my $TimeStamp(keys %$CA_data_ref)
    {
      $ReqRespDataRef->{'Response'}{$TimeStamp} = $CA_data_ref->{$TimeStamp}{'DATA'};
    }
    if(defined $RespID1){
      $CA_data_ref = DCOM_VEC_trace_can_canfd_get_message_data( $trace_file , $RespID1, $CANBusNumber );          
      foreach my $TimeStamp(keys %$CA_data_ref)
      {
        $ReqRespDataRef->{'Response'}{$TimeStamp} = $CA_data_ref->{$TimeStamp}{'DATA'};
      }    
    }
    
    $ReqRespDataRef = DCOM_NET_Trace_get_ReqResp_ArrangeReqResp( $ReqRespDataRef );
    DCOM_w2html_ReqResp( $ReqRespDataRef );
    return $ReqRespDataRef;
}

#####################################################################

=head2 DCOM_VEC_trace_can_canfd_get_message_data

    DCOM_VEC_trace_can_canfd_get_message_data ( $trace_file , $can_or_CANFD_id , $can_or_CANFD_bus_nbr );
    wrapper to fetch either CAN or CANFD data into the hash.
    It will look into the trace for the CAN first and if not found then it will for the CANFD.

=cut

#####################################################################

sub DCOM_VEC_trace_can_canfd_get_message_data {
    my @args = @_;
    my $trace_file_path = shift @args;
    my $can_or_CANFD_id = shift @args;
    my $can_or_CANFD_bus_nbr = shift @args;
    
    # look for CAN data from Trace  and  return if found
    my $found_messages_href = VEC_trace_can_get_message_data( $trace_file_path, $can_or_CANFD_id, $can_or_CANFD_bus_nbr );

    # look for the CANFD data from Trace if CAN data not found
    unless ( defined $found_messages_href ) {
         $found_messages_href = VEC_trace_canfd_get_message_data($trace_file_path, {CANFD_ID=>$can_or_CANFD_id, CANFD_CHNL_NBR=>$can_or_CANFD_bus_nbr});   
    }
    
    return $found_messages_href;
}



#####################################################################

=head2 DCOM_CA_Trace_get_ReqResp_GMLAN

    DCOM_CA_Trace_get_ReqResp_ISOTP ( $trace_file , $ReqID , $RespID , $ReqID1, $ReqID1);

=cut

#####################################################################

sub DCOM_CA_Trace_get_ReqResp_GMLAN
{
    my $trace_file = shift;
    my $ReqID   = shift;
    my $RespID  = shift;   
    my $ReqID1  = shift;
    my $RespID1 = shift;   
    my $CANBusNumber = shift;
     
    my (          
          $MsgInfo, 
          $ReqRespDataRef,
          $TimeStamp2,
          $Request,
          $Response,
          $Length,
          $RequestBytes,
          $ResponseBytes,
          $ReqRespDataRef_Ap,
          $ResponseTime,
          $TimeStamps,
          $Response_join,
          $Request_join,
          $Response_TP,
          $Request_TP,
          $ExtendedAddressing,
          $DataStartByte,
       );

    my $CA_data_ref = {};

#     return 1 if $main::opt_offline;  

   unless(defined $CANBusNumber){
      $CANBusNumber = 1;
   }
   $ExtendedAddressing = $GENERIC_ProjectDefaults->{'DIAGNOSIS'}{'ExtAddressing'};   
# Request processing
#---------------
    $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $ReqID , $CANBusNumber );    
    
    foreach my $TimeStamp(keys %$CA_data_ref)
    {
      $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($CA_data_ref->{$TimeStamp}{'DATA'});
    }

    if(defined $ReqID1){
      $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $ReqID1, $CANBusNumber );          
      foreach my $TimeStamp(keys %$CA_data_ref)
      {
        $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($CA_data_ref->{$TimeStamp}{'DATA'});
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Request'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Request_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
      @$RequestBytes = split(/ /,$Request);
      if( $ExtendedAddressing  == 1 ){
         $Length = hex($$RequestBytes[1]);
         $DataStartByte = 2;
      }
      else{      
         $Length = hex($$RequestBytes[0]);
         $DataStartByte = 1;
      }

      if($Length < 8)
      {
        $Request_TP->{'RequestType'} = 'SingleFrame';
        next if( $$RequestBytes[1] eq '3E');        
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = join(' ',splice(@$RequestBytes, $DataStartByte,$Length));
        $Request_TP->{'Request'} = $ReqRespDataRef_Ap->{'Request'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
      if($Length == 16 ){ #10
        $Request_TP->{'RequestType'} = 'MultiFrame';
        $Request_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Request'}{$TimeStamp};

        $Length = hex(join('',splice(@$RequestBytes, 0,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Request_join = join(' ',splice(@$RequestBytes,0,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
          @$RequestBytes = split(/ /,$Request);
          $Request_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Request'}{$TimeStamp};

          if($Length>7){          
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,1,7));
            $Length = $Length -7;
          }
          else{
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,1,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = $Request_join;
        $Request_TP->{'Request'} = $Request_join;
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
    }


# Response processing
#---------------
    $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $RespID , $CANBusNumber );

    foreach my $TimeStamp(keys %$CA_data_ref)
    {
      $ReqRespDataRef->{'Response'}{$TimeStamp} = $CA_data_ref->{$TimeStamp}{'DATA'};
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Response'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Response_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
      @$ResponseBytes = split(/ /,$Response);
      $Length = hex($$ResponseBytes[0]);

      if($Length < 8)
      {
        next if( $$ResponseBytes[1] eq '7E');        
        $Response_TP->{'ResponseType'} = 'SingleFrame';
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = join(' ',splice(@$ResponseBytes, 1,$Length));
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
#       if($Length == 129) #response to A9 service -> response begins with 81
#       {
#         $Response_TP->{'ResponseType'} = 'UUDT';
#         $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = join(' ', @$ResponseBytes);
#         $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
#         $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
#       }
      if($Length == 16 ){ #10
        $Response_TP->{'ResponseType'} = 'MultiFrame';
        $Response_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Response'}{$TimeStamp};

        $Length = hex(join('',splice(@$ResponseBytes, 0,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Response_join = join(' ',splice(@$ResponseBytes,0,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
          @$ResponseBytes = split(/ /,$Response);
          $Response_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Response'}{$TimeStamp};
          if($Length>7){          
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,1,7));
            $Length = $Length -7;
          }
          else{
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,1,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = $Response_join;
        $Response_TP->{'Response'} = $Response_join;
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
    }

# Processing on the alternate response ID (with UUDT messages)
#-------------------------
    undef $ReqRespDataRef;
    if(defined $RespID1){
      $CA_data_ref = VEC_trace_can_get_message_data( $trace_file , $RespID1, $CANBusNumber );          
      foreach my $TimeStamp(keys %$CA_data_ref)
      {
        $ReqRespDataRef->{'Response'}{$TimeStamp} = $CA_data_ref->{$TimeStamp}{'DATA'};
      }    
    }
    @$TimeStamps =  keys %{$ReqRespDataRef->{'Response'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Response_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
      @$ResponseBytes = split(/ /,$Response);
      $Length = hex($$ResponseBytes[0]);

      if($Length == 129) #response to A9 service -> response begins with 81
      {
        $Response_TP->{'ResponseType'} = 'UUDT';
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = join(' ', @$ResponseBytes);
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
      else{
        $Response_TP->{'ResponseType'} = 'UUDT';
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'UUDT_Responses'}{$TimeStamp} = $Response_TP;
      }
    }

    $ReqRespDataRef_Ap = DCOM_NET_Trace_get_ReqResp_ArrangeReqResp($ReqRespDataRef_Ap);
    S_dump2log(1,$ReqRespDataRef_Ap->{'Response'});
    if( S_read_loglevel() > 3){
      DCOM_w2html_ReqResp($ReqRespDataRef_Ap);
    }    
    return $ReqRespDataRef_Ap;
}

#####################################################################

=head2 DCOM_NET_Trace_get_ReqResp_ArrangeReqResp

    DCOM_NET_Trace_get_ReqResp_ArrangeReqResp ( $ReqRespDataRef );

=cut

#####################################################################
sub DCOM_NET_Trace_get_ReqResp_ArrangeReqResp
{
  my $ReqRespDataRef = shift;
  my( 
      $Req_TimeStamps,
      $Resp_TimeStamps,
      $TimeStamp,
      $TimeStamp2,
      $ResponseTime,
      $Request,
      $Response,
      $i,
      $j,
      $ReqTime1,
      $ReqTime2,
      $RespTime,
    );


    @$Req_TimeStamps =  keys %{$ReqRespDataRef->{'Request'}};
    @$Req_TimeStamps = sort { $a <=> $b }@$Req_TimeStamps;
    
    @$Resp_TimeStamps =  keys %{$ReqRespDataRef->{'Response'}};
    @$Resp_TimeStamps = sort { $a <=> $b }@$Resp_TimeStamps;
     
    for($i=0;$i<@$Req_TimeStamps;$i++){
      $ReqTime1  = $$Req_TimeStamps[$i];
      if($i+1 == @$Req_TimeStamps){
        $ReqTime2  = $ReqTime1 + 5; #last time stamp
      }
      else{
        $ReqTime2  = $$Req_TimeStamps[$i+1];
      }      
      $Request   = $ReqRespDataRef->{'Request'}{$ReqTime1};
      $ReqRespDataRef->{'Req_Resp'}{$ReqTime1}{'Request'} = uc($Request);
      $ReqRespDataRef->{'Req_Resp'}{$ReqTime1}{'Response'} = [];
      $ReqRespDataRef->{'Req_Resp'}{$ReqTime1}{'ResponseTiming'} = [];
      
      undef $Response; 
      for($j=0;$j<@$Resp_TimeStamps;$j++){
        $RespTime = $$Resp_TimeStamps[$j];
        if( ( $RespTime > $ReqTime1 ) & ( $RespTime < $ReqTime2 ) ){
           $Response =  $ReqRespDataRef->{'Response'}{$RespTime};
           push ( @{$ReqRespDataRef->{'Req_Resp'}{$ReqTime1}{'Response'}}, uc($Response) );
           push ( @{$ReqRespDataRef->{'Req_Resp'}{$ReqTime1}{'ResponseTiming'}}, $RespTime );           
        }
      }      
    }
    return $ReqRespDataRef;
}


#####################################################################

=head2 DCOM_get_DiagInfo_from_ProjectDefaults

    DCOM_get_DiagInfo_from_ProjectDefaults ( );

=cut

#####################################################################

sub DCOM_get_DiagInfo_from_ProjectDefaults
{
    my $DiagInfo;
    my %DIAGNOSIS;
    undef $DiagInfo;
    
    %DIAGNOSIS = %{$GENERIC_ProjectDefaults->{'DIAGNOSIS'}};    
    $DiagInfo = \%DIAGNOSIS;
    unless ($DiagInfo)
    {
        S_set_error( "DiagMapping is not cofigured correctly. Please Check", 114 );
        return 0;     
    }
    
    $DiagInfo->{'RequestID_phys'}        = sprintf("%X", $DiagInfo->{'RequestID_physical'});
    $DiagInfo->{'ResponseID_phys'}       = sprintf("%X", $DiagInfo->{'ResponseID_physical'});
    $DiagInfo->{'AlternateResponseID'}   = sprintf("%X", $DiagInfo->{'AlternateResponseID'});
    $DiagInfo->{'RequestID_func'}        = sprintf("%X", $DiagInfo->{'RequestID_functional'});
    $DiagInfo->{'ResponseID_func'}       = sprintf("%X", $DiagInfo->{'ResponseID_functional'});
    $DiagInfo->{'FlowControlID_phys'}    = sprintf("%X", $DiagInfo->{'FlowControlID_physical'});
    $DiagInfo->{'FlowControlID_func'}    = sprintf("%X", $DiagInfo->{'FlowControlID_functional'});

    $DiagInfo->{'ExtAddressing'}         = sprintf("%X", $DiagInfo->{'ExtAddressing'});
    $DiagInfo->{'EcuAddr'}               = sprintf("%X", $DiagInfo->{'EcuAddr'});
    $DiagInfo->{'TargetAddr'}            = sprintf("%X", $DiagInfo->{'TargetAddr'});
    
    return $DiagInfo;
}
#####################################################################

=head2 DCOM_w2html_ReqResp

    DCOM_w2html_ReqResp ( $ReqRespDataRef );

=cut

#####################################################################

sub DCOM_w2html_ReqResp
{
  my $ReqRespDataRef = shift;
  my(
      $RespTime,
      $Request,
      $Response,   
      $ResponseTimes,
      $TimeDifferences,
      $TimeDiff,
    );

  DCOM_w2html( "Request,Response and Time info from NET Trace  &6" , "T"  , 'blue' , "Courier" );

  unless(defined $write_2_inner_table){
    DCOM_w2html( "dummy&5" , "BTI"  );
    my $text = "Req;Resp;ReqTimeStamp;RespTimeStamp;TimeDiff(ms)";
    DCOM_w2html( "$text" , "TI" , "black", "Courier", "Lightpink");
    $write_2_inner_table = 1;
  }

    unless( defined $ReqRespDataRef ) 
    {
        DCOM_set_error( " Too Less Params ! SYNTAX: DCOM_w2html_ReqResp(ReqRespDataRef)", 110 );
        return;
    } 
   
    foreach my $ReqTime( sort {$a<=>$b} keys %{$ReqRespDataRef->{'Req_Resp'}} ){
      $Request =  $ReqRespDataRef->{'Req_Resp'}{$ReqTime}{'Request'};
      $Response = join("\n" ,  @{$ReqRespDataRef->{'Req_Resp'}{$ReqTime}{'Response'}});
      $RespTime = join("\n" ,  @{$ReqRespDataRef->{'Req_Resp'}{$ReqTime}{'ResponseTiming'}});
      
      @$ResponseTimes = @{$ReqRespDataRef->{'Req_Resp'}{$ReqTime}{'ResponseTiming'}};
      undef $TimeDifferences;
      for(my $i=0;$i<@$ResponseTimes;$i++){
        $TimeDiff = ($$ResponseTimes[$i] - $ReqTime)*1000;
        $TimeDiff = sprintf("%03.3f" , $TimeDiff);
        push( @$TimeDifferences , $TimeDiff);
      }
      $TimeDiff = join("\n" ,  @$TimeDifferences);
      if(@{$ReqRespDataRef->{'Req_Resp'}{$ReqTime}{'Response'}} > 0){
        DCOM_w2html( "$Request;$Response;$ReqTime;$RespTime;$TimeDiff" , "TI"  , 'green' , "Courier" );
      }
      else{
        DCOM_w2html( "$Request;NoResp;$ReqTime;---;---" , "TI"  , 'blue' , "Courier" );      
      }                    
    }
}

#####################################################################

=head2 DCOM_config_labelvalue_of_request

    $label_value_adjusted = DCOM_config_labelvalue_of_request ( $request, $label_value );
    

=cut

#####################################################################�
sub DCOM_config_labelvalue_of_request
{
   my $request = shift;
   my $label_value = shift;
   my ( 
         $request_info,
         $label_value_adjusted,
         $label_list,
         $value,
         $label,
         $length,
      );
   
   unless( defined $label_value ) 
   {
      DCOM_set_error( " Too Less Params ! SYNTAX: DCOM_config_labelvalue_of_request( request, label_value)", 110 );
      return;
   }  
   
   $request =~ s/^REQ_//;
   $request_info = DCOM_getRequestInfofromMapping( $request );
   $label_value_adjusted = $request_info->{'DefaultLabelValue'};
   
   foreach my $main_label( keys %$label_value){
      @$label_list = split(/:/, $label_value->{$main_label});
      $label_value_adjusted->{$main_label} = 0 unless(defined $label_value_adjusted->{$main_label});
      foreach my $sub_label( @$label_list ){
         $label = $main_label."_".$sub_label;
          if ( $request_info->{'BitCoding'}{$label} =~ /^0b/){
           $length =  length $request_info->{'BitCoding'}{$label};
           $length = 2*($length - 2 ) / 8;
           $value = eval( $request_info->{'BitCoding'}{$label} ); 
           $label_value_adjusted->{$main_label} = $label_value_adjusted->{$main_label} | $value;
          }
          else{
           $length =  length $request_info->{'BitCoding'}{$label};
           $length =  2*$length / 8;
           $value = hex( $request_info->{'BitCoding'}{$label} ); 
           $label_value_adjusted->{$main_label} = $label_value_adjusted->{$main_label} | $value;          
          }  
      }
      $label_value_adjusted->{$main_label} = sprintf( "%0${length}X" , $label_value_adjusted->{$main_label});   
      $label_value_adjusted->{$main_label} = join(' ',$label_value_adjusted->{$main_label} =~ /..?/sg);  
   }      
   
   return $label_value_adjusted;
}
#####################################################################

=head2 DCOM_getReqestResponseFromMapping

    $RequestDetails = DCOM_getReqestResponseFromMapping ( $request, $label_value );
    

=cut

#####################################################################�
sub DCOM_getReqestResponseFromMapping
{
   my $request_label = shift;
   my $label_value = shift;
   my ( 
         $request, 
         $response,
         $request_info,
         $RequestDetails,
         $request_top_label,
      );
   if( $request_label =~ /^REQ_/){
      $request_top_label =  $request_label; 
      $request_top_label =~ s/^REQ_//;
      $request_top_label =~ s/__\S*$//;
      $request_info = $GENERIC_DiagMapping->{'Requests_Responses'}{$request_top_label};
      $request_label =~ s/^REQ_//;
   }
   else{
      $request_info = $GENERIC_DiagMapping->{'Requests_Responses'}{$request_label};
   }
         
   $request = $request_info->{'Requests'}{"REQ_".$request_label}{'Request'};
   foreach my $label(keys %$label_value){
      $request =~ s/$label/$label_value->{$label}/;
   }

   $response = $request_info->{'POS_Responses'}{"PR_".$request_label}{'Response'};
   foreach my $label(keys %$label_value){
      $response =~ s/$label/$label_value->{$label}/;
   }
   $RequestDetails->{'Request'}  = $request;
   $RequestDetails->{'Response'} = $response;
   $RequestDetails->{'Mode'}     = $request_info->{'POS_Responses'}{"PR_".$request_label}{'Mode'};
   $RequestDetails->{'Desc'}     = $request_info->{'POS_Responses'}{"PR_".$request_label}{'Desc'};
   return $RequestDetails;
}

#####################################################################

=head2 DCOM_get_ReqResp_from_dataref

    DCOM_get_ReqResp_from_dataref ( $dataref , $request, [ $label_value, $start_time, $end_time]  );
    

=cut

#####################################################################�

sub DCOM_get_ReqResp_from_dataref
{
  my $dataref = shift;
  my $request = shift;
  my $label_value = shift;
  my $start_time = shift;
  my $end_time = shift;
  my(
      $request_top_label,
      $RequestInfo,
      $request_raw,
      $ReqRespDataref,
    );

   unless( defined $request ) {
      S_set_error( " Too Less Params ! SYNTAX: DCOM_get_ReqResp_from_dataref( dataref, request, label_value, start_time )", 110 );
      return;
   } 
   
   if( ( defined $end_time ) && ( $start_time >= $end_time ) ){
     S_set_error( "StartTime ($start_time) >= EndTime ($end_time)", 109 );
     return 0;
   }
   if( $request =~ /^REQ_/ ){
      $request_top_label =  $request; 
      $request_top_label =~ s/^REQ_//;
      $request_top_label =~ s/__\S*$//;
      $RequestInfo = DCOM_getRequestInfofromMapping($request_top_label);
      $request_raw = $RequestInfo->{'Requests'}{$request}{'Request'};   
   }
   else{
      $request_raw = $request;
   }
# For the request from the RequestLabel
#---------------------------   
   if(defined $label_value){
      foreach my $label(keys %$label_value){
         $request_raw =~ s/$label/$label_value->{$label}/;
      }
   }   
   foreach my $ReqTime( sort {$a<=>$b} keys %{$dataref->{'Req_Resp'}} ){
      next if( ( defined $start_time ) && ( $ReqTime < $start_time ) );
      last if( ( defined $end_time ) && ( $ReqTime > $end_time ) );
      if($dataref->{'Req_Resp'}{$ReqTime}{'Request'} eq $request_raw ){
           $ReqRespDataref->{$ReqTime} = $dataref->{'Req_Resp'}{$ReqTime};
      }
   }   
   return $ReqRespDataref;
}

#####################################################################

=head2 DCOM_eval_ReqResp_from_dataref

    DCOM_eval_ReqResp_from_dataref ( $DataRef , $ReqResp_ref, [ $label_value, $start_time, $end_time]  );
    example:
    $ReqResp_ref = %{
                      'REQ_StartSession_ExtendedSession' => 'PR_StartSession_ExtendedSession|',
                      '10 01' => '50 01',
                    }
    

=cut

#####################################################################�

sub DCOM_eval_ReqResp_from_dataref
{
  my $DataRef = shift;
  my $ReqResp_ref = shift;
  my $label_value = shift;
  my $start_time  = shift;
  my $end_time    = shift;
  my(
      $ReqRespDataref,
      $ReqRespExp,
      $ReqRespFromDiagMapping,
      $RequestExpected,
      $ResponseExpected,
      $ResponseList,
      $ResponseListExpected,
      $NRCInfo,
      $ServiceLabel,
      $text_list,
      $RequestDetected,
      $ResponseListDetected,
    );


   unless( defined $ReqResp_ref ) {
      DCOM_set_error( " Too Less Params ! SYNTAX: DCOM_get_ReqResp_from_dataref( dataref, ReqResp_ref, label_value, start_time )", 110 );
      return;
   } 
   
   if( ( defined $end_time ) && ( $start_time >= $end_time ) ){
     DCOM_set_error( "StartTime ($start_time) >= EndTime ($end_time)", 109 );
     return 0;
   }
   
  DCOM_w2html( "Evaluate the Responses from Trace File &6" , "T"  , 'blue' , "Courier" );

   foreach my $request(keys %$ReqResp_ref){

# Prepare expected values as Hex values instead of Labels 
#-----------------
      undef $ResponseExpected;
      undef $ResponseListExpected;
      if( $request =~ /^REQ_/){
         $ReqRespFromDiagMapping = DCOM_getReqestResponseFromMapping($request , $label_value );
         $RequestExpected = $ReqRespFromDiagMapping->{'Request'};         
      }
      else{
         $RequestExpected = $request; #Raw Request
      }
      @$ResponseList = split(/\|/,$ReqResp_ref->{$request} );
      foreach my $response(@$ResponseList){
            if( $response =~ /^PR_/){
               push(@$ResponseListExpected, $ReqRespFromDiagMapping->{'Response'} );
            }
            elsif( $response =~ /^NR_/ ){
               @$text_list = split("_",$request);
               $ServiceLabel = $$text_list[1];
               $NRCInfo = DCOM_getNRCfromMapping($ServiceLabel,$response);
                push(@$ResponseListExpected, $NRCInfo->{'Response'} );
            }
            else{
                push(@$ResponseListExpected,$response);
            }
         S_w2rep( "$RequestExpected -> ".join( ',' , @$ResponseListExpected)."\n" );
      }

# Get the detected ReqResp from the TraceFile
#-----------------
       $ReqRespDataref = DCOM_get_ReqResp_from_dataref( $DataRef , $request , $label_value , $start_time, $end_time );       
       DCOM_set_verdict( 'VERDICT_FAIL')unless(defined $ReqRespDataref);
       foreach my $time_stamp(keys %$ReqRespDataref){
         $RequestDetected =  $ReqRespDataref->{$time_stamp}{'Request'};
         $ResponseListDetected =  $ReqRespDataref->{$time_stamp}{'Response'};
         for(my $i = 0;$i< scalar @$ResponseListExpected;$i++){
            if(!defined $$ResponseListExpected[$i] | !defined $$ResponseListDetected[$i] ){
               DCOM_set_verdict( 'VERDICT_FAIL' );            
            }#end of if
            else{
               DCOM_evaluate_response_bytes( "$RequestExpected" , $$ResponseListDetected[$i] , 0 , $$ResponseListExpected[$i] );
            }#end of else
         }#end of for
       }#end of foreach
      }#end of foreach     
   return 1;

}

#####################################################################

=head2 DCOM_eval_ResponseTime_from_dataref

    DCOM_eval_ReqResp_from_dataref ( $DataRef , [ $RespTime_ref, [ $label_value, $start_time, $end_time] ] );
    example:
    $RespTime_ref = %{
                      'REQ_StartSession_ExtendedSession'    => "300%5",
                      'REQ_StartSession_ProgrammingSession' => "800%5",
                    }    
                    
    if $RespTime_ref is not given in the argument then all the requests in the DataRef will be evaluated
    The Expected Response time is taken from ProjectDefaults->DIAGNOSIS->'ResponseTime_Max_ms'                    

=cut

#####################################################################�

sub DCOM_eval_ResponseTime_from_dataref
{
  my $DataRef = shift;
  my $RespTime_ref = shift;
  my $label_value = shift;
  my $start_time  = shift;
  my $end_time    = shift;
  my(
      $ReqRespDataref,
      $response,
      $ReqRespExp,
      $ReqRespFromDiagMapping,
      $RequestExpected,
      $NRCInfo,
      $ServiceLabel,
      $text_list,
      $expected_value,
      $tolerance,
      $label,
      $detected_value,
      $request_time,
      $response_time,
      $lower_limit, $upper_limit , $tolerance_text, $ReqRespText , $verdict
    );
   
   unless( defined $RespTime_ref ) {
      DCOM_set_error( " Too Less Params ! SYNTAX: DCOM_get_ReqResp_from_dataref( dataref, RespTime_ref, label_value, start_time )", 110 );
      return;
   } 
   
   if( ( defined $end_time ) && ( $start_time >= $end_time ) ){
     DCOM_set_error( "StartTime ($start_time) >= EndTime ($end_time)", 109 );
     return 0;
   }
   
  DCOM_w2html( "Evaluate the Response Timing from Trace File &6" , "T"  , 'blue' , "Courier" );
  unless(defined $write_2_inner_table){
    DCOM_w2html( "dummy&5" , "BTI"  );
    my $text = "Req;Resp;ReqTimeStamp;RespTimeStamp;RespTime_exp(ms);RespTime_det(ms);Tol;Verdict";
    DCOM_w2html( "$text" , "TI" , "black", "Courier", "Lightpink");
    $write_2_inner_table = 1;
  }

# Evaluate response time of all the requests in the trace 
#---------------
   unless(defined $RespTime_ref){
      $upper_limit = $GENERIC_ProjectDefaults->{'DIAGNOSIS'}{'ResponseTime_Max_ms'};
      $expected_value = "0:X:$upper_limit";
      foreach my $time_stamp(sort {$a<=>$b} keys %{$DataRef->{'Req_Resp'}}){
           my $request = $DataRef->{'Req_Resp'}{$time_stamp}{'Request'};     
            $request_time  =  $time_stamp;
            $response_time =  pop @{$DataRef->{'Req_Resp'}{$time_stamp}{'ResponseTiming'}};
            $response = pop @{$DataRef->{'Req_Resp'}{$time_stamp}{'Response'}};
            $detected_value = ($response_time - $request_time)*1000;
            $detected_value = sprintf("%03.3f" , $detected_value);
            DCOM_w2TestStep("TestStep" , "Eval: RespTime of $request = $expected_value" );
            $label = "RespTime of $request";
            $verdict = EVAL_evaluate_interval( $label , 0 , $upper_limit , $detected_value );
            
            if( $verdict eq VERDICT_PASS){
               DCOM_w2html( "$request;$response;$request_time;$response_time;$expected_value;$detected_value;---;PASS" , "TI"  , 'green' , "Courier" );    
            }
            else{
               DCOM_w2html( "$request;$response;$request_time;$response_time;$expected_value;$detected_value;---;FAIL" , "TI"  , 'red' , "Courier" );
            }
      } 
      return 1;
   }

     foreach my $request(keys %$RespTime_ref){

# Get the detected ReqResp from the TraceFile
#-----------------
       $ReqRespDataref = DCOM_get_ReqResp_from_dataref( $DataRef , $request , $label_value , $start_time, $end_time );       
       DCOM_set_verdict( 'VERDICT_FAIL')unless(defined $ReqRespDataref);
       $expected_value = $RespTime_ref->{$request};
       foreach my $time_stamp(sort {$a<=>$b} keys %$ReqRespDataref){
         $request = $ReqRespDataref->{$time_stamp}{'Request'};     
         $request_time  =  $time_stamp;
         $response_time =  pop @{$ReqRespDataref->{$time_stamp}{'ResponseTiming'}};
         $response = pop @{$ReqRespDataref->{$time_stamp}{'Response'}};
         $detected_value = ($response_time - $request_time)*1000; 
         $detected_value = sprintf("%03.3f" , $detected_value);

         $ReqRespText = "$request:$request_time\n$response:$response_time";
         S_w2rep("RequestTimeStamp = $request_time;ResponseTimeStamp= $response_time;ResponseTime= $detected_value (ms)\n");
         if ( $expected_value =~ /([+-]?\s*\w+\.?\d*)\s*%\s*(\d+\.?\d*)/i )
         {
            $expected_value = $1; $tolerance = $2;
            $label = "RespTime of $request";
            DCOM_w2TestStep("TestStep" , "Eval: RespTime of $request  = $expected_value (tolerance - $tolerance %)" );
            $verdict = EVAL_evaluate_value($label, $expected_value, $detected_value , $tolerance , 'relative' );
            $tolerance_text = $tolerance."%";
         }
         elsif ( $expected_value =~ /([+-]?\s*\w+\.?\d*)\s*\?\s*(\d+\.?\d*)/i )
         {
            $expected_value = $1; $tolerance = $2;
            $label = "RespTime of $request";
            DCOM_w2TestStep("TestStep" , "Eval: RespTime of $request = $expected_value (tolerance - +/- $tolerance)" );
            $verdict =  ($label, $expected_value, $detected_value , $tolerance , 'absolute' );
            $tolerance_text = "+/-".$tolerance;
         }
         elsif ( $expected_value =~ /([+-]?\s*\w+\.?\d*)\s*\:x\:\s*([+-]?\s*\w+\.?\d*)/i )
         {
            $lower_limit = $1; $upper_limit = $2;
            $label = "RespTime of $request";
            DCOM_w2TestStep("TestStep" , "Eval: RespTime of $request = $expected_value" );
            $verdict = EVAL_evaluate_interval( $label , $lower_limit , $upper_limit , $detected_value );
         }
         else  ### check values directly without tolerance
         {
            DCOM_w2TestStep("TestStep" , "Eval: RespTime of $request = $expected_value" );
            $label = "RespTime of $request";
            $verdict = EVAL_evaluate_value($label, $expected_value, $detected_value );
         } 
         if( $verdict eq VERDICT_PASS){
            DCOM_w2html( "$request;$response;$request_time;$response_time;$expected_value;$detected_value;$tolerance_text;PASS" , "TI"  , 'green' , "Courier" );    
         }
         else{
            DCOM_w2html( "$request;$response;$request_time;$response_time;$expected_value;$detected_value;$tolerance_text;FAIL" , "TI"  , 'red' , "Courier" );
         }        
       }#end of foreach
    }#end of foreach     
   return 1;
}
################################################################################

=head2 DCOM_getNRCfromMapping

     DCOM_getNRCfromMapping($service,$NRCLabel);
     
returns a refernce for the NegetiveResponse defined in the $service service refering to the diagmapping file.     
    
   e.g. $NRCInfo = DCOM_getNRCfromMapping('StartSession','NR_LengthIncorrect');

=cut

################################################################################

sub DCOM_getNRCfromMapping {
  my $service = shift;
  my $NRCLabel = shift;
  my $NRCInfo; #hash ref to get NRC information
    
  $NRCInfo->{'Response'}   = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Response'};
  $NRCInfo->{'Mode'}       = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Mode'};
  $NRCInfo->{'Desc'}       = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'Desc'};
  $NRCInfo->{'AddrModes'}  = $GENERIC_DiagMapping->{'DIAG_SERVICES'}{$service}{'NEG_Responses'}{$NRCLabel}{'AddrModes'};

  return $NRCInfo;
}

################################################################################

=head2 DCOM_getRequestInfofromMapping
 
    $RequestInfo=DCOM_getRequestInfofromMapping($Request);

returns a refernce for the Request information from the DiagMapping file
    
   e.g. DCOM_getRequestInfofromMapping('ReadDatabyID_ECUProgrammingInformation');    

=cut

################################################################################

sub DCOM_getRequestInfofromMapping 
{
  my $request = shift;   
  my $requestInfo;

#   GDCOM_comment('s',$request);
  $requestInfo = $GENERIC_DiagMapping->{'Requests_Responses'}{$request};
  unless(defined $requestInfo)
  {
    DCOM_set_error("$request not defined in the Diagmapping file!", 20 );
    return;
  }
  return $requestInfo;
}

#####################################################################

=head2 DCOM_FR_trace_start

    DCOM_FR_trace_start (  );

=cut

#####################################################################
sub DCOM_FR_trace_start 
{
   S_w2rep( " DCOM_FR_trace_start: starting FlexRay Access trace...\n");
   return FR_trace_start ( );
}

#####################################################################

=head2 DCOM_FR_trace_stop

    FlexRay_trace_file_name = DCOM_FR_trace_stop ( [ $store_file_name ] );
    
Stop FlexRay trace and store into test documentation with <store_file_name> or default file name
the stored file name will be returned

=cut

#####################################################################
sub DCOM_FR_trace_stop 
{
   my $store_file_name = shift;

   S_w2rep( " SC_FR_trace_stop: stopping FlexRay Access trace (measurement) and storing data...\n");

   FR_trace_stop ();
#    $FR_trace_data_file_name = FR_trace_store ( $store_file_name );
   ( $FR_trace_data_file_name , $FR_trace_signals_file_name ) = FR_trace_store_both ( $store_file_name );
   
   return $FR_trace_signals_file_name if ( $FR_trace_signals_file_name );
   return $FR_trace_data_file_name;

}

#####################################################################

=head2 DCOM_FR_Trace_get_ReqResp

    DCOM_FR_Trace_get_ReqResp ( $AddressingMode , [ $ReqID , $RespID ] , $TransportProtocol ]);
    
    $AddressingMode = 'physical' or 'functional'
      When $AddtressingMode is specified then the $ReqID and $RespID will be taken from project defaults
      If any other ReqID/RespID (usecase: RespopnseOnEvent) is required then $AddressingMode should be undef 
      and then required IDs can be given
       
    $TransportProtocol = 'ISOTP' or 'raw'
      Currenlty the function supports only ISOTP protocol.
      When the protocol is specified as raw, then all the message data with specified IDs will be given in the Dataref
    
        'Req_Resp' =>{
                        'Time1' => {
                                      'Request'        => 'REQ1',
                                      'Response'       => [ 'RESP11' , 'RESP12' ],
                                      'ResponseTiming' => [ 'Time11' , 'Time12' ],
                                                          
                                   }
                        'Time2' => {


                                   }
                                   ......        
                     }

=cut

#####################################################################

sub DCOM_FR_Trace_get_ReqResp
{
  my $AddressingMode = shift;
  my $ReqID = shift;
  my $RespID = shift;
  my $TransportProtocol = shift;
  my $FlxrBusNumber  = shift;
  my ( 
        $ReqRespDataRef,
        $ReqID1,
        $RespID1,
        $DiagInfo,
      );

  undef $ReqID1;
  undef $RespID1;
  undef $DiagInfo;
  unless ( $FR_trace_data_file_name ) {
      S_w2rep( " DCOM_FR_Trace_get_ReqResp: no current Flexray trace file available !! Did you called DCOM_FR_trace_stop() before ? \n");
      return;
   }

  unless(defined $AddressingMode){
    if(!defined $ReqID | !defined $RespID){
      S_set_error("DCOM_FR_Trace_get_ReqResp: Since Addressing mode is not specified, you need to give the ReqID and RespID!" , 109);
      return 0;        
    }
  }

  $DiagInfo = DCOM_get_DiagInfo_from_ProjectDefaults();
  unless(defined $TransportProtocol){
    $TransportProtocol = $DiagInfo->{'TransportProtocol'};  
  }

  if( lc($AddressingMode) eq 'physical'){
    $ReqID   = $DiagInfo->{'RequestID_phys'};
    $RespID  = $DiagInfo->{'ResponseID_phys'};
    $ReqID1  = $DiagInfo->{'RequestID_phys'};
    $RespID1 = $DiagInfo->{'AlternateResponseID'};  
    }
  elsif( lc($AddressingMode) eq 'functional' ){
    $ReqID   = $DiagInfo->{'RequestID_func'};
    $RespID  = $DiagInfo->{'ResponseID_func'};  
    $ReqID1  = $DiagInfo->{'RequestID_func'};
    $RespID1 = $DiagInfo->{'AlternateResponseID'};  
  }
  elsif( lc($AddressingMode) eq 'phys_func' ){
    $ReqID   = $DiagInfo->{'RequestID_phys'};
    $RespID  = $DiagInfo->{'ResponseID_phys'};
    $ReqID1  = $DiagInfo->{'RequestID_func'};
    $RespID1 = $DiagInfo->{'ResponseID_func'};  
  }

   $FlxrBusNumber = $DiagInfo->{'Flexray_Bus_Number'};  
  if( lc($TransportProtocol) eq "isotp" ){
   $ReqRespDataRef = DCOM_FR_Trace_get_ReqResp_ISOTP($FR_trace_data_file_name, $ReqID, $RespID, $ReqID1 , $RespID1 , $FlxrBusNumber);
  }
  elsif( lc($TransportProtocol) eq "raw" ){
    $ReqRespDataRef = DCOM_FR_Trace_get_ReqResp_raw($FR_trace_data_file_name, $ReqID, $RespID, $ReqID1 , $RespID1  , $FlxrBusNumber );
  }
  elsif( lc($TransportProtocol) eq "gmlan" ){
    $ReqRespDataRef = DCOM_FR_Trace_get_ReqResp_GMLAN($FR_trace_data_file_name, $ReqID, $RespID, $ReqID1 , $RespID1  , $FlxrBusNumber );
  }
  return $ReqRespDataRef;
}

#####################################################################

=head2 DCOM_FR_Trace_get_ReqResp_ISOTP

    DCOM_FR_Trace_get_ReqResp_ISOTP ( $trace_file , $ReqID , $RespID , $ReqID1, $ReqID1);
    $Dataref =>{
    
        'Req_Resp' =>{
                        'Time1' => {
                                      'Request'        => 'REQ1',
                                      'Response'       => [ 'RESP11' , 'RESP12' ],
                                      'ResponseTiming' => [ 'Time11' , 'Time12' ],
                                                          
                                   }
                        'Time2' => {


                                   }
                                   ......        
                     }


        'RequestInfo'    => {
                             'Time1' => {
                                          'Request' => 'REQ1'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                             'Time2' => {
                                          'Request' => 'REQ2'
                                          'RequestType' => 'SingleFrame|MultipleFrame',
                                          'FirstFrame'  => { 
                                                             'TimeFF' => 'FF Data'
                                                           } 
                                           'ConsecutiveFrames' =>{
                                                                   'TimeCF1' => 'CF1 Data',
                                                                   'TimeCF2' => 'CF2 Data',
                                                                   ....
                                                                 }
                                        }
                            },
                                        
        'ResponseInfo'    => {
                             'Time1' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }
                             'Time2' => {
                                  'ResponseType' => 'SingleFrame|MultipleFrame',
                                  'Response'     => 'RESP',
                                  'FirstFrame'   => { 
                                                     'TimeFF' => 'FF Data'
                                                    } 
                                  'ConsecutiveFrames' =>{
                                                           'TimeCF1' => 'CF1 Data',
                                                           'TimeCF2' => 'CF2 Data',
                                                           ....
                                                         }
                                          }                                          
                                }
    
#                   'Request' => {
#                                   'Time1' => 'REQ1'
#                                   'Time2' => 'REQ2'
#                                   .... 
#                                 }
#                   'Response' => {
#                                   'Time1' => 'RESP1'
#                                   'Time2' => 'RESP2'
#                                   .... 
#                                 }                                
               }  

=cut

#####################################################################

sub DCOM_FR_Trace_get_ReqResp_ISOTP
{
    my $trace_file = shift;
    my $ReqID   = shift;
    my $RespID  = shift;   
    my $ReqID1  = shift;
    my $RespID1 = shift;
    my $FlxrBusNumber = shift;   
     
    my (          
          $MsgInfo, 
          $ReqRespDataRef,
          $TimeStamp2,
          $Request,
          $Response,
          $Length,
          $RequestBytes,
          $ResponseBytes,
          $ReqRespDataRef_Ap,
          $ResponseTime,
          $TimeStamps,
          $Response_join,
          $Request_join,
          $Response_TP,
          $Request_TP,
          $DataStartByte,
          $ExtendedAddressing,
       );

    my $FR_data_ref = {};

#     return 1 if $main::opt_offline;  

   $ExtendedAddressing = $GENERIC_ProjectDefaults->{'DIAGNOSIS'}{'ExtAddressing'};

# Request processing
#---------------
    unless(defined $FlxrBusNumber){
      $FlxrBusNumber = 'Fr';
    }

    $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $ReqID , $FlxrBusNumber );   
    
    foreach my $TimeStamp(keys %$FR_data_ref)
    {
      $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($FR_data_ref->{$TimeStamp}{'DATA'});
    }

    if(defined $ReqID1){
      $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $ReqID1 , $FlxrBusNumber );          
      foreach my $TimeStamp(keys %$FR_data_ref)
      {
        $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($FR_data_ref->{$TimeStamp}{'DATA'});
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Request'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Request_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
      @$RequestBytes = split(/ /,$Request);

     if( $ExtendedAddressing  == 1 ){
         $Length = hex($$RequestBytes[5]);
         $DataStartByte = 6;
      }
      else{      
         $Length = hex($$RequestBytes[4]);
         $DataStartByte = 5;
      }      

      if($Length < 8)
      {
        $Request_TP->{'RequestType'} = 'SingleFrame';
        next if( $$RequestBytes[5] eq '3E');        
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = join(' ',splice(@$RequestBytes, $DataStartByte,$Length));
        $Request_TP->{'Request'} = $ReqRespDataRef_Ap->{'Request'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
      if($Length == 16 ){ #10
        $Request_TP->{'RequestType'} = 'MultiFrame';
        $Request_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Request'}{$TimeStamp};

        $Length = hex(join('',splice(@$RequestBytes, 4,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Request_join = join(' ',splice(@$RequestBytes,4,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
          @$RequestBytes = split(/ /,$Request);
          $Request_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Request'}{$TimeStamp};

          if($Length>7){          
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,5,7));
            $Length = $Length -7;
          }
          else{
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,5,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = $Request_join;
        $Request_TP->{'Request'} = $Request_join;
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
    }


# Response processing
#---------------
    $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $RespID , $FlxrBusNumber );

    foreach my $TimeStamp(keys %$FR_data_ref)
    {
      $ReqRespDataRef->{'Response'}{$TimeStamp} = $FR_data_ref->{$TimeStamp}{'DATA'};
    }
    if(defined $RespID1){
      $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $RespID1, $FlxrBusNumber );          
      foreach my $TimeStamp(keys %$FR_data_ref)
      {
        $ReqRespDataRef->{'Response'}{$TimeStamp} = $FR_data_ref->{$TimeStamp}{'DATA'};
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Response'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Response_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
      @$ResponseBytes = split(/ /,$Response);
      $Length = hex($$ResponseBytes[4]);

      if($Length < 8)
      {
        next if( $$ResponseBytes[5] eq '7E');        
        $Response_TP->{'ResponseType'} = 'SingleFrame';
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = join(' ',splice(@$ResponseBytes, 5,$Length));
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
      if($Length == 16 ){ #10
        $Response_TP->{'ResponseType'} = 'MultiFrame';
        $Response_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Response'}{$TimeStamp};

        $Length = hex(join('',splice(@$ResponseBytes, 4,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Response_join = join(' ',splice(@$ResponseBytes,4,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
          @$ResponseBytes = split(/ /,$Response);
          $Response_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Response'}{$TimeStamp};
          if($Length>7){          
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,5,7));
            $Length = $Length -7;
          }
          else{
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,5,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = $Response_join;
        $Response_TP->{'Response'} = $Response_join;
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
    }
    $ReqRespDataRef_Ap = DCOM_NET_Trace_get_ReqResp_ArrangeReqResp($ReqRespDataRef_Ap);
    if( S_read_loglevel() > 3){
      DCOM_w2html_ReqResp($ReqRespDataRef_Ap);
    }    
    return $ReqRespDataRef_Ap;
}

#####################################################################

=head2 DCOM_FR_Trace_get_ReqResp_raw

    DCOM_FR_Trace_get_ReqResp_raw ( $trace_file , $ReqID , $RespID );
    $Dataref =>{
                  'Request' => {
                                  'Time1' => 'REQ1'
                                  'Time2' => 'REQ2'
                                  .... 
                                }
                  'Response' => {
                                  'Time1' => 'RESP1'
                                  'Time2' => 'RESP2'
                                  .... 
                                }                                
               }  

=cut

#####################################################################

sub DCOM_FR_Trace_get_ReqResp_raw
{
    my $trace_file = shift;
    my $ReqID  = shift;
    my $RespID = shift;    
    my $ReqID1  = shift;
    my $RespID1 = shift;
    my $FlxrBusNumber = shift;   
    my (          
          $MsgInfo, 
          $ReqRespDataRef,
          $TimeStamp2,
          $Request,
          $Response,
          $Length,
          $RequestBytes,
          $ResponseBytes,
          $ReqRespDataRef_Ap,
          $ResponseTime,
          $i,
          $TimeStamps,
          $Response_join,
          $Request_join,
       );

    my $FR_data_ref = {};

#     return 1 if $main::opt_offline;  

    unless(defined $FlxrBusNumber){
      $FlxrBusNumber = 'Fr';
    }

# Request processing
#---------------
    $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $ReqID , $FlxrBusNumber );    
    
    foreach my $TimeStamp(keys %$FR_data_ref)
    {
      $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($FR_data_ref->{$TimeStamp}{'DATA'});
      $ReqRespDataRef->{'Request'}{$TimeStamp} = substr($ReqRespDataRef->{'Request'}{$TimeStamp}, 12 );
    }
    if(defined $ReqID1){
      $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $ReqID1, $FlxrBusNumber );          
      foreach my $TimeStamp(keys %$FR_data_ref)
      {
        $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($FR_data_ref->{$TimeStamp}{'DATA'});
        $ReqRespDataRef->{'Request'}{$TimeStamp} = substr($ReqRespDataRef->{'Request'}{$TimeStamp}, 12 );
      }    
    }

# Response processing
#---------------
    $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $RespID , $FlxrBusNumber );

    foreach my $TimeStamp(keys %$FR_data_ref)
    {
      $ReqRespDataRef->{'Response'}{$TimeStamp} = $FR_data_ref->{$TimeStamp}{'DATA'};
      $ReqRespDataRef->{'Response'}{$TimeStamp} = substr($ReqRespDataRef->{'Response'}{$TimeStamp}, 12 );
  }
    if(defined $RespID1){
      $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $RespID1, $FlxrBusNumber );          
      foreach my $TimeStamp(keys %$FR_data_ref)
      {
        $ReqRespDataRef->{'Response'}{$TimeStamp} = $FR_data_ref->{$TimeStamp}{'DATA'};
        $ReqRespDataRef->{'Response'}{$TimeStamp} = substr($ReqRespDataRef->{'Response'}{$TimeStamp}, 12 );
      }    
    }    
    $ReqRespDataRef = DCOM_NET_Trace_get_ReqResp_ArrangeReqResp( $ReqRespDataRef );
    DCOM_w2html_ReqResp( $ReqRespDataRef );
    return $ReqRespDataRef;
}

#####################################################################

=head2 DCOM_FR_Trace_get_ReqResp_GMLAN

    DCOM_FR_Trace_get_ReqResp_GMLAN ( $trace_file , $ReqID , $RespID , $ReqID1, $ReqID1);


=cut

#####################################################################

sub DCOM_FR_Trace_get_ReqResp_GMLAN
{
    my $trace_file = shift;
    my $ReqID   = shift;
    my $RespID  = shift;   
    my $ReqID1  = shift;
    my $RespID1 = shift;
    my $FlxrBusNumber = shift;   
     
    my (          
          $MsgInfo, 
          $ReqRespDataRef,
          $TimeStamp2,
          $Request,
          $Response,
          $Length,
          $RequestBytes,
          $ResponseBytes,
          $ReqRespDataRef_Ap,
          $ResponseTime,
          $TimeStamps,
          $Response_join,
          $Request_join,
          $Response_TP,
          $Request_TP,
          $ExtendedAddressing,
          $DataStartByte,
       );

    my $FR_data_ref = {};

#     return 1 if $main::opt_offline;  

   $ExtendedAddressing = $GENERIC_ProjectDefaults->{'DIAGNOSIS'}{'ExtAddressing'};

# Request processing
#---------------
    unless(defined $FlxrBusNumber){
      $FlxrBusNumber = 'Fr';
    }

    $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $ReqID , $FlxrBusNumber );   
    
    foreach my $TimeStamp(keys %$FR_data_ref)
    {
      $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($FR_data_ref->{$TimeStamp}{'DATA'});
    }

    if(defined $ReqID1){
      $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $ReqID1 , $FlxrBusNumber );          
      foreach my $TimeStamp(keys %$FR_data_ref)
      {
        $ReqRespDataRef->{'Request'}{$TimeStamp} = uc($FR_data_ref->{$TimeStamp}{'DATA'});
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Request'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Request_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
      @$RequestBytes = split(/ /,$Request);
     if( $ExtendedAddressing  == 1 ){
         $Length = hex($$RequestBytes[5]);
         $DataStartByte = 6;
      }
      else{      
         $Length = hex($$RequestBytes[4]);
         $DataStartByte = 5;
      }      

      if($Length < 8)
      {
        $Request_TP->{'RequestType'} = 'SingleFrame';
        next if( $$RequestBytes[5] eq '3E');        
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = join(' ',splice(@$RequestBytes, $DataStartByte,$Length));
        $Request_TP->{'Request'} = $ReqRespDataRef_Ap->{'Request'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
      if($Length == 16 ){ #10
        $Request_TP->{'RequestType'} = 'MultiFrame';
        $Request_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Request'}{$TimeStamp};

        $Length = hex(join('',splice(@$RequestBytes, 4,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Request_join = join(' ',splice(@$RequestBytes,4,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Request = $ReqRespDataRef->{'Request'}{$TimeStamp};   
          @$RequestBytes = split(/ /,$Request);
          $Request_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Request'}{$TimeStamp};

          if($Length>7){          
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,5,7));
            $Length = $Length -7;
          }
          else{
            $Request_join = $Request_join." ".join(' ',splice(@$RequestBytes,5,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Request'}{$TimeStamp} = $Request_join;
        $Request_TP->{'Request'} = $Request_join;
        $ReqRespDataRef_Ap->{'Request_Info'}{$TimeStamp} = $Request_TP;
      }
    }


# Response processing
#---------------
    $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $RespID , $FlxrBusNumber );

    foreach my $TimeStamp(keys %$FR_data_ref)
    {
      $ReqRespDataRef->{'Response'}{$TimeStamp} = $FR_data_ref->{$TimeStamp}{'DATA'};
    }
    if(defined $RespID1){
      $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $RespID1, $FlxrBusNumber );          
      foreach my $TimeStamp(keys %$FR_data_ref)
      {
        $ReqRespDataRef->{'Response'}{$TimeStamp} = $FR_data_ref->{$TimeStamp}{'DATA'};
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Response'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Response_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
      @$ResponseBytes = split(/ /,$Response);
      $Length = hex($$ResponseBytes[4]);

      if($Length < 8)
      {
        next if( $$ResponseBytes[5] eq '7E');        
        $Response_TP->{'ResponseType'} = 'SingleFrame';
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = join(' ',splice(@$ResponseBytes, 5,$Length));
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
      if($Length == 16 ){ #10
        $Response_TP->{'ResponseType'} = 'MultiFrame';
        $Response_TP->{'FirstFrame'}{$TimeStamp}   = $ReqRespDataRef->{'Response'}{$TimeStamp};

        $Length = hex(join('',splice(@$ResponseBytes, 4,2 ))); #Get the Length
        $Length = $Length & 0x0FFF;
        $Response_join = join(' ',splice(@$ResponseBytes,4,6));
        $Length = $Length - 6;
        
        while( $Length > 0){
          $i++;
          $TimeStamp = $$TimeStamps[$i];
          $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
          @$ResponseBytes = split(/ /,$Response);
          $Response_TP->{'ConsecutiveFrames'}{$TimeStamp} = $ReqRespDataRef->{'Response'}{$TimeStamp};
          if($Length>7){          
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,5,7));
            $Length = $Length -7;
          }
          else{
            $Response_join = $Response_join." ".join(' ',splice(@$ResponseBytes,5,$Length));
            $Length = $Length -7;
          }                  
        }
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = $Response_join;
        $Response_TP->{'Response'} = $Response_join;
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
    }

# Processing on the alternate response ID (with UUDT messages)
#-------------------------
    undef $ReqRespDataRef;
    
    if(defined $RespID1){
      $FR_data_ref = VEC_trace_fr_get_PDU_data( $trace_file , $RespID1, $FlxrBusNumber );          
      foreach my $TimeStamp(keys %$FR_data_ref)
      {
        $ReqRespDataRef->{'Response'}{$TimeStamp} = $FR_data_ref->{$TimeStamp}{'DATA'};
      }    
    }

    @$TimeStamps =  keys %{$ReqRespDataRef->{'Response'}};
    @$TimeStamps = sort { $a <=> $b }@$TimeStamps;
    
    for(my $i=0;$i<@$TimeStamps;$i++)
    {
      undef $Response_TP;
      my $TimeStamp = $$TimeStamps[$i];
      $Response = $ReqRespDataRef->{'Response'}{$TimeStamp};   
      @$ResponseBytes = split(/ /,$Response);
      $Length = hex($$ResponseBytes[4]);

      if($Length == 129) #response to A9 service -> response begins with 81
      {
        $Response_TP->{'ResponseType'} = 'UUDT';
        $ReqRespDataRef_Ap->{'Response'}{$TimeStamp} = join(' ', @$ResponseBytes);
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'Response_Info'}{$TimeStamp} = $Response_TP;
      }
      else{
        $Response_TP->{'ResponseType'} = 'UUDT';
        $Response_TP->{'Response'} = $ReqRespDataRef_Ap->{'Response'}{$TimeStamp};
        $ReqRespDataRef_Ap->{'UUDT_Responses'}{$TimeStamp} = $Response_TP;
      }
   }    
    $ReqRespDataRef_Ap = DCOM_NET_Trace_get_ReqResp_ArrangeReqResp($ReqRespDataRef_Ap);
    if( S_read_loglevel() > 3){
      DCOM_w2html_ReqResp($ReqRespDataRef_Ap);
    }    
    return $ReqRespDataRef_Ap;
}

1;
