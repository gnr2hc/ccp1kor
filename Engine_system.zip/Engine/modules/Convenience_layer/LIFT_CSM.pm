# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2015  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CSM;

#######################################################################################################

use LIFT_general;

use LIFT_CSM::StorageManager;

use File::Basename;


@ISA = qw(Exporter);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
            CSM_init
            
            CSM_create_container

            CSM_add_keywords
            CSM_add_userfile
            CSM_add_dump_EDR
            
            CSM_pack_container
            CSM_archive_container

            CSM_search_local_container
            CSM_get_container
            CSM_get_container_working_path            
            CSM_get_userfile

            CSM_clear_container
            );


our ($VERSION, $HEADER);

my $SM;          # instance of Storage Manager which is always alive


=head1 LIFT_CSM Module Information

    LIFT_CSM 

    BoschConnect Introduction 
    
    https://connect.bosch.com/forums/html/topic?id=723fa451-7011-486f-8786-4facdbae9717


=head1 SYNOPSIS

=head2 CONFIGURATION

    package LIFT_PROJECT;

    $Defaults -> {'CSM'} = {
         'LocalWorkingArea_Path'    => 'C:\temp\CSM_Local_Working_Area',
         'StorageArea_Path'         => 'C:\TurboLIFT\_StorageArea_CSM_development',
         'disable_CSM'              => 0 ,
    };


=head2 USE CASE ONLINE: adding user files to a new container during ONLINE run

    use LIFT_CSM;
    
    CSM_init() || return;

    my $container_id = CSM_create_container();

    #
    # do some actions which are leading to the userfile which shall be archived
    #

    S_w2rep( " CSM Adding userfile '$filename_A' to '$container_id'\n" , "blue" );    
    CSM_add_userfile( $container_id , $filename_A , "My first Huuuhuuu File AAA\n" );
    
    my $key_word_File_AAA = 'Huhuuu File AAA';
    S_w2rep( " CSM Adding keyword '$key_word_File_AAA' to '$container_id'\n" , "blue" );    
    CSM_add_keywords( $container_id , [ $key_word_File_AAA ] );

    S_w2rep( " CSM Close container '$container_id'\n" , "blue" );    
    CSM_pack_container( $container_id );

    S_w2rep( " CSM Archive container '$container_id'\n" , "blue" );    
    CSM_archive_container( $container_id , 'KeepLocalData' );    # KeepLocalData or NoLocalData
        

=head2 USE CASE OFFLINE: searching container during OFFLINE run

    use LIFT_CSM;
    
    CSM_init() || return;

    S_w2rep( " CSM search container in Local Working Area via keywords\n" , "blue" );    
    my $query_href_match = {
                    'keywords_fully'        => [ 'my-keyword-test-value-ABC' , 'my-keyword-test-value-XYZ'  ] ,
                    'keywords_partially'    => [ ] ,
                    'keywords_regex'        => [ 'test.*ABC' ] ,
#                     'content_type'               => [ 'Dump_EDR' ] ,
#                     'content_identifier'         => [ 'something special' ] ,
                };        
                
    my @query_result_keywords_match = CSM_search_local_container( $query_href_match );
    
    foreach my $container_id ( @query_result_keywords_match ) {
        S_w2rep( " CONTAINER : $container_id\n" , "blue" );    
    }

        

=head2 USE CASE OFFLINE: opening container with extraction of user file

    use LIFT_CSM;
    
    CSM_init() || return;

    #
    # here the container ID must be found / see searching use case
    #
    my $container_id = "????";    # <=== to be set / searched

    S_w2rep( " CSM get container ID $container_id \n" , "blue" );    
    my $Container_Header = CSM_get_container( $container_id ) || return; 

    #
    # container can have several user files 
    #   each element in the container (user file) has a unique Content ID  
    # 
    S_w2rep( " CSM getContentIdentifiers 'UserFile' \n" , "blue" );    
    my $found_userfile_ids_aref = $Container_Header -> getContentIdentifiers( 'UserFile' );
    
    unless ( $found_userfile_ids_aref -> [0] ) {
        S_set_error( "No ContentIdentifiers received , no userfile is part of Container" ); return
    }
    
    # take the first for testing / => look for the right one by searching with keywords, etc.
    my $content_ID_userfile = $found_userfile_ids_aref -> [0]; 
        
    #
    # container Content (user file) can be extracted just by 
    #
    S_w2rep( " CSM get userfile $content_ID_userfile ( with extraction) \n" , "blue" );    
    $userfile_object = 
        CSM_get_userfile(   #    now with extracting (is default)
                            $container_id , 
                            $content_ID_userfile , 
                            { extract => 1 } ,   # option extract : 0 - no ; 1 - yes 
                        ) || return; 
    
    my $userfile_name_long = $userfile_object -> getFilename_long( );
    S_w2rep( "UserFile extracted Name: $userfile_name_long \n" , 'blue' );

    #
    # working path can be obtained like this
    #
    my $cont_work_path = CSM_get_container_working_path( $container_id );
    
    #
    # here the user file can be used (opening/reading)
    #


    #
    # after finish of working with userfile
    #    the opened container shall be closed
    #       (unzipped working directory will be removed)
    #
    S_w2rep( "CSM clear container\n" , 'blue' );
    CSM_clear_container( $ContID ) || return; 


=cut

################################################################################

=head2 CSM_init

    CSM_init ( $options_href );
    CSM_init (  );

    Reading $LIFT_PROJECT::Defaults -> {'CSM'} ( => see CONFIGURATION chapter ).

    
    Handling for LocalWorkingArea_Path
    Different possibilites to call 
    
        CSM_init( { 'LocalWorkingArea_Path' => 'C:\\self_defined\\LWA_special\\' } );  
                    -> overwrite settings of ProjectDefaults if defined
          
        CSM_init( { 'LocalWorkingArea_Path' => 'DEFAULT' } );    
                    -> use DEFAULT 'C:\\temp\\csm_default_lwa\\' 
                    -> overwrite settings of ProjectDefaults if defined
                  
        CSM_init( );        
            without setting in ProjectDefaults 
                    -> use DEFAULT 'C:\\temp\\csm_default_lwa\\'
            
        CSM_init( );        
            use setting in ProjectDefaults  (see below)
    
    
    Handling for StorageArea_Path
    
        CSM_init( { 'StorageArea_Path' => 'C:\\self_defined\\StorageArea_special\\' } ); 
                    -> overwrite settings of ProjectDefaults if defined
           
        CSM_init( { 'StorageArea_Path' => 'DEFAULT' } );         
                    -> use DEFAULT REPORT_PATH from $main
                    -> overwrite settings of ProjectDefaults if defined
                     
        CSM_init( );        
            without setting in ProjectDefaults 
                    -> use DEFAULT REPORT_PATH from $main
                    
        CSM_init( );        
            use setting in ProjectDefaults  (see below) 
    
    
        Both attributes can be given together of course
    
        CSM_init( { 
                    'LocalWorkingArea_Path' => 'DEFAULT' ,
                    'StorageArea_Path'      => 'DEFAULT' ,
                    } );



    
    CSM_init() setup initially or check existing the required instance of
        - LIFT_CSM::StorageManager

    Note: LIFT_CSM::StorageManager is initializing
        - LIFT_CSM::LocalWorkigArea
        - LIFT_CSM::StorageArea

    Keeping access to the Object of LIFT_CSM::StorageManager
        ( available in $LIFT_CSM::SM )

    RETURN VALUES :
        Success : 1
        Offline : 1
        Error   : undef/FALSE   ( + Error handling in LIFT_CSM::StorageManager)
        
        CSM Disabled : 0        ( Warning only) 
    
    CSM can be disabled via setting : 
     
        $LIFT_PROJECT::Defaults -> {'CSM'} -> {'disable_CSM'} = 1;
    
=cut

#-------------------------------------------------------------------------------
sub CSM_init {
#-------------------------------------------------------------------------------

    my @args = @_ ;    
    S_checkFunctionArguments( 'CSM_init ( [ $options_href ] )', @args ) || return;
    my $options_href = shift @args;

    S_w2log( 4, " CSM_init()\n" );
    
    $SM = LIFT_CSM::StorageManager -> getInstance( $options_href );

    unless( $SM ) {
        S_w2log( 2, " CSM_init: Storage Manager could not initialize CSM\n" , 'grey' ); 
        return;
    }

    if( $SM -> isDisabled() ) {
        S_set_warning( "CSM is disabled in ProjectDefaults_CSM" );
        return 0;    
    }

    S_w2log( 4, " CSM_init: Done\n" );
    return 1;    
    
}

#-------------------------------------------------------------------------------
sub CSM_create_container {
#-------------------------------------------------------------------------------
    
    my @args = @_ ;    
    S_checkFunctionArguments( 'CSM_create_container ( [ $requested_container_identifier ] )', @args ) || return;
    my $container_identifier = shift @args;

    my $tc_name = $main::CURRENT_TC;
    my $time = S_get_date_extension();

    unless( defined $container_identifier ) {        
        $container_identifier = $tc_name."__".$time;
        S_w2log( 4, " CSM_create_container: Container Identifier (set default) =  '$container_identifier'\n" , 'grey' );
    }
   
    S_w2log( 4, " CSM_create_container( $container_identifier )\n" );
    
    my $created_container_id = $SM -> createContainer( $container_identifier );

    unless( $created_container_id ) {
        S_w2log( 2, " CSM_create_container: Storage Manager could not create new local container\n" ); 
        return;
    }

#         $project_info_href :
#             {
#                 'ECU_fingerprint'       => ...,       # from  PD_initCommunication
#                 'ECU_SW_VERSION'        => ...,       # from  PD_initCommunication
#                 'ECU_AlgoParameter_ID'  => ...,       # from  PD_initCommunication
#                 'ProjectDescription'    => ...,       # from exec_engine / must be set as: LIFT_config::LIFT_ProjectDescription 
#                 'testlist'              => ...,       # from exec_engine
#                 'configuration'         => ...,       # from exec_engine
#                 'start_date'            => ...,       # from exec_engine
#                 'start_time'            => ...,       # from exec_engine
#                 'username'              => ...,       # from exec_engine
#                 'hostname'              => ...,       # from exec_engine
#                 'LIFT_version'          => ...,       # from exec_engine
#                 'LIFT_exec_engine'      => ...,       # from exec_engine
#
#                 TBD VARIANT
#                 TBD CUSTOMER
#             }

    my $CSM_project_data_href = { };

    my $LIFT_project_data_href = S_get_project_info();

    foreach ( keys %$LIFT_project_data_href ) {
        if ( /ProjectDescription/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'ProjectName' } = $LIFT_project_data_href->{ $_ };   
        }   
        if ( /ECU_SW_VERSION/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'ProjectSoftwareVersion' } = $LIFT_project_data_href->{ $_ };   
        }   
        if ( /TBD CUSTOMER/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'ProjectCustomer' } = $LIFT_project_data_href->{ $_ };   
        }   
        if ( /TBD VARIANT/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'ProjectVariant' } = $LIFT_project_data_href->{ $_ };   
        }   
        if ( /ECU_AlgoParameter_ID/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'ECU_AlgoParameter_ID' } = $LIFT_project_data_href->{ $_ };   
        }   
        if ( /ECU_fingerprint/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'ECU_fingerprint' } = $LIFT_project_data_href->{ $_ };   
        }   
        if ( /username/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'Testername' } = $LIFT_project_data_href->{ $_ };   
        }   
        if ( /hostname/ ) {
            $CSM_project_data_href->{'ProjectData'}{ 'Hostname' } = $LIFT_project_data_href->{ $_ };   
        }   
    }

    $CSM_project_data_href->{'ProjectData'}{ 'TestcaseOfCreation' } = $tc_name;   
    $CSM_project_data_href->{'ProjectData'}{ 'TimeOfCreation' } = $time;   

    unless ( $SM -> addContainerHeader( $created_container_id , $CSM_project_data_href ) ) {
        S_w2log( 2, " CSM_create_container: Storage Manager could not add Header with Container project Data (Cont-Id : $created_container_id)\n" ); 
        return;
    }

    S_w2log( 4, " CSM_create_container() -> '$created_container_id' - done\n" );
    return $created_container_id;   
}


################################################################################

=head2 CSM_add_keywords

    CSM_add_keywords ( $container_identifier ,  $keywords_aref );

Adding keywords to the keywords list of a CSM container identified by the Container ID 

    Arguments :
        $container_identifier => Container ID (e.g. given from CSM_create_container)
        $keywords_aref => array reference to a list of keywords to be added

    Example:  

        CSM_add_keywords( 'MY_TEST_CONTAINER_ID' , [ 'Keyword_A' , 'Keyword_B' ] )       

=cut

#-------------------------------------------------------------------------------
sub CSM_add_keywords {
#-------------------------------------------------------------------------------
    
    my @args = @_;    
    S_checkFunctionArguments( 'CSM_add_keywords ( $container_identifier , $keywords_aref )', @args ) || return;
    my $container_identifier = shift @args;
    my $keywords_aref = shift @args;
    
    unless( defined $keywords_aref ) {
        S_set_error( "Missing parameter keywords" ); return;
    }

    unless( ref $keywords_aref eq 'ARRAY' ) {
        S_set_error( "Given parameter keywords must be array reference" ); return;
    }
    
    S_w2log( 4, " CSM_add_keywords -> $container_identifier : @$keywords_aref \n" );
    
    unless( $SM -> addKeywords( $container_identifier , $keywords_aref ) ) {
        S_w2log( 2, " CSM_add_keywords: Storage Manager could not add Keywords" ); 
        return;
    }

    return 1;       
}

################################################################################

=head2 CSM_add_userfile

    CSM_add_userfile ( $container_identifier ,  $filename_long [ , $userfile_description ] );

Adding a physical userfile given by filename (long incl. path) to a CSM container identified by the Container ID , additionally file description can be given. 

    Arguments :
        $container_identifier => Container ID (e.g. given from CSM_create_container)
        $filename_long => filename with complete path of file to be added to container
        $userfile_description => free text description of file content  (optional)

    Example:  

        CSM_add_userfile( 
                          'MY_TEST_CONTAINER_ID' , 
                          'c:/temp/my_userfile.txt' , 
                          'This file contain a lot of wonderful but secret things' ,
                          )       

=cut

#-------------------------------------------------------------------------------
sub CSM_add_userfile {
#-------------------------------------------------------------------------------

    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_add_userfile ( $container_identifier ,  $filename_long [ , $userfile_description ] )', @args ) || return;
    my $container_identifier = shift @args;
    my $filename_long        = shift @args;
    my $userfile_description = shift @args;
    
    S_w2log( 4, " CSM_add_userfile -> $container_identifier : FILENAME $filename_long ( DESCRIPTION: $userfile_description ) \n" );
    
    unless( $SM -> addUserfile( $container_identifier , $filename_long , $userfile_description ) ) {
        S_w2log( 2, " CSM_add_userfile: Storage Manager could not add given userfile '$filename_long'" ); 
        return;
    }

    return 1;       
}

#-------------------------------------------------------------------------------
sub CSM_add_dump_EDR {
#-------------------------------------------------------------------------------
    
    my $container_identifier = shift;
    my $EDR_DATA_href = shift;
    my $EDR_storage_identifier = shift;
    
    S_w2log( 4, " CSM_add_dump_EDR -> $container_identifier \n" );
    
    unless( $SM -> addDump_EDR( $container_identifier , $EDR_DATA_href , $EDR_storage_identifier ) ) {
        S_w2log( 2, " CSM_add_dump_EDR: Storage Manager could not add EDR dump" ); 
        return;
    }

    return 1;       
}


#-------------------------------------------------------------------------------
sub CSM_pack_container {
#-------------------------------------------------------------------------------
    
    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_pack_container ( $container_identifier )', @args ) || return;
    my $container_identifier = shift @args;
    
    S_w2log( 4, " CSM_pack_container -> $container_identifier \n" );
    
    unless( $SM -> packContainer( $container_identifier ) ) {
        S_w2log( 2, " CSM_pack_container: Storage Manager could not close container" ); 
        return;
    }

    return 1;    
}

#
#   archive modes : 
#       KeepLocalContainer -> keep local Container
#       NoLocalContainer -> remove local Container
#
#-------------------------------------------------------------------------------
sub CSM_archive_container {
#-------------------------------------------------------------------------------
    
    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_archive_container ( $container_identifier [ , $archive_mode ] )', @args ) || return;
    my $container_identifier = shift @args;
    my $archive_mode = shift @args;
    
    $archive_mode = 'KeepLocalContainer' unless defined $archive_mode;
    
    unless( $archive_mode eq 'KeepLocalData' or $archive_mode eq 'NoLocalData' ) {
        S_set_error( "option mode must be 'KeepLocalData' or 'NoLocalData'" ); return;
    }
    
    S_w2log( 4, " CSM_archive_container -> $container_identifier ($archive_mode) \n" );
    
    unless( $SM -> archiveContainer( $container_identifier , $archive_mode ) ) {
        S_w2log( 2, " CSM_archive_container: Storage Manager could not archive container" ); 
        return;
    }

    return 1;       
}

#-------------------------------------------------------------------------------
sub CSM_search_local_container {
#-------------------------------------------------------------------------------
    
    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_search_local_container ( $query_href )', @args ) || return;
    my $query_href = shift @args;
    
    my ( @returned_ContIds_LWA , $nbr_Cont_LWA );
    
    unless( defined $query_href ) {
        S_set_error( "missing argument 'query_href'" , 110 ); return;
    }

    S_w2log( 4, " CSM_search_local_container : Searching in LocalWorkingArea \n" );
    ( $nbr_Cont_LWA , @returned_ContIds_LWA ) = $SM -> searchLocalContainer( $query_href );

    return unless defined $nbr_Cont_LWA; # ERROR occured
    
    #
    # no results
    #
    if( $nbr_Cont_LWA == 0 ) {
        S_w2log( 3 , " CSM_search_local_container: No Container found in LocalWorkingArea\n" , 'orange' );
        return ( ) ;
    }

    #
    # return results
    #
    S_w2log( 3 , " CSM_search_local_container: $nbr_Cont_LWA Container found -> return IDs \n" , 'green' );
                
    return @returned_ContIds_LWA;
}



# look for container in LWA
#  if not available -> copy container from SA
#
#  read and return header
#
#-------------------------------------------------------------------------------
sub CSM_get_container {
#-------------------------------------------------------------------------------
    
    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_get_container ( $container_identifier )', @args ) || return;
    my $container_identifier = shift @args;
        
    my $header_data = $SM -> getContainer( $container_identifier ) || return;

    S_w2log( 4, " CSM_get_container( $container_identifier ) -> return Header Data\n" );
    return $header_data;    
}

#-------------------------------------------------------------------------------
sub CSM_get_container_working_path {
#-------------------------------------------------------------------------------
    
    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_get_container_working_path ( $container_identifier )', @args ) || return;
    my $container_identifier = shift @args;
    
#     S_w2log( 4, " CSM_get_container_working_path( $container_identifier )\n" );
    
    my $cont_work_path = $SM -> getContainerWorkingPath( $container_identifier );

    unless( $cont_work_path ) {
        S_w2log( 3, " CSM_get_container_working_path : is not set\n" ); return
    }
    
    S_w2log( 4, " CSM_get_container_working_path : $cont_work_path  (Cont ID: $container_identifier)\n" );

    return $cont_work_path;    
}

################################################################################

=head2 CSM_clear_container

    CSM_clear_container ( $container_identifier );

Function remove all waste of a Container from Local-Working-Area. 
Perfect for use in Finalization phase of a Testcase !

=head3 Created or Filled -> Delete
    
In case a new Container was just created - and is not worth to be packed and archived - the Container is in State : Created or Filled and can be cleared.

=head3 Opened -> Initialized
    
In case an existing Container was opened for reading the Container is in State : Opened. Then the directory from LocalWorkingArea will be deleted and Container state changes to : Initialized

=head3 Packed, Archived, Initialized -> No action

In case an existing Container is in State : Packed, Archived, Initialized -> nothing happen with this function. 

=head3 Return values 

    Success : 1
    Offline : 1
    Error   : undef/FALSE   ( + Error handling in LIFT_CSM::StorageManager)
    
=cut

#-------------------------------------------------------------------------------
sub CSM_clear_container {
#-------------------------------------------------------------------------------
    
    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_clear_container ( $container_identifier )', @args ) || return;
    my $container_identifier = shift @args;
    
    S_w2log( 4, " CSM_clear_container( $container_identifier ) ... \n" );
    
    $SM -> clearContainer( $container_identifier ) || return;

    return 1;    
}


################################################################################

=head2 CSM_get_userfile

    $userfile_object = CSM_get_userfile ( $container_identifier ,  $userfile_identifer , $options_href );

    Getting the object of userfile identified with userfile content identifier 
    ( normally filename (short excl. path) ) 
    from CSM container identified by the Container ID
    Userfile will be extracted per default ( can then be accessed by $userfile_object -> getFilename_long() )  

    Arguments :
        $container_identifier : Container ID (e.g. given from CSM_create_container)
        $userfile_identifer   : filename with complete path of file to be geted to container
        $options_href :
            { extract => 0 }        # => no extraction of userfile from container
            { extract => 1 }        # => extraction of userfile from container

    Return :
        $userfile_object

    Example:  

        $userfile_object  = CSM_get_userfile ( 
                          'MY_TEST_CONTAINER_ID' , 
                          'my_userfile.txt' ,
                          { extract => 0 } ,      # 0  => file will NOT be extracted from Container
                          )       

        my $file_name = $userfile_object -> getFilename( );
        my $file_description = $userfile_object -> getDescription( );

        $userfile_object = CSM_get_userfile( 
                          'MY_TEST_CONTAINER_ID' , 
                          'my_userfile.txt' ,
                          { extract => 1 } ,        # 1 is default   => file will be extracted from Container
                          )       

        my $file_name_long = $userfile_object -> getFilename_long( );

=cut

#-------------------------------------------------------------------------------
sub CSM_get_userfile {
#-------------------------------------------------------------------------------

    my @args = @_ ;
    S_checkFunctionArguments( 'CSM_get_userfile ( $container_identifier ,  $userfile_identifer [ , $options_href ] )', @args ) || return;   
    my $container_identifier = shift @args;
    my $userfile_identifer = shift @args;
    my $options_href = shift @args;
    
    S_w2log( 4, " CSM_get_userfile ( $container_identifier , $userfile_identifer ) ... \n" );
    
    my $userfile_object = $SM -> getUserfile( $container_identifier , $userfile_identifer , $options_href );
    unless( $userfile_object ) {
        S_w2log( 2, " CSM_get_userfile: Storage Manager could not get requested userfile object '$userfile_identifer'" ); 
        return;
    }

    return $userfile_object;       
}


1;

__END__