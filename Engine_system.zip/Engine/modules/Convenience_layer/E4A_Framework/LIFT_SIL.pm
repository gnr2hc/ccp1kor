# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package E4A_Framework::LIFT_SIL;

use strict;
use warnings;
use File::Basename;
use Storable qw(dclone);
use Cwd;
use Win32::Process;
use File::Copy;
use File::Copy::Recursive qw(dircopy);
use File::stat;
use File::Path qw(remove_tree);
use File::Find;
use File::Slurp;

use LIFT_numerics;
use LIFT_general;
use LIFT_labcar;
use LIFT_functional_layer;
require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  LIFT_SIL_Init
  LIFT_SIL_ConvertIDCSimLogToCSV
  LIFT_SIL_InputFileGenerator
  LIFT_SIL_StartSimulation
  LIFT_SIL_StopSimulation
  LIFT_SIL_Read_Mapping_File
  LIFT_SIL_BuildIDCSim
  LIFT_SIL_ClearE4AStorageDir
  LIFT_SIL_GetE4AStorageSize
  LIFT_SIL_ConfigureCSVInputFile
  LIFT_SIL_CopyE4AFiles2TestDataContainer
  LIFT_SIL_SelectE4ASUT
  LIFT_SIL_PrepareTestEnvironment
  LIFT_SIL_StopTestEnvironment
  LIFT_SIL_BuildSW
);

our ( $sil_mapping_data_href, $sil_output_log_file, $checkpointDir );

my $e4aTestbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );

our ( $VERSION, $HEADER );

my @availableTestbenchFunctionGroups = qw{basic HostPlatform};

my $functionMapping_href = {
	'base' => {
		'SIL' => {
			'LIFT_SIL_Init' => 'LIFT_SIL_Init',    # for documentation purposes only
			'LIFT_SIL_Exit' => 'NONE',
		},
	},
	'basic' => {
		'SIL' => {
			'E4A_Framework::LIFT_SIL::LIFT_SIL_Read_Mapping_File'     => 'LIFT_SIL_Read_Mapping_File',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_GetE4AStorageSize'     => 'LIFT_SIL_GetE4AStorageSize',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_ClearE4AStorageDir'    => 'LIFT_SIL_ClearE4AStorageDir',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_ConvertIDCSimLogToCSV' => 'LIFT_SIL_ConvertIDCSimLogToCSV',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_InputFileGenerator'    => 'LIFT_SIL_InputFileGenerator',
		},
	},

	'HostPlatform' => {
		'QNX' => {
			'E4A_Framework::LIFT_SIL::LIFT_SIL_SelectE4ASUT'                   => 'LIFT_SIL_QNX::LIFT_SIL_QNX_SelectE4ASUT',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_ConfigureCSVInputFile'          => 'LIFT_SIL_QNX::LIFT_SIL_QNX_ConfigureCSVInputFile',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_BuildSW'                        => 'LIFT_SIL_QNX::LIFT_SIL_QNX_BuildSW',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StartSimulation'                => 'LIFT_SIL_QNX::LIFT_SIL_QNX_StartSimulation',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_PrepareTestEnvironment'         => 'LIFT_SIL_QNX::LIFT_SIL_QNX_PrepareE4ATestEnvironment',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StopSimulation'                 => 'LIFT_SIL_QNX::LIFT_SIL_QNX_StopSimulation',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StopTestEnvironment'            => 'LIFT_SIL_QNX::LIFT_SIL_QNX_StopTestEnvironment',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_CopyE4AFiles2TestDataContainer' => 'LIFT_SIL_QNX::LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer',
		},
		'LINUX' => {
			'E4A_Framework::LIFT_SIL::LIFT_SIL_SelectE4ASUT'                   => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_SelectE4ASUT',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_ConfigureCSVInputFile'          => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_ConfigureCSVInputFile',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_BuildSW'                        => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_BuildSW',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StartSimulation'                => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_StartSimulation',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_PrepareTestEnvironment'         => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_PrepareE4ATestEnvironment',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StopSimulation'                 => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_StopSimulation',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StopTestEnvironment'            => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_StopTestEnvironment',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_CopyE4AFiles2TestDataContainer' => 'LIFT_SIL_LINUX::LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer',
		},
		'WINDOWS' => {
			'E4A_Framework::LIFT_SIL::LIFT_SIL_SelectE4ASUT'                   => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_SelectE4ASUT',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_ConfigureCSVInputFile'          => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_ConfigureCSVInputFile',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_BuildSW'                        => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_BuildSW',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StartSimulation'                => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_StartSimulation',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_PrepareTestEnvironment'         => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_PrepareE4ATestEnvironment',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StopSimulation'                 => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_StopSimulation',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_StopTestEnvironment'            => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_StopTestEnvironment',
			'E4A_Framework::LIFT_SIL::LIFT_SIL_CopyE4AFiles2TestDataContainer' => 'LIFT_SIL_WINDOWS::LIFT_SIL_WINDOWS_CopyE4AFiles2TestDataContainer',
		},
	},
};

=head1 NAME

FuncLib_EDR4AD $Revision: 1.2 n
=head1 SYNOPSIS

    use LIFT_SIL

    my $csvFilepath = LIFT_SIL_ConvertIDCSimLogToCSV( $idcsimLogPath);
    
=head1 DESCRIPTION

=head1 FUNCTIONS

=head1 Function Group 'base'

=head2 LIFT_SIL_Init
    
    LIFT_SIL_Init();
    
Initialize the devices for all SIL function groups (basic or HostPlatform).

This function has to be called before calling any other function in this library.
Calls internally the init functions of all devices that are configured in LIFT_Testbenches.pm for this functional module.

B<Note>: Its not needed to call this function explicitly if "EQUIP_init_testbench" was already called.

=cut

sub LIFT_SIL_Init {
	return FL_Init( 'SIL', $functionMapping_href, \@availableTestbenchFunctionGroups );
}

=head1 Function Group 'basic'

=head2 LIFT_SIL_ConvertIDCSimLogToCSV

    my $loghashref = LIFT_SIL_ConvertIDCSimLogToCSV($idcsimLogPath, $csvFilepath);
    
    Extract data from the log file obtained from IDCSIM and Convert store the data in a csv format

B<Arguments:>

=over

=item $idcsimLogPath

Path of the IDSIM log file

=item $csvFilepath

The path where the csv file will be generated

=back

B<Return Values:>

=over

=item $csvFilepath

The path where the csv file will be generated

=back

B<Examples:>

B<Notes:> 

=cut

sub LIFT_SIL_ConvertIDCSimLogToCSV {
	my @args = @_;

	# STEP Fetch the input arguments ($idcsimLogPath and $csvFilepath)
	my $idcsimLogPath = shift @args;
	my $csvFilepath   = shift @args;

	unless ( $idcsimLogPath && -f $idcsimLogPath ) {
		S_set_error( "LIFT_SIL_ConvertIDCSimLogToCSV: IDCSim log file '$idcsimLogPath' is not accessible! Please provide the valid path\n", 1 );
		return;
	}

	# STEP Set the $defaultcsvpath
	my $defaultcsvpath = 'C:\temp\ConvertedIDCSimlog.csv';

	# STEP Set the $csvStoredir as $csvFilepath otherwise set as $defaultcsvpath
	my $csvStoredir = $csvFilepath ? dirname($csvFilepath) : dirname($defaultcsvpath);
	mkdir($csvStoredir) unless ( -d $csvStoredir );
	$csvFilepath = $csvFilepath ? $csvFilepath : $defaultcsvpath;

	# STEP Open the iDCSim log in read mode
	open( my $idcsimfh, "<$idcsimLogPath" );

	# STEP Open the csv log in write mode
	open( my $csvfh, "+>$csvFilepath" );

	my $linenbr = 0;
	my ( $tcName, $inputSignalscnt );

	my $e4aLogfound = 0;

	# STEP Read the log file and store it in a csv format
	while ( my $line = <$idcsimfh> ) {
		if ( $line =~ /E4A>(.*)<E4A/ ) {
			$e4aLogfound = 1;
			my $data = $1;
			$data =~ s/\R//g;
			$data =~ s/^;//g;

			#line with E4A SW version data
			if ( $data =~ /Software Version :(.*)/ ) {
				my $swVersion = $1;
				S_w2log( 3, "LIFT_SIL_ConvertIDCSimLogToCSV : E4A SW version = '$swVersion'\n" );
				next;
			}
			$linenbr++;

			#line with TCname
			if ( $linenbr == 1 ) {
				$tcName = $data;
				my $semicoloncnt = () = $tcName =~ /;/g;
				if ( $semicoloncnt > 1 ) {
					S_set_error( "LIFT_SIL_ConvertIDCSimLogToCSV : IDCSim log format is not valid!", 1 );
					return;
				}
				$tcName =~ s/;//g;
				S_w2log( 3, "LIFT_SIL_ConvertIDCSimLogToCSV : Generating csv file for TestCase : $tcName\n" );
			}
			else {
				#print the header and data lines
				print $csvfh $data . "\n";
			}
		}
	}

	close($idcsimfh);
	close($csvfh);

	unless ($e4aLogfound) {
		S_set_error( "LIFT_SIL_ConvertIDCSimLogToCSV : IDCSim log doesn't have required data lines\n", 1 );
		return;
	}
	S_w2log( 2, "LIFT_SIL_ConvertIDCSimLogToCSV : Successfully generated csv file '$csvFilepath' from IDCSim log '$idcsimLogPath'\n" );

	# STEP Return the $csvFilepath
	return $csvFilepath;
}

=head2 LIFT_SIL_InputFileGenerator

    my $sil_InputFile_path = LIFT_SIL_InputFileGenerator($inputHash);
    
    It generates the input file required for SIL testing.    

B<Arguments:>

=over

=item $inputHash

The signal data obtained from user to be stored in a csv format

B<Return Values:>

=over

=item $sil_InputFile_path

The input file is a csv file containing signal data

=back

B<Examples:>

my $sil_InputFile_path = LIFT_SIL_InputFileGenerator($inputHash);

B<Notes:> 

=cut

sub LIFT_SIL_InputFileGenerator {

	my @args = @_;

	# STEP Fetch the input arguments ($inputHash)
	my $inputHash = shift @args;

	S_w2log( 2, " LIFT_SIL_InputFileGenerator : Start generating the SIL Input File\n" );

	unless ( defined $inputHash ) {
		S_set_warning(" LIFT_SIL_InputFileGenerator : There is no signal input from the testcase parameter file\n");
	}

	# STEP Read the SIL mapping file
	my $sil_data_href = LIFT_SIL_Read_Mapping_File();

	return unless ($sil_data_href);

	# STEP Convert the input obtained from the parameter file into a structure understandable by the function 'LIFT_SIL_InputFileGenerator'
	# CALL ConvertParInp2InputHash
	$inputHash = ConvertParInp2InputHash($inputHash);

	# STEP Resample the signal data obtained from mapping file
	# CALL Resample_edr4ad_input
	my $csv_data_href = Resample_edr4ad_input($inputHash);

	# STEP Write the sampled data into a csv file
	my $sil_csv_InputFile_path = Write_data_to_csv($csv_data_href);

	return unless ($sil_csv_InputFile_path);

	S_w2log( 2, " LIFT_SIL_InputFileGenerator : The SIL Input File is generated in the location '$sil_csv_InputFile_path'\n" );

	# STEP Return $sil_csv_InputFile_path
	return $sil_csv_InputFile_path;
}

=head2 LIFT_SIL_ChangeIDCSim_Shared_Folder_Path

    LIFT_SIL_ChangeIDCSim_Shared_Folder_Path( $shared_Folder_Path );
    
Changes the VM Shared Folder path to $shared_Folder_Path

B<Arguments:>

=over

=item $shared_Folder_Path

Shared folder path to be set in the VMWare

=back

B<Return Values:>

=over

=item $shared_Folder_Path

Returns the shared folder path set in the VMWare

=back

B<Examples:>

$shared_Folder_Path = LIFT_SIL_StartSimulation( $idcsim_Path, $shared_Folder_Path );

B<Notes:> 

=cut

sub LIFT_SIL_ChangeIDCSim_Shared_Folder_Path {
	my @args = @_;

	# STEP Fetch the input arguments ($idcsim_Path, $shared_Folder_Path)
	my $shared_Folder_Path = shift @args;

	unless ( defined $shared_Folder_Path and -d $shared_Folder_Path ) {
		S_set_error( "LIFT_SIL_ChangeIDCSim_Shared_Folder_Path : SIL shared folder path '$shared_Folder_Path' is not valid\n", 1 );
		return;
	}

	# STEP Store the image file path
	my $vm_image_file = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\tools\idcsim\ETAS_RTPC_6_2_1\Debian 6 64-bit.vmx';

	# STEP Start the VM
	ExcecuteVmrunCommand( { operation => 'start', vmxPath => $vm_image_file } );

	# STEP Enable the shared file path
	ExcecuteVmrunCommand( { operation => 'enableSharedFolders', vmxPath => $vm_image_file } );

	#STEP Remove existing shared folder
	ExcecuteVmrunCommand( { operation => 'removeSharedFolder', vmxPath => $vm_image_file, arguments => ['workspace'] } );

	#STEP Add the shared folder 'workspace
	ExcecuteVmrunCommand( { operation => 'addSharedFolder', vmxPath => $vm_image_file, arguments => [ 'workspace', $shared_Folder_Path ] } );

	return $shared_Folder_Path;

}

=head2 LIFT_SIL_Read_Mapping_File

    my $sil_mapping_data_href = LIFT_SIL_Read_Mapping_File();
    
Reads the data from the Mapping_SIL file 

B<Arguments:>

=over

B<Return Values:>

=over

=item $sil_mapping_data_href

hash reference to the data in the Mapping_SIL file

=back

B<Examples:>

B<Notes:> 

=cut

sub LIFT_SIL_Read_Mapping_File {
	my @args = @_;

	# STEP Read the Mapping_SIL content
	$sil_mapping_data_href = S_get_contents_of_hash( ['Mapping_SIL'] );

	unless ($sil_mapping_data_href) {
		S_set_error( "LIFT_SIL_Read_Mapping_File : Failed to fetch data from the 'Mapping_SIL' file\n", 1 );
		return;
	}

	# STEP return $sil_mapping_data_href
	return $sil_mapping_data_href;
}

=head2 LIFT_SIL_GetE4AStorageSize

    $folderSize = LIFT_SIL_GetE4AStorageSize ( [ $folderpath ] );

Returns the size of folder in bytes

If the '$folderpath' is not given E4A directory path is derived using SIL mapping

B<Arguments:>

=over

=item $folderpath

 - Complete path of E4A storage directory

=back

B<Return Values:>

=over

=item $folderSize

 - Folder size in number of bytes

=back

B<Examples:>

LIFT_SIL_GetE4AStorageSize();

=cut

sub LIFT_SIL_GetE4AStorageSize {
	my @args       = @_;
	my $folderpath = shift @args;

	my $foldersize = 0;

	# Derive the E4A storage directory path if not given
	unless ($folderpath) {

		$folderpath = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\output\E4A-logfiles';
		S_w2log( 2, "LIFT_SIL_GetE4AStorageSize : E4A storage directory path is not given. Taking path from E4A config '$folderpath' \n" );
	}

	unless ( -d $folderpath ) {
		S_set_warning("LIFT_SIL_GetE4AStorageSize : Folder '$folderpath' not exists!! Please provide the valid E4A folderpath");
		return;
	}
	find( { wanted => sub { $foldersize += -s if -f }, no_chdir => 1 }, $folderpath );

	S_w2log( 2, "LIFT_SIL_GetE4AStorageSize : Size of E4A storage '$folderpath' is '$foldersize' Bytes \n" );

	return $foldersize;
}

=head2 LIFT_SIL_ClearE4AStorageDir

    $status = LIFT_SIL_ClearE4AStorageDir ( [ $folderpath ] );

Empties the E4A storage directory

If the '$folderpath' is not given E4A directory path is derived using SIL mapping

B<Arguments:>

=over

=item $folderpath

 - Complete path of E4A storage directory

=back

B<Return Values:>

=over

=item $status

 - Returns 1 if the E4A storgae directory is cleared. Undef otherwise

=back

B<Examples:>

LIFT_SIL_ClearE4AStorageDir();

B<Notes:> 

=cut

sub LIFT_SIL_ClearE4AStorageDir {
	my @args       = @_;
	my $folderpath = shift;

	# Derive the E4A storage directory path if not given
	unless ($folderpath) {

		$folderpath = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\output\E4A-logfiles';
		S_w2log( 2, "LIFT_SIL_ClearE4AStorageDir : E4A storage directory path is not given. Taking path from E4A config '$folderpath' \n" );
	}

	unless ( -d $folderpath ) {
		S_set_warning("LIFT_SIL_ClearE4AStorageDir : Folder '$folderpath' not exists!! Please provide the valid E4A folderpath");
		return;
	}

	find(
		{
			wanted => sub {
				if ( -e $_ && -d $_ && $_ ne '.' ) { rmtree $_}
				elsif ( -f $_ ) { unlink $_ }
			  }

		},
		$folderpath
	);

	unless ( LIFT_SIL_GetE4AStorageSize($folderpath) ) {
		S_w2log( 2, "LIFT_SIL_ClearE4AStorageDir : Successfully cleared the E4A directory '$folderpath'\n" );
		return 1;
	}
	else {
		S_w2log( 2, "LIFT_SIL_ClearE4AStorageDir : Failed to clear the E4A directory '$folderpath'\n" );
		return;
	}

}

=head1 Function Group 'HostPlatform'

=head2 LIFT_SIL_StartSimulation

    my $SILInputFile = LIFT_SIL_StartSimulation( $LogfFileName, [$minIdcsimRuntime] );

B<Linux/QNX:>
    
Starts the IDCSim simulation

Checks the log continuously after $minIdcsimRuntime, to check whether the simulation has completed.

B<Windows:>

Executes the host compiled exe

B<Arguments:>

=over

=item $LogfFileName(optional for Windows)

Name of the Sil output LogFile

=item $minIdcsimRuntime(optional for Windows)

Minimum time(approximately) to run the simulation for given input file

If not defined takes the default value 'IDCSim_MinRunTime_S' from mapping

=back

B<Return Values:>

=over

=item $sil_output_log_file

Path of the SIL output log file

=back

B<Examples:>

$sil_output_log_file = LIFT_SIL_StartSimulation( )

$sil_output_log_file = LIFT_SIL_StartSimulation( $LogfFileName );

$sil_output_log_file = LIFT_SIL_StartSimulation( $LogfFileName, $minIdcsimRuntime );

B<Notes:> 

=cut

sub LIFT_SIL_StartSimulation {
	my @args = @_;
	return CallDeviceFunction(@args);
}

=head2 LIFT_SIL_StopSimulation

    my $status = LIFT_SIL_StopSimulation();
    
Kills the IDCSIM, VMWARE and VMRCService process

B<Arguments:>

=over

B<Return Values:>

=over

=item $status

success

=back


B<Examples:>

$status = LIFT_SIL_StopSimulation();

B<Notes:> 

=cut

sub LIFT_SIL_StopSimulation {
	my @args = @_;
	return CallDeviceFunction(@args);

}

=head2 LIFT_SIL_SelectE4ASUT

    $status = LIFT_SIL_SelectE4ASUT ( [$sourceFolderpath] );

-> Copies platform specific binary/exe files from configured path in cfg($LIFT_config::E4A_SW_Path).

-> If $sourceFolderpath is defined, copies the binaries from $sourceFolderpath.

-> If $LIFT_config::E4A_SW_Path is not configured/configured path doesnt exists, existing binary files in simulation directory is considered.

B<Arguments:>

=over

=item $sourceFolderpath

 - Path from where binaries to be copied

=back

B<Return Values:>

=over

=item $status

 - Returns 1 on success, Undef otherwise

=back

B<Examples:>

LIFT_SIL_SelectE4ASUT();

B<Notes:> 

=cut

sub LIFT_SIL_SelectE4ASUT {
	my @args = @_;
	return CallDeviceFunction(@args);

}

=head2 LIFT_SIL_ConfigureCSVInputFile

    $status = LIFT_SIL_ConfigureCSVInputFile ( $scenarioName );

Copies the csv file name from TC par to IDCSim input file location as 'Signal.csv' for Linux/QNX.

Windows - Copies the input files specified(ex: input1.dat input2.dat input3.dat) from configured input location $LIFT_Config::WINCompiled_in to current working directory(as windows executable searches the input files in current working directory)

This function shall be called for every test which has different csv input file to be considered based on scenario.

B<Arguments:>

=over

=item $scenarioName

 - LINUX/QNX : Name of the scenario inidcating the name of csv file, ex: 'triggerOccurance'
 
 - WINDOWS : Name of input files for exe, ex: 'input1.dat input2.dat input3.dat'

=back

B<Return Values:>

=over

=item $status

 - Returns 1 if the configuration is successful. Undef otherwise

=back

B<Examples:>

LIFT_SIL_ConfigureCSVInputFile('multipleTriggerOccurance');

LIFT_SIL_ConfigureCSVInputFile('input1.dat input2.dat input3.dat');

B<Notes:> 

=cut

sub LIFT_SIL_ConfigureCSVInputFile {
	my @args = @_;

	return CallDeviceFunction(@args);

}

=head2 LIFT_SIL_PrepareTestEnvironment

    $status = LIFT_SIL_PrepareTestEnvironment ();

Performs the preconditions before starting the E4A SIL tests

Does the following:

B<LINUX/QNX:>

-> Updates the VMWare shared folder for the simulation

-> Before starting automated tests, Stops the instances of VMWare, IDCSim if it was started manually (To keep error free due to process clash)

-> Creates input and output folders in case of QNX

B<WINDOWS:>

-> Does nothing in case of windows.

B<Arguments:>

=over

=back

B<Return Values:>

=over

=item $status

 - Returns 1 on success, Undef otherwise

=back

B<Examples:>

	LIFT_SIL_PrepareTestEnvironment();
	
B<Notes:> 

=cut

sub LIFT_SIL_PrepareTestEnvironment {
	my @args = @_;

	return CallDeviceFunction(@args);

}

=head2 LIFT_SIL_StopTestEnvironment

    $status = LIFT_SIL_StopTestEnvironment ();

Performs the postconditions after running the E4A SIL tests

Stops the instances of VMWare,vmware-tray and vmware-vmx

B<Arguments:>

=over

=back

B<Return Values:>

=over

=item $status

 - Returns 1 on success, Undef otherwise

=back

B<Examples:>

	LIFT_SIL_StopTestEnvironment();

B<Notes:> 

=cut

sub LIFT_SIL_StopTestEnvironment {
	my @args = @_;
	return CallDeviceFunction(@args);
}

=head2 LIFT_SIL_BuildSW

    $status = LIFT_SIL_BuildSW();

Builds the E4A SW for QNX/Linux

Copies the binary files generated after Build process to the desired location

Windows - Do nothing on function call

B<Arguments:>

=over

=back

B<Return Values:>

=over

=item $status

 - Returns 1 on success, Undef otherwise

=back

B<Examples:>

	LIFT_SIL_BuildSW();

B<Notes:> 

=cut

sub LIFT_SIL_BuildSW {
	my @args = @_;

	return CallDeviceFunction(@args);

}

=head2 LIFT_SIL_CopyE4AFiles2TestDataContainer

    $dirPath = LIFT_SIL_CopyE4AFiles2TestDataContainer ( [$scenarioName] );

B<LINUX/QNX:>

Copies the generated E4A SW logs, IDCSim Simulation logs and E4A SW input CSV files to Testdatacontainer directory.

Testdata container directory shall be configured in Configuration(i.e $LIFT_config::E4A_testDataContainerPath) otherwise by default current report path is considered.

This function creates folderstructure in below manner

								   |--> \E4ARecordLogs
\Report Dir --> \Checkpoint Name --|--> \SimulationTraces
								   |--> ScenarioName.csv
								   
B<WINDOWS:>

								   |--> input1.dat
\Report Dir --> \Checkpoint Name --|--> ..
								   |--> inputN.dat
								   |--> out.dat					   

Checkpoint Name is configured in E4A configuration (i.e $LIFT_config::E4A_SW_Path)

B<Arguments:>

=over

=item $scenarioName

 - LINUX/QNX : Name of the scenario inidcating the name of csv file otherwise Test.csv is considered from simulation path
 
 - QNX : Name of the current TestCase 

=back

B<Return Values:>

=over

=item $dirPath

 - Path of the scenario directory inside the TestdataContainer directory. Undef otherwise.

=back

B<Examples:>

LIFT_SIL_CopyE4AFiles2TestDataContainer('multipleTriggerOccurance');

B<Notes:> 

=cut

sub LIFT_SIL_CopyE4AFiles2TestDataContainer {
	my @args     = shift;
	my $scenario = shift @args;

	my $e4aTestdatacontainerDir = $LIFT_config::E4A_testDataContainerPath;
	unless ( defined $e4aTestdatacontainerDir or -e $e4aTestdatacontainerDir ) {
		$e4aTestdatacontainerDir = "$main::REPORT_PATH";
		S_w2log( 2, "LIFT_SIL_CopyE4AFiles2TestDataContainer : Testdatacontainer path is not configured in cfg/path does not exists. Creating testdatacontainer in : '$e4aTestdatacontainerDir' \n" );
	}

	$e4aTestdatacontainerDir .= '/TestDataContainer';

	#create the testdatacontainer directory
	unless ( -e $e4aTestdatacontainerDir or mkdir $e4aTestdatacontainerDir ) {
		S_set_error("LIFT_SIL_CopyE4AFiles2TestDataContainer : Unable to create Testdatacontainer '$e4aTestdatacontainerDir'\n");
		return;
	}

	#Create folder based on checkpoint name
	unless ( $checkpointDir or -e $checkpointDir ) {
		my $checkpointName;
		my $e4aSwCpPath = $LIFT_config::E4A_SW_Path;
		if ( $e4aSwCpPath && -e $e4aSwCpPath ) {
			$checkpointName = basename($LIFT_config::E4A_SW_Path);
		}
		else {
			S_w2log( 1, " LIFT_SIL_CopyE4AFiles2TestDataContainer : SW Checkpoint is not configured in cfg('$e4aSwCpPath') or configured SW Folder does not exists! Considering name as 'E4ASWCheckpoint' \n" );
			$checkpointName = 'E4ASWCheckpoint';
		}
		$checkpointDir = $e4aTestdatacontainerDir . "/$checkpointName" . S_get_date_extension();

		unless ( mkdir $checkpointDir ) {
			S_set_error("LIFT_SIL_CopyE4AFiles2TestDataContainer : Unable to create checkpoint dir $checkpointName\n");
			return;
		}
	}

	return CallDeviceFunction( $checkpointDir, $scenario );
}

=head1 NOT Exported functions

=head2 Init_SIL

    Init_SIL();

=cut

sub Init_SIL {

	return 1;
}

=head2 Init_LINUX

    Init_LINUX();

=cut

sub Init_LINUX {

	return 1;
}

=head2 Init_WINDOWS

    Init_WINDOWS();

=cut

sub Init_WINDOWS {

	return 1;
}

=head2 Init_QNX

    Init_QNX();

=cut

sub Init_QNX {

	return 1;
}

=head2 Format_edr4ad_input

    $input_data_href = Format_edr4ad_input($default_input_data_href, $simulation_time_ms);
    
    This function takes the default EDR4AD data input and resamples it 

B<Arguments:>

=over

=item $default_input_data_href

 - Default input data href

=item $simulation_time_ms

 - Simulation time to resample the signal time

=back

B<Return Values:>

=over

=item $input_data_href

 - Hash reference where the resampled data is stored

=back

=cut

sub Format_edr4ad_input {

	my @args = @_;

	# STEP Fetch the input arguments ($default_input_data_href, $input_data_href, $simulation_time_ms)
	my $default_input_data_href = shift @args;
	my $input_data_href         = shift @args;

	# STEP Loop over the keys of signal value hash
	foreach my $sig ( keys %$default_input_data_href ) {
		Extract_and_format_inputdata( $default_input_data_href, $sig, $input_data_href );    #Generate ramp values
	}

	# STEP Return the hash containing resampled signal info
	return $input_data_href;
}

=head2 Resample_edr4ad_input

    Format_edr4ad_input($sil_data_href, $inputHash_ref);
    
    This function takes the EDR4AD data input and resamples it 

B<Arguments:>

=over

=item $sil_data_href 

 Contains the default signal data href

=item $inputHash_ref 

 Contains testcase specific signal data hashref
   
=back

B<Return Values:>

=over

=item $input_data_href

 Hash reference where the resampled data is stored

=back

B<Examples:>

=cut

sub Resample_edr4ad_input {

	my @args = @_;

	# STEP Fetch the input arguments ($sil_data_href, $inputHash_ref)
	my $inputHash_ref = shift @args;

	my $input_data_href = {};

	# STEP Resample the default signal input
	# CALL Format_edr4ad_input
	$input_data_href = Format_edr4ad_input( $sil_mapping_data_href->{DefaultSignalValues}, $input_data_href ) if ( exists $sil_mapping_data_href->{DefaultSignalValues} );

	# STEP Resample the Payload signal input
	# CALL Format_edr4ad_input
	$input_data_href = Format_edr4ad_input( $sil_mapping_data_href->{Payload}, $input_data_href ) if ( exists $sil_mapping_data_href->{Payload} );

	# STEP Resample the input from parameter file
	# CALL Format_edr4ad_input
	$input_data_href = Format_edr4ad_input( $inputHash_ref, $input_data_href );    #Generate ramp values

	$input_data_href->{Test_Case_Name} = $sil_mapping_data_href->{Test_Case_Name} if ( exists $sil_mapping_data_href->{Test_Case_Name} );

	# STEP Return $input_data_href
	return $input_data_href;
}

=head2 Extract_and_format_inputdata

    Extract_and_format_inputdata($inputdata_href, $sig, $data_href, $simulation_time_ms);
    
    converts the signals data in the file provided by the user in the below mentioned format
 
                   $data_href=>{
                      Test_case_Name => "EventMonitor", 
                      sig => {
                          sig_name1 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },
                          sig_name2 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },                          
                      }
                   }

B<Arguments:>

=over

=item $inputdata_href 

data fetched from the input file (provided by the user)

=item $sig 

Signal name

=item $simulation_time_ms 

Simulation time to resample the signal time
   
=back

B<Return Values:>

=over

=item $data_href

$data_href as mentioned in the description

=back

B<Examples:>

B<Notes:> 

=cut

sub Extract_and_format_inputdata {

	my @args = @_;

	# STEP Fetch the input arguments ($inputdata_href, $sig, $data_href, $simulation_time_ms)
	my $inputdata_href           = shift @args;
	my $sig                      = shift @args;
	my $data_href                = shift @args;
	my $extracted_inputData_href = $inputdata_href;

	my ( $data_temp_href, $curveFileName, $curve_type, $status );
	my @curve_item_arg;
	my ( $sig_val_aref, $time_val_aref );
	my $output_href;

	my $simulation_time_ms = $sil_mapping_data_href->{SIMULATION_CYCLE_MS} if ( defined $sil_mapping_data_href->{SIMULATION_CYCLE_MS} );

	delete $data_href->{sig}{$sig} if ( exists $data_href->{sig}{$sig} );

	foreach my $data ( @{ $extracted_inputData_href->{$sig}{data} } ) {

		$data =~ s/\s+//g;

		my $curveStruct_href = { 1 => $data };

		foreach my $key_of_hash ( sort { $a <=> $b } keys %{$curveStruct_href} ) {
			my $curve_item = $$curveStruct_href{$key_of_hash};
			@curve_item_arg = split /:/, $curve_item;
			$curve_type = $curve_item_arg[0];

			shift @curve_item_arg;
			foreach (@curve_item_arg) {
				if ( $_ !~ /^\s*\d+((.|,)\d+)?\s*$/ ) {
					S_set_error( "Extract_and_format_inputdata : $_ is not a valid Numeric input", 114 );
					return $status;
				}
			}

			if ( $curve_type =~ /Random$/ ) {

				# STEP Generate random signal values if the type is 'Random'
				( $sig_val_aref, $time_val_aref ) = CreateRandomOnOffCurve( \@curve_item_arg, $simulation_time_ms );
			}
			elsif ( $curve_type =~ /Ramp$/ ) {

				# STEP Generate ramp signal values if the type is 'Ramp'
				$curveFileName = LC_PowerGenCurve($curveStruct_href);
				( $sig_val_aref, $time_val_aref ) = Extract_dataFromCurveFile($curveFileName);    # time returned is in seconds
			}
			else {
				S_set_error( "Extract_and_format_inputdata : Wrong Curve type given : $curve_type", 114 );
				return $status;
			}
		}

		undef $data_temp_href;

		@{ $data_temp_href->{$sig}->{'val'} }  = @$sig_val_aref;
		@{ $data_temp_href->{$sig}->{'time'} } = @$time_val_aref;

		if ($simulation_time_ms) {

			# STEP Resample the ramp or random signal values according to the $simulation_time_ms
			$output_href = Resample_data( $data_temp_href->{$sig}->{'val'}, $data_temp_href->{$sig}->{'time'}[1], $simulation_time_ms );    # time returned is in seconds
			foreach my $val ( @{ $output_href->{dataOutValues_aref} } ) {
				$val = NUM_round2Int($val);
			}
			@{ $data_temp_href->{$sig}->{'val'} }  = @{ $output_href->{dataOutValues_aref} };
			@{ $data_temp_href->{$sig}->{'time'} } = @{ $output_href->{dataOutTimes_aref} };
		}

		push( @{ $data_href->{sig}{$sig}->{'val'} },  @{ $data_temp_href->{$sig}->{'val'} } );
		push( @{ $data_href->{sig}{$sig}->{'time'} }, @{ $data_temp_href->{$sig}->{'time'} } );
		$data_href->{sig}{$sig}->{'unit'} = $extracted_inputData_href->{$sig}{unit};

		$data_href->{sig}{$sig}{'nbr_of_val'} = scalar( @{ $data_href->{sig}{$sig}{'val'} } );
	}

	#STEP Format the time
	my @time_stamps_ms;
	my $time = 0;
	my $time_delta;

	my $nbr_of_val = $data_href->{sig}{$sig}{nbr_of_val};

	foreach my $t ( 0 .. $nbr_of_val - 1 ) {
		$time = $time + $time_delta;
		$time = sprintf( "%.3f", $time );
		push( @time_stamps_ms, $time );
		$time_delta = $simulation_time_ms ? ( $simulation_time_ms / 1000 ) : $data_href->{sig}{$sig}->{'time'}[$t];
	}
	@{ $data_href->{sig}{$sig}->{'time'} } = @time_stamps_ms;

	unlink($curveFileName);

	# STEP return $data_href
	return $data_href;
}

=head2 Write_data_to_csv

    Write_data_to_csv($data_href);
    
    write the data in the signals hashref to csv file
 
                   $data_href=>{
                      Test_case_Name => "EventMonitor", 
                      sig => {
                          sig_name1 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },
                          sig_name2 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },                          
                      }
                   }


B<Arguments:>

=over

=item $data_href 

hash reference containing signal info
   
=back

B<Return Values:>

=over

=item $output_file

csv file containing the signal data

=back

B<Examples:>

B<Notes:> 

=cut 

sub Write_data_to_csv {

	my @args = @_;

	# STEP Fetch the input arguments ($data_href)
	my $data_href = shift @args;

	my $final_hash;

	foreach my $sig ( keys %{ $data_href->{sig} } ) {
		foreach my $i ( 0 .. $data_href->{sig}{$sig}{'nbr_of_val'} - 1 ) {
			$final_hash->{ $data_href->{sig}{$sig}{'time'}[$i] }{$sig} = $data_href->{sig}{$sig}->{'val'}[$i];
		}
	}

	my @endmarker;

	# STEP Assign the complete path for the csv $output_file
	my $output_file = $main::REPORT_PATH . '/' . 'Signal.csv';

	if ( -e $output_file ) {
		unlink $output_file;
	}

	open FH1, ">$output_file";

	#STEP Print the testcase name if undefined
	if ( exists $data_href->{Test_Case_Name} and defined $data_href->{Test_Case_Name} ) {
		print FH1 $data_href->{Test_Case_Name};
		print FH1 "\n";
	}

	# STEP Print the signal names
	my $sig_name_str;

	$sig_name_str = 'timestamp_sec;' if ( $sil_mapping_data_href->{Include_Timestamp} == 1 );
	$sig_name_str = $sig_name_str . join ';', keys %{ $data_href->{sig} };    # revert
	                                                                          #my @temp_sig = ( 'RCM_MajorImpact', 'RCM_MinorImpact', 'PowerLoss', 'NetworkLoss' );
	                                                                          #my $sig_name_str = join ';', @temp_sig;    # revert
	print FH1 $sig_name_str;
	print FH1 "\n";

	my @units;

	#fetch units
	foreach my $sig ( keys %{ $data_href->{sig} } ) {

		#foreach my $sig (@temp_sig) {
		push( @units, $data_href->{sig}{$sig}{unit} );
	}

	# STEP Print the units if undefined
	if ( scalar( grep { defined } @units ) ) {
		unshift( @units, " " );
		my $unit_str = join ';', @units;
		print FH1 $unit_str;
		print FH1 "\n";
	}

	my $prev_sig_val_href;

	# STEP Print the signal values
	foreach my $time ( sort { $a <=> $b } keys %$final_hash ) {
		my @sig_time_values;
		my @time_values;
		my $sig_value;
		undef @endmarker;
		my $time_flag = 0;

		foreach my $sig ( keys %{ $data_href->{sig} } ) {

			#foreach my $sig (@temp_sig) {
			if ( $time_flag == 0 and $sil_mapping_data_href->{Include_Timestamp} == 1 ) {
				push( @sig_time_values, $time );
				$time_flag++;
			}

			if ( exists $final_hash->{$time}{$sig} ) {
				push( @sig_time_values, $final_hash->{$time}{$sig} );
			}
			else {
				push( @sig_time_values, $prev_sig_val_href->{$sig} );
			}

			$prev_sig_val_href->{$sig} = $final_hash->{$time}{$sig} if ( defined $final_hash->{$time}{$sig} );

			if ( $sil_mapping_data_href->{'EndMarker'} ) {
				push( @endmarker, 100 );    #endmarker
			}
		}
		$sig_value = join ';', @sig_time_values;
		print FH1 $sig_value;
		print FH1 "\n";
	}
	print FH1 join ';', @endmarker;

	close FH1;

	# STEP Return the csv output file path
	return $output_file;
}

=head2 Resample_data

    Resample_data($dataIn_aref, $dtIn_sec, $simulation_time_ms);
    
    This function resamples the input data
 
                   $data_href=>{
                      Test_case_Name => "EventMonitor", 
                      sig => {
                          sig_name1 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },
                          sig_name2 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },                          
                      }
                   }


B<Arguments:>

=over

=item $dataIn_aref 

Data to be resampled

=item $dtIn_sec 

time in sec to resample the data

=item $simulation_time_ms 

simulation time in ms
   
=back

B<Return Values:>

=over

=item $data_href

sampled data

=back

B<Examples:>

B<Notes:> 

=cut 

sub Resample_data {

	my @args               = @_;
	my $dataIn_aref        = shift @args;
	my $dtIn_sec           = shift @args;
	my $simulation_time_ms = shift @args;

	# STEP Resample the input Data according to the simulation time

	my $args_href = {
		'dataIn_aref' => $dataIn_aref,                  # input data, to be resampled (type: floating point)
		'dtIn_sec'    => $dtIn_sec,                     # input cycle
		'dtOut_sec'   => $simulation_time_ms / 1000,    # desired output cycle,
	};

	# STEP Return the sampled input_data_href
	return NUM_ResampleData($args_href);

}

=head2 Extract_dataFromCurveFile

    Extract_dataFromCurveFile($curveFileName);
    
    Extracts signal and time data from a curve file 

B<Arguments:>

=over

=item $curveFileName 

Curve filename from where signal data has to be fetched
   
=back

B<Return Values:>

=over

=item @sig_values

array of signal values

=item @time_values

array of time values

=back

B<Examples:>

B<Notes:> 

=cut 

sub Extract_dataFromCurveFile {

	my @args = @_;

	# STEP Fetch the input arguments ($curveFileName)
	my $curveFileName = shift @args;

	unless ( -e $curveFileName ) {
		print "File doesnt exist";
	}

	open FH, "<", $curveFileName;
	my @lines = <FH>;
	close FH;

	my @sig_values;
	my @time_values;

	# STEP Fetch the Signal and time values from the curve file
	foreach my $line (@lines) {
		chomp($line);

		next if ( $line =~ /Dateiname|Punkte|Strombegrenzung|Wiederholungen|U\[V\]/ );

		if ($line) {
			my @data = split /\s/, $line;

			push( @sig_values,  $data[0] );
			push( @time_values, $data[4] );

		}
	}

	# STEP Return @sig_values and @time_values
	return \@sig_values, \@time_values;

}

=head2 CreateRandomOnOffCurve

    ( $status , $volts_aref , $time_aref ) = CreateRandomOnOffCurve( $max_on_voltage, $min_on_voltage,$max_off_voltage , $min_off_voltage, $max_duration );
    e.g. CreateRandomOnOffcurve( 3000, 2000, 700, 500, 12.5, 10.8,1.5,0, 60);

create random voltage curve file (switching on and off at random voltage level for random time under given Boundary conditions).

time $max_on_time,$min_on_time,$max_off_time,$min_off_time in msec, voltage $max_on_voltage, $min_on_voltage,$max_off_voltage ,$min_off_voltage in V and $max_duration in seconds

Source: LIFT_labcar.pm
TurboLIFT Revision: 1.74

=cut

sub CreateRandomOnOffCurve {

	my @args = @_;

	my $randon_inputs_aref = shift @args;
	my $simulation_time_ms = shift @args;
	my @random_curve_input = @$randon_inputs_aref;

	#STEP Get all the mandatory arguments for Random curve
	my ( $valMax, $valMin, $max_duration_sec ) = @random_curve_input;

	my ( @volts, @time );

	my ( $points, $duration );

	$duration = 0;
	$points   = 0;

	my $delta_time = $max_duration_sec / 1000;

	# STEP Generate curve points upto max duration
	while ( $duration < $max_duration_sec and $points <= 1000 ) {

		my $val = rand( $valMax - $valMin ) + $valMin;

		if ( $duration < $max_duration_sec ) {
			push( @volts, $val );
			push( @time,  $delta_time );
			$points++;
		}
		$duration += $simulation_time_ms / 1000;
	}

	# STEP Return the voltage and time values
	return ( \@volts, \@time );
}

=head2 ConvertParInp2InputHash

    ConvertParInp2InputHash($parInp);
    
    Converts the signal input from the parameter file to a format understandable by TurboLIFT
    
    Ex: 
        'RCM_MajorImpact' => { type => 'integer', data => [ 'Ramp:0:0:35', 'Ramp:1:1:12', 'Ramp:0:0:3' ] },   
        'Signal_abc' => { type => 'integer', data => [ 'Random:0:0:35', 'Random:1:1:12', 'Random:0:0:3' ] },           

B<Arguments:>

=over

=item $parInp 

Signal info obtained from the parameter file
   
=back

B<Return Values:>

=over

=item $inputHash

Signal info in the form mentioned above in the documentation

=back

B<Examples:>

B<Notes:> 

=cut 

sub ConvertParInp2InputHash {

	my @args = @_;

	# STEP Fetch the input arguments ($parInp)
	my $parInp = shift @args;

	my $inputHash;    #hash where input for input file generator to be stored

	if ( exists $parInp->{triggerSignal} && exists $parInp->{timeOfTrigger} && exists $parInp->{triggerState} ) {
		my $data;
		if ( $parInp->{timeOfTrigger} > 0 ) {
			$data = [ 'Ramp:0:0:' . $parInp->{timeOfTrigger}, 'Ramp:' . $parInp->{triggerState} . ':' . $parInp->{triggerState} . ':1' ];
		}
		else {
			$data = [ 'Ramp:' . $parInp->{triggerState} . ':' . $parInp->{triggerState} . ':1' ];
		}
		$inputHash = { $parInp->{triggerSignal} => { type => 'integer', data => $data }, };
	}
	else {

		# STEP Parse the input hash obtained from the parameter file and build the valid input hash
		#ex: %( RCM_MinorImpact => 'integer|Ramp:0:0:25|Ramp:2:2:5|Ramp:0:0:34')
		foreach (%$parInp) {

			#remove leading and trailing spaces from key-> to avoid conflicts of having new key
			my $signal = $_;
			$signal =~ s/^\s+//;
			$signal =~ s/\s+$//;
			my $element = 0;
			foreach my $data ( split( /\|/, $parInp->{$_} ) ) {
				$element++;
				if ( $element == 1 ) {
					$inputHash->{$signal}{type} = $data;
					next;
				}
				push @{ $inputHash->{$signal}{data} }, $data;

			}
		}
	}

	# STEP return $inputHash
	return $inputHash;
}

=head2 StopSilInstances

    $status = StopSilInstances($proc2kill_aref);
    
B<Arguments:>

=over

=item $proc2kill_aref 

Array reference of names of process to kill
   
=back

B<Return Values:>

=over

=item $status

Returns 1 in case of success, Undef otherwise

=back

B<Examples:>

	$status = StopSilInstances(['vmware','idcsim']);

B<Notes:> 

=cut 

sub StopSilInstances {
	my @args           = shift;
	my $proc2kill_aref = shift @args;

	unless ( $proc2kill_aref or ref $proc2kill_aref eq 'ARRAY' ) {
		S_set_error( " StopSilInstances : Please provide the valid processnames : \$proc2kill_aref \n", 1 );
		return;
	}

	my %procs = S_get_Win32_processes();
	foreach my $processName (@$proc2kill_aref) {
		if ( exists $procs{$processName} ) {
			S_w2log( 3, "StopSilInstances : Killing $processName !!!\n" );
			kill -9, $_ foreach ( @{ $procs{$processName} } );

			#			Win32::Process::KillProcess( $_, $exitcode ) foreach ( @{ $procs{$processName} } );

			%procs = S_get_Win32_processes();
			if ( exists $procs{$processName} ) {
				S_w2log( 2, " StopSilInstances : Trying 2nd time : kill the process '$processName'\n" );
				S_wait_ms(500);

				#				Win32::Process::KillProcess( $_, $exitcode ) foreach ( @{ $procs{$processName} } );
				kill -9, $_ foreach ( @{ $procs{$processName} } );
				S_wait_ms(500);
				if ( exists $procs{$processName} ) {
					S_set_warning(" StopSilInstances : Couldnt stop '$processName': $^E");
				}
			}
		}
	}
	return 1;
}

=head2 ExcecuteVmrunCommand

    $status = ExcecuteVmrunCommand($params);
    
    Dynamically build the vmrun command and execute it.
    
B<Arguments:>

=over

=item $params 

-> $params->{'operation'} - Openration to be performed on vmx file. ex:start,stop etc

-> $params->{'vmxPath'}   - Full path of vmx file

-> $params->{'arguments'} - array reference of arguments to vmrun command after vmx file

=back

B<Return Values:>

=over

=item $status

Returns 1 in case of success, Undef otherwise

=back

B<Examples:>

	$status = ExcecuteVmrunCommand( { operation => 'addSharedFolder', vmxPath => $vm_image_file, arguments => [ 'workspace', $shared_Folder_Path ] } );

B<Notes:> 

=cut 

sub ExcecuteVmrunCommand {
	my @args      = shift;
	my $params    = shift @args;
	my $operation = $params->{'operation'};
	my $vmxPath   = $params->{'vmxPath'};
	my $arguments = $params->{'arguments'};

	my $vm_exe_path = "$LIFT_config::VmwareExePath";

	# STEP Fetch the current working directory
	my $original_working_directory = getcwd();    #Fetch the current working directory

	# STEP Change the current directory to vm exe path to run the vm related commands
	chdir $vm_exe_path;

	#Prepare the vmrun command
	my $cmd2run = "vmrun $operation \"$vmxPath\" ";

	$cmd2run .= join( ' ', @$arguments ) if ($arguments);

	#Execute the command
	S_w2log( 3, " ExcecuteVmrunCommand : Executing VM command '$cmd2run'\n" );
	system($cmd2run);

	chdir $original_working_directory;

	return 1;

}

=head2 StartVMWareandWait2boot

    $status = StartVMWareandWait2boot($machine2waitbooting);
        
B<Arguments:>

=over

=item $machine2waitbooting 

- Machines(IP address) for which wait till complete boot up

=back

B<Return Values:>

=over

=item $status

Returns 1 in case of success, Undef otherwise

=back

B<Examples:>


B<Notes:> 

=cut 

sub StartVMWareandWait2boot {
	my @args                = shift;
	my $machine2waitbooting = shift @args;

	my $pingObj = Net::Ping->new();

	#Start the VMs if its not started already
	unless ( $pingObj->ping($machine2waitbooting) ) {
		my $simMaster_image_file = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\tools\idcsim\ETAS_RTPC_6_2_1\Debian 6 64-bit.vmx';
		E4A_Framework::LIFT_SIL::ExcecuteVmrunCommand( { operation => 'start', vmxPath => $simMaster_image_file } );

		my $simMTASlave_image_file = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\build\simMtaSlave\IDCSim_MTA.vmx';
		E4A_Framework::LIFT_SIL::ExcecuteVmrunCommand( { operation => 'start', vmxPath => $simMTASlave_image_file } );

		my $simSlave_image_file = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\build\simSlave\IDCSim_Slave.vmx';
		E4A_Framework::LIFT_SIL::ExcecuteVmrunCommand( { operation => 'start', vmxPath => $simSlave_image_file } );
	}

	#wait for 10 secs to see if machine has booted up
	foreach ( 1 .. 10 ) {
		if ( $pingObj->ping($machine2waitbooting) ) {
			S_w2log( 1, "StartVMWareandWait2boot : '$machine2waitbooting' is ready!\n " );
			last;
		}
		else {
			S_w2log( 1, "StartVMWareandWait2boot : Waiting for '$machine2waitbooting' to boot up\n " );
			S_wait_ms(1000);
			if ( $_ == 10 ) {
				if ( $pingObj->ping($machine2waitbooting) ) {
					S_w2log( 1, "StartVMWareandWait2boot : '$machine2waitbooting' is ready!\n " );
				}
				else {
					S_set_error( "StartVMWareandWait2boot : '$machine2waitbooting' failed to boot up\n ", 5 );
					return;
				}
			}
		}
	}

	return 1;
}

=head2 SyncDaiRepoWithRWS

   $status = SyncDaiRepoWithRWS();
 
synchronizes the Dai repository with the updated RWS.
    
=cut

sub SyncDaiRepoWithRWS {
	my @args = @_;

	my $repoBasePath   = "$LIFT_config::E4A_SWRepoPath";
	my $e4aLinuxFolder = $repoBasePath . '\idc5\dai_idc5_apl\component\e4a';
	my $e4aQnxFolder   = $repoBasePath . '\idc5\up_apl\dai_idc5\swcs\e4a';
	my $e4aRWSPath     = "$LIFT_config::E4A_RWSPath";

	S_w2log( 2, "SyncDaiRepoWithRWS : Synchronizing the e4a code from RWS '$e4aRWSPath' to Dai repository '$repoBasePath'!\n" );

	#Check if the configured RWS path exists
	unless ( -e $e4aRWSPath ) {
		S_set_warning("SyncDaiRepoWithRWS : Configured E4A RWS is not present! Will continue to run without synchronizing!");
		return;
	}

	#delete the existing E4A folder from Linux and QNX
	unless ( remove_tree($e4aLinuxFolder) and remove_tree($e4aQnxFolder) ) {
		S_set_error("SyncDaiRepoWithRWS : Failed to delete the existing E4A folder from Dai repository!");
		return;
	}

	#copy the e4a folder from RWS to dai repository
	unless ( dircopy( $e4aRWSPath, $e4aLinuxFolder ) ) {
		S_set_error("SyncDaiRepoWithRWS : Failed to copy E4A folder from RWS to Dai repository!");
		return;
	}

	unless ( dircopy( $e4aRWSPath, $e4aQnxFolder ) ) {
		S_set_error("SyncDaiRepoWithRWS : Failed to copy E4A folder from RWS to Dai repository!");
		return;
	}

	#for Linux copy flist files
	my $flistFolderpath = $e4aLinuxFolder . '\Project\IDCSim_Linux';
	my @flistFiles      = glob( $flistFolderpath . '\*.flist' );

	#copy flist files to e4a base folder
	foreach (@flistFiles) {
		copy( $_, $e4aLinuxFolder );
	}
	return 1;

}

=head2 CallDeviceFunction

   $status = CallDeviceFunction('SIL', $functionMapping_href, @args);
 
Calls the device mapped function under $functionMapping_href.  
    
=cut

sub CallDeviceFunction {
	my @args = @_;
	return FL_CallDeviceFunction( 'SIL', $functionMapping_href, @args );
}

############################################################################################################
#
#
# package LIFT_SIL_QNX
#
#
############################################################################################################

package LIFT_SIL_QNX;

use strict;
use warnings;

use Cwd;
use File::Copy;
use File::Slurp qw(read_file write_file);
use Net::Ping;
use File::Basename;
use Digest::MD5 qw(md5_hex);

use LIFT_general;
use E4A_Framework::LIFT_SIL;

our $inputFilePath_abs;

sub LIFT_SIL_QNX_BuildSW {
	my @args = shift;

	#Synchronize the repository
	E4A_Framework::LIFT_SIL::SyncDaiRepoWithRWS() || return;

	S_w2log( 1, " Building the SW for QNX.This may take few mins. Please wait..\n" );

	#Switch to Linux by updating following files before building
	#CMakeLists.txt
	#enha_br223_idcsim.flist
	#App_BSW_Sim.c
	#Task_Appl_idcsim.c
	Switch2QNX() || return;

	#read the bacthfile path for QNX
	my $swBuildbatchfileDir_qnx    = $LIFT_config::E4A_SWRepoPath . '\idc5';
	my $original_working_directory = getcwd();                                 #Fetch the current working directory
	                                                                           #change the directory before running batch file
	chdir $swBuildbatchfileDir_qnx;

	#change the batch file to build the QNX to not have any keypress. This holds the TurboLIFT to wait until a keypress is made
	# in batch file: replace set "WAIT4KEYPRESS=pause" => set "WAIT4KEYPRESS=exit"
	# create new file only when its not already generated
	my $buildfileNew = 'build_project_auto.bat';
	unless ( -e $buildfileNew ) {
		copy( "build_project.bat", $buildfileNew );
		my $data = read_file $buildfileNew, { binmode => ':utf8' };
		$data =~ s/set "WAIT4KEYPRESS=pause"/set "WAIT4KEYPRESS=exit"/g;
		write_file $buildfileNew, { binmode => ':utf8' }, $data;
	}

	my $buildlogfile = 'C:\temp\QNXBUILDLOG_' . S_get_date_extension() . '.log';
	S_w2log( 2, " LIFT_SIL_QNX_BuildSW : Starting the SW build. Output is being logged to '$buildlogfile'\n" );

	my ( $buildStatus, @buildoutput ) = S_call_command("$buildfileNew TARGET_SIM_VALIDATION RELEASE FAST > $buildlogfile");

	#change the dir to original working directory
	chdir $original_working_directory;

	#revert back the changes
	Switch2QNX( { revert => 1 } ) || return;
	if ($buildStatus) {

		S_w2log( 1, " LIFT_SIL_QNX_BuildSW : Build successfully completed!\n" );
		my $buildresultDir = $LIFT_config::E4A_SWRepoPath . '\idc5\build\TARGET_SIM_VALIDATION-NODE_SLAVE-MIDDLEWARE_RTE-PROJECT_dai_idc5';
		LIFT_SIL_QNX_SelectE4ASUT($buildresultDir);

	}
	else {
		S_set_error( " LIFT_SIL_QNX_BuildSW : Build Failed! Please check build log '$buildlogfile' for more intomation \n", 5 );
	}

	return $buildlogfile;
}

sub LIFT_SIL_QNX_PrepareE4ATestEnvironment {
	my @args = shift;

	#Before starting automated tests, Stop the instances of VMWare, IDCSim if it was started manually (To keep error free)
	E4A_Framework::LIFT_SIL::StopSilInstances( [ 'VMRCService', 'vmware', 'vmware-vmx', 'vmware-tray', 'idcsim' ] );

	my $qnxIPaddress = $e4aTestbench->{'Devices'}{'QNX'}{'IP_address'};
	unless ($qnxIPaddress) {
		S_set_error( "LIFT_SIL_QNX_PrepareE4ATestEnvironment : QNX IP_address is not configured in E4A Testbench!", 1 );
		return;
	}
	E4A_Framework::LIFT_SIL::StartVMWareandWait2boot($qnxIPaddress) || return;

	#create folder to place input csv files in QNX using Plink
	#Plink and pscp commands are by default part of IDCsim repository. In the path same as Idcsim.exe
	my $original_working_directory = getcwd();    #Fetch the current working directory

	#change the directory to where pscp and plink executables are present
	my $plinkPscpDir = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\tools\idcsim\RuntimeFrame';
	chdir($plinkPscpDir);

	#execute command to create E4A input dir in QNX. ex: E4A/input
	my $silInpFileQnx = "/root/E4A/input";
	S_w2log( 2, "LIFT_SIL_QNX_PrepareE4ATestEnvironment : Creating '$silInpFileQnx' folder in QNX\n" );
	my ( $status, @cmdoutput ) = S_call_command("plink $qnxIPaddress -l root mkdir -p $silInpFileQnx");
	unless ($status) {
		S_set_error( "LIFT_SIL_QNX_PrepareE4ATestEnvironment : Failed to create '$silInpFileQnx' folder in QNX. Error :" . join( "\n", @cmdoutput ), 1 );
		return;
	}

	#execute command to create E4A output dir in QNX. ex: E4A/output
	my $silOutputfileQnx = "/root/E4A/output/E4A-logfiles";
	S_w2log( 2, "LIFT_SIL_QNX_PrepareE4ATestEnvironment : Creating '$silOutputfileQnx' folder in QNX\n" );
	( $status, @cmdoutput ) = S_call_command("plink $qnxIPaddress -l root mkdir -p $silOutputfileQnx");
	unless ($status) {
		S_set_error( "LIFT_SIL_QNX_PrepareE4ATestEnvironment : Failed to create '$silOutputfileQnx' folder in QNX. Error :" . join( "\n", @cmdoutput ), 1 );
		return;
	}

	#change back to original working directory
	chdir $original_working_directory;

	return 1;
}

sub LIFT_SIL_QNX_ConfigureCSVInputFile {
	my @args         = @_;
	my $scenarioName = shift @args;

	unless ($scenarioName) {
		S_set_error( "LIFT_SIL_ConfigureCSVInputFile : Scenario name is not specified in par file", 1 );
		return;
	}

	my $inputCSVfolderPath = $LIFT_config::E4A_ScenariosPath;
	my $inputFilePath      = $inputCSVfolderPath . "\\$scenarioName" . '.csv';

	unless ( -e $inputCSVfolderPath ) {
		S_set_error( "LIFT_SIL_ConfigureCSVInputFile : Input directory('$inputCSVfolderPath') containing csv files does not exists!", 1 );
		return;
	}
	unless ( -e $inputFilePath ) {
		S_set_error( "LIFT_SIL_ConfigureCSVInputFile : Input csv file $scenarioName.csv  not found in '$inputCSVfolderPath' ", 1 );
		return;
	}

	$inputFilePath_abs = File::Spec->rel2abs($inputFilePath);

	#Plink and pscp commands are by default part of IDCsim repository. In the path same as Idcsim.exe
	my $original_working_directory = getcwd();                                          #Fetch the current working directory
	my $qnxIPaddress               = $e4aTestbench->{'Devices'}{'QNX'}{'IP_address'};

	E4A_Framework::LIFT_SIL::StartVMWareandWait2boot($qnxIPaddress) || return;

	#change the directory to where pscp and plink executables are present
	my $plinkPscpDir = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\tools\idcsim\RuntimeFrame';
	chdir($plinkPscpDir);

	#execute command delete the existing input file from QNX input folder
	S_w2log( 2, " LIFT_SIL_QNX_ConfigureCSVInputFile : Deleting the existing input file from QNX before copying '$inputFilePath'\n" );
	my $silInpFileQnx = "/root/E4A/input";
	my ( $status, @cmdoutput ) = S_call_command("plink $qnxIPaddress -l root rm -f $silInpFileQnx/Signal.csv");
	unless ($status) {
		S_set_error( "LIFT_SIL_QNX_ConfigureCSVInputFile : Failed to delete the existing input file from QNX :" . join( "\n", @cmdoutput ), 1 );
	}

	#execute command to copy input file to QNX input folder
	S_w2log( 2, " LIFT_SIL_QNX_ConfigureCSVInputFile : Copying the input csv file '$inputFilePath_abs' to QNX input folder '$silInpFileQnx' \n" );
	( $status, @cmdoutput ) = S_call_command( "pscp -scp $inputFilePath_abs root@" . $qnxIPaddress . ":$silInpFileQnx//Signal.csv" );
	unless ($status) {
		S_set_error( "LIFT_SIL_QNX_ConfigureCSVInputFile : Failed to copy IDCSim input file to QNX. Error :" . join( "\n", @cmdoutput ), 1 );
	}

	chdir($original_working_directory);
	return 1;

}

sub LIFT_SIL_QNX_StartSimulation {
	my @args = @_;

	# STEP Fetch the input arguments ($log_FileName)
	my $log_FileName     = shift @args;
	my $minIdcsimRuntime = shift @args;
	unless ( defined $log_FileName ) {
		S_set_error( "LIFT_SIL_QNX_StartSimulation : Log Filename is not defined\n", 1 );
		return;
	}

	# STEP Set the default path of '$idc_SimPath', '$csv_file_path', '$sil_output_log_file' and '$idcsim_exe_cmd'
	my $idc_SimPath         = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\tools\idcsim\RuntimeFrame';
	my $idcsimOutputFiledir = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\\E4A\output';

	#Idcsim appends _0 while generating logfile
	my $generatedLogFileName = $log_FileName . '_0.log';
	$sil_output_log_file = $idcsimOutputFiledir . "\\$generatedLogFileName";
	my $idcsim_exe_cmd = 'idcsim.exe -c -m ' . $LIFT_config::E4A_IDCSimBasePath . '\005_20180517_080840_Manual_HDR___IDC_FR_ESP__stripped.dat' . ' --logfile ' . $idcsimOutputFiledir . "\\$log_FileName";

	unless ( defined $idc_SimPath and -e $idc_SimPath ) {
		S_set_error( "LIFT_SIL_QNX_StartSimulation : The idcsim Path '$idc_SimPath' does not exists!\n", 1 );
		return;
	}
	unless ( -e $idcsimOutputFiledir or mkdir $idcsimOutputFiledir ) {
		S_set_error( "LIFT_SIL_QNX_StartSimulation : Failed to create the output directory '$idcsimOutputFiledir'\n", 1 );
		return;
	}

	#Get the last line of input csv file
	unless ( open( FH, '<', $inputFilePath_abs ) ) {
		S_set_error( "Could not open file '$inputFilePath_abs' $!", 1 );
		return;
	}
	my @inputdata = <FH>;
	close(FH);
	my $lastinputline = $inputdata[-1];
	my $referenceTime = ( split( /;/, $lastinputline ) )[0];

	my $original_working_directory = getcwd();    #Fetch the current working directory

	S_w2log( 2, " LIFT_SIL_QNX_StartSimulation : Change the working directory from '$original_working_directory' to '$idc_SimPath' to run the IDCSIM exe\n" );

	# STEP Change the current working directory to '$idc_SimPath'
	chdir $idc_SimPath;

	$sil_mapping_data_href = E4A_Framework::LIFT_SIL::LIFT_SIL_Read_Mapping_File();

	my $time_to_stop_idcsim_exe_s = $minIdcsimRuntime;

	$time_to_stop_idcsim_exe_s = $sil_mapping_data_href->{IDCSim_MinRunTime_S} unless $time_to_stop_idcsim_exe_s;

	my $maxTime2runSimulation_s = $sil_mapping_data_href->{IDCSim_MaxRunTime_S};

	S_w2log( 2, " LIFT_SIL_QNX_StartSimulation : Execute the IDCSIM exe for minimum '$time_to_stop_idcsim_exe_s' seconds\n" );
	my $idcsimStartTime = time();

	# STEP Stop the IDCSIM after '$time_to_stop_idcsim_exe_s' seconds
	eval {

		local $SIG{ALRM} = sub { die "alarm\n" };
		alarm $time_to_stop_idcsim_exe_s;
		S_w2log( 2, "LIFT_SIL_QNX_StartSimulation: Start the IDCSIM simulation. execute command '$idcsim_exe_cmd'" );
		system($idcsim_exe_cmd);
		alarm 0;

	};

	# STEP Change the working directory to original working directory
	S_w2log( 2, " LIFT_SIL_QNX_StartSimulation : Change the working directory from '$idc_SimPath' to '$original_working_directory' ie to the initial workign directory\n" );
	chdir $original_working_directory;

	S_w2log( 2, " LIFT_SIL_QNX_StartSimulation : Read IDCSim log for every 1s interval to check if it has reached end of Simulation", 'blue' );
	my ( $content, $idcsimlogChecksumOld, $idcsimlogChecksumNew, $idcsimRuntime );
	my ( $idcsimLogidlecount, $donereadinginputfile ) = ( 0, 0 );
	do {

		#calculate idcsimfilelog checksum
		$idcsimlogChecksumOld = md5_hex( read_file($sil_output_log_file) );

		#read the updated idcsim log
		unless ( open( FH, '<', $sil_output_log_file ) ) {
			S_set_error( "Could not open file '$sil_output_log_file' $!", 1 );
		}
		$content = join( '', <FH> );
		close(FH);

		if ( $content =~ /Simulation time is 19s[\s\S]*E4A>\d+;$referenceTime;/ ) {
			$donereadinginputfile = 1;
			S_w2log( 2, " LIFT_SIL_QNX_StartSimulation : Reached the end of Simulation!!\n" );
		}

		#calculate new checksum for idcsim log
		$idcsimlogChecksumNew = md5_hex( read_file($sil_output_log_file) );

		if ( !$donereadinginputfile && $idcsimlogChecksumOld eq $idcsimlogChecksumNew ) {

			#Check if IDCSim log has not changed in last 20s
			foreach ( 1 .. 20 ) {
				$idcsimLogidlecount++;
				$idcsimlogChecksumNew = md5_hex( read_file($sil_output_log_file) );
				if ( $idcsimlogChecksumOld eq $idcsimlogChecksumNew ) {
					S_wait_ms(1000);
					if ( $idcsimLogidlecount == 20 ) {
						S_set_error( "LIFT_SIL_QNX_StartSimulation : There was no update in the IDCSim log in last 20s", 1 );
						$donereadinginputfile = 1;
					}
				}
				else {
					$idcsimLogidlecount = 0;
					last;
				}
			}
		}

		#get the current time
		$idcsimRuntime = time() - $idcsimStartTime;

	} while ( !$donereadinginputfile && $idcsimRuntime < $maxTime2runSimulation_s );

	if ( !$donereadinginputfile && $idcsimRuntime > $maxTime2runSimulation_s ) {
		S_set_warning(" LIFT_SIL_QNX_StartSimulation : IDCSim simulation is taking longer time('$idcsimRuntime' seconds) than expected. Please check IDCsim log for more information");
	}

	if ( $content =~ /Software Version :(.*)/ ) {
		S_w2log( 2, "E4A Software Version = '$1'\n", 'Green' );
	}

	unless ( -e $sil_output_log_file ) {
		S_set_error( "LIFT_SIL_QNX_StartSimulation : Failed to create the SIL output log file in the path '$idc_SimPath'\n", 1 );
		return;
	}

	CopyE4ALogFromQNX2Host();

	unless ($donereadinginputfile) {
		if ( $content =~ /Unable to find vECU executable/ ) {
			S_set_error( "LIFT_SIL_QNX_StartSimulation : ERROR! Check if the VMWare shared folder is configured correctly!\n", 1 );
		}
		elsif ( $content =~ /Initializing SOME\/IP services for \d+\.\d+\.\d+\.\d+$/ ) {
			S_set_error( "LIFT_SIL_QNX_StartSimulation : ERROR! Possible reasons: 1) VMWare, IDCSim process from previous execution was not stopped properly\n 2) Check if IDCSim Input file(i.e csv) is in proper format\n", 1 );
		}
		elsif ( $content =~ /E4A>;(.*)<E4A/ ) {
			S_set_error( "LIFT_SIL_QNX_StartSimulation : Required E4A log lines are not present in IDCSim log \n", 1 );
		}
		else {
			S_set_error( "LIFT_SIL_QNX_StartSimulation : Error found while running simulation. Please check IDCSim log : '$sil_output_log_file'\n", 1 );
		}
	}

	# STEP Return '$sil_output_log_file'
	return $sil_output_log_file;
}

sub LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer {
	my @args              = @_;
	my $checkpointDirPath = shift @args;
	my $scenario          = shift @args;

	my $scenarioDir = $scenario ? $checkpointDirPath . "/$scenario" : $checkpointDirPath . "//$main::CURRENT_TC";
	unless ( -e $scenarioDir or mkdir $scenarioDir ) {
		S_set_error("LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : Unable to create Scenario dir '$scenarioDir' in Testdatacontainer \n");
		return;
	}

	#Copy the scenario input file
	my $scenarioFilePath = $scenario ? $LIFT_config::E4A_ScenariosPath . "/$scenario.csv" : $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\input\Signal.csv';
	S_w2log( 1, " LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : Copying Input Scenario file '$scenarioFilePath' to '$scenarioDir'\n" );
	copy( $scenarioFilePath, $scenarioDir );

	#create directory for E4A record logs and Simulation traces
	my $e4aRecordlogDir = $scenarioDir . "/E4ARecordLogs";
	unless ( mkdir $e4aRecordlogDir ) {
		S_set_error("LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : Unable to create E4A record log dir $e4aRecordlogDir\n");
		return;
	}

	my $e4aStoragedir = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\output\E4A-logfiles';
	my $dir;
	unless ( opendir( $dir, $e4aStoragedir ) ) {
		S_set_warning("LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : Failed to open directory '$e4aStoragedir': $!");
		return;
	}
	my @e4A_logs = readdir($dir);
	closedir $dir;
	foreach my $logfile (@e4A_logs) {
		if ( -f "$e4aStoragedir/$logfile" ) {
			S_w2log( 1, " LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : Copying E4A log '$logfile' to '$e4aRecordlogDir'\n" );
			copy( "$e4aStoragedir/$logfile", $e4aRecordlogDir );
		}
	}

	my $e4aSimuTraceDir = $scenarioDir . "/SimulationTraces";
	unless ( mkdir $e4aSimuTraceDir ) {
		S_set_error("LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : Unable to create E4A Simulation trace dir $e4aSimuTraceDir\n");
		return;
	}

	#copy IDCSim log
	unless ( $sil_output_log_file or -e $sil_output_log_file ) {
		S_set_error("LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : IDCSim simulation log is not generated\n");
		return;
	}

	S_w2log( 1, " LIFT_SIL_QNX_CopyE4AFiles2TestDataContainer : Copying IDCSim log '$sil_output_log_file' to '$e4aSimuTraceDir'\n" );
	copy( $sil_output_log_file, $e4aSimuTraceDir );

	my $ConvertedcsvPath = E4A_Framework::LIFT_SIL::LIFT_SIL_ConvertIDCSimLogToCSV($sil_output_log_file);
	copy( $ConvertedcsvPath, $e4aSimuTraceDir ) if ( -e $ConvertedcsvPath );

	return $scenarioDir;
}

sub CopyE4ALogFromQNX2Host {
	my @args = @_;

	my $e4aLogdir    = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\output\E4A-logfiles';
	my $qnxIPaddress = $e4aTestbench->{'Devices'}{'QNX'}{'IP_address'};

	S_w2log( 2, " CopyE4ALogFromQNX2Host : Copy the E4A logs generated in QNX to host '$e4aLogdir'!\n" );

	#QNX should be running for copying the E4A logs
	E4A_Framework::LIFT_SIL::StartVMWareandWait2boot($qnxIPaddress) || return;

	unless ( -e $e4aLogdir or mkdir $e4aLogdir ) {
		S_set_error( "CopyE4ALogFromQNX2Host : Failed to create the E4A Log directory '$e4aLogdir'\n", 1 );
		return;
	}

	my $original_working_directory = getcwd();    #Fetch the current working directory

	#change the directory to where pscp and plink executables are present
	my $plinkPscpDir = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\tools\idcsim\RuntimeFrame';
	chdir($plinkPscpDir);

	#execute command delete the existing input file from QNX input folder
	my $silOutputfileQnx = "/root/E4A/output/E4A-logfiles";

	my ( $status, @cmdoutput ) = S_call_command( "pscp -scp -unsafe root@" . "$qnxIPaddress:" . $silOutputfileQnx . "/*.* $e4aLogdir" );
	chdir($original_working_directory);

	unless ($status) {
		S_set_error( "CopyE4ALogFromQNX2Host : ERROR! Please check if the E4A logs are generated in QNX! :" . join( "\n", @cmdoutput ), 1 );
		return;
	}
	return 1;
}

sub LIFT_SIL_QNX_SelectE4ASUT {
	my @args             = @_;
	my $sourceFolderpath = shift @args;

	#get the folder where SW binaries are located
	my $e4aSwCpPath = $sourceFolderpath;
	unless ($e4aSwCpPath) {
		$e4aSwCpPath = $LIFT_config::E4A_SW_Path;
		unless ( $e4aSwCpPath or -e $e4aSwCpPath ) {
			S_set_warning("LIFT_SIL_QNX_SelectE4ASUT : 'E4A_SW_Path' is not configured in E4A cfg or Configured path does not exists! Will continue to run using existing SW. \n");
			return;
		}
	}

	my @e4aSwFiles = glob( $e4aSwCpPath . "/*.*" );

	my @binaryFilesQnx = ( 'IDCSim_Slave.vmdk', 'IDCSim_Slave.vmx', 'IDCSim_Slave-flat.vmdk', 'IDCSim_MTA.vmdk', 'IDCSim_MTA.vmx', 'IDCSim_MTA-flat.vmdk' );
	my @files2CopyQnx;
	foreach my $binFile (@binaryFilesQnx) {
		my ($binFilename) = grep ( /$binFile/, @e4aSwFiles );
		unless ($binFilename) {
			S_set_warning("LIFT_SIL_QNX_SelectE4ASUT : Required SW file ('$binFile') is not present in '$e4aSwCpPath'! Will continue to run using existing SW. \n");
			return;
		}
	}

	S_w2log( 2, "LIFT_SIL_QNX_SelectE4ASUT : E4A SW Version: '" . basename($e4aSwCpPath) . "'\n" ) unless ($sourceFolderpath);

	my $simMtaSlavePath = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\build\simMTASlave';
	my $simSlavePath    = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\build\simSlave';
	foreach my $buildopfile (@binaryFilesQnx) {
		my $fullpath = $e4aSwCpPath . "/$buildopfile";
		if ( -e $fullpath ) {
			my $simDirpath = ( $buildopfile =~ /MTA/i ) ? $simMtaSlavePath : $simSlavePath;

			#delete the existing file in the destination folder
			unlink( $simDirpath . "\\$buildopfile" );

			if ( copy( $fullpath, $simDirpath ) ) {
				S_w2log( 1, "LIFT_SIL_QNX_SelectE4ASUT : Copied '$fullpath' to '$simDirpath'\n" );
			}
			else {
				S_set_error( "LIFT_SIL_QNX_SelectE4ASUT : Failed to copy '$fullpath' to '$simDirpath'. You may not have permission!\n", 1 );
				return;
			}
		}
		else {
			S_set_error( "LIFT_SIL_QNX_SelectE4ASUT : File generated from SW Build : '$buildopfile' does not exists!", 1 );
			return;
		}

	}

	#copy E4A disabled LINUX binaries to simMaster
	my $package = (caller)[0];

	#avoid recursive call
	if ( $package ne 'LIFT_SIL_LINUX' ) {
		my $e4aDisabledBinaries = "$LIFT_config::E4A_disabledBinaryPathLinux";
		S_w2log( 2, "LIFT_SIL_QNX_SelectE4ASUT : Copying E4A Disabled Linux binaries from '$e4aDisabledBinaries' \n" );
		LIFT_SIL_LINUX::LIFT_SIL_LINUX_SelectE4ASUT($e4aDisabledBinaries);
	}
	return 1;

}

sub LIFT_SIL_QNX_StopSimulation {
	my @args = @_;

	S_w2log( 2, " LIFT_SIL_QNX_StopSimulation :Stopping the 'IDCSIM' and 'VMRCService'\n" );

	# STEP Stop the processes 'VMRCService' and 'idcsim' if they exist
	E4A_Framework::LIFT_SIL::StopSilInstances( [ 'idcsim', 'VMRCService', 'vmware-vmx' ] );

	return 1;
}

sub LIFT_SIL_QNX_StopTestEnvironment {
	my @args = @_;

	S_w2log( 2, " LIFT_SIL_QNX_StopTestEnvironment : Stopping the VMware instances\n" );

	#Stop Vmware instance
	E4A_Framework::LIFT_SIL::StopSilInstances( [ 'vmware', 'vmware-tray', 'vmware-vmx' ] );

	return 1;
}

sub Switch2QNX {
	my @args   = @_;
	my $params = shift @args;

	my $idcsimRepoPath = $LIFT_config::E4A_SWRepoPath;

	#<repo>\idc5\up_apl\dai_idc5\swcs\CMakeLists.txt
	my $cmakelistFile = $idcsimRepoPath . '\idc5\up_apl\dai_idc5\swcs\CMakeLists.txt';

	#<repo>\idc5\dai_idc5_apl\tools\builder\enha_br223_idcsim.flist
	my $flistfile = $idcsimRepoPath . '\idc5\dai_idc5_apl\tools\builder\enha_br223_idcsim.flist';

	#<repo>\idc5\up_apl\dai_idc5\apps\App_BSW_Sim.c
	my $bswSimfile = $idcsimRepoPath . '\idc5\up_apl\dai_idc5\apps\App_BSW_Sim.c';

	#<repo>\idc5\dai_idc5_apl\main\Task_Appl_idcsim.c
	my $applIdcsimFile = $idcsimRepoPath . '\idc5\dai_idc5_apl\main\Task_Appl_idcsim.c';

	if ( $params->{revert} ) {

		#copy back to the original version
		copy( $cmakelistFile . ".TLbackup",  $cmakelistFile );
		copy( $flistfile . ".TLbackup",      $flistfile );
		copy( $bswSimfile . ".TLbackup",     $bswSimfile );
		copy( $applIdcsimFile . ".TLbackup", $applIdcsimFile );
	}
	else {

		#before updating take a backup of CMakeLists.txt
		unless ( -e $cmakelistFile ) {
			S_set_error( " Switch2QNX : '$cmakelistFile' does not exists!", 1 );
			return;
		}
		copy( $cmakelistFile, $cmakelistFile . ".TLbackup" );

		#before updating take a backup of enha_br223_idcsim.flist
		unless ( -e $flistfile ) {
			S_set_error( " Switch2QNX : '$flistfile' does not exists!", 1 );
			return;
		}
		copy( $flistfile, $flistfile . ".TLbackup" );

		#before updating take a backup of App_BSW_Sim.c
		unless ( -e $bswSimfile ) {
			S_set_error( " Switch2QNX : '$bswSimfile' does not exists!", 1 );
			return;
		}
		copy( $bswSimfile, $bswSimfile . ".TLbackup" );

		#before updating take a backup of Task_Appl_idcsim.c
		unless ( -e $applIdcsimFile ) {
			S_set_error( " Switch2QNX : '$applIdcsimFile' does not exists!", 1 );
			return;
		}
		copy( $applIdcsimFile, $applIdcsimFile . ".TLbackup" );

		#update $cmakelistFile
		my $data = read_file $cmakelistFile, { binmode => ':utf8' };
		$data =~ s/#+(add_subdirectory\(\${CMAKE_CURRENT_LIST_DIR}\/e4a\))/$1/g;
		$data =~ s/(add_library\(rbswcs\s+STATIC\s+\$<TARGET_OBJECTS:mm>\s+\$<TARGET_OBJECTS:tm_s>)\)/$1 \$<TARGET_OBJECTS:e4a>\)/g;
		$data =~ s/(add_library\(rbswcs_high\s+STATIC\s+\$<TARGET_OBJECTS:mm_high>\s+\$<TARGET_OBJECTS:tm_s_high>)\)/$1 \$<TARGET_OBJECTS:e4a_high>\)/g;
		write_file $cmakelistFile, { binmode => ':utf8' }, $data;
		unless ( $data =~ /\n\s*add_subdirectory\(\${CMAKE_CURRENT_LIST_DIR}\/e4a\)/ and $data =~ /add_library\(rbswcs STATIC\s\$<TARGET_OBJECTS:mm>\s\$<TARGET_OBJECTS:tm_s>\s+\$<TARGET_OBJECTS:e4a>\)/g ) {
			S_set_error("Switch2QNX : Falied to update the file '$cmakelistFile' for QNX");
			return;
		}

		#update $flistfile
		$data = read_file $flistfile, { binmode => ':utf8' };
		$data =~ s/#+(include dai_idc5_apl\\component\\(edr4ad|e4a)\\silE4A\.flist)/;$1/g;
		write_file $flistfile, { binmode => ':utf8' }, $data;
		unless ( $data =~ /;include dai_idc5_apl\\component\\(edr4ad|e4a)\\silE4A\.flist/g ) {
			S_set_error("Switch2QNX : Falied to update the file '$flistfile' for QNX");
			return;
		}

		#update $bswSimfile
		$data = read_file $bswSimfile, { binmode => ':utf8' };
		$data =~ s/(\/\/\s*){1,}(e4a_DataRecorderInit)/$2/g;
		$data =~ s/(\/\/\s*){1,}(e4a_DataRecorderRun)/$2/g;
		write_file $bswSimfile, { binmode => ':utf8' }, $data;

		#update $applIdcsimFile
		$data = read_file $applIdcsimFile, { binmode => ':utf8' };
		$data =~ s/(e4a_DataRecorderInit)/\/\/$1/g;
		$data =~ s/(e4a_DataRecorderRun)/\/\/$1/g;
		write_file $applIdcsimFile, { binmode => ':utf8' }, $data;
		unless ( $data =~ /(\/\/\s*){1,}e4a_DataRecorderInit/g and $data =~ /(\/\/\s*){1,}e4a_DataRecorderRun/g ) {
			S_set_error("Switch2QNX : Falied to update the file '$applIdcsimFile' for QNX");
			return;
		}
	}

	return 1;

}

############################################################################################################
#
#
# package LIFT_SIL_LINUX
#
#
############################################################################################################

package LIFT_SIL_LINUX;

use strict;
use warnings;

use Cwd;
use File::Copy;
use File::Slurp qw(read_file write_file);
use File::Basename;
use Digest::MD5 qw(md5_hex);

use LIFT_general;
use E4A_Framework::LIFT_SIL;

sub LIFT_SIL_LINUX_BuildSW {
	my @args = @_;

	#Synchronize the repository
	E4A_Framework::LIFT_SIL::SyncDaiRepoWithRWS() || return;

	#Switch to Linux by updating following files before building
	#CMakeLists.txt
	#enha_br223_idcsim.flist
	#App_BSW_Sim.c
	#Task_Appl_idcsim.c
	Switch2LINUX() || return;

	#change the sharefolder of VMware before Building SW
	my $VmBuildSharedPath = $LIFT_config::E4A_SWRepoPath;
	if ( E4A_Framework::LIFT_SIL::LIFT_SIL_ChangeIDCSim_Shared_Folder_Path($VmBuildSharedPath) ) {
		S_w2log( 2, " LIFT_SIL_LINUX_PrepareE4ATestEnvironment : Changed the Vmware shared folder path to '$VmBuildSharedPath' for simulation\n" );
	}

	S_w2log( 1, "LIFT_SIL_LINUX_BuildSW : Building the SW for Linux.This may take few mins. Please wait..\n" );

	my $swBuildbatchfileDir        = $LIFT_config::E4A_SWRepoPath . '\idc5';
	my $original_working_directory = getcwd();                                 #Fetch the current working directory
	                                                                           #change the directory before running batch file
	chdir $swBuildbatchfileDir;

	#Create a copy of [__Build_SW__].bat to run the build automatically without manual interaction
	my $batchFileUnix = '[__Build_SW__].bat';
	my $psScriptUnix  = '[__Build_SW__].ps1';

	my $batchFileUnix_Auto = '[__Build_SW__]_Auto.bat';
	my $psScriptUnix_Auto  = '[__Build_SW__]_Auto.ps1';

	unless ( -e $batchFileUnix_Auto ) {
		copy( $batchFileUnix, $batchFileUnix_Auto );
		my $data = read_file $batchFileUnix_Auto, { binmode => ':utf8' };
		$data =~ s/\[__Build_SW__\]\.ps1/\[__Build_SW__\]_Auto\.ps1/g;
		write_file $batchFileUnix_Auto, { binmode => ':utf8' }, $data;
	}

	my $buildlogfile = 'C:\temp\LINUXBUILDLOG_' . S_get_date_extension() . '.log';

	#Edit the power shell script to run without GUI
	copy( $psScriptUnix, $psScriptUnix_Auto );
	my $data = read_file $psScriptUnix_Auto, { binmode => ':utf8' };

	#Select the option Clean build
	$data =~ s/\$checkbox_clean\.checked = 0/\$checkbox_clean\.checked = 1/g;

	#Select the option init
	$data =~ s/\$checkbox_00_init\.checked = 0/\$checkbox_00_init\.checked = 1/g;

	#Select the option target.abt
	$data =~ s/\$checkbox_01_target\.checked = 0/\$checkbox_01_target\.checked = 1/g;

	#Select build eha_br223_idcsim
	$data =~ s/\$listbox_build\.SelectedIndex = 0/\$listbox_build.SelectedIndex = 5/g;

	#redirect the init and rebuild logs to a logfile.
	$data =~ s/(call 00_init\.bat \\<nul)/$1 2>&1 \| tee \-a $buildlogfile/g;

	$data =~ s/(call 01_target.bat \\<nul)/$1 2>&1 \| tee \-a $buildlogfile/g;

	#replace '$button_build.Add_Click(' by 'function executeTheBuildProcess'
	$data =~ s/\$button_build\.Add_Click\(/function executeTheBuildProcess/g;

	# replace }) by }
	$data =~ s/}\)(\s+\n+.+\n+#\s+ADD COMPONENTS)/}$1/g;

	# replace $form.ShowDialog()
	$data =~ s/(\$form\.ShowDialog\(\))/executeTheBuildProcess\necho \$textbox_info\.Text/g;

	write_file $psScriptUnix_Auto, { binmode => ':utf8' }, $data;
	S_w2log( 2, " LIFT_SIL_LINUX_BuildSW : Starting the SW build. Output is being logged to '$buildlogfile'\n" );

	my ( $buildStatus, @buildoutput ) = S_call_command($batchFileUnix_Auto);

	#change the dir to original working directory
	chdir $original_working_directory;

	#revert back the changes
	Switch2LINUX( { revert => 1 } ) || return;

	if ( grep ( /Build has failed/, @buildoutput ) or !$buildStatus ) {
		S_set_error( "LIFT_SIL_LINUX_BuildSW: Build has failed. Please check build log '$buildlogfile' for more information", 1 );
		return $buildlogfile;
	}
	else {
		S_w2log( 1, " LIFT_SIL_LINUX_BuildSW : Build successfully completed!\n" );
		my $buildresultDir = $LIFT_config::E4A_SWRepoPath . '\idc5\build\ENHA_BR223_IDCSIM\exec';
		LIFT_SIL_LINUX_SelectE4ASUT($buildresultDir);
	}

	return $buildlogfile;

}

sub LIFT_SIL_LINUX_PrepareE4ATestEnvironment {
	my @args = @_;

	#Before starting automated tests, Stop the instances of VMWare, IDCSim if it was started manually (To keep error free)
	E4A_Framework::LIFT_SIL::StopSilInstances( [ 'VMRCService', 'vmware', 'vmware-vmx', 'vmware-tray', 'idcsim' ] );

	#STEP change the VMware shared folder path for simulation
	my $VmSimulationSharedPath = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5';
	if ( E4A_Framework::LIFT_SIL::LIFT_SIL_ChangeIDCSim_Shared_Folder_Path($VmSimulationSharedPath) ) {
		S_w2log( 2, " LIFT_SIL_LINUX_PrepareE4ATestEnvironment : Changed the Vmware shared folder path to '$VmSimulationSharedPath' for simulation\n" );
	}

	return 1;
}

sub LIFT_SIL_LINUX_ConfigureCSVInputFile {

	my @args         = @_;
	my $scenarioName = shift @args;

	unless ($scenarioName) {
		S_set_error( "LIFT_SIL_ConfigureCSVInputFile : Scenario name is not specified in par file", 1 );
		return;
	}

	my $inputCSVfolderPath = $LIFT_config::E4A_ScenariosPath;
	my $csvfilepath        = $inputCSVfolderPath . "\\$scenarioName" . '.csv';

	unless ( -e $inputCSVfolderPath ) {
		S_set_error( "LIFT_SIL_ConfigureCSVInputFile : Input directory('$inputCSVfolderPath') containing csv files does not exists!", 1 );
		return;
	}
	unless ( -e $csvfilepath ) {
		S_set_error( "LIFT_SIL_ConfigureCSVInputFile : Input csv file $scenarioName.csv  not found in '$inputCSVfolderPath' ", 1 );
		return;
	}

	#idcsim input file path
	my $idcsimInputFilePath = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\input\Signal.csv';

	#Delete existing 'Signal.csv' to avoid error on read only file
	my $delstatus = unlink $idcsimInputFilePath if -e $idcsimInputFilePath;

	#copy csv file
	unless ( copy( $csvfilepath, $idcsimInputFilePath ) ) {
		my $errtxt = $delstatus ? "" : "You may not have permission to delete/replace the existing file '$idcsimInputFilePath'";
		S_set_error( "LIFT_SIL_LINUX_ConfigureCSVInputFile : Failed to copy '$csvfilepath' to '$idcsimInputFilePath' : $errtxt $! \n", 1 );
		return;
	}

	S_w2log( 2, "LIFT_SIL_LINUX_ConfigureCSVInputFile : Copied input csv file '$csvfilepath' to IDCSim input file '$idcsimInputFilePath'\n" );
	return 1;
}

sub LIFT_SIL_LINUX_StartSimulation {
	my @args = @_;

	# STEP Fetch the input arguments ($log_FileName)
	my $log_FileName     = shift @args;
	my $minIdcsimRuntime = shift @args;
	unless ( defined $log_FileName ) {
		S_set_error( "LIFT_SIL_LINUX_StartSimulation : Log Filename is not defined\n", 1 );
		return;
	}

	# STEP Set the default path of '$idc_SimPath', '$csv_file_path', '$sil_output_log_file' and '$idcsim_exe_cmd'
	my $idc_SimPath         = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\tools\idcsim\RuntimeFrame';
	my $sil_InputFiledir    = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\input';
	my $idcsimOutputFiledir = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\\E4A\output';

	#Idcsim appends _0 while generating logfile
	my $generatedLogFileName = $log_FileName . '_0.log';
	$sil_output_log_file = $idcsimOutputFiledir . "\\$generatedLogFileName";
	my $idcsim_exe_cmd = 'idcsim.exe -c -m ' . $LIFT_config::E4A_IDCSimBasePath . '\005_20180517_080840_Manual_HDR___IDC_FR_ESP__stripped.dat' . ' --logfile ' . $idcsimOutputFiledir . "\\$log_FileName";

	unless ( defined $sil_InputFiledir and -e $sil_InputFiledir ) {
		S_set_error( "LIFT_SIL_LINUX_StartSimulation : SIL input file dir '$sil_InputFiledir' does not exists\n", 1 );
		return;
	}

	unless ( -e $idcsimOutputFiledir or mkdir $idcsimOutputFiledir ) {
		S_set_error( "LIFT_SIL_LINUX_StartSimulation : Failed to create the output directory '$idcsimOutputFiledir'\n", 1 );
		return;
	}

	my $silInputfilepath = $sil_InputFiledir . "\\Signal.csv";
	unless ( defined $silInputfilepath and -e $silInputfilepath ) {
		S_set_error( "LIFT_SIL_LINUX_StartSimulation : SIL input file '$silInputfilepath' does not exists\n", 1 );
		return;
	}

	unless ( defined $idc_SimPath and -e $idc_SimPath ) {
		S_set_error( "LIFT_SIL_LINUX_StartSimulation : The idcsim Path '$idc_SimPath' does not exists!\n", 1 );
		return;
	}

	my $original_working_directory = getcwd();    #Fetch the current working directory

	S_w2log( 2, " LIFT_SIL_LINUX_StartSimulation : Change the working directory from '$original_working_directory' to '$idc_SimPath' to run the IDCSIM exe\n" );

	# STEP Change the current working directory to '$idc_SimPath'
	chdir $idc_SimPath;

	#Get the last line of input csv file
	unless ( open( FH, '<', $silInputfilepath ) ) {
		S_set_error( "Could not open file '$silInputfilepath' $!", 1 );
		return;
	}
	my @inputdata = <FH>;
	close(FH);
	my $lastinputline = $inputdata[-1];
	my $referenceTime = ( split( ';', $lastinputline ) )[0];

	$sil_mapping_data_href = E4A_Framework::LIFT_SIL::LIFT_SIL_Read_Mapping_File();

	my $time_to_stop_idcsim_exe_s = $minIdcsimRuntime;

	$time_to_stop_idcsim_exe_s = $sil_mapping_data_href->{IDCSim_MinRunTime_S} unless $time_to_stop_idcsim_exe_s;

	my $maxTime2runSimulation_s = $sil_mapping_data_href->{IDCSim_MaxRunTime_S};

	S_w2log( 2, " LIFT_SIL_LINUX_StartSimulation : Execute the IDCSIM exe for minimum '$time_to_stop_idcsim_exe_s' seconds\n" );
	my $idcsimStartTime = time();

	# STEP Stop the IDCSIM after '$time_to_stop_idcsim_exe_s' seconds
	eval {

		local $SIG{ALRM} = sub { die "alarm\n" };
		alarm $time_to_stop_idcsim_exe_s;
		S_w2log( 2, "LIFT_SIL_LINUX_StartSimulation: Start the IDCSIM simulation. execute command '$idcsim_exe_cmd'" );
		system($idcsim_exe_cmd);
		alarm 0;

	};

	# STEP Change the working directory to original working directory
	S_w2log( 2, " LIFT_SIL_LINUX_StartSimulation : Change the working directory from '$idc_SimPath' to '$original_working_directory' ie to the initial workign directory\n" );
	chdir $original_working_directory;

	S_w2log( 2, " LIFT_SIL_LINUX_StartSimulation : Read IDCSim log for every 1s interval to check if it has reached end of Simulation", 'blue' );

	my ( $content, $idcsimlogChecksumOld, $idcsimlogChecksumNew, $idcsimRuntime );
	my ( $idcsimLogidlecount, $donereadinginputfile ) = ( 0, 0 );
	do {

		#calculate idcsimfilelog checksum
		$idcsimlogChecksumOld = md5_hex( read_file($sil_output_log_file) );

		#read the updated idcsim log
		unless ( open( FH, '<', $sil_output_log_file ) ) {
			S_set_error( "Could not open file '$sil_output_log_file' $!", 1 );
		}
		$content = join( '', <FH> );
		close(FH);

		if ( $content =~ /E4A>\d+;$referenceTime;/ ) {
			$donereadinginputfile = 1;
			S_w2log( 2, " LIFT_SIL_LINUX_StartSimulation : Reached the end of Simulation!!\n" );
		}

		#get the current time
		$idcsimRuntime = time() - $idcsimStartTime;
		if ( !$donereadinginputfile && $idcsimRuntime > $maxTime2runSimulation_s ) {
			S_set_warning(" LIFT_SIL_LINUX_StartSimulation : IDCSim simulation is taking longer time('$idcsimRuntime' seconds) than expected. Please check IDCsim log for more information");
		}

		#calculate new checksum for idcsim log
		$idcsimlogChecksumNew = md5_hex( read_file($sil_output_log_file) );

		if ( !$donereadinginputfile && $idcsimlogChecksumOld eq $idcsimlogChecksumNew ) {

			#Check if IDCSim log has not changed in last 20s
			foreach ( 1 .. 20 ) {
				$idcsimLogidlecount++;
				$idcsimlogChecksumNew = md5_hex( read_file($sil_output_log_file) );
				if ( $idcsimlogChecksumOld eq $idcsimlogChecksumNew ) {
					S_wait_ms(1000);
					if ( $idcsimLogidlecount == 20 ) {
						S_set_error( "LIFT_SIL_LINUX_StartSimulation : There was no update in the IDCSim log in last 20s. Please check if you have provided valid csv file/SW binaries", 1 );
						$donereadinginputfile = 1;
					}
				}
				else {
					$idcsimLogidlecount = 0;
					last;
				}
			}
		}

	} while ( !$donereadinginputfile and $idcsimRuntime < $maxTime2runSimulation_s );

	unless ( -e $sil_output_log_file ) {
		S_set_error( "LIFT_SIL_LINUX_StartSimulation : Failed to create the SIL output log file in the path '$idc_SimPath'\n", 1 );
		return;
	}

	if ( $content =~ /Software Version :(.*)/ ) {
		S_w2log( 2, "E4A Software Version = '$1'\n", 'Green' );
	}

	unless ($donereadinginputfile) {
		if ( $content =~ /Unable to find vECU executable/ ) {
			S_set_error( "LIFT_SIL_LINUX_StartSimulation : ERROR! Check if the VMWare shared folder is configured correctly!\n", 1 );
		}
		elsif ( $content =~ /Initializing SOME\/IP services for \d+\.\d+\.\d+\.\d+$/ ) {
			S_set_error( "LIFT_SIL_LINUX_StartSimulation : ERROR! Possible reasons: 1) VMWare, IDCSim process from previous execution was not stopped properly\n 2) Check if IDCSim Input file(i.e csv) is in proper format\n", 1 );
		}
		elsif ( $content =~ /E4A>;(.*)<E4A/ ) {
			S_set_error( "LIFT_SIL_LINUX_StartSimulation : Required E4A log lines are not present in IDCSim log \n", 1 );
		}
		else {
			S_set_error( "LIFT_SIL_LINUX_StartSimulation : Error found while running simulation. Please check IDCSim log : '$sil_output_log_file'\n", 1 );
		}
	}

	# STEP Return '$sil_output_log_file'
	return $sil_output_log_file;

}

sub LIFT_SIL_LINUX_SelectE4ASUT {
	my @args             = @_;
	my $sourceFolderpath = shift @args;

	#get the folder where SW binaries are located
	my $e4aSwCpPath = $sourceFolderpath;
	unless ($e4aSwCpPath) {
		$e4aSwCpPath = $LIFT_config::E4A_SW_Path;
		unless ( $e4aSwCpPath or -e $e4aSwCpPath ) {
			S_set_warning("LIFT_SIL_LINUX_SelectE4ASUT : 'E4A_SW_Path' is not configured in E4A cfg or Configured path does not exists! Will continue to run using existing SW. \n");
			return;
		}
	}

	my @e4aSwFiles = glob( $e4aSwCpPath . "/*.*" );

	my @binaryFilesLinux = ( 'map', 'vrta_ecu' );
	my @files2CopyLinux;
	foreach my $binFile (@binaryFilesLinux) {
		my ($binFilename) = grep ( /\.$binFile$/, @e4aSwFiles );
		push @files2CopyLinux, $binFilename;

		unless ($binFilename) {
			S_set_warning("LIFT_SIL_LINUX_SelectE4ASUT : Required SW file ('$binFile') is not present in '$e4aSwCpPath'! Will continue to run using existing SW. \n");
			return;
		}
	}

	S_w2log( 2, "LIFT_SIL_LINUX_SelectE4ASUT : E4A SW Version: '" . basename($e4aSwCpPath) . "'\n" ) unless ($sourceFolderpath);

	#copy the binaries to IDCSim simulation folder
	my $idcsimSimPath = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\bosch\build\simMaster';
	@e4aSwFiles = glob( $idcsimSimPath . "/*.*" );

	foreach my $binFile (@binaryFilesLinux) {
		my ($binFileName) = grep( /\.$binFile$/, @e4aSwFiles );
		unless ( not defined $binFileName or unlink $binFileName ) {
			S_set_error("LIFT_SIL_LINUX_SelectE4ASUT : Could not delete existing SW file '$binFileName': $!\n");
			return;
		}
	}

	foreach my $binFile2copy (@files2CopyLinux) {
		if ( copy( $binFile2copy, $idcsimSimPath ) ) {
			S_w2log( 3, "LIFT_SIL_LINUX_SelectE4ASUT : Copied SW file '$binFile2copy' to '$idcsimSimPath'\n" );
		}
		else {
			S_set_error("LIFT_SIL_LINUX_SelectE4ASUT :Failed to copy '$binFile2copy' to '$idcsimSimPath'. $!\n");
			return;
		}

	}

	#copy E4A disabled LINUX binaries to simMaster
	my $package = (caller)[0];

	#avoid recursive call
	if ( $package ne 'LIFT_SIL_QNX' ) {

		#copy E4A disabled QNX binaries to simMaster
		my $e4aDisabledBinaries = "$LIFT_config::E4A_disabledBinaryPathQnx";
		S_w2log( 2, "LIFT_SIL_LINUX_SelectE4ASUT : Copying E4A Disabled QNX binaries from '$e4aDisabledBinaries' \n" );
		LIFT_SIL_QNX::LIFT_SIL_QNX_SelectE4ASUT($e4aDisabledBinaries);
	}

	return 1;

}

sub LIFT_SIL_LINUX_StopSimulation {
	my @args = @_;

	S_w2log( 2, " LIFT_SIL_LINUX_StopSimulation :Stopping the 'IDCSIM' and 'VMRCService'\n" );

	# STEP Stop the processes 'VMRCService' and 'idcsim' if they exist
	E4A_Framework::LIFT_SIL::StopSilInstances( [ 'idcsim', 'VMRCService', 'vmware-vmx' ] );

	return 1;
}

sub LIFT_SIL_LINUX_StopTestEnvironment {
	my @args = @_;

	S_w2log( 2, " LIFT_SIL_LINUX_StopTestEnvironment : Stopping the VMware instances\n" );

	#Stop Vmware instance
	E4A_Framework::LIFT_SIL::StopSilInstances( [ 'vmware', 'vmware-tray', 'vmware-vmx' ] );

	return 1;
}

sub LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer {
	my @args              = @_;
	my $checkpointDirPath = shift @args;
	my $scenario          = shift @args;

	my $scenarioDir = $scenario ? $checkpointDirPath . "/$scenario" : $checkpointDirPath . "//$main::CURRENT_TC";
	unless ( -e $scenarioDir or mkdir $scenarioDir ) {
		S_set_error("LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : Unable to create Scenario dir '$scenarioDir' in Testdatacontainer \n");
		return;
	}

	#Copy the scenario input file
	my $scenarioFilePath = $scenario ? $LIFT_config::E4A_ScenariosPath . "/$scenario.csv" : $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\input\Signal.csv';
	S_w2log( 1, " LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : Copying Input Scenario file '$scenarioFilePath' to '$scenarioDir'\n" );
	copy( $scenarioFilePath, $scenarioDir );

	#create directory for E4A record logs and Simulation traces
	my $e4aRecordlogDir = $scenarioDir . "/E4ARecordLogs";
	unless ( mkdir $e4aRecordlogDir ) {
		S_set_error("LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : Unable to create E4A record log dir $e4aRecordlogDir\n");
		return;
	}

	my $e4aStoragedir = $LIFT_config::E4A_IDCSimBasePath . '\dai_customer_build\idc5\E4A\output\E4A-logfiles';
	my $dir;
	unless ( opendir( $dir, $e4aStoragedir ) ) {
		S_set_warning("LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : Failed to open directory '$e4aStoragedir': $!");
		return;
	}
	my @e4A_logs = readdir($dir);
	closedir $dir;
	foreach my $logfile (@e4A_logs) {
		if ( -f "$e4aStoragedir/$logfile" ) {
			S_w2log( 1, " LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : Copying E4A log '$logfile' to '$e4aRecordlogDir'\n" );
			copy( "$e4aStoragedir/$logfile", $e4aRecordlogDir );
		}
	}

	my $e4aSimuTraceDir = $scenarioDir . "/SimulationTraces";
	unless ( mkdir $e4aSimuTraceDir ) {
		S_set_error("LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : Unable to create E4A Simulation trace dir $e4aSimuTraceDir\n");
		return;
	}

	#copy IDCSim log
	unless ( $sil_output_log_file or -e $sil_output_log_file ) {
		S_set_error("LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : IDCSim simulation log is not generated\n");
		return;
	}

	S_w2log( 1, " LIFT_SIL_LINUX_CopyE4AFiles2TestDataContainer : Copying IDCSim log '$sil_output_log_file' to '$e4aSimuTraceDir'\n" );
	copy( $sil_output_log_file, $e4aSimuTraceDir );

	my $ConvertedcsvPath = E4A_Framework::LIFT_SIL::LIFT_SIL_ConvertIDCSimLogToCSV($sil_output_log_file);
	copy( $ConvertedcsvPath, $e4aSimuTraceDir ) if ( -e $ConvertedcsvPath );

	return $scenarioDir;

}

sub Switch2LINUX {
	my @args = @_;

	my $params = shift @args;

	my $idcsimRepoPath = $LIFT_config::E4A_SWRepoPath;

	#<repo>\idc5\up_apl\dai_idc5\swcs\CMakeLists.txt
	my $cmakelistFile = $idcsimRepoPath . '\idc5\up_apl\dai_idc5\swcs\CMakeLists.txt';

	#<repo>\idc5\dai_idc5_apl\tools\builder\enha_br223_idcsim.flist
	my $flistfile = $idcsimRepoPath . '\idc5\dai_idc5_apl\tools\builder\enha_br223_idcsim.flist';

	#<repo>\idc5\up_apl\dai_idc5\apps\App_BSW_Sim.c
	my $bswSimfile = $idcsimRepoPath . '\idc5\up_apl\dai_idc5\apps\App_BSW_Sim.c';

	#<repo>\idc5\dai_idc5_apl\main\Task_Appl_idcsim.c
	my $applIdcsimFile = $idcsimRepoPath . '\idc5\dai_idc5_apl\main\Task_Appl_idcsim.c';

	if ( $params->{revert} ) {

		#copy back to the original version
		copy( $cmakelistFile . ".TLbackup",  $cmakelistFile );
		copy( $flistfile . ".TLbackup",      $flistfile );
		copy( $bswSimfile . ".TLbackup",     $bswSimfile );
		copy( $applIdcsimFile . ".TLbackup", $applIdcsimFile );
	}
	else {

		#before updating take a backup of CMakeLists.txt
		unless ( -e $cmakelistFile ) {
			S_set_error( " Switch2LINUX : '$cmakelistFile' does not exists!", 1 );
			return;
		}
		copy( $cmakelistFile, $cmakelistFile . ".TLbackup" );

		#before updating take a backup of enha_br223_idcsim.flist
		unless ( -e $flistfile ) {
			S_set_error( " Switch2LINUX : '$flistfile' does not exists!", 1 );
			return;
		}
		copy( $flistfile, $flistfile . ".TLbackup" );

		#before updating take a backup of App_BSW_Sim.c
		unless ( -e $bswSimfile ) {
			S_set_error( " Switch2LINUX : '$bswSimfile' does not exists!", 1 );
			return;
		}
		copy( $bswSimfile, $bswSimfile . ".TLbackup" );

		#before updating take a backup of Task_Appl_idcsim.c
		unless ( -e $applIdcsimFile ) {
			S_set_error( " Switch2LINUX : '$applIdcsimFile' does not exists!", 1 );
			return;
		}
		copy( $applIdcsimFile, $applIdcsimFile . ".TLbackup" );

		#update $cmakelistFile
		my $data = read_file $cmakelistFile, { binmode => ':utf8' };
		$data =~ s/(add_subdirectory\(\${CMAKE_CURRENT_LIST_DIR}\/e4a\))/#$1/g;
		$data =~ s/(add_library\(rbswcs\s+STATIC\s+\$<TARGET_OBJECTS:mm>\s+\$<TARGET_OBJECTS:tm_s>)\s+\$<TARGET_OBJECTS:e4a>/$1/g;
		$data =~ s/(add_library\(rbswcs_high\s+STATIC\s+\$<TARGET_OBJECTS:mm_high>\s+\$<TARGET_OBJECTS:tm_s_high>)\s+\$<TARGET_OBJECTS:e4a_high>/$1/g;
		write_file $cmakelistFile, { binmode => ':utf8' }, $data;
		unless ( $data =~ /add_library\(rbswcs STATIC\s\$<TARGET_OBJECTS:mm>\s\$<TARGET_OBJECTS:tm_s>\)/g ) {
			S_set_error("Switch2LINUX : Falied to update the file '$cmakelistFile' for Linux");
			return;
		}

		#update $flistfile
		$data = read_file $flistfile, { binmode => ':utf8' };
		$data =~ s/;+\s*(include dai_idc5_apl\\component\\(edr4ad|e4a)\\silE4A\.flist)/#$1/g;
		write_file $flistfile, { binmode => ':utf8' }, $data;
		unless ( $data =~ /#include dai_idc5_apl\\component\\(edr4ad|e4a)\\silE4A\.flist/g ) {
			S_set_error("Switch2LINUX : Falied to update the file '$flistfile' for Linux");
			return;
		}

		#update $bswSimfile
		$data = read_file $bswSimfile, { binmode => ':utf8' };
		$data =~ s/(e4a_DataRecorderInit)/\/\/$1/g;
		$data =~ s/(e4a_DataRecorderRun)/\/\/$1/g;
		write_file $bswSimfile, { binmode => ':utf8' }, $data;

		#update $applIdcsimFile
		$data = read_file $applIdcsimFile, { binmode => ':utf8' };
		$data =~ s/(\/\/\s*){1,}(e4a_DataRecorderInit)/$2/g;
		$data =~ s/(\/\/\s*){1,}(e4a_DataRecorderRun)/$2/g;
		write_file $applIdcsimFile, { binmode => ':utf8' }, $data;
		unless ( $data =~ /\n\s*e4a_DataRecorderInit/g and $data =~ /\n\s*e4a_DataRecorderRun/g ) {
			S_set_error("Switch2LINUX : Falied to update the file '$applIdcsimFile' for Linux");
			return;
		}

	}
	return 1;

}

############################################################################################################
#
#
# package LIFT_SIL_WINDOWS
#
#
############################################################################################################

package LIFT_SIL_WINDOWS;

use strict;
use warnings;
use Cwd;
use File::Copy;
use File::Slurp qw(read_file write_file);

use LIFT_general;
use E4A_Framework::LIFT_SIL;

our ( $e4aSUTWinPath, $inputFilesWin, @signalInputfiles );

sub LIFT_SIL_WINDOWS_BuildSW {
	my @args = @_;

	S_w2log( 2, " NOT yet implemented!\n" );

	return 0;

}

sub LIFT_SIL_WINDOWS_PrepareE4ATestEnvironment {
	my @args = @_;

	return 1;
}

sub LIFT_SIL_WINDOWS_ConfigureCSVInputFile {

	my @args = @_;
	$inputFilesWin = shift @args;

	my $evalInputpath = "$LIFT_config::WINCompiled_in";

	#signal inputfiles
	my $workingDir = getcwd();
	foreach ( split( /\s+/, $inputFilesWin ) ) {

		my $inputfilepath = File::Spec->rel2abs("$evalInputpath/$_");
		unless ( -e $inputfilepath ) {
			S_set_error( "LIFT_SIL_WINDOWS_ConfigureCSVInputFile : Signal input file '$inputfilepath' does not exists\n", 1 );
			return;
		}
		push @signalInputfiles, $inputfilepath;
		S_w2log( 2, "LIFT_SIL_WINDOWS_ConfigureCSVInputFile : Copying the input file '$_' from '$evalInputpath' to working directory '$workingDir'\n" );
		copy( $inputfilepath, $workingDir );
	}
	return @signalInputfiles;

}

sub LIFT_SIL_WINDOWS_StartSimulation {
	my @args = @_;

	#Start Simulation for WINDOWS
	unless ($e4aSUTWinPath) {
		S_set_error("LIFT_SIL_WINDOWS_StartSimulation : SUT path is not known! Please call 'LIFT_SIL_SelectE4ASUT/LIFT_SIL_BuildSW' before running simulation");
		return;
	}
	S_w2log( 2, " LIFT_SIL_WINDOWS_StartSimulation : Executing SUT '$e4aSUTWinPath' !\n" );

	#excute the exe
	my ( $buildStatus, @buildoutput ) = S_call_command($e4aSUTWinPath);

	if ($buildStatus) {
		S_w2log( 2, " LIFT_SIL_WINDOWS_StartSimulation : Simulation completed!\n" );
	}
	else {
		S_set_error( " LIFT_SIL_WINDOWS_StartSimulation : Simulation Failed! ERROR:" . join( "", @buildoutput ) . " \n", 1 );
		return;
	}

	#Check if the out.bat is generated
	my $outfilepath = File::Spec->rel2abs("$LIFT_config::LIFT_PRJCFG_path/../out.dat");
	unless ( -e $outfilepath ) {
		S_set_error( "LIFT_SIL_WINDOWS_StartSimulation :  Output record file '$outfilepath' not generated! ", 1 );
		return;
	}
	return 1;

}

sub LIFT_SIL_WINDOWS_SelectE4ASUT {
	my @args = @_;

	my $e4aSWBinpath = "$LIFT_config::E4A_SW_Path";
	S_w2log( 2, " LIFT_SIL_WINDOWS_SelectE4ASUT : Selecting the SUT from '$e4aSWBinpath' for execution!\n" );

	my $dir;
	unless ( opendir( $dir, $e4aSWBinpath ) ) {
		S_set_warning("LIFT_SIL_WINDOWS_SelectE4ASUT : Failed to open directory '$e4aSWBinpath': $!");
		return;
	}
	my @e4aSwFiles = readdir($dir);
	closedir $dir;
	my $binFilenameWindows;
	($binFilenameWindows) = grep ( /\.exe$/, @e4aSwFiles );
	unless ($binFilenameWindows) {
		S_set_error("LIFT_SIL_WINDOWS_SelectE4ASUT : Required SW file ('.exe') is not present in '$e4aSWBinpath'! \n");
		return;
	}
	$e4aSUTWinPath = $e4aSWBinpath . "\\$binFilenameWindows";

	return 1;
}

sub LIFT_SIL_WINDOWS_StopSimulation {
	my @args = @_;

	S_w2log( 2, "LIFT_SIL_WINDOWS_StopSimulation : Removing the input files copied during execution" );
	foreach ( split( /\s+/, $inputFilesWin ) ) {
		my $inputfilepath = File::Spec->rel2abs( getcwd() . "/$_" );
		unlink $inputfilepath;
	}

	#move Out.dat file to configured location
	my $outfilepath      = File::Spec->rel2abs( getcwd() . "/out.dat" );
	my $outputFolderPath = "$LIFT_config::WINCompiled_out";
	unless ( -e $outputFolderPath or mkdir $outputFolderPath ) {
		S_set_error("LIFT_SIL_WINDOWS_StopSimulation : Unable to create output dir '$outputFolderPath'\n");
		return;
	}

	S_w2log( 2, "LIFT_SIL_WINDOWS_StopSimulation : Moving the generated 'out.dat' file to '$outputFolderPath'" );
	move( $outfilepath, $outputFolderPath );
	return 1;
}

sub LIFT_SIL_WINDOWS_StopTestEnvironment {
	my @args = @_;
	return 1;
}

sub LIFT_SIL_WINDOWS_CopyE4AFiles2TestDataContainer {
	my @args              = @_;
	my $checkpointDirPath = shift @args;
	my $scenario          = "$main::CURRENT_TC";

	my $scenarioDir = $scenario ? $checkpointDirPath . "/$scenario" : $checkpointDirPath . "/TestScenario";
	unless ( -e $scenarioDir or mkdir $scenarioDir ) {
		S_set_error("LIFT_SIL_WINDOWS_CopyE4AFiles2TestDataContainer : Unable to create Scenario dir '$scenarioDir' in Testdatacontainer \n");
		return;
	}

	#Copy the input files
	S_w2log( 2, " LIFT_SIL_WINDOWS_CopyE4AFiles2TestDataContainer : Copying Input files to '$scenarioDir'\n" );
	foreach my $inputfileWin (@signalInputfiles) {
		copy( $inputfileWin, $scenarioDir );
	}

	#copy the output record file
	my $outputFilePath = "$LIFT_config::WINCompiled_out" . "/out.dat";
	if ( -e $outputFilePath ) {
		S_w2log( 2, " LIFT_SIL_WINDOWS_CopyE4AFiles2TestDataContainer : Copying output record file '$outputFilePath' to '$scenarioDir'\n" );
		copy( $outputFilePath, $scenarioDir );
	}
	return $scenarioDir;
}

1;

