# C:\ISMPerl\V5_6_1\bin\Perl.exe
package DCOM_SecurityAccess_KeyAlgo;

=head1 NAME

DCOM_user_functions 

Provide user defined functions for DCOM tests

=head1 SYNOPSIS

    use DCOM_user_functions;

    ...

=cut

use strict qw(vars);
use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

@ISA    = qw(Exporter);
@EXPORT = qw(
  get_SW_version
  SecAccessOEMDIDLogin
  SecAccessEDRDevFuncLogin
  KeyAlgo_SecurityAlgorithms
  KeyAlgo_SecurityKeyGeneration
  KeyAlgo_SHA
);

use LIFT_DCOM;
use LIFT_general;

use Crypt::RSA::Key;
use Crypt::RSA;
use Digest::SHA qw(sha256_hex);
use Crypt::RSA::SS::PKCS1v15;
use Crypt::RSA::SS::PSS;
use Crypt::PK::ECC;
use Crypt::Ed25519;

#no warnings 'overflow'; # to avoid loads of integer overflow warnings

#####################################################################

=head2 add_const
               
    @result_bytes = add_const( $const , @hex_bytes )
    
adds $const (in decimal) to the hex-number represented by the list @hex_bytes
and returns the result of the addition as list of hex-bytes (@result_bytes). 
@hex_bytes and @result_bytes are limited to 8 bytes.                         

=cut

#####################################################################
sub add_const {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
                                            #S_w2log(4, "add_const: hex $hexnumber");

    $number = hex($hexnumber) + $const;     # add decimal constant
                                            #S_w2log(4, "add_const: dec $number");

    if ( $number >= $limit ) {              # more than 4 bytes: split number in 2 parts of 4 bytes each
        DCOM_comment( 's', "I am here $number" );
        $low       = $number % $limit;
        $high      = int( $number / $limit );
        $hexnumber = sprintf( "%08X", $high ) . sprintf( "%08X", $low );
    }
    else {                                  # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%08X", $number );
    }

    if ( length($hexnumber) % 2 ) {         # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }

    #S_w2log(4, "add_const: hex $hexnumber");

    $numbytes = length($hexnumber) / 2;     # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "add_const: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  SecAccessVAGFlash
# --------------------------------------------------------------------------
# @result_bytes = SecAccessVAGFlash( $const , @hex_bytes )
#
# added by ESI4-Riedle
##############################################################################
sub SecAccessVAGFlash {
    my $const     = shift;    # get first argument
    my @hex_bytes = @_;       # get all other arguments: bytes that are extracted with "x<nrOfBytes>"

    my @result_bytes;
    my $hexnumber;
    my ( $number, $key, $seed, $val, $VAGlow, $VAGhigh, $help );

    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion

    my $C_BB_AkeyValue_UL = 2538363051;    #0x974C58AB;
    my $C_BB_BkeyValue_UL = 4275878552;    #0xFEDCBA98;
    my $C_BB_CkeyValue_UL = 2557891634;    #0x98765432;

    $hexnumber = join( "", @hex_bytes );   # get hex number from single bytes into string
                                           #S_w2log(4, "add_const: hex $hexnumber");

    #*******************************************************************************************
    # calculation starts here
    #*******************************************************************************************

    # set seed
    $seed = hex($hexnumber);
    S_w2log( 4, "SecAccessVAGFlash: seed $seed" );

    # calc key for AUDI flash access
    $key = $seed + $C_BB_AkeyValue_UL;
    if ( $key > $limit ) {
        $key -= $limit;
    }

    S_w2log( 4, "SecAccessVAGFlash: key $key" );
    $val = 4294967295 - $C_BB_AkeyValue_UL;    #0xffffffff - $C_BB_AkeyValue_UL;
    S_w2log( 4, "SecAccessVAGFlash: val $val" );

    if ( $val < $seed ) {
        S_w2log( 4, "SecAccessVAGFlash a: key $key" );
        $help = $key ^ $C_BB_BkeyValue_UL;
        S_w2log( 4, "SecAccessVAGFlash b: key $help" );
        $key = $help;
        S_w2log( 4, "SecAccessVAGFlash c: if key $key" );

    }
    else {
        $key ^= $C_BB_CkeyValue_UL;
        S_w2log( 4, "SecAccessVAGFlash: else key $key" );
    }

    $VAGlow = $key & (0x00007ff);
    S_w2log( 4, "SecAccessVAGFlash: VAGlow $VAGlow" );
    $VAGhigh = $VAGlow << 21;
    S_w2log( 4, "SecAccessVAGFlash: VAGhigh $VAGhigh" );

    $key = $key >> 11;
    S_w2log( 4, "SecAccessVAGFlash: key $key" );
    $key = $key | $VAGhigh;
    S_w2log( 4, "SecAccessVAGFlash: key $key" );

    $number = $key;    # set key

    #*******************************************************************************************
    # calculation ends here
    #*******************************************************************************************

    if ( $number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $number % $limit;
        $high      = int( $number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                        # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $number );
    }

    if ( length($hexnumber) % 2 ) {    # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }

    #S_w2log(4, "add_const: hex $hexnumber");

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "add_const: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DC01
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DC01(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DC01 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed_UW;
    my $Key_UW;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC01                          (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    # limit input value to 16 bit Seed-Value
    $Seed_UW = hex($hexnumber) & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DC01: Seed: $Seed_UW dez");

    #Key-Algo: DC01
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    $Key_UW = ( ( ( ( $Seed_UW >> 2 ) ^ $Seed_UW ) << 3 ) ^ $Seed_UW );

    # limit to 16-Bit key-Value
    $Key_UW = $Key_UW & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DC01: Key:  $Key_UW dez");

    $result_number = $Key_UW;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DC01_Delay
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DC01_Delay(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DC01_Delay {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed_UW;
    my $Key_UW;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01_Delay: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01_Delay: SEED-AND-KEY Algo DC01                    (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    # limit input value to 16 bit Seed-Value
    $Seed_UW = hex($hexnumber) & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DC01_Delay: Seed: $Seed_UW dez");

    #Key-Algo: DC01
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    $Key_UW = ( ( ( ( $Seed_UW >> 2 ) ^ $Seed_UW ) << 3 ) ^ $Seed_UW );

    # limit to 16-Bit key-Value
    $Key_UW = $Key_UW & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DC01_Delay: Key:  $Key_UW dez");

    $result_number = $Key_UW;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01_Delay: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01_Delay: result_bytes @result_bytes");

    STEPS_DCOM::DCOM_delay( '2', 'Ensure that key generation timer expires' );

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DCNCV01
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DCNCV01(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DCNCV01 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed_UW;
    my $Key_UW;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DCNCV01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DCNCV01: SEED-AND-KEY Algo DC01                          (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    # limit input value to 16 bit Seed-Value
    $Seed_UW = hex($hexnumber) & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCNCV01: Seed: $Seed_UW dez");

    #Key-Algo: DC01
    #C-Source: Key_UW = ((((Seed_UW>>3) ^ Seed_UW) << 2) ^ Seed_UW) & 0xFFFF;

    $Key_UW = ( ( ( ( $Seed_UW >> 3 ) ^ $Seed_UW ) << 2 ) ^ $Seed_UW );

    # limit to 16-Bit key-Value
    $Key_UW = $Key_UW & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCNCV01: Key:  $Key_UW dez");

    $result_number = $Key_UW;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DCNCV01: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DCNCV01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DCNCV01_Delay
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DCNCV01_Delay(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DCNCV01_Delay {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed_UW;
    my $Key_UW;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DCNCV01_Delay: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DCNCV01_Delay: SEED-AND-KEY Algo DC01                    (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    # limit input value to 16 bit Seed-Value
    $Seed_UW = hex($hexnumber) & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCNCV01_Delay: Seed: $Seed_UW dez");

    #Key-Algo: DC01
    #C-Source: Key_UW = ((((Seed_UW>>3) ^ Seed_UW) << 2) ^ Seed_UW) & 0xFFFF;

    $Key_UW = ( ( ( ( $Seed_UW >> 3 ) ^ $Seed_UW ) << 2 ) ^ $Seed_UW );

    # limit to 16-Bit key-Value
    $Key_UW = $Key_UW & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCNCV01_Delay: Key:  $Key_UW dez");

    $result_number = $Key_UW;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DCNCV01_Delay: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DCNCV01_Delay: result_bytes @result_bytes");

    STEPS_DCOM::DCOM_delay( '2', 'Ensure that key generation timer expires' );

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DC222
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DC222(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DC222 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed: $low dez" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $high dez" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $SeedX dez" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $SeedY dez" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;
    $Key1_UL = ( ( ( $SeedX * 0x22 ) + 0x2648 ) );
    $Key2_UL = ( ( ( $SeedY * 0x22 ) + 0x2648 ) );

    S_w2log( 4, "KeyAlgo_DC222: Seed: $Key1_UL hex" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $Key2_UL hex" );

    $result_number1 = $Key1_UL;

    if ( $result_number1 >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low1 = $result_number1 % $limit;
    }
    else {                                # 4 bytes or less: convert directly to hex
        $low1 = $result_number1;
    }

    if ( length($low1) % 2 ) {            # add leading zero if hex number has odd length
        $low1 = "0" . $low1;
    }
    $result_number2 = $Key2_UL;

    if ( $result_number2 >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low2 = $result_number2 % $limit;
    }
    else {                                # 4 bytes or less: convert directly to hex
        $low2 = $result_number2;
    }

    if ( length($low2) % 2 ) {            # add leading zero if hex number has odd length
        $low2 = "0" . $low2;
    }

    #$Key1_32_UL = $Key1_UL & 0xFFFFFFFF;
    #$Key2_32_UL = $Key2_UL & 0xFFFFFFFF;
    S_w2log( 4, "KeyAlgo_DC222: Seed: $low1 hex" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $low2 hex" );

    $Key_UL = ( ($low1) ^ ($low2) ^ (0x13243546) );

    # limit to 16-Bit key-Value
    $Key_UL = $Key_UL & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_DC01: Key:  $Key_UL dez");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DC222DGR
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DC222DGR(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DC222DGR {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed: $low dez" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $high dez" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $SeedX dez" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $SeedY dez" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;
    $Key1_UL = ( ( ( $SeedX * 0x17 ) + 0x8462 ) );
    $Key2_UL = ( ( ( $SeedY * 0x17 ) + 0x8462 ) );

    S_w2log( 4, "KeyAlgo_DC222: Seed: $Key1_UL hex" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $Key2_UL hex" );

    $result_number1 = $Key1_UL;

    if ( $result_number1 >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low1 = $result_number1 % $limit;
    }
    else {                                # 4 bytes or less: convert directly to hex
        $low1 = $result_number1;
    }

    if ( length($low1) % 2 ) {            # add leading zero if hex number has odd length
        $low1 = "0" . $low1;
    }
    $result_number2 = $Key2_UL;

    if ( $result_number2 >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low2 = $result_number2 % $limit;
    }
    else {                                # 4 bytes or less: convert directly to hex
        $low2 = $result_number2;
    }

    if ( length($low2) % 2 ) {            # add leading zero if hex number has odd length
        $low2 = "0" . $low2;
    }

    #$Key1_32_UL = $Key1_UL & 0xFFFFFFFF;
    #$Key2_32_UL = $Key2_UL & 0xFFFFFFFF;
    S_w2log( 4, "KeyAlgo_DC222: Seed: $low1 hex" );
    S_w2log( 4, "KeyAlgo_DC222: Seed: $low2 hex" );

    $Key_UL = ( ($low1) ^ ($low2) ^ (0x97867564) );

    # limit to 16-Bit key-Value
    $Key_UL = $Key_UL & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_DC01: Key:  $Key_UL dez");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DCMFASCN
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DCMFASCN(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DCMFASCN {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    my $Keytemp1_UL;
    my $KeyByte1_UL;
    my $KeyByte2_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed X i/p in dec: $low dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y i/p in dec: $high dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed X in dec: $SeedX dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y in dec: $SeedY dez\n" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    #$Key1_UL = (($SeedX * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedX * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedX * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key1_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key1_UL = ( ( $Keytemp1_UL + $Key1_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec before add: $Key1_UL dez\n" );

    #$Key2_UL = (($SeedY * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedY * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedY * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key2_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key2_UL = ( ( $Keytemp1_UL + $Key2_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec before add: $Key2_UL dez\n" );

    $Key1_UL = ( ( $Key1_UL + 0x3039 ) % $limit );
    $Key2_UL = ( ( $Key2_UL + 0x3039 ) % $limit );

    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec: $Key1_UL dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec: $Key2_UL dez\n" );

    $Key_UL = ( ($Key1_UL) ^ ($Key2_UL) );
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    $Key_UL = ( ($Key_UL) ^ (0xD45D233F) );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    #S_w2log(4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY in hex = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_MBLT2
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_MBLT2(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_MBLT2 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    my $Keytemp1_UL;
    my $KeyByte1_UL;
    my $KeyByte2_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed X i/p in dec: $low dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y i/p in dec: $high dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed X in dec: $SeedX dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y in dec: $SeedY dez\n" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    #$Key1_UL = (($SeedX * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedX * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedX * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key1_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key1_UL = ( ( $Keytemp1_UL + $Key1_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec before add: $Key1_UL dez\n" );

    #$Key2_UL = (($SeedY * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedY * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedY * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key2_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key2_UL = ( ( $Keytemp1_UL + $Key2_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec before add: $Key2_UL dez\n" );

    $Key1_UL = ( ( $Key1_UL + 0x3039 ) % $limit );
    $Key2_UL = ( ( $Key2_UL + 0x3039 ) % $limit );

    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec: $Key1_UL dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec: $Key2_UL dez\n" );

    $Key_UL = ( ($Key1_UL) ^ ($Key2_UL) );
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    $Key_UL = ( ($Key_UL) ^ (0x90883701) );

    #$Key_UL = (($low1 )^ ($low2)^ (0x90883701));
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    #S_w2log(4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY in hex = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_MBLT3
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_MBLT3(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_MBLT3 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    my $Keytemp1_UL;
    my $KeyByte1_UL;
    my $KeyByte2_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed X i/p in dec: $low dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y i/p in dec: $high dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed X in dec: $SeedX dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y in dec: $SeedY dez\n" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    #$Key1_UL = (($SeedX * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedX * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedX * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key1_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key1_UL = ( ( $Keytemp1_UL + $Key1_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec before add: $Key1_UL dez\n" );

    #$Key2_UL = (($SeedY * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedY * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedY * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key2_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key2_UL = ( ( $Keytemp1_UL + $Key2_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec before add: $Key2_UL dez\n" );

    $Key1_UL = ( ( $Key1_UL + 0x3039 ) % $limit );
    $Key2_UL = ( ( $Key2_UL + 0x3039 ) % $limit );

    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec: $Key1_UL dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec: $Key2_UL dez\n" );

    $Key_UL = ( ($Key1_UL) ^ ($Key2_UL) );
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    $Key_UL = ( ($Key_UL) ^ (0x909C9617) );

    #$Key_UL = (($low1 )^ ($low2)^ (0x909C9617));
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    #S_w2log(4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY in hex = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_MBLT4
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_MBLT4(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_MBLT4 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    my $Keytemp1_UL;
    my $KeyByte1_UL;
    my $KeyByte2_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed X i/p in dec: $low dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y i/p in dec: $high dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed X in dec: $SeedX dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y in dec: $SeedY dez\n" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    #$Key1_UL = (($SeedX * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedX * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedX * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key1_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key1_UL = ( ( $Keytemp1_UL + $Key1_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec before add: $Key1_UL dez\n" );

    #$Key2_UL = (($SeedY * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedY * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedY * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key2_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key2_UL = ( ( $Keytemp1_UL + $Key2_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec before add: $Key2_UL dez\n" );

    $Key1_UL = ( ( $Key1_UL + 0x3039 ) % $limit );
    $Key2_UL = ( ( $Key2_UL + 0x3039 ) % $limit );

    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec: $Key1_UL dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec: $Key2_UL dez\n" );

    $Key_UL = ( ($Key1_UL) ^ ($Key2_UL) );
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    $Key_UL = ( ($Key_UL) ^ (0x90883710) );

    #$Key_UL = (($low1 )^ ($low2)^ (0x90883710));
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    #S_w2log(4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY in hex = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_MBLT5
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_MBLT5(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_MBLT5 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    my $Keytemp1_UL;
    my $KeyByte1_UL;
    my $KeyByte2_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed X i/p in dec: $low dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y i/p in dec: $high dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed X in dec: $SeedX dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y in dec: $SeedY dez\n" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    #$Key1_UL = (($SeedX * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedX * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedX * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key1_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key1_UL = ( ( $Keytemp1_UL + $Key1_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec before add: $Key1_UL dez\n" );

    #$Key2_UL = (($SeedY * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedY * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedY * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key2_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key2_UL = ( ( $Keytemp1_UL + $Key2_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec before add: $Key2_UL dez\n" );

    $Key1_UL = ( ( $Key1_UL + 0x3039 ) % $limit );
    $Key2_UL = ( ( $Key2_UL + 0x3039 ) % $limit );

    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec: $Key1_UL dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec: $Key2_UL dez\n" );

    $Key_UL = ( ($Key1_UL) ^ ($Key2_UL) );
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    $Key_UL = ( ($Key_UL) ^ (0x90BB1713) );

    #$Key_UL = (($low1 )^ ($low2)^ (0x90BB1713));
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    #S_w2log(4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY in hex = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_MBLT6
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_MBLT6(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_MBLT6 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    my $Keytemp1_UL;
    my $KeyByte1_UL;
    my $KeyByte2_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed X i/p in dec: $low dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y i/p in dec: $high dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed X in dec: $SeedX dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y in dec: $SeedY dez\n" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    #$Key1_UL = (($SeedX * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedX * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedX * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key1_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key1_UL = ( ( $Keytemp1_UL + $Key1_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec before add: $Key1_UL dez\n" );

    #$Key2_UL = (($SeedY * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedY * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedY * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key2_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key2_UL = ( ( $Keytemp1_UL + $Key2_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec before add: $Key2_UL dez\n" );

    $Key1_UL = ( ( $Key1_UL + 0x3039 ) % $limit );
    $Key2_UL = ( ( $Key2_UL + 0x3039 ) % $limit );

    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec: $Key1_UL dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec: $Key2_UL dez\n" );

    $Key_UL = ( ($Key1_UL) ^ ($Key2_UL) );
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    $Key_UL = ( ($Key_UL) ^ (0x90336715) );

    #$Key_UL = (($low1 )^ ($low2)^ (0x90336715));
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    #S_w2log(4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY in hex = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_MBLT7
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_MBLT7(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_MBLT7 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $result_number1;
    my $result_number2;

    my $low;
    my $high;
    my $numbytes;
    my $arr1;
    my $arr2;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #my $limit = 0x100000000;
    my $SeedX;
    my $SeedY;
    my $Key1_UL;
    my $Key2_UL;
    my $low1;
    my $low2;
    my $Key1_32_UL;
    my $Key2_32_UL;
    my $Key_UL;

    my $Keytemp1_UL;
    my $KeyByte1_UL;
    my $KeyByte2_UL;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DC01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DC01: SEED-AND-KEY Algo DC222                         (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    $arr1 = substr( $hexnumber, 0, 8 );
    $arr2 = substr( $hexnumber, 8, 8 );
    $low  = hex($arr1);
    $high = hex($arr2);

    # limit input value to 8 byte Seed-Value
    $SeedX = ( $low & 0xFFFFFFFF );
    $SeedY = ( $high & 0xFFFFFFFF );

    S_w2log( 4, "KeyAlgo_DC222: Seed X i/p in dec: $low dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y i/p in dec: $high dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed X in dec: $SeedX dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Seed Y in dec: $SeedY dez\n" );

    #Key-Algo: DC222
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    #$Key1_UL = (($SeedX * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedX * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedX * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedX * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key1_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key1_UL = ( ( $Keytemp1_UL + $Key1_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec before add: $Key1_UL dez\n" );

    #$Key2_UL = (($SeedY * 0x41C64E6D) % $limit);
    #Do this two steps, inorder to avoid tolerrance problem

    $KeyByte1_UL = ( ( $SeedY * 0x6D ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x4E ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 8 ) % $limit );
    $Keytemp1_UL = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $KeyByte1_UL = ( ( $SeedY * 0xC6 ) % $limit );
    $KeyByte1_UL = ( ( $KeyByte1_UL << 16 ) % $limit );
    $KeyByte2_UL = ( ( $SeedY * 0x41 ) % $limit );
    $KeyByte2_UL = ( ( $KeyByte2_UL << 24 ) % $limit );
    $Key2_UL     = ( ( $KeyByte2_UL + $KeyByte1_UL ) % $limit );

    $Key2_UL = ( ( $Keytemp1_UL + $Key2_UL ) % $limit );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec before add: $Key2_UL dez\n" );

    $Key1_UL = ( ( $Key1_UL + 0x3039 ) % $limit );
    $Key2_UL = ( ( $Key2_UL + 0x3039 ) % $limit );

    S_w2log( 4, "KeyAlgo_DC222: Key1_UL in dec: $Key1_UL dez\n" );
    S_w2log( 4, "KeyAlgo_DC222: Key2_UL in dec: $Key2_UL dez\n" );

    $Key_UL = ( ($Key1_UL) ^ ($Key2_UL) );
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    $Key_UL = ( ($Key_UL) ^ (0x9044AB17) );

    #$Key_UL = (($low1 )^ ($low2)^ (0x9044AB17));
    S_w2log( 4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n" );

    #$Key_UL = (($low1 )^ ($low2)^ (0xD45D233F));
    #S_w2log(4, "KeyAlgo_DC01: Key in dec:  $Key_UL dez\n");

    $result_number = $Key_UL;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DC01: KEY in hex = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DC01: result_bytes @result_bytes");

    return @result_bytes;
}
##############################################################################
# PROCEDURE:  KeyAlgo_W222
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_W222(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_W222 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $numbytes;
    my $ii;

    $hexnumber = 13243546;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, KeyAlgo_W222result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_W222DGR
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_W222DGR(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_W222DGR {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $numbytes;
    my $ii;

    $hexnumber = 97867564;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, KeyAlgo_W222result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DCDGR
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DCDGR(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DCDGR {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed_UW;
    my $Key_UW;

    #my $DGRConst_UW = 0x0204;
    my $DGRKey_UW      = 0;
    my $DGRCalcBit1_UB = 0;
    my $DGRCalcBit2_UB = 0;
    my $DGRCnt_UB      = 0;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DCDGR: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DCDGR: SEED-AND-KEY Algo DCDGR                          (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    # limit input value to 16 bit Seed-Value
    $Seed_UW = hex($hexnumber) & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCDGR: Seed: $Seed_UW dez");

    #Key-Algo: DCDGR
    for ( $DGRCnt_UB = 0 ; $DGRCnt_UB < 16 ; $DGRCnt_UB++ ) {
        $Seed_UW        = ( $Seed_UW + 0x0204 );
        $Seed_UW        = ( $Seed_UW % 0xFFFF );
        $DGRCalcBit1_UB = ( ($Seed_UW) >> ($DGRCnt_UB) );
        $DGRCalcBit1_UB = ( ($DGRCalcBit1_UB) & 0x0001 );
        $DGRCalcBit2_UB = ( ($Seed_UW) >> ( 15 - ( ( $DGRCnt_UB * 3 ) % 16 ) ) );
        $DGRCalcBit2_UB = ( $DGRCalcBit2_UB % 16 );
        $DGRCalcBit2_UB = ( $DGRCalcBit2_UB & 0x0001 );
        $DGRKey_UW |= ( ( $DGRCalcBit1_UB ^ $DGRCalcBit2_UB ) << $DGRCnt_UB );

    }

    #$Key_UW = $DGRKey_UW;
    $Key_UW = $DGRKey_UW;

    # limit to 16-Bit key-Value
    $Key_UW = $Key_UW & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCDGR: Key:  $Key_UW dez");

    $result_number = $Key_UW;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DCDGR: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DCDGR: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_DCDGR_Delay
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_DCDGR_Delay(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_DCDGR_Delay {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed_UW;
    my $Key_UW;

    #my $DGRConst_UW = 0x0204;
    my $DGRKey_UW      = 0;
    my $DGRCalcBit1_UB = 0;
    my $DGRCalcBit2_UB = 0;
    my $DGRCnt_UB      = 0;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_DCDGR_Delay: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_DCDGR_Delay: SEED-AND-KEY Algo DCDGR                  (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    # limit input value to 16 bit Seed-Value
    $Seed_UW = hex($hexnumber) & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCDGR_Delay: Seed: $Seed_UW dez");

    #Key-Algo: DCDGR
    for ( $DGRCnt_UB = 0 ; $DGRCnt_UB < 16 ; $DGRCnt_UB++ ) {
        $Seed_UW        = ( $Seed_UW + 0x0204 );
        $Seed_UW        = ( $Seed_UW % 0xFFFF );
        $DGRCalcBit1_UB = ( ($Seed_UW) >> ($DGRCnt_UB) );
        $DGRCalcBit1_UB = ( ($DGRCalcBit1_UB) & 0x0001 );
        $DGRCalcBit2_UB = ( ($Seed_UW) >> ( 15 - ( ( $DGRCnt_UB * 3 ) % 16 ) ) );
        $DGRCalcBit2_UB = ( $DGRCalcBit2_UB % 16 );
        $DGRCalcBit2_UB = ( $DGRCalcBit2_UB & 0x0001 );
        $DGRKey_UW |= ( ( $DGRCalcBit1_UB ^ $DGRCalcBit2_UB ) << $DGRCnt_UB );

    }

    #$Key_UW = $DGRKey_UW;
    $Key_UW = $DGRKey_UW;

    # limit to 16-Bit key-Value
    $Key_UW = $Key_UW & 0xFFFF;

    #S_w2log(4, "KeyAlgo_DCDGR_Delay: Key:  $Key_UW dez");

    $result_number = $Key_UW;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_DCDGR_Delay: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_DCDGR_Delay: result_bytes @result_bytes");

    STEPS_DCOM::DCOM_delay( '2', 'Ensure that key generation timer expires' );

    return @result_bytes;
}

#############################################################################
###########################   Porsche key Algorithm  ########################
#############################################################################
sub KeyAlgo_POR01 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexSeed;
    my $numofshiftsbytes;
    my $SeedBuffer;
    my $hexSeedBuffer;
    my $shiftcounter;
    my $Overflowflag_UW;
    my $linkmodebytes;
    my $hexnumber;
    my $result_number;
    my $Higher;
    my $Lower;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $hexSeed_UW;
    my $Key_UW;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_POR01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_POR01: SEED-AND-KEY Algo POR01
    # -----------------------------------------------------------------------------
    S_w2log( 4, "KeyAlgo_POR01: SEED = $hexnumber hex" );
    $Lower = ( ( hex($hexnumber) << 8 ) & 0xFFFF );
    S_w2log( 4, "KeyAlgo_POR01:lower = $Lower" );
    $Higher = ( ( hex($hexnumber) & 0xFF00 ) >> 8 );
    S_w2log( 4, "KeyAlgo_POR01: higher = $Higher hex" );
    $hexnumber = ( ( $Lower + $Higher ) & 0xFFFF );

    $Lower = ( ( ($hexnumber) << 8 ) & 0xFFFF );
    S_w2log( 4, "KeyAlgo_POR01:lower1 = $Lower hex\n" );
    $Higher = ( ( ($hexnumber) & 0xFF00 ) >> 8 );
    S_w2log( 4, "KeyAlgo_POR01: higher2 = $Higher hex\n" );
    $hexnumber = ( ( $Lower + $Higher ) & 0xFFFF );
    S_w2log( 4, "KeyAlgo_POR01: SEED = $hexnumber hex\n" );

    S_w2log( 4, "KeyAlgo_POR01: SEED = $hexnumber hex" );

    # limit input value to 16 bit Seed-Value
    # $Seed_UW = hex( $hexnumber) & 0xFFFF;
    #S_w2log(4, "KeyAlgo_POR01: Seed: $Seed_UW dez");
    $hexSeed_UW = $hexnumber;

    #Key-Algo: POR01
    $hexSeedBuffer = $hexSeed_UW;
    S_w2log( 4, "KeyAlgo_POR01:Buffer = $hexSeedBuffer \n" );

    $numofshiftsbytes = ( ( ($hexSeedBuffer) & 0x0006 ) << 1 );
    S_w2log( 4, "KeyAlgo_POR01:shifts = $numofshiftsbytes\n" );
    $hexSeed = ( ( ($hexSeedBuffer) & 0x0010 ) >> 3 );
    S_w2log( 4, "KeyAlgo_POR01:Buffer = $hexSeedBuffer\n" );
    S_w2log( 4, "KeyAlgo_POR01:Buffer1 = $hexSeed\n" );
    $numofshiftsbytes |= $hexSeed;
    S_w2log( 4, "KeyAlgo_POR01:shifts = $numofshiftsbytes\n" );
    $hexSeed = ( ( ($hexSeedBuffer) & 0x2000 ) >> 13 );
    S_w2log( 4, "KeyAlgo_POR01:Buffer = $hexSeedBuffer\n" );
    S_w2log( 4, "KeyAlgo_POR01:Buffer1 = $hexSeed\n" );
    $numofshiftsbytes |= $hexSeed;
    S_w2log( 4, "KeyAlgo_POR01:shifts = $numofshiftsbytes\n" );

    if ( ( $hexSeedBuffer & 0x0400 ) == 0x0400 ) {
        for ( $shiftcounter = 0x00 ; $shiftcounter < $numofshiftsbytes ; $shiftcounter++ ) {
            $Overflowflag_UW = ( ($hexSeed_UW) & 0x0080 );
            $Overflowflag_UW = ( ( $Overflowflag_UW & 0xFFFF ) >> 15 );
            $hexSeed_UW      = ( ($hexSeed_UW) << 1 );
            $hexSeed_UW |= ( $Overflowflag_UW & 0xFFFF );
            $hexSeed_UW = ( ($hexSeed_UW) & 0xFFFF );
            S_w2log( 4, "KeyAlgo_POR01:seed1 = $hexSeed_UW\n" );
        }
    }
    else {
        for ( $shiftcounter = 0x00 ; $shiftcounter < $numofshiftsbytes ; $shiftcounter++ ) {
            $Overflowflag_UW = ( ($hexSeed_UW) & 0x0001 );
            $Overflowflag_UW = $Overflowflag_UW << 15;
            $hexSeed_UW      = ( ($hexSeed_UW) >> 1 );
            $hexSeed_UW |= $Overflowflag_UW;

            #$hexSeed_UW  =  (hex($hexSeed_UW) & 0xFFFF);
            S_w2log( 4, "KeyAlgo_POR01:seed2 = $hexSeed_UW\n" );
        }
    }

    $linkmodebytes = ( ( $hexSeedBuffer & 0x0040 ) >> 5 ) + ( ( $hexSeedBuffer & 0x1000 ) >> 12 );
    S_w2log( 4, "KeyAlgo_POR01:link = $linkmodebytes\n" );

    if ( $linkmodebytes == 0x0000 ) {
        $hexSeedBuffer = $hexSeedBuffer | $hexSeed_UW;
    }

    if ( $linkmodebytes == 0x0001 ) {
        $hexSeedBuffer = $hexSeedBuffer & $hexSeed_UW;
    }

    if ( $linkmodebytes == 0x0002 ) {
        $hexSeedBuffer = $hexSeedBuffer ^ $hexSeed_UW;
    }

    if ( $linkmodebytes == 0x0003 ) {
        $hexSeedBuffer = $hexSeed_UW;
    }

    S_w2log( 4, "KeyAlgo_POR01:Buffer = $hexSeedBuffer\n" );

    # limit to 16-Bit key-Value
    $Key_UW = $hexSeedBuffer & 0xFFFF;

    #S_w2log(4, "KeyAlgo_POR01: Key:  $Key_UW dez");

    $result_number = $Key_UW & 0xFFFF;
    S_w2log( 4, "KeyAlgo_POR01:result = $result_number\n" );

    S_w2log( 4, "KeyAlgo_POR01:result = $result_number hex\n" );

    #$Lower = ((($result_number) << 8) & 0xFFFF);
    #S_w2log(4, "KeyAlgo_POR01:lower1 = $Lower hex\n");
    #$Higher = ((($result_number) & 0xFF00) >>8);
    #S_w2log(4, "KeyAlgo_POR01: higher2 = $Higher hex\n");
    #$result_number = (($Lower + $Higher) & 0xFFFF);
    #S_w2log(4, "KeyAlgo_POR01: SEED = $result_number hex\n");

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_POR01: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_POR01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_China_MS
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_China_MS(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_China_MS {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed_UW;
    my $Key_UW;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_China_MS: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_China_MS: SEED-AND-KEY Algo DC01                          (SEL2SI 150304)
    # -----------------------------------------------------------------------------

    # limit input value to 16 bit Seed-Value
    $Seed_UW = hex($hexnumber) & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_China_MS: Seed: $Seed_UW dez");

    #Key-Algo: China_MS
    #C-Source: Key_UW = ((((Seed_UW>>2) ^ Seed_UW) << 3) ^ Seed_UW) & 0xFFFF;

    $Key_UW = ( ( ( ( $Seed_UW >> 2 ) ^ $Seed_UW ) << 3 ) ^ $Seed_UW );

    # limit to 16-Bit key-Value
    $Key_UW = $Key_UW & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_China_MS: Key:  $Key_UW dez");

    $result_number = $Key_UW;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_China_MS: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_China_MS: result_bytes @result_bytes");

    return @result_bytes;
}

#######################################################################################
# PROCEDURE:  KeyAlgo_PSA  written by Stefan Mahr CS-SM/ESI4                          #
# ----------------------------------------------------------------------------------- #
# @result_bytes = KeyAlgo_PSA( $const , @hex_bytes )                                  #
#                                                                                     #
# calculate a 4 byte key from a 4 byte seed and a applicationkey                      #
# The applicationkey is given by the command, the seed comes from the response of the #
# first request "27 81".                                                              #
# @hex_bytes and @result_bytes are limited to 8 bytes.                                #
#                                                                                     #
# They are two funktion's F1 and F2 to calculate the Key's.                           #
#                                                                                     #
# KEY1 KEY2 = F1(Application Key) | F2(SEED1 SEED4)                                   #
# KEY3 KEY4 = F1(SEED2 SEED3)     | F2(KEY1 KEY2)                                     #
#                                                                                     #
# You can see the funktion's F1 and F2 below in the source code.                      #
#                                                                                     #
#######################################################################################
sub KeyAlgo_PSA {
    my $const     = shift;    # get first argument
    my @hex_bytes = @_;       # get all other arguments: bytes that are extracted with "x<nrOfBytes>"
    my @result_bytes;
    my $hexnumber;
    my ( $number, $key, $seed, $val, $help );
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
                               #PSA specific variables
    my ( $l_R_SW, $l_K_SW, $l_F1_SW, $l_F2_SW, $l_Result_SW, $l_Counter_SW, $l_E1_1_SW, $l_E2_1_SW );
    my ( $S1, $S4, $S2_3, $S1_4, $Appl_Key, $K1_2, $K3_4 );

    #get hex number from single bytes into string
    $hexnumber = join( "", @hex_bytes );

    #set seed
    $seed = hex($hexnumber);
    S_w2log( 4, "KeyAlgo_PSA_7FFF: Seed           : $seed" );

    #copy the seed in the right rormat (seed1|seed2|seed3|seed4) --> (seed1|seed4)  (seed2|seed3)
    $S2_3 = $seed >> 8;
    $S2_3 = $S2_3 & 0x00FFFF;
    $S1   = $seed >> 24;
    $S4   = $seed & 0x000000FF;
    $S1_4 = $S1 << 8;
    $S1_4 = $S1_4 + $S4;

    #    S_w2log(4, "add_const: dec $const");
    #set the applicationkey to the value wich is given by the DiagIDC
    $Appl_Key = $const;

    #show the results on the Dos window
    #    S_w2log(4, "KeyAlgo_PSA_7FFF: seed1 $S1");
    #    S_w2log(4, "KeyAlgo_PSA_7FFF: seed4 $S4");
    #    S_w2log(4, "KeyAlgo_PSA_7FFF: seed2&3 $S2_3");
    #    S_w2log(4, "KeyAlgo_PSA_7FFF: seed1&4 $S1_4");
    S_w2log( 4, "KeyAlgo_PSA_7FFF: Applicationkey : $Appl_Key" );

    #calculation of KEY1 and KEY2
    #KEY1 KEY2 = F1(Application Key) | F2(SEED1 SEED4)
    #The follow calculation is because if the msb of the hb of the word is 1,
    #that mean the dec value is negative.
    #example with 0xC023 -> 11000000 00100011
    #       ~ 0xC023     =  11111111 11111111 00111111 11011100
    #       + 1          =  11111111 11111111 00111111 11011101
    #       & 0x0000FFFF =  00111111 11011101 = dec 16348
    #       * -1         =  dec -16348
    if ( ( $Appl_Key & 0x8000 ) == 0x8000 ) {
        $Appl_Key = ~$Appl_Key;
        $Appl_Key = $Appl_Key + 1;
        $Appl_Key = $Appl_Key & 0x0000FFFF;
        $Appl_Key = $Appl_Key * -1;
    }
    $l_R_SW       = 0;
    $l_K_SW       = 0;
    $l_F1_SW      = 0;
    $l_F2_SW      = 0;
    $l_E1_1_SW    = $Appl_Key;
    $l_E2_1_SW    = $S1_4;
    $l_Counter_SW = $l_E1_1_SW;

    #F1 begin
    #division of the word with 178
    if ( $l_E1_1_SW >= 0 ) {
        do {
            $l_Counter_SW = $l_Counter_SW - 178;
            $l_K_SW++;
        } while ( $l_Counter_SW > 178 );
    }
    else {
        do {
            $l_Counter_SW = $l_Counter_SW + 178;
            $l_K_SW--;
        } while ( $l_Counter_SW < -178 );
    }

    #S_w2log(4, "Debug1: $l_K_SW");
    $l_R_SW = $l_E1_1_SW - $l_K_SW * 178;

    #S_w2log(4, "Debug2: $l_R_SW");
    $l_F1_SW = -63 * $l_K_SW + $l_R_SW * 170;

    #S_w2log(4, "Debug3: $l_F1_SW");
    if ( $l_F1_SW < 0 ) {
        $l_F1_SW = $l_F1_SW + 30323;
    }

    #S_w2log(4, "Debug4: $l_F1_SW");
    #F1 end
    #F2 begin
    if ( ( $S1_4 & 0x8000 ) == 0x8000 ) {
        $S1_4 = ~$S1_4;
        $S1_4 = $S1_4 + 1;
        $S1_4 = $S1_4 & 0x0000FFFF;
        $S1_4 = $S1_4 * -1;
    }
    $l_K_SW       = 0;
    $l_E2_1_SW    = $S1_4;
    $l_Counter_SW = $l_E2_1_SW;
    if ( $l_E2_1_SW >= 0 ) {
        do {
            $l_Counter_SW = $l_Counter_SW - 177;
            $l_K_SW++;
        } while ( $l_Counter_SW > 177 );
    }
    else {
        do {
            $l_Counter_SW = $l_Counter_SW + 177;
            $l_K_SW--;
        } while ( $l_Counter_SW < -177 );
    }

    #S_w2log(4, "Debug5: $l_K_SW");
    $l_R_SW = $l_E2_1_SW - $l_K_SW * 177;

    #S_w2log(4, "Debug6: $l_R_SW");
    $l_F2_SW = -$l_K_SW - $l_K_SW + $l_R_SW * 171;

    #S_w2log(4, "Debug7: $l_F2_SW");
    if ( $l_F2_SW < 0 ) {
        $l_F2_SW = $l_F2_SW + 30269;
    }

    #S_w2log(4, "Debug8: $l_F2_SW");
    #F2 end
    $K1_2 = $l_F1_SW | $l_F2_SW;

    #S_w2log(4, "Debug9 KEY1&2  : $K1_2");
    #calculation of KEY3 and KEY4
    #KEY3 KEY4 = F1(SEED2 SEED3) | F2(KEY1 KEY2)
    $l_R_SW  = 0;
    $l_K_SW  = 0;
    $l_F1_SW = 0;
    $l_F2_SW = 0;
    if ( ( $S2_3 & 0x8000 ) == 0x8000 ) {
        $S2_3 = ~$S2_3;
        $S2_3 = $S2_3 + 1;
        $S2_3 = $S2_3 & 0x0000FFFF;
        $S2_3 = $S2_3 * -1;
    }
    $l_E1_1_SW    = $S2_3;
    $l_E2_1_SW    = $K1_2;
    $l_Counter_SW = $l_E1_1_SW;

    #F1 begin
    if ( $l_E1_1_SW >= 0 ) {
        do {
            $l_Counter_SW = $l_Counter_SW - 178;
            $l_K_SW++;
        } while ( $l_Counter_SW > 178 );
    }
    else {
        do {
            $l_Counter_SW = $l_Counter_SW + 178;
            $l_K_SW--;
        } while ( $l_Counter_SW < -178 );
    }

    #S_w2log(4, "Debug10: $l_K_SW");
    $l_R_SW = $l_E1_1_SW - $l_K_SW * 178;

    #S_w2log(4, "Debug11: $l_R_SW");
    $l_F1_SW = -63 * $l_K_SW + $l_R_SW * 170;

    #S_w2log(4, "Debug12: $l_F1_SW");
    if ( $l_F1_SW < 0 ) {
        $l_F1_SW = $l_F1_SW + 30323;
    }

    #S_w2log(4, "Debug13: $l_F1_SW");
    #F1 end
    #F2 begin
    if ( ( $l_E2_1_SW & 0x8000 ) == 0x8000 ) {
        $l_E2_1_SW = ~$l_E2_1_SW;
        $l_E2_1_SW = $l_E2_1_SW + 1;
        $l_E2_1_SW = $l_E2_1_SW & 0x0000FFFF;
        $l_E2_1_SW = $l_E2_1_SW * -1;
    }
    $l_K_SW       = 0;
    $l_Counter_SW = $l_E2_1_SW;
    if ( $l_E2_1_SW >= 0 ) {
        do {
            $l_Counter_SW = $l_Counter_SW - 177;
            $l_K_SW++;
        } while ( $l_Counter_SW > 177 );
    }
    else {
        do {
            $l_Counter_SW = $l_Counter_SW + 177;
            $l_K_SW--;
        } while ( $l_Counter_SW < -177 );
    }

    #S_w2log(4, "Debug14: $l_K_SW");
    $l_R_SW = $l_E2_1_SW - $l_K_SW * 177;

    #S_w2log(4, "Debug15: $l_R_SW");
    $l_F2_SW = -$l_K_SW - $l_K_SW + $l_R_SW * 171;

    #S_w2log(4, "Debug16: $l_F2_SW");
    if ( $l_F2_SW < 0 ) {
        $l_F2_SW = $l_F2_SW + 30269;
    }

    #S_w2log(4, "Debug17: $l_F2_SW");
    #F2 end
    $K3_4 = $l_F1_SW | $l_F2_SW;

    #S_w2log(4, "Debug18 Key3&4 : $K3_4");
    $key = $K1_2 << 16;
    $key = $key + $K3_4;

    #calculation finhished
    #show the results on the Dos window
    S_w2log( 4, "KeyAlgo_PSA_7FFF: Key 1 & 2      : $K1_2" );
    S_w2log( 4, "KeyAlgo_PSA_7FFF: Key 3 & 4      : $K3_4" );
    S_w2log( 4, "KeyAlgo_PSA_7FFF: Key coplete    : $key" );
    $number = $key;    # set key
    if ( $number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $number % $limit;
        $high      = int( $number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                        # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $number );
    }
    if ( length($hexnumber) % 2 ) {    # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }

    #S_w2log(4, "add_const: hex $hexnumber");
    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "add_const: result_bytes @result_bytes");
    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_smart01
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_smart01(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_smart01 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed;
    my $Key;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_smart01: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_smart01: SEED-AND-KEY Algo SMART C01                 (UDKOEGEL 240404)
    # -----------------------------------------------------------------------------

    # limit input value to 32 bit Seed-Value
    $Seed = hex($hexnumber) & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_smart01: Seed: $Seed dez");

    #Key-Algo: SMART01
    $Key = $Seed;

    # limit to 32-Bit key-Value
    $Key = $Key & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_smart01: Key:  $Key dez");

    $result_number = $Key;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_smart01: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_smart01: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_smart02
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_smart02(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_smart02 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed;
    my $Key;
    my $Tmp1;
    my $Tmp2;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_smart02: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_smart01: SEED-AND-KEY Algo SMART C02                 (UDKOEGEL 260504)
    # -----------------------------------------------------------------------------

    # limit input value to 32 bit Seed-Value
    $Seed = hex($hexnumber) & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_smart02: Seed: $Seed dez");

    #Key-Algo: SMART02
    $Tmp1 = ( ( $Seed >> 16 ) * 0x07 + 0x1035 );

    #S_w2log(4, "KeyAlgo_smart02: Tmp1:  $Tmp1 dez");
    $Tmp2 = ( ( $Seed & 0x0000FFFF ) * 0x07 + 0x1035 );

    #S_w2log(4, "KeyAlgo_smart02: Tmp2:  $Tmp2 dez");
    $Key = ( $Tmp1 << 16 ) | ( $Tmp2 & 0x0000FFFF );

    # limit to 32-Bit key-Value
    $Key = $Key & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_smart02: Key:  $Key dez");

    $result_number = $Key;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_smart02: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_smart02: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_smart03
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_smart03(@hex_bytes )
#
# calculates the Key out of the Seed hex-number represented by the list @hex_bytes
# and returns the result as list of hex-bytes (@result_bytes).
# @hex_bytes and @result_bytes are limited to 8 bytes.
##############################################################################
sub KeyAlgo_smart03 {
    my $const     = shift;
    my @hex_bytes = @_;

    my @result_bytes;
    my $hexnumber;
    my $result_number;
    my $low;
    my $high;
    my $numbytes;
    my $ii;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $Seed;
    my $Key;
    my $Tmp1;
    my $Tmp2;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes
    S_w2log( 4, "KeyAlgo_smart03: SEED = $hexnumber hex" );

    # -----------------------------------------------------------------------------
    # KeyAlgo_smart03: SEED-AND-KEY Algo SMART C03                 (UDKOEGEL 100305)
    # -----------------------------------------------------------------------------

    # limit input value to 32 bit Seed-Value
    $Seed = hex($hexnumber) & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_smart03: Seed: $Seed dez");

    #Key-Algo: SMART03
    $Tmp1 = ( ( $Seed >> 16 ) * 0x05 + 0x1023 );

    #S_w2log(4, "KeyAlgo_smart03: Tmp1:  $Tmp1 dez");
    $Tmp2 = ( ( $Seed & 0x0000FFFF ) * 0x05 + 0x1023 );

    #S_w2log(4, "KeyAlgo_smart03: Tmp2:  $Tmp2 dez");
    $Key = ( $Tmp1 << 16 ) | ( $Tmp2 & 0x0000FFFF );

    # limit to 32-Bit key-Value
    $Key = $Key & 0xFFFFFFFF;

    #S_w2log(4, "KeyAlgo_smart03: Key:  $Key dez");

    $result_number = $Key;

    # -----------------------------------------------------------------------------
    # -----------------------------------------------------------------------------

    if ( $result_number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $result_number % $limit;
        $high      = int( $result_number / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                               # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $result_number );
    }

    if ( length($hexnumber) % 2 ) {      # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    S_w2log( 4, "KeyAlgo_smart03: KEY  = $hexnumber hex " );

    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    #S_w2log(4, "KeyAlgo_smart03: result_bytes @result_bytes");

    return @result_bytes;
}

##############################################################################
# PROCEDURE:  KeyAlgo_FIAT
# --------------------------------------------------------------------------
# @result_bytes = KeyAlgo_FIAT(@hex_bytes )
#
##############################################################################
#/******************************************************************************/
#/* Function: fiat_f1                                                          */
#/*                                                                            */
#/******************************************************************************/

sub VIN_F1 {
    my $value = shift;

    my $rotate_reg;

    $rotate_reg = ( ( $value << 8 ) | $value );
    $value      = $rotate_reg >> 3;
    $value      = hex sprintf( "%x", $value & 0x00FF );
    return $value;
}

#/******************************************************************************/
#/* Function: fiat_f2                                                          */
#/*                                                                            */
#/******************************************************************************/

sub VIN_F2 {
    my $value = shift;
    $value = hex $value;
    my $rotate_reg;
    $rotate_reg = ( ( $value << 8 ) | $value ) ^ 0xFFFF;
    $value      = $rotate_reg >> 2;
    $value      = hex sprintf( "%x", $value & 0x00FF );
    return $value;
}

#/******************************************************************************/
#/* Function: fiat_f3                                                          */
#/*                                                                            */
#/******************************************************************************/

sub VIN_F3 {
    my $value = shift;
    $value ^= 0x9A;
    $value = hex sprintf( "%x", $value & 0x00FF );
    return $value;
}

#/******************************************************************************/
#/* Function: fiat_f4                                                          */
#/*                                                                            */
#/******************************************************************************/

sub VIN_F4 {
    my $value = shift;
    my $hold;
    $value = hex $value;
    $hold  = 0;
    $hold |= 0x40 & ( $value << 6 );    #/*A*/
    $hold |= 0x10 & ( $value << 3 );    #/*B*/
    $hold |= 0x2 &  ( $value >> 1 );    #/*C*/
    $hold |= 0x80 & ( $value << 4 );    #/*D*/
    $hold |= 0x4 &  ( $value >> 2 );    #/*E*/
    $hold |= 0x1 &  ( $value >> 5 );    #/*F*/
    $hold |= 0x20 & ( $value >> 1 );    #/*G*/
    $hold |= 0x8 &  ( $value >> 4 );    #/*H*/
    $value = $hold;
    $value = hex sprintf( "%x", $value & 0x00FF );
    return $value;
}

sub VIN_rsa_calc_crc {

    my $NumChars         = shift;
    my @data             = @_;
    my $VIN_RSA_REV_POLY = 0x1929;
    my $crc;                            #/* Result of the calculation   */
    my $NextByte;                       #/* The next byte to bring down */
    my $BitCount;                       #/* Count of bits processed     */
    my $carry;
    my $i = 0;

    $crc = 0xa5a5;

    while ( $NumChars-- > 0 ) {
        $BitCount = 0;
        $NextByte = $data[ $i++ ];
        while ( $BitCount < 8 ) {
            $carry = ( $crc & 0x0001 );
            $crc   = $crc >> 1;           #/* Rotar right the CRC */
            if ( $carry ^ ( $NextByte & 0x1 ) ) {    #/* XOR the Poly */
                $crc = $crc ^ $VIN_RSA_REV_POLY;
            }
            $NextByte = ( $NextByte >> 1 );

            $BitCount++;
        }
    }

    return ($crc);
}

#
sub KeyAlgo_FIAT {
    my $const     = shift;
    my @hex_bytes = @_;
    my @result_bytes;

    my $calc;
    my @unlock_key;
    my $appli_key_msb;
    my $appli_key_lsb;
    my $seed_1;
    my $seed_2;
    my $seed_3;
    my $seed_4;
    my $r2_msb = 0xDC;
    my $r2_lsb = 0x7A;
    my $crc_1;
    my $crc_2;
    my $numbytes;
    my $ii;

    my $limit = 4294967296;
    my $hexnumber;
    my $low;
    my $high;

    my $appli_key = 0x1608;
    my $r         = 1;

    #get hex number from single bytes into string
    $hexnumber = join( "", @hex_bytes );

    $appli_key_msb = ( $appli_key >> 8 );
    $appli_key_lsb = ($appli_key);

    $seed_1 = $hex_bytes[0];
    $seed_2 = $hex_bytes[1];
    $seed_3 = $hex_bytes[2];
    $seed_4 = $hex_bytes[3];

    $appli_key_msb = VIN_F1($appli_key_msb);
    $seed_3        = VIN_F2($seed_3);
    $seed_1        = hex $seed_1 ^ $r2_msb;
    $appli_key_lsb = VIN_F3($appli_key_lsb);
    $seed_2        = VIN_F4($seed_2);
    $seed_4        = hex $seed_4 ^ $r2_lsb;

    $unlock_key[0] = $appli_key_msb;
    $unlock_key[1] = $seed_3;
    $unlock_key[2] = $seed_1;
    $crc_1 = VIN_rsa_calc_crc( 3, @unlock_key );    #// Hi Word

    $unlock_key[0] = $appli_key_lsb;
    $unlock_key[1] = $seed_2;
    $unlock_key[2] = $seed_4;
    $crc_2 = VIN_rsa_calc_crc( 3, @unlock_key );    #// Lo Word

    $calc = $crc_1 << 16 | $crc_2;

    if ( $calc >= $limit ) {                        # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low       = $calc % $limit;
        $high      = int( $calc / $limit );
        $hexnumber = sprintf( "%X", $high ) . sprintf( "%X", $low );
    }
    else {                                          # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%X", $calc );
    }
    if ( length($hexnumber) % 2 ) {                 # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    $numbytes = length($hexnumber) / 2;             # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }

    if ( $numbytes eq 3 ) {                                         # add leading zero if hex number is only 3 bytes
        $hexnumber = "00" . $hexnumber;
        $numbytes  = 4;
    }

    return (@result_bytes);

}

##############################################################################
# PROCEDURE:  SecAccessOEMDIDLogin
# --------------------------------------------------------------------------
# @result_bytes = SecAccessOEMDIDLogin(@hex_bytes )
# @hex_bytes : Four Bytes of Seed
# N-Drive path For algo : \\siz 1130\aerse$\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\60.Software\L.Diagnosis\05.Requirements
##############################################################################
sub SecAccessOEMDIDLogin {

    my @hex_bytes = @_;    # get all other arguments: bytes that are extracted with "x<nrOfBytes>"
    my @result_bytes;
    my $hexnumber;
    my ( $number, $key, $seed );
    my $numbytes;
    my $ii;
    my $Carry;
    my $Count = 10;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $low;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes into string

    #*******************************************************************************************
    # calculation starts here
    #*******************************************************************************************

    # set seed
    $seed = hex($hexnumber);

    S_w2log( 4, "SecAccessOEMDIDLogin: seed $seed" );

    if ( $seed >= $limit ) {
        $seed = $seed % $limit;
    }

    # Calculating the Seed
    $seed = $seed + 0x454B5345;
    if ( $seed >= $limit ) {
        $seed = $seed % $limit;
    }

    while ($Count) {
        if ( ( $seed & 0x80000000 ) == 0x80000000 ) {
            $Carry = 1;
        }
        else {
            $Carry = 0;
        }

        $seed = $seed << 1;
        if ( $seed >= $limit ) {
            $seed = $seed % $limit;
        }

        $seed = $seed | $Carry;
        if ( $seed >= $limit ) {
            $seed = $seed % $limit;
        }

        if ( $Carry == 1 ) {
            $seed = $seed ^ 0x56574155;
            if ( $seed >= $limit ) {
                $seed = $seed % $limit;
            }

            if ( ( $seed & 0x80000000 ) == 0x80000000 ) {
                $Carry = 1;
            }

            else {
                $Carry = 0;
            }

            $seed = $seed << 1;
            if ( $seed >= $limit ) {
                $seed = $seed % $limit;
            }

            $seed = $seed | $Carry;
            if ( $seed >= $limit ) {
                $seed = $seed % $limit;
            }
        }
        $Count--;
    }

    # calc key for SecAccessOEMDIDLogin
    $key = $seed - 0x41554449;
    if ( $key >= $limit ) {
        $key = $key % $limit;
    }
    S_w2log( 4, "SecAccessOEMDIDLogin: key $key" );
    $number = $key;    # set key
    if ( $number >= $limit ) {
        $number = $number % $limit;
    }

    #*******************************************************************************************
    # calculation ends here
    #*******************************************************************************************

    if ( $number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low = $number % $limit;
        $hexnumber = sprintf( "%08X", $low );
    }
    else {                        # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%08X", $number );
    }

    if ( length($hexnumber) % 2 ) {    # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }
    return @result_bytes;
}

##############################################################################
# PROCEDURE:  SecAccessEDRDevFuncLogin
# --------------------------------------------------------------------------
# @result_bytes = SecAccessEDRDevFuncLogin(@hex_bytes )
# @hex_bytes : Four Bytes of Seed
# N-Drive path For algo : \\siz 1130\aerse$\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\60.Software\L.Diagnosis\05.Requirements
# ##############################################################################
sub SecAccessEDRDevFuncLogin {
    my @hex_bytes = @_;    # get all other arguments: bytes that are extracted with "x<nrOfBytes>"
    my @result_bytes;
    my $hexnumber;
    my ( $number, $key, $seed );
    my $numbytes;
    my $ii;
    my $Carry;
    my $Count;
    my $limit = 4294967296;    # 2^32; limit for dec -> hex conversion
    my $low;
    my $Subtrahend_1 = 0x41555445;
    my $Subtrahend_2 = 0x31303634;
    my $Summand      = 0x6A777677;
    my $Teilsumme_1;
    my $Teilsumme_2;

    $hexnumber = join( "", @hex_bytes );    # get hex number from single bytes into string

    #*******************************************************************************************
    # calculation starts here
    #*******************************************************************************************
    $seed = hex($hexnumber);
    S_w2log( 4, "SecAccessEDRDevFuncLogin seed $seed" );

    $key   = 0x00000000;
    $Carry = 0x00000000;
    $key   = $seed;
    if ( $Subtrahend_1 > $key ) {
        $Carry = 0x00000001;
    }
    else {
        $Carry = 0x00000000;
    }
    $key = $key - $Subtrahend_1;
    if ( $key >= $limit ) {
        $key = $key % $limit;
    }
    for ( $Count = 0 ; $Count < 6 ; $Count++ ) {
        if ( $Carry == 0x00000001 ) {
            $key = $key ^ 0x4F4D5657;
            if ( $key >= $limit ) {
                $key = $key % $limit;
            }
        }
        $Carry = $key & 0x00000001;
        $key   = $key >> 1;
        if ( $key >= $limit ) {
            $key = $key % $limit;
        }

        if ( $Carry == 0x00000001 ) {
            $key = $key | 0x80000000;
            if ( $key >= $limit ) {
                $key = $key % $limit;
            }
        }
    }
    $Teilsumme_1 = $key;
    $Teilsumme_2 = $Summand;
    $key         = $key + $Summand;
    if ( $key >= $limit ) {
        $key = $key % $limit;
    }
    if ( ( $key < $Teilsumme_1 ) | ( $key < $Teilsumme_2 ) ) {
        for ( $Count = 0 ; $Count < 4 ; $Count++ ) {
            $Carry = $key & 0x80000000;
            $key   = $key << 1;
            if ( $key >= $limit ) {
                $key = $key % $limit;
            }

            if ( $Carry == 0x80000000 ) {
                $key = $key | 0x00000001;
                if ( $key >= $limit ) {
                    $key = $key % $limit;
                }
            }
            $key = $key - $Subtrahend_2;
            if ( $key >= $limit ) {
                $key = $key % $limit;
            }
        }
    }
    S_w2log( 4, "SecAccessEDRDevFuncLogin:  $key" );
    $number = $key;    # set key

    #*******************************************************************************************
    # calculation ends here
    #*******************************************************************************************
    if ( $number >= $limit ) {    # more than 4 bytes: split number in 2 parts of 4 bytes each
        $low = $number % $limit;
        $hexnumber = sprintf( "%08X", $low );
    }
    else {                        # 4 bytes or less: convert directly to hex
        $hexnumber = sprintf( "%08X", $number );
    }

    if ( length($hexnumber) % 2 ) {    # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    $numbytes = length($hexnumber) / 2;    # get number of bytes
    for ( $ii = 0 ; $ii < $numbytes ; $ii++ ) {
        push( @result_bytes, substr( $hexnumber, $ii * 2, 2 ) );    # split hex number into bytes
    }
    return @result_bytes;
}

##############################################################################
# PROCEDURE:  Calculate_MFA2_Level1
# --------------------------------------------------------------------------
# @result_bytes = Calculate_MFA2_Level1(@hex_bytes )
# @hex_bytes : Four Bytes of Seed
# N-Drive path For algo :
# For Level1 key is Negation of the seed
# ##############################################################################

sub Calculate_MFA2_Level1 {
    my $const     = shift;
    my @hex_bytes = @_;
    my @result_bytes;
    my ( $number, $key, $seed );
    my $hexnumber;
    my $numbytes;
    my $i;

    # get hex number from single bytes into string
    $hexnumber = join( "", @hex_bytes );

    $seed = hex($hexnumber);
    S_w2log( 4, "Calculate_MFA2_Level1 seed $seed" );

    $key = ~$seed;

    S_w2log( 4, "Calculate_MFA2_Level1:  $key" );

    $number = $key;                            # set key
    $hexnumber = sprintf( "%08X", $number );

    if ( length($hexnumber) % 2 ) {            # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    $numbytes = length($hexnumber) / 2;        # get number of bytes
    for ( $i = 0 ; $i < $numbytes ; $i++ ) {
        push( @result_bytes, substr( $hexnumber, $i * 2, 2 ) );    # split hex number into bytes
    }
    return @result_bytes;
}

##############################################################################
# PROCEDURE:  Calculate_MFA2_Level48
# --------------------------------------------------------------------------
# @result_bytes = Calculate_MFA2_Level1(@hex_bytes )
# @hex_bytes : Four Bytes of Seed
# N-Drive path For algo :
# For Level48 key = (~0x54ED) & (Seed ^ ~Seed)
#   (Seed ^ ~Seed) is always 1111
#then key is (~0x54ED)
# ##############################################################################

sub Calculate_MFA2_Level48 {
    my $const     = shift;
    my @hex_bytes = @_;
    my @result_bytes;
    my ( $number, $key, $seed );
    my $hexnumber;
    my $numbytes;
    my $i;

    # get hex number from single bytes into string
    $hexnumber = join( "", @hex_bytes );

    $seed = hex($hexnumber);
    S_w2log( 4, "Calculate_MFA2_Level1 seed $seed" );

    $key = ( ~0x54ED );

    S_w2log( 4, "Calculate_MFA2_Level1:  $key" );

    $number = $key;                            # set key
    $hexnumber = sprintf( "%04X", $number );

    S_w2log( 2, "Calculate_MFA2_Level48:  $hexnumber" );

    if ( length($hexnumber) % 2 ) {            # add leading zero if hex number has odd length
        $hexnumber = "0" . $hexnumber;
    }
    $numbytes = length($hexnumber) / 2;        # get number of bytes
    for ( $i = 0 ; $i < 2 ; $i++ ) {
        push( @result_bytes, substr( $hexnumber, ( $i + 2 ) * 2, 2 ) );    # split hex number into bytes
    }
    return @result_bytes;
}

=head2 KeyAlgo_RSA_GenerateKeys
    ( $public, $private ) = KeyAlgo_RSA_GenerateKeys( $bits );
It returns a list of two elements, a Crypt::RSA::Key::Public object that holds the public part of the key pair and a Crypt::RSA::Key::Private object that holds that private part

B<Arguments:>
=over
=item $bits

Bit Length should be greater or Equal than 48 and Should be even

=item $signature

=back


B<Return Values:>
=over
=item $private

Creates and returns a new private key

=item $public

Creates and returns a new public key
   
Success : Generates a pair of private and public key

Error   : undef 
=back
B<Examples:>
=over
    my ($public,$private) = KeyAlgo_RSA_GenerateKeys(2048);
=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_RSA_GenerateKeys {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_RSA_GenerateKeys( $bits )', @args )
      or return;

    my $bits = shift @args;

    if ( $bits < 48 or $bits % 2 != 0 ) {
        S_set_error( "KeyAlgo_RSA_GenerateKeys : Bit Length should be greater or Equal than 48 and Should be even", 109 );
        return;
    }
    my $cryptRSAObj = Crypt::RSA::Key->new();

    S_w2log( 2, "KeyAlgo_RSA_GenerateKeys : Starting to generate Public and Private keys...\n" );
    my ( $public, $private ) = $cryptRSAObj->generate( Size => $bits );
    if ( defined $public and defined $private ) {
        S_w2log( 2, "KeyAlgo_RSA_GenerateKeys : Keys are generated...\n" );
        return ( $public, $private );
    }
    else {
        S_set_error( "KeyAlgo_RSA_GenerateKeys : Could not generate the keys", 23 );
        return;

    }

    return ( $public, $private );
}

=head2 KeyAlgo_ECDSA_GenerateKeys
    ( $public_key, $private_key ) = KeyAlgo_ECDSA_GenerateKeys( $curve_name );
Function to generate ECDSA private and public keys.

B<Return Values:>
=over
=item $private

Creates and returns a new Private key.

=item $public

Creates and returns a new Public key.
   
Success : Generates a pair of secret and public key

Error   : undef 
=back
B<Examples:>
=over
    $curveName = "brainpoolp256r1";
    
    my ( $public_key, $private_key ) = KeyAlgo_ECDSA_GenerateKeys( $curve_name );
=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_ECDSA_GenerateKeys {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_ECDSA_GenerateKeys( $curve_name )', @args )
      or return;

    my $curve_name = shift @args;

    if ( $curve_name ne 'brainpoolp256r1' ) {
        S_set_error( "KeyAlgo_ECDSA_GenerateKeys : Could not generate signature due to incorrect curve name", 23 );
        return;
    }

    my $pk = Crypt::PK::ECC->new();

    $pk->generate_key($curve_name);

    my $private_key = $pk->export_key_jwk( 'private', 1 );
    my $public_key  = $pk->export_key_jwk( 'public',  1 );

    return ( $public_key, $private_key );
}

=head2 KeyAlgo_RSA_SS_PSS_signatureGeneration
Function to generate signature using RSA-SS-PSS Signature Algorithm
    $signature = KeyAlgo_RSA_SS_PSS_signatureGeneration( $message,$private );

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $private

Accepts a RSA-Private key.

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message using the public and private keys.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    ($public,$private) = KeyAlgo_RSA_GenerateKeys(2048);
    
    $signature = KeyAlgo_RSA_SS_PSS_signatureGeneration( $message,$private );
=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_RSA_SS_PSS_signatureGeneration {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_RSA_SS_PSS_signatureGeneration( $message,$private )', @args )
      or return;

    my $message = shift @args;
    my $private = shift @args;

    my $pss = Crypt::RSA::SS::PSS->new();
    S_w2log( 2, "KeyAlgo_RSA_SS_PSS_signatureGeneration : Starting to generate Signature...\n" );
    my $signature = $pss->sign(
        Message => $message,
        Key     => $private,
    );
    if ( defined $signature ) {
        S_w2log( 2, "KeyAlgo_RSA_SS_PSS_signatureGeneration : Signature generated\n" );
        return $signature;
    }
    else {
        S_set_error( "KeyAlgo_RSA_SS_PSS_signatureGeneration : Could not generate signature", 23 );
        return;
    }

}

=head2 KeyAlgo_RSA_SS_PSS_verification
This module verifies signatures based on RSA-SS-PSS and returns 0 if Signature is verified and 1 if Signature is not verified
    KeyAlgo_RSA_SS_PSS_verification( $message,$public,$signature );
    
B<Arguments:>
=over
=item $message

Message for which verification would be done.

=item $signature

Accepts a RSA generated signature.

=item $public

Public key for RSA Signature Algorithm

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";
    ($public,$private) = KeyAlgo_RSA_GenerateKeys(2048);
    $signature = KeyAlgo_RSA_SS_PSS_signatureGeneration( $message,$private );
    
    KeyAlgo_RSA_SS_PSS_verification( $message,$public,$signature );

=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_RSA_SS_PSS_verification {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_RSA_SS_PSS_verification( $message,$public,$signature )', @args )
      or return;

    my $message   = shift @args;
    my $public    = shift @args;
    my $signature = shift @args;

    my $pss = Crypt::RSA::SS::PSS->new();

    S_w2log( 2, "KeyAlgo_RSA_SS_PSS_verification : Starting Verification process...\n" );
    my $verify = $pss->verify(
        Message   => $message,
        Key       => $public,
        Signature => $signature,
    );

    if ($verify) {
        S_w2log( 2, "KeyAlgo_RSA_SS_PSS_verification : Verification successful\n" );
        return 1;
    }
    else {
        S_w2log( 2, "KeyAlgo_RSA_SS_PSA_verification : Verification not successful\n" );
        return;
    }
}

=head2 KeyAlgo_RSA_SS_PSS
Function to generate signature using RSA-SS-PSS Signature Algorithm
    $signature = KeyAlgo_RSA_SS_PSS( $message,$key,$typeOfOperation);

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $key

Either RSA Private key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function.
In this case it should be "signatureGeneration".

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message using RSA-SS-PSS Signature Algorithm.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    $bits = 2048;
    ($public,$private) = KeyAlgo_RSA_GenerateKeys($bits);
    $typeOfOperation = "signatureGeneration";
    
    $signature = KeyAlgo_RSA_SS_PSS( $message,$private,$typeOfOperation);
    
=back

This module verifies signatures based on RSA-SS-PSS and returns 0 if Signature is verified and 1 if Signature is not verified
    KeyAlgo_RSA_SS_PSS( $message,$key,$typeOfOperation,$signature);
    
B<Arguments:>
=over
=item $message

Message for which verification would be done.

=item $key

Either RSA Public key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function.
In this case it should be "verification".

=item signature

Signature of RSA-SS-PSS algorthm of old Message against which new message will be verified.

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";
    $bits = 2048;
    ($public,$private) = KeyAlgo_RSA_GenerateKeys($bits);
    $typeOfOperation = "signatureGeneration";
    $signature = KeyAlgo_RSA_SS_PSS( $message,$private,$typeOfOperation);
    
    $typeOfOperation = "verification";
    KeyAlgo_RSA_SS_PSS( $message,$public,$typeOfOperation,$signature);

=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_RSA_SS_PSS {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_RSA_SS_PSS( $message,$key,$typeOfOperation [,$signature ])', @args )
      or return;
    S_w2log( 2, "KeyAlgo_RSA_SS_PSS : Initiating the process...\n" );

    my $message         = shift @args;
    my $key             = shift @args;
    my $typeOfOperation = shift @args;
    my $signature       = shift @args;

    if ( $typeOfOperation =~ /signatureGeneration/i ) {
        return KeyAlgo_RSA_SS_PSS_signatureGeneration( $message, $key );    #private key
    }
    elsif ( $typeOfOperation =~ /verification/i ) {
        if ( defined $signature ) {
            KeyAlgo_RSA_SS_PSS_verification( $message, $key, $signature );    #public key
        }
        else {
            S_set_error( "KeyAlgo_RSA_SS_PSS : Please provide signature for the verification process...\n", 110 );
        }
        return;
    }
    S_w2log( 2, "KeyAlgo_RSA_SS_PSS : Process ended\n" );

    return;
}

=head2 KeyAlgo_RSA_SS_PKCS1_V1_5
Function to generate signature using RSA-SS-PKCS1_v1_5 Signature Algorithm
    $signature = KeyAlgo_RSA_SS_PKCS1_V1_5( $message,$key,$typeOfOperation);

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $key

Either RSA Private key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function. 
In this case it should be "signatureGeneration".

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message using RSA-SS-PKCS1_v1_5 Signature Algorithm.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    $bits = 2048;
    ($public,$private) = KeyAlgo_RSA_GenerateKeys($bits);
    $typeOfOperation = "signatureGeneration";
    
    $signature = KeyAlgo_RSA_SS_PKCS1_V1_5( $message,$private,$typeOfOperation);
    
=back

This module verifies signatures based on RSA-SS-PKCS1_v1_5 and returns 0 if Signature is verified and 1 if Signature is not verified
    KeyAlgo_RSA_SS_PKCS1_V1_5( $message,$key,$typeOfOperation,$signature);
    
B<Arguments:>
=over
=item $message

Message for which verification would be done.

=item $key

Either RSA Public key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function.
In this case it should be "verification".

=item signature

Signature of RSA-SS-PKCS1_v1_5 algorthm of old Message against which new message will be verified.

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";
    $bits = 2048;
    ($public,$private) = KeyAlgo_RSA_GenerateKeys($bits);
    $typeOfOperation = "signatureGeneration";
    $signature = KeyAlgo_RSA_SS_PKCS1_V1_5( $message,$private,$typeOfOperation);
    
    $typeOfOperation = "verification";
    KeyAlgo_RSA_SS_PKCS1_V1_5( $message,$public,$typeOfOperation,$signature);
    
    
    
=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_RSA_SS_PKCS1_V1_5 {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_RSA_SS_PKCS1_V1_5( $message,$key,$typeOfOperation [,$signature ])', @args ) or return;
    S_w2log( 2, "KeyAlgo_RSA_SS_PKCS1_V1_5 : Initiating the process...\n" );

    my $message         = shift @args;
    my $key             = shift @args;
    my $typeOfOperation = shift @args;
    my $signature       = shift @args;

    if ( $typeOfOperation =~ /signatureGeneration/i ) {
        return KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration( $message, $key );    #private key
    }
    elsif ( $typeOfOperation =~ /verification/i ) {
        if ( defined $signature ) {
            KeyAlgo_RSA_SS_PKCS1_V1_5_verification( $message, $signature, $key );    #public key
        }
        else {
            S_set_error( "KeyAlgo_RSA_SS_PKCS1_V1_5 : Please provide signature for the verification process...\n", 110 );
        }
        return;
    }
    S_w2log( 2, "KeyAlgo_RSA_SS_PKCS1_V1_5 : Process ended\n" );

    return;
}

=head2 KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration
Function to generate signature using RSA-SS-PKCS1_v1_5 Signature Algorithm
    $signature = KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration( $message,$private );

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $private

Accepts a RSA-Private key.

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message using the public and private keys.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    ($public,$private) = KeyAlgo_RSA_GenerateKeys(2048);
    
    $signature = KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration( $message,$private );
=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration( $message,$private )', @args )
      or return;

    my $message = shift @args;
    my $private = shift @args;

    my $pkcs = Crypt::RSA::SS::PKCS1v15->new( Digest => 'SHA1' );

    S_w2log( 2, "KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration : Starting to generate Signature...\n" );
    my $signature = $pkcs->sign(
        Message => $message,
        Key     => $private
    );    #|| die $pkcs->errstr;

    unless ( defined $signature ) {
        S_set_error( "KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration : Could not generate signature", 23 );
        return;
    }

    S_w2log( 2, "KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration : Signature generated\n" );
    return $signature;

}

=head2 KeyAlgo_ECDSA_signatureGeneration
Function to generate signature using ECDSA Signature Algorithm
    $signature = KeyAlgo_ECDSA_signatureGeneration( $message,$private );

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $private

Accepts a private key for the signature.

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    $curveName = "brainpoolp256r1";
    ( $public, $private ) = KeyAlgo_ECDSA_GenerateKeys($curveName);
    
    $signature = KeyAlgo_ECDSA_signatureGeneration($message,$private);
=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_ECDSA_signatureGeneration {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_ECDSA_signatureGeneration( $message,$private_href )', @args )
      or return;

    my $message      = shift @args;
    my $private_href = shift @args;

    my $priv      = Crypt::PK::ECC->new($private_href);
    my $signature = $priv->sign_message($message);

    S_w2log( 2, "KeyAlgo_ECDSA_signatureGeneration : Signature generated\n" );
    return $signature;
}

=head2 KeyAlgo_RSA_SS_PKCS1_V1_5_verification
This module verifies signatures based on RSA-SS-PKCS_v1_5 and returns 0 if Signature is verified and 1 if Signature is not verified
    KeyAlgo_RSA_SS_PKCS1_V1_5_verification( $message,$signature,$public );
    
B<Arguments:>
=over
=item $message

Message for which verification would be done.

=item $signature

Accepts a RSA generated signature.

=item $public

Public key for RSA Signature Algorithm

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";
    ($public,$private) = KeyAlgo_RSA_GenerateKeys(2048);
    $signature = KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration( $message,$private );
    
    KeyAlgo_RSA_SS_PKCS1_V1_5_verification( $message,$signature,$public );

=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_RSA_SS_PKCS1_V1_5_verification {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_RSA_SS_PKCS1_V1_5_verification( $message,$signature,$public )', @args ) or return;

    my $message   = shift @args;
    my $signature = shift @args;
    my $public    = shift @args;

    #    my $pkcs = new Crypt::RSA::SS::PKCS1v15( Digest => 'SHA1' );
    my $pkcs = Crypt::RSA::SS::PKCS1v15->new( Digest => 'SHA1' );
    S_w2log( 2, "KeyAlgo_RSA_SS_PKCS1_V1_5_verification : Starting Verification process...\n" );
    my $verify = $pkcs->verify(
        Message   => $message,
        Key       => $public,
        Signature => $signature
    );    #|| die $pkcs->errstr;
    if ($verify) {
        S_w2log( 2, "KeyAlgo_RSA_SS_PKCS1_V1_5_verification : Verification sucessfull...\n" );
        return 1;
    }
    else {
        S_w2log( 2, "KeyAlgo_RSA_SS_PKCS1_V1_5_verification : Verification not sucessfull...\n" );
        return;
    }
}

=head2 KeyAlgo_ECDSA_verification
    KeyAlgo_ECDSA_verification( $message,$signature,$public )
This module implements ECDSA signatures and returns 0 if Signature is verified and undef if Signature is not verified

B<Arguments:>
=over
=item $message

Message for which verification would be done.

=item $signature

Accepts a ECDSA generated signature.

=item $public

Public key for ECDSA Signature Algorithm

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";
    $curveName = "brainpoolp256r1";
    ($public,$private) = KeyAlgo_ECDSA_GenerateKeys($curveName);
    $signature = KeyAlgo_ECDSA_signatureGeneration($message,$private);
        
    KeyAlgo_ECDSA_verification( $message,$signature,$public);

=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_ECDSA_verification {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_ECDSA_verification( $message,$signature,$public_href )', @args )
      or return;

    my $message     = shift @args;
    my $signature   = shift @args;
    my $public_href = shift @args;

    my $pub = Crypt::PK::ECC->new($public_href);
    my $verify = $pub->verify_message( $signature, $message );

    if ($verify) {
        S_w2log( 2, "KeyAlgo_ECDSA_verification : Verification sucessfull\n" );
        return 1;
    }
    else {
        S_set_error( "KeyAlgo_ECDSA_verification : Could not verify due to error", 109 );
        return;
    }
}

=head2 KeyAlgo_ECDSA
Function to generate signature using ECDSA Signature Algorithm
    $signature = KeyAlgo_ECDSA($message,$key,$typeOfOperation);

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $key

ECDSA Private key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function.
In this case it should be "signatureGeneration".

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    $typeOfOperation = "signatureGeneration";
    $curveName = "brainpoolp256r1";
    ( $public_key, $private_key ) = KeyAlgo_ECDSA_GenerateKeys( $curve_name );
    
    $signature = KeyAlgo_ECDSA($message,$private_key,$typeOfOperation);
    
=back

Function used for verification of messages using ECDSA Signature Algorithm
    KeyAlgo_EdDSA($message,$key,$typeOfOperation,$signature)
    
B<Arguments:>
=over
=item $message

Message for which verification would be done

=item $key

ECDSA Public key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function.
In this case it should be "verification".

=item $signature

Accepts a ECDSA generated signature for the message against which new signature would be verified.

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";
    $typeOfOperation = "signatureGeneration";
    $curveName = "brainpoolp256r1";
    ( $public_key, $private_key ) = KeyAlgo_ECDSA_GenerateKeys( $curve_name );
    
    $signature = KeyAlgo_ECDSA($message,$private_key,$typeOfOperation);
    
    
    $typeOfOperation = "verification";
    KeyAlgo_ECDSA($message,$public_key,$typeOfOperation,$signature);
    
=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_ECDSA {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_ECDSA( $message,$key_href,$typeOfOperation [,$signature ])', @args ) or return;
    S_w2log( 2, "KeyAlgo_ECDSA : Initiating the process...\n" );

    my $message         = shift @args;
    my $key_href        = shift @args;
    my $typeOfOperation = shift @args;
    my $signature       = shift @args;

    #    S_w2log( 2, "KeyAlgo_ECDSA : Generating Keys...\n" );
    #    my ( $public, $private ) = KeyAlgo_ECDSA_GenerateKeys($curveName);
    #    S_w2log( 2, "KeyAlgo_ECDSA : Keys generated\n" );

    if ( $typeOfOperation =~ /signatureGeneration/i ) {
        return KeyAlgo_ECDSA_signatureGeneration( $message, $key_href );    #private
    }
    elsif ( $typeOfOperation =~ /verification/i ) {
        if ( defined $signature ) {
            KeyAlgo_ECDSA_verification( $message, $signature, $key_href );    #public
        }
        else {
            S_set_error( "KeyAlgo_ECDSA : Please provide signature for the verification process...\n", 110 );
            return;
        }

    }
    S_w2log( 2, "KeyAlgo_ECDSA : Process ended\n" );

    return;
}

=head2 KeyAlgo_SHA
    $digest = KeyAlgo_SHA( $message,$nbr_of_bits );
Implements SHA2-256 and SHA2-512
B<Arguments:>
=over
=item $message

Message for which hash would be generated

=item $nbr_of_bits

Accepts Bits of the Hash function

=back

B<Return Values:>
=over

=item $digest

Success : Returns the digest encoded as a binary string.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToHash";
    $nbr_of_bits = 256;
    $signature = KeyAlgo_SHA($message,$nbr_of_bits);
=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_SHA {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_SHA( $message,$nbr_of_bits )', @args )
      or return;

    my $message     = shift @args;
    my $nbr_of_bits = shift @args;

    S_w2log( 4, "KeyAlgo_SHA : Starting Hashing process...\n" );

    my $digest;

    $digest = Digest::SHA::sha256_hex($message) if ( $nbr_of_bits == 256 );
    $digest = Digest::SHA::sha512_hex($message) if ( $nbr_of_bits == 512 );

    unless ( defined $digest ) {
        S_set_error( "KeyAlgo_SHA : Could not generate the Digest(reason could be wrong nbr of bits passed as argument or this variant of SHA is not yet supported..Only sha256 is supported)", 109 );
        return;
    }

    S_w2log( 4, "KeyAlgo_SHA : Digest is generated successfully...\n" );
    return $digest;

}

=head2 KeyAlgo_EdDSA_GenerateKeys
    my ($secret,$public) = KeyAlgo_EdDSA_GenerateKeys();
Function to generate EdDSA secret and public keys.

B<Return Values:>
=over
=item $secret

Creates and returns a new secret key, which is always 32 octets long. The secret key can be used to generate the public key via Crypt::Ed25519::eddsa_public_key and is not the same as the private key used in the Ed25519 API.

=item $public

Takes a secret key generated by Crypt::Ed25519::eddsa_secret_key and returns the corresponding $public_key. The derivation is deterministic, i.e. the $public_key generated for a specific $secret_key is always the same.
   
Success : Generates a pair of secret and public key

Error   : undef 
=back
B<Examples:>
=over
    my ($secret,$public) = KeyAlgo_EdDSA_GenerateKeys();
=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_EdDSA_GenerateKeys {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_EdDSA_GenerateKeys()', @args ) or return;

    my $secret = Crypt::Ed25519::eddsa_secret_key;
    my $public = Crypt::Ed25519::eddsa_public_key $secret;

    return ( $secret, $public );
}

=head2 KeyAlgo_EdDSA_signatureGeneration
Function to generate signature using EdDSA Signature Algorithm
    $signature = KeyAlgo_EdDSA_signatureGeneration($message,$secret);

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $secret

Accepts a secret key, which is always 32 octets long. The secret key can be used to generate the public key via Crypt::Ed25519::eddsa_public_key and is not the same as the private key used in the Ed25519 API.

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message using the public and private keys. The signature is always 64 octets long and deterministic, i.e. it is always the same for a specific combination of $message, $public_key and $private_key, i.e. no external source of randomness is required for signing.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    ($secret,$public) = KeyAlgo_EdDSA_GenerateKeys();
    ( $signature, $pubkey ) = KeyAlgo_EdDSA_signatureGeneration($message,$secret);
=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_EdDSA_signatureGeneration {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_EdDSA_signatureGeneration( $message,$secret,$pubkey )', @args )
      or return;
    my $message = shift @args;
    my $secret  = shift @args;
    my $pubkey = shift @args;
#    /Crypt::Ed25519::eddsa_public_key $secret;

    S_w2log( 2, "KeyAlgo_EdDSA_signatureGeneration : Starting to generate Signature...\n" );
    my $signature = Crypt::Ed25519::eddsa_sign $message, $pubkey, $secret;

    unless ( defined $signature ) {
        S_set_error( "KeyAlgo_EdDSA_signatureGeneration : Could not generate signature", 23 );
        return;
    }

    S_w2log( 2, "KeyAlgo_EdDSA_signatureGeneration : Signature generated\n" );
    return ( $signature);
}

=head2 KeyAlgo_EdDSA_verification
Function used for verification of messages using EdDSA Signature Algorithm
    KeyAlgo_EdDSA_verification($message,$signature,$public)
    
B<Arguments:>
=over
=item $message

Message for which verification would be done.

=item $signature

Accepts a EdDSA generated signature.

=item $public

Public key for EdDSA Signature Algorithm

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";    
    ($secret,$pubkey)KeyAlgo_EdDSA_GenerateKeys();
    $signature = KeyAlgo_EdDSA_signatureGeneration($message,$secret);
    
    KeyAlgo_EdDSA_verification( $message,$signature,$public);

=back

B<Notes: Non Exported function> 
=cut

sub KeyAlgo_EdDSA_verification {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_EdDSA_verification( $message,$signature,$public )', @args )
      or return;

    my $message   = shift @args;
    my $signature = shift @args;
    my $public    = shift @args;

    S_w2log( 2, "KeyAlgo_EdDSA_verification : Starting verification process...\n" );

    my $verify = Crypt::Ed25519::eddsa_verify $message, $public, $signature;

    if ( $verify == 1) {
        S_w2log( 2, "KeyAlgo_EdDSA_verification : Verification sucessfull\n" );
        return 1;
    }
    else {
        S_set_error( "KeyAlgo_EdDSA_verification : Verification not sucessfull due to error", 109 );
        return;
    }
}

=head2 KeyAlgo_EdDSA
Function to generate signature using EdDSA Signature Algorithm
    $signature = KeyAlgo_EdDSA($message,$key,$typeOfOperation);

B<Arguments:>
=over
=item $message

Message for which signature would be generated

=item $key

EdDSA Secret key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function.
In this case it should be "signatureGeneration".

=back

B<Return Values:>
=over

=item $signature

Success : Generates a signature for the given message.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToSign";
    $typeOfOperation = "signatureGeneration";
    ($secret,$public) = KeyAlgo_EdDSA_GenerateKeys();
    
    $signature = KeyAlgo_EdDSA($message,$secret,$typeOfOperation);
    
    
=back

Function used for verification of messages using EdDSA Signature Algorithm
    KeyAlgo_EdDSA($message,$key,$typeOfOperation,$signature)
    
B<Arguments:>
=over
=item $message

Message for which verification would be done

=item $key

EdDSA Public key

=item $typeOfOperation

Can be of two types "signatureGeneration" or "verification". Decides the behaviour of the function.
In this case it should be "verification".

=item $signature

Accepts a EdDSA generated signature.

=back

B<Return Values:>
=over

Success : Verifies if the signature and the new message's signature matches.

Error   : undef 
=back
B<Examples:>
=over
    $message = "messageToVerify";
    $typeOfOperation = "signatureGeneration";
    ($secret,$public) = KeyAlgo_EdDSA_GenerateKeys();
    
    $signature = KeyAlgo_EdDSA($message,$secret,$typeOfOperation);
    
    $typeOfOperation = "verification";
    KeyAlgo_EdDSA($message,$public,$typeOfOperation,$signature);
    
=back

B<Notes: Exported function> 
=cut

sub KeyAlgo_EdDSA {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_EdDSA( $message,$key,$typeOfOperation [,$signature ])', @args )
      or return;

    S_w2log( 2, "KeyAlgo_EdDSA : Initiating process...\n" );

    my $message         = shift @args;
    my $key             = shift @args;
    my $typeOfOperation = shift @args;
    my $signature       = shift @args;

    #    S_w2log( 2, "KeyAlgo_EdDSA : Generating Keys...\n" );
    #    my ( $secret, $public ) = KeyAlgo_EdDSA_GenerateKeys();
    #    S_w2log( 2, "KeyAlgo_EdDSA : Keys generated\n" );

    if ( $typeOfOperation =~ /signatureGeneration/i ) {
        return KeyAlgo_EdDSA_signatureGeneration( $message, $key );    #secret
    }
    elsif ( $typeOfOperation =~ /verification/i ) {
        if ( defined $signature ) {
            return KeyAlgo_EdDSA_verification( $message, $signature, $key );    #public
        }
        else {
            S_set_error( "KeyAlgo_EdDSA : Please provide signature for the verification process...\n", 110 );
            return;
        }

    }
    S_w2log( 2, "KeyAlgo_EdDSA : Process ended\n" );
    return;
}

sub KeyAlgo_SecurityKeyGeneration {

    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_SecurityKeyGeneration($keyHash_href)', @args ) or return;
    my $keyHash_href = shift @args;

    if ( !%$keyHash_href ) {
        S_set_error( "KeyAlgo_SecurityKeyGeneration : Hash is undefined\n", 110 );
        return;
    }

    # LOOP-START Loop over hash for the algorithm name
    # IF Algorithm Name is ECDSA P-256 ?
    #   IF-YES-START
    #       STEP Get the curve name of the ECDSA P-256
    #       CALL KeyAlgo_ECDSA_GenerateKeys with curve name
    #       STEP Return private and public key as hash
    #   IF-YES-END
    # IF Algorithm Name is RSASSA-PSS ?
    #   IF-YES-START
    #       STEP Get the number of bits for RSASSA-PSS
    #       CALL KeyAlgo_RSA_GenerateKeys with number of bits
    #       STEP Return private and public key as hash
    #   IF-YES-END
    # IF Algorithm Name is RSASSA_PKCS1-v1_5 ?
    #   IF-YES-START
    #       STEP Get the number of bits for RSASSA-PSS
    #       CALL KeyAlgo_RSA_GenerateKeys with number of bits
    #       STEP Return private and public key as hash
    #   IF-YES-END
    # IF Algorithm Name is EdDSA ?
    #   IF-YES-START
    #       CALL KeyAlgo_EdDSA_GenerateKeys
    #       STEP Return private and public key as hash
    #   IF-YES-END
    # LOOP-END
    my %keys;
    foreach my $algoName ( keys %$keyHash_href ) {

        if ( $algoName eq "ECDSA P-256" ) {
            my $curveName = $keyHash_href->{$algoName}{"CURVE_NAME"};
            my ( $publicKey, $privateKey ) = KeyAlgo_ECDSA_GenerateKeys($curveName);
            $keys{"ECDSA P-256"}{"PRIVATE_KEY"} = $privateKey;
            $keys{"ECDSA P-256"}{"PUBLIC_KEY"}  = $publicKey;

        }
        elsif ( ( $algoName eq "RSASSA-PSS" ) or ( $algoName eq "RSASSA_PKCS1-v1_5" ) ) {
            my $bits = $keyHash_href->{$algoName}{"BITS"};
            my ( $publicKey, $privateKey ) = KeyAlgo_RSA_GenerateKeys($bits);
            if ( $algoName eq "RSASSA-PSS" ) {
                $keys{"RSASSA-PSS"}{"PRIVATE_KEY"} = $privateKey;
                $keys{"RSASSA-PSS"}{"PUBLIC_KEY"}  = $publicKey;
            }
            else {
                $keys{"RSASSA_PKCS1-v1_5"}{"PRIVATE_KEY"} = $privateKey;
                $keys{"RSASSA_PKCS1-v1_5"}{"PUBLIC_KEY"}  = $publicKey;
            }
        }
        elsif ( $algoName eq "EdDSA" ) {

            my ( $privateKey, $publicKey ) = KeyAlgo_EdDSA_GenerateKeys();
            $keys{"EdDSA"}{"PRIVATE_KEY"} = $privateKey;
            $keys{"EdDSA"}{"PUBLIC_KEY"}  = $publicKey;
        }
        else {
            S_set_error( "KeyAlgo_SecurityKeyGeneration : Specified Algorithm not found or Invalid\n", 109 );
            return;
        }
    }

    #    use Data::Dumper;
    #    print Dumper( \%keys );
    return \%keys;
}

sub KeyAlgo_SecurityAlgorithms {
    my @args = @_;
    S_checkFunctionArguments( 'KeyAlgo_SecurityAlgorithms($keyHash_href)', @args ) or return;
    my $keyHash_href = shift @args;

    if ( !%$keyHash_href ) {
        S_set_error( "KeyAlgo_SecurityAlgorithms : Hash is undefined\n", 110 );
        return;
    }

    # LOOP-START Loop over hash for the algorithm name
    # STEP Get message
    # IF Type of operation is Signature Generation ?
    # IF-YES-START
    # STEP Get private key
    # IF Algorithm name is ECDSA P-256
    # IF-YES-START
    #CALL KeyAlgo_ECDSA_signatureGeneration with message and private key
    # IF-YES-END
    # IF Algorithm name is EdDSA
    # IF-YES-START
    #CALL KeyAlgo_EdDSA_signatureGeneration with message and private key
    # IF-YES-END
    # IF Algorithm name is RSASSA_PKCS1-v1_5
    # IF-YES-START
    #CALL KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration with message and private key
    # IF-YES-END
    # IF Algorithm name is RSASSA-PSS
    # IF-YES-START
    #CALL KeyAlgo_RSA_SS_PSS_signatureGeneration with message and private key
    # IF-YES-END
    # IF-YES-END
    # IF Type of operation is Verification ?
    # IF-YES-START
    # STEP Get Public key
    # STEP Get Signature
    # IF Algorithm name is ECDSA P-256
    # IF-YES-START
    #CALL KeyAlgo_ECDSA_verification with Message, Signature and Public key
    # IF-YES-END
    # IF Algorithm name is EdDSA
    # IF-YES-START
    #CALL KeyAlgo_EdDSA_verification with Message, Signature and Public key
    # IF-YES-END
    # IF Algorithm name is RSASSA_PKCS1-v1_5
    # IF-YES-START
    #CALL KeyAlgo_RSA_SS_PKCS1_V1_5_verification with Message, Signature and Public key
    # IF-YES-END
    # IF Algorithm name is RSASSA-PSS
    # IF-YES-START
    #CALL KeyAlgo_RSA_SS_PSS_verification with Message, Signature and Public key
    # IF-YES-END
    # IF-YES-END
    # LOOP-END
    my %signatureAndVerificationHash;
    foreach my $algoName ( keys %$keyHash_href ) {
        my $message = $keyHash_href->{$algoName}{"MESSAGE"};
        if ( $keyHash_href->{$algoName}{"TYPE_OF_OPERATION"} eq "SIGNATURE_GENERATION" ) {
            my $privateKey = $keyHash_href->{$algoName}{"PRIVATE_KEY"};
            if ( $algoName eq "ECDSA P-256" ) {
                $signatureAndVerificationHash{"ECDSA P-256"}{"SIGNATURE"} = KeyAlgo_ECDSA_signatureGeneration( $message, $privateKey );
            }
            elsif ( $algoName eq "EdDSA" ) {
                my $publicKey = $keyHash_href->{"EdDSA"}{"PUBLIC_KEY"};
                $signatureAndVerificationHash{"EdDSA"}{"SIGNATURE"} = KeyAlgo_EdDSA_signatureGeneration( $message, $privateKey,$publicKey);
            }
            elsif ( $algoName eq "RSASSA_PKCS1-v1_5" ) {
                $signatureAndVerificationHash{"RSASSA_PKCS1-v1_5"}{"SIGNATURE"} = KeyAlgo_RSA_SS_PKCS1_V1_5_signatureGeneration( $message, $privateKey );
            }
            elsif ( $algoName eq "RSASSA-PSS" ) {
                $signatureAndVerificationHash{"RSASSA-PSS"}{"SIGNATURE"} = KeyAlgo_RSA_SS_PSS_signatureGeneration( $message, $privateKey );
            }
        }
        elsif ( $keyHash_href->{$algoName}{"TYPE_OF_OPERATION"} eq "VERIFICATION" ) {
            my $publicKey = $keyHash_href->{$algoName}{"PUBLIC_KEY"};
            my $signature = $keyHash_href->{$algoName}{"SIGNATURE"};
            if ( $algoName eq "ECDSA P-256" ) {
                my $verificationStatus = KeyAlgo_ECDSA_verification( $message, $signature, $publicKey );
                unless ( defined $verificationStatus ) {
                    $signatureAndVerificationHash{"ECDSA P-256"}{"VERIFICATION_STATUS"} = "NOT_VERIFIED";
                }
                else {
                    $signatureAndVerificationHash{"ECDSA P-256"}{"VERIFICATION_STATUS"} = "VERIFIED";
                }
            }
            elsif ( $algoName eq "EdDSA" ) {
                my $verificationStatus = KeyAlgo_EdDSA_verification( $message, $signature, $publicKey );
                unless ( defined  $verificationStatus ) {
                    $signatureAndVerificationHash{"EdDSA"}{"VERIFICATION_STATUS"} = "NOT_VERIFIED";
                }
                else {
                    $signatureAndVerificationHash{"EdDSA"}{"VERIFICATION_STATUS"} = "VERIFIED";
                }
            }
            elsif ( $algoName eq "RSASSA_PKCS1-v1_5" ) {
                my $verificationStatus = KeyAlgo_RSA_SS_PKCS1_V1_5_verification( $message, $signature, $publicKey );
                unless ( defined $verificationStatus ) {
                    $signatureAndVerificationHash{"RSASSA_PKCS1-v1_5"}{"VERIFICATION_STATUS"} = "NOT_VERIFIED";
                }
                else {
                    $signatureAndVerificationHash{"RSASSA_PKCS1-v1_5"}{"VERIFICATION_STATUS"} = "VERIFIED";
                }
            }
            elsif ( $algoName eq "RSASSA-PSS" ) {
                my $verificationStatus = KeyAlgo_RSA_SS_PSS_verification( $message,$publicKey, $signature );
                unless ( defined $verificationStatus ) {
                    $signatureAndVerificationHash{"RSASSA-PSS"}{"VERIFICATION_STATUS"} = "NOT_VERIFIED";
                }
                else {
                    $signatureAndVerificationHash{"RSASSA-PSS"}{"VERIFICATION_STATUS"} = "VERIFIED";
                }
            }
        }
        else {
            S_set_error( "KeyAlgo_SecurityAlgorithms : Specified TYPE_OF_OPERATION is not found or Invalid\n", 109 );
            return;
        }
    }
    return \%signatureAndVerificationHash;
}

1;

