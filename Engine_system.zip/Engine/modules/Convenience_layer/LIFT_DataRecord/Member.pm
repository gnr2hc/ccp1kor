# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package Member;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################

use strict;
use warnings;
use Moose;
use namespace::autoclean;

use LIFT_general;

our ( $VERSION, $HEADER );

=head1 NAME

Member 
=head1 SYNOPSIS

    use LIFT_DataRecord::Member;
    
    # create a data member object
    $member_obj = Member -> new([RawValue, DecodingInfo]);

=head1 DESCRIPTION

This class describes the structure of a data record member.

The attributes of the member can be fetched or set.

The class LIFT_DataRecord will interact with this Member class.

=cut

=head1 ATTRIBUTES

=over

=item RawValue

Raw value of the member.

=item RawValuesArray

Raw values of the member in case it has various data samples

=cut

# Following attributes will be set when member is created
# 1 Value -> 1 Byte, RawValuesArray is an array of bytes
has RawValue => ( is => "rw", isa => 'Int' );
has RawValuesArray => ( is => "rw", isa => 'ArrayRef' );
has DecodingInformation => (is => "rw", isa => 'Maybe[HashRef]');

# Raw Value split into data samples
# 1 data sample
has RawValue_Hex => ( is => "rw", isa => 'Maybe[Str]', lazy => 1,builder => '_set_RawValue_Hex' );
has RawValueDataSample => ( is => "rw", isa => 'Maybe[Int]', lazy => 1, builder => '_set_RawValueDataSample' );

# more than 1 data sample
has RawValueDataSamples_Hex => ( is => "rw", isa => 'Maybe[ArrayRef]', lazy => 1, builder => '_set_RawValueDataSamples_Hex' );
has RawValueDataSamples => ( is => "rw", isa => 'Maybe[ArrayRef]', lazy => 1, builder => '_set_RawValueDataSamples' );

# Decoded Values
# 1 data sample
has DecodedValue => (is => "rw", isa => 'Value'); # can be string, integer, float...
# more than 1 data sample
has DecodedValuesArray => (is => "rw", isa => 'ArrayRef'); # can be string, integer, float...

# Description of the member
has Description => (is => "rw", isa => 'Str');

=head1 METHODS

=head2 decode

    $member_obj -> decode();

Sets attribute DecodedValue / DecodedValuesArray

Supported decoding types are:

=over

=item numeric

Raw data sample converted to decoded by applying factor and offset.

Formula:

    DecodedValue = (RawValue * Factor) + Offset

=back

Returns 1 on success, undef otherwise

=cut

sub decode {
    my $self = shift;

    if(not defined $self -> {'DecodingInformation'}){
        S_set_error("Decoding not possible - no decoding information given! Set attribute 'DecodingInformation' first.");
        return;
    }

    my $decodingType = $self -> {'DecodingInformation'} -> {'DataType'};
    if(not defined $decodingType){
        S_w2log(4, "LIFT_Member -> decode: No 'DataType' given for decoding. Default is 'numeric' with factor 1 and offset 0.");
        $decodingType = 'numeric';       
    }

    if(not $decodingType =~ m/numeric|interpreted/){
        S_set_error("Decoding not possible - DataType '$decodingType' is not known.\n".
                    "Possible data types are: numeric, interpreted, continuous, none");
        return;                
    }
    
    $self -> {Description} = $self -> {'DecodingInformation'} -> {'Description'};

    if(not defined $self -> RawValueDataSample and not defined $self -> RawValueDataSamples){
        S_set_error("No raw value defined for this member. Decoding not possible.");
        return;        
    }

    # Decode    
    my $decodingDispatchTable ||= {
        numeric => \&_decode_numeric,
        interpreted => \&_decode_interpreted,
    }; 

    my $decodingSuccess = $decodingDispatchTable -> {$decodingType} -> ($self);
    
    return $decodingSuccess;
}

=head2 INTERNAL FUNCTIONS

=head3 _decode_numeric

    $success = $self -> _decode_numeric();
    
Called by function decode() in case the decoding type for the member is 'numeric'

=cut
sub _decode_numeric {
    my $self = shift;
    
    my $factor = $self -> {'DecodingInformation'} -> {'Factor'};
    $factor = 1 unless($factor);
    
    my $offset = $self -> {'DecodingInformation'} -> {'Offset'};
    $offset = 0 unless($offset);
    
    if(defined $self -> {RawValueDataSample}){
        $self -> {DecodedValue} = ($self -> {RawValueDataSample} * $factor) + $offset;
        return 1;
    }

    unless(defined $self -> {RawValueDataSamples}){
        S_set_error("No data samples defined. Decoding not possible.");
        return;
    }

    foreach my $dataSample (@{$self -> {RawValueDataSamples}}){
        my $decodedDataSample = ($dataSample * $factor) + $offset;
        push(@{$self -> {DecodedValuesArray}}, $decodedDataSample);
    }

    return 1;
}

=head3 _decode_interpreted

    $success = $self -> _decode_interpreted();
    
Called by function decode() in case the decoding type for the member is 'interpreted'

=cut
sub _decode_interpreted {
    my $self = shift;
    
    my $dataValueTable = $self -> {'DecodingInformation'} -> {'DataValueTable'};
    if(not defined $dataValueTable){
        S_set_error("'DataValueTable' for decoding type 'interpreted' in data definition mapping not defined. Decoding not possible.");
        return;
    }
    
    if(ref($dataValueTable) ne 'HASH'){
        S_set_error("'DataValueTable' for decoding type 'interpreted' in data definition mapping defined in wrong format.\n".
                    "Define as hash! Example: 'DataValueTable' => {2 => 'PositionA', 3 => 'PositionB'}\n".
                    "Decoding not possible.");
        return;
    }
    
    if(defined $self -> {RawValueDataSample}){
        my $decValue = $self -> {RawValueDataSample};
        my $interpretedValue = $dataValueTable -> {$decValue};
        unless(defined $interpretedValue){
            S_set_error("For value '$decValue' , no interpreted value defined in 'DataValueTable'. Decoding not possible.");
            return;
        }
        $self -> {DecodedValue} = $interpretedValue;
        return 1;
    }

    unless(defined $self -> {RawValueDataSamples}){
        S_set_error("No data samples defined. Decoding not possible.");
        return;
    }

    my @valuesNotDefined;
    foreach my $dataSample (@{$self -> {RawValueDataSamples}}){
        my $interpretedValue = $dataValueTable -> {$dataSample};
        unless(defined $interpretedValue){
            push(@valuesNotDefined, $interpretedValue);
            next;        
        }
        push(@{$self -> {DecodedValuesArray}}, $interpretedValue);
    }
    
    if(@valuesNotDefined >= 1){
        S_set_error("Following values are not defined in 'DataValueTable' (decoding not possible):\n".
                        "@valuesNotDefined");
        return;
    }

    return 1;
}


=head2 USER-DEFINED SETTERS

For the raw value, the automatically generated setters are not sufficient.

Reason: The input raw value will be given byte-wise. 
This byte-wise values must be converted to raw values on data sample basis.

That means e.g. for a member with 1 data sample, 2 bytes per data sample, the raw data given as input will be an array of two bytes. 
This will be converted to a single raw value where these 2 bytes are combined to 1 data sample.

=head3 _set_RawValue_Hex

    $success = $self -> _set_RawValue_Hex();
    
Setter for attribute 'RawValue_Hex'.

This attribute contains the member raw value in hex for members with one data sample (regardless of the number of bytes per data sample).

=cut
sub _set_RawValue_Hex {
    my $self = shift;
    
    return unless(defined $self -> RawValueDataSample);
    
    my $bytesPerDataSample = $self -> {'DecodingInformation'} -> {'BytesPerDataSample'} // 1;
    my $numberOfCharacters = $bytesPerDataSample * 2;

    $self -> {RawValue_Hex} = sprintf("%0".$numberOfCharacters."X", $self -> RawValueDataSample);
    
    return $self -> {RawValue_Hex};
}

=head3 _set_RawValueDataSamples_Hex

    $success = $self -> _set_RawValueDataSamples_Hex();
    
Setter for attribute 'RawValueDataSamples_Hex'.

This attribute contains the member raw value in hex for members with more than one data sample 
(regardless of the number of bytes per data sample).

=cut
sub _set_RawValueDataSamples_Hex {
    my $self = shift;
    
    return unless(defined $self -> RawValueDataSamples());

    my $bytesPerDataSample = $self -> {'DecodingInformation'} -> {'BytesPerDataSample'} // 1;
    my $numberOfCharacters = $bytesPerDataSample * 2;

    foreach my $rawValueDec (@{$self -> {RawValueDataSamples}}){
        push(@{$self -> {RawValuesArray_Hex}}, sprintf("%0".$numberOfCharacters."X", $rawValueDec));
    }
    
    return $self -> {RawValuesArray_Hex};
}

=head3 _set_RawValueDataSample

    $success = $self -> _set_RawValueDataSample();
    
Setter for attribute 'RawValueDataSample_Hex'.

This attribute contains the member raw value in dec for members with one data sample 
(regardless of the number of bytes per data sample).

=cut
sub _set_RawValueDataSample {
    my $self = shift;
    
    if(defined $self -> {RawValue}){
        $self -> {RawValueDataSample} = $self -> {RawValue};
    }
    elsif(defined $self -> {RawValuesArray}){
        my $numberOfDataSamples = $self -> {'DecodingInformation'} -> {'NumberOfDataSamples'};
        if(not defined $numberOfDataSamples){
            S_set_error("Splitting raw data into data samples not possible due to missing attribute 'NumberOfDataSamples' in 'DecodingInformation'.");
            return;
        }
        return undef if($numberOfDataSamples > 1); # more than one data sample

        my $bytesPerDataSample = $self -> {'DecodingInformation'} -> {'BytesPerDataSample'};
        if(not defined $bytesPerDataSample){
            S_set_error("Splitting raw data into data samples not possible due to missing attribute 'BytesPerDataSample' in 'DecodingInformation'.");
            return;
        }
        my $sampleHex;
        my $rawValueIndex = 0;
        foreach my $bytesInDataSample (1..$bytesPerDataSample){
            $sampleHex .= sprintf("%02X", $self -> {RawValuesArray} -> [$rawValueIndex]);
            $rawValueIndex++;
        }
        $self -> {RawValueDataSample} = hex($sampleHex);        
    }

    return $self -> {RawValueDataSample};
}

=head3 _set_RawValueDataSamples

    $success = $self -> _set_RawValueDataSamples();
    
Setter for attribute 'RawValueDataSamples'.

This attribute contains the member raw value in dec for members with more than one data sample 
(regardless of the number of bytes per data sample).

=cut
sub _set_RawValueDataSamples {
    my $self = shift;
    
    return unless(defined $self -> {RawValuesArray});

    my @notDefinedMandatoryAttributes;
    my $numberOfDataSamples = $self -> {'DecodingInformation'} -> {'NumberOfDataSamples'};
    push(@notDefinedMandatoryAttributes, 'NumberOfDataSamples') if(not defined $numberOfDataSamples);

    my $bytesPerDataSample = $self -> {'DecodingInformation'} -> {'BytesPerDataSample'};
    push(@notDefinedMandatoryAttributes, 'BytesPerDataSample') if(not defined $bytesPerDataSample);

    if(@notDefinedMandatoryAttributes > 0){
        S_set_error("Splitting raw data into data samples not possible due to missing attributes in 'DecodingInformation'.\n".
                    "Missing: @notDefinedMandatoryAttributes");
        return;        
    }

    return 1 if($numberOfDataSamples == 1);

    my $rawValueIndex = 0;
    foreach my $dataSample (1..$numberOfDataSamples){
        my $sampleHex;         
        foreach my $bytesInDataSample (1..$bytesPerDataSample){
            $sampleHex .= sprintf("%02X", $self -> {RawValuesArray} -> [$rawValueIndex]);
            $rawValueIndex++;
        }
        push(@{$self -> {RawValueDataSamples}}, hex($sampleHex));
    }

    return $self -> {RawValueDataSamples};
}

__PACKAGE__->meta->make_immutable;

1;

