package FuncLib_SPILC_Framework;

use strict;
use warnings;

use LIFT_general;
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_spi_access;
use Clone 'clone';

use Exporter;

our ( $VERSION, $HEADER );

our ( @ISA, @EXPORT );

BEGIN {
    @ISA    = qw(Exporter);
    @EXPORT = qw(
      SPILC_prepare_squib_faults
      SPILC_prepare_pas_faults
      SPILC_prepare_switch_faults
      SPILC_resolve_signal_label
      SPILC_set_FireCounter
      SPILC_ShortLines
      SPILC_UndoShortLines
      SPILC_ConnectLine
      SPILC_DisconnectLine
      SPILC_init
    );
}

my $mappingSpiNw_href;
my $mappingdevice_href;
my $SPILC_FuncMap_href;
my $device_config_href;
my $spi_manipulation_status;

my $SPILC_init_flag     = 0;
my $sig_collection_href = {
    squibs   => [ 'res_value_raw', 'validity_flag', 'fire_cnt_high_level', 'fire_cnt_low_level' ],
    switches => [ 'adc_data',      'sup',           'vd',                  'vzl' ],
    pases    => ['vzl'],
};

my $device_func_map_href = {

    'squibs'   => \&SPILC_prepare_squib_faults,
    'pases'    => \&SPILC_prepare_pas_faults,
    'switches' => \&SPILC_prepare_switch_faults,
};

my $device_track_status     = {};    # This variable is used in SPILC connect and disconnect line functions
my $dev_name_uppercase_href = {};    # This variable is used to collect the device name converted to upper case.

=head1 NAME

FuncLib_SPILC_Framework $Revision :

=head1 SYNOPSIS

    use FuncLib_SPILC_Framework;

    #
    # Function SPI_init() from library LIFT_spi_access.pm 
    # should be called before using SPILC functions
    #


    # 'Mapping_SPI' and 'SPILC_FunctionMapping' must be defined 
    #       according to project in Mapping_SPI_network.pm
    #  Location of Template Mapping: 
    #       g:/MKS/Projects/TurboLIFT/Template/config/Mapping_SPI_network.pm.
    #
    #
    #
    # Mapping_DEVICE is required for device types switches, inorder to determine the switch type
    #
    #
    
    SPILC_init();

    SPILC_DisconnectLine( 'AB1FD' );

    SPILC_ConnectLine ('AB1FD');

    SPILC_ShortLines ( ['AB1FD+', 'B+'] );

    SPILC_UndoShortLines ();

=head1 DESCRIPTION

Provides common functions for SPI line manipulations tests.

Line manipulation is done by changing the values of MISO signals.
    
B<LIFT_labcar functions are used to call SPILC functions.>
    
    # CONFIGURATION UPDATE of TEMPLATE Mapping_SPI_Network.pm IS REQUIRED 
    # IN FOLLOWING CASE :
     
    # 1. SWITCHES based on current measurement: The Values for openline 
    #           and shortline for switches needs to changed.

    # 2. PASES: Timeslot for the pas device has to be configured,
    #            which can be found in SYC of the project.

=head1 CONFIGURATION

=head2 Testbench Configuration for line manipulations using SPILC

    'Devices' => {
        ...
        'Manitoo' => {
                'Connection_Type' => 'COM15',
                    # Supported types 'COM<PORT_NUMBER>', 'USB'
                    # COM<PORT_NUMBER> : COM port detected when connected to TestPC
                    # USB : USB-A to USB-A connector.
                    # Drivers needs to be installed for this : refer link
                    # https://inside-docupedia.bosch.com/confluence/display/MOBIT/Setup+USB+connection+for+mobiTOOL
                    
                'FET_HW_Type' => 'FET_3_Ports' ,
                'FET_PortsSelection' => 1 , 
            }, 
        ...
    },
        
    'Functions' => {
        ...
        'Labcar' => {
                'power_Ubat' => 'Manitoo',
                'line' => 'SPILC'
            },

        'SPI_Access' => {
           'manipulate' => 'Manitoo',
        }
        ...
    },
    
=head1 Line Functions

=cut

=head2 SPILC_init

    $returnValue = SPILC_init(); 

This functions collect SPI mapping data.

B<Arguments: NONE>

B<Return Value:>

=over

=item $returnValue 

1 on Success

undef on failure

=back

=cut

sub SPILC_init {

    $mappingSpiNw_href  = S_get_contents_of_hash( ['Mapping_SPI'] );
    $mappingdevice_href = S_get_contents_of_hash( ['Mapping_DEVICE'] );
    $SPILC_FuncMap_href = S_get_contents_of_hash( ['SPILC_FunctionMapping'] );

    #STEP collect SPI mapping details else return with error
    unless ($mappingSpiNw_href) {
        S_set_error( "SPILC_init: 'Mapping_SPI' not defined in 'Mapping_SPI_network.pm'\n", 109 );
        return;
    }
    unless ($SPILC_FuncMap_href) {
        S_set_error( "SPILC_init: 'SPILC_FunctionMapping' not defined in 'Mapping_SPI_network.pm'\n", 109 );
        return;
    }

    if ($SPILC_init_flag) {
        S_w2log( 3, "SPILC already initialised nothing to do !" );
        return 1;
    }

    #STEP Initialise SPI data base else return with error.
    return unless ( SPI_init() );

    #STEP Initialise PRD and collect device configuration
    return unless ( PRD_init() );
    $device_config_href = PRD_Get_Device_Configuration( { 'NOHTML' => 1, } );

    unless ($device_config_href) {
        S_set_error( "SPILC_init: Failed to get device configuration, please check sad file configured is matching with software", 109 );
        return;
    }

    #convert device name to upper case
    foreach my $dev_type ( keys %$device_config_href ) {
        map { $dev_name_uppercase_href->{$dev_type}{ uc $_ } = $device_config_href->{$dev_type}{$_} } keys %{ $device_config_href->{$dev_type} };
    }

    $SPILC_init_flag = 1;

    return 1;
}

=head2 SPILC_prepare_squib_faults

    $returnValue = SPILC_prepare_squib_faults( $options_href ); 

This functions prepares the SPI data required for squibs faults.

B<Arguments:>

=over

=item $options_href 

    $options_href = {
                     'Fault_type' => 'short2gnd',
                     'Lines' => [ 'AB1FD+' ] ,
                     'Duration_ms' => '200'  ( or ) 'FrameCycles' => '50' ,
                     'res_value_raw' =>  0 .. 2047 , # optional
                     'validity_flag' => 1|0 , # optional
                                              # 1 - valid  , 
                                              # 0 - invalid/old
                    };

B<'Fault_type' Range>: 'short2gnd' or 'short2bat' or 'cross-coupling' or 'cross-coupling2gnd' or 'cross-coupling2bat'

B<'Lines' Range>: [ 'AB1FD+', 'AB1FP+', .... ]

B<'Duration_ms'>: Duration in ms for the manipualtion of SPI data for the squib.

( or )

B<'FrameCycles'>: (integer) Number of SPI frames to be manipulated.
 
=back

B<Return Value:>

=over

=item $returnValue 

1 on Success

undef on failure

=back

Examples:

1. Short2gnd

  SPILC_prepare_squib_faults( { 'Fault_type' => 'short2gnd' ,
                                'Lines' => [ 'AB1FD+' ] ,
                                'Duration_ms' => '200'
                              }
                            );

2. Short2bat

  SPILC_prepare_squib_faults( { 'Fault_type' => 'short2bat' ,
                                'Lines' => [ 'BT1RD+' ] ,
                                'FrameCycles' => '20'
                              }
                            );

=cut

sub SPILC_prepare_squib_faults {

    my @args = @_;

    # variables required to pass as argument to 'S_checkFunctionArgumentHashKeys'
    my $valid_keys_href = { 'Fault_type' => 1, 'Lines' => 1, 'Duration_ms' => 1, 'FrameCycles' => 1, 'res_value_raw' => 1, 'validity_flag' => 1 };
    my $mand_keys_href = { 'Fault_type' => 1, 'Lines' => 1 };

    my $options_href = shift @args;
    return unless S_checkFunctionArgumentHashKeys( 'SPILC_prepare_squib_faults', $options_href, $valid_keys_href, $mand_keys_href );

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    #STEP check if duration or framecycles are defined else return with error
    unless ( defined $options_href->{Duration_ms} or defined $options_href->{FrameCycles} ) {
        S_set_error( "SPILC_prepare_squib_faults: Either Duration_ms or FrameCycles should be cofigured\n", 109 );
        return;
    }

    $options_href->{device_type} = 'squibs';

    #CALL Load_spi_signals to prepare the squib faults
    return unless ( Load_spi_signals($options_href) );

    return 1;
}

=head2 SPILC_prepare_pas_faults

    $returnValue = SPILC_prepare_pas_faults( $options_href ); 

This functions prepares the SPI data required for pas faults.

B<Arguments:>

=over

=item $options_href 

    $options_href = {
                     'Fault_type' => 'short2gnd',
                     'Lines' => [ 'AB1FD+' ] ,
                     'Duration_ms' => '200'  ( or ) 'FrameCycles' => '50' ,
                     'vzl' => 1|0 # 1-> vzp too low, 0 -> VZP ok
                    };

B<'Fault_type' Range>: 'short2gnd' or 'short2bat' 

B<'Lines' Range>: [ 'UfsP+', 'UfsD+', .... ]

B<'Duration_ms'>: Duration in ms for the manipualtion of SPI data for the PAS.

( or )

B<'FrameCycles'>: (integer) Number of SPI frames to be manipulated.
 
=back

B<Return Value:>

=over

=item $returnValue 

1 on Success

undef on failure

=back

Examples:

1. Short2gnd

  SPILC_prepare_pas_faults( { 'Fault_type' => 'short2gnd' ,
                              'Lines' => [ 'UfsP+' ] ,
                              'Duration_ms' => '200'
                            }
                          );
  
2. Short2bat

  SPILC_prepare_pas_faults( { 'Fault_type' => 'short2bat' ,
                              'Lines' => [ 'UfsD+' ] ,
                              'FrameCycles' => '20'
                            }
                          );

=cut

sub SPILC_prepare_pas_faults {

    my @args = @_;

    # variables required to pass as argument to 'S_checkFunctionArgumentHashKeys'
    my $valid_keys_href = { 'Fault_type' => 1, 'Lines' => 1, 'Duration_ms' => 1, 'FrameCycles' => 1, 'vzl' => 1, };
    my $mand_keys_href = { 'Fault_type' => 1, 'Lines' => 1 };

    my $options_href = shift @args;
    return unless S_checkFunctionArgumentHashKeys( 'SPILC_prepare_pas_faults', $options_href, $valid_keys_href, $mand_keys_href );

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    #STEP check if duration or framecycles are defined else return with error
    unless ( defined $options_href->{Duration_ms} or defined $options_href->{FrameCycles} ) {
        S_set_error( "SPILC_prepare_pas_faults Either Duration_ms or FrameCycles should be cofigured\n", 109 );
        return;
    }

    $options_href->{device_type} = 'pases';

    #CALL Load_spi_signals to prepare the pas faults
    return unless ( Load_spi_signals($options_href) );

    return 1;
}

=head2 SPILC_prepare_switch_faults

    $returnValue = SPILC_prepare_switch_faults( $options_href ); 

This functions prepares the SPI data required for switch faults.

B<Arguments:>

=over

=item $options_href 

    $options_href = {
                     'Fault_type' => 'short2gnd',
                     'Lines' => [ 'AB1FD+' ] ,
                     'Duration_ms' => '200'  ( or ) 'FrameCycles' => '50' ,
                     'adc_data' => 0 .. 1023, # 10 bit value
                    };

B<'Fault_type'>: 'short2bat' or 'short2gnd' or 'openline' or 'undefined' or 'shortline'.

'adc_data' has to be configured for Fault_type('short2gnd', 'openline', 'undefined', 'shortline' ),
because the fault qualification is based on 'adc_data'. 

B<'Lines' Range>: [ 'BLFD+', 'BLFP+', .... ]

B<'Duration_ms'>: Duration in ms for the manipualtion of SPI data for the PAS.

( or )

B<'FrameCycles'>: (integer) Number of SPI frames to be manipulated.
 
=back

B<Return Value:>

=over

=item $returnValue 

1 on Success

undef on failure

=back

Examples:

1. Short2gnd

    SPILC_prepare_switch_faults( { 'Fault_type' => 'short2gnd' ,
                                   'Lines' => [ 'BLFD+' ] ,
                                   'Duration_ms' => '200',
                                   'adc_data' => 1023 
                                 } 
                               );
  
2.  Undefined

    SPILC_prepare_switch_faults( { 'Fault_type' => 'undefined' , 
                                   'Lines' => [ 'BLFD+' ] ,
                                   'Duration_ms' => '200',
                                   'adc_data' => 255
                                 } 
                               );
  
3. Short2bat

    SPILC_prepare_switch_faults( { 'Fault_type' => 'short2bat' ,
                                   'Lines' => [ 'BLFD+' ] , 
                                   'FrameCycles' => '20'
                                 }
                               );

4. openline

    SPILC_prepare_switch_faults( { 'Fault_type' => 'short2bat' ,
                                   'Lines' => [ 'BLFD+' ] ,
                                   'Duration_ms' => '200',
                                   'adc_data' => 0
                                 }
                               );

=cut

sub SPILC_prepare_switch_faults {

    my @args = @_;

    # variables required to pass as argument to 'S_checkFunctionArgumentHashKeys'
    my $valid_keys_href = { 'Fault_type' => 1, 'Lines' => 1, 'Duration_ms' => 1, 'FrameCycles' => 1, 'adc_data' => 1, 'supply_error' => 1, 'sds_flag' => 1, 'vzl' => 1, };
    my $mand_keys_href = { 'Fault_type' => 1, 'Lines' => 1 };

    my $options_href = shift @args;
    return unless S_checkFunctionArgumentHashKeys( 'SPILC_prepare_switch_faults', $options_href, $valid_keys_href, $mand_keys_href );

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );
    unless ( defined $options_href->{Duration_ms} or defined $options_href->{FrameCycles} ) {
        S_set_error( "SPILC_prepare_switch_faults Either Duration_ms or FrameCycles should be cofigured\n", 109 );
        return;
    }

    #STEP if adc_data is initialised and check its range
    if ( defined $options_href->{adc_data} ) {
        if ( $options_href->{adc_data} < 0 or $options_href->{adc_data} > 1023 ) {
            S_set_error( "SPILC_prepare_switch_faults: 'adc_data' out of range. Valid Range 0 .. 1023\n", 109 );
            return;
        }
    }

    $options_href->{device_type} = 'switches';

    #CALL Load_spi_signals to prepare the switch faults
    return unless ( Load_spi_signals($options_href) );

    return 1;
}

=head2 SPILC_resolve_signal_label

    $returnValue = SPILC_resolve_signal_label( $options_href ); 

This functions prepares the SPI data required for switch faults.

B<Arguments:>

=over

=item $options_href 

    $options_href = {
                       'Device_type' => 'switches' ,
                       'Line' => 'BLFD' ,
                       'Mapping_Label' => 'adc_data',
                    };


=back

B<Return Value:>

=over

=item $returnValue 

1 on Success

undef on failure

=back

Examples:

1. Switch BLFD Short2gnd

	SPILC_resolve_signal_label ( { 'Device_type' => 'switches' ,
	                               'Line' => 'BLFD+' ,
	                               'Mapping_Label' => 'adc_data' 
	                             }
	                           );
  
2. PAS UFSD Sensor Data  (PSI_READ_DATA<ASIC_CH_TS>)

    SPILC_resolve_signal_label ( { 'Device_type' => 'pases' ,
                                   'Line' => 'UFSD' ,
                                   'Mapping_Label' => 'psi_data'
                                 }
                               );

3. Squib AB1FD Resistor value  (AB1FD or AB1FD+ can be given)

    SPILC_resolve_signal_label ( { 'Device_type' => 'squibs' ,
                                   'Line' => 'AB1FD+' ,
                                   'Mapping_Label' => 'psi_data'
                                 }
                               );

4. Analog I/O Status of System_Warning_Indicator

    SPILC_resolve_signal_label ( { 'Device_type' => 'analog_io' ,
                                   'Line' => 'System_Warning_Indicator' ,
                                   'Mapping_Label' => 'aio_status'
                                 }
                               );

=cut

sub SPILC_resolve_signal_label {

    my @args = @_;

    # variables required to pass as argument to 'S_checkFunctionArgumentHashKeys'
    my $valid_keys_href = { 'Device_type' => 1, 'Line' => 1, 'Mapping_Label' => 1 };
    my $mand_keys_href  = { 'Device_type' => 1, 'Line' => 1, 'Mapping_Label' => 1 };

    my $options_href = shift @args;
    return unless S_checkFunctionArgumentHashKeys( 'SPILC_resolve_signal_label', $options_href, $valid_keys_href, $mand_keys_href );

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    $options_href->{Line} =~ s/\+//;

    #CALL Get_spi_details to retrieve the node and command detils
    my $command_details_href = Get_spi_details( $options_href->{Device_type}, $options_href->{Line}, $options_href->{Mapping_Label} );

    return if ( not defined $command_details_href );

    my $resolvedSiglabel;

    foreach my $key ( keys %$command_details_href ) {
        foreach my $node_name ( keys %{ $command_details_href->{$key} } ) {
            foreach my $cmd ( keys %{ $command_details_href->{$key}{$node_name} } ) {
                my @sig = keys %{ $command_details_href->{$key}{$node_name}{$cmd} };
                $resolvedSiglabel = $node_name . '::' . $cmd . '::' . $sig[0];
                last;
            }
        }
    }
    return $resolvedSiglabel;

}

=head2 SPILC_set_FireCounter

    $returnValue = SPILC_set_FireCounter( $options_href ); 

This functions sets the fire counter current low level and high level.

B<Arguments:>

=over

=item $options_href 

    $options_href = {
                       'Line' => 'BLFD' ,
                       'Duration_ms' => '200'  ( or ) 'FrameCycles' => '50' ,
                       'fire_cnt_low_level' => 0 .. 127, # 7 bit binary data (0 .. 127 dec)
                       'fire_cnt_high_level' => 0 .. 127, # 7 bit binary data (0 .. 127 dec)
                    };


=back

B<Return Value:>

=over

=item $returnValue 

1 on Success

undef on failure

=back

Examples:

1. set fire counter low level

	SPILC_set_FireCounter ( { 'Line' => 'BLFD' , 
	                          'fire_cnt_low_level' => 80,
	                          'Duration_ms' => '3000'
	                        }
	                      );
  
2. set fire counter high level

    SPILC_set_FireCounter ( { 'Line' => 'BLFD' ,
                              'fire_cnt_high_level' => 100,
                               'Duration_ms' => '3000'
                            }
                          );


=cut

sub SPILC_set_FireCounter {

    my @args = @_;

    # variables required to pass as argument to 'S_checkFunctionArgumentHashKeys'
    my $valid_keys_href = { 'Line' => 1, 'fire_cnt_low_level' => 1, 'fire_cnt_high_level' => 1, 'Duration_ms' => 1 };
    my $mand_keys_href = { 'Line' => 1 };

    my $options_href = shift @args;
    return unless S_checkFunctionArgumentHashKeys( 'SPILC_set_FireCounter', $options_href, $valid_keys_href, $mand_keys_href );

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    unless ( defined $options_href->{Duration_ms} or defined $options_href->{FrameCycles} ) {
        S_set_error( "SPILC_set_FireCounter: Either 'Duration_ms' or 'FrameCycles' should be cofigured\n", 109 );
        return;
    }

    my $mapped_label;

    #STEP check fire_cnt_low_level range if not in range return error
    if ( defined $options_href->{fire_cnt_low_level} ) {
        if ( $options_href->{fire_cnt_low_level} > 127 ) {
            S_set_error( "SPILC_set_FireCounter: fire_cnt_low_level '$options_href->{fire_cnt_low_level}' not in range. Valid range 0 .. 127\n", 109 );
            return;
        }
        $mapped_label = 'fire_cnt_low_level';
    }

    #STEP check fire_cnt_high_level range if not in range return error
    if ( defined $options_href->{fire_cnt_high_level} ) {
        if ( $options_href->{fire_cnt_high_level} > 127 ) {
            S_set_error( "SPILC_set_FireCounter: fire_cnt_high_level '$options_href->{fire_cnt_high_level}' not in range. Valid range 0 .. 127\n", 109 );
            return;
        }
        $mapped_label = 'fire_cnt_high_level';
    }

    $options_href->{device_type} = 'squibs';

    $options_href->{mapped_label} = $mapped_label;

    $options_href->{Lines} = [ $options_href->{Line} ];

    #CALL Load_spi_signals to set fire counters
    return unless ( Load_spi_signals($options_href) );

    return 1;
}

=head2 SPILC_ShortLines

    $returnValue = SPILC_ShortLines( $lines_aref );

Currently supports short to bat and short to ground of more than one line ( max 12 lines ).

It is recommanded to use LIFT_labcar functions instead of directly using this function in TCs.

B<DEVICE TYPES SUPPORTED: SWITCHES, SQUIBS and PASES>

B<NOTE: SHORTLINES AND DISCONNECTLINE CANNOT BE ACTIVE AT SAME TIME USING SPI MANIPULATION>

B<Arguments:>

=over

=item $lines_aref

$lines_aref = ['AB1FD+', 'B+'];

=back

B<Return Value:>

=over

=item $returnValue

1 on Success

undef on failure

=back

Examples:

1. Short to battery HS of one line

	SPILC_ShortLines ( ['AB1FD+', 'B+'] );

2. Short to ground HS of one line 

    SPILC_ShortLines ( ['AB1FD+', 'B-']; );

3. Short to battery HS of more than one line

	SPILC_ShortLines ( ['AB1FD+', 'UFSD+', 'BLFD+', 'B+'] );

4. Short to ground HS of more than one line 

    SPILC_ShortLines ( ['AB1FD+', 'UFSD+', 'BLFD+', 'B-']; );

=cut

sub SPILC_ShortLines {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SPILC_ShortLines( $lines_aref )', @args );

    my $lines_aref = shift;

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    return unless Check_manipulation_status();

    #STEP validate input arguments for type of short
    return unless ( Validate_lines($lines_aref) );

    my $short_type = pop @$lines_aref;

    #LOOP-START resolve device type and load each device SPI data
    foreach my $line (@$lines_aref) {

        #STEP find out device type
        my $device_type = Resolve_device_type($line);

        #STEP validate device type if not found return error
        unless ($device_type) {
            S_set_error( "SPILC_ShortLines: Could not resolve Device type for device $line\n", 109 );
        }

        #STEP validate device type supported or not, else return error
        unless ( $device_func_map_href->{$device_type} ) {
            S_set_error( "SPILC_ShortLines: Device type '$device_type' not supported\n", 109 );
            return;
        }

        #CALL device type specific prepare faults function using function pointer hash $device_func_map_href
        my $faultType = ( $short_type =~ /(B-|UF-)/i ) ? 'short2gnd' : 'short2bat';
        return unless ( $device_func_map_href->{$device_type}( { 'Fault_type' => $faultType, 'Lines' => [$line], 'Duration_ms' => 'infinite' } ) );
    }

    #LOOP-END after all devices are resolved for SPI data

    #CALL SPI_start_manipulation to do short of the lines
    return unless ( SPI_start_manipulation() );

    $device_track_status->{ShortLine_UndoShortLine} = 1;

    S_w2log( 3, "SPILC_ShortLines: Shorting lines '@$lines_aref' to $short_type is successfull" );

    $spi_manipulation_status = 1;

    return 1;
}

=head2 SPILC_UndoShortLines

    $returnValue = SPILC_UndoShortLines();

Removes short between the lines. This function will be called by LC_ functions.

LC_ functions shall be used in test cases.

B<DEVICE TYPES SUPPORTED: SWITCHES, SQUIBS and PASES>

B<Arguments: NONE>

B<Return Value:>

=over

=item $returnValue

1 on Success

undef on failure

=back

=cut

sub SPILC_UndoShortLines {

    my @args = @_;
    return unless S_checkFunctionArguments( 'SPILC_UndoShortLines()', @args );

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    unless ( $device_track_status->{ShortLine_UndoShortLine} ) {
        S_set_warning( "SPILC_ConnectLine: No short found! Nothing to do! ", 109 );
        return 1;
    }

    #CALL SPI_stop_manipulation to undo the short line
    return unless ( SPI_stop_manipulation() );

    delete $device_track_status->{ShortLine_UndoShortLine};
    S_w2log( 3, "SPILC_UndoShortLines: Undo Short lines successfull" );
    $spi_manipulation_status = 0;
    return 1;
}

=head2 SPILC_DisconnectLine

    $returnValue = SPILC_DisconnectLine( '$line' );

Disconnects the line.

It is recommanded to use LIFT_labcar functions instead of directly using this function in TCs.

B<DEVICE TYPES SUPPORTED: SWITCHES, SQUIBS and PASES>

B<NOTE: SHORTLINES AND DISCONNECTLINE CANNOT BE ACTIVE AT SAME TIME USING SPI MANIPULATION>

B<Arguments:>

=over

=item $line

$line = 'AB1FD';

=back

B<Return Value:>

=over

=item $returnValue

1 on Success

undef on failure

=back

Examples:

1. Disconnect line 'AB1FD'

	SPILC_DisconnectLine( 'AB1FD' );

=cut

sub SPILC_DisconnectLine {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SPILC_DisconnectLine($line)', @args );
    my $line = uc shift @args;    # convert device name to upper case inorder to allow case insensitive device name configuration

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    return unless Check_manipulation_status();

    #STEP find out device type
    my $device_type = Resolve_device_type($line);

    #STEP validate device type if not found return error
    unless ($device_type) {
        S_set_error( "SPILC_DisconnectLine: Could not resolve Device type for device '$line'\n", 109 );
    }

    #STEP validate device type supported or not, else return error
    unless ( $device_func_map_href->{$device_type} ) {
        S_set_error( "SPILC_DisconnectLine: Device type '$device_type' not supported\n", 109 );
        return;
    }

    #CALL device type specific prepare faults function using function pointer hash $device_func_map_href
    return unless ( $device_func_map_href->{$device_type}( { 'Fault_type' => 'openline', 'Lines' => [$line], 'Duration_ms' => 'infinite' } ) );

    #CALL SPI_start_manipulation to disconnect lines
    return unless ( SPI_start_manipulation() );

    $device_track_status->{connect_disconnect}{$line} = 1;    # set flag when line is disconnected.

    S_w2log( 3, "SPILC_DisconnectLine: Line '$line' Disconnected!" );

    $spi_manipulation_status = 1;
    return 1;
}

=head2 SPILC_ConnectLine

    $returnValue = SPILC_ConnectLine( '$line' );

Connects the line.

It is recommanded to use LIFT_labcar functions instead of directly using this function in TCs.

B<DEVICE TYPES SUPPORTED: SWITCHES, SQUIBS and PASES>

B<Arguments:>

=over

=item $line

$line = 'AB1FD';

=back

B<Return Value:>

=over

=item $returnValue

1 on Success

undef on failure

=back

Examples:

1. Connect line 'AB1FD'

	SPILC_ConnectLine( 'AB1FD' );

=cut

sub SPILC_ConnectLine {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SPILC_ConnectLine($line)', @args );

    #STEP check if SPILC is initialised else return with error
    return unless ( Check_SPILC_init() );

    my $line = uc shift @args;    # convert device name to upper case inorder to allow case insensitive device name configuration

    unless ( $device_track_status->{connect_disconnect}{$line} ) {
        S_set_warning( "SPILC_ConnectLine: Line '$line' Already connected, Nothing to do! ", 109 );
        return 1;
    }

    #CALL SPI_stop_manipulation to undo the short line
    return unless ( SPI_stop_manipulation() );

    delete $device_track_status->{connect_disconnect}{$line};    # reset the flag after line connected

    S_w2log( 3, "SPILC_ConnectLine: Line '$line' Connected!" );

    $spi_manipulation_status = 0;

    return 1;
}

=head1 Non exported functions



=cut

=head2 Resolve_device_type

    This function returns the device type to which the device belong

=cut

sub Resolve_device_type {

    my $device = clone(shift);

    # retrieve the device type by using the PRD get device configuration function which is called in the SPILC init
    $device =~ s/\+|-//;    # substitute signsin order to retrieve the device type
    foreach my $device_type ( keys %$dev_name_uppercase_href ) {
        return $device_type if ( grep { $_ =~ /$device/i } keys %{ $dev_name_uppercase_href->{$device_type} } );
    }
    return;
}

=head2 GetMultiSigAndVal

    This function returns the signals and its values required for the manipulation of SPI command

=cut

sub GetMultiSigAndVal {

    my $options_href     = shift;
    my $sig_and_val_href = shift;
    my $nodeName         = shift;
    my $spiCmd           = shift;

    my $multisignls = $sig_collection_href->{ $options_href->{device_type} };

    # retrieve all the signals value when more than one signal is configured for the device type
    foreach my $signal (@$multisignls) {
        if ( defined $options_href->{$signal} ) {
            if ( exists $SPILC_FuncMap_href->{ $options_href->{device_type} }{$signal} ) {
                foreach my $key ( keys %{ $SPILC_FuncMap_href->{ $options_href->{device_type} }{$signal} } ) {
                    my $sig = $SPILC_FuncMap_href->{ $options_href->{device_type} }{$signal}{$key}{SIG};
                    my $val = $SPILC_FuncMap_href->{ $options_href->{device_type} }{$signal}{$key}{VAL};
                    $val =~ s/<.*>//;
                    $sig_and_val_href->{$sig} = $options_href->{$signal};
                }
            }
            else {
                S_set_error( "GetMultiSigAndVal: '$signal' not defined in Mapping_spi_network.pm\n", 109 );
                return;
            }
        }

    }
    return 1;
}

=head2 GetPolarityAndDeviceName

    This function returns the polarity for the device high side or lowside and also device name.

=cut

sub GetPolarityAndDeviceName {

    my $line        = shift;
    my $fault_type  = shift;
    my $device_type = shift;

    my $polarity = 'hs';    # high side
    if ( $line =~ /\-/ ) {
        $polarity = 'ls';    # low side
    }
    my ( $squibName, $fault_name );
    $squibName = $1 if ( $line =~ /([0-9A-Za-z]+)(\+|-)?$/i );
    if ( exists $SPILC_FuncMap_href->{$device_type}{ $polarity . '_' . $fault_type } ) {

        # append high side or lowside to the fault type
        $fault_name = $polarity . '_' . $fault_type if ( defined $polarity );
    }
    else {
        $fault_name = $fault_type;
    }

    return ( $fault_name, $squibName );
}

=head2 Load_spi_signals

    This function preapres and loads the SPI signals to Manitoo.

=cut

sub Load_spi_signals {

    my $options_href = shift;

    my ( $duration_ms, $frameCycles );
    $duration_ms = $options_href->{Duration_ms} if ( defined $options_href->{Duration_ms} );
    $frameCycles = $options_href->{FrameCycles} if ( defined $options_href->{FrameCycles} );

    my $fault_type  = $options_href->{Fault_type} // $options_href->{mapped_label};
    my $lines_aref  = $options_href->{Lines};
    my $device_type = $options_href->{device_type};

    my $spi_cmd_details;

    my $function_name = ( caller(1) )[3];
    $function_name =~ s/(.*::)//;    # remove package name;
    foreach my $line (@$lines_aref) {

        # get asic channel and Id
        S_w2log( 3, "$function_name : Preparing spi data for $line started\n" );
        $line = uc $line;            # convert device name to upper case inorder to allow case insensitive device name configuration
        my ( $fault_name, $devName ) = GetPolarityAndDeviceName( $line, $fault_type, $device_type );

        my $command_details_href = Get_spi_details( $device_type, $devName, $fault_name, $options_href );
        return unless ( defined $command_details_href );

        #Load SPI command and signals for required line fault behaviour.
        foreach my $key ( keys %$command_details_href ) {
            foreach my $node_name ( keys %{ $command_details_href->{$key} } ) {
                foreach my $cmd ( keys %{ $command_details_href->{$key}{$node_name} } ) {
                    my $sig_and_vals_href = $command_details_href->{$key}{$node_name}{$cmd};
                    map { $spi_cmd_details->{$node_name}{$cmd}{$_} = $sig_and_vals_href->{$_} } keys %$sig_and_vals_href;
                }
            }

            my $load_options_href;

            $load_options_href = { 'spi_cmd_details_href' => clone($spi_cmd_details), 'FrameCycles' => $frameCycles } if defined($frameCycles);
            $load_options_href = { 'spi_cmd_details_href' => clone($spi_cmd_details), 'Duration_ms' => $duration_ms } if defined($duration_ms);

            return unless ( Load_spi_data($load_options_href) );
            $spi_cmd_details = {};
        }

        S_w2log( 3, "$function_name : Preparing spi data for $line completed\n" );
    }

    S_w2log( 3, "$function_name loading spi data to manitoo completed\n" );

    return 1;
}

=head2 Load_spi_signals

    This function loads the SPI data prepared by function Load_spi_signals to Manitoo.

=cut

sub Load_spi_data {

    my @args = @_;

    my $load_data_href       = shift @args;
    my $spi_cmd_details_href = $load_data_href->{spi_cmd_details_href};
    my $frameCycles;
    my $duration_ms;

    $frameCycles = $load_data_href->{FrameCycles} if ( defined $load_data_href->{FrameCycles} );
    $duration_ms = $load_data_href->{Duration_ms} if ( defined $load_data_href->{Duration_ms} );
    S_w2log( 3, "Load_spi_data : loading spi data to manitoo started\n" );
    foreach my $nodeName ( keys %$spi_cmd_details_href ) {

        foreach my $spi_cmd ( keys %{ $spi_cmd_details_href->{$nodeName} } ) {
            if ( defined $frameCycles ) {
                return unless SPI_load_signal_manipulation( 'Node' => $nodeName, 'Command' => "$spi_cmd", 'Signals_and_Values' => $spi_cmd_details_href->{$nodeName}{$spi_cmd}, 'FrameCycles' => $frameCycles );
            }
            else {
                return unless SPI_load_signal_manipulation( 'Node' => $nodeName, 'Command' => "$spi_cmd", 'Signals_and_Values' => $spi_cmd_details_href->{$nodeName}{$spi_cmd}, 'Duration_ms' => $duration_ms );
            }
        }

    }
    return 1;
}

=head2 Get_spi_details

    This function decodes the SPI command and signal values for a device configured in line functions.

=cut

sub Get_spi_details {

    my $device_type  = shift;
    my $devName      = uc shift;    # convert device name to upper case inorder to allow case insensitive device name configuration
    my $mapped_label = shift;
    my $options_href = shift;

    my $sig_and_val_href;

    # get asic channel and Id
    S_w2log( 4, "Get_spi_details: Fetching Asic_ID and Asic_Channel for squibs\n" );

    # Validate if device is present in the sad file or not.
    unless ( exists( $dev_name_uppercase_href->{$device_type}{$devName} ) ) {
        S_set_error( "Get_spi_details: could not fetch details for device '$devName'", 109 );
        return;
    }
    my $asicChannel = $dev_name_uppercase_href->{$device_type}{$devName}{Asic_Channel} + 1;
    my $asicId      = $dev_name_uppercase_href->{$device_type}{$devName}{Asic_Id};

    if ( not defined $asicId or not defined $asicChannel ) {
        S_set_error( "Get_spi_details: Asic Id or Asic Channel not found for Device $devName\n", 109 );
        return;
    }

    my ( $spiCmd, $nodeName, $collect_cmd_details_href );
    if ( exists $SPILC_FuncMap_href->{$device_type}{$mapped_label} ) {
        foreach my $key ( keys %{ $SPILC_FuncMap_href->{$device_type}{$mapped_label} } ) {
            $spiCmd = $SPILC_FuncMap_href->{$device_type}{$mapped_label}{$key}{'CMD'};
            if ( $spiCmd =~ /<ASIC_CHANNEL_TS>/i ) {

                unless ( exists $SPILC_FuncMap_href->{pases}{timeslots}{ uc $devName } ) {
                    S_set_error( "Get_spi_details: Timeslots for PAS device '$devName' not found in Mapping_SPI_network.pm\n", 109 );
                    return;
                }
                my $line_time_slot = '_CH' . $asicChannel . '_TS' . $SPILC_FuncMap_href->{pases}{timeslots}{ uc $devName };
                $spiCmd =~ s/<ASIC_CHANNEL_TS>/$line_time_slot/;
            }
            else {
                $spiCmd =~ s/<ASIC_CHANNEL>/$asicChannel/;
            }

            my $spiSig = $SPILC_FuncMap_href->{$device_type}{$mapped_label}{$key}{'SIG'};
            $spiSig =~ s/<ASIC_CHANNEL>/$asicChannel/;
            my $spiSigVal;
            $spiSigVal = $SPILC_FuncMap_href->{$device_type}{$mapped_label}{$key}{'VAL'} if ( exists $SPILC_FuncMap_href->{$device_type}{$mapped_label}{$key}{'VAL'} );

            #Set value for switches based on switch type for openline and short to ground.
            if ( $device_type eq 'switches' ) {

                unless ( defined( $mappingdevice_href->{$devName}{type} ) ) {
                    S_set_error( "Get_spi_details: Switch type not defined for '$devName', define switch type in Mapping_Device!", 109 );
                    return;
                }
                if ( $mapped_label =~ m/short2gnd|openline/i ) {
                    my $switchType = $mappingdevice_href->{$devName}{type};
                    $spiSigVal = $SPILC_FuncMap_href->{$device_type}{$mapped_label}{$key}{$switchType};
                }
            }

            #extract node name
            ($nodeName) = grep { $mappingSpiNw_href->{$_}{Asic_Id} == $asicId } keys %$mappingSpiNw_href;
            unless ($nodeName) {
                S_set_error( "Get_spi_details : 'Asic_Id' not defined in Mapping_SPI_network.pm\n", 109 );
                return;
            }

            $sig_and_val_href->{$spiSig} = $spiSigVal;
            my $multisig_aref = $sig_collection_href->{ $options_href->{device_type} };
            my @multisignls = grep { exists $options_href->{$_} } @$multisig_aref;
            if (@multisignls) {
                return unless ( GetMultiSigAndVal( $options_href, $sig_and_val_href, $nodeName, $spiCmd ) );
            }
            elsif ( $spiSigVal !~ /\d+/ ) {
                S_set_error( "Get_spi_details: Invalid value '$spiSigVal' configured for SPI Signal '$spiSig' in Mapping_SPI_network.pm\n", 109 );
                return;
            }
            $collect_cmd_details_href->{$key}{$nodeName}{$spiCmd} = clone($sig_and_val_href);
            $sig_and_val_href = {};
        }
    }
    else {
        S_set_error( "Get_spi_details: Device type '$device_type' or label '$mapped_label' not found in Mapping_spi_network.pm\n", 109 );
        return;
    }

    return $collect_cmd_details_href;
}

=head2 Validate_lines

    This function validates the supported line functionality.

=cut

sub Validate_lines {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Validate_lines( $lines_aref )', @args );
    my $lines_aref = clone( shift @args );

    if ( $lines_aref->[-1] !~ /(B|UF)(\+|-)/i ) {
        my @devices = @$lines_aref;
        S_set_error( "Validate_lines: Invalid arguments (@devices), only short to ground or short to battery of one device is allowed!\n", 109 );
        return;
    }

    if ( @$lines_aref > 12 ) {
        S_set_error( "Validate_lines: Maximum of 12 lines is allowed for short!\n", 109 );
        return;
    }

    #identify if same lines present more than once
    my %check_duplicates;
    map { chop } @$lines_aref;    # remove +|- from line names.
    foreach my $line (@$lines_aref) {
        next unless $check_duplicates{$line}++;
        S_set_error( "Validate_lines: Same line $line used more than once for short!\n", 109 );
        return;
    }

    return 1;
}

=head2 Check_SPILC_init

    This function checks SPILC is initialised or not.

=cut

sub Check_SPILC_init {
    unless ($SPILC_init_flag) {
        S_set_error( "Check_SPILC_init: SPILC not initialised call SPILC_init() to initialise!", 120 );
        return;
    }
    return 1;
}

=head2 Check_manipulation_status

    This function checks if more than one type of line faults is active at once.

=cut

sub Check_manipulation_status {
    if ($spi_manipulation_status) {
        S_set_error( "SPILC_DisconnectLine: SPI manipulation is already active , Two different kind of line faults(e.g openline and shortline) cannot be performed at once with SPI manipulation", 109 );
        return;
    }
    return 1;
}

1;
