# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package FaultEntry::Disturbance;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################

use strict;
use warnings;
use Moose;
use namespace::autoclean;

use LIFT_general;

extends 'FaultEntry';


our ( $VERSION, $HEADER );

=head1 NAME

FaultEntry 
=head1 SYNOPSIS

    use LIFT_FaultMemory::FaultEntry::Disturbance;
    
    # Create new Disturbance fault entry
    $entry_obj = FaultEntry::Disturbance -> new;

    # set inherited attribute of fault entry object
    $entry_obj -> BoschFaultNbr( 125 );

    # set Disturbance fault entry specific attribute
    $entry_obj -> DisturbanceCounter( 12 );


=head1 DESCRIPTION

This class inherits all attributes and methods of the FaultEntry class.

Disturbance fault entry specific attributes and methods are added.

=cut

=head1 ATTRIBUTES

B<Inherited attributes>

=over

=item DTC

Integer with the fault DTC

=item BoschFaultNbr

Integer with the unique Bosch Fault Number

=item FaultName

String with fault name

=item RawStatus

Integer with the raw fault status

=item DecodedStatus

Hash reference with the decoded fault status (bit wise decoded)

=back

B<Disturbance attributes>

=over

=item EventDebugData

Integer of event debug data -> interpretation dependent on fault entry

=item GeneralStatus

Integer with general status. Generic interpretation possible and available with attribute 'DecodedGeneralStatus'

=item DecodedGeneralStatus

Interpreted 'GeneralStatus'

=item GeneralStatusDecodingTable

Description of bit wise interpretation of 'GeneralStatus' for decoding

=item DisturbanceCounter

Counter how often disturbed fault occured

=item StatusDecodingTable

Bit wise description of the fault status for decoding - overwrites same attribute from FaultEntry class

=cut

my $statusDecodingTableDefault = {
    'Bit_0' => 'TestCurrent',
    'Bit_1' => 'TestDisturbed',
};

#
# must be called 'Bit_0' because pure numbers can't be managed in write_to_file / load_from_file ( XML notation doesnt allow pure digits ) 
#
my $generalStatusDecodingTable = {
    'Bit_0' => 'IdleMode_active',
    'Bit_1' => 'InitMode_active',
    'Bit_2' => 'VBat_OutOfRange_present',
    'Bit_3' => 'VUp_OutOfRange_present',
    'Bit_4' => 'Algo_active',
    'Bit_5' => 'DIS_ALP_enabled',
    'Bit_6' => 'Squib_fired_current_POC',
    'Bit_7' => 'reserved',    
};

has EventDebugData => ( is => "rw", isa => 'Int' );
has GeneralStatus => ( is => "rw", isa => 'Int' );
has DecodedGeneralStatus => ( is => "rw", isa => 'HashRef[Bool]' );
has GeneralStatusDecodingTable => ( is => "rw", default => sub { $generalStatusDecodingTable } ,isa => 'HashRef[Str]' );
has DisturbanceCounter => ( is => "rw", isa => 'Int' );
has StatusDecodingTable => ( is => "rw", default => sub { $statusDecodingTableDefault } ,isa => 'HashRef[Str]' );

=head1 METHODS

=head2 decode_GeneralStatus

    $entry_obj -> decode_GeneralStatus();

Can be called after attribute 'GeneralStatus' is set to decode the fault status and set the attribute 'DecodedGeneralStatus'

=cut

sub decode_GeneralStatus {
    my $self = shift;
    
    my $binaryRawStatus = S_dec2bin($self -> {GeneralStatus});
    my @binaryRawStatusArray = split(//, $binaryRawStatus);
    my @binaryRawStatusArrayReversed = reverse(@binaryRawStatusArray);
    
#     foreach my $bitInStatus (sort {$a <=> $b} keys %{$self -> {GeneralStatusDecodingTable}})
    #        'Bit_0' .. 'Bit_n'
    foreach my $bitInStatus (sort __by_number__ keys %{$self -> {GeneralStatusDecodingTable}})
    {
        my $thisBitStatusString = $self -> {GeneralStatusDecodingTable}->{$bitInStatus};
        my ( $index_in_status ) = $bitInStatus =~ /(\d+)/;
        my $thisBitValue = $binaryRawStatusArrayReversed[$index_in_status];
#         my $thisBitValue = $binaryRawStatusArrayReversed[$bitInStatus];
        $self -> {DecodedGeneralStatus} -> {$thisBitStatusString} = $thisBitValue;
    }

    return 1;
}

#
# used for numerical sorting 'Bit_0' ..
#
sub __by_number__ {
    my ( $anum ) = $a =~ /(\d+)/;
    my ( $bnum ) = $b =~ /(\d+)/;
    return ( $anum || 0 ) <=> ( $bnum || 0 );
}

__PACKAGE__->meta->make_immutable;

1;

