# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package FaultEntry::Customer;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################

use strict;
use warnings;
use Moose;
use namespace::autoclean;

use LIFT_general;
use LIFT_CD;
use LIFT_DataRecord;

extends 'FaultEntry';


our ( $VERSION, $HEADER );

=head1 NAME

FaultEntry 
=head1 SYNOPSIS

    use LIFT_FaultMemory::FaultEntry::Customer;
    
    # Create new Customer fault entry
    $entry_obj = FaultEntry::Customer -> new;
    
    # set inherited attribute of fault entry object
    $entry_obj -> BoschFaultNbr( 125 );

=head1 DESCRIPTION

This class inherits all attributes and methods of the FaultEntry class.

Customer fault entry specific attributes and methods are added.

=cut

=head1 ATTRIBUTES

B<Inherited attributes>

=over

=item DTC

Integer with the fault DTC

=item BoschFaultNbr

Integer with the unique Bosch Fault Number

=item FaultName

String with fault name

=item RawStatus

Integer with the raw fault status

=item DecodedStatus

Hash reference with the decoded fault status (bit wise decoded)

=item StatusDecodingTable

Bit wise description of the fault status for decoding

=back

B<Customer attributes>

=over

=item tbd

<...>

=cut

has ExtendedDataRecords => ( is => "rw", isa => 'HashRef[LIFT_DataRecord]' );
has SnapshotDataRecords => ( is => "rw", isa => 'HashRef[LIFT_DataRecord]' );

=head1 METHODS

=head2 read_snapshot_data

    $entry_obj -> read_snapshot_data($recordNbr);

=cut

sub read_snapshot_data {
    my $self = shift;
    my $recordNbr = shift;
    
    unless(defined $recordNbr){
        S_w2log(3, "Customer fault entry: Snapshot record number FF will be read (default)");
        $recordNbr = '255';
    }
    
    my $faultName = $self -> FaultName();
    S_w2log(4, "Customer::read_snapshot_data -> Reading snapshot data for fault entry '$faultName'");

    my $dtcHex = sprintf("%06X", $self -> {DTC});
    my @dtcArray = split(//, $dtcHex);

    my $response_aref = CD_send_request_wait_response([ '0x19', '0x04',
                                                        "0x".$dtcArray[0].$dtcArray[1],
                                                        "0x".$dtcArray[2].$dtcArray[3],
                                                        "0x".$dtcArray[4].$dtcArray[5],
                                                        "0x".sprintf("%02X", $recordNbr)]);
    
    if(@{$response_aref} == 0 and not $main::opt_offline){
        S_set_error("No response received when reading snapshot data record $recordNbr (Service 19 04) for DTC $dtcHex");
        return;
    }
    elsif($response_aref -> [0] == 0x7F){
        my $nrc = sprintf("%02X", $response_aref -> [-1]);
        S_set_error("Negative response received when reading snapshot data record $recordNbr (Service 19 04) for DTC $dtcHex.\n".
                    "Negative response code: $nrc");
        return;
    }
                                                        
    my $dataRecordObject = LIFT_DataRecord -> create_data_record('SnapshotData', $response_aref);    
    if(not defined $dataRecordObject){
        S_set_error("Data record object for snapshot data could not be created. Check whether 'Mapping_SnapshotData' is defined.");
        return;
    }

    $self -> {SnapshotDataRecords} -> {"Snapshot\_$recordNbr"} = $dataRecordObject;

    $dataRecordObject -> print_HTML_Table("Snapshot record $recordNbr for DTC 0x$dtcHex ($faultName)");

    return 1;
}

=head2 read_extended_data

    $entry_obj -> read_extended_data($recordNbr);

=cut

sub read_extended_data {
    my $self = shift;
    my $recordNbr = shift;
    
    unless(defined $recordNbr){
        S_w2log(3, "Customer fault entry: Extended record number FF will be read (default)");
        $recordNbr = '255';
    }
    
    my $faultName = $self -> FaultName();
    S_w2log(4, "Customer::read_extended_data -> Reading Extended data for fault entry '$faultName'");

    my $dtcHex = sprintf("%06X", $self -> {DTC});
    my @dtcArray = split(//, $dtcHex);

    my $response_aref = CD_send_request_wait_response([ '0x19', '0x06',
                                                        "0x".$dtcArray[0].$dtcArray[1],
                                                        "0x".$dtcArray[2].$dtcArray[3],
                                                        "0x".$dtcArray[4].$dtcArray[5],
                                                        "0x".sprintf("%02X", $recordNbr)]);
    
    if(@{$response_aref} == 0 and not $main::opt_offline){
        S_set_error("No response received when reading Extended data record $recordNbr (Service 19 04) for DTC $dtcHex");
        return;
    }
    elsif($response_aref -> [0] == 0x7F){
        my $nrc = sprintf("%02X", $response_aref -> [-1]);
        S_set_error("Negative response received when reading Extended data record $recordNbr (Service 19 04) for DTC $dtcHex.\n".
                    "Negative response code: $nrc");
        return;
    }
                                                        
    my $dataRecordObject = LIFT_DataRecord -> create_data_record('ExtendedData', $response_aref);
    if(not defined $dataRecordObject){
        S_set_error("Data record object for extended data could not be created. Check whether 'Mapping_ExtendedData' is defined.");
        return;
    }

    $self -> {ExtendedDataRecords} -> {"Extended\_$recordNbr"} = $dataRecordObject;

    $dataRecordObject -> print_HTML_Table("Extended record $recordNbr for DTC 0x$dtcHex ($faultName)");

    return 1;
}

=head2 get_snapshot_data_value_raw

    $entry_obj -> get_snapshot_data_value_raw($dataKey[, $recordNbr, $format]);

=cut

sub get_snapshot_data_value_raw {
    my $self = shift;
    my $dataKey = shift;
    my $recordNbr = shift;
    my $format = shift;
    
    unless(defined $dataKey){
        S_set_error("Customer::get_snapshot_data_value_raw -> Missing mandatory parameter data key!\n".
                    "Specify which snapshot data element shall be read.", 110);
        return;
    }

    unless(defined $recordNbr){
        S_w2log(4, "Customer fault entry: Data from snapshot record number 1 will be read (default)");
        $recordNbr = 1;
    }  

    if($main::opt_offline){
        $self -> read_snapshot_data($recordNbr); # reset fault entries hash     
    }

    my $dataRecordObject = $self -> {SnapshotDataRecords} -> {"Snapshot\_$recordNbr"};
    unless(defined $dataRecordObject){
        my $faultname = $self -> FaultName();
        S_set_error("Snapshot data not available for fault '$faultname'. Call read_snapshot_data first.");
        return;
    }

    my $value = $dataRecordObject -> get_member_value_raw($dataKey, $format);

    return $value;
}

=head2 get_extended_data_value_raw

    $entry_obj -> get_extended_data_value_raw($dataKey[, $recordNbr, $format]);

=cut

sub get_extended_data_value_raw {
    my $self = shift;
    my $dataKey = shift;
    my $recordNbr = shift;
    my $format = shift;
    
    unless(defined $dataKey){
        S_set_error("Customer::get_extended_data_value_raw -> Missing mandatory parameter data key!\n".
                    "Specify which extended data element shall be read.", 110);
        return;
    }

    unless(defined $recordNbr){
        S_w2log(4, "Customer fault entry: Data from extended record number FF will be read (default)");
        $recordNbr = '255';
    }  

    if($main::opt_offline){
        $self -> read_extended_data($recordNbr); # reset fault entries hash     
    }

    my $dataRecordObject = $self -> {ExtendedDataRecords} -> {"Extended\_$recordNbr"};
    unless(defined $dataRecordObject){
        my $faultname = $self -> FaultName();
        S_set_error("extended data not available for fault '$faultname'. Call read_extended_data first.");
        return;
    }

    my $value = $dataRecordObject -> get_member_value_raw($dataKey, $format);

    return $value;
}
=head2 get_snapshot_data_value_decoded

    $entry_obj -> get_snapshot_data_value_decoded($dataKey[, $recordNbr]);

=cut

sub get_snapshot_data_value_decoded {
    my $self = shift;
    my $dataKey = shift;
    my $recordNbr = shift;

    unless(defined $dataKey){
        S_set_error("Customer::get_snapshot_data_value_decoded -> Missing mandatory parameter data key!\n".
                    "Specify which snapshot data element shall be read.", 110);
        return;
    }
    
    unless(defined $recordNbr){
        S_w2log(4, "Customer::get_snapshot_data_value_decoded -> Data from snapshot record number 1 will be read (default)");
        $recordNbr = '255';
    }  

    if($main::opt_offline){
        $self -> read_snapshot_data($recordNbr); # reset fault entries hash     
    }

    my $dataRecordObject = $self -> {SnapshotDataRecords} -> {"Snapshot\_$recordNbr"};
    unless($dataRecordObject){
        my $faultname = $self -> FaultName();
        S_set_error("Snapshot data record $recordNbr not available for fault '$faultname'.\n".
                    "Call read_snapshot_data first with same record number.");
        return;
    }

    my $value = $dataRecordObject -> get_member_value_decoded($dataKey);

    return $value;
}

=head2 get_extended_data_value_decoded

    $entry_obj -> get_extended_data_value_decoded($dataKey[, $recordNbr]);

=cut

sub get_extended_data_value_decoded {
    my $self = shift;
    my $dataKey = shift;
    my $recordNbr = shift;

    unless(defined $dataKey){
        S_set_error("Customer::get_extended_data_value_decoded -> Missing mandatory parameter data key!\n".
                    "Specify which extended data element shall be read.", 110);
        return;
    }
    
    unless(defined $recordNbr){
        S_w2log(4, "Customer::get_extended_data_value_decoded -> Data from extended record number FF will be read (default)");
        $recordNbr = 255;
    }  

    if($main::opt_offline){
        $self -> read_extended_data($recordNbr); # reset fault entries hash     
    }

    my $dataRecordObject = $self -> {ExtendedDataRecords} -> {"Extended\_$recordNbr"};
    unless($dataRecordObject){
        my $faultname = $self -> FaultName();
        S_set_error("extended data record $recordNbr not available for fault '$faultname'.\n".
                    "Call read_extended_data first with same record number.");
        return;
    }

    my $value = $dataRecordObject -> get_member_value_decoded($dataKey);

    return $value;
}

__PACKAGE__->meta->make_immutable;

1;

