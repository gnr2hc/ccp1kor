# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package FaultEntry::Bosch;

   ####    ##
  #    #    #
 #          #
 #          #     ####    #####   #####
 #          #         #  #     # #     #
 #          #     #####   ###     ###
 #          #    #    #      ##      ##
  #    #    #    #    #  #     # #     #
   ####   #####   #### #  #####   #####

#######################################################################################################

use strict;
use warnings;
use Moose;
use namespace::autoclean;

use LIFT_general;

extends 'FaultEntry';


our ( $VERSION, $HEADER );

=head1 NAME

FaultEntry 
=head1 SYNOPSIS

    use LIFT_FaultMemory::FaultEntry::Bosch;
    
    # Create new Bosch fault entry
    $entry_obj = FaultEntry::Bosch -> new;
    
    # set inherited attribute of fault entry object
    $entry_obj -> BoschFaultNbr( 125 );

    # set Bosch fault entry specific attribute
    $entry_obj -> GeneralStatus( 12 );

    # decode GeneralStatus
    $entry_obj -> decode_GeneralStatus();

=head1 DESCRIPTION

This class inherits all attributes and methods of the FaultEntry class.

Bosch fault entry specific attributes and methods are added.

=cut

=head1 ATTRIBUTES

B<Inherited attributes>

=over

=item DTC

Integer with the fault DTC

=item BoschFaultNbr

Integer with the unique Bosch Fault Number

=item FaultName

String with fault name

=item RawStatus

Integer with the raw fault status

=item DecodedStatus

Hash reference with the decoded fault status (bit wise decoded)

=item StatusDecodingTable

Bit wise description of the fault status for decoding

=back

B<Bosch attributes>

=over

=item EventDebugData

Integer of event debug data -> interpretation dependent on fault entry

=item GeneralStatus

Integer with general status. Generic interpretation possible and available with attribute 'DecodedGeneralStatus'

=item DecodedGeneralStatus

Interpreted 'GeneralStatus'

=item GeneralStatusDecodingTable

Description of bit wise interpretation of 'GeneralStatus' for decoding

=item Qualification_poweron_cycle

PON cycle in which fault was qualified

=item Dequalification_poweron_cycle

PON cycle in which fault was dequalified

=item QualificationTime

ECU operating time at which fault was qualified

=item DequalificationTime

ECU operating time at which fault was dequalified

=item OccurrenceCounter

Number of times that fault was qualified

=item ASIC_Temperature

Master Asic temperature at time of fault qualification

=item StatusDecodingTable

Bit wise description of the fault status for decoding - overwrites same attribute from FaultEntry class

=cut

my $statusDecodingTableBosch = {
    'Bit_0' => 'TestFailed',
};

#
# must be called 'Bit_0' because pure numbers can't be managed in write_to_file / load_from_file ( XML notation doesnt allow pure digits ) 
#
my $generalStatusDecodingTable = {
    'Bit_0' => 'IdleMode_active',
    'Bit_1' => 'InitMode_active',
    'Bit_2' => 'VBat_OutOfRange_present',
    'Bit_3' => 'VUp_OutOfRange_present',
    'Bit_4' => 'Algo_active',
    'Bit_5' => 'DIS_ALP_enabled',
    'Bit_6' => 'Squib_fired_current_POC',
    'Bit_7' => 'reserved',    
};

has EventDebugData => ( is => "rw", isa => 'Int' );
has GeneralStatus => ( is => "rw", isa => 'Int' );
has DecodedGeneralStatus => ( is => "rw", isa => 'HashRef[Bool]' );
has GeneralStatusDecodingTable => ( is => "rw", default => sub { $generalStatusDecodingTable } ,isa => 'HashRef[Str]' );
has Qualification_poweron_cycle => ( is => "rw", isa => 'Int' );
has Dequalification_poweron_cycle => ( is => "rw", isa => 'Int' );
has QualificationTime => ( is => "rw", isa => 'Int' );
has DequalificationTime => ( is => "rw", isa => 'Int' );
has OccurrenceCounter => ( is => "rw", isa => 'Int' );
has ASIC_Temperature => ( is => "rw", isa => 'Int' );
has StatusDecodingTable => ( is => "rw", default => sub { $statusDecodingTableBosch } ,isa => 'HashRef[Str]' );

=head1 METHODS

=head2 decode_GeneralStatus

    $entry_obj -> decode_GeneralStatus();

Can be called after attribute 'GeneralStatus' is set to decode the fault status and set the attribute 'DecodedGeneralStatus'

=cut

sub decode_GeneralStatus {
    my $self = shift;
    
    my $binaryRawStatus = S_dec2bin($self -> {GeneralStatus});
    my @binaryRawStatusArray = split(//, $binaryRawStatus);
    my @binaryRawStatusArrayReversed = reverse(@binaryRawStatusArray);
    
#     foreach my $bitInStatus (sort {$a <=> $b} keys %{$self -> {GeneralStatusDecodingTable}})
    #        'Bit_0' .. 'Bit_n'
    foreach my $bitInStatus (sort __by_number__ keys %{$self -> {GeneralStatusDecodingTable}})
    {
        my $thisBitStatusString = $self -> {GeneralStatusDecodingTable}->{$bitInStatus};
        my ( $index_in_status ) = $bitInStatus =~ /(\d+)/;
        my $thisBitValue = $binaryRawStatusArrayReversed[$index_in_status];
#         my $thisBitValue = $binaryRawStatusArrayReversed[$bitInStatus];
        $self -> {DecodedGeneralStatus} -> {$thisBitStatusString} = $thisBitValue;
    }

    return 1;
}


#
# used for numerical sorting 'Bit_0' ..
#
sub __by_number__ {
    my ( $anum ) = $a =~ /(\d+)/;
    my ( $bnum ) = $b =~ /(\d+)/;
    return ( $anum || 0 ) <=> ( $bnum || 0 );
}

__PACKAGE__->meta->make_immutable;

1;

