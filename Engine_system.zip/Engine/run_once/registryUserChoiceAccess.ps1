$userID = [Environment]::UserDomainName + "\" + [Environment]::UserName
$key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.pl\UserChoice",[Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree,[System.Security.AccessControl.RegistryRights]::ChangePermissions)
$acl = $key.GetAccessControl()
$acl |Format-List
$rule = New-Object System.Security.AccessControl.RegistryAccessRule ($userID,"SetValue","Deny")
$acl.RemoveAccessRule($rule)
$key.SetAccessControl($acl)
