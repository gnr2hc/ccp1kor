#!usr\bin\perl

use strict;
use warnings;

my $latestfile = '\\\\siz1130\aerse$\Support\Tools\MLC\LIFTmotd.txt';
my $currentfile = 'U:\LIFTmotd.txt';

my ($currentmotd,$latestmotd);
$currentmotd=$latestmotd=0;

exit unless ( -e 'U:'); # exit if no U drive accessible

# get last seen motd from U-drive
if (open (IN, "< $currentfile")){
    my $line = <IN>;
    $line =~ m/latest MOTD : (\d+)/;
    $currentmotd = $1;
    close(IN);
}
else {warn "can't open $currentfile: $!";$currentmotd = 0;}

# get latest motd from N-drive (count lines)
if (open(FILE, "< $latestfile") ){

    while (<FILE>)
    {
            $latestmotd++ if (/\S/);     
    }
    $latestmotd = $currentmotd  unless ($latestmotd > 0);
    if ($currentmotd < $latestmotd){
        # open LIFT hompage to display only not seen MOTDs
        system('CMD /C start "C:\Program Files\Internet Explorer\iexplore.exe" '."http://si-airbag-www.de.bosch.com/support/LIFT/motd.aspx?motd=$currentmotd");

        # update latest motd on U-drive
        if(open (OUT, "> $currentfile")){
            print OUT"latest MOTD : $latestmotd\n";
            close(OUT);
        }
        else {warn "could not update $currentfile";}
    }
}
else {warn "can't open $latestfile: $!";}