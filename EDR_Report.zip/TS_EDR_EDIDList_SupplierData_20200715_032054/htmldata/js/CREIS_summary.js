var oTable;
var  winObj;

function htmlEncode(value) {
	// create a in-memory div, set it's inner text(which jQuery automatically
	// encodes)
	// then grab the encoded contents back out. The div never exists on the
	// page.
	return $('<div/>').text(value).html();
}

function htmlDecode(value) {
	return $('<div/>').html(value).text();
}

$(document).ready(function() {

	// find which are the columns to be able to be sorted
		var columnSort = new Array;
		/**
		 * sorting for the simdevices
		 */
		$("#summarytable").find('thead tr:nth-child(1) th').each(function() {
			var totalcolumns = 1;
			// if the th contains colspan, then set the
				// column sort option for all the effective
				// columns
				if ($(this).attr('colspan')) {
					totalcolumns = $(this).attr('colspan');

				}
				
				// for all the columns, set the column sort property for datatable
				for ( var index = 0; index < totalcolumns; index++) {
					if ($(this).is('[sortable]')
							&& $(this).attr('sortable') == 'true') {
						columnSort.push( {
							"bSortable" : true
						});
					} else {
						columnSort.push( {
							"bSortable" : false
						});
					}

				}
			});

		oTable = $("#summarytable").dataTable(
				{
					"aLengthMenu" : [ [ 25, 50, 100, 200, -1 ],
							[ 25, 50, 100, 200, "All" ] ],
					"iDisplayLength" : -1,
					"aoColumns" : columnSort,
					"fnRowCallback" : function(nRow, aData, iDisplayIndex,
							iDisplayIndexFull) {
						//$(nRow).css('background-color', 'LightSalmon');
					}
				});

		$('#summarytable tbody tr td img').click(
				function() {
					var nTr = this.parentNode.parentNode;
					var crashcode = $(this).closest('td').next('td').text();
					var additionalInfo = $(this).closest('td').find(
							'div.divCheckbox').text();

					if (this.src.match('details_close')) {
						/* This row is already open - close it */
						this.src = "./htmldata/images/details_open.png";
						oTable.fnClose(nTr);
					} else {
						/* Open this row */
						this.src = "./htmldata/images/details_close.png";
						oTable.fnOpen(nTr, additionalInfo, 'details');
					}
				});
	});

function OpenWindow(winURL, winName, winFeatures)
{
  var theWin; // this will hold our opened window

  // first check to see if the window already exists
  if (winObj != null)
  {
    // the window has already been created, but did the user close it?
    // if so, then reopen it. Otherwise make it the active window.
    if (!winObj.closed) {
      winObj.focus();
      //return winObj;
    }
    // otherwise fall through to the code below to re-open the window
  }

  // if we get here, then the window hasn't been created yet, or it
  // was closed by the user.
  winObj = window.open(winURL, winName);
} 