//Global Declarations
var ie = (document.all) ? true : false;

function hideClass(objClass)
{
    var elements = (ie) ? document.all : document.getElementsByClassName(objClass);
    for (i=0; i<elements.length; i++)
    {
        elements[i].style.display="none"
    }
}

function showClass(objClass){
  var elements = (ie) ? document.all : document.getElementsByClassName(objClass);
  for (i=0; i<elements.length; i++)
  {
       elements[i].style.display="block"
  }
}

// has to be changed if there are no log levels
function hideall()
{
  if (document.getElementById)
    {
        var i
        for (i=0;i<=5;i++)
        {
        
        
            if (i>0)
            {
                hideClass(i);
            }
          
            
        }
        hideClass('w2rep');
        hideClass('teststep');
        hideClass('warningmessage');
        hideClass('TCgraph');
        hideClass('TCtime');
        hideClass('TCtext');
        hideClass('TCtable');
    }
}

// hide all values, then show those who are selected
function set_filter(){
        
        hideall();
        filter();
}

 function show_ALL(){

  if (document.getElementById)
    {
        var i
        for (i=0;i<=5;i++)
        {       
            if (i>0)
            {
                showClass(i);
            }
        }
        showClass('w2rep');
        showClass('teststep');
        showClass('warningmessage');
        showClass('TCgraph');
        showClass('TCtime');
        showClass('TCtext');
        showClass('TCtable');
    }
}

// search for the selected values and show them
function filter(){

        var InvForm = document.forms.Formular;         
         
          // go through all library values - if the value is selected, show those values
          for (var x=0;x<InvForm.filter_library.length;x++){
                if (InvForm.filter_library[x].selected){
                    showClass(InvForm.filter_library[x].value);
                }
            }

          // go through all type values - if the value is not selected, hide those values
          for (var x=0;x<InvForm.filter_type.length;x++)
          {
	          if(InvForm.filter_type[x].value == "TEXT")
	          {
	               InvForm.filter_type[x].value = "TCtext";
	          }
	          if (InvForm.filter_type[x].value == "TIME")
	          {
	                   InvForm.filter_type[x].value = "TCtime";
	          }
	          if (InvForm.filter_type[x].value == "TABLE")
                  {
                       InvForm.filter_type[x].value = "TCtable";
                  }
              if (InvForm.filter_type[x].value == "GRAPHICS")
              {
                       InvForm.filter_type[x].value = "TCgraph";
                       
              }
         }
         for (var x=0;x<InvForm.filter_type.length;x++){
            if (!InvForm.filter_type[x].selected){
                  hideClass(InvForm.filter_type[x].value);
            } else {
                    showClass(InvForm.filter_type[x].value);
            }
         }
         // go through all priority values - if the value is not selected, hide those values
         for (var x=0;x<InvForm.filter_priority.length;x++){
            if (!InvForm.filter_priority[x].selected){
                hideClass(InvForm.filter_priority[x].value);
            }
            
         }
}


// read the tables in the html file
function on_load()
{
    // array of the categories
    var categories = new Array("filter_type","filter_priority","filter_library");
    
    // go through all categories
    for(var z=0;z<categories.length;z++){
        // get all elements of the selected category by searching for the class name ..._data
        var elements = (ie) ? document.all : document.getElementsByClassName(categories[z]+"_data");
        
        // get the selection and add the name to it - if the second value is 1, select the value
        for(var i=0;i+1<elements.length;i=i+2){
            var selection = document.getElementById(categories[z]);
            var option = document.createElement("option");
            option.text = elements[i].innerHTML;        
            if(elements[i+1].innerHTML==1){
                option.selected = true;
            }
            selection.add(option);        
            
        }
    }
    // set the filter
    set_filter();    
}

function filter_show()
{
  document.getElementById("filter").hidden=false;  
}

function filter_hide()
{
   document.getElementById("filter").hidden=true;     
}
