## This file is generated using CREIS Configuration Generator Tool - Revision: 1.28  ##
## This file is generated from *.mdb: C:/TurboLIFT/AB12/config/Tools/CREIS/M0309/AWD_CREIS_M38_RT4_AWD_CREIS_04B005_20180509.mdb ##

package LIFT_PROJECT;

$Defaults->{'MDSRESULT'} = {
    "ENABLE_DEBUG_LOG_FILE" => 1,
    "RESULTS"               => {
        "DEFAULT" => {
            "MDSTYPE" => "MDSNG",
            "PATH"    => $LIFT_config::LIFT_PRJCFG_path . '/../Custlib_EDR/config/MDB/EDR_SW_Test_M04_09_054CA3_20200707.mdb',
        },
        "EDR" => {
            "MDSTYPE" => "MDSNG",
            "PATH"    => $LIFT_config::LIFT_PRJCFG_path . '/../Custlib_EDR/config/MDB/EDR_SW_Test_M04_09_054CA3_20200707.mdb',
        },
        "SCI" => {
            "MDSTYPE" => "MDSNG",
            "PATH"    => $LIFT_config::LIFT_PRJCFG_path . '/../Custlib_EDR/config/MDB/EDR_SW_Test_M04_09_054CA3_20200707.mdb',
        }
    }
};

$Defaults->{'CRASH_SIMULATION'} = {
    "ENVIRONMENT" => {
        "AlgoFctPedProEnable" => {
            "EnvType"                  => "SpecialBehaviourBit",
            "Mandatory"                => 0,
            "MappingMDS2Configuration" => {
                0 => "set_Configure",
                1 => "clear_Configure"
            },
            "SpecialBitName" => "DisableAlgoPep",
            "Verify"         => {
                "BitNbr_ZeroBased"          => 5,
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_bswm_AlgoState_au32(1)",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => 0
                }
            }
        },
        "AlgoFctPitchoverEnable" => {
            "EnvType"                  => "SpecialBehaviourBit",
            "Mandatory"                => 0,
            "MappingMDS2Configuration" => {
                0 => "set_Configure",
                1 => "clear_Configure"
            },
            "SpecialBitName" => "DisableAlgoPitch",
            "Verify"         => {
                "BitNbr_ZeroBased"          => 6,
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_bswm_AlgoState_au32(1)",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => 0
                }
            }
        },
        "AlgoFctRoseEnable" => {
            "EnvType"                  => "SpecialBehaviourBit",
            "Mandatory"                => 0,
            "MappingMDS2Configuration" => {
                0 => "set_Configure",
                1 => "clear_Configure"
            },
            "SpecialBitName" => "DisableAlgoRollover",
            "Verify"         => {
                "BitNbr_ZeroBased"          => 3,
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_bswm_AlgoState_au32(1)",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => 0
                }
            }
        },
        "CsEcuHighGXMonErrBehaviour" => {
            "EnvType"   => "FaultManipulation",
            "FaultName" => "rb_csem_MonPermAccXHgMonChl_flt",
            "Mandatory" => 0,
            "Verify"    => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verification not possible"
            }
        }
        ,
        "CsEcuHighGXMonOverloadBhvr" => {
            "EnvType"         => "SpecificFunction",
            "Mandatory"       => 0,
            "OverloadChannel" => "ECU: Valid: 0: NoFilter (1g=1LSB)",
            "ResetMdbValue"   => 0,
            "SensorName"      => "ECU: Acc_MG: X: SMI800_810_860_axay_35g_260Hz",
            "Verify"          => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verification not possible"
            }
        },
        "CsEcuHighGXMonOverloadEnd" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 0,
            "Text"      => "Parameter for other environments."
        },
        "CsEcuHighGXMonOverloadStart" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 0,
            "Text"      => "Parameter for other environments."
        },
        "CsEcuHighGYMonErrBehaviour" => {
            "EnvType"   => "FaultManipulation",
            "FaultName" => "rb_csem_MonPermAccYHgMonChl_flt",
            "Mandatory" => 0,
            "Verify"    => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verification not possible"
            }
        },
        "CsEcuHighGYMonOverloadBhvr" => {
            "EnvType"         => "SpecificFunction",
            "Mandatory"       => 0,
            "OverloadChannel" => "ECU: Valid: 0: NoFilter (1g=1LSB)",
            "ResetMdbValue"   => 0,
            "SensorName"      => "ECU: Acc_MG: -Y: SMI800_810_860_axay_35g_260Hz",
            "Verify"          => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verification not possible"
            }
        },
        "CsEcuHighGYMonOverloadEnd" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 0,
            "Text"      => "Parameter for other environments."
        },
        "CsEcuHighGYMonOverloadStart" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 0,
            "Text"      => "Parameter for other environments."
        },
        "EnvAmbientTemp" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "degC",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "CAN",
            "SignalFactor_Mdb2Net" => 1,
            "SignalName"           => "Ext_temperature",
            "SignalUnit_Net"       => "degC",
            "SourceEnvironment"    => "EnvAmbientTemp_Source",
            "SourceMapping"        => {
                0 => "TEMPERATURE_degCelsius",
                1 => "EnvAmbientTemp"
            },
            "Verify" => {
                "EnvVerificationType"       => "PdLabel",
                "Factor_LsbPdLabel2Mdb"     => 1,
                "PdLabel"                   => "rb_cia_AmbientTemp_s8",
                "SignalMapping_Mdb2PdLabel" => {
                    "INVALID" => 65534
                },
                "Tolerance"           => 1,
                "ValidityEnvironment" => "EnvAmbientTempValid"
            }
        },
        "EnvAmbientTempValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 1,
                1 => 0
            },
            "SignalName" => "TemperatureStatus",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvAmbientTemp'"
            }
        },
        "EnvAmbientTemp_Source" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 1,
            "Text"      => "Parameter for other environments."
        },
        "EnvEgoVelocity" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "km/h",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "CAN",
            "ResetValue"           => 0,
            "SignalFactor_Mdb2Net" => 1,
            "SignalName"           => "VSD_ESPReferenceVelocity",
            "SignalUnit_Net"       => "km/h",
            "SourceEnvironment"    => "EnvEgoVelocity_Source",
            "SourceMapping"        => {
                0 => "VELOCITY_X_kmh",
                1 => "VELOCITY_kmh",
                2 => "EnvEgoVelocity",
                3 => undef
            },
            "Verify" => {
                "EnvVerificationType"       => "PdLabel",
                "Factor_LsbPdLabel2Mdb"     => "0.125",
                "PdLabel"                   => "rb_cia_EgoVelocity_u16",
                "SignalMapping_Mdb2PdLabel" => {
                    "INVALID" => 65534
                },
                "Tolerance"           => "0.125",
                "ValidityEnvironment" => "EnvEgoVelocityValid"
            }
        },
        "EnvEgoVelocityValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "CAN",
            "ResetMdbValue"         => 1,
            "SignalMapping_Mdb2Net" => {
                0 => 1,
                1 => 0
            },
            "SignalName" => "VSD_ESPReferenceVelocityStatus",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvEgoVelocity'"
            }
        },
        "EnvEgoVelocity_Source" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 1,
            "Text"      => "Parameter for other environments."
        },
        "EnvIDFAccepFlag" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvIDFAccepFlagSel" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvIDFEolEnabled" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "IDFEolParam"
        },
        "EnvIDFRobustFactor" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvIDFSensitiveFactor" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSAEBFlag" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSAEBFlagSource" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSAEBFlagValid" => {
            "EnvType"             => "SpecificFunction",
            "Force4eachIteration" => 1,
            "Mandatory"           => 0
        },
        "EnvISSBrakePedPosValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "DRV_BrakePedalPositionStatus"
        },
        "EnvISSBrakingPressureValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "VDC_MCPressureStatus"
        },
        "EnvISSClsVel" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSClsVelSource" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSClsvelValid" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSESPAccXValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "VDC_AccLongitudinalStatus"
        },
        "EnvISSESPAccYValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "VDC_AccLateralStatus"
        },
        "EnvISSESPYawRateValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "VDC_YawRateStatus"
        },
        "EnvISSGasPedPosValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "DRV_AccPedalPositionStatus"
        },
        "EnvISSMsbFDState" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "MSB_FD_Status"
        },
        "EnvISSMsbFPState" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "MSB_FP_Status"
        },
        "EnvISSMsbRCState" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "MSB_RC_Status"
        },
        "EnvISSMsbRDState" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "MSB_RD_Status"
        },
        "EnvISSMsbRPState" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "MSB_RP_Status"
        },
        "EnvISSObjClsSource" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSObjClsValid" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSPcpAebEnable" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "EXT_PCP_AEB_Enable"
        },
        "EnvISSPcpBeltJerkEnable" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "EXT_PCP_PCWEnable"
        },
        "EnvISSPcpBsrEnable" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "EXT_PCP_BSR_Enable"
        },
        "EnvISSPcpEbEnable" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "EXT_PCP_EBEnable"
        },
        "EnvISSPcpEnable" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "EXT_PCP_Enable"
        },
        "EnvISSPcpSbEnable" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 0,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0 => 0,
                1 => 1
            },
            "SignalName" => "EXT_PCP_SBEnable"
        },
        "EnvISSTTI" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSTTISource" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSTTIValid" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvISSTTIage" => {
            "EnvType"             => "SpecificFunction",
            "Force4eachIteration" => 1,
            "Mandatory"           => 0
        },
        "EnvISSTTIageSource" => {
            "EnvType" => "Parameter",
            "Text"    => "Parameter for 'EnvISSTTIage'."
        },
        "EnvISSTTIageValid" => {
            "EnvType"             => "SpecificFunction",
            "Force4eachIteration" => 1,
            "Mandatory"           => 0
        },
        "EnvISSobjectclass" => {
            "EnvType" => "Parameter",
            "Text"    => "No mapped signal available."
        },
        "EnvPCPEolEnabled" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "PCPEolParam"
        },
        "EnvPCPMsbFDConfig" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "MsbFDConfig"
        },
        "EnvPCPMsbFPConfig" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "MsbFPConfig"
        },
        "EnvPCPMsbRCConfig" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "MsbRCConfig"
        },
        "EnvPCPMsbRDConfig" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "MsbRDConfig"
        },
        "EnvPCPMsbRPConfig" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "MsbRPConfig"
        },
        "EnvVehicleDrivingDir" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "CAN",
            "SignalMapping_Mdb2Net" => {
                0         => 0,
                1         => 1,
                "INVALID" => 3
            },
            "SignalName" => "VSD_VehDrivingDirection",
            "Verify"     => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_DrivingDirection_u8",
                "SignalMapping_Mdb2PdLabel" => {
                    0         => 0,
                    1         => 1,
                    "INVALID" => 3
                },
                "ValidityEnvironment" => "EnvVehicleDrivingDirValid"
            }
        },
        "EnvVehicleDrivingDirSource" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 1,
            "Text"      => "Parameter for other environments."
        },
        "EnvVehicleDrivingDirValid" => {
            "EnvType"   => "Parameter",
            "Mandatory" => 1,
            "Text"      => "Parameter for other environments.",
            "Verify"    => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvVehicleDrivingDir'"
            }
        },
        "FCLConfSystem_DriverRight" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 0,
            "SpecialBitName" => "IsRightHandDriver",
            "Verify"         => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_siam_DriverConfigSign_s8",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => -1
                }
            }
        },
        "PsPasFDConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PasFD"
        },
        "PsPasFDErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PASFD"
        },
        "PsPasFPConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PasFP"
        },
        "PsPasFPErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PASFP"
        },
        "PsPasMDConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PasMD"
        },
        "PsPasMDErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PASMD"
        },
        "PsPasMPConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PasMP"
        },
        "PsPasMPErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PASMP"
        },
        "PsPcsCConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PcsC"
        },
        "PsPcsCErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PCSC"
        },
        "PsPcsCenterConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PcsC"
        },
        "PsPcsCenterErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PCSC"
        },
        "PsPpsFDConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PpsFD"
        },
        "PsPpsFDErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PPSFD"
        },
        "PsPpsFPConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PpsFP"
        },
        "PsPpsFPErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PPSFP"
        },
        "PsPtsDConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PtsD"
        },
        "PsPtsDErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PTSD"
        },
        "PsPtsPConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PtsP"
        },
        "PsPtsPErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PTSP"
        },
        "PsRearConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "PasRC"
        },
        "PsRearErrBehavior" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PASRC"
        },
        "PsRearErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "PASRC"
        },
        "PsUfsDConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "UfsD"
        },
        "PsUfsDErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "UFSD"
        },
        "PsUfsDrConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "UfsD"
        },
        "PsUfsDrErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "UFSD"
        },
        "PsUfsPConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "UfsP"
        },
        "PsUfsPErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "UFSP"
        },
        "PsUfsPaConfigured" => {
            "EnvType"    => "ExternalSensorConfiguration",
            "Mandatory"  => 0,
            "SensorName" => "UfsP"
        },
        "PsUfsPaErrBehaviour" => {
            "EnvType"    => "ExternalSensorError",
            "Mandatory"  => 0,
            "SensorName" => "UFSP"
        },
        "Switch_BLFD_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "BLFD",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_BLFD_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "BLFD",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_BLFD_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "BLFD",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        },
        "Switch_BLFP_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "BLFP",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_BLFP_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "BLFP",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_BLFP_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "BLFP",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        },
        "Switch_BLRC_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "BLRC",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_BLRC_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "BLRC",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_BLRC_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "BLRC",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        },
        "Switch_BLRD_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "BLRD",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_BLRD_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "BLRD",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_BLRD_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "BLRD",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        },
        "Switch_BLRP_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "BLRP",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_BLRP_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "BLRP",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_BLRP_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "BLRP",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        },
        "Switch_OPSFP_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "OPSFP",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_OPSFP_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "OPSFP",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_OPSFP_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "OPSFP",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        },
        "Switch_PADS_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "PADS1",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_PADS_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "PADS1",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_PADS_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "PADS1",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        },
        "Switch_SPSFD_Configured" => {
            "EnvType"    => "SwitchConfiguration",
            "Mandatory"  => 0,
            "SwitchName" => "SPSFD",
            "Verify"     => {
                "EnvVerificationType" => "SwitchConfiguration"
            }
        },
        "Switch_SPSFD_Diagnosable" => {
            "EnvType"    => "SwitchDiagnosable",
            "Mandatory"  => 0,
            "SwitchName" => "SPSFD",
            "Verify"     => {
                "EnvVerificationType" => "SwitchDiagnosable"
            }
        },
        "Switch_SPSFD_State" => {
            "EnvType"            => "SwitchState",
            "Mandatory"          => 1,
            "Source4SwitchValue" => "SYC",
            "SwitchName"         => "SPSFD",
            "Verify"             => {
                "EnvVerificationType" => "SwitchState"
            }
        }
    },
    "STIMULATION" => {
        "CRASH_SENSORS" => {
            "ECU: Acc_HG: -X: SMA760_axay_128g_426Hz"                        => "SMA760::Acc_HG_-X",
            "ECU: Acc_HG: -Y: SMA760_axay_128g_426Hz"                        => "SMA760::Acc_HG_-Y",
            "ECU: Acc_HG: Y: SMA760_axay_128g_426Hz"                         => "SMA760::Acc_HG_-Y",
            "ECU: Acc_LG: -X: SMI800_810_860_axay_6g_75Hz"                   => "SMI860::Acc_LG_X",
            "ECU: Acc_LG: -Y: SMI800_810_860_axay_6g_75Hz"                   => "SMI860::Acc_LG_-Y",
            "ECU: Acc_LG: -Z: SMI810_860_az_bottomLayer_6g_66Hz"             => "SMI860::Acc_LG_-Z",
            "ECU: Acc_LG: X: SMI800_810_860_axay_6g_75Hz"                    => "SMI860::Acc_LG_X",
            "ECU: Acc_MG: -X: SMI800_810_860_axay_35g_260Hz"                 => "SMI860::Acc_MG_X",
            "ECU: Acc_MG: -Y: SMI800_810_860_axay_35g_260Hz"                 => "SMI860::Acc_MG_-Y",
            "ECU: Acc_MG: X: SMI800_810_860_axay_35g_260Hz"                  => "SMI860::Acc_MG_X",
            "ECU: Acc_RHG: -X: SMA720_ax_128g_426Hz"                         => "SMA720::Acc_RHG_-X",
            "ECU: Acc_RHG: -Z: SMA720_az_32g_53Hz"                           => "SMA720::Acc_RHG_-Z",
            "ECU: Acc_RHG: X: SMA720_ax_128g_426Hz"                          => "SMA720::Acc_RHG_-X",
            "ECU: Acc_RHG: Z: SMA720_az_32g_53Hz"                            => "SMA720::Acc_RHG_-Z",
            "ECU: Angular_Rate: -Y: SMI860_SMI810_SMG810_wxwy_300grads_75Hz" => "SMG810::Angular_Rate_-Y",
            "ECU: Angular_Rate: -Z: SMI860_wz_300grads_75Hz"                 => "SMI860::AngularRate_-Z",
            "ECU: Angular_Rate: X: SMI860_SMI810_SMG810_wxwy_300grads_75Hz"  => "SMI860::Angular_Rate_X",
            "PASFD: Acc: -Y: PAS6_sync_ax_120g_426Hz"                        => "PASFD",
            "PASFD: Acc: -Y: PAS6e_sync_ax_120g_426Hz"                       => "PASFD",
            "PASFP: Acc: Y: PAS6_sync_ax_120g_426Hz"                         => "PASFP",
            "PASFP: Acc: Y: PAS6e_sync_ax_120g_426Hz"                        => "PASFP",
            "PASMD: Acc: -Y: PAS6e_sync_ax_120g_426Hz"                       => "PASMD",
            "PASMP: Acc: Y: PAS6e_sync_ax_120g_426Hz"                        => "PASMP",
            "PCSC: Acc: X: UFS6e_sync_ax_480g_426Hz"                         => "PCSC",
            "PPSFD: PPS3: 0: PPS3_sync_p0_460Hz"                             => "PPSFD",
            "PPSFD: PPS3: 0: PPS3e_PTS1e_SMP470_sync_pn_Range1_460Hz"        => "PPSFD",
            "PPSFP: PPS3: 0: PPS3_sync_p0_460Hz"                             => "PPSFP",
            "PPSFP: PPS3: 0: PPS3e_PTS1e_SMP470_sync_pn_Range1_460Hz"        => "PPSFP",
            "PTSD: PPS3: 0: PPS3_PTS1_nofilter"                              => "PTSD",
            "PTSP: PPS3: 0: PPS3_PTS1_nofilter"                              => "PTSP",
            "UFSD: Acc: X: UFS6e_sync_ax_480g_426Hz"                         => "UFSD",
            "UFSP: Acc: X: UFS6e_sync_ax_480g_426Hz"                         => "UFSP"
        },
        "NETWORK_DYNAMIC" => {
            "ECU: CAN_ESP_ReferenceVelocity: 0: NoFilter_For_Bus_Signals"    => "VSD_ESPReferenceVelocity",
            "ECU: CAN_ISSAEBBraking: Bus: NoFilter_For_Bus_Signals"          => "BMI_AEB_Expected",
            "ECU: CAN_ISSAEBFlag: Bus: NoFilter_For_Bus_Signals"             => "IDF_01_AEB_Flag",
            "ECU: CAN_ISSAEBState: Bus: NoFilter_For_Bus_Signals"            => "BMI_AEB_State",
            "ECU: CAN_ISSBeltJerk: Bus: NoFilter_For_Bus_Signals"            => "BMI_BeltJerk",
            "ECU: CAN_ISSBeltJerkExtReq: Bus: NoFilter_For_Bus_Signals"      => "EXT_MSB_BeltJerk_ExtReq",
            "ECU: CAN_ISSBrakePedPos: Bus: CAN_PedPos_Platform"              => "DRV_BrakePedalPosition",
            "ECU: CAN_ISSBrakingPressure: Bus: CAN_BrakingPressure_Platform" => "VDC_MCPressure",
            "ECU: CAN_ISSClsVel: Bus: NoFilter_For_Bus_Signals"              => "IDF_01_Closing_Velocity",
            "ECU: CAN_ISSESPAccX: Bus: CAN_Acc_Platform"                     => "VDC_AccLongitudinal",
            "ECU: CAN_ISSESPAccY: Bus: CAN_Acc_Platform"                     => "VDC_AccLateral",
            "ECU: CAN_ISSESPIntervention: Bus: NoFilter_For_Bus_Signals"     => "VDC_Intervention",
            "ECU: CAN_ISSESPYawRate: Bus: CAN_YawRate_Platform"              => "VDC_YawRate",
            "ECU: CAN_ISSFullTensExtReq: Bus: NoFilter_For_Bus_Signals"      => "EXT_MSB_FullTensing_ExtReq",
            "ECU: CAN_ISSGasPedPos: Bus: CAN_PedPos_Platform"                => "DRV_AccPedalPosition",
            "ECU: CAN_ISSObjCls: Bus: NoFilter_For_Bus_Signals"              => "IDF_01_Object_Class",
            "ECU: CAN_ISSPartTensExtReq: Bus: NoFilter_For_Bus_Signals"      => "EXT_MSB_PartTensing_ExtReq",
            "ECU: CAN_ISSTTI: Bus: NoFilter_For_Bus_Signals"                 => "IDF_01_Time_to_Impact",
            "ECU: CAN_ISSTTIage: Bus: NoFilter_For_Bus_Signals"              => "IDF_01_TTI_TimeStamp"
        }
    }
};

$Defaults->{'CRASH_MEASUREMENT_AND_EVALUATION'} = {
    "AdditionalMeasurements" => {},
    "AdditionalPdLabels"     => {
        "Configurations" => {
            "EnvDataVector" => {
                "InWork[0]" => {
                    "Mode"    => "bin",
                    "PdLabel" => "rb_edp_EnvDataVectorInWork_au32(0)"
                },
                "InWork[1]" => {
                    "Mode"    => "bin",
                    "PdLabel" => "rb_edp_EnvDataVectorInWork_au32(1)"
                },
                "InWork[2]" => {
                    "Mode"    => "bin",
                    "PdLabel" => "rb_edp_EnvDataVectorInWork_au32(2)"
                },
                "Valid[0]" => {
                    "Mode"    => "bin",
                    "PdLabel" => "rb_edp_EnvDataVectorValid_au32(0)"
                },
                "Valid[1]" => {
                    "Mode"    => "bin",
                    "PdLabel" => "rb_edp_EnvDataVectorValid_au32(1)"
                },
                "Valid[2]" => {
                    "Mode"    => "bin",
                    "PdLabel" => "rb_edp_EnvDataVectorValid_au32(2)"
                }
            },
            "PomAdcData" => {
                "Temperature_ASIC1" => {
                    "Factor"  => "0.1",
                    "Mode"    => "dec",
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Temperature_s32",
                    "Unit"    => "C"
                },
                "Temperature_ASIC2" => {
                    "Factor"  => "0.1",
                    "Mode"    => "dec",
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(1).Temperature_s32",
                    "Unit"    => "C"
                },
                "VBat1" => {
                    "Factor"  => "0.01",
                    "Mode"    => "dec",
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vbat1_u16",
                    "Unit"    => "V"
                },
                "Ver" => {
                    "Factor"  => "0.01",
                    "Mode"    => "dec",
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Ver_u16",
                    "Unit"    => "V"
                },
                "Vup" => {
                    "Factor"  => "0.01",
                    "Mode"    => "dec",
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vup_u16",
                    "Unit"    => "V"
                }
            }
        }
    },
    "FastDiagTrace" => {
        "Configurations" => {
            "AlgoActive" => {
                "rb_fcl_StatusFirCtrl_u8" => "U8"
            },
            "AlgoFlags" => {
                "T_AfnFireFlagList_t_U32X"   => "U16",
                "T_AfnFireFlagList_t_U32X.2" => "U16",
                "T_SacCsabsPlsFlagL_U8X"     => "U16",
                "T_SideFireFlags_t_U16X"     => "U16"
            },
            "EDR" => {
                "rb_dcc_ImpactInfoRT_ast(0).EventStatusFlags_u8" => "U8",
                "rb_dcc_ImpactInfoRT_ast(1).EventStatusFlags_u8" => "U8",
                "rb_dcc_ImpactInfoRT_ast(2).EventStatusFlags_u8" => "U8",
                "rb_dcsm_DataSectionStoreIndex_aen(0)"           => "U8",
                "rb_dcsm_DataSectionStoreIndex_aen(1)"           => "U8",
                "rb_dcsm_EvStoreState_aen(0)"                    => "U8",
                "rb_dcsm_EvStoreState_aen(1)"                    => "U8",
                "rb_dcsm_EvStoreState_aen(2)"                    => "U8",
                "rb_evm_EventInfo_ast(0).EventInfoFlagList_u8"   => "U8",
                "rb_evm_EventInfo_ast(0).EventSeverityList_u16"  => "U16",
                "rb_evm_EventInfo_ast(1).EventInfoFlagList_u8"   => "U8",
                "rb_evm_EventInfo_ast(1).EventSeverityList_u16"  => "U16"
            },
            "Edp_EnvDataVector(0)" => {
                "rb_edp_EnvDataVectorValid_au32(0)"   => "U8",
                "rb_edp_EnvDataVectorValid_au32(0).1" => "U8",
                "rb_edp_EnvDataVectorValid_au32(0).2" => "U8",
                "rb_edp_EnvDataVectorValid_au32(0).3" => "U8",
                "rb_fcl_StatusFirCtrl_u8"             => "U8"
            },
            "Edp_EnvDataVector(1)" => {
                "rb_edp_EnvDataVectorValid_au32(1)"   => "U8",
                "rb_edp_EnvDataVectorValid_au32(1).1" => "U8",
                "rb_edp_EnvDataVectorValid_au32(1).2" => "U8",
                "rb_edp_EnvDataVectorValid_au32(1).3" => "U8",
                "rb_fcl_StatusFirCtrl_u8"             => "U8"
            },
            "Edp_EnvDataVector(2)" => {
                "rb_edp_EnvDataVectorValid_au32(2)"   => "U8",
                "rb_edp_EnvDataVectorValid_au32(2).1" => "U8",
                "rb_edp_EnvDataVectorValid_au32(2).2" => "U8",
                "rb_edp_EnvDataVectorValid_au32(2).3" => "U8",
                "rb_fcl_StatusFirCtrl_u8"             => "U8"
            },
            "EdrCompleteness" => {
                "Fee_Rb_WorkingState_en" => "U8",
                "Fls_Mode"               => "U8",
                "Fls_Rb_stSuspend_en"    => "U8",
                "Fls_stMain"             => "U8"
            },
            "FreezeEnvironment" => {
                "rb_fcl_StatusFirCtrl_u8"                          => "U8",
                "rb_swm_SwitchInfo_ast(2).PositionFiltered_en"     => "U8",
                "rb_swm_SwitchInfo_ast(2).StatusFiltered_en"       => "U8",
                "rb_swma_AsicChannelData_ast(0)(0).Value10Bit_u16" => "U16"
            },
            "FreezeSwitchState" => {
                "rb_fcl_StatusFirCtrl_u8"                          => "U8",
                "rb_swm_SwitchInfo_ast(2).PositionFiltered_en"     => "U8",
                "rb_swm_SwitchInfo_ast(2).StatusFiltered_en"       => "U8",
                "rb_swma_AsicChannelData_ast(0)(0).Value10Bit_u16" => "U16"
            },
            "FreezeVelocity" => {
                "T_CafFrozenVelocity_t_U16X"  => "U16",
                "rb_cia_UnfrozenVelocity_u16" => "U16",
                "rb_fcl_StatusFirCtrl_u8"     => "U8"
            },
            "IDF" => {
                "T_FrtIDFAccepFlag_t_U8X"   => "U8",
                "T_FrtIDFTtiAgeOrg_t_U16X"  => "U16",
                "T_FrtIDFTtiCounter_t_S16X" => "S16",
                "T_FrtIDFTtiOrg_t_S16X"     => "S16",
                "T_FrtVelocity_t_U16X"      => "U16"
            },
            "IDF_Faults" => {
                "T_FrtIDFActive_t_U8X"          => "U8",
                "T_FrtIDFEnvMonCnt_t_U8X"       => "U8",
                "T_FrtIDFEnvMonErrFlag_t_U8X"   => "U8",
                "T_FrtIDFEnvMonEventFlag_t_U8X" => "U8",
                "T_FrtIDFPassbyFlag_t_U8X"      => "U8",
                "T_FrtStcReset_t_U8X"           => "U8",
                "rb_cia_ISSTimeToImpact_s16"    => "S16"
            },
            "IDF_Signals" => {
                "rb_cdp_SynTimeStamp_u32"       => "U32",
                "rb_cia_ISSAEBFlag_u8"          => "U8",
                "rb_cia_ISSCOMValid_u8"         => "U8",
                "rb_cia_ISSClosingVelocity_u16" => "U16",
                "rb_cia_ISSObjectClass_u8"      => "U8",
                "rb_cia_ISSTimeToImpactAge_u16" => "U16"
            },
            "Overload" => {
                "rb_csem_SensorDataRT_st.InertDataOverload_b32"    => "U32",
                "rb_siam_CentralSensorData_st.CsOverloadFlags_b16" => "U16"
            },
            "SensorData" => {
                "rb_siam_CentralSensorData_st.CsLowGXData_s16" => "S16",
                "rb_siam_CentralSensorData_st.CsLowGYData_s16" => "S16"
            },
            "cia_signals" => {
                "rb_cia_AmbientTemp_s8"         => "S8",
                "rb_cia_CANSignalValidFlags_b8" => "U8",
                "rb_cia_DrivingDirection_u8"    => "U8",
                "rb_cia_EgoVelocity_u16"        => "U16"
            },
            "temperature" => {
                "T_CafFrozenTempValid_t_S8X"    => "U16",
                "T_CafFrozenTemperature_t_S8X"  => "U8",
                "rb_cia_AmbientTemp_s8"         => "S8",
                "rb_cia_CANSignalValidFlags_b8" => "U8"
            }
        },
        "NbrOfCanIDs" => 1
    },
    "Faults" => {
        "AdditionalAfterCrash" => {
            "CrashDependent" => {},
            "Generic"        => {
                "CsemMonTempFaults_Clipping" => {
                    "EventDebugData" => "0b0000000100000000",
                    "FaultName"      => "rb_csem_MonTemp.*_flt"
                },
                "EdrDataFullFault" => {
                    "FaultName" => "rb_edr_DataAreaFull_flt"
                },
                "EventManagerFault" => {
                    "FaultName" => "rb_evm_.*CrashDetected_flt"
                },
                "SimpFaults" => {
                    "FaultName" => "rb_simp_SignalMonPes.*_flt"
                }
            }
        },
        "BeforeCrash" => {
            "EnvironmentDependent" => {
                "rb_csem_MonPermAccXHgMonChl_flt" => "#CsEcuHighGXMonErrBehaviour == 0",
                "rb_csem_MonTempAccXHgMonChl_flt" => "#CsEcuHighGXMonOverloadBhvr > 0",
                "rb_psem_OpenLineUFSD_flt"        => "#PsUfsDConfigured|1 == 1 and #PsUfsDErrBehaviour == 0",
                "rb_psem_OpenLineUFSP_flt"        => "#PsUfsPConfigured|1 == 1 and #PsUfsPErrBehaviour == 0",
                "rb_swm_OpenLineBLFD_flt"         => "#Switch_BLFD_Configured|1 == 1 and #Switch_BLFD_State == 3",
                "rb_swm_OpenLineBLFP_flt"         => "#Switch_BLFP_Configured|1 == 1 and #Switch_BLFP_State == 3",
                "rb_swm_OpenLineBLRC_flt"         => "#Switch_BLRC_Configured|1 == 1 and #Switch_BLRC_State == 3",
                "rb_swm_OpenLineBLRD_flt"         => "#Switch_BLRD_Configured|1 == 1 and #Switch_BLRD_State == 3",
                "rb_swm_OpenLineBLRP_flt"         => "#Switch_BLRP_Configured|1 == 1 and #Switch_BLRP_State == 3",
                "rb_swm_OpenLineOPSFP_flt"        => "#Switch_OPSFP_Configured|1 == 1 and #Switch_OPSFP_State == 3",
                "rb_swm_OpenLinePADS1_flt"        => "#Switch_PADS_Configured|1 == 1 and #Switch_PADS_State == 3",
                "rb_swm_OpenLineSPSFD_flt"        => "#Switch_SPSFD_Configured|1 == 1 and #Switch_SPSFD_State == 3",
                "rb_swm_UndefinedBLFD_flt"        => "#Switch_BLFD_State == 2",
                "rb_swm_UndefinedBLFP_flt"        => "#Switch_BLFP_State == 2",
                "rb_swm_UndefinedBLRC_flt"        => "#Switch_BLRC_State == 2",
                "rb_swm_UndefinedBLRD_flt"        => "#Switch_BLRD_State == 2",
                "rb_swm_UndefinedBLRP_flt"        => "#Switch_BLRP_State == 2",
                "rb_swm_UndefinedOPSFP_flt"       => "#Switch_OPSFP_State == 2",
                "rb_swm_UndefinedPADS1_flt"       => "#Switch_PADS_State == 2",
                "rb_swm_UndefinedSPSFD_flt"       => "#Switch_SPSFD_State == 2",
                "rb_swm_UnexpectedBLFD_flt"       => "#Switch_BLFD_Configured|1 == 0 and not #Switch_BLFD_State == 3",
                "rb_swm_UnexpectedBLFP_flt"       => "#Switch_BLFP_Configured|1 == 0 and not #Switch_BLFP_State == 3",
                "rb_swm_UnexpectedBLRC_flt"       => "#Switch_BLRC_Configured|1 == 0 and not #Switch_BLRC_State == 3",
                "rb_swm_UnexpectedBLRD_flt"       => "#Switch_BLRD_Configured|1 == 0 and not #Switch_BLRD_State == 3",
                "rb_swm_UnexpectedBLRP_flt"       => "#Switch_BLRP_Configured|1 == 0 and not #Switch_BLRP_State == 3",
                "rb_swm_UnexpectedOPSFP_flt"      => "#Switch_OPSFP_Configured|1 == 0 and not #Switch_OPSFP_State == 3",
                "rb_swm_UnexpectedPADS1_flt"      => "#Switch_PADS_Configured|1 == 0 and not #Switch_PADS_State == 3",
                "rb_swm_UnexpectedSPSFD_flt"      => "#Switch_SPSFD_Configured|1 == 0 and not #Switch_SPSFD_State == 3"
            },
            "Generic" => []
        }
    },
    "General_Settings" => {
        "DisposalTime_ms"                   => 300,
        "EDRnumberOfEvents"                 => "SAD",
        "EDRnumberOfEventsPEP"              => "SAD",
        "FiringCurrentThresholdTolerance_A" => "0.2",
        "FiringCurrentThreshold_A"          => "SYC",
        "SamplingFrequency_Hz"              => 20000
    },
    "InvalidEnvironmentCombinations" => {
        "BLFD"  => "(#Switch_BLFD_Configured|1 == 1 and #Switch_BLFD_Diagnosable|1 == 0 and #Switch_BLFD_State == 3 or #Switch_BLFD_State == 2) or (#Switch_BLFD_Configured|1 == 0 and #Switch_BLFD_Diagnosable|1 == 0 and #Switch_BLFD_State == 1 or #Switch_BLFD_State == 2)",
        "BLFP"  => "(#Switch_BLFP_Configured|1 == 1 and #Switch_BLFP_Diagnosable|1 == 0 and #Switch_BLFP_State == 3 or #Switch_BLFP_State == 2) or (#Switch_BLFP_Configured|1 == 0 and #Switch_BLFP_Diagnosable|1 == 0 and #Switch_BLFP_State == 1 or #Switch_BLFP_State == 2)",
        "BLRC"  => "(#Switch_BLRC_Configured|1 == 1 and #Switch_BLRC_Diagnosable|1 == 0 and #Switch_BLRC_State == 3 or #Switch_BLRC_State == 2) or (#Switch_BLRC_Configured|1 == 0 and #Switch_BLRC_Diagnosable|1 == 0 and #Switch_BLRC_State == 1 or #Switch_BLRC_State == 2)",
        "BLRD"  => "(#Switch_BLRD_Configured|1 == 1 and #Switch_BLRD_Diagnosable|1 == 0 and #Switch_BLRD_State == 3 or #Switch_BLRD_State == 2) or (#Switch_BLRD_Configured|1 == 0 and #Switch_BLRD_Diagnosable|1 == 0 and #Switch_BLRD_State == 1 or #Switch_BLRD_State == 2)",
        "BLRP"  => "(#Switch_BLRP_Configured|1 == 1 and #Switch_BLRP_Diagnosable|1 == 0 and #Switch_BLRP_State == 3 or #Switch_BLRP_State == 2) or (#Switch_BLRP_Configured|1 == 0 and #Switch_BLRP_Diagnosable|1 == 0 and #Switch_BLRP_State == 1 or #Switch_BLRP_State == 2)",
        "OPSFP" => "(#Switch_OPSFP_Configured|1 == 1 and #Switch_OPSFP_Diagnosable|1 == 0 and #Switch_OPSFP_State == 3 or #Switch_OPSFP_State == 2) or (#Switch_OPSFP_Configured|1 == 0 and #Switch_OPSFP_Diagnosable|1 == 0 and #Switch_OPSFP_State == 1 or #Switch_OPSFP_State == 2)",
        "PADS"  => "(#Switch_PADS_Configured|1 == 1 and #Switch_PADS_Diagnosable|1 == 0 and #Switch_PADS_State == 3 or #Switch_PADS_State == 2) or (#Switch_PADS_Configured|1 == 0 and #Switch_PADS_Diagnosable|1 == 0 and #Switch_PADS_State == 1 or #Switch_PADS_State == 2)",
        "SPSFD" => "(#Switch_SPSFD_Configured|1 == 1 and #Switch_SPSFD_Diagnosable|1 == 0 and #Switch_SPSFD_State == 3 or #Switch_SPSFD_State == 2) or (#Switch_SPSFD_Configured|1 == 0 and #Switch_SPSFD_Diagnosable|1 == 0 and #Switch_SPSFD_State == 1 or #Switch_SPSFD_State == 2)"
    },
    "SimDevices" => {
        "AB1FD"                    => {},
        "AB1FP"                    => {},
        "AB2FD"                    => {},
        "AB2FP"                    => {},
        "AB3FP"                    => {},
        "ALLFD"                    => {},
        "ALLFP"                    => {},
        "ASC1FD"                   => {},
        "AlgoWatchDogCSABSFailure" => {
            "DebugData"  => "0b0000000001001000",
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultsList" => ["rb_simc_SignalMonCtrlMain_flt"],
            "MeasureBy"  => "fault_memory"
        },
        "AlgoWatchDogFrtReaFailure" => {
            "DebugData"  => "0b0000000000xx1000",
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultsList" => ["rb_simc_SignalMonCtrlMain_flt"],
            "MeasureBy"  => "fault_memory"
        },
        "AlgoWatchDogPesFailure" => {
            "DebugData"  => "0b0000000000001000",
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultsList" => [ "rb_simp_SignalMonPesPasFD_flt", "rb_simp_SignalMonPesPasFP_flt", "rb_simp_SignalMonPesPasMD_flt", "rb_simp_SignalMonPesPasMP_flt", "rb_simp_SignalMonPesPpsFD_flt", "rb_simp_SignalMonPesPpsFP_flt" ],
            "MeasureBy"  => "fault_memory"
        },
        "AlgoWatchDogPitchFailure" => {
            "DebugData"  => "0b0000000000001000",
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultsList" => ["rb_simc_SignalMonCtrlPitchRateLf_flt"],
            "MeasureBy"  => "fault_memory"
        },
        "AlgoWatchDogRoseFailure" => {
            "DebugData"  => "0b0000000000001000",
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultsList" => ["rb_simc_SignalMonCtrlRollRateLf_flt"],
            "MeasureBy"  => "fault_memory"
        },
        "BATD"                  => {},
        "BT1FD"                 => {},
        "BT1FP"                 => {},
        "BT1RC"                 => {},
        "BT1RD"                 => {},
        "BT1RP"                 => {},
        "BT2FD"                 => {},
        "BT2FP"                 => {},
        "BT2RC"                 => {},
        "BT2RD"                 => {},
        "BT2RP"                 => {},
        "FCO_DeploymentTrigger" => {
            "CRO1" => {
                "ALIAS"                => "CRO1",
                "Evaluation"           => "CREIS_EvaluatePWMSignal",
                "Ignored"              => "no evaluation method defined",
                "MeasureBy"            => "trace_analog",
                "SamplingFrequency_Hz" => 5000,
                "starting_level"       => "high",
                "t_max_high_ms"        => "4.5",
                "t_max_low_ms"         => "4.5",
                "t_min_high_ms"        => "3.5",
                "t_min_low_ms"         => "3.5"
            },
            "CRO2" => {
                "ALIAS"                => "CRO2_FP",
                "Evaluation"           => "CREIS_EvaluatePWMSignal",
                "Ignored"              => "no evaluation method defined",
                "MeasureBy"            => "trace_analog",
                "SamplingFrequency_Hz" => 5000,
                "starting_level"       => "high",
                "t_max_high_ms"        => "4.5",
                "t_max_low_ms"         => "4.5",
                "t_min_high_ms"        => "3.5",
                "t_min_low_ms"         => "3.5"
            }
        },
        "FCO_EmergencyCallTrigger" => {
            "Ignored" => "no evaluation method defined"
        },
        "FCO_FuelCutOffTrigger" => {
            "Ignored" => "no evaluation method defined"
        },
        "FCO_PitchoverEvent" => {
            "Ignored" => "no evaluation method defined"
        },
        "FCO_RollStatEvent" => {
            "CRO1" => {
                "ALIAS"                => "CRO1",
                "Evaluation"           => "CREIS_EvaluatePWMSignal",
                "MeasureBy"            => "trace_analog",
                "SamplingFrequency_Hz" => 5000,
                "starting_level"       => "high",
                "t_max_high_ms"        => "2.5",
                "t_max_low_ms"         => "2.5",
                "t_min_high_ms"        => "1.5",
                "t_min_low_ms"         => "1.5"
            },
            "CRO2" => {
                "ALIAS"                => "CRO2_FP",
                "Evaluation"           => "CREIS_EvaluatePWMSignal",
                "MeasureBy"            => "trace_analog",
                "SamplingFrequency_Hz" => 5000,
                "starting_level"       => "high",
                "t_max_high_ms"        => "2.5",
                "t_max_low_ms"         => "2.5",
                "t_min_high_ms"        => "1.5",
                "t_min_low_ms"         => "1.5"
            }
        },
        "FrtStcResetOff" => {
            "Ignored" => "no evaluation method defined"
        },
        "HOODD" => {},
        "HOODP" => {},
        "IC1FD" => {},
        "IC1FP" => {},
        "IC1RD" => {
            "MeasureBy" => "trace_analog"
        },
        "IC1RP"        => {},
        "KA1FD"        => {},
        "KA1FP"        => {},
        "PPAB1"        => {},
        "SA1FD"        => {},
        "SA1FP"        => {},
        "SA1RD"        => {},
        "SA1RP"        => {},
        "SCON_DIS_AHP" => {
            "ALIAS"                => "Front_4_3_5",
            "Evaluation"           => "CREIS_EvaluateSlope",
            "MeasureBy"            => "trace_analog",
            "SamplingFrequency_Hz" => 20000,
            "SlopeThreshold_V"     => 1,
            "SlopeType"            => "negative",
            "VoltageRange"         => 5
        },
        "SCON_DIS_WFL" => {
            "Evaluation"           => "CREIS_EvaluateSlope",
            "MeasureBy"            => "trace_analog",
            "SamplingFrequency_Hz" => 20000,
            "SlopeThreshold_V"     => 1,
            "SlopeType"            => "negative",
            "VoltageRange"         => 5
        },
        "SCON_DIS_XFL" => {
            "Evaluation"           => "CREIS_EvaluateSlope",
            "MeasureBy"            => "trace_analog",
            "SamplingFrequency_Hz" => 20000,
            "SlopeThreshold_V"     => 1,
            "SlopeType"            => "negative",
            "VoltageRange"         => 5
        },
        "SCON_DIS_YFL" => {
            "Evaluation"           => "CREIS_EvaluateSlope",
            "MeasureBy"            => "trace_analog",
            "SamplingFrequency_Hz" => 20000,
            "SlopeThreshold_V"     => 1,
            "SlopeType"            => "negative",
            "VoltageRange"         => 5
        },
        "SimCsAccEcuHighGXFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlHighgXMon_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuHighGYFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlHighgYMon_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuLowGXFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlLowgX_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuLowGYFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlLowgY_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuLowGYPlsFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "Ignored"    => "sensor channel not used",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuLowGZFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlLowgZ_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuM45Fault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlMain_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuP45Fault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlMain_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuPlsM45Fault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "Ignored"    => "sensor channel not used",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuPlsP45Fault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "Ignored"    => "sensor channel not used",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuPlsXFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlPlausi_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuPlsYFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlPlausi_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuPlsZFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlPlausi_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuXFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlMain_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsAccEcuYFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlMain_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsEcuPitchRateFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlPitchRateLf_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsEcuRollRateFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlRollRateLf_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsEcuYawRateDriftFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "Ignored"    => "sensor channel not used",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsEcuYawRateFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlYawRateLf_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsEcuYawRatePlsFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "Ignored"    => "sensor channel not used",
            "MeasureBy"  => "fault_memory"
        },
        "SimCsLocMonErrorFlag" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simc_SignalMonCtrlMain_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPasFDFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPasFD_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPasFPFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPasFP_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPasMDFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPasMD_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPasMPFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPasMP_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPcdCFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPcsC_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPcsCFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPcsC_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPpsFDFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPpsFD_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPpsFPFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPpsFP_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPtsDFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPtsD_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPtsLocMonFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPtsP_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsPtsPFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesPtsP_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsRearFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonCtrlPasRD_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsUfsDFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesUfsD_flt",
            "MeasureBy"  => "fault_memory"
        },
        "SimPsUfsPFault" => {
            "Evaluation" => "CREIS_EvaluateFaultEntry",
            "FaultName"  => "rb_simp_SignalMonPesUfsP_flt",
            "MeasureBy"  => "fault_memory"
        }
    }
};

$Defaults->{'REPORTING'} = {
    "LOGLEVELS" => {
        1 => {
            "CONSOLE" => 1,
            "HTML"    => 1,
            "TEXT"    => 1
        },
        2 => {
            "CONSOLE" => 1,
            "HTML"    => 1,
            "TEXT"    => 1
        },
        3 => {
            "CONSOLE" => 1,
            "HTML"    => 1,
            "TEXT"    => 1
        },
        4 => {
            "CONSOLE" => 0,
            "HTML"    => 0,
            "TEXT"    => 1
        },
        5 => {
            "CONSOLE" => 0,
            "HTML"    => 0,
            "TEXT"    => 1
        },
        "w2rep" => {
            "CONSOLE" => 1,
            "HTML"    => 1,
            "TEXT"    => 1
        }
    }
};

1;
