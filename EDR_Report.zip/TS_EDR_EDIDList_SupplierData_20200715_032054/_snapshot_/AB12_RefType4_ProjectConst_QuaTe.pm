package LIFT_PROJECT;

#$VERSION = q$Revision: 1.3 $;
#$HEADER = q$Header: config/Mappings/AB12_RefType4_ProjectConst_QuaTe.pm 1.3 2020/03/03 03:01:37CET Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

$Defaults->{'QUATE'} = {

    # Master QuaTe 0
    'QUATE0' => {
        'FIRMWARE' => 'rev2_step42_v6.bit',

        #Device	Type			FP   Name
        #0		PSI5DEVICE_1CH	1    UFSD
        #1		PSI5DEVICE_1CH	2    UFSP
        #2		PSI5DEVICE_1CH	3    PASFD
        #3		PSI5DEVICE_1CH	4    PASFP
        #4		PSI5DEVICE_1CH	5    PASMD
        #5		PSI5DEVICE_1CH	6    PASMP
        #6		PSI5DEVICE_1CH	7    PCSC
        #7		PSI5DEVICE_1CH	8    PTSD
        #8		PSI5DEVICE_1CH	9    PTSP
        #9		PSI5DEVICE_1CH	10
        #10		PSI5DEVICE_1CH	11
        #11		PSI5DEVICE_1CH	12  PPSFD
        #12		PSI5DEVICE_1CH	13  PPSFP
        #13		PSI5DEVICE_1CH	14
        #14		PSIMonitor

        'DEVICES' => {
            '0' => {    # FP 1
                'DEVICE_NAME' => 'UFSD',
                'ROM_FILE'    => 'PSI5_UFS6e_UFSx_CM17.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'UFSD',    #channel direction
                        'SID'          => '0x10',
                    },
                },
            },
            '1' => {                                 # FP 2
                'DEVICE_NAME' => 'UFSP',
                'ROM_FILE'    => 'PSI5_UFS6e_UFSx_CM17.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'UFSP',    #channel direction
                        'SID'          => '0x11',
                    },
                },
            },
            '2' => {                                 # FP 3
                'DEVICE_NAME' => 'PASFD',
                #'ROM_FILE'    => 'PSI5_PAS6_PASFx_CM0.rom',
                'ROM_FILE'    => 'PSI5_PAS6e_PASFx_189_Slot1_CM20.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASFD',    #channel direction
                        'SID'          => '0x09',
                    },
                },
            },
            '3' => {                                  # FP 4
                'DEVICE_NAME' => 'PASFP',
                #'ROM_FILE'    => 'PSI5_PAS6_PASFx_CM0.rom',
                'ROM_FILE'    => 'PSI5_PAS6e_PASFx_189_Slot1_CM20.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASFP',    #channel direction
                        'SID'          => '0x0A',
                    },
                },
            },
            '4' => {                                  # FP 5
                'DEVICE_NAME' => 'PASMD',
                #'ROM_FILE'    => 'PSI5_PAS6e_PASMx_CM17.rom',
                'ROM_FILE'    => 'PSI5_PAS6e_PASMx_189_Slot2_CM21.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASMD',    #channel direction
                        'SID'          => '0x0B',
                    },
                },
            },
            '5' => {                                  # FP 6
                'DEVICE_NAME' => 'PASMP',
                #'ROM_FILE'    => 'PSI5_PAS6e_PASMx_CM17.rom',
                'ROM_FILE'    => 'PSI5_PAS6e_PASMx_189_Slot2_CM21.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASMP',    #channel direction
                        'SID'          => '0x0C',
                    },
                },
            },
            '6' => {                                  # FP 7
                'DEVICE_NAME' => 'PCSC',
                'ROM_FILE'    => 'PSI5_UFS6e_UFSx_CM17.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PCSC',     #channel direction
                        'SID'          => '0x0E',
                    },
                },
            },
            '7' => {                                  # FP 8
                'DEVICE_NAME' => 'PTSD',
                'ROM_FILE'    => 'PSI5_PTS1_PTSx_CM7.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PTSD',     #channel direction
                        'SID'          => '0x0D',
                    },
                },
            },
            '8' => {                                  # FP 9
                'DEVICE_NAME' => 'PTSP',
                'ROM_FILE'    => 'PSI5_PTS1_PTSx_CM7.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PTSP',     #channel direction
                        'SID'          => '0x0F',
                    },
                },
            },

            '11' => {                                 # FP 12
                'DEVICE_NAME' => 'PPSFD',
                #'ROM_FILE'    => 'PSI5_PPS3_PPSFx_CM7.rom',
                'ROM_FILE'    => 'PSI5_PPS3e_189k_slot4_CM11.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PPSFD',    #channel direction
                    },
                },
            },
            '12' => {                                 # FP 13
                'DEVICE_NAME' => 'PPSFP',
                #'ROM_FILE'    => 'PSI5_PPS3_PPSFx_CM7.rom',
                'ROM_FILE'    => 'PSI5_PPS3e_189k_slot4_CM11.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PPSFP',    #channel direction
                    },
                },
            },
            '14' => {                                 #
                'DEVICE_NAME' => 'PSImonitorQ1',
            },
        },

        'TRIGGER' => {

            # LINE_1 and LINE_2 can be OFF(Master QuaTe Default Value), POS_SLOPE, NEG_SLOPE,EXT_TRIGGER
            'LINE_1' => 'OFF',
            'LINE_2' => 'NEG_SLOPE',
        },
    },

    # Slave QuaTe 1
    'QUATE1' => {
        #'FIRMWARE' => 'rev2_step81_v1.bit', # C0 samples of SMI8
        'FIRMWARE' => 'rev2_step82_v1.bit',  # C1 and C2 samples of SMI8

        #Device	Type		FP	used with new LVDS
        #0		SMA7xx		-	ChipSelect x - SMA760
        #1 		SMA7xx		-	ChipSelect x - SMA720
        #2		SMI8xx		-	ChipSelect x - SMI860
        #3		SMI8xx		-	ChipSelect x - SMG810
        #4		SMB470		-	-
        #5		SPIMonitor32	SPImonitorQ0

        'DEVICES' => {
            '0' => {
                'DEVICE_NAME' => 'SMA760',
                'ROM_FILE'    => 'SMA760_C0_v1.rom',
                'CHIP_SELECT' => '0',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Acc_HG_-Y',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'Acc_HG_-X',
                    },
                },
            },
            '1' => {
                'DEVICE_NAME' => 'SMA720',
                'ROM_FILE'    => 'SMA720_C0_v1.rom',
                'CHIP_SELECT' => '1',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Acc_RHG_-X',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'Acc_RHG_-Z',
                    },
                },
            },
            '2' => {
                'DEVICE_NAME' => 'SMI860',
                #'ROM_FILE'    => 'SMI860_C0_v1.rom',
                'ROM_FILE'    => 'SMI860_C2_v1.rom',
                'CHIP_SELECT' => '2',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Angular_Rate_X',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'Acc_LG_-Y',
                    },
                    '2' => {
                        'CHANNEL_NAME' => 'Acc_LG_X',
                    },
                    '3' => {
                        'CHANNEL_NAME' => 'Acc_MG_-Y',
                    },
                    '4' => {
                        'CHANNEL_NAME' => 'Acc_MG_X',
                    },
                    '5' => {
                        'CHANNEL_NAME' => 'AngularRate_-Z',
                    },
                    '6' => {
                        'CHANNEL_NAME' => 'Acc_LG_-Z',
                    },

                    '7' => {
                        'CHANNEL_NAME' => 'Acc_MG_-Z',
                    },
                },
            },
            '3' => {
                'DEVICE_NAME' => 'SMG810',
                #'ROM_FILE'    => 'SMI810_C0_v1.cfg',
                'ROM_FILE'    => 'SMI810_C2_v1.rom',
                'CHIP_SELECT' => '2',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Angular_Rate_-Y',
                        'SID'          => '0x0D',
                    },
                },
            },
            '5' => {
                'DEVICE_NAME' => 'SPImonitor',
            },
        },

        'TRIGGER' => {

            # LINE_1 and LINE_2 can be OFF(Master QuaTe Default Value), POS_SLOPE, NEG_SLOPE,EXT_TRIGGER
            'LINE_1' => 'OFF',
            'LINE_2' => 'EXT_TRIGGER',
        },
    },

};

$Defaults->{'QUATE_plant'} = {

    # Master QuaTe 0
    'QUATE0' => {
        'FIRMWARE' => 'rev2_step42_v6.bit',

        #Device	Type			FP
        #0		PAS6     		1
        #1		PAS6	    	2
        #2		PAS6	        3
        #3		PAS6     		4
        #4		PAS6     		5
        #5		PAS6     		6
        #6		PAS6     		7
        #7		PAS6     		8
        #8		PAS6     		9
        #9		PAS6			10
        #10		PAS6			11
        #11		PAS6 			12
        #12		PAS6 			13
        #13		PAS6 			14
        #14		PSIMonitor

        'DEVICES' => {
            '0' => {    # 1_1
                'DEVICE_NAME' => 'UFSD',
                'ROM_FILE'    => 'PSI5Device_PAS6_no2.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'UFSD',    #channel direction
                        'SID'          => '0x10',
                    },
                },
            },
            '1' => {                                 # 1_1
                'DEVICE_NAME' => 'UFSP',
                'ROM_FILE'    => 'PSI5Device_PAS6_no2.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'UFSP',    #channel direction
                        'SID'          => '0x11',
                    },
                },
            },
            '2' => {                                 # 1_1
                'DEVICE_NAME' => 'PASFD',
                'ROM_FILE'    => 'PSI5Device_PAS6_no1.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASFD',    #channel direction
                        'SID'          => '0x09',
                    },
                },
            },
            '3' => {                                  # 1_1
                'DEVICE_NAME' => 'PASFP',
                'ROM_FILE'    => 'PSI5Device_PAS6_no1.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASFP',    #channel direction
                        'SID'          => '0x0A',
                    },
                },
            },
            '4' => {                                  # 1_2
                'DEVICE_NAME' => 'PASMD',
                'ROM_FILE'    => 'PSI5Device_PAS6_no2.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASMD',    #channel direction
                        'SID'          => '0x0B',
                    },
                },
            },
            '5' => {                                  # 1_3
                'DEVICE_NAME' => 'PASMP',
                'ROM_FILE'    => 'PSI5Device_PAS6_no2.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PASMP',    #channel direction
                        'SID'          => '0x0C',
                    },
                },
            },

            '6' => {                                  # 1_1
                'DEVICE_NAME' => 'PCSC',
                'ROM_FILE'    => 'PSI5Device_PAS6_no2.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PCSC',     #channel direction
                        'SID'          => '0x0E',
                    },
                },
            },
            '7' => {                                  # 1_1
                'DEVICE_NAME' => 'PTSD',
                'ROM_FILE'    => 'PSI5Device_PAS6_no3.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PTSD',     #channel direction
                        'SID'          => '0x0D',
                    },
                },
            },
            '8' => {                                  # 1_1
                'DEVICE_NAME' => 'PTSP',
                'ROM_FILE'    => 'PSI5Device_PAS6_no3.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PTSP',     #channel direction
                        'SID'          => '0x0F',
                    },
                },
            },

            '11' => {                                 # 1_4
                'DEVICE_NAME' => 'PPSFD',
                'ROM_FILE'    => 'PSI5Device_PAS6_no3.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PPSFD',    #channel direction
                        'SID'          => '0x05',
                    },
                },
            },
            '12' => {                                 # 2_2
                'DEVICE_NAME' => 'PPSFP',
                'ROM_FILE'    => 'PSI5Device_PAS6_no3.rom',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'PPSFP',    #channel direction
                        'SID'          => '0x06',
                    },
                },
            },
        },

        'TRIGGER' => {

            # LINE_1 and LINE_2 can be OFF(Master QuaTe Default Value), POS_SLOPE, NEG_SLOPE,EXT_TRIGGER
            'LINE_1' => 'OFF',
            'LINE_2' => 'NEG_SLOPE',
        },
    },

    # Slave QuaTe 1
    'QUATE1' => {
        #'FIRMWARE' => 'rev2_step81_v1.bit', # C0 samples of SMI8
        'FIRMWARE' => 'rev2_step82_v1.bit',  # C1 and C2 samples of SMI8

        #Device	Type		FP	used with new LVDS
        #0		SMA7xx		-	ChipSelect x - SMA760
        #1 		SMA7xx		-	ChipSelect x - SMA720
        #2		SMI8xx		-	ChipSelect x - SMI860
        #3		SMI8xx		-	ChipSelect x - SMG810
        #4		SMB470		-	-
        #5		SPIMonitor32	SPImonitorQ0

        'DEVICES' => {
            '0' => {
                'DEVICE_NAME' => 'SMA760',
                'ROM_FILE'    => 'SMA760_C0_v1.rom',
                'CHIP_SELECT' => '0',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Acc_HG_-Y',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'Acc_HG_-X',
                    },
                },
            },
            '1' => {
                'DEVICE_NAME' => 'SMA720',
                'ROM_FILE'    => 'SMA720_C0_v1.rom',
                'CHIP_SELECT' => '1',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Acc_RHG_-X',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'Acc_RHG_-Z',
                    },
                },
            },
            '2' => {
                'DEVICE_NAME' => 'SMI860',
                #'ROM_FILE'    => 'SMI860_C0_v1.rom',
                'ROM_FILE'    => 'SMI860_C2_v1.rom',
                'CHIP_SELECT' => '2',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Angular_Rate_X',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'Acc_LG_-Y',
                    },
                    '2' => {
                        'CHANNEL_NAME' => 'Acc_LG_X',
                    },
                    '3' => {
                        'CHANNEL_NAME' => 'Acc_MG_-Y',
                    },
                    '4' => {
                        'CHANNEL_NAME' => 'Acc_MG_X',
                    },
                    '5' => {
                        'CHANNEL_NAME' => 'AngularRate_-Z',
                    },
                    '6' => {
                        'CHANNEL_NAME' => 'Acc_LG_-Z',
                    },

                    '7' => {
                        'CHANNEL_NAME' => 'Acc_MG_-Z',
                    },
                },
            },
            '3' => {
                'DEVICE_NAME' => 'SMG810',
                #'ROM_FILE'    => 'SMI810_C0_v1.cfg',
                'ROM_FILE'    => 'SMI810_C2_v1.rom',
                'CHIP_SELECT' => '2',
                'CHANNELS'    => {
                    '0' => {
                        'CHANNEL_NAME' => 'Angular_Rate_-Y',
                        'SID'          => '0x0D',
                    },
                },
            },
            '5' => {
                'DEVICE_NAME' => 'SPImonitor',
            },
        },

        'TRIGGER' => {

            # LINE_1 and LINE_2 can be OFF(Master QuaTe Default Value), POS_SLOPE, NEG_SLOPE,EXT_TRIGGER
            'LINE_1' => 'OFF',
            'LINE_2' => 'EXT_TRIGGER',
        },
    },

};

1;
