#### This file has generic contents and should only be changed if the project has really different values ####

package LIFT_PROJECT;

##########################################################
$VERSION = q$Revision: 1.2 $;
$HEADER  = q$Header: config/Mapping_SAD.pm 1.2 2016/08/11 17:26:32IST Zierhut Katharina (CC-PS/EPS2) (ZIK1ABT) develop  $;
##########################################################

$Defaults->{"SAD"} = {

	'squibs' => {
		'SAD_name' => {
			'10' => 'E_MaxSquibs_SXC',
			'12' => 'rb_PSTActiveSquib_en',
			#'12' => 'rb_sycf_MaxSquibDevice_e',		# not yet in SAD file	
		},
	},
	'pases' => {
		'SAD_name' => {
			'10' => 'E_MaxPASensors_SXC',
			'12' => 'rb_psgp_SensorChannelOfSample_aen(0)',
		},
	},
	'switches' => {
		'SAD_name' => {
			'10' => 'E_MaxSwitchDevices_SXC',
			'12' => 'rb_swm_InitTestDevice_en',
		},
	},
	'lamps' => {
		'SAD_name' => {
			'10' => 'E_MaxWLDevice_SXC',
			'12' => 'AOutSysWarningIndicator',
		},
	},
	'cust' => {
		'SAD_name' => {
			'10' => 'E_MaxCustDevice_SXC',
			#'12' => '',
		},
	},
	'asics' => {
		'SAD_name' => {
			'10' => 'E_MaxAsics_SXC',
			#'12' => '',
		},
	},
	'SpBehaviour' => {
		'SAD_name' => {
			'10' => 'E_MaxSpecialBehaviours_SXC',
			#'12' => '',
		},
	},
	'parSections' => {
		'SAD_name' => {
			'10' => 'E_MaxParSections_SXC',
			#'12' => '',
		},
	},

};
1;
