package LIFT_Testbenches;

use File::Basename;
use Cwd 'abs_path';
my $PRJCFG_path = abs_path( dirname($main::opt_conf) );    #   absolute path like C:\working_somewhere\...\lift_project_config\

our $Testbench;
$Testbench = {

	'BMH1083009' => {                                      # MANITOO TESTBENCH AB12.1 RT4  () in Bie office )
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'BMH1083009',
				'Test_Bench_Number' => 43,                       #     only for logging purpose
				'Description'       => "Core Asset EDR setup",
				'CANHWSerialNo'     => 31995,
				'CANchannel'        => 2,                        # slot 2 on VN89xx Box, because FR channel does not count
				                                                 # 'POWER'             => {
				                                                 # 'Ubat' => "internal",  #  POWER Devices:: LabCar,TOE1 or IDX
				                                                 # 'UF'   => "internal",  #  POWER Devices:: LabCar,TOE1 or IDX
				                                                 # },
			},

			'PDLayer' => {                                       # example values given here
				'BusType'             => 'CANFD',                # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 1,                      # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 2892,                   # Vector hardware serial number
			},

			'Manitoo' => {
				'Connection_Type'    => 'COM5',
				'FET_HW_Type'        => 'FET_3_Ports',
				'FET_PortsSelection' => 1,
				'Description'        => "only for Manitoo testing ",    # only for logging purpose
			},
			'PeriBox' => {
				'Description'       => "Peribox Manitoo RefType4 Testbench",
				'Test_Bench_Number' => 'BMH1083009',                           # number of test bench (Laborplatz)
			},
			'PD' => {
				'Hostname'      => 'BMH1083009',
				'CANHWSerialNo' => 31995,
				'AB12'          => 1,
				'CANchannel'    => 1,
			},

			'PDLayer' => {
				'BusType'             => 'CAN',                                # possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 0,                                    #optional
				'Hw_Serial_Nbr'       => 57512,
			},

			'CD' => {
				'Hostname'      => 'BMH1083009',
				'CANHWSerialNo' => 31995,
				'AB12'          => 1,
				'CANchannel'    => 1,                                          # für 573
			},
			'QuaTe' => {
				'Controllers' => 2,                                            #   number of controllers connected
			},

			# 'CD' => {
			# 'CANchannel' => 1,
			# 'CANHWSerialNo' => 2892,
			# },
			'CANoe' => {
				'Hostname'      => 'BMH1083009',
				'Online_Config' => $PRJCFG_path . '\..\..\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'Log_File'      => $PRJCFG_path . '\..\..\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
				'ILUsed'        => 'Yes',                                                                                                 # Option : 'Yes' if Interaction layer used , otherwise 'No'
			},

		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {

			'Labcar' => {    # see documentaton of LIFT_labcar for possible devices
				'line'                  => 'TSG4',
				'power_Ubat'            => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_UF'              => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'LCT',

			},
			'Crash_simulation' => {
				'crash_database' => 'MDSRESULT',    # possible devices: MDSRESULT
				'crash_sensors'  => 'QuaTe',        # possible devices: QuaTe, IDEFIX
				'trigger'        => 'QuaTe',        # possible devices: QuaTe, IDEFIX, can_access
			},

			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'basic'     => 'CANoe',             # function groups: read, write, trace, simulation
				'stimulate' => 'CANoe',             # function groups: Stimulate signals , call CAPL
			},
			'ProdDiag' => {
				'generation' => 'AB12',
				'basic'      => 'PDLayer',
			},

			'CD' => 'CAN',                          # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices

			'NET_Access' => {
				'basic'     => 'CANoe',             # function groups: read, write, trace, simulation
				'stimulate' => 'CANoeCtrl',         # function groups: Stimulate signals ,CAPL
			},

		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'BIEZ00HL' => {    # LIFT PC host name  -  Core Asset EDR setup   (good example for TSG4+LCT with crash setup)
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'BIEZ00HL',
				'Test_Bench_Number' => 20,                                #     only for logging purpose
				'Description'       => "Core Asset EDR setup L2B-R1.4",
				'CANHWSerialNo'     => 3685,                              # 573, 2890            # 2890 -> VN1640
				'CANchannel'        => 2,                                 # 2890 -> 3  ,        # VN1640 CH4        slot 2 on VN89xx Box, because FR channel does not count
				'POWER'             => {
					'Ubat' => "internal",                                 #  POWER Devices:: LabCar,TOE1 or IDX
					'UF'   => "internal",                                 #  POWER Devices:: LabCar,TOE1 or IDX
				},
			},

			'PDLayer' => {                                                # example values given here
				'BusType'             => 'CANFD',                         # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 3,                               # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 3685,                            # Vector hardware serial number                573 ->   VN89xx Box
			},

			'CD' => {

				#'Hostname'      => 'BIEZ00HL',
				'CANHWSerialNo' => 3685,
				'CANchannel'    => 3,                                     # f�r 573
			},
			'QuaTe' => {
				'Controllers' => 2,                                       #RT4, RT3.2: 2 - RT3: 3             #   number of controllers connected
			},
			'CANoe' => {
				'Hostname'      => 'BIEZ00HL',
				'Online_Config' => $PRJCFG_path . '\..\..\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'Log_File'      => $PRJCFG_path . '\..\..\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
				'ILUsed'        => 'Yes',
			},
			'Renesas_Flash_Tool' => {
				'ECU_type'          => 'D3A',                                                  #  ECU_type can be R1L, R1L1MB, D4 or D3 or D3A
				'FlashTool_Sl_Num'  => '7CS106857C',                                           #  written on tool
				'Project_Workspace' => $PRJCFG_path . '\..\..\COMMON_config\Tools\Renesas',    # Renesas project workspace
			},
		},
		'Functions' => {
			'Labcar' => {                                                                      # see documentaton of LIFT_labcar for possible devices
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'LCT',
			},

			'ProdDiag' => {
				'generation' => 'AB12',                                                        # Airbag generation, possible values: currently 'AB12' only
				'basic'      => 'PDLayer',                                                     # Device for function group 'basic' (all functions): device currently only 'PDLayer'
			},

			'CD' => 'CAN',                                                                     # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices

			'CAN_Access' => {
				'basic'     => 'CANoe',
				'stimulate' => 'CANoe',                                                        # function groups: read, write, trace, simulation
			},

			'Crash_simulation' => {
				'crash_database' => 'MDSRESULT',                                               # possible devices: MDSRESULT
				'crash_sensors'  => 'QuaTe',                                                   # possible devices: QuaTe, IDEFIX
				'trigger'        => 'QuaTe',                                                   # possible devices: QuaTe, IDEFIX, can_access
			},

			'CREIS' => {                                                                       # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'LCT',
				},

				#				'PD' => 'PD',
				'ProdDiag' => {
					'generation' => 'AB12',                                                    # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',                                                 # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				'CD'         => 'CAN',
				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},

				#				'NET_Access' => {
				#	            	'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
				#	            	'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL
				#        		},
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',    # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',        # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',        # possible devices: QuaTe, IDEFIX, can_access
				},
			},
			'FLASH_ONLY' => {
				'Labcar' => {                           # see documentaton of LIFT_labcar for possible devices
					'line'       => 'TSG4',             # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'TSG4',             # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				},
				'ProdDiag' => {
					'generation' => 'AB12',             # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',          # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
			},
		},
	},    ## end of ~~ BIEZ00HL ~~

};
