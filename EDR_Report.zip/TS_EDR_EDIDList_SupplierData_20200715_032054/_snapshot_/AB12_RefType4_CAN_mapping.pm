### file generated with Mappingfile_Generators/CANMapping/LIFT_prepare_CAN_mapping.pl 1.9 2019/08/09 09:19:24CEST Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  
### input dbc files:
### C:/TurboLIFT/AB12/config/Tools/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc
package LIFT_PROJECT;

$Defaults->{"Mapping_CAN"} = {
'NODE_UNDER_TEST'       => 'Airbag',

'Diag_Byte_1'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_1',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'Diag_Byte_2'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_2',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_3'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_3',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_4'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_4',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_5'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_5',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_6'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_6',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_7'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_7',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_8'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_8',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'PD_req_2' =>
               {
               'SIGNAL_NAME'   => 'PD_req_2',  
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'Can_PDiag_2_ABECU',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'CAN_MESSAGES'  => {
      'EventTrigger'  =>
                      {
                        'ID'            => 7,
                        'DLC'           => 8,
                        'SENDER'        => 'TSG4',
                        'CAN_BUS_NBR'   => 2,
                      },

       'MLC_A3'  =>
                      {
                        'ID'            => 163,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A2'  =>
                      {
                        'ID'            => 162,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A1'  =>
                      {
                        'ID'            => 161,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A4'  =>
                      {
                        'ID'            => 164,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_110'  =>
                      {
                        'ID'            => 272,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_101'  =>
                      {
                        'ID'            => 257,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_102'  =>
                      {
                        'ID'            => 258,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_201'  =>
                      {
                        'ID'            => 513,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_202'  =>
                      {
                        'ID'            => 514,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },

       'EXT_PCP_MSG'  =>
                      {
                        'ID'            => 120,
                        'DLC'           => 2,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvEXT_PCP_MSGTo_' ,
                        'CANOE_DLC'     => 'EnvEXT_PCP_MSGDlc_' ,
                        'CANOE_TIMING'  => 'EnvEXT_PCP_MSGTime_' ,
                      },
       'BMI_EMN_MSG'  =>
                      {
                        'ID'            => 121,
                        'DLC'           => 2,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvBMI_EMN_MSGTo_' ,
                        'CANOE_DLC'     => 'EnvBMI_EMN_MSGDlc_' ,
                        'CANOE_TIMING'  => 'EnvBMI_EMN_MSGTime_' ,
                      },
       'ISS_Sync'  =>
                      {
                        'ID'            => 128,
                        'DLC'           => 6,
                        'SENDER'        => 'MRR',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvISS_SyncTo_' ,
                        'CANOE_DLC'     => 'EnvISS_SyncDlc_' ,
                        'CANOE_TIMING'  => 'EnvISS_SyncTime_' ,
                      },
       'IDF_01'  =>
                      {
                        'ID'            => 129,
                        'DLC'           => 8,
                        'SENDER'        => 'MRR',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvIDF_01To_' ,
                        'CANOE_DLC'     => 'EnvIDF_01Dlc_' ,
                        'CANOE_TIMING'  => 'EnvIDF_01Time_' ,
                      },
       'VDC_01'  =>
                      {
                        'ID'            => 131,
                        'DLC'           => 6,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvVDC_01To_' ,
                        'CANOE_DLC'     => 'EnvVDC_01Dlc_' ,
                        'CANOE_TIMING'  => 'EnvVDC_01Time_' ,
                      },
       'DRV_01'  =>
                      {
                        'ID'            => 132,
                        'DLC'           => 3,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvDRV_01To_' ,
                        'CANOE_DLC'     => 'EnvDRV_01Dlc_' ,
                        'CANOE_TIMING'  => 'EnvDRV_01Time_' ,
                      },
       'MSB_FD'  =>
                      {
                        'ID'            => 134,
                        'DLC'           => 1,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMSB_FDTo_' ,
                        'CANOE_DLC'     => 'EnvMSB_FDDlc_' ,
                        'CANOE_TIMING'  => 'EnvMSB_FDTime_' ,
                      },
       'MSB_FP'  =>
                      {
                        'ID'            => 135,
                        'DLC'           => 1,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMSB_FPTo_' ,
                        'CANOE_DLC'     => 'EnvMSB_FPDlc_' ,
                        'CANOE_TIMING'  => 'EnvMSB_FPTime_' ,
                      },
       'MSB_RD'  =>
                      {
                        'ID'            => 136,
                        'DLC'           => 1,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMSB_RDTo_' ,
                        'CANOE_DLC'     => 'EnvMSB_RDDlc_' ,
                        'CANOE_TIMING'  => 'EnvMSB_RDTime_' ,
                      },
       'MSB_RC'  =>
                      {
                        'ID'            => 137,
                        'DLC'           => 1,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMSB_RCTo_' ,
                        'CANOE_DLC'     => 'EnvMSB_RCDlc_' ,
                        'CANOE_TIMING'  => 'EnvMSB_RCTime_' ,
                      },
       'MSB_RP'  =>
                      {
                        'ID'            => 144,
                        'DLC'           => 1,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMSB_RPTo_' ,
                        'CANOE_DLC'     => 'EnvMSB_RPDlc_' ,
                        'CANOE_TIMING'  => 'EnvMSB_RPTime_' ,
                      },
       'GGCC'  =>
                      {
                        'ID'            => 256,
                        'DLC'           => 8,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 400,
                        'CANOE_DISABLE' => 'EnvGGCCTo_' ,
                        'CANOE_DLC'     => 'EnvGGCCDlc_' ,
                        'CANOE_TIMING'  => 'EnvGGCCTime_' ,
                      },
       'Veh_Speed_dashboard'  =>
                      {
                        'ID'            => 512,
                        'DLC'           => 4,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'LIFT_CAN_access::SysVar_VehicleSpeedDashboard_timeout' ,
                        'CANOE_DLC'     => 'LIFT_CAN_access::SysVar_VehicleSpeedDashboard_dlc',
                        'CANOE_TIMING'  => 'LIFT_CAN_access::SysVar_VehicleSpeedDashboard_timeout' ,
                      },
       'EdrData_01'  =>
                      {
                        'ID'            => 768,
                        'DLC'           => 8,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'LIFT_CAN_access::SysVar_EdrData_01_timeout' ,
                        'CANOE_DLC'     => 'LIFT_CAN_access::SysVar_EdrData_01_dlc' ,
                        'CANOE_TIMING'  => 'LIFT_CAN_access::SysVar_EdrData_01_timeout' ,
                      },
       'EdrData_02'  =>
                      {
                        'ID'            => 769,
                        'DLC'           => 8,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'LIFT_CAN_access::SysVar_EdrData_02_timeout' ,
                        'CANOE_DLC'     => 'LIFT_CAN_access::SysVar_EdrData_02_dlc' ,
                        'CANOE_TIMING'  => 'LIFT_CAN_access::SysVar_EdrData_02_timeout' ,
                      },
       'EdrData_03'  =>
                      {
                        'ID'            => 770,
                        'DLC'           => 4,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'LIFT_CAN_access::SysVar_EdrData_03_timeout' ,
                        'CANOE_DLC'     => 'LIFT_CAN_access::SysVar_EdrData_03_dlc' ,
                        'CANOE_TIMING'  => 'LIFT_CAN_access::SysVar_EdrData_03_timeout' ,
                      },
		'EdrData_04'  =>
                      {
                        'ID'            => 771,
                        'DLC'           => 5,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'LIFT_CAN_access::SysVar_EdrData_04_timeout' ,
                        'CANOE_DLC'     => 'LIFT_CAN_access::SysVar_EdrData_04_dlc' ,
                        'CANOE_TIMING'  => 'LIFT_CAN_access::SysVar_EdrData_04_timeout' ,
                      },
       'Airbag01'  =>
                      {
                        'ID'            => 1024,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvAirbag01To_' ,
                        'CANOE_DLC'     => 'EnvAirbag01Dlc_' ,
                        'CANOE_TIMING'  => 'EnvAirbag01Time_' ,
                      },
       'Airbag_MSB'  =>
                      {
                        'ID'            => 1026,
                        'DLC'           => 3,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvAirbag_MSBTo_' ,
                        'CANOE_DLC'     => 'EnvAirbag_MSBDlc_' ,
                        'CANOE_TIMING'  => 'EnvAirbag_MSBTime_' ,
                      },
       'CustDiag_Physical_Response'  =>
                      {
                        'ID'            => 1276,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvCustDiag_Physical_ResponseTo_' ,
                        'CANOE_DLC'     => 'EnvCustDiag_Physical_ResponseDlc_' ,
                        'CANOE_TIMING'  => 'EnvCustDiag_Physical_ResponseTime_' ,
                      },
       'FLM_env_data'  =>
                      {
                        'ID'            => 1280,
                        'DLC'           => 3,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 1000,
                        'CANOE_DISABLE' => 'EnvFLM_env_dataTo_' ,
                        'CANOE_DLC'     => 'EnvFLM_env_dataDlc_' ,
                        'CANOE_TIMING'  => 'EnvFLM_env_dataTime_' ,
                      },
       'Temperature'  =>
                      {
                        'ID'            => 1296,
                        'DLC'           => 8,
                        'SENDER'        => 'Other_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 200,
                        'CANOE_DISABLE' => 'EnvTemperatureTo_' ,
                        'CANOE_DLC'     => 'EnvTemperatureDlc_' ,
                        'CANOE_TIMING'  => 'EnvTemperatureTime_' ,
                      },
       'Sensordata'  =>
                      {
                        'ID'            => 1536,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvSensordataTo_' ,
                        'CANOE_DLC'     => 'EnvSensordataDlc_' ,
                        'CANOE_TIMING'  => 'EnvSensordataTime_' ,
                      },
       'ProDiag_Request'  =>
                      {
                        'ID'            => 1616,
                        'DLC'           => 8,
                        'SENDER'        => 'Tester',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvProDiag_RequestTo_' ,
                        'CANOE_DLC'     => 'EnvProDiag_RequestDlc_' ,
                        'CANOE_TIMING'  => 'EnvProDiag_RequestTime_' ,
                      },
       'ProDiag_Response1'  =>
                      {
                        'ID'            => 1617,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvProDiag_Response1To_' ,
                        'CANOE_DLC'     => 'EnvProDiag_Response1Dlc_' ,
                        'CANOE_TIMING'  => 'EnvProDiag_Response1Time_' ,
                      },
       'ProDiag_Response2'  =>
                      {
                        'ID'            => 1618,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvProDiag_Response2To_' ,
                        'CANOE_DLC'     => 'EnvProDiag_Response2Dlc_' ,
                        'CANOE_TIMING'  => 'EnvProDiag_Response2Time_' ,
                      },
       'ProDiag_Response3'  =>
                      {
                        'ID'            => 1619,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvProDiag_Response3To_' ,
                        'CANOE_DLC'     => 'EnvProDiag_Response3Dlc_' ,
                        'CANOE_TIMING'  => 'EnvProDiag_Response3Time_' ,
                      },
       'ProDiag_Response4'  =>
                      {
                        'ID'            => 1620,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvProDiag_Response4To_' ,
                        'CANOE_DLC'     => 'EnvProDiag_Response4Dlc_' ,
                        'CANOE_TIMING'  => 'EnvProDiag_Response4Time_' ,
                      },
       'PrdFastDiagRespViaCANFD1'  =>
                      {
                        'ID'            => 1621,
                        'DLC'           => 1,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvPrdFastDiagRespViaCANFD1To_' ,
                        'CANOE_DLC'     => 'EnvPrdFastDiagRespViaCANFD1Dlc_' ,
                        'CANOE_TIMING'  => 'EnvPrdFastDiagRespViaCANFD1Time_' ,
                      },
       'PrdFastDiagRespViaCANFD2'  =>
                      {
                        'ID'            => 1622,
                        'DLC'           => 1,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvPrdFastDiagRespViaCANFD2To_' ,
                        'CANOE_DLC'     => 'EnvPrdFastDiagRespViaCANFD2Dlc_' ,
                        'CANOE_TIMING'  => 'EnvPrdFastDiagRespViaCANFD2Time_' ,
                      },
       'CustDiag_Physical_Request'  =>
                      {
                        'ID'            => 1756,
                        'DLC'           => 8,
                        'SENDER'        => 'Tester',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvCustDiag_Physical_RequestTo_' ,
                        'CANOE_DLC'     => 'EnvCustDiag_Physical_RequestDlc_' ,
                        'CANOE_TIMING'  => 'EnvCustDiag_Physical_RequestTime_' ,
                      },
       'CustDiag_Functional_Request'  =>
                      {
                        'ID'            => 1772,
                        'DLC'           => 8,
                        'SENDER'        => 'Tester',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 200,
                        'CANOE_DISABLE' => 'EnvCustDiag_Functional_RequestTo_' ,
                        'CANOE_DLC'     => 'EnvCustDiag_Functional_RequestDlc_' ,
                        'CANOE_TIMING'  => 'EnvCustDiag_Functional_RequestTime_' ,
                      },
       'CANFDTestRx01'  =>
                      {
                        'ID'            => 1809,
                        'DLC'           => 64,
                        'SENDER'        => 'Other_ECU', #'Vector__XXX',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'EnvCANFDTestRx01To_' ,
                        'CANOE_DLC'     => 'EnvCANFDTestRx01Dlc_' ,
                        'CANOE_TIMING'  => 'EnvCANFDTestRx01Time_' ,
                      },
       'CANFDTestTx01'  =>
                      {
                        'ID'            => 1810,
                        'DLC'           => 64,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'EnvCANFDTestTx01To_' ,
                        'CANOE_DLC'     => 'EnvCANFDTestTx01Dlc_' ,
                        'CANOE_TIMING'  => 'EnvCANFDTestTx01Time_' ,
                      },
       'VDS_Sensordata'  =>
                      {
                        'ID'            => 1811,
                        'DLC'           => 16,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvVDS_SensordataTo_' ,
                        'CANOE_DLC'     => 'EnvVDS_SensordataDlc_' ,
                        'CANOE_TIMING'  => 'EnvVDS_SensordataTime_' ,
                      },
       'IsoDisp_Physical_Request'  =>
                      {
                        'ID'            => 2033,
                        'DLC'           => 8,
                        'SENDER'        => 'Tester',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvIsoDisp_Physical_RequestTo_' ,
                        'CANOE_DLC'     => 'EnvIsoDisp_Physical_RequestDlc_' ,
                        'CANOE_TIMING'  => 'EnvIsoDisp_Physical_RequestTime_' ,
                      },
       'IsoDisp_Physical_Response'  =>
                      {
                        'ID'            => 2041,
                        'DLC'           => 8,
                        'SENDER'        => 'AB_ECU',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvIsoDisp_Physical_ResponseTo_' ,
                        'CANOE_DLC'     => 'EnvIsoDisp_Physical_ResponseDlc_' ,
                        'CANOE_TIMING'  => 'EnvIsoDisp_Physical_ResponseTime_' ,
                      },
       'VECTOR__INDEPENDENT_SIG_MSG'  =>
                      {
                        'ID'            => 3221225472,
                        'DLC'           => 0,
                        'SENDER'        => 'Vector__XXX',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvVECTOR__INDEPENDENT_SIG_MSGTo_' ,
                        'CANOE_DLC'     => 'EnvVECTOR__INDEPENDENT_SIG_MSGDlc_' ,
                        'CANOE_TIMING'  => 'EnvVECTOR__INDEPENDENT_SIG_MSGTime_' ,
                      },
           },

############################################# 

## --- Signal List (msg by msg , IDs ascending) of System under Test node 

############################################# 

## Signal List (msg by msg , IDs ascending) from Simulator 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: EXT_PCP_MSG (Other_ECU) ID: 120 (0x78), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'EXT_MSB_BeltJerk_ExtReq' =>
               {
               'SIGNAL_NAME'   => 'EXT_MSB_BeltJerk_ExtReq',      'CANOE_ENV_VAR' => 'EnvEXT_MSB_BeltJerk_ExtReq_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 5, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_MSB_BeltJerk_ExtReq.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_MSB_BeltJerk_ExtReq.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00100000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_MSB_FullTensing_ExtReq' =>
               {
               'SIGNAL_NAME'   => 'EXT_MSB_FullTensing_ExtReq',      'CANOE_ENV_VAR' => 'EnvEXT_MSB_FullTensing_ExtReq_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_MSB_FullTensing_ExtReq.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_MSB_FullTensing_ExtReq.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_MSB_PartialTensing_ExtReq' =>
               {
               'SIGNAL_NAME'   => 'EXT_MSB_PartialTensing_ExtReq',      'CANOE_ENV_VAR' => 'EnvEXT_MSB_PartialTensing_ExtReq_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 6, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_MSB_PartialTensing_ExtReq.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_MSB_PartialTensing_ExtReq.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b01000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_PCP_AEB_Enable' =>
               {
               'SIGNAL_NAME'   => 'EXT_PCP_AEB_Enable',      'CANOE_ENV_VAR' => 'EnvEXT_PCP_AEB_Enable_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_PCP_AEB_Enable.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_PCP_AEB_Enable.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00000001' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_PCP_BSR_Enable' =>
               {
               'SIGNAL_NAME'   => 'EXT_PCP_BSR_Enable',      'CANOE_ENV_VAR' => 'EnvEXT_PCP_BSR_Enable_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 9, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_PCP_BSR_Enable.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_PCP_BSR_Enable.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00000010' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_PCP_EBEnable' =>
               {
               'SIGNAL_NAME'   => 'EXT_PCP_EBEnable',      'CANOE_ENV_VAR' => 'EnvEXT_PCP_EBEnable_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 11, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_PCP_EBEnable.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_PCP_EBEnable.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00001000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_PCP_Enable' =>
               {
               'SIGNAL_NAME'   => 'EXT_PCP_Enable',      'CANOE_ENV_VAR' => 'EnvEXT_PCP_Enable_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 12, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_PCP_Enable.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_PCP_Enable.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00010000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_PCP_PCWEnable' =>
               {
               'SIGNAL_NAME'   => 'EXT_PCP_PCWEnable',      'CANOE_ENV_VAR' => 'EnvEXT_PCP_PCWEnable_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 13, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_PCP_PCWEnable.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_PCP_PCWEnable.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00100000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EXT_PCP_SBEnable' =>
               {
               'SIGNAL_NAME'   => 'EXT_PCP_SBEnable',      'CANOE_ENV_VAR' => 'EnvEXT_PCP_SBEnable_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EXT_PCP_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 10, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EXT_PCP_SBEnable.EXT_PCP_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EXT_PCP_SBEnable.EXT_PCP_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00000100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: BMI_EMN_MSG (Other_ECU) ID: 121 (0x79), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'BMI_AEB_Expected' =>
               {
               'SIGNAL_NAME'   => 'BMI_AEB_Expected',      'CANOE_ENV_VAR' => 'EnvBMI_AEB_Expected_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'BMI_EMN_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 6, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'BMI_AEB_Expected.BMI_EMN_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'BMI_AEB_Expected.BMI_EMN_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b01000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'BMI_AEB_State' =>
               {
               'SIGNAL_NAME'   => 'BMI_AEB_State',      'CANOE_ENV_VAR' => 'EnvBMI_AEB_State_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'BMI_EMN_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 4, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'BMI_AEB_State.BMI_EMN_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'BMI_AEB_State.BMI_EMN_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00011000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'BMI_BeltJerk' =>
               {
               'SIGNAL_NAME'   => 'BMI_BeltJerk',      'CANOE_ENV_VAR' => 'EnvBMI_BeltJerk_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'BMI_EMN_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'BMI_BeltJerk.BMI_EMN_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'BMI_BeltJerk.BMI_EMN_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: ISS_Sync (MRR) ID: 128 (0x80), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'ISS_Sync_CRC' =>
               {
               'SIGNAL_NAME'   => 'ISS_Sync_CRC',      'CANOE_ENV_VAR' => 'EnvISS_Sync_CRC_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'ISS_Sync',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ISS_Sync_CRC.ISS_Sync.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ISS_Sync_CRC.ISS_Sync.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ISS_Sync_PDU_Type' =>
               {
               'SIGNAL_NAME'   => 'ISS_Sync_PDU_Type',      'CANOE_ENV_VAR' => 'EnvISS_Sync_PDU_Type_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'ISS_Sync',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 4, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ISS_Sync_PDU_Type.ISS_Sync.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ISS_Sync_PDU_Type.ISS_Sync.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ISS_Sync_SeqID' =>
               {
               'SIGNAL_NAME'   => 'ISS_Sync_SeqID',      'CANOE_ENV_VAR' => 'EnvISS_Sync_SeqID_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'ISS_Sync',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 12, 'LENGTH' => 4, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ISS_Sync_SeqID.ISS_Sync.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ISS_Sync_SeqID.ISS_Sync.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11110000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ISS_Sync_Sync_TimeStamp' =>
               {
               'SIGNAL_NAME'   => 'ISS_Sync_Sync_TimeStamp',      'CANOE_ENV_VAR' => 'EnvISS_Sync_Sync_TimeStamp_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'ISS_Sync',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 32, 'OFFSET' => 0.000000, 'FACTOR' => 10.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'Unit_�s',
               'LC_READ_PHYS'  => 'ISS_Sync_Sync_TimeStamp.ISS_Sync.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ISS_Sync_Sync_TimeStamp.ISS_Sync.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: IDF_01 (MRR) ID: 129 (0x81), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'IDF_01_AEB_Flag' =>
               {
               'SIGNAL_NAME'   => 'IDF_01_AEB_Flag',      'CANOE_ENV_VAR' => 'EnvIDF_01_AEB_Flag_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'IDF_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 58, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IDF_01_AEB_Flag.IDF_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IDF_01_AEB_Flag.IDF_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b00001100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IDF_01_Closing_Velocity' =>
               {
               'SIGNAL_NAME'   => 'IDF_01_Closing_Velocity',      'CANOE_ENV_VAR' => 'EnvIDF_01_Closing_Velocity_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'IDF_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 24, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 0.167000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'Unit_m/s',
               'LC_READ_PHYS'  => 'IDF_01_Closing_Velocity.IDF_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IDF_01_Closing_Velocity.IDF_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IDF_01_Object_Class' =>
               {
               'SIGNAL_NAME'   => 'IDF_01_Object_Class',      'CANOE_ENV_VAR' => 'EnvIDF_01_Object_Class_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'IDF_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 12, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IDF_01_Object_Class.IDF_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IDF_01_Object_Class.IDF_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b01110000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IDF_01_TTI_TimeStamp' =>
               {
               'SIGNAL_NAME'   => 'IDF_01_TTI_TimeStamp',      'CANOE_ENV_VAR' => 'EnvIDF_01_TTI_TimeStamp_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'IDF_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 32, 'LENGTH' => 26, 'OFFSET' => 0.000000, 'FACTOR' => 0.001000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'Unit_s',
               'LC_READ_PHYS'  => 'IDF_01_TTI_TimeStamp.IDF_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IDF_01_TTI_TimeStamp.IDF_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b00000011' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IDF_01_Time_to_Impact' =>
               {
               'SIGNAL_NAME'   => 'IDF_01_Time_to_Impact',      'CANOE_ENV_VAR' => 'EnvIDF_01_Time_to_Impact_',
               'SENDER'        => 'MRR',
               'MESSAGE'       => 'IDF_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 0.004000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'Unit_s',
               'LC_READ_PHYS'  => 'IDF_01_Time_to_Impact.IDF_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IDF_01_Time_to_Impact.IDF_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: VDC_01 (Other_ECU) ID: 131 (0x83), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'VDC_AccLateral' =>
               {
               'SIGNAL_NAME'   => 'VDC_AccLateral',      'CANOE_ENV_VAR' => 'EnvVDC_AccLateral_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 1, 'LENGTH' => 10, 'OFFSET' => 0.000000, 'FACTOR' => 0.047852,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => 'mps2',
               'LC_READ_PHYS'  => 'VDC_AccLateral.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_AccLateral.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000011' , 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_AccLateralStatus' =>
               {
               'SIGNAL_NAME'   => 'VDC_AccLateralStatus',      'CANOE_ENV_VAR' => 'EnvVDC_AccLateralStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDC_AccLateralStatus.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_AccLateralStatus.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_AccLongitudinal' =>
               {
               'SIGNAL_NAME'   => 'VDC_AccLongitudinal',      'CANOE_ENV_VAR' => 'EnvVDC_AccLongitudinal_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 10, 'OFFSET' => 0.000000, 'FACTOR' => 0.047852,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => 'mps2',
               'LC_READ_PHYS'  => 'VDC_AccLongitudinal.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_AccLongitudinal.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' , 3 => '0b11000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_AccLongitudinalStatus' =>
               {
               'SIGNAL_NAME'   => 'VDC_AccLongitudinalStatus',      'CANOE_ENV_VAR' => 'EnvVDC_AccLongitudinalStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 6, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDC_AccLongitudinalStatus.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_AccLongitudinalStatus.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b01000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_Intervention' =>
               {
               'SIGNAL_NAME'   => 'VDC_Intervention',      'CANOE_ENV_VAR' => 'EnvVDC_Intervention_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 4, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDC_Intervention.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_Intervention.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00010000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_MCPressure' =>
               {
               'SIGNAL_NAME'   => 'VDC_MCPressure',      'CANOE_ENV_VAR' => 'EnvVDC_MCPressure_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 35, 'LENGTH' => 12, 'OFFSET' => 46626.160000, 'FACTOR' => 23.960000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => 'kPa',
               'LC_READ_PHYS'  => 'VDC_MCPressure.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_MCPressure.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b00001111' , 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_MCPressureStatus' =>
               {
               'SIGNAL_NAME'   => 'VDC_MCPressureStatus',      'CANOE_ENV_VAR' => 'EnvVDC_MCPressureStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 3, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDC_MCPressureStatus.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_MCPressureStatus.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00001000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_YawRate' =>
               {
               'SIGNAL_NAME'   => 'VDC_YawRate',      'CANOE_ENV_VAR' => 'EnvVDC_YawRate_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 29, 'LENGTH' => 10, 'OFFSET' => 0.000000, 'FACTOR' => 0.244141,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '�/s',
               'LC_READ_PHYS'  => 'VDC_YawRate.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_YawRate.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b00111111' , 4 => '0b11110000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDC_YawRateStatus' =>
               {
               'SIGNAL_NAME'   => 'VDC_YawRateStatus',      'CANOE_ENV_VAR' => 'EnvVDC_YawRateStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'VDC_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 2, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDC_YawRateStatus.VDC_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDC_YawRateStatus.VDC_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: DRV_01 (Other_ECU) ID: 132 (0x84), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'DRV_AccPedalPosition' =>
               {
               'SIGNAL_NAME'   => 'DRV_AccPedalPosition',      'CANOE_ENV_VAR' => 'EnvDRV_AccPedalPosition_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'DRV_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 0.392157,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '%',
               'LC_READ_PHYS'  => 'DRV_AccPedalPosition.DRV_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'DRV_AccPedalPosition.DRV_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00000001' , 2 => '0b11111110' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'DRV_AccPedalPositionStatus' =>
               {
               'SIGNAL_NAME'   => 'DRV_AccPedalPositionStatus',      'CANOE_ENV_VAR' => 'EnvDRV_AccPedalPositionStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'DRV_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 4, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'DRV_AccPedalPositionStatus.DRV_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'DRV_AccPedalPositionStatus.DRV_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00010000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'DRV_BrakePedalPosition' =>
               {
               'SIGNAL_NAME'   => 'DRV_BrakePedalPosition',      'CANOE_ENV_VAR' => 'EnvDRV_BrakePedalPosition_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'DRV_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 0.392157,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '%',
               'LC_READ_PHYS'  => 'DRV_BrakePedalPosition.DRV_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'DRV_BrakePedalPosition.DRV_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000001' , 1 => '0b11111110' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'DRV_BrakePedalPositionStatus' =>
               {
               'SIGNAL_NAME'   => 'DRV_BrakePedalPositionStatus',      'CANOE_ENV_VAR' => 'EnvDRV_BrakePedalPositionStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'DRV_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 3, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'DRV_BrakePedalPositionStatus.DRV_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'DRV_BrakePedalPositionStatus.DRV_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00001000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MSB_FD (Other_ECU) ID: 134 (0x86), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'MSB_FD_Status' =>
               {
               'SIGNAL_NAME'   => 'MSB_FD_Status',      'CANOE_ENV_VAR' => 'EnvMSB_FD_Status_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'MSB_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'MSB_FD_Status.MSB_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'MSB_FD_Status.MSB_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MSB_FP (Other_ECU) ID: 135 (0x87), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'MSB_FP_Status' =>
               {
               'SIGNAL_NAME'   => 'MSB_FP_Status',      'CANOE_ENV_VAR' => 'EnvMSB_FP_Status_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'MSB_FP',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'MSB_FP_Status.MSB_FP.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'MSB_FP_Status.MSB_FP.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MSB_RD (Other_ECU) ID: 136 (0x88), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'MSB_RD_Status' =>
               {
               'SIGNAL_NAME'   => 'MSB_RD_Status',      'CANOE_ENV_VAR' => 'EnvMSB_RD_Status_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'MSB_RD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'MSB_RD_Status.MSB_RD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'MSB_RD_Status.MSB_RD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MSB_RC (Other_ECU) ID: 137 (0x89), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Status_MSB_RC' =>
               {
               'SIGNAL_NAME'   => 'Status_MSB_RC',      'CANOE_ENV_VAR' => 'EnvStatus_MSB_RC_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'MSB_RC',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Status_MSB_RC.MSB_RC.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Status_MSB_RC.MSB_RC.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MSB_RP (Other_ECU) ID: 144 (0x90), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'MSB_RP_Status' =>
               {
               'SIGNAL_NAME'   => 'MSB_RP_Status',      'CANOE_ENV_VAR' => 'EnvMSB_RP_Status_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'MSB_RP',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'MSB_RP_Status.MSB_RP.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'MSB_RP_Status.MSB_RP.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: GGCC (Other_ECU) ID: 256 (0x100), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'GGCC_Id' =>
               {
               'SIGNAL_NAME'   => 'GGCC_Id',      'CANOE_ENV_VAR' => 'EnvGGCC_Id_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'GGCC',
               'MULTIPLEX'     => { 'MASTER' => 'GGCC_Id' },
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'GGCC_Id.GGCC.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'GGCC_Id.GGCC.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'GGCC_VinHigh' =>
               {
               'SIGNAL_NAME'   => 'GGCC_VinHigh',      'CANOE_ENV_VAR' => 'EnvGGCC_VinHigh_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'GGCC',
               'MULTIPLEX'     => { 'MASTER' => 'GGCC_Id' , 'CODE' => 0 },
               'STARTBIT'      => 15, 'LENGTH' => 56, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'GGCC_VinHigh.GGCC.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'GGCC_VinHigh.GGCC.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'GGCC_VinLow' =>
               {
               'SIGNAL_NAME'   => 'GGCC_VinLow',      'CANOE_ENV_VAR' => 'EnvGGCC_VinLow_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'GGCC',
               'MULTIPLEX'     => { 'MASTER' => 'GGCC_Id' , 'CODE' => 2 },
               'STARTBIT'      => 15, 'LENGTH' => 24, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'GGCC_VinLow.GGCC.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'GGCC_VinLow.GGCC.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'GGCC_VinMid' =>
               {
               'SIGNAL_NAME'   => 'GGCC_VinMid',      'CANOE_ENV_VAR' => 'EnvGGCC_VinMid_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'GGCC',
               'MULTIPLEX'     => { 'MASTER' => 'GGCC_Id' , 'CODE' => 1 },
               'STARTBIT'      => 15, 'LENGTH' => 56, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'GGCC_VinMid.GGCC.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'GGCC_VinMid.GGCC.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Veh_Speed_dashboard (Other_ECU) ID: 512 (0x200), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'VSD_ESPReferenceVelocity' =>
               {
               'SIGNAL_NAME'   => 'VSD_ESPReferenceVelocity',      'CANOE_ENV_VAR' => 'EnvVSD_ESPReferenceVelocity_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'Veh_Speed_dashboard',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 10, 'LENGTH' => 11, 'OFFSET' => 0.000000, 'FACTOR' => 0.125000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => 'kph',
               'LC_READ_PHYS'  => 'VSD_ESPReferenceVelocity.Veh_Speed_dashboard.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VSD_ESPReferenceVelocity.Veh_Speed_dashboard.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00000111' , 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => {
									  'Min' => 0,
									  'Max' => 255,
									  'Min_Value' => 0,
									  'Max_Value' => 255, # max value EDR
									  'RandomInRange' => 10,
									  'FAULTY' => '255.5',
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 },
               },

'VSD_ESPReferenceVelocityStatus' =>
               {
               'SIGNAL_NAME'   => 'VSD_ESPReferenceVelocityStatus',      'CANOE_ENV_VAR' => 'EnvVSD_ESPReferenceVelocityStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'Veh_Speed_dashboard',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 27, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VSD_ESPReferenceVelocityStatus.Veh_Speed_dashboard.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VSD_ESPReferenceVelocityStatus.Veh_Speed_dashboard.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b00001000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VSD_VehDrivingDirection' =>
               {
               'SIGNAL_NAME'   => 'VSD_VehDrivingDirection',      'CANOE_ENV_VAR' => 'EnvVSD_VehDrivingDirection_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'Veh_Speed_dashboard',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 29, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VSD_VehDrivingDirection.Veh_Speed_dashboard.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VSD_VehDrivingDirection.Veh_Speed_dashboard.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b00110000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: EdrData_01 (Other_ECU) ID: 768 (0x300), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Edr_ABSActivity' =>
               {
               'SIGNAL_NAME'   => 'Edr_ABSActivity',      'CANOE_ENV_VAR' => 'EnvEdr_ABSActivity_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_ABSActivity.EdrData_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_ABSActivity.EdrData_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => { 'DefaultValue' => '0',
			   						   'FAULTY'       => 254, #check with value 2	
			   						  'Min_Value' => 0,
									  'Max_Value' => 2,
									  'RandomInRange' => 1,
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',		   						 
			                       },
               },

'Edr_AcceleratorPedal' =>
               {
               'SIGNAL_NAME'   => 'Edr_AcceleratorPedal',      'CANOE_ENV_VAR' => 'EnvEdr_AcceleratorPedal_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '%',
               'LC_READ_PHYS'  => 'Edr_AcceleratorPedal.EdrData_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AcceleratorPedal.EdrData_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 100,
									  'RandomInRange' => 10,
									  'FAULTY' => '101',
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 },
               },

'Edr_EngineRpm' =>
               {
               'SIGNAL_NAME'   => 'Edr_EngineRpm',      'CANOE_ENV_VAR' => 'EnvEdr_EngineRpm_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 64.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => 'rpm',
               'LC_READ_PHYS'  => 'Edr_EngineRpm.EdrData_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_EngineRpm.EdrData_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 10048,
									  'RandomInRange' => 1,
									  'FAULTY' => '10112', # 10049
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 }, 
               },

'Edr_GearPosition' =>
               {
               'SIGNAL_NAME'   => 'Edr_GearPosition',      'CANOE_ENV_VAR' => 'EnvEdr_GearPosition_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_GearPosition.EdrData_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_GearPosition.EdrData_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 3,
									  'RandomInRange' => 2,
									  'FAULTY' => '8',
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 },

               },

'Edr_ServiceBrakeActivation' =>
               {
               'SIGNAL_NAME'   => 'Edr_ServiceBrakeActivation',      'CANOE_ENV_VAR' => 'EnvEdr_ServiceBrakeActivation_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_ServiceBrakeActivation.EdrData_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_ServiceBrakeActivation.EdrData_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '2',
			                        },
               },

'Edr_StabilityControl' =>
               {
               'SIGNAL_NAME'   => 'Edr_StabilityControl',      'CANOE_ENV_VAR' => 'EnvEdr_StabilityControl_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_StabilityControl.EdrData_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_StabilityControl.EdrData_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '254', # check with value 3
			   						  'Min_Value' => 0, # -250
									  'Max_Value' => 253, #250
			                        },
               },

'Edr_SteeringInput' =>
               {
               'SIGNAL_NAME'   => 'Edr_SteeringInput',      'CANOE_ENV_VAR' => 'EnvEdr_SteeringInput_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 16, 'OFFSET' => -819.100000, 'FACTOR' => 0.100000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => 'deg',
               'LC_READ_PHYS'  => 'Edr_SteeringInput.EdrData_01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_SteeringInput.EdrData_01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' , 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               'DataValueTable' => {
									  'Min_Value' => -780, # -250
									  'Max_Value' => 780, #250
									  'RandomInRange' => 100,
									  'FAULTY' => '820', #1070
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 },
              
               },
# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: EdrData_02 (Other_ECU) ID: 769 (0x301), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Edr_AccidentDay' =>
               {
               'SIGNAL_NAME'   => 'Edr_AccidentDay',      'CANOE_ENV_VAR' => 'EnvEdr_AccidentDay_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_02',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 21, 'LENGTH' => 6, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AccidentDay.EdrData_02.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AccidentDay.EdrData_02.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b00111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Edr_AccidentHour' =>
               {
               'SIGNAL_NAME'   => 'Edr_AccidentHour',      'CANOE_ENV_VAR' => 'EnvEdr_AccidentHour_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_02',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 28, 'LENGTH' => 5, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AccidentHour.EdrData_02.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AccidentHour.EdrData_02.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b00011111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Edr_AccidentMilliSecond' =>
               {
               'SIGNAL_NAME'   => 'Edr_AccidentMilliSecond',      'CANOE_ENV_VAR' => 'EnvEdr_AccidentMilliSecond_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_02',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 10, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => 'ms',
               'LC_READ_PHYS'  => 'Edr_AccidentMilliSecond.EdrData_02.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AccidentMilliSecond.EdrData_02.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' , 7 => '0b11000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Edr_AccidentMinute' =>
               {
               'SIGNAL_NAME'   => 'Edr_AccidentMinute',      'CANOE_ENV_VAR' => 'EnvEdr_AccidentMinute_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_02',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 37, 'LENGTH' => 6, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AccidentMinute.EdrData_02.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AccidentMinute.EdrData_02.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b00111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Edr_AccidentMonth' =>
               {
               'SIGNAL_NAME'   => 'Edr_AccidentMonth',      'CANOE_ENV_VAR' => 'EnvEdr_AccidentMonth_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_02',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 11, 'LENGTH' => 4, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AccidentMonth.EdrData_02.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AccidentMonth.EdrData_02.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Edr_AccidentSecond' =>
               {
               'SIGNAL_NAME'   => 'Edr_AccidentSecond',      'CANOE_ENV_VAR' => 'EnvEdr_AccidentSecond_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_02',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 45, 'LENGTH' => 6, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AccidentSecond.EdrData_02.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AccidentSecond.EdrData_02.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b00111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Edr_AccidentYear' =>
               {
               'SIGNAL_NAME'   => 'Edr_AccidentYear',      'CANOE_ENV_VAR' => 'EnvEdr_AccidentYear_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_02',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AccidentYear.EdrData_02.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AccidentYear.EdrData_02.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: EdrData_03 (Other_ECU) ID: 770 (0x302), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Edr_AEBStatus' =>
               {
               'SIGNAL_NAME'   => 'Edr_AEBStatus',      'CANOE_ENV_VAR' => 'EnvEdr_AEBStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_03',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AEBStatus.EdrData_03.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AEBStatus.EdrData_03.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
				'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '254', #check with value 3
			   						  'Min_Value' => 0,
									  'Max_Value' => 253,
			                        },
               },

'Edr_AdaptiveCruiseControl' =>
               {
               'SIGNAL_NAME'   => 'Edr_AdaptiveCruiseControl',      'CANOE_ENV_VAR' => 'EnvEdr_AdaptiveCruiseControl_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_03',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 14, 'LENGTH' => 4, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_AdaptiveCruiseControl.EdrData_03.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_AdaptiveCruiseControl.EdrData_03.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b01111000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
				'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 3,
									  'RandomInRange' => 1,
									  'FAULTY' => '8',									  
									  'DefaultValue' => '0',
									 },
               },

'Edr_CCSStatus' =>
               {
               'SIGNAL_NAME'   => 'Edr_CCSStatus',      'CANOE_ENV_VAR' => 'EnvEdr_CCSStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_03',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 10, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_CCSStatus.EdrData_03.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_CCSStatus.EdrData_03.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00000111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
                'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 4,
									  'RandomInRange' => 2,
									  'FAULTY' => '5',									  
									  'DefaultValue' => '0',
									 },
               },

'Edr_PressureMonLampStatus' =>
               {
               'SIGNAL_NAME'   => 'Edr_PressureMonLampStatus',      'CANOE_ENV_VAR' => 'EnvEdr_PressureMonLampStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_03',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_PressureMonLampStatus.EdrData_03.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_PressureMonLampStatus.EdrData_03.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
				'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '2',
			                        },
               },

'Edr_ThrottlePedalPosition' =>
               {
               'SIGNAL_NAME'   => 'Edr_ThrottlePedalPosition',      'CANOE_ENV_VAR' => 'EnvEdr_ThrottlePedalPosition_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_03',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '%',
               'LC_READ_PHYS'  => 'Edr_ThrottlePedalPosition.EdrData_03.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_ThrottlePedalPosition.EdrData_03.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 100,
									  'RandomInRange' => 10,
									  'FAULTY' => '101',
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 },
               },

'Edr_TractionCtlSysStatus' =>
               {
               'SIGNAL_NAME'   => 'Edr_TractionCtlSysStatus',      'CANOE_ENV_VAR' => 'EnvEdr_TractionCtlSysStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_03',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 20, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_TractionCtlSysStatus.EdrData_03.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_TractionCtlSysStatus.EdrData_03.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b00011000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
				'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '4',
			   						  'Min_Value' => 0,
									  'Max_Value' => 3,
			                        },
               },

'Edr_TurnSglSwStatus' =>
               {
               'SIGNAL_NAME'   => 'Edr_TurnSglSwStatus',      'CANOE_ENV_VAR' => 'EnvEdr_TurnSglSwStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_03',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 18, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_TurnSglSwStatus.EdrData_03.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_TurnSglSwStatus.EdrData_03.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b00000111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '4',
			   						  'Min_Value' => 0,
									  'Max_Value' => 3,
               },
},
# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: EdrData_04 (Vector__XXX) ID: 771 (0x303), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Edr_BrakePedalPosition' =>
               {
               'SIGNAL_NAME'   => 'Edr_BrakePedalPosition',      'CANOE_ENV_VAR' => 'EnvEdr_BrakePedalPosition_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_04',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_BrakePedalPosition.EdrData_04.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_BrakePedalPosition.EdrData_04.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 100,
									  'RandomInRange' => 10,
									  'FAULTY' => '101',
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 },
               },

'Edr_BrakingSystemWarningStatus' =>
               {
               'SIGNAL_NAME'   => 'Edr_BrakingSystemWarningStatus',      'CANOE_ENV_VAR' => 'EnvEdr_BrakingSystemWarningStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_04',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 11, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_BrakingSystemWarningStatus.EdrData_04.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_BrakingSystemWarningStatus.EdrData_04.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00001100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '2',
               },
               },

'Edr_EngineRPM_V2' =>
               {
               'SIGNAL_NAME'   => 'Edr_EngineRPM_V2',      'CANOE_ENV_VAR' => 'EnvEdr_EngineRPM_V2_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_04',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => 'rpm',
               'LC_READ_PHYS'  => 'Edr_EngineRPM_V2.EdrData_04.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_EngineRPM_V2.EdrData_04.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' , 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => {
									  'Min_Value' => 0,
									  'Max_Value' => 10000, # 10048 65533
									  'RandomInRange' => 10,
									  'FAULTY' => '65534', # 10112 65534
									  'DEFAULTVALUE' => '0',
									  'DefaultValue' => '0',
									 },
               },

'Edr_ParkingSystemStatus' =>
               {
               'SIGNAL_NAME'   => 'Edr_ParkingSystemStatus',      'CANOE_ENV_VAR' => 'EnvEdr_ParkingSystemStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'EdrData_04',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 9, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Edr_ParkingSystemStatus.EdrData_04.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Edr_ParkingSystemStatus.EdrData_04.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00000011' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
			   'DataValueTable' => { 'DefaultValue' => '0',
			   						  'FAULTY' => '3',#need to check with 1
			   						  'Min_Value' => 0,
									  'Max_Value' => 2, # 10048 65533
									  'RandomInRange' => 1,
               },
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Airbag01 (AB_ECU) ID: 1024 (0x400), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Airbag01_BeltLockFrontDriver' =>
               {
               'SIGNAL_NAME'   => 'Airbag01_BeltLockFrontDriver',      'CANOE_ENV_VAR' => 'EnvAirbag01_BeltLockFrontDriver_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 1, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag01_BeltLockFrontDriver.Airbag01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag01_BeltLockFrontDriver.Airbag01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000011' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Airbag01_BeltLockFrontPassenger' =>
               {
               'SIGNAL_NAME'   => 'Airbag01_BeltLockFrontPassenger',      'CANOE_ENV_VAR' => 'EnvAirbag01_BeltLockFrontPassenger_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag01_BeltLockFrontPassenger.Airbag01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag01_BeltLockFrontPassenger.Airbag01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Airbag01_RollingCounter' =>
               {
               'SIGNAL_NAME'   => 'Airbag01_RollingCounter',      'CANOE_ENV_VAR' => 'EnvAirbag01_RollingCounter_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 6, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag01_RollingCounter.Airbag01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag01_RollingCounter.Airbag01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Airbag01_TestUint8NSignal' =>
               {
               'SIGNAL_NAME'   => 'Airbag01_TestUint8NSignal',      'CANOE_ENV_VAR' => 'EnvAirbag01_TestUint8NSignal_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 48, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag01_TestUint8NSignal.Airbag01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag01_TestUint8NSignal.Airbag01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Airbag_MSB (AB_ECU) ID: 1026 (0x402), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Airbag_MSB_FD' =>
               {
               'SIGNAL_NAME'   => 'Airbag_MSB_FD',      'CANOE_ENV_VAR' => 'EnvAirbag_MSB_FD_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag_MSB',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag_MSB_FD.Airbag_MSB.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag_MSB_FD.Airbag_MSB.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11100000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Airbag_MSB_FP' =>
               {
               'SIGNAL_NAME'   => 'Airbag_MSB_FP',      'CANOE_ENV_VAR' => 'EnvAirbag_MSB_FP_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag_MSB',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 4, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag_MSB_FP.Airbag_MSB.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag_MSB_FP.Airbag_MSB.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00011100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Airbag_MSB_RC' =>
               {
               'SIGNAL_NAME'   => 'Airbag_MSB_RC',      'CANOE_ENV_VAR' => 'EnvAirbag_MSB_RC_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag_MSB',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 12, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag_MSB_RC.Airbag_MSB.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag_MSB_RC.Airbag_MSB.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b00011100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Airbag_MSB_RD' =>
               {
               'SIGNAL_NAME'   => 'Airbag_MSB_RD',      'CANOE_ENV_VAR' => 'EnvAirbag_MSB_RD_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag_MSB',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag_MSB_RD.Airbag_MSB.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag_MSB_RD.Airbag_MSB.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11100000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Airbag_MSB_RP' =>
               {
               'SIGNAL_NAME'   => 'Airbag_MSB_RP',      'CANOE_ENV_VAR' => 'EnvAirbag_MSB_RP_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Airbag_MSB',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Airbag_MSB_RP.Airbag_MSB.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Airbag_MSB_RP.Airbag_MSB.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11100000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: CustDiag_Physical_Response (AB_ECU) ID: 1276 (0x4fc), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'CustDiag_Physical_ResponseByte1' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte1',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte1.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte1.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_ResponseByte2' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte2',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte2_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte2.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte2.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_ResponseByte3' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte3',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte3_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte3.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte3.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_ResponseByte4' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte4',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte4_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte4.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte4.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_ResponseByte5' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte5',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte5_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte5.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte5.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_ResponseByte6' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte6',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte6_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte6.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte6.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_ResponseByte7' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte7',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte7_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte7.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte7.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_ResponseByte8' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_ResponseByte8',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_ResponseByte8_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CustDiag_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_ResponseByte8.CustDiag_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_ResponseByte8.CustDiag_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: FLM_env_data (Other_ECU) ID: 1280 (0x500), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'FLM_EnvData_Mileage' =>
               {
               'SIGNAL_NAME'   => 'FLM_EnvData_Mileage',      'CANOE_ENV_VAR' => 'EnvFLM_EnvData_Mileage_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'FLM_env_data',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 20, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => 'kilometer',
               'LC_READ_PHYS'  => 'FLM_EnvData_Mileage.FLM_env_data.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'FLM_EnvData_Mileage.FLM_env_data.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11110000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Temperature (Other_ECU) ID: 1296 (0x510), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'Ext_TestUint8NSignal' =>
               {
               'SIGNAL_NAME'   => 'Ext_TestUint8NSignal',      'CANOE_ENV_VAR' => 'EnvExt_TestUint8NSignal_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'Temperature',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 40, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Ext_TestUint8NSignal.Temperature.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Ext_TestUint8NSignal.Temperature.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Ext_temperature' =>
               {
               'SIGNAL_NAME'   => 'Ext_temperature',      'CANOE_ENV_VAR' => 'EnvExt_temperature_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'Temperature',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => -50.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Ext_temperature.Temperature.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Ext_temperature.Temperature.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'TemperatureStatus' =>
               {
               'SIGNAL_NAME'   => 'TemperatureStatus',      'CANOE_ENV_VAR' => 'EnvTemperatureStatus_',
               'SENDER'        => 'Other_ECU',
               'MESSAGE'       => 'Temperature',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'TemperatureStatus.Temperature.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'TemperatureStatus.Temperature.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Sensordata (AB_ECU) ID: 1536 (0x600), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'SensorData1' =>
               {
               'SIGNAL_NAME'   => 'SensorData1',      'CANOE_ENV_VAR' => 'EnvSensorData1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 16, 'OFFSET' => -32767.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SensorData1.Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SensorData1.Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'SensorStatus1no' =>
               {
               'SIGNAL_NAME'   => 'SensorStatus1no',      'CANOE_ENV_VAR' => 'EnvSensorStatus1no_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SensorStatus1no.Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SensorStatus1no.Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: ProDiag_Request (Tester) ID: 1616 (0x650), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'ProDiag_RequestByte1' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte1',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte1_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte1.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte1.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_RequestByte2' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte2',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte2_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte2.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte2.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_RequestByte3' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte3',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte3_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte3.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte3.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_RequestByte4' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte4',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte4_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte4.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte4.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_RequestByte5' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte5',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte5_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte5.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte5.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_RequestByte6' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte6',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte6_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte6.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte6.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_RequestByte7' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte7',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte7_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte7.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte7.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_RequestByte8' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_RequestByte8',      'CANOE_ENV_VAR' => 'EnvProDiag_RequestByte8_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'ProDiag_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_RequestByte8.ProDiag_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_RequestByte8.ProDiag_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: ProDiag_Response1 (AB_ECU) ID: 1617 (0x651), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'ProDiag_Response1Byte1' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte1',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte1.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte1.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response1Byte2' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte2',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte2_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte2.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte2.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response1Byte3' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte3',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte3_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte3.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte3.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response1Byte4' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte4',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte4_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte4.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte4.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response1Byte5' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte5',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte5_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte5.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte5.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response1Byte6' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte6',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte6_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte6.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte6.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response1Byte7' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte7',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte7_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte7.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte7.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response1Byte8' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response1Byte8',      'CANOE_ENV_VAR' => 'EnvProDiag_Response1Byte8_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response1Byte8.ProDiag_Response1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response1Byte8.ProDiag_Response1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: ProDiag_Response2 (AB_ECU) ID: 1618 (0x652), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'ProDiag_Response2Byte1' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte1',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte1.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte1.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response2Byte2' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte2',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte2_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte2.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte2.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response2Byte3' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte3',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte3_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte3.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte3.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response2Byte4' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte4',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte4_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte4.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte4.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response2Byte5' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte5',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte5_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte5.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte5.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response2Byte6' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte6',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte6_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte6.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte6.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response2Byte7' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte7',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte7_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte7.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte7.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response2Byte8' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response2Byte8',      'CANOE_ENV_VAR' => 'EnvProDiag_Response2Byte8_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response2Byte8.ProDiag_Response2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response2Byte8.ProDiag_Response2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: ProDiag_Response3 (AB_ECU) ID: 1619 (0x653), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'ProDiag_Response3Byte1' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte1',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte1.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte1.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response3Byte2' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte2',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte2_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte2.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte2.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response3Byte3' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte3',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte3_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte3.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte3.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response3Byte4' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte4',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte4_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte4.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte4.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response3Byte5' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte5',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte5_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte5.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte5.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response3Byte6' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte6',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte6_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte6.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte6.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response3Byte7' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte7',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte7_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte7.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte7.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response3Byte8' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response3Byte8',      'CANOE_ENV_VAR' => 'EnvProDiag_Response3Byte8_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response3',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response3Byte8.ProDiag_Response3.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response3Byte8.ProDiag_Response3.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: ProDiag_Response4 (AB_ECU) ID: 1620 (0x654), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'ProDiag_Response4Byte1' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte1',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte1.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte1.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response4Byte2' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte2',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte2_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte2.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte2.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response4Byte3' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte3',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte3_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte3.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte3.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response4Byte4' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte4',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte4_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte4.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte4.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response4Byte5' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte5',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte5_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte5.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte5.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response4Byte6' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte6',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte6_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte6.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte6.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response4Byte7' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte7',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte7_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte7.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte7.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ProDiag_Response4Byte8' =>
               {
               'SIGNAL_NAME'   => 'ProDiag_Response4Byte8',      'CANOE_ENV_VAR' => 'EnvProDiag_Response4Byte8_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'ProDiag_Response4',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ProDiag_Response4Byte8.ProDiag_Response4.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ProDiag_Response4Byte8.ProDiag_Response4.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: PrdFastDiagRespViaCANFD1 (AB_ECU) ID: 1621 (0x655), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'PrdFastDiagRespViaCANFD1Byte1' =>
               {
               'SIGNAL_NAME'   => 'PrdFastDiagRespViaCANFD1Byte1',      'CANOE_ENV_VAR' => 'EnvPrdFastDiagRespViaCANFD1Byte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'PrdFastDiagRespViaCANFD1',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 512, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'PrdFastDiagRespViaCANFD1Byte1.PrdFastDiagRespViaCANFD1.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'PrdFastDiagRespViaCANFD1Byte1.PrdFastDiagRespViaCANFD1.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' , 8 => '0b11111111' , 9 => '0b11111111' , 10 => '0b11111111' , 11 => '0b11111111' , 12 => '0b11111111' , 13 => '0b11111111' , 14 => '0b11111111' , 15 => '0b11111111' , 16 => '0b11111111' , 17 => '0b11111111' , 18 => '0b11111111' , 19 => '0b11111111' , 20 => '0b11111111' , 21 => '0b11111111' , 22 => '0b11111111' , 23 => '0b11111111' , 24 => '0b11111111' , 25 => '0b11111111' , 26 => '0b11111111' , 27 => '0b11111111' , 28 => '0b11111111' , 29 => '0b11111111' , 30 => '0b11111111' , 31 => '0b11111111' , 32 => '0b11111111' , 33 => '0b11111111' , 34 => '0b11111111' , 35 => '0b11111111' , 36 => '0b11111111' , 37 => '0b11111111' , 38 => '0b11111111' , 39 => '0b11111111' , 40 => '0b11111111' , 41 => '0b11111111' , 42 => '0b11111111' , 43 => '0b11111111' , 44 => '0b11111111' , 45 => '0b11111111' , 46 => '0b11111111' , 47 => '0b11111111' , 48 => '0b11111111' , 49 => '0b11111111' , 50 => '0b11111111' , 51 => '0b11111111' , 52 => '0b11111111' , 53 => '0b11111111' , 54 => '0b11111111' , 55 => '0b11111111' , 56 => '0b11111111' , 57 => '0b11111111' , 58 => '0b11111111' , 59 => '0b11111111' , 60 => '0b11111111' , 61 => '0b11111111' , 62 => '0b11111111' , 63 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: PrdFastDiagRespViaCANFD2 (AB_ECU) ID: 1622 (0x656), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'PrdFastDiagRespViaCANFD2Byte1' =>
               {
               'SIGNAL_NAME'   => 'PrdFastDiagRespViaCANFD2Byte1',      'CANOE_ENV_VAR' => 'EnvPrdFastDiagRespViaCANFD2Byte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'PrdFastDiagRespViaCANFD2',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 512, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'PrdFastDiagRespViaCANFD2Byte1.PrdFastDiagRespViaCANFD2.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'PrdFastDiagRespViaCANFD2Byte1.PrdFastDiagRespViaCANFD2.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' , 8 => '0b11111111' , 9 => '0b11111111' , 10 => '0b11111111' , 11 => '0b11111111' , 12 => '0b11111111' , 13 => '0b11111111' , 14 => '0b11111111' , 15 => '0b11111111' , 16 => '0b11111111' , 17 => '0b11111111' , 18 => '0b11111111' , 19 => '0b11111111' , 20 => '0b11111111' , 21 => '0b11111111' , 22 => '0b11111111' , 23 => '0b11111111' , 24 => '0b11111111' , 25 => '0b11111111' , 26 => '0b11111111' , 27 => '0b11111111' , 28 => '0b11111111' , 29 => '0b11111111' , 30 => '0b11111111' , 31 => '0b11111111' , 32 => '0b11111111' , 33 => '0b11111111' , 34 => '0b11111111' , 35 => '0b11111111' , 36 => '0b11111111' , 37 => '0b11111111' , 38 => '0b11111111' , 39 => '0b11111111' , 40 => '0b11111111' , 41 => '0b11111111' , 42 => '0b11111111' , 43 => '0b11111111' , 44 => '0b11111111' , 45 => '0b11111111' , 46 => '0b11111111' , 47 => '0b11111111' , 48 => '0b11111111' , 49 => '0b11111111' , 50 => '0b11111111' , 51 => '0b11111111' , 52 => '0b11111111' , 53 => '0b11111111' , 54 => '0b11111111' , 55 => '0b11111111' , 56 => '0b11111111' , 57 => '0b11111111' , 58 => '0b11111111' , 59 => '0b11111111' , 60 => '0b11111111' , 61 => '0b11111111' , 62 => '0b11111111' , 63 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: CustDiag_Physical_Request (Tester) ID: 1756 (0x6dc), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'CustDiag_Physical_RequestByte1' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte1',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte1_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte1.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte1.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_RequestByte2' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte2',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte2_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte2.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte2.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_RequestByte3' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte3',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte3_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte3.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte3.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_RequestByte4' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte4',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte4_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte4.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte4.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_RequestByte5' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte5',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte5_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte5.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte5.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_RequestByte6' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte6',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte6_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte6.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte6.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_RequestByte7' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte7',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte7_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte7.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte7.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Physical_RequestByte8' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Physical_RequestByte8',      'CANOE_ENV_VAR' => 'EnvCustDiag_Physical_RequestByte8_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Physical_RequestByte8.CustDiag_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Physical_RequestByte8.CustDiag_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: CustDiag_Functional_Request (Tester) ID: 1772 (0x6ec), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'CustDiag_Functional_RequestByte1' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte1',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte1_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte1.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte1.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Functional_RequestByte2' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte2',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte2_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte2.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte2.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Functional_RequestByte3' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte3',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte3_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte3.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte3.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Functional_RequestByte4' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte4',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte4_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte4.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte4.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Functional_RequestByte5' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte5',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte5_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte5.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte5.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Functional_RequestByte6' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte6',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte6_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte6.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte6.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Functional_RequestByte7' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte7',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte7_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte7.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte7.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CustDiag_Functional_RequestByte8' =>
               {
               'SIGNAL_NAME'   => 'CustDiag_Functional_RequestByte8',      'CANOE_ENV_VAR' => 'EnvCustDiag_Functional_RequestByte8_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'CustDiag_Functional_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CustDiag_Functional_RequestByte8.CustDiag_Functional_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CustDiag_Functional_RequestByte8.CustDiag_Functional_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: CANFDTestRx01 (Vector__XXX) ID: 1809 (0x711), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'CanFDRxSignal01' =>
               {
               'SIGNAL_NAME'   => 'CanFDRxSignal01',      'CANOE_ENV_VAR' => 'EnvCanFDRxSignal01_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'CANFDTestRx01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 512, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CanFDRxSignal01.CANFDTestRx01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CanFDRxSignal01.CANFDTestRx01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' , 8 => '0b11111111' , 9 => '0b11111111' , 10 => '0b11111111' , 11 => '0b11111111' , 12 => '0b11111111' , 13 => '0b11111111' , 14 => '0b11111111' , 15 => '0b11111111' , 16 => '0b11111111' , 17 => '0b11111111' , 18 => '0b11111111' , 19 => '0b11111111' , 20 => '0b11111111' , 21 => '0b11111111' , 22 => '0b11111111' , 23 => '0b11111111' , 24 => '0b11111111' , 25 => '0b11111111' , 26 => '0b11111111' , 27 => '0b11111111' , 28 => '0b11111111' , 29 => '0b11111111' , 30 => '0b11111111' , 31 => '0b11111111' , 32 => '0b11111111' , 33 => '0b11111111' , 34 => '0b11111111' , 35 => '0b11111111' , 36 => '0b11111111' , 37 => '0b11111111' , 38 => '0b11111111' , 39 => '0b11111111' , 40 => '0b11111111' , 41 => '0b11111111' , 42 => '0b11111111' , 43 => '0b11111111' , 44 => '0b11111111' , 45 => '0b11111111' , 46 => '0b11111111' , 47 => '0b11111111' , 48 => '0b11111111' , 49 => '0b11111111' , 50 => '0b11111111' , 51 => '0b11111111' , 52 => '0b11111111' , 53 => '0b11111111' , 54 => '0b11111111' , 55 => '0b11111111' , 56 => '0b11111111' , 57 => '0b11111111' , 58 => '0b11111111' , 59 => '0b11111111' , 60 => '0b11111111' , 61 => '0b11111111' , 62 => '0b11111111' , 63 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: CANFDTestTx01 (AB_ECU) ID: 1810 (0x712), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'CANFDTxSignal01' =>
               {
               'SIGNAL_NAME'   => 'CANFDTxSignal01',      'CANOE_ENV_VAR' => 'EnvCANFDTxSignal01_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CANFDTestTx01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 480, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CANFDTxSignal01.CANFDTestTx01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CANFDTxSignal01.CANFDTestTx01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' , 8 => '0b11111111' , 9 => '0b11111111' , 10 => '0b11111111' , 11 => '0b11111111' , 12 => '0b11111111' , 13 => '0b11111111' , 14 => '0b11111111' , 15 => '0b11111111' , 16 => '0b11111111' , 17 => '0b11111111' , 18 => '0b11111111' , 19 => '0b11111111' , 20 => '0b11111111' , 21 => '0b11111111' , 22 => '0b11111111' , 23 => '0b11111111' , 24 => '0b11111111' , 25 => '0b11111111' , 26 => '0b11111111' , 27 => '0b11111111' , 28 => '0b11111111' , 29 => '0b11111111' , 30 => '0b11111111' , 31 => '0b11111111' , 32 => '0b11111111' , 33 => '0b11111111' , 34 => '0b11111111' , 35 => '0b11111111' , 36 => '0b11111111' , 37 => '0b11111111' , 38 => '0b11111111' , 39 => '0b11111111' , 40 => '0b11111111' , 41 => '0b11111111' , 42 => '0b11111111' , 43 => '0b11111111' , 44 => '0b11111111' , 45 => '0b11111111' , 46 => '0b11111111' , 47 => '0b11111111' , 48 => '0b11111111' , 49 => '0b11111111' , 50 => '0b11111111' , 51 => '0b11111111' , 52 => '0b11111111' , 53 => '0b11111111' , 54 => '0b11111111' , 55 => '0b11111111' , 56 => '0b11111111' , 57 => '0b11111111' , 58 => '0b11111111' , 59 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CANFDTxSignal02' =>
               {
               'SIGNAL_NAME'   => 'CANFDTxSignal02',      'CANOE_ENV_VAR' => 'EnvCANFDTxSignal02_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'CANFDTestTx01',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 480, 'LENGTH' => 32, 'OFFSET' => 0.000000, 'FACTOR' => 0.001000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'CANFDTxSignal02.CANFDTestTx01.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CANFDTxSignal02.CANFDTestTx01.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 60 => '0b11111111' , 61 => '0b11111111' , 62 => '0b11111111' , 63 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: VDS_Sensordata (AB_ECU) ID: 1811 (0x713), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'VDS_CANFDHeaveSignalData' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDHeaveSignalData',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDHeaveSignalData_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.000200,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => 'g',
               'LC_READ_PHYS'  => 'VDS_CANFDHeaveSignalData.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDHeaveSignalData.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDHeaveSignalStatus' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDHeaveSignalStatus',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDHeaveSignalStatus_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 112, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDS_CANFDHeaveSignalStatus.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDHeaveSignalStatus.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 14 => '0b00000011' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDLateralSignalData' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDLateralSignalData',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDLateralSignalData_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.000200,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => 'g',
               'LC_READ_PHYS'  => 'VDS_CANFDLateralSignalData.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDLateralSignalData.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' , 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDLateralSignalStatus' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDLateralSignalStatus',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDLateralSignalStatus_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 114, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDS_CANFDLateralSignalStatus.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDLateralSignalStatus.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 14 => '0b00001100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDLinearSignalData' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDLinearSignalData',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDLinearSignalData_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 32, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.000200,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => 'g',
               'LC_READ_PHYS'  => 'VDS_CANFDLinearSignalData.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDLinearSignalData.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' , 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDLinearSignalStatus' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDLinearSignalStatus',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDLinearSignalStatus_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 116, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDS_CANFDLinearSignalStatus.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDLinearSignalStatus.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 14 => '0b00110000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDPitchSignalData' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDPitchSignalData',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDPitchSignalData_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 48, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.010000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '�/s',
               'LC_READ_PHYS'  => 'VDS_CANFDPitchSignalData.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDPitchSignalData.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' , 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDPitchSignalStatus' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDPitchSignalStatus',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDPitchSignalStatus_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 118, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDS_CANFDPitchSignalStatus.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDPitchSignalStatus.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 14 => '0b11000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDRollSignalData' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDRollSignalData',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDRollSignalData_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 64, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.010000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '�/s',
               'LC_READ_PHYS'  => 'VDS_CANFDRollSignalData.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDRollSignalData.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 8 => '0b11111111' , 9 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDRollSignalStatus' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDRollSignalStatus',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDRollSignalStatus_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 120, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDS_CANFDRollSignalStatus.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDRollSignalStatus.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 15 => '0b00000011' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDTemperatureSignalData' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDTemperatureSignalData',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDTemperatureSignalData_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 96, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.005000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '�C',
               'LC_READ_PHYS'  => 'VDS_CANFDTemperatureSignalData.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDTemperatureSignalData.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 12 => '0b11111111' , 13 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDYawSignalData' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDYawSignalData',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDYawSignalData_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 80, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.010000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '�/s',
               'LC_READ_PHYS'  => 'VDS_CANFDYawSignalData.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDYawSignalData.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 10 => '0b11111111' , 11 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'VDS_CANFDYawSignalStatus' =>
               {
               'SIGNAL_NAME'   => 'VDS_CANFDYawSignalStatus',      'CANOE_ENV_VAR' => 'EnvVDS_CANFDYawSignalStatus_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'VDS_Sensordata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 122, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'VDS_CANFDYawSignalStatus.VDS_Sensordata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'VDS_CANFDYawSignalStatus.VDS_Sensordata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 15 => '0b00001100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: IsoDisp_Physical_Request (Tester) ID: 2033 (0x7f1), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'IsoDisp_Physical_RequestByte1' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte1',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte1_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte1.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte1.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_RequestByte2' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte2',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte2_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte2.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte2.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_RequestByte3' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte3',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte3_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte3.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte3.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_RequestByte4' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte4',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte4_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte4.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte4.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_RequestByte5' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte5',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte5_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte5.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte5.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_RequestByte6' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte6',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte6_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte6.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte6.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_RequestByte7' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte7',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte7_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte7.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte7.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_RequestByte8' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_RequestByte8',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_RequestByte8_',
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'IsoDisp_Physical_Request',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_RequestByte8.IsoDisp_Physical_Request.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_RequestByte8.IsoDisp_Physical_Request.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: IsoDisp_Physical_Response (AB_ECU) ID: 2041 (0x7f9), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'IsoDisp_Physical_ResponseByte1' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte1',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte1_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte1.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte1.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_ResponseByte2' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte2',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte2_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte2.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte2.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_ResponseByte3' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte3',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte3_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte3.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte3.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_ResponseByte4' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte4',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte4_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte4.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte4.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_ResponseByte5' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte5',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte5_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte5.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte5.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_ResponseByte6' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte6',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte6_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte6.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte6.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_ResponseByte7' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte7',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte7_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte7.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte7.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IsoDisp_Physical_ResponseByte8' =>
               {
               'SIGNAL_NAME'   => 'IsoDisp_Physical_ResponseByte8',      'CANOE_ENV_VAR' => 'EnvIsoDisp_Physical_ResponseByte8_',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'IsoDisp_Physical_Response',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IsoDisp_Physical_ResponseByte8.IsoDisp_Physical_Response.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IsoDisp_Physical_ResponseByte8.IsoDisp_Physical_Response.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: VECTOR__INDEPENDENT_SIG_MSG (Vector__XXX) ID: 3221225472 (0xc0000000), DBC File name :AB12_CoreAssets_CanDatabase ------------- 

# -------------------------------------------------------------------------------------- 

'EDR_SCSStatus' =>
               {
               'SIGNAL_NAME'   => 'EDR_SCSStatus',      'CANOE_ENV_VAR' => 'EnvEDR_SCSStatus_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'VECTOR__INDEPENDENT_SIG_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EDR_SCSStatus.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EDR_SCSStatus.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IDF_01_BZ' =>
               {
               'SIGNAL_NAME'   => 'IDF_01_BZ',      'CANOE_ENV_VAR' => 'EnvIDF_01_BZ_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'VECTOR__INDEPENDENT_SIG_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 4, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IDF_01_BZ.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IDF_01_BZ.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b1111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IDF_01_CRC' =>
               {
               'SIGNAL_NAME'   => 'IDF_01_CRC',      'CANOE_ENV_VAR' => 'EnvIDF_01_CRC_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'VECTOR__INDEPENDENT_SIG_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IDF_01_CRC.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IDF_01_CRC.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'New_Signal_174' =>
               {
               'SIGNAL_NAME'   => 'New_Signal_174',      'CANOE_ENV_VAR' => 'EnvNew_Signal_174_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'VECTOR__INDEPENDENT_SIG_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'New_Signal_174.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'New_Signal_174.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'New_Signal_184' =>
               {
               'SIGNAL_NAME'   => 'New_Signal_184',      'CANOE_ENV_VAR' => 'EnvNew_Signal_184_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'VECTOR__INDEPENDENT_SIG_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'New_Signal_184.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'New_Signal_184.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

};
# end of CAN mapping

1;
